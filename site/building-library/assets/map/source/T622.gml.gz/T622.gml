<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b42b3bca-38e5-4b32-9f8e-0a8fa877cd2b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">14.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669318369209 139.73908532900924 0 35.66929445245262 139.7391271556013 0 35.66925724957987 139.73919221668348 0 35.669249221924616 139.73918526706362 0 35.6692329292766 139.73921367467457 0 35.66930887584208 139.73927886804552 0 35.66938628818529 139.73914357270021 0 35.669318369209 139.73908532900924 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669318369209 139.73908532900924 13.106 35.66938628818529 139.73914357270021 13.106 35.66930887584208 139.73927886804552 13.106 35.6692329292766 139.73921367467457 13.106 35.669249221924616 139.73918526706362 13.106 35.66925724957987 139.73919221668348 13.106 35.66929445245262 139.7391271556013 13.106 35.669318369209 139.73908532900924 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669318369209 139.73908532900924 13.106 35.66929445245262 139.7391271556013 13.106 35.66929445245262 139.7391271556013 27.6 35.669318369209 139.73908532900924 27.6 35.669318369209 139.73908532900924 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929445245262 139.7391271556013 13.106 35.66925724957987 139.73919221668348 13.106 35.66925724957987 139.73919221668348 27.6 35.66929445245262 139.7391271556013 27.6 35.66929445245262 139.7391271556013 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925724957987 139.73919221668348 13.106 35.669249221924616 139.73918526706362 13.106 35.669249221924616 139.73918526706362 27.6 35.66925724957987 139.73919221668348 27.6 35.66925724957987 139.73919221668348 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669249221924616 139.73918526706362 13.106 35.6692329292766 139.73921367467457 13.106 35.6692329292766 139.73921367467457 27.6 35.669249221924616 139.73918526706362 27.6 35.669249221924616 139.73918526706362 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6692329292766 139.73921367467457 13.106 35.66930887584208 139.73927886804552 13.106 35.66930887584208 139.73927886804552 27.6 35.6692329292766 139.73921367467457 27.6 35.6692329292766 139.73921367467457 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66930887584208 139.73927886804552 13.106 35.66938628818529 139.73914357270021 13.106 35.66938628818529 139.73914357270021 27.6 35.66930887584208 139.73927886804552 27.6 35.66930887584208 139.73927886804552 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66938628818529 139.73914357270021 13.106 35.669318369209 139.73908532900924 13.106 35.669318369209 139.73908532900924 27.6 35.66938628818529 139.73914357270021 27.6 35.66938628818529 139.73914357270021 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669318369209 139.73908532900924 27.6 35.66929445245262 139.7391271556013 27.6 35.66925724957987 139.73919221668348 27.6 35.669249221924616 139.73918526706362 27.6 35.6692329292766 139.73921367467457 27.6 35.66930887584208 139.73927886804552 27.6 35.66938628818529 139.73914357270021 27.6 35.669318369209 139.73908532900924 27.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fa346965-a3c8-49b1-b950-df56c1e0cd2d"/>
							<gml:surfaceMember xlink:href="#poly-83c49874-1a33-45c0-9baa-cf9e73db2324"/>
							<gml:surfaceMember xlink:href="#poly-c183dd24-7ec7-4186-b936-797706a24707"/>
							<gml:surfaceMember xlink:href="#poly-8d29d289-46b7-47b0-a8e4-f55369d8781f"/>
							<gml:surfaceMember xlink:href="#poly-55e40e50-eb4c-4b01-b51c-426988ee2d5c"/>
							<gml:surfaceMember xlink:href="#poly-96d4355d-a307-48da-b599-c660a09a6dca"/>
							<gml:surfaceMember xlink:href="#poly-f83e6ac3-8c2d-412c-b6ac-f99838caabb8"/>
							<gml:surfaceMember xlink:href="#poly-7e9e7d1a-8a45-4621-a685-cd1bce308244"/>
							<gml:surfaceMember xlink:href="#poly-6d4bc110-fa96-42c5-801e-ed16a99e2896"/>
							<gml:surfaceMember xlink:href="#poly-f7627899-7fec-4be5-a730-6e82666f4959"/>
							<gml:surfaceMember xlink:href="#poly-3e6f7bb2-4050-421d-8323-4e503b19f82d"/>
							<gml:surfaceMember xlink:href="#poly-3746db5b-eba9-4a7a-89e5-3540aaada51c"/>
							<gml:surfaceMember xlink:href="#poly-6642dd7f-a3ea-4ffe-b074-be018434b8bd"/>
							<gml:surfaceMember xlink:href="#poly-4541688d-1a7d-4841-a0e7-25f33587b34f"/>
							<gml:surfaceMember xlink:href="#poly-d5df08d9-842c-421a-9a04-dab8dd54298d"/>
							<gml:surfaceMember xlink:href="#poly-11be65e1-a112-42ac-8eec-aeafc140cf3e"/>
							<gml:surfaceMember xlink:href="#poly-201d5621-e499-4ba7-85cd-eaa670f39294"/>
							<gml:surfaceMember xlink:href="#poly-81a95f3b-7393-4de0-a741-717e28f87699"/>
							<gml:surfaceMember xlink:href="#poly-4379c755-5335-4939-b7af-5bdbde098e9c"/>
							<gml:surfaceMember xlink:href="#poly-a5dc5374-769d-40e0-be23-5c99c6ba89d8"/>
							<gml:surfaceMember xlink:href="#poly-4f49605f-8183-4add-80db-27bf628b09a5"/>
							<gml:surfaceMember xlink:href="#poly-e13da9a5-dd8c-42db-a1ad-0d140228bc86"/>
							<gml:surfaceMember xlink:href="#poly-25ca7fb5-5cc3-4bf3-a2d3-7f926831261c"/>
							<gml:surfaceMember xlink:href="#poly-b061c9e8-3a5c-4177-b5a6-038c09cc5c28"/>
							<gml:surfaceMember xlink:href="#poly-36707788-1e35-4fb6-9002-7fe984488448"/>
							<gml:surfaceMember xlink:href="#poly-5c7bbd39-25db-4782-8349-6666cc74430a"/>
							<gml:surfaceMember xlink:href="#poly-cb44a633-8dd8-4933-b8fe-b916410eeb89"/>
							<gml:surfaceMember xlink:href="#poly-9a1e8d9f-a3ea-4da3-8260-712d8c98e41d"/>
							<gml:surfaceMember xlink:href="#poly-b14a86d4-95c0-4695-a31b-5eec71886d02"/>
							<gml:surfaceMember xlink:href="#poly-3ad2011e-7477-4728-ac4f-d44fb03dbe1e"/>
							<gml:surfaceMember xlink:href="#poly-9985a48b-f0f2-483b-be46-95bd9bbbaaac"/>
							<gml:surfaceMember xlink:href="#poly-fe5bbb81-5259-4e27-ad65-8a7902a150e7"/>
							<gml:surfaceMember xlink:href="#poly-6efddb7a-5a35-49ad-951f-7c6b0494b3a2"/>
							<gml:surfaceMember xlink:href="#poly-edf3aa66-b776-4ce3-978e-204016981e47"/>
							<gml:surfaceMember xlink:href="#poly-7150d63c-da6b-46bf-9183-f982db309658"/>
							<gml:surfaceMember xlink:href="#poly-2b1a9f5e-ede6-42d7-abfc-a68a6888ab6f"/>
							<gml:surfaceMember xlink:href="#poly-ac40a5a9-9456-4561-91d0-350697cbb019"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b42b3bca-38e5-4b32-9f8e-0a8fa877cd2b_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84db929d-f812-416d-8773-926531feb93b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669318369208995 139.73908532900924 13.106 35.66929445245262 139.73912715560127 13.106 35.6692841969519 139.73911835285625 13.106 35.66930811370525 139.73907652626696 13.106 35.669318369208995 139.73908532900924 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05dba55c-dc7b-4de7-982f-52aa37bd1c0d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931870022563 139.73912822067717 27.655 35.66932516742103 139.73913378032026 27.655 35.669309018866805 139.7391620110616 27.655 35.669302560695044 139.7391564624529 27.655 35.66931870022563 139.73912822067717 27.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e692f5ab-62c9-4b3e-a917-aaff280846e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e692f5ab-62c9-4b3e-a917-aaff280846e1_0">
											<gml:posList>35.66929445245262 139.73912715560127 13.106 35.66929445245262 139.73912715560127 27.723 35.6692841969519 139.73911835285625 27.723 35.6692841969519 139.73911835285625 13.106 35.66929445245262 139.73912715560127 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dfe9a9c-eefe-4b61-ac53-d9f9bfd7a9da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4dfe9a9c-eefe-4b61-ac53-d9f9bfd7a9da_0">
											<gml:posList>35.66930811370525 139.73907652626696 27.723 35.66930811370525 139.73907652626696 13.106 35.6692841969519 139.73911835285625 13.106 35.6692841969519 139.73911835285625 27.723 35.66930811370525 139.73907652626696 27.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d407d43-f0e5-4131-ad77-622cd9ab7486">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d407d43-f0e5-4131-ad77-622cd9ab7486_0">
											<gml:posList>35.66929445245262 139.73912715560127 27.723 35.669318369208995 139.73908532900924 27.723 35.66930811370525 139.73907652626696 27.723 35.6692841969519 139.73911835285625 27.723 35.66929445245262 139.73912715560127 27.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a8b52fe-59b5-4032-9e86-5ca85f083fef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a8b52fe-59b5-4032-9e86-5ca85f083fef_0">
											<gml:posList>35.669318369208995 139.73908532900924 27.723 35.669318369208995 139.73908532900924 13.106 35.66930811370525 139.73907652626696 13.106 35.66930811370525 139.73907652626696 27.723 35.669318369208995 139.73908532900924 27.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a6c803d-9214-4f36-a78e-be3fbf558387">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a6c803d-9214-4f36-a78e-be3fbf558387_0">
											<gml:posList>35.66931870022563 139.73912822067717 27.655 35.66931870022563 139.73912822067717 28.678 35.66932516742103 139.73913378032026 28.678 35.66932516742103 139.73913378032026 27.655 35.66931870022563 139.73912822067717 27.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efd6ca26-6b28-41cc-b4cd-5809a2bee73c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efd6ca26-6b28-41cc-b4cd-5809a2bee73c_0">
											<gml:posList>35.66931870022563 139.73912822067717 28.678 35.66931870022563 139.73912822067717 27.655 35.669302560695044 139.7391564624529 27.655 35.669302560695044 139.7391564624529 28.678 35.66931870022563 139.73912822067717 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67b1b9b8-c3a0-4ed7-a04f-560b9b751f66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67b1b9b8-c3a0-4ed7-a04f-560b9b751f66_0">
											<gml:posList>35.669309018866805 139.7391620110616 28.678 35.66932516742103 139.73913378032026 28.678 35.66931870022563 139.73912822067717 28.678 35.669302560695044 139.7391564624529 28.678 35.669309018866805 139.7391620110616 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b3edf9b-d856-41e3-985b-1051993e64c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b3edf9b-d856-41e3-985b-1051993e64c6_0">
											<gml:posList>35.66932516742103 139.73913378032026 27.655 35.66932516742103 139.73913378032026 28.678 35.669309018866805 139.7391620110616 28.678 35.669309018866805 139.7391620110616 27.655 35.66932516742103 139.73913378032026 27.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2978f648-4fdd-4276-9ba7-e1715f1c61ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2978f648-4fdd-4276-9ba7-e1715f1c61ba_0">
											<gml:posList>35.669309018866805 139.7391620110616 27.655 35.669309018866805 139.7391620110616 28.678 35.669302560695044 139.7391564624529 28.678 35.669302560695044 139.7391564624529 27.655 35.669309018866805 139.7391620110616 27.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b42b3bca-38e5-4b32-9f8e-0a8fa877cd2b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9634fb5-24e3-46a1-902f-2840104fb925">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929175765944 139.73913907751944 31.863 35.669300488811125 139.7391465675714 31.863 35.66928997514861 139.73916494960105 31.863 35.669281253003135 139.7391574484914 31.863 35.66929175765944 139.73913907751944 31.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41ee8e86-cc9c-451e-b84b-c13578f20f29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669302560695044 139.7391564624529 27.655 35.66931498996031 139.73916712944487 27.655 35.669303126084294 139.7391878769283 27.655 35.6692906968122 139.7391771988886 27.655 35.669302560695044 139.7391564624529 27.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cce3e196-b7c3-4ad0-a7e1-59a2a2210db6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cce3e196-b7c3-4ad0-a7e1-59a2a2210db6_0">
											<gml:posList>35.669281253003135 139.7391574484914 31.863 35.66928997514861 139.73916494960105 31.863 35.66928997514861 139.73916494960105 34.967 35.669281253003135 139.7391574484914 34.967 35.669281253003135 139.7391574484914 31.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12eeac96-47dc-43be-a6b6-8e167677302c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12eeac96-47dc-43be-a6b6-8e167677302c_0">
											<gml:posList>35.669281253003135 139.7391574484914 31.863 35.669281253003135 139.7391574484914 34.967 35.66929175765944 139.73913907751944 34.967 35.66929175765944 139.73913907751944 31.863 35.669281253003135 139.7391574484914 31.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f32c5ce2-6e6b-499e-ab97-f4a30bd3909d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f32c5ce2-6e6b-499e-ab97-f4a30bd3909d_0">
											<gml:posList>35.66929175765944 139.73913907751944 34.967 35.669281253003135 139.7391574484914 34.967 35.66928997514861 139.73916494960105 34.967 35.669300488811125 139.7391465675714 34.967 35.66929175765944 139.73913907751944 34.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67ed88c8-d1f3-4faa-916b-fde7209102be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67ed88c8-d1f3-4faa-916b-fde7209102be_0">
											<gml:posList>35.66928997514861 139.73916494960105 31.863 35.669300488811125 139.7391465675714 31.863 35.669300488811125 139.7391465675714 34.967 35.66928997514861 139.73916494960105 34.967 35.66928997514861 139.73916494960105 31.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ebe5b0f-ee53-46f5-8c6b-09897c00064e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ebe5b0f-ee53-46f5-8c6b-09897c00064e_0">
											<gml:posList>35.669300488811125 139.7391465675714 31.863 35.66929175765944 139.73913907751944 31.863 35.66929175765944 139.73913907751944 34.967 35.669300488811125 139.7391465675714 34.967 35.669300488811125 139.7391465675714 31.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-886031a3-b55a-407c-9007-7c5f5b49f390">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-886031a3-b55a-407c-9007-7c5f5b49f390_0">
											<gml:posList>35.6692906968122 139.7391771988886 27.655 35.6692906968122 139.7391771988886 30.513 35.669302560695044 139.7391564624529 30.513 35.669302560695044 139.7391564624529 27.655 35.6692906968122 139.7391771988886 27.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64db1c18-fac1-41f3-8077-a25a153f3577">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64db1c18-fac1-41f3-8077-a25a153f3577_0">
											<gml:posList>35.6692906968122 139.7391771988886 27.655 35.669303126084294 139.7391878769283 27.655 35.669303126084294 139.7391878769283 30.513 35.6692906968122 139.7391771988886 30.513 35.6692906968122 139.7391771988886 27.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7638891c-91fc-48c9-8b70-df99654ff6fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7638891c-91fc-48c9-8b70-df99654ff6fa_0">
											<gml:posList>35.669303126084294 139.7391878769283 30.513 35.66931498996031 139.73916712944487 30.513 35.669302560695044 139.7391564624529 30.513 35.6692906968122 139.7391771988886 30.513 35.669303126084294 139.7391878769283 30.513</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c3e3774-3d3b-4335-b4f1-a047198a6e8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c3e3774-3d3b-4335-b4f1-a047198a6e8f_0">
											<gml:posList>35.669302560695044 139.7391564624529 27.655 35.669302560695044 139.7391564624529 30.513 35.66931498996031 139.73916712944487 30.513 35.66931498996031 139.73916712944487 27.655 35.669302560695044 139.7391564624529 27.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6737f87a-6e37-4414-a9b1-def425c4b0dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6737f87a-6e37-4414-a9b1-def425c4b0dc_0">
											<gml:posList>35.669303126084294 139.7391878769283 27.655 35.66931498996031 139.73916712944487 27.655 35.66931498996031 139.73916712944487 30.513 35.669303126084294 139.7391878769283 30.513 35.669303126084294 139.7391878769283 27.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fa346965-a3c8-49b1-b950-df56c1e0cd2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa346965-a3c8-49b1-b950-df56c1e0cd2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa346965-a3c8-49b1-b950-df56c1e0cd2d">
											<gml:posList>35.66923292927661 139.73921367467457 13.106 35.6692492219246 139.7391852670636 13.106 35.66925724957984 139.73919221668345 13.106 35.66929445245262 139.73912715560127 13.106 35.669318369208995 139.73908532900924 13.106 35.669386288185294 139.73914357270021 13.106 35.66930887584206 139.73927886804552 13.106 35.66923292927661 139.73921367467457 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83c49874-1a33-45c0-9baa-cf9e73db2324">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83c49874-1a33-45c0-9baa-cf9e73db2324">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83c49874-1a33-45c0-9baa-cf9e73db2324">
											<gml:posList>35.669318369208995 139.73908532900924 28.192 35.669318650242516 139.73908738325594 28.192 35.66935426035153 139.73911791705362 28.192 35.66935592759659 139.7391175395265 28.192 35.669318369208995 139.73908532900924 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c183dd24-7ec7-4186-b936-797706a24707">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c183dd24-7ec7-4186-b936-797706a24707">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c183dd24-7ec7-4186-b936-797706a24707">
											<gml:posList>35.669318650242516 139.73908738325594 28.192 35.669318369208995 139.73908532900924 28.192 35.66929445245262 139.73912715560127 28.192 35.669295435605314 139.73912799395052 28.192 35.669318650242516 139.73908738325594 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d29d289-46b7-47b0-a8e4-f55369d8781f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d29d289-46b7-47b0-a8e4-f55369d8781f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d29d289-46b7-47b0-a8e4-f55369d8781f">
											<gml:posList>35.66929445245262 139.73912715560127 33.091 35.66929462472447 139.73912844779372 33.091 35.66931007562031 139.7391417070668 33.091 35.66931113004456 139.7391414738598 33.091 35.66929445245262 139.73912715560127 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-55e40e50-eb4c-4b01-b51c-426988ee2d5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55e40e50-eb4c-4b01-b51c-426988ee2d5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55e40e50-eb4c-4b01-b51c-426988ee2d5c">
											<gml:posList>35.66927545945928 139.73916037146844 33.091 35.669276504878496 139.73916014931845 33.091 35.66929462472447 139.73912844779372 33.091 35.66929445245262 139.73912715560127 33.091 35.66927545945928 139.73916037146844 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96d4355d-a307-48da-b599-c660a09a6dca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96d4355d-a307-48da-b599-c660a09a6dca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96d4355d-a307-48da-b599-c660a09a6dca">
											<gml:posList>35.66931007562031 139.7391417070668 31.863 35.66929462472447 139.73912844779372 31.863 35.669276504878496 139.73916014931845 31.863 35.66929194675718 139.73917340860527 31.863 35.66931007562031 139.7391417070668 31.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f83e6ac3-8c2d-412c-b6ac-f99838caabb8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f83e6ac3-8c2d-412c-b6ac-f99838caabb8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f83e6ac3-8c2d-412c-b6ac-f99838caabb8">
											<gml:posList>35.66931113004456 139.7391414738598 33.091 35.66931007562031 139.7391417070668 33.091 35.66929194675718 139.73917340860527 33.091 35.66929212803361 139.73917468974108 33.091 35.66931113004456 139.7391414738598 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e9e7d1a-8a45-4621-a685-cd1bce308244">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e9e7d1a-8a45-4621-a685-cd1bce308244">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e9e7d1a-8a45-4621-a685-cd1bce308244">
											<gml:posList>35.66929212803361 139.73917468974108 33.091 35.66929194675718 139.73917340860527 33.091 35.669276504878496 139.73916014931845 33.091 35.66927545945928 139.73916037146844 33.091 35.66929212803361 139.73917468974108 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d4bc110-fa96-42c5-801e-ed16a99e2896">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d4bc110-fa96-42c5-801e-ed16a99e2896">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d4bc110-fa96-42c5-801e-ed16a99e2896">
											<gml:posList>35.66935426035153 139.73911791705362 27.655 35.669318650242516 139.73908738325594 27.655 35.669295435605314 139.73912799395052 27.655 35.66931113004456 139.7391414738598 27.655 35.66929212803361 139.73917468974108 27.655 35.669276442620394 139.73916122086396 27.655 35.66925753961665 139.73919425987225 27.655 35.66924950294779 139.73918731026276 27.655 35.66923459653064 139.73921330819613 27.655 35.669279614274714 139.73925196091355 27.655 35.66935426035153 139.73911791705362 27.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7627899-7fec-4be5-a730-6e82666f4959">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7627899-7fec-4be5-a730-6e82666f4959">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7627899-7fec-4be5-a730-6e82666f4959">
											<gml:posList>35.669276442620394 139.73916122086396 28.192 35.66927545945928 139.73916037146844 28.192 35.66925724957984 139.73919221668345 28.192 35.66925753961665 139.73919425987225 28.192 35.669276442620394 139.73916122086396 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e6f7bb2-4050-421d-8323-4e503b19f82d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e6f7bb2-4050-421d-8323-4e503b19f82d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e6f7bb2-4050-421d-8323-4e503b19f82d">
											<gml:posList>35.669386288185294 139.73914357270021 22.701 35.66935592759659 139.7391175395265 28.192 35.669279922346576 139.7392540151281 28.192 35.669386288185294 139.73914357270021 22.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3746db5b-eba9-4a7a-89e5-3540aaada51c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3746db5b-eba9-4a7a-89e5-3540aaada51c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3746db5b-eba9-4a7a-89e5-3540aaada51c">
											<gml:posList>35.66935592759659 139.7391175395265 28.192 35.66935426035153 139.73911791705362 28.192 35.669279614274714 139.73925196091355 28.192 35.669279922346576 139.7392540151281 28.192 35.66935592759659 139.7391175395265 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6642dd7f-a3ea-4ffe-b074-be018434b8bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6642dd7f-a3ea-4ffe-b074-be018434b8bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6642dd7f-a3ea-4ffe-b074-be018434b8bd">
											<gml:posList>35.66925724957984 139.73919221668345 28.192 35.6692492219246 139.7391852670636 28.192 35.66924950294779 139.73918731026276 28.192 35.66925753961665 139.73919425987225 28.192 35.66925724957984 139.73919221668345 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4541688d-1a7d-4841-a0e7-25f33587b34f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4541688d-1a7d-4841-a0e7-25f33587b34f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4541688d-1a7d-4841-a0e7-25f33587b34f">
											<gml:posList>35.66923292927661 139.73921367467457 28.192 35.66923459653064 139.73921330819613 28.192 35.66924950294779 139.73918731026276 28.192 35.6692492219246 139.7391852670636 28.192 35.66923292927661 139.73921367467457 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5df08d9-842c-421a-9a04-dab8dd54298d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5df08d9-842c-421a-9a04-dab8dd54298d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5df08d9-842c-421a-9a04-dab8dd54298d">
											<gml:posList>35.669279922346576 139.7392540151281 28.192 35.66930887584206 139.73927886804552 22.701 35.669386288185294 139.73914357270021 22.701 35.669279922346576 139.7392540151281 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11be65e1-a112-42ac-8eec-aeafc140cf3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11be65e1-a112-42ac-8eec-aeafc140cf3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11be65e1-a112-42ac-8eec-aeafc140cf3e">
											<gml:posList>35.669279922346576 139.7392540151281 28.192 35.669279614274714 139.73925196091355 28.192 35.66923459653064 139.73921330819613 28.192 35.66923292927661 139.73921367467457 28.192 35.669279922346576 139.7392540151281 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-201d5621-e499-4ba7-85cd-eaa670f39294">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-201d5621-e499-4ba7-85cd-eaa670f39294">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-201d5621-e499-4ba7-85cd-eaa670f39294">
											<gml:posList>35.669276504878496 139.73916014931845 33.091 35.669276504878496 139.73916014931845 31.863 35.66929462472447 139.73912844779372 31.863 35.66929462472447 139.73912844779372 33.091 35.669276504878496 139.73916014931845 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81a95f3b-7393-4de0-a741-717e28f87699">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81a95f3b-7393-4de0-a741-717e28f87699">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81a95f3b-7393-4de0-a741-717e28f87699">
											<gml:posList>35.66931007562031 139.7391417070668 33.091 35.66931007562031 139.7391417070668 31.863 35.66929194675718 139.73917340860527 31.863 35.66929194675718 139.73917340860527 33.091 35.66931007562031 139.7391417070668 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4379c755-5335-4939-b7af-5bdbde098e9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4379c755-5335-4939-b7af-5bdbde098e9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4379c755-5335-4939-b7af-5bdbde098e9c">
											<gml:posList>35.669318650242516 139.73908738325594 28.192 35.669318650242516 139.73908738325594 27.655 35.66935426035153 139.73911791705362 27.655 35.66935426035153 139.73911791705362 28.192 35.669318650242516 139.73908738325594 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5dc5374-769d-40e0-be23-5c99c6ba89d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5dc5374-769d-40e0-be23-5c99c6ba89d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5dc5374-769d-40e0-be23-5c99c6ba89d8">
											<gml:posList>35.669318369208995 139.73908532900924 13.106 35.66929445245262 139.73912715560127 13.106 35.66929445245262 139.73912715560127 28.192 35.669318369208995 139.73908532900924 28.192 35.669318369208995 139.73908532900924 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f49605f-8183-4add-80db-27bf628b09a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f49605f-8183-4add-80db-27bf628b09a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f49605f-8183-4add-80db-27bf628b09a5">
											<gml:posList>35.669295435605314 139.73912799395052 28.192 35.669295435605314 139.73912799395052 27.655 35.669318650242516 139.73908738325594 27.655 35.669318650242516 139.73908738325594 28.192 35.669295435605314 139.73912799395052 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e13da9a5-dd8c-42db-a1ad-0d140228bc86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e13da9a5-dd8c-42db-a1ad-0d140228bc86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e13da9a5-dd8c-42db-a1ad-0d140228bc86">
											<gml:posList>35.669318369208995 139.73908532900924 28.192 35.66935592759659 139.7391175395265 28.192 35.669386288185294 139.73914357270021 22.701 35.669386288185294 139.73914357270021 13.106 35.669318369208995 139.73908532900924 13.106 35.669318369208995 139.73908532900924 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25ca7fb5-5cc3-4bf3-a2d3-7f926831261c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25ca7fb5-5cc3-4bf3-a2d3-7f926831261c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25ca7fb5-5cc3-4bf3-a2d3-7f926831261c">
											<gml:posList>35.669295435605314 139.73912799395052 28.192 35.66929445245262 139.73912715560127 28.192 35.66929445245262 139.73912715560127 33.091 35.66931113004456 139.7391414738598 33.091 35.66931113004456 139.7391414738598 27.655 35.669295435605314 139.73912799395052 27.655 35.669295435605314 139.73912799395052 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b061c9e8-3a5c-4177-b5a6-038c09cc5c28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b061c9e8-3a5c-4177-b5a6-038c09cc5c28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b061c9e8-3a5c-4177-b5a6-038c09cc5c28">
											<gml:posList>35.66929462472447 139.73912844779372 33.091 35.66929462472447 139.73912844779372 31.863 35.66931007562031 139.7391417070668 31.863 35.66931007562031 139.7391417070668 33.091 35.66929462472447 139.73912844779372 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36707788-1e35-4fb6-9002-7fe984488448">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36707788-1e35-4fb6-9002-7fe984488448">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36707788-1e35-4fb6-9002-7fe984488448">
											<gml:posList>35.66929212803361 139.73917468974108 27.655 35.66931113004456 139.7391414738598 27.655 35.66931113004456 139.7391414738598 33.091 35.66929212803361 139.73917468974108 33.091 35.66929212803361 139.73917468974108 27.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c7bbd39-25db-4782-8349-6666cc74430a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c7bbd39-25db-4782-8349-6666cc74430a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c7bbd39-25db-4782-8349-6666cc74430a">
											<gml:posList>35.66927545945928 139.73916037146844 28.192 35.66927545945928 139.73916037146844 33.091 35.66929445245262 139.73912715560127 33.091 35.66929445245262 139.73912715560127 28.192 35.66929445245262 139.73912715560127 13.106 35.66925724957984 139.73919221668345 13.106 35.66925724957984 139.73919221668345 28.192 35.66927545945928 139.73916037146844 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb44a633-8dd8-4933-b8fe-b916410eeb89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb44a633-8dd8-4933-b8fe-b916410eeb89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb44a633-8dd8-4933-b8fe-b916410eeb89">
											<gml:posList>35.66929194675718 139.73917340860527 33.091 35.66929194675718 139.73917340860527 31.863 35.669276504878496 139.73916014931845 31.863 35.669276504878496 139.73916014931845 33.091 35.66929194675718 139.73917340860527 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a1e8d9f-a3ea-4da3-8260-712d8c98e41d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a1e8d9f-a3ea-4da3-8260-712d8c98e41d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a1e8d9f-a3ea-4da3-8260-712d8c98e41d">
											<gml:posList>35.66927545945928 139.73916037146844 33.091 35.66927545945928 139.73916037146844 28.192 35.669276442620394 139.73916122086396 28.192 35.669276442620394 139.73916122086396 27.655 35.66929212803361 139.73917468974108 27.655 35.66929212803361 139.73917468974108 33.091 35.66927545945928 139.73916037146844 33.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b14a86d4-95c0-4695-a31b-5eec71886d02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b14a86d4-95c0-4695-a31b-5eec71886d02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b14a86d4-95c0-4695-a31b-5eec71886d02">
											<gml:posList>35.66925753961665 139.73919425987225 28.192 35.66925753961665 139.73919425987225 27.655 35.669276442620394 139.73916122086396 27.655 35.669276442620394 139.73916122086396 28.192 35.66925753961665 139.73919425987225 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ad2011e-7477-4728-ac4f-d44fb03dbe1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ad2011e-7477-4728-ac4f-d44fb03dbe1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ad2011e-7477-4728-ac4f-d44fb03dbe1e">
											<gml:posList>35.66935426035153 139.73911791705362 28.192 35.66935426035153 139.73911791705362 27.655 35.669279614274714 139.73925196091355 27.655 35.669279614274714 139.73925196091355 28.192 35.66935426035153 139.73911791705362 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9985a48b-f0f2-483b-be46-95bd9bbbaaac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9985a48b-f0f2-483b-be46-95bd9bbbaaac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9985a48b-f0f2-483b-be46-95bd9bbbaaac">
											<gml:posList>35.66925724957984 139.73919221668345 13.106 35.6692492219246 139.7391852670636 13.106 35.6692492219246 139.7391852670636 28.192 35.66925724957984 139.73919221668345 28.192 35.66925724957984 139.73919221668345 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe5bbb81-5259-4e27-ad65-8a7902a150e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe5bbb81-5259-4e27-ad65-8a7902a150e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe5bbb81-5259-4e27-ad65-8a7902a150e7">
											<gml:posList>35.66924950294779 139.73918731026276 28.192 35.66924950294779 139.73918731026276 27.655 35.66925753961665 139.73919425987225 27.655 35.66925753961665 139.73919425987225 28.192 35.66924950294779 139.73918731026276 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6efddb7a-5a35-49ad-951f-7c6b0494b3a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6efddb7a-5a35-49ad-951f-7c6b0494b3a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6efddb7a-5a35-49ad-951f-7c6b0494b3a2">
											<gml:posList>35.6692492219246 139.7391852670636 13.106 35.66923292927661 139.73921367467457 13.106 35.66923292927661 139.73921367467457 28.192 35.6692492219246 139.7391852670636 28.192 35.6692492219246 139.7391852670636 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edf3aa66-b776-4ce3-978e-204016981e47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edf3aa66-b776-4ce3-978e-204016981e47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edf3aa66-b776-4ce3-978e-204016981e47">
											<gml:posList>35.66923459653064 139.73921330819613 28.192 35.66923459653064 139.73921330819613 27.655 35.66924950294779 139.73918731026276 27.655 35.66924950294779 139.73918731026276 28.192 35.66923459653064 139.73921330819613 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7150d63c-da6b-46bf-9183-f982db309658">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7150d63c-da6b-46bf-9183-f982db309658">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7150d63c-da6b-46bf-9183-f982db309658">
											<gml:posList>35.66930887584206 139.73927886804552 13.106 35.669386288185294 139.73914357270021 13.106 35.669386288185294 139.73914357270021 22.701 35.66930887584206 139.73927886804552 22.701 35.66930887584206 139.73927886804552 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b1a9f5e-ede6-42d7-abfc-a68a6888ab6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b1a9f5e-ede6-42d7-abfc-a68a6888ab6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b1a9f5e-ede6-42d7-abfc-a68a6888ab6f">
											<gml:posList>35.669279614274714 139.73925196091355 28.192 35.669279614274714 139.73925196091355 27.655 35.66923459653064 139.73921330819613 27.655 35.66923459653064 139.73921330819613 28.192 35.669279614274714 139.73925196091355 28.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac40a5a9-9456-4561-91d0-350697cbb019">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac40a5a9-9456-4561-91d0-350697cbb019">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac40a5a9-9456-4561-91d0-350697cbb019">
											<gml:posList>35.66930887584206 139.73927886804552 22.701 35.669279922346576 139.7392540151281 28.192 35.66923292927661 139.73921367467457 28.192 35.66923292927661 139.73921367467457 13.106 35.66930887584206 139.73927886804552 13.106 35.66930887584206 139.73927886804552 22.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10666</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">140.95425</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>