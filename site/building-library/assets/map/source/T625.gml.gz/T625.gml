<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b4ef9c73-f163-4353-aad5-ee7934fa9d7d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">6.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.666857572944934 139.73842887702392 0 35.66692570561699 139.73838040481021 0 35.666938896093455 139.7383618322719 0 35.66694702210491 139.73836771005182 0 35.66694832783223 139.7383661068664 0 35.666910821624974 139.73832033338465 0 35.666842437673814 139.73840447273525 0 35.666857572944934 139.73842887702392 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666857572944934 139.73842887702392 12.329 35.666842437673814 139.73840447273525 12.329 35.666910821624974 139.73832033338465 12.329 35.66694832783223 139.7383661068664 12.329 35.66694702210491 139.73836771005182 12.329 35.666938896093455 139.7383618322719 12.329 35.66692570561699 139.73838040481021 12.329 35.666857572944934 139.73842887702392 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666857572944934 139.73842887702392 12.329 35.66692570561699 139.73838040481021 12.329 35.66692570561699 139.73838040481021 19.08 35.666857572944934 139.73842887702392 19.08 35.666857572944934 139.73842887702392 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66692570561699 139.73838040481021 12.329 35.666938896093455 139.7383618322719 12.329 35.666938896093455 139.7383618322719 19.08 35.66692570561699 139.73838040481021 19.08 35.66692570561699 139.73838040481021 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666938896093455 139.7383618322719 12.329 35.66694702210491 139.73836771005182 12.329 35.66694702210491 139.73836771005182 19.08 35.666938896093455 139.7383618322719 19.08 35.666938896093455 139.7383618322719 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66694702210491 139.73836771005182 12.329 35.66694832783223 139.7383661068664 12.329 35.66694832783223 139.7383661068664 19.08 35.66694702210491 139.73836771005182 19.08 35.66694702210491 139.73836771005182 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66694832783223 139.7383661068664 12.329 35.666910821624974 139.73832033338465 12.329 35.666910821624974 139.73832033338465 19.08 35.66694832783223 139.7383661068664 19.08 35.66694832783223 139.7383661068664 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666910821624974 139.73832033338465 12.329 35.666842437673814 139.73840447273525 12.329 35.666842437673814 139.73840447273525 19.08 35.666910821624974 139.73832033338465 19.08 35.666910821624974 139.73832033338465 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666842437673814 139.73840447273525 12.329 35.666857572944934 139.73842887702392 12.329 35.666857572944934 139.73842887702392 19.08 35.666842437673814 139.73840447273525 19.08 35.666842437673814 139.73840447273525 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666857572944934 139.73842887702392 19.08 35.66692570561699 139.73838040481021 19.08 35.666938896093455 139.7383618322719 19.08 35.66694702210491 139.73836771005182 19.08 35.66694832783223 139.7383661068664 19.08 35.666910821624974 139.73832033338465 19.08 35.666842437673814 139.73840447273525 19.08 35.666857572944934 139.73842887702392 19.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ffab53b7-5954-46e9-b1c9-142b86b75bd2"/>
							<gml:surfaceMember xlink:href="#poly-52d452fd-f1de-4bfb-a839-a961ade8526a"/>
							<gml:surfaceMember xlink:href="#poly-8aa2133e-3d72-4fd2-9ba0-fcae74f0b3b6"/>
							<gml:surfaceMember xlink:href="#poly-e7d5463c-9024-4194-9ff6-c8261eebd5db"/>
							<gml:surfaceMember xlink:href="#poly-7a0d483f-c9bc-47b2-bec1-a6c5487e04a7"/>
							<gml:surfaceMember xlink:href="#poly-b259a08e-2f98-43e1-aaec-4b3f6d01f330"/>
							<gml:surfaceMember xlink:href="#poly-6b08a981-b2e6-40b9-947f-3a887b24f598"/>
							<gml:surfaceMember xlink:href="#poly-8d2a97a8-bc3e-4792-8a98-9eac9a2ba2f6"/>
							<gml:surfaceMember xlink:href="#poly-951f9c92-d5cc-415b-ad02-d27ce60b587f"/>
							<gml:surfaceMember xlink:href="#poly-5bfeaa00-e594-441f-a0e8-89a52c689441"/>
							<gml:surfaceMember xlink:href="#poly-e5e0b892-042a-4658-b0df-2858798e9f22"/>
							<gml:surfaceMember xlink:href="#poly-6e8af092-20b8-49cb-956b-7d219fe1508e"/>
							<gml:surfaceMember xlink:href="#poly-ed9a66b7-4bef-43f1-bc29-56c5917549e7"/>
							<gml:surfaceMember xlink:href="#poly-3f7b48f2-c926-4903-a9f1-be84dff03189"/>
							<gml:surfaceMember xlink:href="#poly-539ce941-56b7-4742-bc9f-5ec397e7ae76"/>
							<gml:surfaceMember xlink:href="#poly-089dcd43-59cd-4e37-a938-989c09745214"/>
							<gml:surfaceMember xlink:href="#poly-257e26a5-5677-47c7-af2c-4cd3c921823b"/>
							<gml:surfaceMember xlink:href="#poly-bd0efe9c-8f8c-4bc7-88bf-897223100116"/>
							<gml:surfaceMember xlink:href="#poly-243d49b2-5b37-47bb-843e-4e5ed51fcad5"/>
							<gml:surfaceMember xlink:href="#poly-8989baca-2ff9-4854-825b-3210a53fab42"/>
							<gml:surfaceMember xlink:href="#poly-19c301ba-9f64-40a3-84f5-bd870a3dcd19"/>
							<gml:surfaceMember xlink:href="#poly-c3d218b4-f930-4f5e-8014-6ede1da1589b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b4ef9c73-f163-4353-aad5-ee7934fa9d7d_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30759c38-0cea-433b-94be-29a1654eccb0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666894035047925 139.73835080648735 19.587 35.66690377024264 139.7383626912614 19.587 35.666888686865775 139.73838124394132 19.587 35.66687895167286 139.73836935916725 19.587 35.666894035047925 139.73835080648735 19.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb430ab3-83f4-48a1-9f15-8f0a15d1e05b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb430ab3-83f4-48a1-9f15-8f0a15d1e05b_0">
											<gml:posList>35.666894035047925 139.73835080648735 21.065 35.66690377024264 139.7383626912614 21.065 35.66690377024264 139.7383626912614 19.587 35.666894035047925 139.73835080648735 19.587 35.666894035047925 139.73835080648735 21.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44b6ddd8-cfe8-4a36-8259-1ae31c80e7b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44b6ddd8-cfe8-4a36-8259-1ae31c80e7b1_0">
											<gml:posList>35.66687895167286 139.73836935916725 21.065 35.666894035047925 139.73835080648735 21.065 35.666894035047925 139.73835080648735 19.587 35.66687895167286 139.73836935916725 19.587 35.66687895167286 139.73836935916725 21.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-305362b3-bb2a-4de7-a4f5-3d3104abbcf1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-305362b3-bb2a-4de7-a4f5-3d3104abbcf1_0">
											<gml:posList>35.666888686865775 139.73838124394132 21.065 35.66690377024264 139.7383626912614 21.065 35.666894035047925 139.73835080648735 21.065 35.66687895167286 139.73836935916725 21.065 35.666888686865775 139.73838124394132 21.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c08c7866-23bc-4dd3-962b-c6c46d0725f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c08c7866-23bc-4dd3-962b-c6c46d0725f8_0">
											<gml:posList>35.66690377024264 139.7383626912614 19.587 35.66690377024264 139.7383626912614 21.065 35.666888686865775 139.73838124394132 21.065 35.666888686865775 139.73838124394132 19.587 35.66690377024264 139.7383626912614 19.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b6276a1-f844-4684-91bc-508f3568105c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b6276a1-f844-4684-91bc-508f3568105c_0">
											<gml:posList>35.666888686865775 139.73838124394132 19.587 35.666888686865775 139.73838124394132 21.065 35.66687895167286 139.73836935916725 21.065 35.66687895167286 139.73836935916725 19.587 35.666888686865775 139.73838124394132 19.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ffab53b7-5954-46e9-b1c9-142b86b75bd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffab53b7-5954-46e9-b1c9-142b86b75bd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffab53b7-5954-46e9-b1c9-142b86b75bd2">
											<gml:posList>35.66693889609344 139.7383618322719 12.329 35.66692570561697 139.73838040481021 12.329 35.66685757294494 139.7384288770239 12.329 35.66684243767379 139.73840447273525 12.329 35.66691082162495 139.73832033338462 12.329 35.66694832783223 139.7383661068664 12.329 35.66694702210489 139.7383677100518 12.329 35.66693889609344 139.7383618322719 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52d452fd-f1de-4bfb-a839-a961ade8526a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52d452fd-f1de-4bfb-a839-a961ade8526a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52d452fd-f1de-4bfb-a839-a961ade8526a">
											<gml:posList>35.66691082162495 139.73832033338462 20.173 35.66691081460702 139.73832286287686 20.173 35.66694417951407 139.73836357124856 20.173 35.66694832783223 139.7383661068664 20.173 35.66691082162495 139.73832033338462 20.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8aa2133e-3d72-4fd2-9ba0-fcae74f0b3b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8aa2133e-3d72-4fd2-9ba0-fcae74f0b3b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8aa2133e-3d72-4fd2-9ba0-fcae74f0b3b6">
											<gml:posList>35.66684243767379 139.73840447273525 20.173 35.66684436672468 139.7384046140466 20.173 35.66691081460702 139.73832286287686 20.173 35.66691082162495 139.73832033338462 20.173 35.66684243767379 139.73840447273525 20.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e7d5463c-9024-4194-9ff6-c8261eebd5db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7d5463c-9024-4194-9ff6-c8261eebd5db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7d5463c-9024-4194-9ff6-c8261eebd5db">
											<gml:posList>35.66693889609344 139.7383618322719 20.173 35.66694702210489 139.7383677100518 20.173 35.66694417951407 139.73836357124856 20.173 35.66693857880095 139.73835953512437 20.173 35.66693889609344 139.7383618322719 20.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a0d483f-c9bc-47b2-bec1-a6c5487e04a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a0d483f-c9bc-47b2-bec1-a6c5487e04a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a0d483f-c9bc-47b2-bec1-a6c5487e04a7">
											<gml:posList>35.66694702210489 139.7383677100518 20.173 35.66694832783223 139.7383661068664 20.173 35.66694417951407 139.73836357124856 20.173 35.66694702210489 139.7383677100518 20.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b259a08e-2f98-43e1-aaec-4b3f6d01f330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b259a08e-2f98-43e1-aaec-4b3f6d01f330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b259a08e-2f98-43e1-aaec-4b3f6d01f330">
											<gml:posList>35.66693889609344 139.7383618322719 20.173 35.66693857880095 139.73835953512437 20.173 35.66692474004197 139.73837900313913 20.173 35.66692570561697 139.73838040481021 20.173 35.66693889609344 139.7383618322719 20.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b08a981-b2e6-40b9-947f-3a887b24f598">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b08a981-b2e6-40b9-947f-3a887b24f598">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b08a981-b2e6-40b9-947f-3a887b24f598">
											<gml:posList>35.66685795868095 139.73842652381748 19.587 35.66692474004197 139.73837900313913 19.587 35.66693857880095 139.73835953512437 19.587 35.66694417951407 139.73836357124856 19.587 35.66691081460702 139.73832286287686 19.587 35.66684436672468 139.7384046140466 19.587 35.66685795868095 139.73842652381748 19.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d2a97a8-bc3e-4792-8a98-9eac9a2ba2f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d2a97a8-bc3e-4792-8a98-9eac9a2ba2f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d2a97a8-bc3e-4792-8a98-9eac9a2ba2f6">
											<gml:posList>35.66692570561697 139.73838040481021 20.173 35.66692474004197 139.73837900313913 20.173 35.66685795868095 139.73842652381748 20.173 35.66685757294494 139.7384288770239 20.173 35.66692570561697 139.73838040481021 20.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-951f9c92-d5cc-415b-ad02-d27ce60b587f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-951f9c92-d5cc-415b-ad02-d27ce60b587f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-951f9c92-d5cc-415b-ad02-d27ce60b587f">
											<gml:posList>35.66685757294494 139.7384288770239 20.173 35.66685795868095 139.73842652381748 20.173 35.66684436672468 139.7384046140466 20.173 35.66684243767379 139.73840447273525 20.173 35.66685757294494 139.7384288770239 20.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5bfeaa00-e594-441f-a0e8-89a52c689441">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bfeaa00-e594-441f-a0e8-89a52c689441">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bfeaa00-e594-441f-a0e8-89a52c689441">
											<gml:posList>35.66692474004197 139.73837900313913 20.173 35.66692474004197 139.73837900313913 19.587 35.66685795868095 139.73842652381748 19.587 35.66685795868095 139.73842652381748 20.173 35.66692474004197 139.73837900313913 20.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5e0b892-042a-4658-b0df-2858798e9f22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5e0b892-042a-4658-b0df-2858798e9f22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5e0b892-042a-4658-b0df-2858798e9f22">
											<gml:posList>35.66685757294494 139.7384288770239 12.329 35.66692570561697 139.73838040481021 12.329 35.66692570561697 139.73838040481021 20.173 35.66685757294494 139.7384288770239 20.173 35.66685757294494 139.7384288770239 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e8af092-20b8-49cb-956b-7d219fe1508e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e8af092-20b8-49cb-956b-7d219fe1508e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e8af092-20b8-49cb-956b-7d219fe1508e">
											<gml:posList>35.66692570561697 139.73838040481021 12.329 35.66693889609344 139.7383618322719 12.329 35.66693889609344 139.7383618322719 20.173 35.66692570561697 139.73838040481021 20.173 35.66692570561697 139.73838040481021 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed9a66b7-4bef-43f1-bc29-56c5917549e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed9a66b7-4bef-43f1-bc29-56c5917549e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed9a66b7-4bef-43f1-bc29-56c5917549e7">
											<gml:posList>35.66694417951407 139.73836357124856 20.173 35.66694417951407 139.73836357124856 19.587 35.66693857880095 139.73835953512437 19.587 35.66693857880095 139.73835953512437 20.173 35.66694417951407 139.73836357124856 20.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f7b48f2-c926-4903-a9f1-be84dff03189">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f7b48f2-c926-4903-a9f1-be84dff03189">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f7b48f2-c926-4903-a9f1-be84dff03189">
											<gml:posList>35.66693889609344 139.7383618322719 12.329 35.66694702210489 139.7383677100518 12.329 35.66694702210489 139.7383677100518 20.173 35.66693889609344 139.7383618322719 20.173 35.66693889609344 139.7383618322719 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-539ce941-56b7-4742-bc9f-5ec397e7ae76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-539ce941-56b7-4742-bc9f-5ec397e7ae76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-539ce941-56b7-4742-bc9f-5ec397e7ae76">
											<gml:posList>35.66691082162495 139.73832033338462 12.329 35.66684243767379 139.73840447273525 12.329 35.66684243767379 139.73840447273525 20.173 35.66691082162495 139.73832033338462 20.173 35.66691082162495 139.73832033338462 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-089dcd43-59cd-4e37-a938-989c09745214">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-089dcd43-59cd-4e37-a938-989c09745214">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-089dcd43-59cd-4e37-a938-989c09745214">
											<gml:posList>35.66684436672468 139.7384046140466 20.173 35.66684436672468 139.7384046140466 19.587 35.66691081460702 139.73832286287686 19.587 35.66691081460702 139.73832286287686 20.173 35.66684436672468 139.7384046140466 20.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-257e26a5-5677-47c7-af2c-4cd3c921823b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-257e26a5-5677-47c7-af2c-4cd3c921823b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-257e26a5-5677-47c7-af2c-4cd3c921823b">
											<gml:posList>35.66685795868095 139.73842652381748 20.173 35.66685795868095 139.73842652381748 19.587 35.66684436672468 139.7384046140466 19.587 35.66684436672468 139.7384046140466 20.173 35.66685795868095 139.73842652381748 20.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd0efe9c-8f8c-4bc7-88bf-897223100116">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd0efe9c-8f8c-4bc7-88bf-897223100116">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd0efe9c-8f8c-4bc7-88bf-897223100116">
											<gml:posList>35.66684243767379 139.73840447273525 12.329 35.66685757294494 139.7384288770239 12.329 35.66685757294494 139.7384288770239 20.173 35.66684243767379 139.73840447273525 20.173 35.66684243767379 139.73840447273525 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-243d49b2-5b37-47bb-843e-4e5ed51fcad5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-243d49b2-5b37-47bb-843e-4e5ed51fcad5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-243d49b2-5b37-47bb-843e-4e5ed51fcad5">
											<gml:posList>35.66691081460702 139.73832286287686 20.173 35.66691081460702 139.73832286287686 19.587 35.66694417951407 139.73836357124856 19.587 35.66694417951407 139.73836357124856 20.173 35.66691081460702 139.73832286287686 20.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8989baca-2ff9-4854-825b-3210a53fab42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8989baca-2ff9-4854-825b-3210a53fab42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8989baca-2ff9-4854-825b-3210a53fab42">
											<gml:posList>35.66694832783223 139.7383661068664 12.329 35.66691082162495 139.73832033338462 12.329 35.66691082162495 139.73832033338462 20.173 35.66694832783223 139.7383661068664 20.173 35.66694832783223 139.7383661068664 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19c301ba-9f64-40a3-84f5-bd870a3dcd19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19c301ba-9f64-40a3-84f5-bd870a3dcd19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19c301ba-9f64-40a3-84f5-bd870a3dcd19">
											<gml:posList>35.66694702210489 139.7383677100518 12.329 35.66694832783223 139.7383661068664 12.329 35.66694832783223 139.7383661068664 20.173 35.66694702210489 139.7383677100518 20.173 35.66694702210489 139.7383677100518 12.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3d218b4-f930-4f5e-8014-6ede1da1589b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3d218b4-f930-4f5e-8014-6ede1da1589b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3d218b4-f930-4f5e-8014-6ede1da1589b">
											<gml:posList>35.66693857880095 139.73835953512437 20.173 35.66693857880095 139.73835953512437 19.587 35.66692474004197 139.73837900313913 19.587 35.66692474004197 139.73837900313913 20.173 35.66693857880095 139.73835953512437 20.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-698</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">50.2243</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>