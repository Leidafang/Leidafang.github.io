<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b52cb3fe-24f9-42fb-ad09-5ac2bafc3d83">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">415</bldg:usage>
			<bldg:measuredHeight uom="m">6.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66687836174045 139.7470347500261 0 35.66689315114349 139.747044343938 0 35.66689927359304 139.74703472752066 0 35.666952746774314 139.7470650458892 0 35.666967230542674 139.74702548637924 0 35.66690014107604 139.7469874506458 0 35.66687836174045 139.7470347500261 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687836174045 139.7470347500261 6.892 35.66690014107604 139.7469874506458 6.892 35.666967230542674 139.74702548637924 6.892 35.666952746774314 139.7470650458892 6.892 35.66689927359304 139.74703472752066 6.892 35.66689315114349 139.747044343938 6.892 35.66687836174045 139.7470347500261 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687836174045 139.7470347500261 6.892 35.66689315114349 139.747044343938 6.892 35.66689315114349 139.747044343938 13.04 35.66687836174045 139.7470347500261 13.04 35.66687836174045 139.7470347500261 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689315114349 139.747044343938 6.892 35.66689927359304 139.74703472752066 6.892 35.66689927359304 139.74703472752066 13.04 35.66689315114349 139.747044343938 13.04 35.66689315114349 139.747044343938 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689927359304 139.74703472752066 6.892 35.666952746774314 139.7470650458892 6.892 35.666952746774314 139.7470650458892 13.04 35.66689927359304 139.74703472752066 13.04 35.66689927359304 139.74703472752066 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666952746774314 139.7470650458892 6.892 35.666967230542674 139.74702548637924 6.892 35.666967230542674 139.74702548637924 13.04 35.666952746774314 139.7470650458892 13.04 35.666952746774314 139.7470650458892 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666967230542674 139.74702548637924 6.892 35.66690014107604 139.7469874506458 6.892 35.66690014107604 139.7469874506458 13.04 35.666967230542674 139.74702548637924 13.04 35.666967230542674 139.74702548637924 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66690014107604 139.7469874506458 6.892 35.66687836174045 139.7470347500261 6.892 35.66687836174045 139.7470347500261 13.04 35.66690014107604 139.7469874506458 13.04 35.66690014107604 139.7469874506458 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687836174045 139.7470347500261 13.04 35.66689315114349 139.747044343938 13.04 35.66689927359304 139.74703472752066 13.04 35.666952746774314 139.7470650458892 13.04 35.666967230542674 139.74702548637924 13.04 35.66690014107604 139.7469874506458 13.04 35.66687836174045 139.7470347500261 13.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-876622de-afb1-47fb-9fa3-0a6805257dda"/>
							<gml:surfaceMember xlink:href="#poly-acfad41a-b4b0-4ab6-8195-25bd1d09d261"/>
							<gml:surfaceMember xlink:href="#poly-5dc6b488-1d5c-4c6f-a4d0-ec4dde9553f8"/>
							<gml:surfaceMember xlink:href="#poly-0e377495-727a-4820-862c-899a3f792865"/>
							<gml:surfaceMember xlink:href="#poly-a4aba8fd-2964-4c43-8155-f321553e029a"/>
							<gml:surfaceMember xlink:href="#poly-ad1c2999-9ce1-4277-a279-0633b170be1b"/>
							<gml:surfaceMember xlink:href="#poly-c9223f95-4749-40e9-b981-671f25c9b67b"/>
							<gml:surfaceMember xlink:href="#poly-73a98aaf-7ad3-4567-a2ea-df2fa30ba2f8"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-876622de-afb1-47fb-9fa3-0a6805257dda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-876622de-afb1-47fb-9fa3-0a6805257dda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-876622de-afb1-47fb-9fa3-0a6805257dda">
											<gml:posList>35.66690014107602 139.7469874506458 6.892 35.666967230542674 139.74702548637924 6.892 35.66695274677428 139.7470650458892 6.892 35.66689927359301 139.74703472752066 6.892 35.6668931511435 139.74704434393797 6.892 35.666878361740444 139.74703475002607 6.892 35.66690014107602 139.7469874506458 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-acfad41a-b4b0-4ab6-8195-25bd1d09d261">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acfad41a-b4b0-4ab6-8195-25bd1d09d261">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acfad41a-b4b0-4ab6-8195-25bd1d09d261">
											<gml:posList>35.66690014107602 139.7469874506458 13.3 35.666878361740444 139.74703475002607 13.3 35.6668931511435 139.74704434393797 13.3 35.66689927359301 139.74703472752066 13.3 35.66695274677428 139.7470650458892 13.3 35.666967230542674 139.74702548637924 13.3 35.66690014107602 139.7469874506458 13.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5dc6b488-1d5c-4c6f-a4d0-ec4dde9553f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dc6b488-1d5c-4c6f-a4d0-ec4dde9553f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dc6b488-1d5c-4c6f-a4d0-ec4dde9553f8">
											<gml:posList>35.666878361740444 139.74703475002607 6.892 35.6668931511435 139.74704434393797 6.892 35.6668931511435 139.74704434393797 13.3 35.666878361740444 139.74703475002607 13.3 35.666878361740444 139.74703475002607 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e377495-727a-4820-862c-899a3f792865">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e377495-727a-4820-862c-899a3f792865">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e377495-727a-4820-862c-899a3f792865">
											<gml:posList>35.66690014107602 139.7469874506458 6.892 35.666878361740444 139.74703475002607 6.892 35.666878361740444 139.74703475002607 13.3 35.66690014107602 139.7469874506458 13.3 35.66690014107602 139.7469874506458 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4aba8fd-2964-4c43-8155-f321553e029a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4aba8fd-2964-4c43-8155-f321553e029a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4aba8fd-2964-4c43-8155-f321553e029a">
											<gml:posList>35.6668931511435 139.74704434393797 6.892 35.66689927359301 139.74703472752066 6.892 35.66689927359301 139.74703472752066 13.3 35.6668931511435 139.74704434393797 13.3 35.6668931511435 139.74704434393797 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad1c2999-9ce1-4277-a279-0633b170be1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad1c2999-9ce1-4277-a279-0633b170be1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad1c2999-9ce1-4277-a279-0633b170be1b">
											<gml:posList>35.66689927359301 139.74703472752066 6.892 35.66695274677428 139.7470650458892 6.892 35.66695274677428 139.7470650458892 13.3 35.66689927359301 139.74703472752066 13.3 35.66689927359301 139.74703472752066 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9223f95-4749-40e9-b981-671f25c9b67b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9223f95-4749-40e9-b981-671f25c9b67b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9223f95-4749-40e9-b981-671f25c9b67b">
											<gml:posList>35.666967230542674 139.74702548637924 6.892 35.66690014107602 139.7469874506458 6.892 35.66690014107602 139.7469874506458 13.3 35.666967230542674 139.74702548637924 13.3 35.666967230542674 139.74702548637924 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73a98aaf-7ad3-4567-a2ea-df2fa30ba2f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73a98aaf-7ad3-4567-a2ea-df2fa30ba2f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73a98aaf-7ad3-4567-a2ea-df2fa30ba2f8">
											<gml:posList>35.66695274677428 139.7470650458892 6.892 35.666967230542674 139.74702548637924 6.892 35.666967230542674 139.74702548637924 13.3 35.66695274677428 139.7470650458892 13.3 35.66695274677428 139.7470650458892 6.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7570</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">34.89655</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1420</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>