<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b5aa0b90-ad5d-47a5-a6ed-d6dcbfe3c341">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">25.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66848862811775 139.73986018697704 0 35.66842142903161 139.73979995421112 0 35.668434365657255 139.73977921684093 0 35.66836159858632 139.73971066201432 0 35.66826598300863 139.73985260388585 0 35.66840678940946 139.73998410790009 0 35.66848862811775 139.73986018697704 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848862811775 139.73986018697704 11.02 35.66840678940946 139.73998410790009 11.02 35.66826598300863 139.73985260388585 11.02 35.66836159858632 139.73971066201432 11.02 35.668434365657255 139.73977921684093 11.02 35.66842142903161 139.73979995421112 11.02 35.66848862811775 139.73986018697704 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848862811775 139.73986018697704 11.02 35.66842142903161 139.73979995421112 11.02 35.66842142903161 139.73979995421112 36.83 35.66848862811775 139.73986018697704 36.83 35.66848862811775 139.73986018697704 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66842142903161 139.73979995421112 11.02 35.668434365657255 139.73977921684093 11.02 35.668434365657255 139.73977921684093 36.83 35.66842142903161 139.73979995421112 36.83 35.66842142903161 139.73979995421112 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668434365657255 139.73977921684093 11.02 35.66836159858632 139.73971066201432 11.02 35.66836159858632 139.73971066201432 36.83 35.668434365657255 139.73977921684093 36.83 35.668434365657255 139.73977921684093 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66836159858632 139.73971066201432 11.02 35.66826598300863 139.73985260388585 11.02 35.66826598300863 139.73985260388585 36.83 35.66836159858632 139.73971066201432 36.83 35.66836159858632 139.73971066201432 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66826598300863 139.73985260388585 11.02 35.66840678940946 139.73998410790009 11.02 35.66840678940946 139.73998410790009 36.83 35.66826598300863 139.73985260388585 36.83 35.66826598300863 139.73985260388585 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840678940946 139.73998410790009 11.02 35.66848862811775 139.73986018697704 11.02 35.66848862811775 139.73986018697704 36.83 35.66840678940946 139.73998410790009 36.83 35.66840678940946 139.73998410790009 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848862811775 139.73986018697704 36.83 35.66842142903161 139.73979995421112 36.83 35.668434365657255 139.73977921684093 36.83 35.66836159858632 139.73971066201432 36.83 35.66826598300863 139.73985260388585 36.83 35.66840678940946 139.73998410790009 36.83 35.66848862811775 139.73986018697704 36.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7da47072-7721-4b07-a929-20adfe361c63"/>
							<gml:surfaceMember xlink:href="#poly-e97c69e0-c2b5-4dde-bc2d-40fd9a64e466"/>
							<gml:surfaceMember xlink:href="#poly-a68bcb5a-b19a-413b-ada9-105275365a9d"/>
							<gml:surfaceMember xlink:href="#poly-10f6e5fb-e4bc-4745-b77b-d1ed5dd6cc52"/>
							<gml:surfaceMember xlink:href="#poly-7c04e455-780b-42ac-b21b-f9e9e070d82d"/>
							<gml:surfaceMember xlink:href="#poly-94654be9-53f6-4da3-b32d-867c13a713dd"/>
							<gml:surfaceMember xlink:href="#poly-9a9021b6-ab26-4019-8fb9-0a2c3da64766"/>
							<gml:surfaceMember xlink:href="#poly-c7ba47dd-8d27-42a6-9633-1acd469051f8"/>
							<gml:surfaceMember xlink:href="#poly-7020e2aa-e8aa-4a20-8d67-0f9ddaf95e39"/>
							<gml:surfaceMember xlink:href="#poly-4a3984ff-89ff-4246-b49b-a32c4a299515"/>
							<gml:surfaceMember xlink:href="#poly-b8c471f6-193f-4601-92b2-78213c357746"/>
							<gml:surfaceMember xlink:href="#poly-e224cfca-e92f-4c0c-9b9b-39c83d985c6f"/>
							<gml:surfaceMember xlink:href="#poly-70c19d79-9927-405d-9ec9-9dbd01995d98"/>
							<gml:surfaceMember xlink:href="#poly-3f5210d2-ad40-4428-b289-4bde6be94a13"/>
							<gml:surfaceMember xlink:href="#poly-4a9a9550-1bdd-4734-95fb-c970f0b73b56"/>
							<gml:surfaceMember xlink:href="#poly-8b9e0f0f-db2c-4fa7-95c5-78d844724e56"/>
							<gml:surfaceMember xlink:href="#poly-c0670c1a-356d-4f5b-ac09-1e5e090eecb2"/>
							<gml:surfaceMember xlink:href="#poly-2ba0ba3f-463b-417c-b995-e9bd9e2d28ec"/>
							<gml:surfaceMember xlink:href="#poly-6f5741f1-eaf5-49e8-be71-20a216f016af"/>
							<gml:surfaceMember xlink:href="#poly-57228d84-36c0-435b-8c2f-c0f60413cf80"/>
							<gml:surfaceMember xlink:href="#poly-95ba6c13-f008-4126-bb9f-344a62572019"/>
							<gml:surfaceMember xlink:href="#poly-fb4babdb-6acc-4fe1-b080-465efcff4ac0"/>
							<gml:surfaceMember xlink:href="#poly-a10ee1ab-8286-4342-b79e-891d22de5ea6"/>
							<gml:surfaceMember xlink:href="#poly-1c3731cb-24ba-4fba-94fa-5cd13264da72"/>
							<gml:surfaceMember xlink:href="#poly-297ffdbf-77f5-47cc-8c71-ac966e923f54"/>
							<gml:surfaceMember xlink:href="#poly-17a5f0e5-fb57-40b1-b08c-36fab9316495"/>
							<gml:surfaceMember xlink:href="#poly-b0e6e5a6-cbee-424c-8e8e-f79e07e38f9c"/>
							<gml:surfaceMember xlink:href="#poly-a274847b-9159-462b-8549-8bba192f3075"/>
							<gml:surfaceMember xlink:href="#poly-e0083872-07a8-4a66-9000-a242042bba54"/>
							<gml:surfaceMember xlink:href="#poly-f23b1db5-e4f4-47b7-a3ec-3c006d373095"/>
							<gml:surfaceMember xlink:href="#poly-fb93498b-8dc8-43e5-8dd8-b77d0c1d004b"/>
							<gml:surfaceMember xlink:href="#poly-8bcc62e5-2872-4676-aed2-db5f94f7a04a"/>
							<gml:surfaceMember xlink:href="#poly-c8fcc20b-feb7-49f0-9ed6-d7196c7526b3"/>
							<gml:surfaceMember xlink:href="#poly-6d1b20b7-6cc9-44bd-be07-ce12ab56c88e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b5aa0b90-ad5d-47a5-a6ed-d6dcbfe3c341_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21f337a5-67da-4751-bfd0-0fb23f7ae7d6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668346115339084 139.73984129879605 37.209 35.668384065184284 139.73987874461844 37.209 35.66836855283568 139.73990234587035 37.209 35.66833060299771 139.739864900044 37.209 35.668346115339084 139.73984129879605 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52beb9d2-445d-43ca-b5a7-bdfb2b6b7027">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52beb9d2-445d-43ca-b5a7-bdfb2b6b7027_0">
											<gml:posList>35.66833060299771 139.739864900044 37.209 35.66833060299771 139.739864900044 39.641 35.668346115339084 139.73984129879605 39.641 35.668346115339084 139.73984129879605 37.209 35.66833060299771 139.739864900044 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4fb5a4d-05e6-4c90-8ddf-9b356199e323">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4fb5a4d-05e6-4c90-8ddf-9b356199e323_0">
											<gml:posList>35.668346115339084 139.73984129879605 37.209 35.668346115339084 139.73984129879605 39.641 35.668384065184284 139.73987874461844 39.641 35.668384065184284 139.73987874461844 37.209 35.668346115339084 139.73984129879605 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb5d9862-f2ac-490a-9864-aba4a0b7393d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb5d9862-f2ac-490a-9864-aba4a0b7393d_0">
											<gml:posList>35.66836855283568 139.73990234587035 39.641 35.668384065184284 139.73987874461844 39.641 35.668346115339084 139.73984129879605 39.641 35.66833060299771 139.739864900044 39.641 35.66836855283568 139.73990234587035 39.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e075c151-f9ad-43f9-b844-41facac3e6b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e075c151-f9ad-43f9-b844-41facac3e6b3_0">
											<gml:posList>35.66836855283568 139.73990234587035 37.209 35.66836855283568 139.73990234587035 39.641 35.66833060299771 139.739864900044 39.641 35.66833060299771 139.739864900044 37.209 35.66836855283568 139.73990234587035 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50e74767-42f7-4441-b9ff-37b89707a984">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50e74767-42f7-4441-b9ff-37b89707a984_0">
											<gml:posList>35.668384065184284 139.73987874461844 37.209 35.668384065184284 139.73987874461844 39.641 35.66836855283568 139.73990234587035 39.641 35.66836855283568 139.73990234587035 37.209 35.668384065184284 139.73987874461844 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b5aa0b90-ad5d-47a5-a6ed-d6dcbfe3c341_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-301771ea-f8fd-4374-974f-a894df0e7f18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668398714315245 139.73976500911476 44.57 35.668386641859726 139.73978426530786 44.57 35.66837461775854 139.7397729461576 44.57 35.66838669020368 139.73975367891973 44.57 35.668398714315245 139.73976500911476 44.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69bde04c-83f7-4240-9bc5-059ccdac8ed3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668344270029365 139.73977489252252 37.209 35.66833753503145 139.73978425632427 37.209 35.668329181301615 139.73977523046142 37.209 35.668335907285105 139.7397658666704 37.209 35.668344270029365 139.73977489252252 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cf278c0-f15f-4b0f-95c8-5e353aeea7b5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668391134530836 139.73978919762177 37.209 35.66841104324138 139.7398090240363 37.209 35.668395026566756 139.73983317819702 37.209 35.668375117851554 139.73981334073443 37.209 35.668391134530836 139.73978919762177 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55880e81-bb5c-43c7-8530-c349c79ebbf2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55880e81-bb5c-43c7-8530-c349c79ebbf2_0">
											<gml:posList>35.668335907285105 139.7397658666704 37.209 35.668329181301615 139.73977523046142 37.209 35.668329181301615 139.73977523046142 38.751 35.668335907285105 139.7397658666704 38.751 35.668335907285105 139.7397658666704 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fd6e843-9c54-4560-93aa-f7ef53966748">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fd6e843-9c54-4560-93aa-f7ef53966748_0">
											<gml:posList>35.668329181301615 139.73977523046142 37.209 35.66833753503145 139.73978425632427 37.209 35.66833753503145 139.73978425632427 38.751 35.668329181301615 139.73977523046142 38.751 35.668329181301615 139.73977523046142 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e328ea0-84fb-437d-b54a-593715f00291">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e328ea0-84fb-437d-b54a-593715f00291_0">
											<gml:posList>35.668329181301615 139.73977523046142 38.751 35.66833753503145 139.73978425632427 38.751 35.668344270029365 139.73977489252252 38.751 35.668335907285105 139.7397658666704 38.751 35.668329181301615 139.73977523046142 38.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92aad23e-73da-4331-817a-ad8c51391729">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92aad23e-73da-4331-817a-ad8c51391729_0">
											<gml:posList>35.668335907285105 139.7397658666704 37.209 35.668335907285105 139.7397658666704 38.751 35.668344270029365 139.73977489252252 38.751 35.668344270029365 139.73977489252252 37.209 35.668335907285105 139.7397658666704 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40533129-6aa0-4fac-b499-b3007c1e86a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40533129-6aa0-4fac-b499-b3007c1e86a4_0">
											<gml:posList>35.66833753503145 139.73978425632427 37.209 35.668344270029365 139.73977489252252 37.209 35.668344270029365 139.73977489252252 38.751 35.66833753503145 139.73978425632427 38.751 35.66833753503145 139.73978425632427 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b132fe38-ef7c-417d-af1b-b7cfa179c718">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b132fe38-ef7c-417d-af1b-b7cfa179c718_0">
											<gml:posList>35.66837461775854 139.7397729461576 44.57 35.668386641859726 139.73978426530786 44.57 35.668386641859726 139.73978426530786 45.699 35.66837461775854 139.7397729461576 45.699 35.66837461775854 139.7397729461576 44.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f88a7ca7-a5e5-427a-84fc-dd08191e6f9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f88a7ca7-a5e5-427a-84fc-dd08191e6f9d_0">
											<gml:posList>35.66837461775854 139.7397729461576 44.57 35.66837461775854 139.7397729461576 45.699 35.66838669020368 139.73975367891973 45.699 35.66838669020368 139.73975367891973 44.57 35.66837461775854 139.7397729461576 44.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4f6e3f9-73a4-48c7-a0ec-2e7e92f01e34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4f6e3f9-73a4-48c7-a0ec-2e7e92f01e34_0">
											<gml:posList>35.668375117851554 139.73981334073443 37.209 35.668375117851554 139.73981334073443 38.205 35.668391134530836 139.73978919762177 38.205 35.668391134530836 139.73978919762177 37.209 35.668375117851554 139.73981334073443 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a90093c8-5391-49d2-9f73-0bd8c92746d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a90093c8-5391-49d2-9f73-0bd8c92746d3_0">
											<gml:posList>35.668375117851554 139.73981334073443 37.209 35.668395026566756 139.73983317819702 37.209 35.668395026566756 139.73983317819702 38.205 35.668375117851554 139.73981334073443 38.205 35.668375117851554 139.73981334073443 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-732ee293-8864-41df-a5bb-b96b00c71745">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-732ee293-8864-41df-a5bb-b96b00c71745_0">
											<gml:posList>35.66837461775854 139.7397729461576 45.699 35.668386641859726 139.73978426530786 45.699 35.668398714315245 139.73976500911476 45.699 35.66838669020368 139.73975367891973 45.699 35.66837461775854 139.7397729461576 45.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f870785f-b58f-4144-a134-c4783be66d2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f870785f-b58f-4144-a134-c4783be66d2f_0">
											<gml:posList>35.668386641859726 139.73978426530786 44.57 35.668398714315245 139.73976500911476 44.57 35.668398714315245 139.73976500911476 45.699 35.668386641859726 139.73978426530786 45.699 35.668386641859726 139.73978426530786 44.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdb2c224-ea7a-4217-8a1b-623834475473">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdb2c224-ea7a-4217-8a1b-623834475473_0">
											<gml:posList>35.668398714315245 139.73976500911476 44.57 35.66838669020368 139.73975367891973 44.57 35.66838669020368 139.73975367891973 45.699 35.668398714315245 139.73976500911476 45.699 35.668398714315245 139.73976500911476 44.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-674f7675-0d9d-4682-9406-9c77a35b0a0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-674f7675-0d9d-4682-9406-9c77a35b0a0a_0">
											<gml:posList>35.668395026566756 139.73983317819702 38.205 35.66841104324138 139.7398090240363 38.205 35.668391134530836 139.73978919762177 38.205 35.668375117851554 139.73981334073443 38.205 35.668395026566756 139.73983317819702 38.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bffe65f-d8af-4fa8-8d22-f1114f7eabbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bffe65f-d8af-4fa8-8d22-f1114f7eabbb_0">
											<gml:posList>35.668391134530836 139.73978919762177 37.209 35.668391134530836 139.73978919762177 38.205 35.66841104324138 139.7398090240363 38.205 35.66841104324138 139.7398090240363 37.209 35.668391134530836 139.73978919762177 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eebf7ebe-36d4-4caf-8413-fac7fb316852">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eebf7ebe-36d4-4caf-8413-fac7fb316852_0">
											<gml:posList>35.668395026566756 139.73983317819702 37.209 35.66841104324138 139.7398090240363 37.209 35.66841104324138 139.7398090240363 38.205 35.668395026566756 139.73983317819702 38.205 35.668395026566756 139.73983317819702 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b5aa0b90-ad5d-47a5-a6ed-d6dcbfe3c341_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a2b973a-3aa3-4594-9777-4c54d732d8ca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66837192253162 139.73980760055022 37.209 35.66835119292811 139.73978694665485 37.209 35.66835914273662 139.73977495249085 37.209 35.66837987234215 139.73979560638514 37.209 35.66837192253162 139.73980760055022 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6afd8b8d-cfdb-4a3f-ae45-ee59cafa337d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6afd8b8d-cfdb-4a3f-ae45-ee59cafa337d_0">
											<gml:posList>35.66835119292811 139.73978694665485 38.095 35.66835914273662 139.73977495249085 38.095 35.66835914273662 139.73977495249085 37.209 35.66835119292811 139.73978694665485 37.209 35.66835119292811 139.73978694665485 38.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d9395df-202f-4586-8c06-80c921423f96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d9395df-202f-4586-8c06-80c921423f96_0">
											<gml:posList>35.66835914273662 139.73977495249085 37.209 35.66835914273662 139.73977495249085 38.095 35.66837987234215 139.73979560638514 38.095 35.66837987234215 139.73979560638514 37.209 35.66835914273662 139.73977495249085 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c6350ca-761a-4a4f-9ca2-652ca66a0f26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c6350ca-761a-4a4f-9ca2-652ca66a0f26_0">
											<gml:posList>35.66837192253162 139.73980760055022 38.095 35.66837987234215 139.73979560638514 38.095 35.66835914273662 139.73977495249085 38.095 35.66835119292811 139.73978694665485 38.095 35.66837192253162 139.73980760055022 38.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86255896-d5a7-40fd-af44-c1b33e4db08f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86255896-d5a7-40fd-af44-c1b33e4db08f_0">
											<gml:posList>35.66837192253162 139.73980760055022 38.095 35.66835119292811 139.73978694665485 38.095 35.66835119292811 139.73978694665485 37.209 35.66837192253162 139.73980760055022 37.209 35.66837192253162 139.73980760055022 38.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-528f249c-2960-4dd9-a8b9-c7b5471d6d31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-528f249c-2960-4dd9-a8b9-c7b5471d6d31_0">
											<gml:posList>35.66837987234215 139.73979560638514 37.209 35.66837987234215 139.73979560638514 38.095 35.66837192253162 139.73980760055022 38.095 35.66837192253162 139.73980760055022 37.209 35.66837987234215 139.73979560638514 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7da47072-7721-4b07-a929-20adfe361c63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7da47072-7721-4b07-a929-20adfe361c63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7da47072-7721-4b07-a929-20adfe361c63">
											<gml:posList>35.66836159858631 139.73971066201432 11.02 35.66843436565722 139.73977921684093 11.02 35.668421429031596 139.73979995421112 11.02 35.66848862811771 139.73986018697704 11.02 35.66840678940943 139.73998410790009 11.02 35.668265983008624 139.73985260388582 11.02 35.66836159858631 139.73971066201432 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e97c69e0-c2b5-4dde-bc2d-40fd9a64e466">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e97c69e0-c2b5-4dde-bc2d-40fd9a64e466">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e97c69e0-c2b5-4dde-bc2d-40fd9a64e466">
											<gml:posList>35.668265983008624 139.73985260388582 39.482 35.66826840743501 139.73985225863436 39.482 35.668361826205285 139.7397135889336 39.482 35.66836151755726 139.73971078361475 39.482 35.668265983008624 139.73985260388582 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a68bcb5a-b19a-413b-ada9-105275365a9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a68bcb5a-b19a-413b-ada9-105275365a9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a68bcb5a-b19a-413b-ada9-105275365a9d">
											<gml:posList>35.66840678940943 139.73998410790009 39.482 35.668406498735216 139.73998122523574 39.482 35.66826840743501 139.73985225863436 39.482 35.668265983008624 139.73985260388582 39.482 35.66840678940943 139.73998410790009 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-10f6e5fb-e4bc-4745-b77b-d1ed5dd6cc52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10f6e5fb-e4bc-4745-b77b-d1ed5dd6cc52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10f6e5fb-e4bc-4745-b77b-d1ed5dd6cc52">
											<gml:posList>35.668352151683685 139.73976799063468 46.444 35.668354648236765 139.73976766738804 46.444 35.668379749126785 139.73972983874145 46.444 35.66837909824092 139.73972739833889 46.444 35.668352151683685 139.73976799063468 46.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c04e455-780b-42ac-b21b-f9e9e070d82d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c04e455-780b-42ac-b21b-f9e9e070d82d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c04e455-780b-42ac-b21b-f9e9e070d82d">
											<gml:posList>35.66838409403474 139.73979980998038 46.444 35.66838383928231 139.73979676158586 46.444 35.668354648236765 139.73976766738804 46.444 35.668352151683685 139.73976799063468 46.444 35.66838409403474 139.73979980998038 46.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-94654be9-53f6-4da3-b32d-867c13a713dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94654be9-53f6-4da3-b32d-867c13a713dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94654be9-53f6-4da3-b32d-867c13a713dd">
											<gml:posList>35.668361826205285 139.7397135889336 39.482 35.66837763068663 139.73972956506486 39.482 35.668379080161955 139.73972733208407 39.482 35.66836151755726 139.73971078361475 39.482 35.668361826205285 139.7397135889336 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a9021b6-ab26-4019-8fb9-0a2c3da64766">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a9021b6-ab26-4019-8fb9-0a2c3da64766">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a9021b6-ab26-4019-8fb9-0a2c3da64766">
											<gml:posList>35.66826840743501 139.73985225863436 37.209 35.668406498735216 139.73998122523574 37.209 35.668486185689666 139.73986056538823 37.209 35.66841903170666 139.73980037675517 37.209 35.668432013340926 139.73977956201122 37.209 35.66841063515658 139.739759439072 37.209 35.66838409403474 139.73979980998038 37.209 35.668352151683685 139.73976799063468 37.209 35.66837763068663 139.73972956506486 37.209 35.668361826205285 139.7397135889336 37.209 35.66826840743501 139.73985225863436 37.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c7ba47dd-8d27-42a6-9633-1acd469051f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7ba47dd-8d27-42a6-9633-1acd469051f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7ba47dd-8d27-42a6-9633-1acd469051f8">
											<gml:posList>35.66840894016418 139.73975891084262 44.57 35.668379749126785 139.73972983874145 44.57 35.668354648236765 139.73976766738804 44.57 35.66838383928231 139.73979676158586 44.57 35.66840894016418 139.73975891084262 44.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7020e2aa-e8aa-4a20-8d67-0f9ddaf95e39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7020e2aa-e8aa-4a20-8d67-0f9ddaf95e39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7020e2aa-e8aa-4a20-8d67-0f9ddaf95e39">
											<gml:posList>35.66837909824092 139.73972739833889 46.444 35.668379749126785 139.73972983874145 46.444 35.66840894016418 139.73975891084262 46.444 35.66841172479589 139.73975812332782 46.444 35.66837909824092 139.73972739833889 46.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a3984ff-89ff-4246-b49b-a32c4a299515">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a3984ff-89ff-4246-b49b-a32c4a299515">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a3984ff-89ff-4246-b49b-a32c4a299515">
											<gml:posList>35.66841172479589 139.73975812332782 46.444 35.66840894016418 139.73975891084262 46.444 35.66838383928231 139.73979676158586 46.444 35.66838409403474 139.73979980998038 46.444 35.66841172479589 139.73975812332782 46.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8c471f6-193f-4601-92b2-78213c357746">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8c471f6-193f-4601-92b2-78213c357746">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8c471f6-193f-4601-92b2-78213c357746">
											<gml:posList>35.668432013340926 139.73977956201122 39.482 35.668434293641816 139.73977933843088 39.482 35.66841160749729 139.73975796882087 39.482 35.66841063515658 139.739759439072 39.482 35.668432013340926 139.73977956201122 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e224cfca-e92f-4c0c-9b9b-39c83d985c6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e224cfca-e92f-4c0c-9b9b-39c83d985c6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e224cfca-e92f-4c0c-9b9b-39c83d985c6f">
											<gml:posList>35.668421429031596 139.73979995421112 39.482 35.668434293641816 139.73977933843088 39.482 35.668432013340926 139.73977956201122 39.482 35.66841903170666 139.73980037675517 39.482 35.668421429031596 139.73979995421112 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70c19d79-9927-405d-9ec9-9dbd01995d98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70c19d79-9927-405d-9ec9-9dbd01995d98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70c19d79-9927-405d-9ec9-9dbd01995d98">
											<gml:posList>35.66848862811771 139.73986018697704 39.482 35.668486185689666 139.73986056538823 39.482 35.668406498735216 139.73998122523574 39.482 35.66840678940943 139.73998410790009 39.482 35.66848862811771 139.73986018697704 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f5210d2-ad40-4428-b289-4bde6be94a13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f5210d2-ad40-4428-b289-4bde6be94a13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f5210d2-ad40-4428-b289-4bde6be94a13">
											<gml:posList>35.668421429031596 139.73979995421112 39.482 35.66841903170666 139.73980037675517 39.482 35.668486185689666 139.73986056538823 39.482 35.66848862811771 139.73986018697704 39.482 35.668421429031596 139.73979995421112 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a9a9550-1bdd-4734-95fb-c970f0b73b56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a9a9550-1bdd-4734-95fb-c970f0b73b56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a9a9550-1bdd-4734-95fb-c970f0b73b56">
											<gml:posList>35.66838383928231 139.73979676158586 46.444 35.66838383928231 139.73979676158586 44.57 35.668354648236765 139.73976766738804 44.57 35.668354648236765 139.73976766738804 46.444 35.66838383928231 139.73979676158586 46.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b9e0f0f-db2c-4fa7-95c5-78d844724e56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b9e0f0f-db2c-4fa7-95c5-78d844724e56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b9e0f0f-db2c-4fa7-95c5-78d844724e56">
											<gml:posList>35.66836159858631 139.73971066201432 11.02 35.668265983008624 139.73985260388582 11.02 35.668265983008624 139.73985260388582 39.482 35.66836151755726 139.73971078361475 39.482 35.66836159858631 139.73971066201432 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0670c1a-356d-4f5b-ac09-1e5e090eecb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0670c1a-356d-4f5b-ac09-1e5e090eecb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0670c1a-356d-4f5b-ac09-1e5e090eecb2">
											<gml:posList>35.66826840743501 139.73985225863436 39.482 35.66826840743501 139.73985225863436 37.209 35.668361826205285 139.7397135889336 37.209 35.668361826205285 139.7397135889336 39.482 35.66826840743501 139.73985225863436 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ba0ba3f-463b-417c-b995-e9bd9e2d28ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ba0ba3f-463b-417c-b995-e9bd9e2d28ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ba0ba3f-463b-417c-b995-e9bd9e2d28ec">
											<gml:posList>35.668265983008624 139.73985260388582 11.02 35.66840678940943 139.73998410790009 11.02 35.66840678940943 139.73998410790009 39.482 35.668265983008624 139.73985260388582 39.482 35.668265983008624 139.73985260388582 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f5741f1-eaf5-49e8-be71-20a216f016af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f5741f1-eaf5-49e8-be71-20a216f016af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f5741f1-eaf5-49e8-be71-20a216f016af">
											<gml:posList>35.668406498735216 139.73998122523574 39.482 35.668406498735216 139.73998122523574 37.209 35.66826840743501 139.73985225863436 37.209 35.66826840743501 139.73985225863436 39.482 35.668406498735216 139.73998122523574 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57228d84-36c0-435b-8c2f-c0f60413cf80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57228d84-36c0-435b-8c2f-c0f60413cf80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57228d84-36c0-435b-8c2f-c0f60413cf80">
											<gml:posList>35.66837763068663 139.73972956506486 39.482 35.66837763068663 139.73972956506486 37.209 35.668352151683685 139.73976799063468 37.209 35.668352151683685 139.73976799063468 46.444 35.66837909824092 139.73972739833889 46.444 35.668379080161955 139.73972733208407 39.482 35.66837763068663 139.73972956506486 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95ba6c13-f008-4126-bb9f-344a62572019">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95ba6c13-f008-4126-bb9f-344a62572019">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95ba6c13-f008-4126-bb9f-344a62572019">
											<gml:posList>35.668354648236765 139.73976766738804 46.444 35.668354648236765 139.73976766738804 44.57 35.668379749126785 139.73972983874145 44.57 35.668379749126785 139.73972983874145 46.444 35.668354648236765 139.73976766738804 46.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb4babdb-6acc-4fe1-b080-465efcff4ac0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb4babdb-6acc-4fe1-b080-465efcff4ac0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb4babdb-6acc-4fe1-b080-465efcff4ac0">
											<gml:posList>35.668352151683685 139.73976799063468 46.444 35.668352151683685 139.73976799063468 37.209 35.66838409403474 139.73979980998038 37.209 35.66838409403474 139.73979980998038 46.444 35.668352151683685 139.73976799063468 46.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a10ee1ab-8286-4342-b79e-891d22de5ea6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a10ee1ab-8286-4342-b79e-891d22de5ea6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a10ee1ab-8286-4342-b79e-891d22de5ea6">
											<gml:posList>35.668361826205285 139.7397135889336 39.482 35.668361826205285 139.7397135889336 37.209 35.66837763068663 139.73972956506486 37.209 35.66837763068663 139.73972956506486 39.482 35.668361826205285 139.7397135889336 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c3731cb-24ba-4fba-94fa-5cd13264da72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c3731cb-24ba-4fba-94fa-5cd13264da72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c3731cb-24ba-4fba-94fa-5cd13264da72">
											<gml:posList>35.668379749126785 139.73972983874145 46.444 35.668379749126785 139.73972983874145 44.57 35.66840894016418 139.73975891084262 44.57 35.66840894016418 139.73975891084262 46.444 35.668379749126785 139.73972983874145 46.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-297ffdbf-77f5-47cc-8c71-ac966e923f54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-297ffdbf-77f5-47cc-8c71-ac966e923f54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-297ffdbf-77f5-47cc-8c71-ac966e923f54">
											<gml:posList>35.66840894016418 139.73975891084262 46.444 35.66840894016418 139.73975891084262 44.57 35.66838383928231 139.73979676158586 44.57 35.66838383928231 139.73979676158586 46.444 35.66840894016418 139.73975891084262 46.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17a5f0e5-fb57-40b1-b08c-36fab9316495">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17a5f0e5-fb57-40b1-b08c-36fab9316495">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17a5f0e5-fb57-40b1-b08c-36fab9316495">
											<gml:posList>35.66841063515658 139.739759439072 39.482 35.66841160749729 139.73975796882087 39.482 35.66841172479589 139.73975812332782 46.444 35.66838409403474 139.73979980998038 46.444 35.66838409403474 139.73979980998038 37.209 35.66841063515658 139.739759439072 37.209 35.66841063515658 139.739759439072 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0e6e5a6-cbee-424c-8e8e-f79e07e38f9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0e6e5a6-cbee-424c-8e8e-f79e07e38f9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0e6e5a6-cbee-424c-8e8e-f79e07e38f9c">
											<gml:posList>35.66843436565722 139.73977921684093 11.02 35.66836159858631 139.73971066201432 11.02 35.66836151755726 139.73971078361475 39.482 35.668379080161955 139.73972733208407 39.482 35.66837909824092 139.73972739833889 46.444 35.66841172479589 139.73975812332782 46.444 35.66841160749729 139.73975796882087 39.482 35.668434293641816 139.73977933843088 39.482 35.66843436565722 139.73977921684093 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a274847b-9159-462b-8549-8bba192f3075">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a274847b-9159-462b-8549-8bba192f3075">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a274847b-9159-462b-8549-8bba192f3075">
											<gml:posList>35.66841063515658 139.739759439072 39.482 35.66841063515658 139.739759439072 37.209 35.668432013340926 139.73977956201122 37.209 35.668432013340926 139.73977956201122 39.482 35.66841063515658 139.739759439072 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0083872-07a8-4a66-9000-a242042bba54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0083872-07a8-4a66-9000-a242042bba54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0083872-07a8-4a66-9000-a242042bba54">
											<gml:posList>35.668432013340926 139.73977956201122 39.482 35.668432013340926 139.73977956201122 37.209 35.66841903170666 139.73980037675517 37.209 35.66841903170666 139.73980037675517 39.482 35.668432013340926 139.73977956201122 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f23b1db5-e4f4-47b7-a3ec-3c006d373095">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f23b1db5-e4f4-47b7-a3ec-3c006d373095">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f23b1db5-e4f4-47b7-a3ec-3c006d373095">
											<gml:posList>35.668421429031596 139.73979995421112 11.02 35.66843436565722 139.73977921684093 11.02 35.668434293641816 139.73977933843088 39.482 35.668421429031596 139.73979995421112 39.482 35.668421429031596 139.73979995421112 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb93498b-8dc8-43e5-8dd8-b77d0c1d004b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb93498b-8dc8-43e5-8dd8-b77d0c1d004b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb93498b-8dc8-43e5-8dd8-b77d0c1d004b">
											<gml:posList>35.668486185689666 139.73986056538823 39.482 35.668486185689666 139.73986056538823 37.209 35.668406498735216 139.73998122523574 37.209 35.668406498735216 139.73998122523574 39.482 35.668486185689666 139.73986056538823 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bcc62e5-2872-4676-aed2-db5f94f7a04a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bcc62e5-2872-4676-aed2-db5f94f7a04a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bcc62e5-2872-4676-aed2-db5f94f7a04a">
											<gml:posList>35.66840678940943 139.73998410790009 11.02 35.66848862811771 139.73986018697704 11.02 35.66848862811771 139.73986018697704 39.482 35.66840678940943 139.73998410790009 39.482 35.66840678940943 139.73998410790009 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8fcc20b-feb7-49f0-9ed6-d7196c7526b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8fcc20b-feb7-49f0-9ed6-d7196c7526b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8fcc20b-feb7-49f0-9ed6-d7196c7526b3">
											<gml:posList>35.66841903170666 139.73980037675517 39.482 35.66841903170666 139.73980037675517 37.209 35.668486185689666 139.73986056538823 37.209 35.668486185689666 139.73986056538823 39.482 35.66841903170666 139.73980037675517 39.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d1b20b7-6cc9-44bd-be07-ce12ab56c88e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d1b20b7-6cc9-44bd-be07-ce12ab56c88e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d1b20b7-6cc9-44bd-be07-ce12ab56c88e">
											<gml:posList>35.66848862811771 139.73986018697704 11.02 35.668421429031596 139.73979995421112 11.02 35.668421429031596 139.73979995421112 39.482 35.66848862811771 139.73986018697704 39.482 35.66848862811771 139.73986018697704 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7876</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">304.0362</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.19</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>