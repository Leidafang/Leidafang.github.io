<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b60c9d02-b809-4836-9a7b-784441779f5b">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">6.7</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66861725665342 139.7399331837497 0 35.66867044268236 139.73998613166484 0 35.668701773829774 139.73993887341922 0 35.668648587780346 139.73988592551493 0 35.66861725665342 139.7399331837497 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66861725665342 139.7399331837497 11.46 35.668648587780346 139.73988592551493 11.46 35.668701773829774 139.73993887341922 11.46 35.66867044268236 139.73998613166484 11.46 35.66861725665342 139.7399331837497 11.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66861725665342 139.7399331837497 11.46 35.66867044268236 139.73998613166484 11.46 35.66867044268236 139.73998613166484 18.16 35.66861725665342 139.7399331837497 18.16 35.66861725665342 139.7399331837497 11.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867044268236 139.73998613166484 11.46 35.668701773829774 139.73993887341922 11.46 35.668701773829774 139.73993887341922 18.16 35.66867044268236 139.73998613166484 18.16 35.66867044268236 139.73998613166484 11.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668701773829774 139.73993887341922 11.46 35.668648587780346 139.73988592551493 11.46 35.668648587780346 139.73988592551493 18.16 35.668701773829774 139.73993887341922 18.16 35.668701773829774 139.73993887341922 11.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668648587780346 139.73988592551493 11.46 35.66861725665342 139.7399331837497 11.46 35.66861725665342 139.7399331837497 18.16 35.668648587780346 139.73988592551493 18.16 35.668648587780346 139.73988592551493 11.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66861725665342 139.7399331837497 18.16 35.66867044268236 139.73998613166484 18.16 35.668701773829774 139.73993887341922 18.16 35.668648587780346 139.73988592551493 18.16 35.66861725665342 139.7399331837497 18.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c680ade3-b009-445c-9236-b0c45efc5917"/>
							<gml:surfaceMember xlink:href="#poly-1e8509ff-de0b-4a65-a050-711b904ab2b3"/>
							<gml:surfaceMember xlink:href="#poly-f16ce49e-30cb-49d9-a20f-436361579047"/>
							<gml:surfaceMember xlink:href="#poly-e3920ddd-f2b7-4f78-ae46-144ad26aba4d"/>
							<gml:surfaceMember xlink:href="#poly-6620f4ad-9abf-42cf-af0f-94557ebda3b2"/>
							<gml:surfaceMember xlink:href="#poly-9988dd42-5991-4cbc-b1c2-edf773ba1131"/>
							<gml:surfaceMember xlink:href="#poly-4aba7b3d-3e80-41e9-8c8b-78ca33fa0a81"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c680ade3-b009-445c-9236-b0c45efc5917">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c680ade3-b009-445c-9236-b0c45efc5917">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c680ade3-b009-445c-9236-b0c45efc5917">
											<gml:posList>35.668617256653405 139.7399331837497 11.46 35.66864858778035 139.7398859255149 11.46 35.66870177382976 139.73993887341922 11.46 35.66867044268234 139.73998613166484 11.46 35.668617256653405 139.7399331837497 11.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e8509ff-de0b-4a65-a050-711b904ab2b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e8509ff-de0b-4a65-a050-711b904ab2b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e8509ff-de0b-4a65-a050-711b904ab2b3">
											<gml:posList>35.66870177382976 139.73993887341922 16.888 35.66864858778035 139.7398859255149 16.888 35.668632922223516 139.73990956015993 19.125 35.66868610825411 139.73996249702364 19.125 35.66870177382976 139.73993887341922 16.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f16ce49e-30cb-49d9-a20f-436361579047">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f16ce49e-30cb-49d9-a20f-436361579047">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f16ce49e-30cb-49d9-a20f-436361579047">
											<gml:posList>35.668617256653405 139.7399331837497 16.888 35.66867044268234 139.73998613166484 16.888 35.66868610825411 139.73996249702364 19.125 35.668632922223516 139.73990956015993 19.125 35.668617256653405 139.7399331837497 16.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3920ddd-f2b7-4f78-ae46-144ad26aba4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3920ddd-f2b7-4f78-ae46-144ad26aba4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3920ddd-f2b7-4f78-ae46-144ad26aba4d">
											<gml:posList>35.66864858778035 139.7398859255149 11.46 35.668617256653405 139.7399331837497 11.46 35.668617256653405 139.7399331837497 16.888 35.668632922223516 139.73990956015993 19.125 35.66864858778035 139.7398859255149 16.888 35.66864858778035 139.7398859255149 11.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6620f4ad-9abf-42cf-af0f-94557ebda3b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6620f4ad-9abf-42cf-af0f-94557ebda3b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6620f4ad-9abf-42cf-af0f-94557ebda3b2">
											<gml:posList>35.66870177382976 139.73993887341922 11.46 35.66864858778035 139.7398859255149 11.46 35.66864858778035 139.7398859255149 16.888 35.66870177382976 139.73993887341922 16.888 35.66870177382976 139.73993887341922 11.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9988dd42-5991-4cbc-b1c2-edf773ba1131">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9988dd42-5991-4cbc-b1c2-edf773ba1131">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9988dd42-5991-4cbc-b1c2-edf773ba1131">
											<gml:posList>35.668617256653405 139.7399331837497 11.46 35.66867044268234 139.73998613166484 11.46 35.66867044268234 139.73998613166484 16.888 35.668617256653405 139.7399331837497 16.888 35.668617256653405 139.7399331837497 11.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4aba7b3d-3e80-41e9-8c8b-78ca33fa0a81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4aba7b3d-3e80-41e9-8c8b-78ca33fa0a81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4aba7b3d-3e80-41e9-8c8b-78ca33fa0a81">
											<gml:posList>35.66867044268234 139.73998613166484 11.46 35.66870177382976 139.73993887341922 11.46 35.66870177382976 139.73993887341922 16.888 35.66868610825411 139.73996249702364 19.125 35.66867044268234 139.73998613166484 16.888 35.66867044268234 139.73998613166484 11.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7685</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">222</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>