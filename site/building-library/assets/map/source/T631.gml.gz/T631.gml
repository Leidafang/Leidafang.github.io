<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b70a507b-9101-41c7-ba64-56f0070a2388">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">36.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>12</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67262214346292 139.73821279839893 0 35.67265154738781 139.7383055768113 0 35.672655746202764 139.73830357240476 0 35.67265944201955 139.73831523320527 0 35.67269636640345 139.73829765852278 0 35.67269528203692 139.7382942132758 0 35.672722583376306 139.7382812232705 0 35.67274101727756 139.73833938377538 0 35.67279308805071 139.73831459980454 0 35.67274044288836 139.73814849947726 0 35.67262464203344 139.73820362678262 0 35.67262684686138 139.73821056141156 0 35.67262214346292 139.73821279839893 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67262214346292 139.73821279839893 9.013 35.67262684686138 139.73821056141156 9.013 35.67262464203344 139.73820362678262 9.013 35.67274044288836 139.73814849947726 9.013 35.67279308805071 139.73831459980454 9.013 35.67274101727756 139.73833938377538 9.013 35.672722583376306 139.7382812232705 9.013 35.67269528203692 139.7382942132758 9.013 35.67269636640345 139.73829765852278 9.013 35.67265944201955 139.73831523320527 9.013 35.672655746202764 139.73830357240476 9.013 35.67265154738781 139.7383055768113 9.013 35.67262214346292 139.73821279839893 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67262214346292 139.73821279839893 9.013 35.67265154738781 139.7383055768113 9.013 35.67265154738781 139.7383055768113 45.9 35.67262214346292 139.73821279839893 45.9 35.67262214346292 139.73821279839893 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67265154738781 139.7383055768113 9.013 35.672655746202764 139.73830357240476 9.013 35.672655746202764 139.73830357240476 45.9 35.67265154738781 139.7383055768113 45.9 35.67265154738781 139.7383055768113 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672655746202764 139.73830357240476 9.013 35.67265944201955 139.73831523320527 9.013 35.67265944201955 139.73831523320527 45.9 35.672655746202764 139.73830357240476 45.9 35.672655746202764 139.73830357240476 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67265944201955 139.73831523320527 9.013 35.67269636640345 139.73829765852278 9.013 35.67269636640345 139.73829765852278 45.9 35.67265944201955 139.73831523320527 45.9 35.67265944201955 139.73831523320527 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67269636640345 139.73829765852278 9.013 35.67269528203692 139.7382942132758 9.013 35.67269528203692 139.7382942132758 45.9 35.67269636640345 139.73829765852278 45.9 35.67269636640345 139.73829765852278 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67269528203692 139.7382942132758 9.013 35.672722583376306 139.7382812232705 9.013 35.672722583376306 139.7382812232705 45.9 35.67269528203692 139.7382942132758 45.9 35.67269528203692 139.7382942132758 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672722583376306 139.7382812232705 9.013 35.67274101727756 139.73833938377538 9.013 35.67274101727756 139.73833938377538 45.9 35.672722583376306 139.7382812232705 45.9 35.672722583376306 139.7382812232705 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67274101727756 139.73833938377538 9.013 35.67279308805071 139.73831459980454 9.013 35.67279308805071 139.73831459980454 45.9 35.67274101727756 139.73833938377538 45.9 35.67274101727756 139.73833938377538 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67279308805071 139.73831459980454 9.013 35.67274044288836 139.73814849947726 9.013 35.67274044288836 139.73814849947726 45.9 35.67279308805071 139.73831459980454 45.9 35.67279308805071 139.73831459980454 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67274044288836 139.73814849947726 9.013 35.67262464203344 139.73820362678262 9.013 35.67262464203344 139.73820362678262 45.9 35.67274044288836 139.73814849947726 45.9 35.67274044288836 139.73814849947726 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67262464203344 139.73820362678262 9.013 35.67262684686138 139.73821056141156 9.013 35.67262684686138 139.73821056141156 45.9 35.67262464203344 139.73820362678262 45.9 35.67262464203344 139.73820362678262 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67262684686138 139.73821056141156 9.013 35.67262214346292 139.73821279839893 9.013 35.67262214346292 139.73821279839893 45.9 35.67262684686138 139.73821056141156 45.9 35.67262684686138 139.73821056141156 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67262214346292 139.73821279839893 45.9 35.67265154738781 139.7383055768113 45.9 35.672655746202764 139.73830357240476 45.9 35.67265944201955 139.73831523320527 45.9 35.67269636640345 139.73829765852278 45.9 35.67269528203692 139.7382942132758 45.9 35.672722583376306 139.7382812232705 45.9 35.67274101727756 139.73833938377538 45.9 35.67279308805071 139.73831459980454 45.9 35.67274044288836 139.73814849947726 45.9 35.67262464203344 139.73820362678262 45.9 35.67262684686138 139.73821056141156 45.9 35.67262214346292 139.73821279839893 45.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-89e7c292-17e6-4c79-92ab-170d542cdf26"/>
							<gml:surfaceMember xlink:href="#poly-fdbbd8f9-d2bc-40a5-a392-b70e6d39f59d"/>
							<gml:surfaceMember xlink:href="#poly-498d9713-52e0-44fa-9eed-d01f0e6aafa0"/>
							<gml:surfaceMember xlink:href="#poly-15592802-caad-427b-bcf6-781d74658e85"/>
							<gml:surfaceMember xlink:href="#poly-9f2a5da5-b789-45d2-9d9b-338efbd1650c"/>
							<gml:surfaceMember xlink:href="#poly-c22389c2-5673-4d28-871a-e6e4cf192bbb"/>
							<gml:surfaceMember xlink:href="#poly-dd79989c-d0ce-4c8d-9d91-2c2da0a2fa34"/>
							<gml:surfaceMember xlink:href="#poly-7f4de7d0-6134-48de-9950-bbe3f95c830b"/>
							<gml:surfaceMember xlink:href="#poly-df4171be-0af7-46aa-b843-15c15ea5c8de"/>
							<gml:surfaceMember xlink:href="#poly-70d22663-5432-451f-898e-43f69baa0713"/>
							<gml:surfaceMember xlink:href="#poly-f2b7696e-1778-4db9-984c-3dbe6963ce26"/>
							<gml:surfaceMember xlink:href="#poly-aab4e8c9-a189-42ca-8990-055fd34d92e5"/>
							<gml:surfaceMember xlink:href="#poly-2bac6c14-816f-4c85-9d61-720f5ac95e7f"/>
							<gml:surfaceMember xlink:href="#poly-057aca15-dbc0-4b1a-ba71-6bf51093b8bb"/>
							<gml:surfaceMember xlink:href="#poly-aa107875-411f-4f00-a2d5-b11e1a057aa0"/>
							<gml:surfaceMember xlink:href="#poly-954ba0f5-637d-41cc-aab0-5232ef8109d5"/>
							<gml:surfaceMember xlink:href="#poly-47e45ba0-834d-42fb-ad43-9cea121ba7d9"/>
							<gml:surfaceMember xlink:href="#poly-f1c43606-3ff8-4c6d-bcee-8cf56508623c"/>
							<gml:surfaceMember xlink:href="#poly-d0963e6b-50cb-4dde-9882-ffe419339ce5"/>
							<gml:surfaceMember xlink:href="#poly-09a33f45-fb4d-48d7-b219-f2816d510958"/>
							<gml:surfaceMember xlink:href="#poly-25fc5aab-e717-4b2e-a03a-6e7f47498475"/>
							<gml:surfaceMember xlink:href="#poly-1f552af9-d937-40a8-bfbb-446cee203a09"/>
							<gml:surfaceMember xlink:href="#poly-381b1aa9-3b14-4f59-9b51-f6709a54e51d"/>
							<gml:surfaceMember xlink:href="#poly-98f25dab-cb18-4500-971d-d275594dfbbd"/>
							<gml:surfaceMember xlink:href="#poly-2b9250c8-d23e-4ffa-95db-23e3aebf88b7"/>
							<gml:surfaceMember xlink:href="#poly-65642ac4-20bf-491b-a004-ef3922ae3801"/>
							<gml:surfaceMember xlink:href="#poly-11981998-67df-4790-8d3d-2ab7c27d71bb"/>
							<gml:surfaceMember xlink:href="#poly-2a4e03d7-6d75-4802-8ba7-fa999fedb632"/>
							<gml:surfaceMember xlink:href="#poly-d1f60c29-419f-4bc9-961a-0766fe6125b6"/>
							<gml:surfaceMember xlink:href="#poly-da8d6765-a430-4dd4-8dbc-02a0d2cbcd34"/>
							<gml:surfaceMember xlink:href="#poly-260815e8-8788-40a7-9133-0327f7ed8a76"/>
							<gml:surfaceMember xlink:href="#poly-408a2d13-cb6e-4a9b-97ba-70ff3b517cd5"/>
							<gml:surfaceMember xlink:href="#poly-3f4f718a-0644-4160-9cc0-184a8f1ccc85"/>
							<gml:surfaceMember xlink:href="#poly-99d2b7b0-ff2b-4f84-a4b6-edea734f6300"/>
							<gml:surfaceMember xlink:href="#poly-6c079a76-c5c0-40dc-8588-5040dd436a63"/>
							<gml:surfaceMember xlink:href="#poly-990d6fdd-6c60-45f1-b825-dfbb804e7a40"/>
							<gml:surfaceMember xlink:href="#poly-0d247c0d-5e92-4f93-9674-68fe847cdbfb"/>
							<gml:surfaceMember xlink:href="#poly-ffaf588d-2f2a-4d19-b82c-722806ba61da"/>
							<gml:surfaceMember xlink:href="#poly-f0d2b303-ba1e-40a3-9efd-ff2db4452a4d"/>
							<gml:surfaceMember xlink:href="#poly-99a9a6cc-fb9f-4d48-9ee0-6b70631653e2"/>
							<gml:surfaceMember xlink:href="#poly-09a6957c-fb0f-479b-adfa-4dabfb8e0177"/>
							<gml:surfaceMember xlink:href="#poly-3adb380e-2346-45f2-a544-55951334ab50"/>
							<gml:surfaceMember xlink:href="#poly-b584d015-fc52-480a-97dd-03f3ddc2c876"/>
							<gml:surfaceMember xlink:href="#poly-9a91658b-3e2e-445a-95bb-b4db54d7dfb9"/>
							<gml:surfaceMember xlink:href="#poly-88506822-138b-4370-b38c-79c41c41a268"/>
							<gml:surfaceMember xlink:href="#poly-fabed631-620d-48dd-9175-300f8f578feb"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b70a507b-9101-41c7-ba64-56f0070a2388_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e6de525-9276-4ee4-b98e-4ff62518533d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e6de525-9276-4ee4-b98e-4ff62518533d_0">
											<gml:posList>35.67267248165096 139.73824263070605 43.005 35.672665237212044 139.7382459201312 43.005 35.672665237212044 139.7382459201312 43.814 35.67267248165096 139.73824263070605 43.814 35.67267248165096 139.73824263070605 43.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48109ca4-24b3-4ad3-8ea7-37f245fe5ee0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48109ca4-24b3-4ad3-8ea7-37f245fe5ee0_0">
											<gml:posList>35.67267878857752 139.73828489847145 43.005 35.67267878857752 139.73828489847145 43.814 35.672665237212044 139.7382459201312 43.814 35.672665237212044 139.7382459201312 43.005 35.67267878857752 139.73828489847145 43.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6036d400-975d-4ab0-95b2-f68ede476d24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6036d400-975d-4ab0-95b2-f68ede476d24_0">
											<gml:posList>35.67267248165096 139.73824263070605 43.814 35.672665237212044 139.7382459201312 43.814 35.67267878857752 139.73828489847145 43.814 35.67268589748907 139.73828120048663 43.814 35.67268325044358 139.7382735704406 43.814 35.67267248165096 139.73824263070605 43.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8b2000f-8875-4efb-9d38-7c48f1cc3121">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8b2000f-8875-4efb-9d38-7c48f1cc3121_0">
											<gml:posList>35.67267248165096 139.73824263070605 43.814 35.67268325044358 139.7382735704406 43.814 35.67268194053282 139.7382698713907 43.005 35.67267248165096 139.73824263070605 43.005 35.67267248165096 139.73824263070605 43.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60eec812-0f4b-40bb-a128-eebf7424edf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60eec812-0f4b-40bb-a128-eebf7424edf4_0">
											<gml:posList>35.67268586143419 139.73828120052937 43.005 35.67268589748907 139.73828120048663 43.814 35.67267878857752 139.73828489847145 43.814 35.67267878857752 139.73828489847145 43.005 35.67268586143419 139.73828120052937 43.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7d932f0-8094-482a-a468-a952ad21d4e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7d932f0-8094-482a-a468-a952ad21d4e6_0">
											<gml:posList>35.67268325044358 139.7382735704406 43.814 35.67268589748907 139.73828120048663 43.814 35.67268586143419 139.73828120052937 43.005 35.67268194053282 139.7382698713907 43.005 35.67268325044358 139.7382735704406 43.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b47ddb19-70a0-43df-9857-937ac41ba363">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67268194053282 139.7382698713907 43.005 35.67268586143419 139.73828120052937 43.005 35.67267878857752 139.73828489847145 43.005 35.672665237212044 139.7382459201312 43.005 35.67267248165096 139.73824263070605 43.005 35.67268194053282 139.7382698713907 43.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b70a507b-9101-41c7-ba64-56f0070a2388_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f3b38a7-84ca-4aa9-bd2e-2e4e4f96a547">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67276823342708 139.73829839077774 45.814 35.67276424844599 139.73828581343818 45.814 35.67277497976484 139.73828070823788 45.814 35.67277896473774 139.73829327453228 45.814 35.67276823342708 139.73829839077774 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fef4e69-9e61-4238-b2a3-3cfc3282b606">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fef4e69-9e61-4238-b2a3-3cfc3282b606_0">
											<gml:posList>35.67276823342708 139.73829839077774 45.814 35.67276823342708 139.73829839077774 48.224 35.67276424844599 139.73828581343818 48.224 35.67276424844599 139.73828581343818 45.814 35.67276823342708 139.73829839077774 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01bcacd8-e4ad-4c61-b7ba-b88832ff9f85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01bcacd8-e4ad-4c61-b7ba-b88832ff9f85_0">
											<gml:posList>35.67276424844599 139.73828581343818 45.814 35.67276424844599 139.73828581343818 48.224 35.67277497976484 139.73828070823788 48.224 35.67277497976484 139.73828070823788 45.814 35.67276424844599 139.73828581343818 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-905d187f-d1b1-4c64-b765-1e82b706687d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-905d187f-d1b1-4c64-b765-1e82b706687d_0">
											<gml:posList>35.67277497976484 139.73828070823788 48.224 35.67276424844599 139.73828581343818 48.224 35.67276823342708 139.73829839077774 48.224 35.67277896473774 139.73829327453228 48.224 35.67277497976484 139.73828070823788 48.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b34c6765-8660-4cfd-bb40-f45985253e98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b34c6765-8660-4cfd-bb40-f45985253e98_0">
											<gml:posList>35.67277896473774 139.73829327453228 45.814 35.67277896473774 139.73829327453228 48.224 35.67276823342708 139.73829839077774 48.224 35.67276823342708 139.73829839077774 45.814 35.67277896473774 139.73829327453228 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a23dd05-ca4a-40a3-83ad-f28ba0580bb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a23dd05-ca4a-40a3-83ad-f28ba0580bb1_0">
											<gml:posList>35.67277497976484 139.73828070823788 45.814 35.67277497976484 139.73828070823788 48.224 35.67277896473774 139.73829327453228 48.224 35.67277896473774 139.73829327453228 45.814 35.67277497976484 139.73828070823788 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b70a507b-9101-41c7-ba64-56f0070a2388_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a5390ee-d548-465f-bf0c-fa0e5ca8d68f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67274920331933 139.7382271959987 45.814 35.67275986584392 139.7382605329962 45.814 35.67274180918102 139.738269203885 45.814 35.6727311466588 139.73823586689386 45.814 35.67274920331933 139.7382271959987 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c16432ae-ee26-4815-a701-d935d5cf6f25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c16432ae-ee26-4815-a701-d935d5cf6f25_0">
											<gml:posList>35.6727311466588 139.73823586689386 45.814 35.6727311466588 139.73823586689386 48.87 35.67274920331933 139.7382271959987 48.87 35.67274920331933 139.7382271959987 45.814 35.6727311466588 139.73823586689386 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-284f8a99-20fb-4812-80ae-adbcd497333c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-284f8a99-20fb-4812-80ae-adbcd497333c_0">
											<gml:posList>35.67274920331933 139.7382271959987 45.814 35.67274920331933 139.7382271959987 48.87 35.67275986584392 139.7382605329962 48.87 35.67275986584392 139.7382605329962 45.814 35.67274920331933 139.7382271959987 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22b577cb-eb5d-43e7-ad9c-3017210afb9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22b577cb-eb5d-43e7-ad9c-3017210afb9f_0">
											<gml:posList>35.67274920331933 139.7382271959987 48.87 35.6727311466588 139.73823586689386 48.87 35.67274180918102 139.738269203885 48.87 35.67275986584392 139.7382605329962 48.87 35.67274920331933 139.7382271959987 48.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-165bc550-d1ac-4b69-84c8-37419368ca58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-165bc550-d1ac-4b69-84c8-37419368ca58_0">
											<gml:posList>35.67274180918102 139.738269203885 45.814 35.67274180918102 139.738269203885 48.87 35.6727311466588 139.73823586689386 48.87 35.6727311466588 139.73823586689386 45.814 35.67274180918102 139.738269203885 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3402dab9-ff7f-4f64-84f5-704410717a42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3402dab9-ff7f-4f64-84f5-704410717a42_0">
											<gml:posList>35.67275986584392 139.7382605329962 45.814 35.67275986584392 139.7382605329962 48.87 35.67274180918102 139.738269203885 48.87 35.67274180918102 139.738269203885 45.814 35.67275986584392 139.7382605329962 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b70a507b-9101-41c7-ba64-56f0070a2388_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e77bb062-7376-4a42-9256-ab68272d463a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672672666045834 139.7382250222467 46.316 35.67267783366251 139.73823991794694 46.316 35.67267742819349 139.73824010621968 46.316 35.672672666045834 139.7382250222467 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4aa6d52f-73fd-4d4e-a5f6-33469fa9fa54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67268207073597 139.7382521193881 46.316 35.67269422184272 139.73828713367607 46.316 35.67272586616288 139.73827207280812 46.316 35.67272625472953 139.7382733095646 46.316 35.672693619571575 139.73828922219334 46.316 35.6726816472482 139.7382523187287 46.316 35.67268207073597 139.7382521193881 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c726741-f9d0-45e3-a648-757e03697a9b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67272586616288 139.73827207280812 45.814 35.67269422184272 139.73828713367607 45.814 35.67268207073597 139.7382521193881 45.814 35.67268316998223 139.73825157680218 45.814 35.67269454595293 139.7382866472424 45.814 35.67272802808613 139.73827033593113 45.814 35.672732943522334 139.7382854970616 45.814 35.672731709122466 139.73828610608714 45.814 35.67272738101704 139.73827276694658 45.814 35.67272625472953 139.7382733095646 45.814 35.67272586616288 139.73827207280812 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5155742-5b73-49b7-a84a-9c3757382241">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67274733563486 139.73819063401677 45.814 35.672674856353304 139.73822498650856 45.814 35.67267933839519 139.73823920918127 45.814 35.67267783366251 139.73823991794694 45.814 35.672672666045834 139.7382250222467 45.814 35.67267224132783 139.7382236640218 45.814 35.67274687408474 139.73818829268845 45.814 35.67278160938433 139.73829786677857 45.814 35.672781230947656 139.73829804397263 45.814 35.67274733563486 139.73819063401677 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc468c78-0ab5-4f04-a632-76d4ebaf89bd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67278160938433 139.73829786677857 46.316 35.67274687408474 139.73818829268845 46.316 35.672748333757234 139.73818759502126 46.316 35.672782933903996 139.73829723555284 46.316 35.67278160938433 139.73829786677857 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdf8e022-cd58-47e1-9618-0c539ba5bf1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdf8e022-cd58-47e1-9618-0c539ba5bf1d_0">
											<gml:posList>35.67274687408474 139.73818829268845 46.316 35.67274687408474 139.73818829268845 45.814 35.67267224132783 139.7382236640218 45.814 35.67267224132783 139.7382236640218 47.464 35.672748333757234 139.73818759502126 47.464 35.672748333757234 139.73818759502126 46.316 35.67274687408474 139.73818829268845 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b949721-02c6-4ec8-9fdb-0288e0e731b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b949721-02c6-4ec8-9fdb-0288e0e731b5_0">
											<gml:posList>35.67274733563486 139.73819063401677 45.814 35.67274733563486 139.73819063401677 47.464 35.672674856353304 139.73822498650856 47.464 35.672674856353304 139.73822498650856 45.814 35.67274733563486 139.73819063401677 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59e9d58b-a21a-4e83-99c7-7f9e0d64b899">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59e9d58b-a21a-4e83-99c7-7f9e0d64b899_0">
											<gml:posList>35.672672666045834 139.7382250222467 46.316 35.67267742819349 139.73824010621968 46.316 35.67267742819349 139.73824010621968 47.464 35.67267224132783 139.7382236640218 47.464 35.67267224132783 139.7382236640218 45.814 35.672672666045834 139.7382250222467 45.814 35.672672666045834 139.7382250222467 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17e5c941-f79e-4900-a578-6e72b970f1e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17e5c941-f79e-4900-a578-6e72b970f1e4_0">
											<gml:posList>35.672674856353304 139.73822498650856 45.814 35.672674856353304 139.73822498650856 47.464 35.67267933839519 139.73823920918127 47.464 35.67267933839519 139.73823920918127 45.814 35.672674856353304 139.73822498650856 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f65ca98-e8eb-4f92-ac2e-65fe7988cd96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f65ca98-e8eb-4f92-ac2e-65fe7988cd96_0">
											<gml:posList>35.672672666045834 139.7382250222467 45.814 35.67267783366251 139.73823991794694 45.814 35.67267783366251 139.73823991794694 46.316 35.672672666045834 139.7382250222467 46.316 35.672672666045834 139.7382250222467 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-890776f0-807f-4912-a975-e6f920eb3161">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-890776f0-807f-4912-a975-e6f920eb3161_0">
											<gml:posList>35.67267933839519 139.73823920918127 45.814 35.67267933839519 139.73823920918127 47.464 35.67267742819349 139.73824010621968 47.464 35.67267742819349 139.73824010621968 46.316 35.67267783366251 139.73823991794694 46.316 35.67267783366251 139.73823991794694 45.814 35.67267933839519 139.73823920918127 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d00cd33-ccb6-400c-91ff-0c00d61c0657">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d00cd33-ccb6-400c-91ff-0c00d61c0657_0">
											<gml:posList>35.672748333757234 139.73818759502126 46.316 35.672748333757234 139.73818759502126 47.464 35.672782933903996 139.73829723555284 47.464 35.672782933903996 139.73829723555284 46.316 35.672748333757234 139.73818759502126 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f04a6e23-683c-407c-8a8d-386ad7bc266d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f04a6e23-683c-407c-8a8d-386ad7bc266d_0">
											<gml:posList>35.67267933839519 139.73823920918127 47.464 35.672674856353304 139.73822498650856 47.464 35.67274733563486 139.73819063401677 47.464 35.672781230947656 139.73829804397263 47.464 35.672782933903996 139.73829723555284 47.464 35.672748333757234 139.73818759502126 47.464 35.67267224132783 139.7382236640218 47.464 35.67267742819349 139.73824010621968 47.464 35.67267933839519 139.73823920918127 47.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2f6ccbc-6879-4574-a8a4-2e9edb09389a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2f6ccbc-6879-4574-a8a4-2e9edb09389a_0">
											<gml:posList>35.67278160938433 139.73829786677857 45.814 35.67274687408474 139.73818829268845 45.814 35.67274687408474 139.73818829268845 46.316 35.67278160938433 139.73829786677857 46.316 35.67278160938433 139.73829786677857 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5281ac5-13f9-453d-96c2-039bd18e8e1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5281ac5-13f9-453d-96c2-039bd18e8e1d_0">
											<gml:posList>35.672781230947656 139.73829804397263 45.814 35.672781230947656 139.73829804397263 47.464 35.67274733563486 139.73819063401677 47.464 35.67274733563486 139.73819063401677 45.814 35.672781230947656 139.73829804397263 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab8df028-27fc-4275-b012-48ca301fa70e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab8df028-27fc-4275-b012-48ca301fa70e_0">
											<gml:posList>35.67268207073597 139.7382521193881 46.316 35.6726816472482 139.7382523187287 46.316 35.6726816472482 139.7382523187287 47.464 35.67268316998223 139.73825157680218 47.464 35.67268316998223 139.73825157680218 45.814 35.67268207073597 139.7382521193881 45.814 35.67268207073597 139.7382521193881 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31d06c38-d18c-4a11-b7a4-b1eb175030f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31d06c38-d18c-4a11-b7a4-b1eb175030f8_0">
											<gml:posList>35.67268316998223 139.73825157680218 45.814 35.67268316998223 139.73825157680218 47.464 35.67269454595293 139.7382866472424 47.464 35.67269454595293 139.7382866472424 45.814 35.67268316998223 139.73825157680218 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-118d6143-5586-4841-aeb1-7bcb8f9b31d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-118d6143-5586-4841-aeb1-7bcb8f9b31d0_0">
											<gml:posList>35.67269422184272 139.73828713367607 46.316 35.67268207073597 139.7382521193881 46.316 35.67268207073597 139.7382521193881 45.814 35.67269422184272 139.73828713367607 45.814 35.67269422184272 139.73828713367607 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c9a2aa4-92fe-4667-b7c6-43f3d4f4aeba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c9a2aa4-92fe-4667-b7c6-43f3d4f4aeba_0">
											<gml:posList>35.672732943522334 139.7382854970616 47.464 35.67272802808613 139.73827033593113 47.464 35.67269454595293 139.7382866472424 47.464 35.67268316998223 139.73825157680218 47.464 35.6726816472482 139.7382523187287 47.464 35.672693619571575 139.73828922219334 47.464 35.67272738101704 139.73827276694658 47.464 35.672731709122466 139.73828610608714 47.464 35.672732943522334 139.7382854970616 47.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eef85a08-97ac-43f5-863d-281b94abf1f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eef85a08-97ac-43f5-863d-281b94abf1f0_0">
											<gml:posList>35.672693619571575 139.73828922219334 46.316 35.672693619571575 139.73828922219334 47.464 35.6726816472482 139.7382523187287 47.464 35.6726816472482 139.7382523187287 46.316 35.672693619571575 139.73828922219334 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-711f7f64-2ee0-41aa-a1fb-8f973c403eea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-711f7f64-2ee0-41aa-a1fb-8f973c403eea_0">
											<gml:posList>35.67272625472953 139.7382733095646 45.814 35.67272625472953 139.7382733095646 46.316 35.67272586616288 139.73827207280812 46.316 35.67272586616288 139.73827207280812 45.814 35.67272625472953 139.7382733095646 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fdac477-f717-4780-b876-60184d617deb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fdac477-f717-4780-b876-60184d617deb_0">
											<gml:posList>35.67272802808613 139.73827033593113 47.464 35.672732943522334 139.7382854970616 47.464 35.672732943522334 139.7382854970616 45.814 35.67272802808613 139.73827033593113 45.814 35.67272802808613 139.73827033593113 47.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33feed37-b521-4a8b-89c1-7d7851e2e202">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33feed37-b521-4a8b-89c1-7d7851e2e202_0">
											<gml:posList>35.67269454595293 139.7382866472424 47.464 35.67272802808613 139.73827033593113 47.464 35.67272802808613 139.73827033593113 45.814 35.67269454595293 139.7382866472424 45.814 35.67269454595293 139.7382866472424 47.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f50419ae-2d8c-4303-8a5d-99e52861ac44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f50419ae-2d8c-4303-8a5d-99e52861ac44_0">
											<gml:posList>35.672731709122466 139.73828610608714 45.814 35.672731709122466 139.73828610608714 47.464 35.67272738101704 139.73827276694658 47.464 35.67272738101704 139.73827276694658 45.814 35.672731709122466 139.73828610608714 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91f750e9-ee9b-47ab-8b61-128c0632c3a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91f750e9-ee9b-47ab-8b61-128c0632c3a7_0">
											<gml:posList>35.67272586616288 139.73827207280812 46.316 35.67269422184272 139.73828713367607 46.316 35.67269422184272 139.73828713367607 45.814 35.67272586616288 139.73827207280812 45.814 35.67272586616288 139.73827207280812 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53747df9-9f85-4872-9d67-38858ac334e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53747df9-9f85-4872-9d67-38858ac334e9_0">
											<gml:posList>35.67272738101704 139.73827276694658 45.814 35.67272738101704 139.73827276694658 47.464 35.672693619571575 139.73828922219334 47.464 35.672693619571575 139.73828922219334 46.316 35.67272625472953 139.7382733095646 46.316 35.67272625472953 139.7382733095646 45.814 35.67272738101704 139.73827276694658 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa92df0d-7248-4211-9203-9a1068e11e10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa92df0d-7248-4211-9203-9a1068e11e10_0">
											<gml:posList>35.672732943522334 139.7382854970616 45.814 35.672732943522334 139.7382854970616 47.464 35.672731709122466 139.73828610608714 47.464 35.672731709122466 139.73828610608714 45.814 35.672732943522334 139.7382854970616 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-927048cf-2d8f-4243-984d-d4da5931d580">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-927048cf-2d8f-4243-984d-d4da5931d580_0">
											<gml:posList>35.67278160938433 139.73829786677857 46.316 35.672782933903996 139.73829723555284 46.316 35.672782933903996 139.73829723555284 47.464 35.672781230947656 139.73829804397263 47.464 35.672781230947656 139.73829804397263 45.814 35.67278160938433 139.73829786677857 45.814 35.67278160938433 139.73829786677857 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-89e7c292-17e6-4c79-92ab-170d542cdf26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89e7c292-17e6-4c79-92ab-170d542cdf26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89e7c292-17e6-4c79-92ab-170d542cdf26">
											<gml:posList>35.672740442888326 139.73814849947726 9.013 35.67279308805069 139.73831459980454 9.013 35.67274101727757 139.73833938377538 9.013 35.672722583376284 139.7382812232705 9.013 35.672695282036905 139.7382942132758 9.013 35.67269636640343 139.73829765852278 9.013 35.67265944201953 139.73831523320527 9.013 35.672655746202764 139.73830357240473 9.013 35.67265154738781 139.7383055768113 9.013 35.67262214346294 139.73821279839893 9.013 35.672626846861355 139.73821056141156 9.013 35.672624642033426 139.73820362678262 9.013 35.672740442888326 139.73814849947726 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fdbbd8f9-d2bc-40a5-a392-b70e6d39f59d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdbbd8f9-d2bc-40a5-a392-b70e6d39f59d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdbbd8f9-d2bc-40a5-a392-b70e6d39f59d">
											<gml:posList>35.672626846861355 139.73821056141156 43.263 35.67262214346294 139.73821279839893 43.263 35.672625579164546 139.73821466119267 43.263 35.67263029157672 139.73821242419464 43.263 35.672626846861355 139.73821056141156 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-498d9713-52e0-44fa-9eed-d01f0e6aafa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-498d9713-52e0-44fa-9eed-d01f0e6aafa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-498d9713-52e0-44fa-9eed-d01f0e6aafa0">
											<gml:posList>35.672626846861355 139.73821056141156 43.263 35.67263029157672 139.73821242419464 43.263 35.672628077735176 139.738205489576 43.263 35.672624642033426 139.73820362678262 43.263 35.672626846861355 139.73821056141156 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15592802-caad-427b-bcf6-781d74658e85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15592802-caad-427b-bcf6-781d74658e85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15592802-caad-427b-bcf6-781d74658e85">
											<gml:posList>35.67265154738781 139.7383055768113 43.263 35.67265306738465 139.73830136626557 43.263 35.672625579164546 139.73821466119267 43.263 35.67262214346294 139.73821279839893 43.263 35.67265154738781 139.7383055768113 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f2a5da5-b789-45d2-9d9b-338efbd1650c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f2a5da5-b789-45d2-9d9b-338efbd1650c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f2a5da5-b789-45d2-9d9b-338efbd1650c">
											<gml:posList>35.672628077735176 139.738205489576 43.263 35.67265575748433 139.73819230026407 43.263 35.672654799638536 139.73818927463986 43.263 35.672624642033426 139.73820362678262 43.263 35.672628077735176 139.738205489576 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c22389c2-5673-4d28-871a-e6e4cf192bbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c22389c2-5673-4d28-871a-e6e4cf192bbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c22389c2-5673-4d28-871a-e6e4cf192bbb">
											<gml:posList>35.672655746202764 139.73830357240473 43.263 35.672657266199536 139.7382993618587 43.263 35.67265306738465 139.73830136626557 43.263 35.67265154738781 139.7383055768113 43.263 35.672655746202764 139.73830357240473 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd79989c-d0ce-4c8d-9d91-2c2da0a2fa34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd79989c-d0ce-4c8d-9d91-2c2da0a2fa34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd79989c-d0ce-4c8d-9d91-2c2da0a2fa34">
											<gml:posList>35.672655746202764 139.73830357240473 43.263 35.67265944201953 139.73831523320527 43.263 35.6726609530117 139.73831103371654 43.263 35.672657266199536 139.7382993618587 43.263 35.672655746202764 139.73830357240473 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f4de7d0-6134-48de-9950-bbe3f95c830b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f4de7d0-6134-48de-9950-bbe3f95c830b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f4de7d0-6134-48de-9950-bbe3f95c830b">
											<gml:posList>35.67266341119056 139.7382164500381 43.005 35.67265575748433 139.73819230026407 43.005 35.672628077735176 139.738205489576 43.005 35.67263029157672 139.73821242419464 43.005 35.672625579164546 139.73821466119267 43.005 35.67265306738465 139.73830136626557 43.005 35.672657266199536 139.7382993618587 43.005 35.6726609530117 139.73831103371654 43.005 35.672691191622164 139.73829651581295 43.005 35.67266341119056 139.7382164500381 43.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df4171be-0af7-46aa-b843-15c15ea5c8de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df4171be-0af7-46aa-b843-15c15ea5c8de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df4171be-0af7-46aa-b843-15c15ea5c8de">
											<gml:posList>35.6726609530117 139.73831103371654 43.263 35.67265944201953 139.73831523320527 43.263 35.672692266695904 139.73829960758033 43.263 35.672691191622164 139.73829651581295 43.263 35.6726609530117 139.73831103371654 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70d22663-5432-451f-898e-43f69baa0713">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70d22663-5432-451f-898e-43f69baa0713">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70d22663-5432-451f-898e-43f69baa0713">
											<gml:posList>35.67266341119056 139.7382164500381 46.316 35.672692266695904 139.73829960758033 46.316 35.67269422184272 139.73828713367607 46.316 35.672671057939176 139.73822038459298 46.316 35.67266341119056 139.7382164500381 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2b7696e-1778-4db9-984c-3dbe6963ce26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2b7696e-1778-4db9-984c-3dbe6963ce26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2b7696e-1778-4db9-984c-3dbe6963ce26">
											<gml:posList>35.672695282036905 139.7382942132758 46.316 35.67269422184272 139.73828713367607 46.316 35.672692266695904 139.73829960758033 46.316 35.67269636640343 139.73829765852278 46.316 35.672695282036905 139.7382942132758 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aab4e8c9-a189-42ca-8990-055fd34d92e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aab4e8c9-a189-42ca-8990-055fd34d92e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aab4e8c9-a189-42ca-8990-055fd34d92e5">
											<gml:posList>35.67274905444946 139.73817567490008 46.214 35.672740442888326 139.73814849947726 43.329 35.672654799638536 139.73818927463986 43.329 35.67266341119056 139.7382164500381 46.214 35.67274905444946 139.73817567490008 46.214</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2bac6c14-816f-4c85-9d61-720f5ac95e7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bac6c14-816f-4c85-9d61-720f5ac95e7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bac6c14-816f-4c85-9d61-720f5ac95e7f">
											<gml:posList>35.67266341119056 139.7382164500381 46.316 35.672671057939176 139.73822038459298 46.316 35.67274577166148 139.7381848143225 46.316 35.67274905444946 139.73817567490008 46.316 35.67266341119056 139.7382164500381 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-057aca15-dbc0-4b1a-ba71-6bf51093b8bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-057aca15-dbc0-4b1a-ba71-6bf51093b8bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-057aca15-dbc0-4b1a-ba71-6bf51093b8bb">
											<gml:posList>35.672722583376284 139.7382812232705 46.316 35.67272586616288 139.73827207280812 46.316 35.67269422184272 139.73828713367607 46.316 35.672695282036905 139.7382942132758 46.316 35.672722583376284 139.7382812232705 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa107875-411f-4f00-a2d5-b11e1a057aa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa107875-411f-4f00-a2d5-b11e1a057aa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa107875-411f-4f00-a2d5-b11e1a057aa0">
											<gml:posList>35.67272586616288 139.73827207280812 45.814 35.672744300068594 139.73833023331326 45.814 35.67278563051491 139.73831056559112 45.814 35.67274577166148 139.7381848143225 45.814 35.672671057939176 139.73822038459298 45.814 35.67269422184272 139.73828713367607 45.814 35.67272586616288 139.73827207280812 45.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-954ba0f5-637d-41cc-aab0-5232ef8109d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-954ba0f5-637d-41cc-aab0-5232ef8109d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-954ba0f5-637d-41cc-aab0-5232ef8109d5">
											<gml:posList>35.672722583376284 139.7382812232705 46.316 35.67274101727757 139.73833938377538 46.316 35.672744300068594 139.73833023331326 46.316 35.67272586616288 139.73827207280812 46.316 35.672722583376284 139.7382812232705 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47e45ba0-834d-42fb-ad43-9cea121ba7d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47e45ba0-834d-42fb-ad43-9cea121ba7d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47e45ba0-834d-42fb-ad43-9cea121ba7d9">
											<gml:posList>35.67279308805069 139.73831459980454 46.316 35.67278563051491 139.73831056559112 46.316 35.672744300068594 139.73833023331326 46.316 35.67274101727757 139.73833938377538 46.316 35.67279308805069 139.73831459980454 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1c43606-3ff8-4c6d-bcee-8cf56508623c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1c43606-3ff8-4c6d-bcee-8cf56508623c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1c43606-3ff8-4c6d-bcee-8cf56508623c">
											<gml:posList>35.67274905444946 139.73817567490008 46.316 35.67274577166148 139.7381848143225 46.316 35.67278563051491 139.73831056559112 46.316 35.67279308805069 139.73831459980454 46.316 35.67274905444946 139.73817567490008 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0963e6b-50cb-4dde-9882-ffe419339ce5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0963e6b-50cb-4dde-9882-ffe419339ce5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0963e6b-50cb-4dde-9882-ffe419339ce5">
											<gml:posList>35.672744300068594 139.73833023331326 46.316 35.672744300068594 139.73833023331326 45.814 35.67272586616288 139.73827207280812 45.814 35.67272586616288 139.73827207280812 46.316 35.672744300068594 139.73833023331326 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09a33f45-fb4d-48d7-b219-f2816d510958">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09a33f45-fb4d-48d7-b219-f2816d510958">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09a33f45-fb4d-48d7-b219-f2816d510958">
											<gml:posList>35.672626846861355 139.73821056141156 9.013 35.67262214346294 139.73821279839893 9.013 35.67262214346294 139.73821279839893 43.263 35.672626846861355 139.73821056141156 43.263 35.672626846861355 139.73821056141156 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25fc5aab-e717-4b2e-a03a-6e7f47498475">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25fc5aab-e717-4b2e-a03a-6e7f47498475">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25fc5aab-e717-4b2e-a03a-6e7f47498475">
											<gml:posList>35.672624642033426 139.73820362678262 9.013 35.672626846861355 139.73821056141156 9.013 35.672626846861355 139.73821056141156 43.263 35.672624642033426 139.73820362678262 43.263 35.672624642033426 139.73820362678262 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f552af9-d937-40a8-bfbb-446cee203a09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f552af9-d937-40a8-bfbb-446cee203a09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f552af9-d937-40a8-bfbb-446cee203a09">
											<gml:posList>35.672625579164546 139.73821466119267 43.263 35.672625579164546 139.73821466119267 43.005 35.67263029157672 139.73821242419464 43.005 35.67263029157672 139.73821242419464 43.263 35.672625579164546 139.73821466119267 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-381b1aa9-3b14-4f59-9b51-f6709a54e51d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-381b1aa9-3b14-4f59-9b51-f6709a54e51d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-381b1aa9-3b14-4f59-9b51-f6709a54e51d">
											<gml:posList>35.67263029157672 139.73821242419464 43.263 35.67263029157672 139.73821242419464 43.005 35.672628077735176 139.738205489576 43.005 35.672628077735176 139.738205489576 43.263 35.67263029157672 139.73821242419464 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98f25dab-cb18-4500-971d-d275594dfbbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98f25dab-cb18-4500-971d-d275594dfbbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98f25dab-cb18-4500-971d-d275594dfbbd">
											<gml:posList>35.67262214346294 139.73821279839893 9.013 35.67265154738781 139.7383055768113 9.013 35.67265154738781 139.7383055768113 43.263 35.67262214346294 139.73821279839893 43.263 35.67262214346294 139.73821279839893 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b9250c8-d23e-4ffa-95db-23e3aebf88b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b9250c8-d23e-4ffa-95db-23e3aebf88b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b9250c8-d23e-4ffa-95db-23e3aebf88b7">
											<gml:posList>35.67265306738465 139.73830136626557 43.263 35.67265306738465 139.73830136626557 43.005 35.672625579164546 139.73821466119267 43.005 35.672625579164546 139.73821466119267 43.263 35.67265306738465 139.73830136626557 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65642ac4-20bf-491b-a004-ef3922ae3801">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65642ac4-20bf-491b-a004-ef3922ae3801">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65642ac4-20bf-491b-a004-ef3922ae3801">
											<gml:posList>35.672628077735176 139.738205489576 43.263 35.672628077735176 139.738205489576 43.005 35.67265575748433 139.73819230026407 43.005 35.67265575748433 139.73819230026407 43.263 35.672628077735176 139.738205489576 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11981998-67df-4790-8d3d-2ab7c27d71bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11981998-67df-4790-8d3d-2ab7c27d71bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11981998-67df-4790-8d3d-2ab7c27d71bb">
											<gml:posList>35.67265154738781 139.7383055768113 9.013 35.672655746202764 139.73830357240473 9.013 35.672655746202764 139.73830357240473 43.263 35.67265154738781 139.7383055768113 43.263 35.67265154738781 139.7383055768113 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a4e03d7-6d75-4802-8ba7-fa999fedb632">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a4e03d7-6d75-4802-8ba7-fa999fedb632">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a4e03d7-6d75-4802-8ba7-fa999fedb632">
											<gml:posList>35.672657266199536 139.7382993618587 43.263 35.672657266199536 139.7382993618587 43.005 35.67265306738465 139.73830136626557 43.005 35.67265306738465 139.73830136626557 43.263 35.672657266199536 139.7382993618587 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1f60c29-419f-4bc9-961a-0766fe6125b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1f60c29-419f-4bc9-961a-0766fe6125b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1f60c29-419f-4bc9-961a-0766fe6125b6">
											<gml:posList>35.672655746202764 139.73830357240473 9.013 35.67265944201953 139.73831523320527 9.013 35.67265944201953 139.73831523320527 43.263 35.672655746202764 139.73830357240473 43.263 35.672655746202764 139.73830357240473 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da8d6765-a430-4dd4-8dbc-02a0d2cbcd34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da8d6765-a430-4dd4-8dbc-02a0d2cbcd34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da8d6765-a430-4dd4-8dbc-02a0d2cbcd34">
											<gml:posList>35.6726609530117 139.73831103371654 43.263 35.6726609530117 139.73831103371654 43.005 35.672657266199536 139.7382993618587 43.005 35.672657266199536 139.7382993618587 43.263 35.6726609530117 139.73831103371654 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-260815e8-8788-40a7-9133-0327f7ed8a76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-260815e8-8788-40a7-9133-0327f7ed8a76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-260815e8-8788-40a7-9133-0327f7ed8a76">
											<gml:posList>35.672654799638536 139.73818927463986 43.329 35.672654799638536 139.73818927463986 43.263 35.67265575748433 139.73819230026407 43.263 35.67265575748433 139.73819230026407 43.005 35.67266341119056 139.7382164500381 43.005 35.67266341119056 139.7382164500381 46.214 35.672654799638536 139.73818927463986 43.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-408a2d13-cb6e-4a9b-97ba-70ff3b517cd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-408a2d13-cb6e-4a9b-97ba-70ff3b517cd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-408a2d13-cb6e-4a9b-97ba-70ff3b517cd5">
											<gml:posList>35.672691191622164 139.73829651581295 43.263 35.672691191622164 139.73829651581295 43.005 35.6726609530117 139.73831103371654 43.005 35.6726609530117 139.73831103371654 43.263 35.672691191622164 139.73829651581295 43.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f4f718a-0644-4160-9cc0-184a8f1ccc85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f4f718a-0644-4160-9cc0-184a8f1ccc85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f4f718a-0644-4160-9cc0-184a8f1ccc85">
											<gml:posList>35.67266341119056 139.7382164500381 43.005 35.672691191622164 139.73829651581295 43.005 35.672691191622164 139.73829651581295 43.263 35.672692266695904 139.73829960758033 43.263 35.672692266695904 139.73829960758033 46.316 35.67266341119056 139.7382164500381 46.316 35.67266341119056 139.7382164500381 46.214 35.67266341119056 139.7382164500381 43.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99d2b7b0-ff2b-4f84-a4b6-edea734f6300">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99d2b7b0-ff2b-4f84-a4b6-edea734f6300">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99d2b7b0-ff2b-4f84-a4b6-edea734f6300">
											<gml:posList>35.67269636640343 139.73829765852278 9.013 35.67269636640343 139.73829765852278 46.316 35.672692266695904 139.73829960758033 46.316 35.672692266695904 139.73829960758033 43.263 35.67265944201953 139.73831523320527 43.263 35.67265944201953 139.73831523320527 9.013 35.67269636640343 139.73829765852278 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c079a76-c5c0-40dc-8588-5040dd436a63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c079a76-c5c0-40dc-8588-5040dd436a63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c079a76-c5c0-40dc-8588-5040dd436a63">
											<gml:posList>35.672624642033426 139.73820362678262 9.013 35.672624642033426 139.73820362678262 43.263 35.672654799638536 139.73818927463986 43.263 35.672654799638536 139.73818927463986 43.329 35.672740442888326 139.73814849947726 43.329 35.672740442888326 139.73814849947726 9.013 35.672624642033426 139.73820362678262 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-990d6fdd-6c60-45f1-b825-dfbb804e7a40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-990d6fdd-6c60-45f1-b825-dfbb804e7a40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-990d6fdd-6c60-45f1-b825-dfbb804e7a40">
											<gml:posList>35.67269422184272 139.73828713367607 46.316 35.67269422184272 139.73828713367607 45.814 35.672671057939176 139.73822038459298 45.814 35.672671057939176 139.73822038459298 46.316 35.67269422184272 139.73828713367607 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d247c0d-5e92-4f93-9674-68fe847cdbfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d247c0d-5e92-4f93-9674-68fe847cdbfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d247c0d-5e92-4f93-9674-68fe847cdbfb">
											<gml:posList>35.67269636640343 139.73829765852278 9.013 35.672695282036905 139.7382942132758 9.013 35.672695282036905 139.7382942132758 46.316 35.67269636640343 139.73829765852278 46.316 35.67269636640343 139.73829765852278 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffaf588d-2f2a-4d19-b82c-722806ba61da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffaf588d-2f2a-4d19-b82c-722806ba61da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffaf588d-2f2a-4d19-b82c-722806ba61da">
											<gml:posList>35.67274905444946 139.73817567490008 46.316 35.67274905444946 139.73817567490008 46.214 35.67266341119056 139.7382164500381 46.214 35.67266341119056 139.7382164500381 46.316 35.67274905444946 139.73817567490008 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0d2b303-ba1e-40a3-9efd-ff2db4452a4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0d2b303-ba1e-40a3-9efd-ff2db4452a4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0d2b303-ba1e-40a3-9efd-ff2db4452a4d">
											<gml:posList>35.672671057939176 139.73822038459298 46.316 35.672671057939176 139.73822038459298 45.814 35.67274577166148 139.7381848143225 45.814 35.67274577166148 139.7381848143225 46.316 35.672671057939176 139.73822038459298 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99a9a6cc-fb9f-4d48-9ee0-6b70631653e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99a9a6cc-fb9f-4d48-9ee0-6b70631653e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99a9a6cc-fb9f-4d48-9ee0-6b70631653e2">
											<gml:posList>35.672695282036905 139.7382942132758 9.013 35.672722583376284 139.7382812232705 9.013 35.672722583376284 139.7382812232705 46.316 35.672695282036905 139.7382942132758 46.316 35.672695282036905 139.7382942132758 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09a6957c-fb0f-479b-adfa-4dabfb8e0177">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09a6957c-fb0f-479b-adfa-4dabfb8e0177">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09a6957c-fb0f-479b-adfa-4dabfb8e0177">
											<gml:posList>35.67272586616288 139.73827207280812 46.316 35.67272586616288 139.73827207280812 45.814 35.67269422184272 139.73828713367607 45.814 35.67269422184272 139.73828713367607 46.316 35.67272586616288 139.73827207280812 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3adb380e-2346-45f2-a544-55951334ab50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3adb380e-2346-45f2-a544-55951334ab50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3adb380e-2346-45f2-a544-55951334ab50">
											<gml:posList>35.672722583376284 139.7382812232705 9.013 35.67274101727757 139.73833938377538 9.013 35.67274101727757 139.73833938377538 46.316 35.672722583376284 139.7382812232705 46.316 35.672722583376284 139.7382812232705 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b584d015-fc52-480a-97dd-03f3ddc2c876">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b584d015-fc52-480a-97dd-03f3ddc2c876">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b584d015-fc52-480a-97dd-03f3ddc2c876">
											<gml:posList>35.67278563051491 139.73831056559112 46.316 35.67278563051491 139.73831056559112 45.814 35.672744300068594 139.73833023331326 45.814 35.672744300068594 139.73833023331326 46.316 35.67278563051491 139.73831056559112 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a91658b-3e2e-445a-95bb-b4db54d7dfb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a91658b-3e2e-445a-95bb-b4db54d7dfb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a91658b-3e2e-445a-95bb-b4db54d7dfb9">
											<gml:posList>35.67274577166148 139.7381848143225 46.316 35.67274577166148 139.7381848143225 45.814 35.67278563051491 139.73831056559112 45.814 35.67278563051491 139.73831056559112 46.316 35.67274577166148 139.7381848143225 46.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88506822-138b-4370-b38c-79c41c41a268">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88506822-138b-4370-b38c-79c41c41a268">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88506822-138b-4370-b38c-79c41c41a268">
											<gml:posList>35.67274905444946 139.73817567490008 46.214 35.67274905444946 139.73817567490008 46.316 35.67279308805069 139.73831459980454 46.316 35.67279308805069 139.73831459980454 9.013 35.672740442888326 139.73814849947726 9.013 35.672740442888326 139.73814849947726 43.329 35.67274905444946 139.73817567490008 46.214</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fabed631-620d-48dd-9175-300f8f578feb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fabed631-620d-48dd-9175-300f8f578feb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fabed631-620d-48dd-9175-300f8f578feb">
											<gml:posList>35.67274101727757 139.73833938377538 9.013 35.67279308805069 139.73831459980454 9.013 35.67279308805069 139.73831459980454 46.316 35.67274101727757 139.73833938377538 46.316 35.67274101727757 139.73833938377538 9.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8941</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">309.2927</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>