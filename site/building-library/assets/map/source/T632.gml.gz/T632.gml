<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b7669b73-035b-41ad-9f5c-cf99c8621882">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">25.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66836599924487 139.7392275056297 0 35.66832701848484 139.73928985068594 0 35.66838799602814 139.7393471078297 0 35.668441425692514 139.73926150503874 0 35.66846641915377 139.7392825072919 0 35.66849050980965 139.73924398372827 0 35.66839947641672 139.73915853938445 0 35.66835986542258 139.73922176891844 0 35.66836599924487 139.7392275056297 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66836599924487 139.7392275056297 11.62 35.66835986542258 139.73922176891844 11.62 35.66839947641672 139.73915853938445 11.62 35.66849050980965 139.73924398372827 11.62 35.66846641915377 139.7392825072919 11.62 35.668441425692514 139.73926150503874 11.62 35.66838799602814 139.7393471078297 11.62 35.66832701848484 139.73928985068594 11.62 35.66836599924487 139.7392275056297 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66836599924487 139.7392275056297 11.62 35.66832701848484 139.73928985068594 11.62 35.66832701848484 139.73928985068594 37.3 35.66836599924487 139.7392275056297 37.3 35.66836599924487 139.7392275056297 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66832701848484 139.73928985068594 11.62 35.66838799602814 139.7393471078297 11.62 35.66838799602814 139.7393471078297 37.3 35.66832701848484 139.73928985068594 37.3 35.66832701848484 139.73928985068594 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838799602814 139.7393471078297 11.62 35.668441425692514 139.73926150503874 11.62 35.668441425692514 139.73926150503874 37.3 35.66838799602814 139.7393471078297 37.3 35.66838799602814 139.7393471078297 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668441425692514 139.73926150503874 11.62 35.66846641915377 139.7392825072919 11.62 35.66846641915377 139.7392825072919 37.3 35.668441425692514 139.73926150503874 37.3 35.668441425692514 139.73926150503874 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66846641915377 139.7392825072919 11.62 35.66849050980965 139.73924398372827 11.62 35.66849050980965 139.73924398372827 37.3 35.66846641915377 139.7392825072919 37.3 35.66846641915377 139.7392825072919 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66849050980965 139.73924398372827 11.62 35.66839947641672 139.73915853938445 11.62 35.66839947641672 139.73915853938445 37.3 35.66849050980965 139.73924398372827 37.3 35.66849050980965 139.73924398372827 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66839947641672 139.73915853938445 11.62 35.66835986542258 139.73922176891844 11.62 35.66835986542258 139.73922176891844 37.3 35.66839947641672 139.73915853938445 37.3 35.66839947641672 139.73915853938445 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66835986542258 139.73922176891844 11.62 35.66836599924487 139.7392275056297 11.62 35.66836599924487 139.7392275056297 37.3 35.66835986542258 139.73922176891844 37.3 35.66835986542258 139.73922176891844 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66836599924487 139.7392275056297 37.3 35.66832701848484 139.73928985068594 37.3 35.66838799602814 139.7393471078297 37.3 35.668441425692514 139.73926150503874 37.3 35.66846641915377 139.7392825072919 37.3 35.66849050980965 139.73924398372827 37.3 35.66839947641672 139.73915853938445 37.3 35.66835986542258 139.73922176891844 37.3 35.66836599924487 139.7392275056297 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-84ced6bb-f44b-4205-8c5c-2903a18424df"/>
							<gml:surfaceMember xlink:href="#poly-87b8f53b-62d1-4e5d-bdb1-95368448b026"/>
							<gml:surfaceMember xlink:href="#poly-62addc8c-97a0-4bf3-b505-36b097284564"/>
							<gml:surfaceMember xlink:href="#poly-bdf93636-1f2f-4a6c-af50-f6f309d08647"/>
							<gml:surfaceMember xlink:href="#poly-126989e2-4964-4700-8716-2104535741af"/>
							<gml:surfaceMember xlink:href="#poly-deebdbcf-9065-41f5-8402-4b1bc80f0c85"/>
							<gml:surfaceMember xlink:href="#poly-adaad262-87e0-4388-a33d-05604a81c8da"/>
							<gml:surfaceMember xlink:href="#poly-c17fa835-9f95-47c5-b8e7-f977cf8c4f4f"/>
							<gml:surfaceMember xlink:href="#poly-eef54994-ae52-4604-ba2f-eaf6f615eafe"/>
							<gml:surfaceMember xlink:href="#poly-11a45937-f021-4934-bc63-e28c14bd4651"/>
							<gml:surfaceMember xlink:href="#poly-fdb77566-aae9-4922-a877-4a3e6dd1c512"/>
							<gml:surfaceMember xlink:href="#poly-632c400b-a06d-4527-81eb-9d823f471e31"/>
							<gml:surfaceMember xlink:href="#poly-445f22e8-4d5d-4da3-8586-50eabd2dcca8"/>
							<gml:surfaceMember xlink:href="#poly-666dd102-4eca-4792-a483-7c8b8b6d7a1d"/>
							<gml:surfaceMember xlink:href="#poly-3cc52bd8-6865-4f52-98bc-5d2e28092765"/>
							<gml:surfaceMember xlink:href="#poly-7894d45f-eb33-4fda-a87b-fad8b575b504"/>
							<gml:surfaceMember xlink:href="#poly-dcf9e2e1-2236-476d-ad15-774e3314dfd4"/>
							<gml:surfaceMember xlink:href="#poly-c7b053d5-5819-4d39-b1ff-c0119d2421ff"/>
							<gml:surfaceMember xlink:href="#poly-04301206-6035-4102-99ff-0a4e8a370061"/>
							<gml:surfaceMember xlink:href="#poly-36445940-833a-41a0-a458-b6ba9dc2e253"/>
							<gml:surfaceMember xlink:href="#poly-a9ae6d88-8fcf-4b21-a3cd-f6da187d0570"/>
							<gml:surfaceMember xlink:href="#poly-1158c4b4-8152-49da-a84d-48fe1e3b2d5c"/>
							<gml:surfaceMember xlink:href="#poly-f98661a6-8f34-4d1a-930e-898473f8b419"/>
							<gml:surfaceMember xlink:href="#poly-3f923c73-51c6-4ba3-bf79-30ad062283df"/>
							<gml:surfaceMember xlink:href="#poly-0611bd7e-3f31-471e-bb78-e1e67da16dc6"/>
							<gml:surfaceMember xlink:href="#poly-dbd484f6-e00d-4e9a-83c5-a3aedc762e3c"/>
							<gml:surfaceMember xlink:href="#poly-475e2061-87cd-4252-9985-2516d11aba99"/>
							<gml:surfaceMember xlink:href="#poly-fb82340f-e06d-44b0-949e-4a6128194ea7"/>
							<gml:surfaceMember xlink:href="#poly-980e295d-0730-4cf7-b6d1-725840c5b4f2"/>
							<gml:surfaceMember xlink:href="#poly-5e59b561-9532-4339-870a-48d2bd6a3174"/>
							<gml:surfaceMember xlink:href="#poly-838e5c59-a7b7-4931-b089-d32a1a9a98cd"/>
							<gml:surfaceMember xlink:href="#poly-8bab1d4b-6303-401b-a208-eda56f7d97b7"/>
							<gml:surfaceMember xlink:href="#poly-754d8a2b-3e74-4e2b-bd3f-e5090a758f71"/>
							<gml:surfaceMember xlink:href="#poly-7f7728e4-f15e-4d11-bef4-3882c5cbc684"/>
							<gml:surfaceMember xlink:href="#poly-9e1bade0-3d6c-4705-9c3d-1728dff02de0"/>
							<gml:surfaceMember xlink:href="#poly-5851c8c7-278b-4a8a-9f57-3a6b6da1badb"/>
							<gml:surfaceMember xlink:href="#poly-179ff724-9411-48ce-9608-09cbf5841823"/>
							<gml:surfaceMember xlink:href="#poly-30ae4cc1-1cf1-4517-8f9c-799a3f9753f3"/>
							<gml:surfaceMember xlink:href="#poly-b3e2bfab-133e-4d89-ad8f-1fa04059025f"/>
							<gml:surfaceMember xlink:href="#poly-ea14169a-b7aa-474f-be28-8c50cc22f399"/>
							<gml:surfaceMember xlink:href="#poly-d9050d1b-053d-4fc8-9f1a-369a6a8a1460"/>
							<gml:surfaceMember xlink:href="#poly-47a753c9-1444-4de3-8642-2e42dcb910a1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b7669b73-035b-41ad-9f5c-cf99c8621882_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d146a442-d6fb-4fae-95d4-259443cf033b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d146a442-d6fb-4fae-95d4-259443cf033b_0">
											<gml:posList>35.66849931366977 139.73925224685172 39.256 35.66853135394395 139.7392823206665 34.813 35.66849050980962 139.73924398372827 39.922 35.66849931366977 139.73925224685172 39.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2233cf4-6e5e-41af-bce9-09d2cc8f803c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2233cf4-6e5e-41af-bce9-09d2cc8f803c_0">
											<gml:posList>35.66853135394395 139.7392823206665 34.813 35.66853135394395 139.7392823206665 11.62 35.66849050980962 139.73924398372827 11.62 35.66853135394395 139.7392823206665 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdc9e160-b093-40d6-9d6e-60b6b70c8f1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdc9e160-b093-40d6-9d6e-60b6b70c8f1c_0">
											<gml:posList>35.66849050980962 139.73924398372827 39.922 35.66853135394395 139.7392823206665 34.813 35.66849050980962 139.73924398372827 11.62 35.66849050980962 139.73924398372827 39.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac8101a0-a593-496c-a13d-48394a033b49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac8101a0-a593-496c-a13d-48394a033b49_0">
											<gml:posList>35.66849050980962 139.73924398372827 11.62 35.66846641915377 139.73928250729188 39.922 35.66849050980962 139.73924398372827 39.922 35.66849050980962 139.73924398372827 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eab8fc97-45d9-4ad3-a20d-fed2619d4e2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eab8fc97-45d9-4ad3-a20d-fed2619d4e2c_0">
											<gml:posList>35.66849050980962 139.73924398372827 11.62 35.66846641915377 139.73928250729188 11.62 35.66846641915377 139.73928250729188 39.922 35.66849050980962 139.73924398372827 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0bf6d0b-4dd4-41d7-8951-062574961465">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0bf6d0b-4dd4-41d7-8951-062574961465_0">
											<gml:posList>35.66844142569249 139.73926150503874 11.62 35.668437329659454 139.7392681816232 41.525 35.66844142569249 139.73926150503874 41.525 35.66844142569249 139.73926150503874 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ed585ab-326e-4b02-bacc-79adc38c1188">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ed585ab-326e-4b02-bacc-79adc38c1188_0">
											<gml:posList>35.66844142569249 139.73926150503874 11.62 35.668437329659454 139.7392681816232 11.62 35.668437329659454 139.7392681816232 41.525 35.66844142569249 139.73926150503874 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e92ce23f-6487-4685-959a-aee2d8354941">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e92ce23f-6487-4685-959a-aee2d8354941_0">
											<gml:posList>35.66849050980962 139.73924398372827 39.922 35.66848209241726 139.73928043435234 39.256 35.66849931366977 139.73925224685172 39.256 35.66849050980962 139.73924398372827 39.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-756684f1-afac-43e5-8d08-b30818edd46d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-756684f1-afac-43e5-8d08-b30818edd46d_0">
											<gml:posList>35.66847051555291 139.73929938076927 39.256 35.66848209241726 139.73928043435234 39.256 35.66846641915377 139.73928250729188 39.922 35.66847051555291 139.73929938076927 39.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e480e89-4e2f-486e-b01f-834624729fcf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e480e89-4e2f-486e-b01f-834624729fcf_0">
											<gml:posList>35.668437329659454 139.7392681816232 41.525 35.66847051555291 139.73929938076927 39.256 35.66846641915377 139.73928250729188 39.922 35.668437329659454 139.7392681816232 41.525</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b05f6ea5-3c85-40c7-b4f2-c68bc202668a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b05f6ea5-3c85-40c7-b4f2-c68bc202668a_0">
											<gml:posList>35.66844142569249 139.73926150503874 41.525 35.668437329659454 139.7392681816232 41.525 35.66846641915377 139.73928250729188 39.922 35.66844142569249 139.73926150503874 41.525</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aec47b43-80ca-4728-887a-410417150fc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aec47b43-80ca-4728-887a-410417150fc8_0">
											<gml:posList>35.66848209241726 139.73928043435234 39.256 35.66849050980962 139.73924398372827 39.922 35.66846641915377 139.73928250729188 39.922 35.66848209241726 139.73928043435234 39.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bbdc94a-fc41-47a0-b519-813a0ece379f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bbdc94a-fc41-47a0-b519-813a0ece379f_0">
											<gml:posList>35.66844142569249 139.73926150503874 11.62 35.66846641915377 139.73928250729188 39.922 35.66846641915377 139.73928250729188 11.62 35.66844142569249 139.73926150503874 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-432eddb1-061e-4bfa-98d3-c8eaaad6f947">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-432eddb1-061e-4bfa-98d3-c8eaaad6f947_0">
											<gml:posList>35.66844142569249 139.73926150503874 11.62 35.66844142569249 139.73926150503874 41.525 35.66846641915377 139.73928250729188 39.922 35.66844142569249 139.73926150503874 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6927f6cb-4f8a-45cf-b0ac-ac744f921106">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6927f6cb-4f8a-45cf-b0ac-ac744f921106_0">
											<gml:posList>35.66851628376491 139.73930640758266 34.813 35.66853135394395 139.7392823206665 34.813 35.66849931366977 139.73925224685172 39.256 35.66851628376491 139.73930640758266 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d36bae19-9d20-42cf-867d-cc6b1b5af611">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d36bae19-9d20-42cf-867d-cc6b1b5af611_0">
											<gml:posList>35.66848209241726 139.73928043435234 39.256 35.66851628376491 139.73930640758266 34.813 35.66849931366977 139.73925224685172 39.256 35.66848209241726 139.73928043435234 39.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6957840d-45b3-4911-9990-2ed1dcb142f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6957840d-45b3-4911-9990-2ed1dcb142f5_0">
											<gml:posList>35.668437329659454 139.7392681816232 11.62 35.66847051555291 139.73929938076927 39.256 35.668437329659454 139.7392681816232 41.525 35.668437329659454 139.7392681816232 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9711c0ba-5d64-4a67-8c8b-32e2ce1645fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9711c0ba-5d64-4a67-8c8b-32e2ce1645fe_0">
											<gml:posList>35.668437329659454 139.7392681816232 11.62 35.66847051555291 139.73929938076927 11.62 35.66847051555291 139.73929938076927 39.256 35.668437329659454 139.7392681816232 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7c8e2e1-6b02-41df-b83c-ac12a65c1ee3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7c8e2e1-6b02-41df-b83c-ac12a65c1ee3_0">
											<gml:posList>35.66848209241726 139.73928043435234 11.62 35.66847051555291 139.73929938076927 39.256 35.66847051555291 139.73929938076927 11.62 35.66848209241726 139.73928043435234 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ef6175f-ea6d-4ed4-8cc3-c6722fa9f493">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ef6175f-ea6d-4ed4-8cc3-c6722fa9f493_0">
											<gml:posList>35.66848209241726 139.73928043435234 11.62 35.66848209241726 139.73928043435234 39.256 35.66847051555291 139.73929938076927 39.256 35.66848209241726 139.73928043435234 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77d663bf-0b68-462b-a5f9-ab52902fc05e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77d663bf-0b68-462b-a5f9-ab52902fc05e_0">
											<gml:posList>35.66851628376491 139.73930640758266 34.813 35.66848209241726 139.73928043435234 39.256 35.66848209241726 139.73928043435234 11.62 35.66851628376491 139.73930640758266 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef52c37d-3a98-40b7-9180-7fa68429400a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef52c37d-3a98-40b7-9180-7fa68429400a_0">
											<gml:posList>35.66851628376491 139.73930640758266 11.62 35.66851628376491 139.73930640758266 34.813 35.66848209241726 139.73928043435234 11.62 35.66851628376491 139.73930640758266 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-135d6812-1107-47a5-b4d8-00afec1075b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-135d6812-1107-47a5-b4d8-00afec1075b3_0">
											<gml:posList>35.66851628376491 139.73930640758266 11.62 35.66853135394395 139.7392823206665 34.813 35.66851628376491 139.73930640758266 34.813 35.66851628376491 139.73930640758266 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cceb7800-d5db-40f5-bdc6-8c17b178ee2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cceb7800-d5db-40f5-bdc6-8c17b178ee2c_0">
											<gml:posList>35.66851628376491 139.73930640758266 11.62 35.66853135394395 139.7392823206665 11.62 35.66853135394395 139.7392823206665 34.813 35.66851628376491 139.73930640758266 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bce6b9ae-5e82-4c8b-bd1c-f4fe51f89a89">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853135394395 139.7392823206665 11.62 35.66848209241726 139.73928043435234 11.62 35.66849050980962 139.73924398372827 11.62 35.66853135394395 139.7392823206665 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-324528a6-0777-44ef-b1a9-d8930f674fa8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853135394395 139.7392823206665 11.62 35.66851628376491 139.73930640758266 11.62 35.66848209241726 139.73928043435234 11.62 35.66853135394395 139.7392823206665 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dac8c04-42df-4c59-8351-5770d1302ed8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66849050980962 139.73924398372827 11.62 35.66848209241726 139.73928043435234 11.62 35.66846641915377 139.73928250729188 11.62 35.66849050980962 139.73924398372827 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52ef2ae1-d076-403b-a579-1dd1b94bdd52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668437329659454 139.7392681816232 11.62 35.66844142569249 139.73926150503874 11.62 35.66846641915377 139.73928250729188 11.62 35.668437329659454 139.7392681816232 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-035d679a-c5ca-441d-ae9f-63c597463b19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668437329659454 139.7392681816232 11.62 35.66846641915377 139.73928250729188 11.62 35.66847051555291 139.73929938076927 11.62 35.668437329659454 139.7392681816232 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed189e80-9528-4764-9806-5a2da847c012">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66846641915377 139.73928250729188 11.62 35.66848209241726 139.73928043435234 11.62 35.66847051555291 139.73929938076927 11.62 35.66846641915377 139.73928250729188 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b7669b73-035b-41ad-9f5c-cf99c8621882_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5aeaef6d-a9f7-40ea-a816-62ef4869e739">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66842323064155 139.7392316027992 41.879 35.66843262021641 139.73921656923198 41.879 35.66844571777127 139.73922887014044 41.879 35.66843632818626 139.7392438926627 41.879 35.66842323064155 139.7392316027992 41.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a019cc3d-b7de-4d95-999e-282568b7a32c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66841601297835 139.73928074382755 41.879 35.66840819192672 139.73927287721222 41.879 35.66841464724349 139.7392632375377 41.879 35.66842246829574 139.73927110415272 41.879 35.66841601297835 139.73928074382755 41.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-802d0829-690b-456a-a812-58e511490abd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-802d0829-690b-456a-a812-58e511490abd_0">
											<gml:posList>35.66841464724349 139.7392632375377 41.879 35.66840819192672 139.73927287721222 41.879 35.66840819192672 139.73927287721222 42.721 35.66841464724349 139.7392632375377 42.721 35.66841464724349 139.7392632375377 41.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-612c46e0-666a-41a8-bc7a-b84080c96978">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-612c46e0-666a-41a8-bc7a-b84080c96978_0">
											<gml:posList>35.66840819192672 139.73927287721222 41.879 35.66841601297835 139.73928074382755 41.879 35.66841601297835 139.73928074382755 42.721 35.66840819192672 139.73927287721222 42.721 35.66840819192672 139.73927287721222 41.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3201c37-7300-47e0-8612-ed027e40487e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3201c37-7300-47e0-8612-ed027e40487e_0">
											<gml:posList>35.66841464724349 139.7392632375377 42.721 35.66840819192672 139.73927287721222 42.721 35.66841601297835 139.73928074382755 42.721 35.66842246829574 139.73927110415272 42.721 35.66841464724349 139.7392632375377 42.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25fd9485-f07a-4a73-826d-be0005f01079">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25fd9485-f07a-4a73-826d-be0005f01079_0">
											<gml:posList>35.66841464724349 139.7392632375377 42.721 35.66842246829574 139.73927110415272 42.721 35.66842246829574 139.73927110415272 41.879 35.66841464724349 139.7392632375377 41.879 35.66841464724349 139.7392632375377 42.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c09ea767-aecd-442f-aa01-5c79c825b33c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c09ea767-aecd-442f-aa01-5c79c825b33c_0">
											<gml:posList>35.66841601297835 139.73928074382755 41.879 35.66842246829574 139.73927110415272 41.879 35.66842246829574 139.73927110415272 42.721 35.66841601297835 139.73928074382755 42.721 35.66841601297835 139.73928074382755 41.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd1572dd-b6c2-4765-a1f1-798d73797fcd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd1572dd-b6c2-4765-a1f1-798d73797fcd_0">
											<gml:posList>35.66842323064155 139.7392316027992 41.879 35.66842323064155 139.7392316027992 43.521 35.66843262021641 139.73921656923198 43.521 35.66843262021641 139.73921656923198 41.879 35.66842323064155 139.7392316027992 41.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-311aa4c3-9a47-48f4-8aac-cca5c4945a96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-311aa4c3-9a47-48f4-8aac-cca5c4945a96_0">
											<gml:posList>35.66842323064155 139.7392316027992 41.879 35.66843632818626 139.7392438926627 41.879 35.66843632818626 139.7392438926627 43.521 35.66842323064155 139.7392316027992 43.521 35.66842323064155 139.7392316027992 41.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71a76067-4ebd-454d-806f-ab256c31aee1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71a76067-4ebd-454d-806f-ab256c31aee1_0">
											<gml:posList>35.66842323064155 139.7392316027992 43.521 35.66843632818626 139.7392438926627 43.521 35.66844571777127 139.73922887014044 43.521 35.66843262021641 139.73921656923198 43.521 35.66842323064155 139.7392316027992 43.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f0fc896-e0e1-4712-bb86-2f039eff498f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f0fc896-e0e1-4712-bb86-2f039eff498f_0">
											<gml:posList>35.66844571777127 139.73922887014044 41.879 35.66843262021641 139.73921656923198 41.879 35.66843262021641 139.73921656923198 43.521 35.66844571777127 139.73922887014044 43.521 35.66844571777127 139.73922887014044 41.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd67a2f0-025b-4da5-95ae-9da5d6b22258">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd67a2f0-025b-4da5-95ae-9da5d6b22258_0">
											<gml:posList>35.66843632818626 139.7392438926627 41.879 35.66844571777127 139.73922887014044 41.879 35.66844571777127 139.73922887014044 43.521 35.66843632818626 139.7392438926627 43.521 35.66843632818626 139.7392438926627 41.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-84ced6bb-f44b-4205-8c5c-2903a18424df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84ced6bb-f44b-4205-8c5c-2903a18424df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84ced6bb-f44b-4205-8c5c-2903a18424df">
											<gml:posList>35.66839947641671 139.73915853938442 11.62 35.66849050980962 139.73924398372827 11.62 35.66846641915377 139.73928250729188 11.62 35.66844142569249 139.73926150503874 11.62 35.66838799602811 139.7393471078297 11.62 35.66832701848484 139.73928985068594 11.62 35.66836599924487 139.7392275056297 11.62 35.66835986542256 139.7392217689184 11.62 35.66839947641671 139.73915853938442 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87b8f53b-62d1-4e5d-bdb1-95368448b026">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87b8f53b-62d1-4e5d-bdb1-95368448b026">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87b8f53b-62d1-4e5d-bdb1-95368448b026">
											<gml:posList>35.66833099304605 139.73928921640368 35.203 35.66836213277766 139.73923958342505 35.203 35.66835986855449 139.73923731060998 35.203 35.66832701848484 139.73928985068594 35.203 35.66833099304605 139.73928921640368 35.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62addc8c-97a0-4bf3-b505-36b097284564">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62addc8c-97a0-4bf3-b505-36b097284564">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62addc8c-97a0-4bf3-b505-36b097284564">
											<gml:posList>35.66838799602811 139.7393471078297 35.203 35.668387469438464 139.73934224821363 35.203 35.66833099304605 139.73928921640368 35.203 35.66832701848484 139.73928985068594 35.203 35.66838799602811 139.7393471078297 35.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdf93636-1f2f-4a6c-af50-f6f309d08647">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdf93636-1f2f-4a6c-af50-f6f309d08647">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdf93636-1f2f-4a6c-af50-f6f309d08647">
											<gml:posList>35.66836599924487 139.7392275056297 42.341 35.66835986855449 139.73923731060998 42.341 35.66836436591147 139.73923667571134 42.341 35.66836858808318 139.73922993270745 42.341 35.66836599924487 139.7392275056297 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-126989e2-4964-4700-8716-2104535741af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-126989e2-4964-4700-8716-2104535741af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-126989e2-4964-4700-8716-2104535741af">
											<gml:posList>35.66833099304605 139.73928921640368 34.919 35.668387469438464 139.73934224821363 34.919 35.66841715978477 139.7392949255321 34.919 35.66836213277766 139.73923958342505 34.919 35.66833099304605 139.73928921640368 34.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-deebdbcf-9065-41f5-8402-4b1bc80f0c85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-deebdbcf-9065-41f5-8402-4b1bc80f0c85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-deebdbcf-9065-41f5-8402-4b1bc80f0c85">
											<gml:posList>35.66836599924487 139.7392275056297 35.08 35.66840742334834 139.7391659971384 35.08 35.66839947641671 139.73915853938442 35.08 35.66835986542256 139.7392217689184 35.08 35.66836599924487 139.7392275056297 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-adaad262-87e0-4388-a33d-05604a81c8da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adaad262-87e0-4388-a33d-05604a81c8da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adaad262-87e0-4388-a33d-05604a81c8da">
											<gml:posList>35.66836599924487 139.7392275056297 42.341 35.66836858808318 139.73922993270745 42.341 35.66840795044608 139.7391714974212 42.341 35.66840742334834 139.7391659971384 42.341 35.66836599924487 139.7392275056297 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c17fa835-9f95-47c5-b8e7-f977cf8c4f4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c17fa835-9f95-47c5-b8e7-f977cf8c4f4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c17fa835-9f95-47c5-b8e7-f977cf8c4f4f">
											<gml:posList>35.668419279675085 139.73929705492185 42.341 35.668418743414065 139.73929135582037 42.341 35.66836436591147 139.73923667571134 42.341 35.66835986855449 139.73923731060998 42.341 35.668419279675085 139.73929705492185 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eef54994-ae52-4604-ba2f-eaf6f615eafe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eef54994-ae52-4604-ba2f-eaf6f615eafe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eef54994-ae52-4604-ba2f-eaf6f615eafe">
											<gml:posList>35.668387469438464 139.73934224821363 35.203 35.66838799602811 139.7393471078297 35.203 35.668419279675085 139.73929705492185 35.203 35.66841715978477 139.7392949255321 35.203 35.668387469438464 139.73934224821363 35.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11a45937-f021-4934-bc63-e28c14bd4651">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11a45937-f021-4934-bc63-e28c14bd4651">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11a45937-f021-4934-bc63-e28c14bd4651">
											<gml:posList>35.66843884586857 139.7392590779472 41.879 35.66846191921789 139.73922215725312 41.879 35.66840795044608 139.7391714974212 41.879 35.66836858808318 139.73922993270745 41.879 35.66836436591147 139.73923667571134 41.879 35.668418743414065 139.73929135582037 41.879 35.66843884586857 139.7392590779472 41.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fdb77566-aae9-4922-a877-4a3e6dd1c512">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdb77566-aae9-4922-a877-4a3e6dd1c512">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdb77566-aae9-4922-a877-4a3e6dd1c512">
											<gml:posList>35.66844142569249 139.73926150503874 42.341 35.66843884586857 139.7392590779472 42.341 35.668418743414065 139.73929135582037 42.341 35.668419279675085 139.73929705492185 42.341 35.66844142569249 139.73926150503874 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-632c400b-a06d-4527-81eb-9d823f471e31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-632c400b-a06d-4527-81eb-9d823f471e31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-632c400b-a06d-4527-81eb-9d823f471e31">
											<gml:posList>35.66840742334834 139.7391659971384 42.341 35.66840795044608 139.7391714974212 42.341 35.66846191921789 139.73922215725312 42.341 35.668466479593086 139.73922142286492 42.341 35.66840742334834 139.7391659971384 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-445f22e8-4d5d-4da3-8586-50eabd2dcca8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-445f22e8-4d5d-4da3-8586-50eabd2dcca8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-445f22e8-4d5d-4da3-8586-50eabd2dcca8">
											<gml:posList>35.66843884586857 139.7392590779472 42.341 35.66844142569249 139.73926150503874 42.341 35.6684432531919 139.73925857570669 42.341 35.66843884586857 139.7392590779472 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-666dd102-4eca-4792-a483-7c8b8b6d7a1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-666dd102-4eca-4792-a483-7c8b8b6d7a1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-666dd102-4eca-4792-a483-7c8b8b6d7a1d">
											<gml:posList>35.66846191921789 139.73922215725312 42.341 35.66843884586857 139.7392590779472 42.341 35.6684432531919 139.73925857570669 42.341 35.66846474211098 139.73922419744906 42.341 35.66846191921789 139.73922215725312 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3cc52bd8-6865-4f52-98bc-5d2e28092765">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cc52bd8-6865-4f52-98bc-5d2e28092765">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cc52bd8-6865-4f52-98bc-5d2e28092765">
											<gml:posList>35.66846579349683 139.73927775824765 42.341 35.6684432531919 139.73925857570669 42.341 35.66844142569249 139.73926150503874 42.341 35.66846641915377 139.73928250729188 42.341 35.66846579349683 139.73927775824765 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7894d45f-eb33-4fda-a87b-fad8b575b504">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7894d45f-eb33-4fda-a87b-fad8b575b504">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7894d45f-eb33-4fda-a87b-fad8b575b504">
											<gml:posList>35.66846191921789 139.73922215725312 42.341 35.66846474211098 139.73922419744906 42.341 35.668466479593086 139.73922142286492 42.341 35.66846191921789 139.73922215725312 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dcf9e2e1-2236-476d-ad15-774e3314dfd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcf9e2e1-2236-476d-ad15-774e3314dfd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcf9e2e1-2236-476d-ad15-774e3314dfd4">
											<gml:posList>35.66846579349683 139.73927775824765 42.092 35.668486517229944 139.73924462908118 42.092 35.66846474211098 139.73922419744906 42.092 35.6684432531919 139.73925857570669 42.092 35.66846579349683 139.73927775824765 42.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c7b053d5-5819-4d39-b1ff-c0119d2421ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7b053d5-5819-4d39-b1ff-c0119d2421ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7b053d5-5819-4d39-b1ff-c0119d2421ff">
											<gml:posList>35.668486517229944 139.73924462908118 42.341 35.66849050980962 139.73924398372827 42.341 35.668466479593086 139.73922142286492 42.341 35.66846474211098 139.73922419744906 42.341 35.668486517229944 139.73924462908118 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04301206-6035-4102-99ff-0a4e8a370061">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04301206-6035-4102-99ff-0a4e8a370061">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04301206-6035-4102-99ff-0a4e8a370061">
											<gml:posList>35.66849050980962 139.73924398372827 42.341 35.668486517229944 139.73924462908118 42.341 35.66846579349683 139.73927775824765 42.341 35.66846641915377 139.73928250729188 42.341 35.66849050980962 139.73924398372827 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36445940-833a-41a0-a458-b6ba9dc2e253">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36445940-833a-41a0-a458-b6ba9dc2e253">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36445940-833a-41a0-a458-b6ba9dc2e253">
											<gml:posList>35.6684432531919 139.73925857570669 42.341 35.6684432531919 139.73925857570669 42.092 35.66846474211098 139.73922419744906 42.092 35.66846474211098 139.73922419744906 42.341 35.6684432531919 139.73925857570669 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9ae6d88-8fcf-4b21-a3cd-f6da187d0570">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9ae6d88-8fcf-4b21-a3cd-f6da187d0570">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9ae6d88-8fcf-4b21-a3cd-f6da187d0570">
											<gml:posList>35.668418743414065 139.73929135582037 42.341 35.668418743414065 139.73929135582037 41.879 35.66836436591147 139.73923667571134 41.879 35.66836436591147 139.73923667571134 42.341 35.668418743414065 139.73929135582037 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1158c4b4-8152-49da-a84d-48fe1e3b2d5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1158c4b4-8152-49da-a84d-48fe1e3b2d5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1158c4b4-8152-49da-a84d-48fe1e3b2d5c">
											<gml:posList>35.66836599924487 139.7392275056297 35.08 35.66836599924487 139.7392275056297 11.62 35.66832701848484 139.73928985068594 11.62 35.66832701848484 139.73928985068594 35.203 35.66835986855449 139.73923731060998 35.203 35.66835986855449 139.73923731060998 42.341 35.66836599924487 139.7392275056297 42.341 35.66836599924487 139.7392275056297 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f98661a6-8f34-4d1a-930e-898473f8b419">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f98661a6-8f34-4d1a-930e-898473f8b419">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f98661a6-8f34-4d1a-930e-898473f8b419">
											<gml:posList>35.66833099304605 139.73928921640368 35.203 35.66833099304605 139.73928921640368 34.919 35.66836213277766 139.73923958342505 34.919 35.66836213277766 139.73923958342505 35.203 35.66833099304605 139.73928921640368 35.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f923c73-51c6-4ba3-bf79-30ad062283df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f923c73-51c6-4ba3-bf79-30ad062283df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f923c73-51c6-4ba3-bf79-30ad062283df">
											<gml:posList>35.66832701848484 139.73928985068594 11.62 35.66838799602811 139.7393471078297 11.62 35.66838799602811 139.7393471078297 35.203 35.66832701848484 139.73928985068594 35.203 35.66832701848484 139.73928985068594 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0611bd7e-3f31-471e-bb78-e1e67da16dc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0611bd7e-3f31-471e-bb78-e1e67da16dc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0611bd7e-3f31-471e-bb78-e1e67da16dc6">
											<gml:posList>35.668387469438464 139.73934224821363 35.203 35.668387469438464 139.73934224821363 34.919 35.66833099304605 139.73928921640368 34.919 35.66833099304605 139.73928921640368 35.203 35.668387469438464 139.73934224821363 35.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbd484f6-e00d-4e9a-83c5-a3aedc762e3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbd484f6-e00d-4e9a-83c5-a3aedc762e3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbd484f6-e00d-4e9a-83c5-a3aedc762e3c">
											<gml:posList>35.66835986542256 139.7392217689184 11.62 35.66836599924487 139.7392275056297 11.62 35.66836599924487 139.7392275056297 35.08 35.66835986542256 139.7392217689184 35.08 35.66835986542256 139.7392217689184 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-475e2061-87cd-4252-9985-2516d11aba99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-475e2061-87cd-4252-9985-2516d11aba99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-475e2061-87cd-4252-9985-2516d11aba99">
											<gml:posList>35.66836436591147 139.73923667571134 42.341 35.66836436591147 139.73923667571134 41.879 35.66836858808318 139.73922993270745 41.879 35.66836858808318 139.73922993270745 42.341 35.66836436591147 139.73923667571134 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb82340f-e06d-44b0-949e-4a6128194ea7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb82340f-e06d-44b0-949e-4a6128194ea7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb82340f-e06d-44b0-949e-4a6128194ea7">
											<gml:posList>35.66839947641671 139.73915853938442 11.62 35.66835986542256 139.7392217689184 11.62 35.66835986542256 139.7392217689184 35.08 35.66839947641671 139.73915853938442 35.08 35.66839947641671 139.73915853938442 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-980e295d-0730-4cf7-b6d1-725840c5b4f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-980e295d-0730-4cf7-b6d1-725840c5b4f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-980e295d-0730-4cf7-b6d1-725840c5b4f2">
											<gml:posList>35.66836599924487 139.7392275056297 35.08 35.66836599924487 139.7392275056297 42.341 35.66840742334834 139.7391659971384 42.341 35.66840742334834 139.7391659971384 35.08 35.66836599924487 139.7392275056297 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e59b561-9532-4339-870a-48d2bd6a3174">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e59b561-9532-4339-870a-48d2bd6a3174">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e59b561-9532-4339-870a-48d2bd6a3174">
											<gml:posList>35.66836858808318 139.73922993270745 42.341 35.66836858808318 139.73922993270745 41.879 35.66840795044608 139.7391714974212 41.879 35.66840795044608 139.7391714974212 42.341 35.66836858808318 139.73922993270745 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-838e5c59-a7b7-4931-b089-d32a1a9a98cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-838e5c59-a7b7-4931-b089-d32a1a9a98cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-838e5c59-a7b7-4931-b089-d32a1a9a98cd">
											<gml:posList>35.66836213277766 139.73923958342505 35.203 35.66836213277766 139.73923958342505 34.919 35.66841715978477 139.7392949255321 34.919 35.66841715978477 139.7392949255321 35.203 35.668419279675085 139.73929705492185 35.203 35.668419279675085 139.73929705492185 42.341 35.66835986855449 139.73923731060998 42.341 35.66835986855449 139.73923731060998 35.203 35.66836213277766 139.73923958342505 35.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bab1d4b-6303-401b-a208-eda56f7d97b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bab1d4b-6303-401b-a208-eda56f7d97b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bab1d4b-6303-401b-a208-eda56f7d97b7">
											<gml:posList>35.66841715978477 139.7392949255321 35.203 35.66841715978477 139.7392949255321 34.919 35.668387469438464 139.73934224821363 34.919 35.668387469438464 139.73934224821363 35.203 35.66841715978477 139.7392949255321 35.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-754d8a2b-3e74-4e2b-bd3f-e5090a758f71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-754d8a2b-3e74-4e2b-bd3f-e5090a758f71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-754d8a2b-3e74-4e2b-bd3f-e5090a758f71">
											<gml:posList>35.66838799602811 139.7393471078297 11.62 35.66844142569249 139.73926150503874 11.62 35.66844142569249 139.73926150503874 42.341 35.668419279675085 139.73929705492185 42.341 35.668419279675085 139.73929705492185 35.203 35.66838799602811 139.7393471078297 35.203 35.66838799602811 139.7393471078297 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f7728e4-f15e-4d11-bef4-3882c5cbc684">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f7728e4-f15e-4d11-bef4-3882c5cbc684">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f7728e4-f15e-4d11-bef4-3882c5cbc684">
											<gml:posList>35.66843884586857 139.7392590779472 42.341 35.66843884586857 139.7392590779472 41.879 35.668418743414065 139.73929135582037 41.879 35.668418743414065 139.73929135582037 42.341 35.66843884586857 139.7392590779472 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e1bade0-3d6c-4705-9c3d-1728dff02de0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e1bade0-3d6c-4705-9c3d-1728dff02de0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e1bade0-3d6c-4705-9c3d-1728dff02de0">
											<gml:posList>35.66840795044608 139.7391714974212 42.341 35.66840795044608 139.7391714974212 41.879 35.66846191921789 139.73922215725312 41.879 35.66846191921789 139.73922215725312 42.341 35.66840795044608 139.7391714974212 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5851c8c7-278b-4a8a-9f57-3a6b6da1badb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5851c8c7-278b-4a8a-9f57-3a6b6da1badb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5851c8c7-278b-4a8a-9f57-3a6b6da1badb">
											<gml:posList>35.66840742334834 139.7391659971384 35.08 35.66840742334834 139.7391659971384 42.341 35.668466479593086 139.73922142286492 42.341 35.66849050980962 139.73924398372827 42.341 35.66849050980962 139.73924398372827 11.62 35.66839947641671 139.73915853938442 11.62 35.66839947641671 139.73915853938442 35.08 35.66840742334834 139.7391659971384 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-179ff724-9411-48ce-9608-09cbf5841823">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-179ff724-9411-48ce-9608-09cbf5841823">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-179ff724-9411-48ce-9608-09cbf5841823">
											<gml:posList>35.66846191921789 139.73922215725312 42.341 35.66846191921789 139.73922215725312 41.879 35.66843884586857 139.7392590779472 41.879 35.66843884586857 139.7392590779472 42.341 35.66846191921789 139.73922215725312 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30ae4cc1-1cf1-4517-8f9c-799a3f9753f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30ae4cc1-1cf1-4517-8f9c-799a3f9753f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30ae4cc1-1cf1-4517-8f9c-799a3f9753f3">
											<gml:posList>35.66844142569249 139.73926150503874 11.62 35.66846641915377 139.73928250729188 11.62 35.66846641915377 139.73928250729188 42.341 35.66844142569249 139.73926150503874 42.341 35.66844142569249 139.73926150503874 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3e2bfab-133e-4d89-ad8f-1fa04059025f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3e2bfab-133e-4d89-ad8f-1fa04059025f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3e2bfab-133e-4d89-ad8f-1fa04059025f">
											<gml:posList>35.66846579349683 139.73927775824765 42.341 35.66846579349683 139.73927775824765 42.092 35.6684432531919 139.73925857570669 42.092 35.6684432531919 139.73925857570669 42.341 35.66846579349683 139.73927775824765 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea14169a-b7aa-474f-be28-8c50cc22f399">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea14169a-b7aa-474f-be28-8c50cc22f399">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea14169a-b7aa-474f-be28-8c50cc22f399">
											<gml:posList>35.66846474211098 139.73922419744906 42.341 35.66846474211098 139.73922419744906 42.092 35.668486517229944 139.73924462908118 42.092 35.668486517229944 139.73924462908118 42.341 35.66846474211098 139.73922419744906 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9050d1b-053d-4fc8-9f1a-369a6a8a1460">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9050d1b-053d-4fc8-9f1a-369a6a8a1460">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9050d1b-053d-4fc8-9f1a-369a6a8a1460">
											<gml:posList>35.668486517229944 139.73924462908118 42.341 35.668486517229944 139.73924462908118 42.092 35.66846579349683 139.73927775824765 42.092 35.66846579349683 139.73927775824765 42.341 35.668486517229944 139.73924462908118 42.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47a753c9-1444-4de3-8642-2e42dcb910a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47a753c9-1444-4de3-8642-2e42dcb910a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47a753c9-1444-4de3-8642-2e42dcb910a1">
											<gml:posList>35.66846641915377 139.73928250729188 11.62 35.66849050980962 139.73924398372827 11.62 35.66849050980962 139.73924398372827 42.341 35.66846641915377 139.73928250729188 42.341 35.66846641915377 139.73928250729188 11.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2232</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">256.5915</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>