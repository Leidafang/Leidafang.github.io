<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b8855757-fcfe-41c1-be27-1f35abc578b8">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">30.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67066650732545 139.73960422379952 0 35.67081573448086 139.73955257349934 0 35.67072601498738 139.73916395889987 0 35.670529839282494 139.739232013471 0 35.670619558471984 139.7396205167339 0 35.67066542593678 139.73960455645266 0 35.67066650732545 139.73960422379952 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066650732545 139.73960422379952 17.94 35.67066542593678 139.73960455645266 17.94 35.670619558471984 139.7396205167339 17.94 35.670529839282494 139.739232013471 17.94 35.67072601498738 139.73916395889987 17.94 35.67081573448086 139.73955257349934 17.94 35.67066650732545 139.73960422379952 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066650732545 139.73960422379952 17.94 35.67081573448086 139.73955257349934 17.94 35.67081573448086 139.73955257349934 48.38 35.67066650732545 139.73960422379952 48.38 35.67066650732545 139.73960422379952 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67081573448086 139.73955257349934 17.94 35.67072601498738 139.73916395889987 17.94 35.67072601498738 139.73916395889987 48.38 35.67081573448086 139.73955257349934 48.38 35.67081573448086 139.73955257349934 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67072601498738 139.73916395889987 17.94 35.670529839282494 139.739232013471 17.94 35.670529839282494 139.739232013471 48.38 35.67072601498738 139.73916395889987 48.38 35.67072601498738 139.73916395889987 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670529839282494 139.739232013471 17.94 35.670619558471984 139.7396205167339 17.94 35.670619558471984 139.7396205167339 48.38 35.670529839282494 139.739232013471 48.38 35.670529839282494 139.739232013471 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670619558471984 139.7396205167339 17.94 35.67066542593678 139.73960455645266 17.94 35.67066542593678 139.73960455645266 48.38 35.670619558471984 139.7396205167339 48.38 35.670619558471984 139.7396205167339 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066542593678 139.73960455645266 17.94 35.67066650732545 139.73960422379952 17.94 35.67066650732545 139.73960422379952 48.38 35.67066542593678 139.73960455645266 48.38 35.67066542593678 139.73960455645266 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066650732545 139.73960422379952 48.38 35.67081573448086 139.73955257349934 48.38 35.67072601498738 139.73916395889987 48.38 35.670529839282494 139.739232013471 48.38 35.670619558471984 139.7396205167339 48.38 35.67066542593678 139.73960455645266 48.38 35.67066650732545 139.73960422379952 48.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4ac1116f-630e-40ef-a3a6-b5842ed03477"/>
							<gml:surfaceMember xlink:href="#poly-6abba66c-1b77-40b6-a171-3e39e2de8815"/>
							<gml:surfaceMember xlink:href="#poly-d262217c-dd6d-45aa-a5cf-bc193ca94642"/>
							<gml:surfaceMember xlink:href="#poly-e4ec8c44-a8e6-48ba-beb8-cbcec1a177f2"/>
							<gml:surfaceMember xlink:href="#poly-af00a029-881c-4f97-aa22-ca6e1a446a0e"/>
							<gml:surfaceMember xlink:href="#poly-a3f463c0-d735-4a7f-bd5d-efc022e88623"/>
							<gml:surfaceMember xlink:href="#poly-cce0216d-036c-49e0-9e3c-43de083bee3e"/>
							<gml:surfaceMember xlink:href="#poly-e53945f0-1df7-4a70-bfde-c88476e9ee07"/>
							<gml:surfaceMember xlink:href="#poly-efc83b05-deff-43e9-b2fb-94c03af3b834"/>
							<gml:surfaceMember xlink:href="#poly-8ec0d943-3b44-4e8b-a384-952fcd1f76d2"/>
							<gml:surfaceMember xlink:href="#poly-b2c0b35f-0955-4448-9b32-199a580363a2"/>
							<gml:surfaceMember xlink:href="#poly-7d70b21e-798c-4ea7-91ef-f61088e6d77c"/>
							<gml:surfaceMember xlink:href="#poly-956ef3ec-4ad1-4a8e-9f86-47ee22a33e18"/>
							<gml:surfaceMember xlink:href="#poly-ee441e60-7516-48c2-b658-2afbdcc90998"/>
							<gml:surfaceMember xlink:href="#poly-0d59461b-e3c2-490e-8fe9-606bc8e80a67"/>
							<gml:surfaceMember xlink:href="#poly-49d60e53-46d7-4c0d-adea-4829e50d5456"/>
							<gml:surfaceMember xlink:href="#poly-850b16c6-951e-4f88-b187-6ce16bfaff9a"/>
							<gml:surfaceMember xlink:href="#poly-54d7a98c-611f-4511-88bf-335804eb6a7d"/>
							<gml:surfaceMember xlink:href="#poly-5cbd3e2e-ba5c-4e76-a039-dfaaf34b0480"/>
							<gml:surfaceMember xlink:href="#poly-0e5bf041-f064-46ce-bf6d-3199a228f787"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b8855757-fcfe-41c1-be27-1f35abc578b8_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a365943d-4a80-487e-8577-c8e9377612f9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066374529855 139.7392064387766 48.423 35.670673666199995 139.73924845830007 48.423 35.67063876569505 139.73926083796619 48.423 35.67062884478925 139.73921880741315 48.423 35.67066374529855 139.7392064387766 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b56c1705-c626-425b-a8c7-a6853fb8f623">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670557846897644 139.73932683503833 48.953 35.67055809921287 139.7393267463722 48.953 35.67057057130281 139.73938075913148 48.953 35.670557846897644 139.73932683503833 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-505417f4-4bd8-4334-8fe2-f23380a94f83">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057057130281 139.73938075913148 48.423 35.67055809921287 139.7393267463722 48.423 35.670585646563374 139.73931698229384 48.423 35.67058281589266 139.73930497829886 48.423 35.67073683592527 139.73925038355407 48.423 35.670806806431074 139.7395468509032 48.423 35.670686677552084 139.73958943131464 48.423 35.67066485217354 139.73959697936257 48.423 35.67066385188257 139.7395972787821 48.423 35.670624878059044 139.7396108450098 48.423 35.67057057130281 139.73938075913148 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb5fc88f-822e-4a19-8cb8-d03656d56978">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67062498657623 139.73961129778095 48.953 35.670624878059044 139.7396108450098 48.953 35.67066385188257 139.7395972787821 48.953 35.67066485217354 139.73959697936257 48.953 35.670686677552084 139.73958943131464 48.953 35.67062498657623 139.73961129778095 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df401843-800a-4ebe-a8b5-c2a476ded4be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df401843-800a-4ebe-a8b5-c2a476ded4be_0">
											<gml:posList>35.67066374529855 139.7392064387766 48.423 35.67062884478925 139.73921880741315 48.423 35.67062884478925 139.73921880741315 49.965 35.67066374529855 139.7392064387766 49.965 35.67066374529855 139.7392064387766 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf5bb377-37a8-4230-bb1e-6dc84bdef109">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf5bb377-37a8-4230-bb1e-6dc84bdef109_0">
											<gml:posList>35.670673666199995 139.73924845830007 48.423 35.67066374529855 139.7392064387766 48.423 35.67066374529855 139.7392064387766 49.965 35.670673666199995 139.73924845830007 49.965 35.670673666199995 139.73924845830007 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f209b94-f31d-44c4-a0a5-1a02881f503d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f209b94-f31d-44c4-a0a5-1a02881f503d_0">
											<gml:posList>35.67066374529855 139.7392064387766 49.965 35.67062884478925 139.73921880741315 49.965 35.67063876569505 139.73926083796619 49.965 35.670673666199995 139.73924845830007 49.965 35.67066374529855 139.7392064387766 49.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e72b5f9-0931-4a47-8ad9-ff3422123ea2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e72b5f9-0931-4a47-8ad9-ff3422123ea2_0">
											<gml:posList>35.67062884478925 139.73921880741315 48.423 35.67063876569505 139.73926083796619 48.423 35.67063876569505 139.73926083796619 49.965 35.67062884478925 139.73921880741315 49.965 35.67062884478925 139.73921880741315 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e7fef9b-141b-4534-873a-5ca8bd44be2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e7fef9b-141b-4534-873a-5ca8bd44be2e_0">
											<gml:posList>35.67063876569505 139.73926083796619 48.423 35.670673666199995 139.73924845830007 48.423 35.670673666199995 139.73924845830007 49.965 35.67063876569505 139.73926083796619 49.965 35.67063876569505 139.73926083796619 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f634f17e-e31c-4629-b5bd-147ab40c192e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f634f17e-e31c-4629-b5bd-147ab40c192e_0">
											<gml:posList>35.67058281589266 139.73930497829886 48.423 35.67058281589266 139.73930497829886 51.215 35.67073683592527 139.73925038355407 51.215 35.67073683592527 139.73925038355407 48.423 35.67058281589266 139.73930497829886 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22490753-59c3-4edf-920d-2b5fa8176c3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22490753-59c3-4edf-920d-2b5fa8176c3e_0">
											<gml:posList>35.67058281589266 139.73930497829886 48.423 35.670585646563374 139.73931698229384 48.423 35.670585646563374 139.73931698229384 51.215 35.67058281589266 139.73930497829886 51.215 35.67058281589266 139.73930497829886 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-273025b7-dfc8-4830-a6a1-e5a780d0bc12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-273025b7-dfc8-4830-a6a1-e5a780d0bc12_0">
											<gml:posList>35.670585646563374 139.73931698229384 51.215 35.670585646563374 139.73931698229384 48.423 35.67055809921287 139.7393267463722 48.423 35.67055809921287 139.7393267463722 48.953 35.670557846897644 139.73932683503833 48.953 35.670557846897644 139.73932683503833 51.215 35.670585646563374 139.73931698229384 51.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e475d9bd-fba8-4032-b60f-360e35e2945c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e475d9bd-fba8-4032-b60f-360e35e2945c_0">
											<gml:posList>35.67055809921287 139.7393267463722 48.423 35.67057057130281 139.73938075913148 48.423 35.67057057130281 139.73938075913148 48.953 35.67055809921287 139.7393267463722 48.953 35.67055809921287 139.7393267463722 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31a15a40-bb74-45a4-bd8b-d952e4a4ea6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31a15a40-bb74-45a4-bd8b-d952e4a4ea6d_0">
											<gml:posList>35.670806806431074 139.7395468509032 48.423 35.67073683592527 139.73925038355407 48.423 35.67073683592527 139.73925038355407 51.215 35.670806806431074 139.7395468509032 51.215 35.670806806431074 139.7395468509032 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a46882db-bddf-4796-ac77-f4ad85de8cf7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a46882db-bddf-4796-ac77-f4ad85de8cf7_0">
											<gml:posList>35.67062498657623 139.73961129778095 51.215 35.670806806431074 139.7395468509032 51.215 35.67073683592527 139.73925038355407 51.215 35.67058281589266 139.73930497829886 51.215 35.670585646563374 139.73931698229384 51.215 35.670557846897644 139.73932683503833 51.215 35.67062498657623 139.73961129778095 51.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75545eef-3e15-4b93-a49b-6a19367c27c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75545eef-3e15-4b93-a49b-6a19367c27c9_0">
											<gml:posList>35.67057057130281 139.73938075913148 48.423 35.670624878059044 139.7396108450098 48.423 35.670624878059044 139.7396108450098 48.953 35.67062498657623 139.73961129778095 48.953 35.67062498657623 139.73961129778095 51.215 35.670557846897644 139.73932683503833 51.215 35.670557846897644 139.73932683503833 48.953 35.67057057130281 139.73938075913148 48.953 35.67057057130281 139.73938075913148 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51e95ab2-e3d4-4b4a-b168-9430208379bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51e95ab2-e3d4-4b4a-b168-9430208379bf_0">
											<gml:posList>35.670686677552084 139.73958943131464 48.953 35.670686677552084 139.73958943131464 48.423 35.670806806431074 139.7395468509032 48.423 35.670806806431074 139.7395468509032 51.215 35.67062498657623 139.73961129778095 51.215 35.67062498657623 139.73961129778095 48.953 35.670686677552084 139.73958943131464 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74832ad9-41ba-444c-b62a-6e2e061fc924">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74832ad9-41ba-444c-b62a-6e2e061fc924_0">
											<gml:posList>35.67066485217354 139.73959697936257 48.423 35.670686677552084 139.73958943131464 48.423 35.670686677552084 139.73958943131464 48.953 35.67066485217354 139.73959697936257 48.953 35.67066485217354 139.73959697936257 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b854c450-64b9-4e6b-b186-9f59ed4db4ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b854c450-64b9-4e6b-b186-9f59ed4db4ee_0">
											<gml:posList>35.67066385188257 139.7395972787821 48.423 35.67066485217354 139.73959697936257 48.423 35.67066485217354 139.73959697936257 48.953 35.67066385188257 139.7395972787821 48.953 35.67066385188257 139.7395972787821 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9105ae6a-768c-4a47-b804-0bdeeb986bae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9105ae6a-768c-4a47-b804-0bdeeb986bae_0">
											<gml:posList>35.67066385188257 139.7395972787821 48.953 35.670624878059044 139.7396108450098 48.953 35.670624878059044 139.7396108450098 48.423 35.67066385188257 139.7395972787821 48.423 35.67066385188257 139.7395972787821 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b8855757-fcfe-41c1-be27-1f35abc578b8_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6efb5947-6466-4978-9b77-aae6399a7627">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6efb5947-6466-4978-9b77-aae6399a7627_0">
											<gml:posList>35.6707049714548 139.7392030543935 48.423 35.67068703910468 139.73920941602387 48.423 35.67068703910468 139.73920941602387 49.965 35.6707049714548 139.7392030543935 49.965 35.6707049714548 139.7392030543935 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-434473b0-b715-4628-b413-62dc4036d460">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-434473b0-b715-4628-b413-62dc4036d460_0">
											<gml:posList>35.6706850046543 139.7392128096267 48.423 35.67067043348943 139.7392179743075 48.423 35.67067043348943 139.7392179743075 49.965 35.6706850046543 139.7392128096267 49.965 35.6706850046543 139.7392128096267 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b610d5d-94c9-4610-8330-dd31137b437f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b610d5d-94c9-4610-8330-dd31137b437f_0">
											<gml:posList>35.67068803427492 139.7392256308265 48.423 35.6706850046543 139.7392128096267 48.423 35.6706850046543 139.7392128096267 49.965 35.67068803427492 139.7392256308265 49.965 35.67068803427492 139.7392256308265 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a4235c6-9e51-4200-968b-c62883b62d52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a4235c6-9e51-4200-968b-c62883b62d52_0">
											<gml:posList>35.67056228950577 139.7392561004703 48.423 35.67056988624584 139.73928836880265 48.423 35.67056988624584 139.73928836880265 49.733 35.67056228950577 139.7392561004703 49.733 35.67056228950577 139.7392561004703 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f5886d0-d1de-4738-8096-ae5846b2ccfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f5886d0-d1de-4738-8096-ae5846b2ccfb_0">
											<gml:posList>35.67071894751716 139.73917458270085 48.423 35.67054037190233 139.7392378777309 48.423 35.67054037190233 139.7392378777309 51.158 35.67071894751716 139.73917458270085 51.158 35.67071894751716 139.73917458270085 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5000bbf7-22cc-49cf-8d65-a3c2e9012c80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5000bbf7-22cc-49cf-8d65-a3c2e9012c80_0">
											<gml:posList>35.670542761902524 139.7392396202385 48.423 35.67071750774022 139.73917767735736 48.423 35.67071750774022 139.73917767735736 51.158 35.670542761902524 139.7392396202385 51.158 35.670542761902524 139.7392396202385 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae4e2b35-567f-43df-b86e-ef96ea776328">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae4e2b35-567f-43df-b86e-ef96ea776328_0">
											<gml:posList>35.67071894751716 139.73917458270085 48.423 35.67071894751716 139.73917458270085 51.158 35.67073683592527 139.73925038355407 51.158 35.67073683592527 139.73925038355407 48.423 35.67071894751716 139.73917458270085 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e449ae7-c99f-4b8b-8429-4c6197c4f484">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e449ae7-c99f-4b8b-8429-4c6197c4f484_0">
											<gml:posList>35.67071018062704 139.7392251408873 48.423 35.6707049714548 139.7392030543935 48.423 35.6707049714548 139.7392030543935 49.965 35.67071018062704 139.7392251408873 49.965 35.67071018062704 139.7392251408873 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7ea45e2-f69b-4ea1-b44c-dac08a883452">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7ea45e2-f69b-4ea1-b44c-dac08a883452_0">
											<gml:posList>35.67071750774022 139.73917767735736 48.423 35.67073482641766 139.73925109287583 48.423 35.67073482641766 139.73925109287583 51.158 35.67071750774022 139.73917767735736 51.158 35.67071750774022 139.73917767735736 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb16aa07-d38a-4503-849e-09a79fe15393">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb16aa07-d38a-4503-849e-09a79fe15393_0">
											<gml:posList>35.67071018062704 139.7392251408873 49.965 35.6707049714548 139.7392030543935 49.965 35.67068703910468 139.73920941602387 49.965 35.670692248275735 139.73923150251312 49.965 35.67071018062704 139.7392251408873 49.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d23f67c-8a71-4916-b698-c37f0b2a72b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d23f67c-8a71-4916-b698-c37f0b2a72b0_0">
											<gml:posList>35.67068703910468 139.73920941602387 48.423 35.670692248275735 139.73923150251312 48.423 35.670692248275735 139.73923150251312 49.965 35.67068703910468 139.73920941602387 49.965 35.67068703910468 139.73920941602387 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3862246a-0861-4442-acd0-1f53525316a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3862246a-0861-4442-acd0-1f53525316a1_0">
											<gml:posList>35.67067345409577 139.73923079551574 49.965 35.67068803427492 139.7392256308265 49.965 35.6706850046543 139.7392128096267 49.965 35.67067043348943 139.7392179743075 49.965 35.67067345409577 139.73923079551574 49.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35a312b7-88c1-4dad-b00e-a0c2ef15524f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35a312b7-88c1-4dad-b00e-a0c2ef15524f_0">
											<gml:posList>35.67067043348943 139.7392179743075 48.423 35.67067345409577 139.73923079551574 48.423 35.67067345409577 139.73923079551574 49.965 35.67067043348943 139.7392179743075 49.965 35.67067043348943 139.7392179743075 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa5a7a35-4fc0-44d7-bdcd-35f4fa0567c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa5a7a35-4fc0-44d7-bdcd-35f4fa0567c7_0">
											<gml:posList>35.67067345409577 139.73923079551574 48.423 35.67068803427492 139.7392256308265 48.423 35.67068803427492 139.7392256308265 49.965 35.67067345409577 139.73923079551574 49.965 35.67067345409577 139.73923079551574 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2643a433-8c69-4785-9934-44bc7df6adab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2643a433-8c69-4785-9934-44bc7df6adab_0">
											<gml:posList>35.670692248275735 139.73923150251312 48.423 35.67071018062704 139.7392251408873 48.423 35.67071018062704 139.7392251408873 49.965 35.670692248275735 139.73923150251312 49.965 35.670692248275735 139.73923150251312 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d871a1e3-f706-44b0-84d9-c2acfd0c9fed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d871a1e3-f706-44b0-84d9-c2acfd0c9fed_0">
											<gml:posList>35.67071894751716 139.73917458270085 51.158 35.67054037190233 139.7392378777309 51.158 35.67056109094073 139.73932568242114 51.158 35.67056292022613 139.73932503959182 51.158 35.670542761902524 139.7392396202385 51.158 35.67071750774022 139.73917767735736 51.158 35.67073482641766 139.73925109287583 51.158 35.67073683592527 139.73925038355407 51.158 35.67071894751716 139.73917458270085 51.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0e76886-b667-4703-be34-8f281aadd62f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0e76886-b667-4703-be34-8f281aadd62f_0">
											<gml:posList>35.67073482641766 139.73925109287583 48.423 35.67073683592527 139.73925038355407 48.423 35.67073683592527 139.73925038355407 51.158 35.67073482641766 139.73925109287583 51.158 35.67073482641766 139.73925109287583 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-064aa511-c9ba-4f07-9c36-4dc28d9053c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-064aa511-c9ba-4f07-9c36-4dc28d9053c3_0">
											<gml:posList>35.6705837452747 139.73924851963417 48.423 35.67056228950577 139.7392561004703 48.423 35.67056228950577 139.7392561004703 49.733 35.6705837452747 139.73924851963417 49.733 35.6705837452747 139.73924851963417 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4cc3607-37b3-46a5-94ea-6bf0ad5df120">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4cc3607-37b3-46a5-94ea-6bf0ad5df120_0">
											<gml:posList>35.67059133301169 139.73928079903126 48.423 35.6705837452747 139.73924851963417 48.423 35.6705837452747 139.73924851963417 49.733 35.67059133301169 139.73928079903126 49.733 35.67059133301169 139.73928079903126 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96d72967-300a-4ce3-b069-2b83cea893f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96d72967-300a-4ce3-b069-2b83cea893f3_0">
											<gml:posList>35.67056228950577 139.7392561004703 49.733 35.67056988624584 139.73928836880265 49.733 35.67059133301169 139.73928079903126 49.733 35.6705837452747 139.73924851963417 49.733 35.67056228950577 139.7392561004703 49.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c9d4e84-6f32-437b-8c6b-fd9dcfdf2382">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c9d4e84-6f32-437b-8c6b-fd9dcfdf2382_0">
											<gml:posList>35.67054037190233 139.7392378777309 48.423 35.67056109094073 139.73932568242114 48.423 35.67056109094073 139.73932568242114 51.158 35.67054037190233 139.7392378777309 51.158 35.67054037190233 139.7392378777309 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88263046-8e2b-4249-b4ea-f01ec73ad2df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88263046-8e2b-4249-b4ea-f01ec73ad2df_0">
											<gml:posList>35.67056292022613 139.73932503959182 48.423 35.670542761902524 139.7392396202385 48.423 35.670542761902524 139.7392396202385 51.158 35.67056292022613 139.73932503959182 51.158 35.67056292022613 139.73932503959182 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b43963cc-317a-4e5a-8c41-150bff3ae727">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b43963cc-317a-4e5a-8c41-150bff3ae727_0">
											<gml:posList>35.67056988624584 139.73928836880265 48.423 35.67059133301169 139.73928079903126 48.423 35.67059133301169 139.73928079903126 49.733 35.67056988624584 139.73928836880265 49.733 35.67056988624584 139.73928836880265 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4378c78c-a1d1-4b00-a0c8-73b05428ec8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4378c78c-a1d1-4b00-a0c8-73b05428ec8d_0">
											<gml:posList>35.67056109094073 139.73932568242114 48.423 35.67056292022613 139.73932503959182 48.423 35.67056292022613 139.73932503959182 51.158 35.67056109094073 139.73932568242114 51.158 35.67056109094073 139.73932568242114 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-236e3a3f-849e-4654-bbea-328350b9b89a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068703910468 139.73920941602387 48.423 35.6707049714548 139.7392030543935 48.423 35.67071018062704 139.7392251408873 48.423 35.670692248275735 139.73923150251312 48.423 35.67068703910468 139.73920941602387 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a1c8316-228d-4cfa-9632-482781094a80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67067345409577 139.73923079551574 48.423 35.67067043348943 139.7392179743075 48.423 35.6706850046543 139.7392128096267 48.423 35.67068803427492 139.7392256308265 48.423 35.67067345409577 139.73923079551574 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bea8d37-ae9a-4d0e-a558-8ac40c137bcf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073482641766 139.73925109287583 48.423 35.67071750774022 139.73917767735736 48.423 35.670542761902524 139.7392396202385 48.423 35.67056292022613 139.73932503959182 48.423 35.67056109094073 139.73932568242114 48.423 35.67054037190233 139.7392378777309 48.423 35.67071894751716 139.73917458270085 48.423 35.67073683592527 139.73925038355407 48.423 35.67073482641766 139.73925109287583 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8677f887-d86e-42cc-9591-a0a0f5e895c5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059133301169 139.73928079903126 48.423 35.67056988624584 139.73928836880265 48.423 35.67056228950577 139.7392561004703 48.423 35.6705837452747 139.73924851963417 48.423 35.67059133301169 139.73928079903126 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4ac1116f-630e-40ef-a3a6-b5842ed03477">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ac1116f-630e-40ef-a3a6-b5842ed03477">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ac1116f-630e-40ef-a3a6-b5842ed03477">
											<gml:posList>35.67066542593676 139.73960455645263 17.94 35.67061955847197 139.7396205167339 17.94 35.670529839282494 139.739232013471 17.94 35.67072601498738 139.7391639588999 17.94 35.67081573448086 139.7395525734993 17.94 35.67066650732546 139.73960422379952 17.94 35.67066542593676 139.73960455645263 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6abba66c-1b77-40b6-a171-3e39e2de8815">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6abba66c-1b77-40b6-a171-3e39e2de8815">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6abba66c-1b77-40b6-a171-3e39e2de8815">
											<gml:posList>35.67061955847197 139.7396205167339 48.953 35.670623796704724 139.73961122184778 48.953 35.67053742388 139.73923719632123 48.953 35.670529839282494 139.739232013471 48.953 35.67061955847197 139.7396205167339 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d262217c-dd6d-45aa-a5cf-bc193ca94642">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d262217c-dd6d-45aa-a5cf-bc193ca94642">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d262217c-dd6d-45aa-a5cf-bc193ca94642">
											<gml:posList>35.670529839282494 139.739232013471 48.953 35.67053742388 139.73923719632123 48.953 35.67072178579436 139.73917324276454 48.953 35.67072601498738 139.7391639588999 48.953 35.670529839282494 139.739232013471 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4ec8c44-a8e6-48ba-beb8-cbcec1a177f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4ec8c44-a8e6-48ba-beb8-cbcec1a177f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4ec8c44-a8e6-48ba-beb8-cbcec1a177f2">
											<gml:posList>35.67066542593676 139.73960455645263 48.953 35.67066385188257 139.7395972787821 48.953 35.670623796704724 139.73961122184778 48.953 35.67061955847197 139.7396205167339 48.953 35.67066542593676 139.73960455645263 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af00a029-881c-4f97-aa22-ca6e1a446a0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af00a029-881c-4f97-aa22-ca6e1a446a0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af00a029-881c-4f97-aa22-ca6e1a446a0e">
											<gml:posList>35.67066542593676 139.73960455645263 48.953 35.67066650732546 139.73960422379952 48.953 35.67066485217354 139.73959697936257 48.953 35.67066385188257 139.7395972787821 48.953 35.67066542593676 139.73960455645263 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3f463c0-d735-4a7f-bd5d-efc022e88623">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3f463c0-d735-4a7f-bd5d-efc022e88623">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3f463c0-d735-4a7f-bd5d-efc022e88623">
											<gml:posList>35.67066385188257 139.7395972787821 48.423 35.67066485217354 139.73959697936257 48.423 35.670808158902325 139.73954737954443 48.423 35.67072178579436 139.73917324276454 48.423 35.67053742388 139.73923719632123 48.423 35.670623796704724 139.73961122184778 48.423 35.67066385188257 139.7395972787821 48.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cce0216d-036c-49e0-9e3c-43de083bee3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cce0216d-036c-49e0-9e3c-43de083bee3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cce0216d-036c-49e0-9e3c-43de083bee3e">
											<gml:posList>35.67066650732546 139.73960422379952 48.953 35.67081573448086 139.7395525734993 48.953 35.670808158902325 139.73954737954443 48.953 35.67066485217354 139.73959697936257 48.953 35.67066650732546 139.73960422379952 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e53945f0-1df7-4a70-bfde-c88476e9ee07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e53945f0-1df7-4a70-bfde-c88476e9ee07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e53945f0-1df7-4a70-bfde-c88476e9ee07">
											<gml:posList>35.67072601498738 139.7391639588999 48.953 35.67072178579436 139.73917324276454 48.953 35.670808158902325 139.73954737954443 48.953 35.67081573448086 139.7395525734993 48.953 35.67072601498738 139.7391639588999 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efc83b05-deff-43e9-b2fb-94c03af3b834">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efc83b05-deff-43e9-b2fb-94c03af3b834">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efc83b05-deff-43e9-b2fb-94c03af3b834">
											<gml:posList>35.670529839282494 139.739232013471 17.94 35.67061955847197 139.7396205167339 17.94 35.67061955847197 139.7396205167339 48.953 35.670529839282494 139.739232013471 48.953 35.670529839282494 139.739232013471 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ec0d943-3b44-4e8b-a384-952fcd1f76d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ec0d943-3b44-4e8b-a384-952fcd1f76d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ec0d943-3b44-4e8b-a384-952fcd1f76d2">
											<gml:posList>35.670623796704724 139.73961122184778 48.953 35.670623796704724 139.73961122184778 48.423 35.67053742388 139.73923719632123 48.423 35.67053742388 139.73923719632123 48.953 35.670623796704724 139.73961122184778 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2c0b35f-0955-4448-9b32-199a580363a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2c0b35f-0955-4448-9b32-199a580363a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2c0b35f-0955-4448-9b32-199a580363a2">
											<gml:posList>35.67072601498738 139.7391639588999 17.94 35.670529839282494 139.739232013471 17.94 35.670529839282494 139.739232013471 48.953 35.67072601498738 139.7391639588999 48.953 35.67072601498738 139.7391639588999 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d70b21e-798c-4ea7-91ef-f61088e6d77c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d70b21e-798c-4ea7-91ef-f61088e6d77c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d70b21e-798c-4ea7-91ef-f61088e6d77c">
											<gml:posList>35.67053742388 139.73923719632123 48.953 35.67053742388 139.73923719632123 48.423 35.67072178579436 139.73917324276454 48.423 35.67072178579436 139.73917324276454 48.953 35.67053742388 139.73923719632123 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-956ef3ec-4ad1-4a8e-9f86-47ee22a33e18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-956ef3ec-4ad1-4a8e-9f86-47ee22a33e18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-956ef3ec-4ad1-4a8e-9f86-47ee22a33e18">
											<gml:posList>35.67061955847197 139.7396205167339 17.94 35.67066542593676 139.73960455645263 17.94 35.67066542593676 139.73960455645263 48.953 35.67061955847197 139.7396205167339 48.953 35.67061955847197 139.7396205167339 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee441e60-7516-48c2-b658-2afbdcc90998">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee441e60-7516-48c2-b658-2afbdcc90998">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee441e60-7516-48c2-b658-2afbdcc90998">
											<gml:posList>35.67066385188257 139.7395972787821 48.953 35.67066385188257 139.7395972787821 48.423 35.670623796704724 139.73961122184778 48.423 35.670623796704724 139.73961122184778 48.953 35.67066385188257 139.7395972787821 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d59461b-e3c2-490e-8fe9-606bc8e80a67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d59461b-e3c2-490e-8fe9-606bc8e80a67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d59461b-e3c2-490e-8fe9-606bc8e80a67">
											<gml:posList>35.67066485217354 139.73959697936257 48.953 35.67066485217354 139.73959697936257 48.423 35.67066385188257 139.7395972787821 48.423 35.67066385188257 139.7395972787821 48.953 35.67066485217354 139.73959697936257 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49d60e53-46d7-4c0d-adea-4829e50d5456">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49d60e53-46d7-4c0d-adea-4829e50d5456">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49d60e53-46d7-4c0d-adea-4829e50d5456">
											<gml:posList>35.67066542593676 139.73960455645263 17.94 35.67066650732546 139.73960422379952 17.94 35.67066650732546 139.73960422379952 48.953 35.67066542593676 139.73960455645263 48.953 35.67066542593676 139.73960455645263 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-850b16c6-951e-4f88-b187-6ce16bfaff9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-850b16c6-951e-4f88-b187-6ce16bfaff9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-850b16c6-951e-4f88-b187-6ce16bfaff9a">
											<gml:posList>35.670808158902325 139.73954737954443 48.953 35.670808158902325 139.73954737954443 48.423 35.67066485217354 139.73959697936257 48.423 35.67066485217354 139.73959697936257 48.953 35.670808158902325 139.73954737954443 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54d7a98c-611f-4511-88bf-335804eb6a7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54d7a98c-611f-4511-88bf-335804eb6a7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54d7a98c-611f-4511-88bf-335804eb6a7d">
											<gml:posList>35.67066650732546 139.73960422379952 17.94 35.67081573448086 139.7395525734993 17.94 35.67081573448086 139.7395525734993 48.953 35.67066650732546 139.73960422379952 48.953 35.67066650732546 139.73960422379952 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cbd3e2e-ba5c-4e76-a039-dfaaf34b0480">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cbd3e2e-ba5c-4e76-a039-dfaaf34b0480">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cbd3e2e-ba5c-4e76-a039-dfaaf34b0480">
											<gml:posList>35.67072178579436 139.73917324276454 48.953 35.67072178579436 139.73917324276454 48.423 35.670808158902325 139.73954737954443 48.423 35.670808158902325 139.73954737954443 48.953 35.67072178579436 139.73917324276454 48.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e5bf041-f064-46ce-bf6d-3199a228f787">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e5bf041-f064-46ce-bf6d-3199a228f787">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e5bf041-f064-46ce-bf6d-3199a228f787">
											<gml:posList>35.67081573448086 139.7395525734993 17.94 35.67072601498738 139.7391639588999 17.94 35.67072601498738 139.7391639588999 48.953 35.67081573448086 139.7395525734993 48.953 35.67081573448086 139.7395525734993 17.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1711</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">826.7756</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>