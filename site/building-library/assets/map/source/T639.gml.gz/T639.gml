<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b8fa1109-5ab2-4806-8cc6-3be1e987dae6">
			<core:creationDate>2023-08-22</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">32.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668754871949616 139.74819360255472 0 35.668781237485575 139.74811129371244 0 35.668627724685706 139.74803759987833 0 35.66862383292541 139.74804957569276 0 35.668592282248646 139.74803444086436 0 35.66856974720812 139.7481047318255 0 35.6686291318381 139.74813324475485 0 35.66868642546336 139.74816075034065 0 35.668754871949616 139.74819360255472 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668754871949616 139.74819360255472 5.429 35.66868642546336 139.74816075034065 5.429 35.6686291318381 139.74813324475485 5.429 35.66856974720812 139.7481047318255 5.429 35.668592282248646 139.74803444086436 5.429 35.66862383292541 139.74804957569276 5.429 35.668627724685706 139.74803759987833 5.429 35.668781237485575 139.74811129371244 5.429 35.668754871949616 139.74819360255472 5.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668754871949616 139.74819360255472 5.429 35.668781237485575 139.74811129371244 5.429 35.668781237485575 139.74811129371244 35.749 35.668754871949616 139.74819360255472 35.749 35.668754871949616 139.74819360255472 5.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668781237485575 139.74811129371244 5.429 35.668627724685706 139.74803759987833 5.429 35.668627724685706 139.74803759987833 35.749 35.668781237485575 139.74811129371244 35.749 35.668781237485575 139.74811129371244 5.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668627724685706 139.74803759987833 5.429 35.66862383292541 139.74804957569276 5.429 35.66862383292541 139.74804957569276 35.749 35.668627724685706 139.74803759987833 35.749 35.668627724685706 139.74803759987833 5.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862383292541 139.74804957569276 5.429 35.668592282248646 139.74803444086436 5.429 35.668592282248646 139.74803444086436 35.749 35.66862383292541 139.74804957569276 35.749 35.66862383292541 139.74804957569276 5.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668592282248646 139.74803444086436 5.429 35.66856974720812 139.7481047318255 5.429 35.66856974720812 139.7481047318255 35.749 35.668592282248646 139.74803444086436 35.749 35.668592282248646 139.74803444086436 5.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856974720812 139.7481047318255 5.429 35.6686291318381 139.74813324475485 5.429 35.6686291318381 139.74813324475485 35.749 35.66856974720812 139.7481047318255 35.749 35.66856974720812 139.7481047318255 5.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686291318381 139.74813324475485 5.429 35.66868642546336 139.74816075034065 5.429 35.66868642546336 139.74816075034065 35.749 35.6686291318381 139.74813324475485 35.749 35.6686291318381 139.74813324475485 5.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868642546336 139.74816075034065 5.429 35.668754871949616 139.74819360255472 5.429 35.668754871949616 139.74819360255472 35.749 35.66868642546336 139.74816075034065 35.749 35.66868642546336 139.74816075034065 5.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668754871949616 139.74819360255472 35.749 35.668781237485575 139.74811129371244 35.749 35.668627724685706 139.74803759987833 35.749 35.66862383292541 139.74804957569276 35.749 35.668592282248646 139.74803444086436 35.749 35.66856974720812 139.7481047318255 35.749 35.6686291318381 139.74813324475485 35.749 35.66868642546336 139.74816075034065 35.749 35.668754871949616 139.74819360255472 35.749</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p1002_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p1002_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p1002_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p1002_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p1002_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p995_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p995_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p995_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p995_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p995_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p995_5"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p995_6"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p995_7"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p995_8"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p995_9"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p1001_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p1001_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p1000_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p1000_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p1000_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p996_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p996_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_p996_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0162_b_0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gnd_TMmnt0162_b_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_b_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_b_0">
											<gml:posList>35.66862393977627 139.7480496273199 5.51732194 35.66862778107397 139.74803761267987 5.5174111 35.66878123761733 139.74811129367563 5.52500518 35.66875491816665 139.74819361392383 5.52439852 35.66856986113904 139.74810475975045 5.5152472 35.66859233903185 139.74803445449282 5.51576464 35.66862393977627 139.7480496273199 5.51732194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0162_p1001_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p1001_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p1001_0">
											<gml:posList>35.66868641963246 139.7481607491807 33.02996121 35.668695962481756 139.7481309017618 33.03018001 35.66868888553165 139.74812750380678 33.02982972 35.66868511383763 139.74813930071818 33.02974309 35.668634908268054 139.74811519486576 33.02726125 35.66862913719815 139.74813324531937 33.0271291 35.66868641963246 139.7481607491807 33.02996121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0162_p1000_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p1000_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p1000_0">
											<gml:posList>35.66876436922721 139.74816374420044 30.04357144 35.668695973648695 139.74813090444175 30.04018028 35.668686430794985 139.7481607518746 30.03996148 35.66875482636661 139.74819359170644 30.04335264 35.66876436922721 139.74816374420044 30.04357144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0162_p1002_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p1002_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p1002_0">
											<gml:posList>35.66865666097703 139.74809365917451 37.97810221 35.66868502532425 139.7481072781573 37.97950449 35.66869287689074 139.7480827205711 37.97968607 35.668664512423206 139.7480691015283 37.97828379 35.66865666097703 139.74809365917451 37.97810221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0162_p995_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p995_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p995_0">
											<gml:posList>35.66868503195046 139.74810727974165 36.20450465 35.6686939671284 139.74811156991953 36.20494676 35.6686946004829 139.7481095889443 36.20496137 35.66872728514093 139.74812528225925 36.20658011 35.6687383347033 139.74809072194833 36.20683602 35.668627666805634 139.74803758562612 36.2013647 35.66862382552647 139.74804960020833 36.20127554 35.668592224934606 139.7480344274543 36.19971826 35.66856974715027 139.7481047323739 36.19920081 35.66862912537363 139.74813324247248 36.20212882 35.66863489644066 139.74811519202777 36.20226097 35.66865666759523 139.74809366075516 36.20310237 35.668664519043645 139.74806910310207 36.20328395 35.668692883519114 139.74808272214858 36.20468623 35.66868503195046 139.74810727974165 36.20450465</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0162_p996_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p996_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p996_0">
											<gml:posList>35.6687383450483 139.7480907244092 33.44183627 35.668727295481155 139.74812528473518 33.44158036 35.66869461080898 139.74810959141325 33.43996162 35.66868888400086 139.74812750343958 33.43982968 35.66876435649242 139.74816374113541 33.44357114 35.66878113297206 139.74811126873743 33.44395899 35.6687383450483 139.7480907244092 33.44183627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0162_p995_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p995_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p995_1">
											<gml:posList>35.66865666759523 139.74809366075516 36.20310237 35.66863489644066 139.74811519202777 36.20226097 35.668685101985176 139.7481392978683 36.2047428 35.6686939671284 139.74811156991953 36.20494676 35.66868503195046 139.74810727974165 36.20450465 35.66865666759523 139.74809366075516 36.20310237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p1000_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p1000_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p1000_2">
											<gml:posList>35.66868641963246 139.7481607491807 33.02996121 35.66862913719815 139.74813324531937 33.0271291 35.66862912537363 139.74813324247248 36.20212882 35.66856974715027 139.7481047323739 36.19920081 35.66856986113904 139.74810475975045 5.5152472 35.66875491816665 139.74819361392383 5.52439852 35.66875482636661 139.74819359170644 30.04335264 35.668686430794985 139.7481607518746 30.03996148 35.66868641963246 139.7481607491807 33.02996121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p995_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p995_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p995_4">
											<gml:posList>35.66856974715027 139.7481047323739 36.19920081 35.668592224934606 139.7480344274543 36.19971826 35.66859233903185 139.74803445449282 5.51576464 35.66856986113904 139.74810475975045 5.5152472 35.66856974715027 139.7481047323739 36.19920081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p995_7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p995_7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p995_7">
											<gml:posList>35.668685101985176 139.7481392978683 36.2047428 35.66868511383763 139.74813930071818 33.02974309 35.66868888553165 139.74812750380678 33.02982972 35.66868888400086 139.74812750343958 33.43982968 35.66869461080898 139.74810959141325 33.43996162 35.6686946004829 139.7481095889443 36.20496137 35.6686939671284 139.74811156991953 36.20494676 35.668685101985176 139.7481392978683 36.2047428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p995_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p995_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p995_2">
											<gml:posList>35.668592224934606 139.7480344274543 36.19971826 35.66862382552647 139.74804960020833 36.20127554 35.66862393977627 139.7480496273199 5.51732194 35.66859233903185 139.74803445449282 5.51576464 35.668592224934606 139.7480344274543 36.19971826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p995_6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p995_6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p995_6">
											<gml:posList>35.6686946004829 139.7481095889443 36.20496137 35.66869461080898 139.74810959141325 33.43996162 35.668727295481155 139.74812528473518 33.44158036 35.66872728514093 139.74812528225925 36.20658011 35.6686946004829 139.7481095889443 36.20496137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p1002_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p1002_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p1002_1">
											<gml:posList>35.66869287689074 139.7480827205711 37.97968607 35.668692883519114 139.74808272214858 36.20468623 35.668664519043645 139.74806910310207 36.20328395 35.668664512423206 139.7480691015283 37.97828379 35.66869287689074 139.7480827205711 37.97968607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p996_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p996_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p996_1">
											<gml:posList>35.66878123761733 139.74811129367563 5.52500518 35.66862778107397 139.74803761267987 5.5174111 35.668627666805634 139.74803758562612 36.2013647 35.6687383347033 139.74809072194833 36.20683602 35.6687383450483 139.7480907244092 33.44183627 35.66878113297206 139.74811126873743 33.44395899 35.66878123761733 139.74811129367563 5.52500518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p995_8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p995_8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p995_8">
											<gml:posList>35.66863489644066 139.74811519202777 36.20226097 35.668634908268054 139.74811519486576 33.02726125 35.66868511383763 139.74813930071818 33.02974309 35.668685101985176 139.7481392978683 36.2047428 35.66863489644066 139.74811519202777 36.20226097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p995_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p995_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p995_3">
											<gml:posList>35.66862382552647 139.74804960020833 36.20127554 35.668627666805634 139.74803758562612 36.2013647 35.66862778107397 139.74803761267987 5.5174111 35.66862393977627 139.7480496273199 5.51732194 35.66862382552647 139.74804960020833 36.20127554</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p995_9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p995_9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p995_9">
											<gml:posList>35.66862912537363 139.74813324247248 36.20212882 35.66862913719815 139.74813324531937 33.0271291 35.668634908268054 139.74811519486576 33.02726125 35.66863489644066 139.74811519202777 36.20226097 35.66862912537363 139.74813324247248 36.20212882</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p996_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p996_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p996_2">
											<gml:posList>35.668695962481756 139.7481309017618 33.03018001 35.668695973648695 139.74813090444175 30.04018028 35.66876436922721 139.74816374420044 30.04357144 35.66876435649242 139.74816374113541 33.44357114 35.66868888400086 139.74812750343958 33.43982968 35.66868888553165 139.74812750380678 33.02982972 35.668695962481756 139.7481309017618 33.03018001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p1001_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p1001_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p1001_1">
											<gml:posList>35.66868641963246 139.7481607491807 33.02996121 35.668686430794985 139.7481607518746 30.03996148 35.668695973648695 139.74813090444175 30.04018028 35.668695962481756 139.7481309017618 33.03018001 35.66868641963246 139.7481607491807 33.02996121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p1002_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p1002_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p1002_4">
											<gml:posList>35.668664512423206 139.7480691015283 37.97828379 35.668664519043645 139.74806910310207 36.20328395 35.66865666759523 139.74809366075516 36.20310237 35.66865666097703 139.74809365917451 37.97810221 35.668664512423206 139.7480691015283 37.97828379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p1002_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p1002_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p1002_3">
											<gml:posList>35.66865666097703 139.74809365917451 37.97810221 35.66865666759523 139.74809366075516 36.20310237 35.66868503195046 139.74810727974165 36.20450465 35.66868502532425 139.7481072781573 37.97950449 35.66865666097703 139.74809365917451 37.97810221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p1000_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p1000_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p1000_1">
											<gml:posList>35.66875491816665 139.74819361392383 5.52439852 35.66878123761733 139.74811129367563 5.52500518 35.66878113297206 139.74811126873743 33.44395899 35.66876435649242 139.74816374113541 33.44357114 35.66876436922721 139.74816374420044 30.04357144 35.66875482636661 139.74819359170644 30.04335264 35.66875491816665 139.74819361392383 5.52439852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p1002_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p1002_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p1002_2">
											<gml:posList>35.66868502532425 139.7481072781573 37.97950449 35.66868503195046 139.74810727974165 36.20450465 35.668692883519114 139.74808272214858 36.20468623 35.66869287689074 139.7480827205711 37.97968607 35.66868502532425 139.7481072781573 37.97950449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0162_p995_5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0162_p995_5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0162_p995_5">
											<gml:posList>35.66872728514093 139.74812528225925 36.20658011 35.668727295481155 139.74812528473518 33.44158036 35.6687383450483 139.7480907244092 33.44183627 35.6687383347033 139.74809072194833 36.20683602 35.66872728514093 139.74812528225925 36.20658011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">179.89655</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">9</uro:districtsAndZonesType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.33</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2412800000</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>