<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ba3ecd19-9069-4e23-888a-c66e52e88b40">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">22.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668544727855014 139.74868113135028 0 35.66855336340345 139.74865604779401 0 35.66852955892872 139.74864436416712 0 35.668585146963835 139.748478394341 0 35.66854056178986 139.74846099987928 0 35.66847809372971 139.74864894738363 0 35.668544727855014 139.74868113135028 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668544727855014 139.74868113135028 5.56 35.66847809372971 139.74864894738363 5.56 35.66854056178986 139.74846099987928 5.56 35.668585146963835 139.748478394341 5.56 35.66852955892872 139.74864436416712 5.56 35.66855336340345 139.74865604779401 5.56 35.668544727855014 139.74868113135028 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668544727855014 139.74868113135028 5.56 35.66855336340345 139.74865604779401 5.56 35.66855336340345 139.74865604779401 28.07 35.668544727855014 139.74868113135028 28.07 35.668544727855014 139.74868113135028 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855336340345 139.74865604779401 5.56 35.66852955892872 139.74864436416712 5.56 35.66852955892872 139.74864436416712 28.07 35.66855336340345 139.74865604779401 28.07 35.66855336340345 139.74865604779401 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852955892872 139.74864436416712 5.56 35.668585146963835 139.748478394341 5.56 35.668585146963835 139.748478394341 28.07 35.66852955892872 139.74864436416712 28.07 35.66852955892872 139.74864436416712 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668585146963835 139.748478394341 5.56 35.66854056178986 139.74846099987928 5.56 35.66854056178986 139.74846099987928 28.07 35.668585146963835 139.748478394341 28.07 35.668585146963835 139.748478394341 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854056178986 139.74846099987928 5.56 35.66847809372971 139.74864894738363 5.56 35.66847809372971 139.74864894738363 28.07 35.66854056178986 139.74846099987928 28.07 35.66854056178986 139.74846099987928 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847809372971 139.74864894738363 5.56 35.668544727855014 139.74868113135028 5.56 35.668544727855014 139.74868113135028 28.07 35.66847809372971 139.74864894738363 28.07 35.66847809372971 139.74864894738363 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668544727855014 139.74868113135028 28.07 35.66855336340345 139.74865604779401 28.07 35.66852955892872 139.74864436416712 28.07 35.668585146963835 139.748478394341 28.07 35.66854056178986 139.74846099987928 28.07 35.66847809372971 139.74864894738363 28.07 35.668544727855014 139.74868113135028 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-cdb25c59-fc51-44bb-b194-614ba043c4bb"/>
							<gml:surfaceMember xlink:href="#poly-cf22b865-ab4b-4f77-9818-d0e438d1e8d0"/>
							<gml:surfaceMember xlink:href="#poly-77715c13-7085-418a-8d7f-3c3e17684c04"/>
							<gml:surfaceMember xlink:href="#poly-71efb7d0-5664-4cef-b441-f9824afba52c"/>
							<gml:surfaceMember xlink:href="#poly-cb1c3997-be6c-4c97-97ce-38165519bd00"/>
							<gml:surfaceMember xlink:href="#poly-bee93f35-9451-4988-a32e-1cd3705c85ef"/>
							<gml:surfaceMember xlink:href="#poly-cc332654-06d9-4860-975d-e5dfb6a851ff"/>
							<gml:surfaceMember xlink:href="#poly-076b0fda-8e6c-4987-a5d5-bb74db448e91"/>
							<gml:surfaceMember xlink:href="#poly-d482b22d-ecae-41c9-91f5-0b061db1ccc7"/>
							<gml:surfaceMember xlink:href="#poly-69d67f9d-8070-4f12-a00c-e196cb2d3c9e"/>
							<gml:surfaceMember xlink:href="#poly-e4120d95-a2fc-4e73-b90a-8246d1a28b45"/>
							<gml:surfaceMember xlink:href="#poly-358d068d-ff3f-47b2-9293-e2de3d470e1d"/>
							<gml:surfaceMember xlink:href="#poly-a8a1dada-6d7b-4a2d-9f4f-fba9dec699ff"/>
							<gml:surfaceMember xlink:href="#poly-1bc0e02f-c25e-45c8-9d17-9c84102b15d2"/>
							<gml:surfaceMember xlink:href="#poly-8a435de3-74b8-48c5-a66d-2fdd93589f91"/>
							<gml:surfaceMember xlink:href="#poly-bb28ced9-fbf6-4c18-baad-fc333cbd45dd"/>
							<gml:surfaceMember xlink:href="#poly-924483e2-a1d8-45f5-934f-2c1d93868f84"/>
							<gml:surfaceMember xlink:href="#poly-089d456a-9309-4b93-9f51-d97f0b5f96d9"/>
							<gml:surfaceMember xlink:href="#poly-78c4a680-22b1-4cba-881f-9cb39da46ce5"/>
							<gml:surfaceMember xlink:href="#poly-177db959-e6d4-4020-a0b4-10f763096dec"/>
							<gml:surfaceMember xlink:href="#poly-168a4bc8-7b3b-4034-946b-ea96d766c05e"/>
							<gml:surfaceMember xlink:href="#poly-ecbde8f1-b2e0-4c30-8190-c034a0e19f07"/>
							<gml:surfaceMember xlink:href="#poly-d1e5ce92-75e4-4e1b-b3eb-16fdfd01d940"/>
							<gml:surfaceMember xlink:href="#poly-1fa0d02c-2f63-46ef-9303-8116bc2b8c34"/>
							<gml:surfaceMember xlink:href="#poly-79cf2298-c3ec-44b9-80b5-6ba9aff85fa3"/>
							<gml:surfaceMember xlink:href="#poly-210baebb-2ca5-4f37-a9c3-7ebd694ffc6f"/>
							<gml:surfaceMember xlink:href="#poly-fb3d2c2c-ebd5-4818-8e55-7d467a046215"/>
							<gml:surfaceMember xlink:href="#poly-0acbfc27-65af-43aa-91c0-cfb825a65e96"/>
							<gml:surfaceMember xlink:href="#poly-68fbdfe3-e637-49d1-864b-7252e2e93152"/>
							<gml:surfaceMember xlink:href="#poly-5361cb13-0c7f-42fc-805b-d43381ebb767"/>
							<gml:surfaceMember xlink:href="#poly-63a92a1f-428c-45a4-8f46-d600017ca544"/>
							<gml:surfaceMember xlink:href="#poly-8a908d5a-7618-4cd8-9932-354a273daf0a"/>
							<gml:surfaceMember xlink:href="#poly-129e3079-b5d9-402b-8d1e-9dfa8136dd9a"/>
							<gml:surfaceMember xlink:href="#poly-53dba8e0-8bc5-4183-a465-3a26eee7c32f"/>
							<gml:surfaceMember xlink:href="#poly-8798a067-e8cd-45ee-9552-e78885d198de"/>
							<gml:surfaceMember xlink:href="#poly-43f403bb-1ada-437a-ab6f-1740b731166f"/>
							<gml:surfaceMember xlink:href="#poly-2819f645-8ea0-4b17-b707-a514d0001bbe"/>
							<gml:surfaceMember xlink:href="#poly-18641f66-79d7-45d4-adbd-a8a7fc3ddaa5"/>
							<gml:surfaceMember xlink:href="#poly-6d0bfe8c-1c23-4662-82ef-506911ee55a2"/>
							<gml:surfaceMember xlink:href="#poly-315c1448-5134-4873-92dc-02043ac68ab1"/>
							<gml:surfaceMember xlink:href="#poly-162b4337-117a-416a-ade1-3505fd06be2f"/>
							<gml:surfaceMember xlink:href="#poly-24e41371-56e9-4a25-881b-93744dac2d75"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ba3ecd19-9069-4e23-888a-c66e52e88b40_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0b3a7c3-a4cf-4b7b-9e22-ed7544c3ec3d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6685634687627 139.74847815217808 27.761 35.66857492924214 139.74848386188378 27.761 35.6685662404176 139.7485100390767 27.761 35.66855477993938 139.7485043293679 27.761 35.6685634687627 139.74847815217808 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78eac434-eab9-41a1-8b97-5b41289958cd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668520005657186 139.74855652538773 27.761 35.66853000492935 139.7485608448497 27.761 35.668525059446935 139.74857799347745 27.761 35.6685150691891 139.7485736740041 27.761 35.668520005657186 139.74855652538773 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33ac60df-08ff-4cda-9c39-d8208de81340">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33ac60df-08ff-4cda-9c39-d8208de81340_0">
											<gml:posList>35.66857492924214 139.74848386188378 27.761 35.6685634687627 139.74847815217808 27.761 35.6685634687627 139.74847815217808 30.011 35.66857492924214 139.74848386188378 30.011 35.66857492924214 139.74848386188378 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00050403-a324-4346-a506-89aef64b3bd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00050403-a324-4346-a506-89aef64b3bd5_0">
											<gml:posList>35.6685634687627 139.74847815217808 27.761 35.66855477993938 139.7485043293679 27.761 35.66855477993938 139.7485043293679 30.011 35.6685634687627 139.74847815217808 30.011 35.6685634687627 139.74847815217808 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-361aa28c-890e-4360-bebf-340495f8df76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-361aa28c-890e-4360-bebf-340495f8df76_0">
											<gml:posList>35.6685662404176 139.7485100390767 30.011 35.66857492924214 139.74848386188378 30.011 35.6685634687627 139.74847815217808 30.011 35.66855477993938 139.7485043293679 30.011 35.6685662404176 139.7485100390767 30.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-170f4bff-98ad-485d-b550-cb0170c4a1cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-170f4bff-98ad-485d-b550-cb0170c4a1cb_0">
											<gml:posList>35.6685662404176 139.7485100390767 27.761 35.66857492924214 139.74848386188378 27.761 35.66857492924214 139.74848386188378 30.011 35.6685662404176 139.7485100390767 30.011 35.6685662404176 139.7485100390767 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-823e2867-ebe1-4c9f-8ce2-1bf2d29bfb59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-823e2867-ebe1-4c9f-8ce2-1bf2d29bfb59_0">
											<gml:posList>35.6685662404176 139.7485100390767 27.761 35.6685662404176 139.7485100390767 30.011 35.66855477993938 139.7485043293679 30.011 35.66855477993938 139.7485043293679 27.761 35.6685662404176 139.7485100390767 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9914e4c-7117-4938-ba72-f6022a288dfc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9914e4c-7117-4938-ba72-f6022a288dfc_0">
											<gml:posList>35.66853000492935 139.7485608448497 27.761 35.668520005657186 139.74855652538773 27.761 35.668520005657186 139.74855652538773 29.925 35.66853000492935 139.7485608448497 29.925 35.66853000492935 139.7485608448497 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84b9c927-8053-48d0-b650-3d56cd7cd88d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84b9c927-8053-48d0-b650-3d56cd7cd88d_0">
											<gml:posList>35.6685150691891 139.7485736740041 27.761 35.6685150691891 139.7485736740041 29.925 35.668520005657186 139.74855652538773 29.925 35.668520005657186 139.74855652538773 27.761 35.6685150691891 139.7485736740041 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab67b0db-0cea-43d8-b186-0c9caf04b1db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab67b0db-0cea-43d8-b186-0c9caf04b1db_0">
											<gml:posList>35.668525059446935 139.74857799347745 29.925 35.66853000492935 139.7485608448497 29.925 35.668520005657186 139.74855652538773 29.925 35.6685150691891 139.7485736740041 29.925 35.668525059446935 139.74857799347745 29.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-566d787c-9d64-437f-9b6c-d6bfa991b3ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-566d787c-9d64-437f-9b6c-d6bfa991b3ea_0">
											<gml:posList>35.668525059446935 139.74857799347745 27.761 35.66853000492935 139.7485608448497 27.761 35.66853000492935 139.7485608448497 29.925 35.668525059446935 139.74857799347745 29.925 35.668525059446935 139.74857799347745 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0604e8ea-dd52-46a4-ba0e-00ea574cbdda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0604e8ea-dd52-46a4-ba0e-00ea574cbdda_0">
											<gml:posList>35.668525059446935 139.74857799347745 27.761 35.668525059446935 139.74857799347745 29.925 35.6685150691891 139.7485736740041 29.925 35.6685150691891 139.7485736740041 27.761 35.668525059446935 139.74857799347745 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ba3ecd19-9069-4e23-888a-c66e52e88b40_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8e4c756-1efc-4bd9-b74a-709a3f0f6439">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8e4c756-1efc-4bd9-b74a-709a3f0f6439_0">
											<gml:posList>35.668519313297715 139.74863579224348 27.761 35.668519313297715 139.74863579224348 28.2 35.66851712219274 139.7486347010036 28.2 35.66851712219274 139.7486347010036 27.761 35.668519313297715 139.74863579224348 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dc5b750-88a2-4e2d-84fc-b2fcb6232c46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dc5b750-88a2-4e2d-84fc-b2fcb6232c46_0">
											<gml:posList>35.66847891413427 139.74864916743712 31.722 35.66848898818922 139.7486188465744 31.722 35.66848898818922 139.7486188465744 28.2 35.66847891413427 139.74864916743712 28.2 35.66847891413427 139.74864916743712 31.722</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce15b880-3c0b-4f04-908e-3a5f95d443cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce15b880-3c0b-4f04-908e-3a5f95d443cd_0">
											<gml:posList>35.668490656296086 139.74861965117003 28.2 35.668490656296086 139.74861965117003 27.761 35.66848150868173 139.74864716537115 27.761 35.66848150868173 139.74864716537115 28.2 35.668490656296086 139.74861965117003 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-603e6e0d-69f7-4362-959c-c0547217e6b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-603e6e0d-69f7-4362-959c-c0547217e6b7_0">
											<gml:posList>35.66851003076895 139.74866372634318 28.2 35.66851003076895 139.74866372634318 31.722 35.66847891413427 139.74864916743712 31.722 35.66847891413427 139.74864916743712 28.2 35.66851003076895 139.74866372634318 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df0c6289-4527-44e2-85bd-6ed98a3487d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df0c6289-4527-44e2-85bd-6ed98a3487d8_0">
											<gml:posList>35.66848150868173 139.74864716537115 27.761 35.6685086131671 139.74866024834935 27.761 35.6685086131671 139.74866024834935 28.2 35.66848150868173 139.74864716537115 28.2 35.66848150868173 139.74864716537115 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18560c5d-d2bc-47d0-b8e4-a7329a16a118">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18560c5d-d2bc-47d0-b8e4-a7329a16a118_0">
											<gml:posList>35.66851003076895 139.74866372634318 31.722 35.66851996091864 139.7486338474627 31.722 35.66848898818922 139.7486188465744 31.722 35.66847891413427 139.74864916743712 31.722 35.66851003076895 139.74866372634318 31.722</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e2f9bdc-3238-4a7d-b253-73a8a2f40076">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e2f9bdc-3238-4a7d-b253-73a8a2f40076_0">
											<gml:posList>35.668490656296086 139.74861965117003 28.2 35.66848898818922 139.7486188465744 28.2 35.66848898818922 139.7486188465744 31.722 35.66851996091864 139.7486338474627 31.722 35.66851996091864 139.7486338474627 27.761 35.668490656296086 139.74861965117003 27.761 35.668490656296086 139.74861965117003 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21daa9aa-d82c-4b19-bcc2-8ba18be5e141">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21daa9aa-d82c-4b19-bcc2-8ba18be5e141_0">
											<gml:posList>35.6685086131671 139.74866024834935 28.2 35.6685086131671 139.74866024834935 27.761 35.66851712219274 139.7486347010036 27.761 35.66851712219274 139.7486347010036 28.2 35.6685086131671 139.74866024834935 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cee98d9-1ec2-4e37-9811-4fa1e6e075b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cee98d9-1ec2-4e37-9811-4fa1e6e075b6_0">
											<gml:posList>35.66851996091864 139.7486338474627 27.761 35.66851996091864 139.7486338474627 31.722 35.66851003076895 139.74866372634318 31.722 35.66851003076895 139.74866372634318 28.2 35.668519313297715 139.74863579224348 28.2 35.668519313297715 139.74863579224348 27.761 35.66851996091864 139.7486338474627 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad5a1897-b6d2-4c7f-b6cc-fa99b3195026">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851712219274 139.7486347010036 27.761 35.6685086131671 139.74866024834935 27.761 35.66848150868173 139.74864716537115 27.761 35.668490656296086 139.74861965117003 27.761 35.66851996091864 139.7486338474627 27.761 35.668519313297715 139.74863579224348 27.761 35.66851712219274 139.7486347010036 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02004c2a-8cff-41be-8739-6229cefa6a00">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848150868173 139.74864716537115 28.2 35.6685086131671 139.74866024834935 28.2 35.66851712219274 139.7486347010036 28.2 35.668519313297715 139.74863579224348 28.2 35.66851003076895 139.74866372634318 28.2 35.66847891413427 139.74864916743712 28.2 35.66848898818922 139.7486188465744 28.2 35.668490656296086 139.74861965117003 28.2 35.66848150868173 139.74864716537115 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-cdb25c59-fc51-44bb-b194-614ba043c4bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdb25c59-fc51-44bb-b194-614ba043c4bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdb25c59-fc51-44bb-b194-614ba043c4bb">
											<gml:posList>35.6684780937297 139.7486489473836 5.56 35.66854056178984 139.74846099987928 5.56 35.668585146963835 139.748478394341 5.56 35.66852955892871 139.74864436416712 5.56 35.668553363403454 139.748656047794 5.56 35.66854472785501 139.74868113135028 5.56 35.6684780937297 139.7486489473836 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf22b865-ab4b-4f77-9818-d0e438d1e8d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf22b865-ab4b-4f77-9818-d0e438d1e8d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf22b865-ab4b-4f77-9818-d0e438d1e8d0">
											<gml:posList>35.668543059285234 139.74846198033038 28.2 35.66854206987725 139.7484649637995 28.2 35.66858166006022 139.74848039735932 28.2 35.668585146963835 139.748478394341 28.2 35.668543059285234 139.74846198033038 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77715c13-7085-418a-8d7f-3c3e17684c04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77715c13-7085-418a-8d7f-3c3e17684c04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77715c13-7085-418a-8d7f-3c3e17684c04">
											<gml:posList>35.66854056178984 139.74846099987928 28.2 35.66851947829269 139.74852443730404 28.2 35.66852288426025 139.7485226994789 28.2 35.66854206987725 139.7484649637995 28.2 35.668543059285234 139.74846198033038 28.2 35.66854056178984 139.74846099987928 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71efb7d0-5664-4cef-b441-f9824afba52c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71efb7d0-5664-4cef-b441-f9824afba52c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71efb7d0-5664-4cef-b441-f9824afba52c">
											<gml:posList>35.66854972098399 139.74853952730163 28.2 35.66855312695174 139.74853778947647 28.2 35.66852288426025 139.7485226994789 28.2 35.66851947829269 139.74852443730404 28.2 35.66854972098399 139.74853952730163 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb1c3997-be6c-4c97-97ce-38165519bd00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb1c3997-be6c-4c97-97ce-38165519bd00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb1c3997-be6c-4c97-97ce-38165519bd00">
											<gml:posList>35.668544180163124 139.74855605798794 24.7 35.66854972098399 139.74853952730163 24.7 35.66851947829269 139.74852443730404 24.7 35.668513784668306 139.74854157567697 24.7 35.668544180163124 139.74855605798794 24.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bee93f35-9451-4988-a32e-1cd3705c85ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bee93f35-9451-4988-a32e-1cd3705c85ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bee93f35-9451-4988-a32e-1cd3705c85ef">
											<gml:posList>35.668544180163124 139.74855605798794 28.2 35.668545616246476 139.74856017663038 28.2 35.66855312695174 139.74853778947647 28.2 35.66854972098399 139.74853952730163 28.2 35.668544180163124 139.74855605798794 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc332654-06d9-4860-975d-e5dfb6a851ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc332654-06d9-4860-975d-e5dfb6a851ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc332654-06d9-4860-975d-e5dfb6a851ff">
											<gml:posList>35.668544180163124 139.74855605798794 28.2 35.668513784668306 139.74854157567697 28.2 35.66851523878737 139.7485457053445 28.2 35.668545616246476 139.74856017663038 28.2 35.668544180163124 139.74855605798794 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-076b0fda-8e6c-4987-a5d5-bb74db448e91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-076b0fda-8e6c-4987-a5d5-bb74db448e91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-076b0fda-8e6c-4987-a5d5-bb74db448e91">
											<gml:posList>35.668585146963835 139.748478394341 28.2 35.66858166006022 139.74848039735932 28.2 35.66852814084463 139.74864020132097 28.2 35.66852955892871 139.74864436416712 28.2 35.668585146963835 139.748478394341 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d482b22d-ecae-41c9-91f5-0b061db1ccc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d482b22d-ecae-41c9-91f5-0b061db1ccc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d482b22d-ecae-41c9-91f5-0b061db1ccc7">
											<gml:posList>35.668545616246476 139.74856017663038 27.761 35.66851523878737 139.7485457053445 27.761 35.66848150868173 139.74864716537115 27.761 35.6685086131671 139.74866024834935 27.761 35.66851712219274 139.7486347010036 27.761 35.66852814084463 139.74864020132097 27.761 35.66858166006022 139.74848039735932 27.761 35.66854206987725 139.7484649637995 27.761 35.66852288426025 139.7485226994789 27.761 35.66855312695174 139.74853778947647 27.761 35.668545616246476 139.74856017663038 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69d67f9d-8070-4f12-a00c-e196cb2d3c9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69d67f9d-8070-4f12-a00c-e196cb2d3c9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69d67f9d-8070-4f12-a00c-e196cb2d3c9e">
											<gml:posList>35.6684780937297 139.7486489473836 28.2 35.66848150868173 139.74864716537115 28.2 35.66851523878737 139.7485457053445 28.2 35.668513784668306 139.74854157567697 28.2 35.6684780937297 139.7486489473836 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4120d95-a2fc-4e73-b90a-8246d1a28b45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4120d95-a2fc-4e73-b90a-8246d1a28b45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4120d95-a2fc-4e73-b90a-8246d1a28b45">
											<gml:posList>35.66851854027702 139.74863886384907 28.2 35.66852955892871 139.74864436416712 28.2 35.66852814084463 139.74864020132097 28.2 35.66851712219274 139.7486347010036 28.2 35.66851854027702 139.74863886384907 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-358d068d-ff3f-47b2-9293-e2de3d470e1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-358d068d-ff3f-47b2-9293-e2de3d470e1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-358d068d-ff3f-47b2-9293-e2de3d470e1d">
											<gml:posList>35.66851854027702 139.74863886384907 30.109 35.66851990413118 139.7486428168779 30.109 35.668550092593286 139.74865771919534 30.109 35.668553363403454 139.748656047794 30.109 35.66851854027702 139.74863886384907 30.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a8a1dada-6d7b-4a2d-9f4f-fba9dec699ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8a1dada-6d7b-4a2d-9f4f-fba9dec699ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8a1dada-6d7b-4a2d-9f4f-fba9dec699ff">
											<gml:posList>35.66851854027702 139.74863886384907 28.2 35.66851712219274 139.7486347010036 28.2 35.6685086131671 139.74866024834935 28.2 35.66851004925464 139.74866437803783 28.2 35.66851854027702 139.74863886384907 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1bc0e02f-c25e-45c8-9d17-9c84102b15d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bc0e02f-c25e-45c8-9d17-9c84102b15d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bc0e02f-c25e-45c8-9d17-9c84102b15d2">
											<gml:posList>35.66851004925464 139.74866437803783 30.109 35.6685133020064 139.74866266247264 30.109 35.66851990413118 139.7486428168779 30.109 35.66851854027702 139.74863886384907 30.109 35.66851004925464 139.74866437803783 30.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a435de3-74b8-48c5-a66d-2fdd93589f91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a435de3-74b8-48c5-a66d-2fdd93589f91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a435de3-74b8-48c5-a66d-2fdd93589f91">
											<gml:posList>35.66851004925464 139.74866437803783 28.2 35.6685086131671 139.74866024834935 28.2 35.66848150868173 139.74864716537115 28.2 35.6684780937297 139.7486489473836 28.2 35.66851004925464 139.74866437803783 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb28ced9-fbf6-4c18-baad-fc333cbd45dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb28ced9-fbf6-4c18-baad-fc333cbd45dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb28ced9-fbf6-4c18-baad-fc333cbd45dd">
											<gml:posList>35.66854338203733 139.74867718934655 29.777 35.668550092593286 139.74865771919534 29.777 35.66851990413118 139.7486428168779 29.777 35.6685133020064 139.74866266247264 29.777 35.66854338203733 139.74867718934655 29.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-924483e2-a1d8-45f5-934f-2c1d93868f84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-924483e2-a1d8-45f5-934f-2c1d93868f84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-924483e2-a1d8-45f5-934f-2c1d93868f84">
											<gml:posList>35.668553363403454 139.748656047794 30.109 35.668550092593286 139.74865771919534 30.109 35.66854338203733 139.74867718934655 30.109 35.66854472785501 139.74868113135028 30.109 35.668553363403454 139.748656047794 30.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-089d456a-9309-4b93-9f51-d97f0b5f96d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-089d456a-9309-4b93-9f51-d97f0b5f96d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-089d456a-9309-4b93-9f51-d97f0b5f96d9">
											<gml:posList>35.66854472785501 139.74868113135028 30.109 35.66854338203733 139.74867718934655 30.109 35.6685133020064 139.74866266247264 30.109 35.66851004925464 139.74866437803783 30.109 35.66854472785501 139.74868113135028 30.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78c4a680-22b1-4cba-881f-9cb39da46ce5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78c4a680-22b1-4cba-881f-9cb39da46ce5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78c4a680-22b1-4cba-881f-9cb39da46ce5">
											<gml:posList>35.66852288426025 139.7485226994789 28.2 35.66852288426025 139.7485226994789 27.761 35.66854206987725 139.7484649637995 27.761 35.66854206987725 139.7484649637995 28.2 35.66852288426025 139.7485226994789 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-177db959-e6d4-4020-a0b4-10f763096dec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-177db959-e6d4-4020-a0b4-10f763096dec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-177db959-e6d4-4020-a0b4-10f763096dec">
											<gml:posList>35.668545616246476 139.74856017663038 28.2 35.668545616246476 139.74856017663038 27.761 35.66855312695174 139.74853778947647 27.761 35.66855312695174 139.74853778947647 28.2 35.668545616246476 139.74856017663038 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-168a4bc8-7b3b-4034-946b-ea96d766c05e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-168a4bc8-7b3b-4034-946b-ea96d766c05e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-168a4bc8-7b3b-4034-946b-ea96d766c05e">
											<gml:posList>35.66858166006022 139.74848039735932 28.2 35.66858166006022 139.74848039735932 27.761 35.66852814084463 139.74864020132097 27.761 35.66852814084463 139.74864020132097 28.2 35.66858166006022 139.74848039735932 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecbde8f1-b2e0-4c30-8190-c034a0e19f07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecbde8f1-b2e0-4c30-8190-c034a0e19f07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecbde8f1-b2e0-4c30-8190-c034a0e19f07">
											<gml:posList>35.66851712219274 139.7486347010036 28.2 35.66851712219274 139.7486347010036 27.761 35.6685086131671 139.74866024834935 27.761 35.6685086131671 139.74866024834935 28.2 35.66851712219274 139.7486347010036 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1e5ce92-75e4-4e1b-b3eb-16fdfd01d940">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1e5ce92-75e4-4e1b-b3eb-16fdfd01d940">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1e5ce92-75e4-4e1b-b3eb-16fdfd01d940">
											<gml:posList>35.66851990413118 139.7486428168779 30.109 35.66851990413118 139.7486428168779 29.777 35.668550092593286 139.74865771919534 29.777 35.668550092593286 139.74865771919534 30.109 35.66851990413118 139.7486428168779 30.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1fa0d02c-2f63-46ef-9303-8116bc2b8c34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fa0d02c-2f63-46ef-9303-8116bc2b8c34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fa0d02c-2f63-46ef-9303-8116bc2b8c34">
											<gml:posList>35.66854056178984 139.74846099987928 5.56 35.66854056178984 139.74846099987928 28.2 35.668543059285234 139.74846198033038 28.2 35.668585146963835 139.748478394341 28.2 35.668585146963835 139.748478394341 5.56 35.66854056178984 139.74846099987928 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79cf2298-c3ec-44b9-80b5-6ba9aff85fa3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79cf2298-c3ec-44b9-80b5-6ba9aff85fa3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79cf2298-c3ec-44b9-80b5-6ba9aff85fa3">
											<gml:posList>35.66858166006022 139.74848039735932 27.761 35.66858166006022 139.74848039735932 28.2 35.66854206987725 139.7484649637995 28.2 35.66854206987725 139.7484649637995 27.761 35.66858166006022 139.74848039735932 27.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-210baebb-2ca5-4f37-a9c3-7ebd694ffc6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-210baebb-2ca5-4f37-a9c3-7ebd694ffc6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-210baebb-2ca5-4f37-a9c3-7ebd694ffc6f">
											<gml:posList>35.66855312695174 139.74853778947647 28.2 35.66855312695174 139.74853778947647 27.761 35.66852288426025 139.7485226994789 27.761 35.66852288426025 139.7485226994789 28.2 35.66855312695174 139.74853778947647 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb3d2c2c-ebd5-4818-8e55-7d467a046215">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb3d2c2c-ebd5-4818-8e55-7d467a046215">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb3d2c2c-ebd5-4818-8e55-7d467a046215">
											<gml:posList>35.66854972098399 139.74853952730163 28.2 35.66851947829269 139.74852443730404 28.2 35.66851947829269 139.74852443730404 24.7 35.66854972098399 139.74853952730163 24.7 35.66854972098399 139.74853952730163 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0acbfc27-65af-43aa-91c0-cfb825a65e96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0acbfc27-65af-43aa-91c0-cfb825a65e96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0acbfc27-65af-43aa-91c0-cfb825a65e96">
											<gml:posList>35.668544180163124 139.74855605798794 28.2 35.66854972098399 139.74853952730163 28.2 35.66854972098399 139.74853952730163 24.7 35.668544180163124 139.74855605798794 24.7 35.668544180163124 139.74855605798794 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68fbdfe3-e637-49d1-864b-7252e2e93152">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68fbdfe3-e637-49d1-864b-7252e2e93152">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68fbdfe3-e637-49d1-864b-7252e2e93152">
											<gml:posList>35.668513784668306 139.74854157567697 28.2 35.668544180163124 139.74855605798794 28.2 35.668544180163124 139.74855605798794 24.7 35.668513784668306 139.74854157567697 24.7 35.668513784668306 139.74854157567697 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5361cb13-0c7f-42fc-805b-d43381ebb767">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5361cb13-0c7f-42fc-805b-d43381ebb767">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5361cb13-0c7f-42fc-805b-d43381ebb767">
											<gml:posList>35.66851523878737 139.7485457053445 28.2 35.66851523878737 139.7485457053445 27.761 35.668545616246476 139.74856017663038 27.761 35.668545616246476 139.74856017663038 28.2 35.66851523878737 139.7485457053445 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63a92a1f-428c-45a4-8f46-d600017ca544">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63a92a1f-428c-45a4-8f46-d600017ca544">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63a92a1f-428c-45a4-8f46-d600017ca544">
											<gml:posList>35.66851947829269 139.74852443730404 24.7 35.66851947829269 139.74852443730404 28.2 35.66854056178984 139.74846099987928 28.2 35.66854056178984 139.74846099987928 5.56 35.6684780937297 139.7486489473836 5.56 35.6684780937297 139.7486489473836 28.2 35.668513784668306 139.74854157567697 28.2 35.668513784668306 139.74854157567697 24.7 35.66851947829269 139.74852443730404 24.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a908d5a-7618-4cd8-9932-354a273daf0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a908d5a-7618-4cd8-9932-354a273daf0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a908d5a-7618-4cd8-9932-354a273daf0a">
											<gml:posList>35.66852955892871 139.74864436416712 5.56 35.668585146963835 139.748478394341 5.56 35.668585146963835 139.748478394341 28.2 35.66852955892871 139.74864436416712 28.2 35.66852955892871 139.74864436416712 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-129e3079-b5d9-402b-8d1e-9dfa8136dd9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-129e3079-b5d9-402b-8d1e-9dfa8136dd9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-129e3079-b5d9-402b-8d1e-9dfa8136dd9a">
											<gml:posList>35.66848150868173 139.74864716537115 28.2 35.66848150868173 139.74864716537115 27.761 35.66851523878737 139.7485457053445 27.761 35.66851523878737 139.7485457053445 28.2 35.66848150868173 139.74864716537115 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53dba8e0-8bc5-4183-a465-3a26eee7c32f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53dba8e0-8bc5-4183-a465-3a26eee7c32f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53dba8e0-8bc5-4183-a465-3a26eee7c32f">
											<gml:posList>35.66852814084463 139.74864020132097 28.2 35.66852814084463 139.74864020132097 27.761 35.66851712219274 139.7486347010036 27.761 35.66851712219274 139.7486347010036 28.2 35.66852814084463 139.74864020132097 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8798a067-e8cd-45ee-9552-e78885d198de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8798a067-e8cd-45ee-9552-e78885d198de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8798a067-e8cd-45ee-9552-e78885d198de">
											<gml:posList>35.668553363403454 139.748656047794 30.109 35.668553363403454 139.748656047794 5.56 35.66852955892871 139.74864436416712 5.56 35.66852955892871 139.74864436416712 28.2 35.66851854027702 139.74863886384907 28.2 35.66851854027702 139.74863886384907 30.109 35.668553363403454 139.748656047794 30.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43f403bb-1ada-437a-ab6f-1740b731166f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43f403bb-1ada-437a-ab6f-1740b731166f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43f403bb-1ada-437a-ab6f-1740b731166f">
											<gml:posList>35.66851004925464 139.74866437803783 28.2 35.66851004925464 139.74866437803783 30.109 35.66851854027702 139.74863886384907 30.109 35.66851854027702 139.74863886384907 28.2 35.66851004925464 139.74866437803783 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2819f645-8ea0-4b17-b707-a514d0001bbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2819f645-8ea0-4b17-b707-a514d0001bbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2819f645-8ea0-4b17-b707-a514d0001bbe">
											<gml:posList>35.6685133020064 139.74866266247264 30.109 35.6685133020064 139.74866266247264 29.777 35.66851990413118 139.7486428168779 29.777 35.66851990413118 139.7486428168779 30.109 35.6685133020064 139.74866266247264 30.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18641f66-79d7-45d4-adbd-a8a7fc3ddaa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18641f66-79d7-45d4-adbd-a8a7fc3ddaa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18641f66-79d7-45d4-adbd-a8a7fc3ddaa5">
											<gml:posList>35.6685086131671 139.74866024834935 28.2 35.6685086131671 139.74866024834935 27.761 35.66848150868173 139.74864716537115 27.761 35.66848150868173 139.74864716537115 28.2 35.6685086131671 139.74866024834935 28.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d0bfe8c-1c23-4662-82ef-506911ee55a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d0bfe8c-1c23-4662-82ef-506911ee55a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d0bfe8c-1c23-4662-82ef-506911ee55a2">
											<gml:posList>35.66854472785501 139.74868113135028 5.56 35.66854472785501 139.74868113135028 30.109 35.66851004925464 139.74866437803783 30.109 35.66851004925464 139.74866437803783 28.2 35.6684780937297 139.7486489473836 28.2 35.6684780937297 139.7486489473836 5.56 35.66854472785501 139.74868113135028 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-315c1448-5134-4873-92dc-02043ac68ab1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-315c1448-5134-4873-92dc-02043ac68ab1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-315c1448-5134-4873-92dc-02043ac68ab1">
											<gml:posList>35.668550092593286 139.74865771919534 30.109 35.668550092593286 139.74865771919534 29.777 35.66854338203733 139.74867718934655 29.777 35.66854338203733 139.74867718934655 30.109 35.668550092593286 139.74865771919534 30.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-162b4337-117a-416a-ade1-3505fd06be2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-162b4337-117a-416a-ade1-3505fd06be2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-162b4337-117a-416a-ade1-3505fd06be2f">
											<gml:posList>35.66854472785501 139.74868113135028 5.56 35.668553363403454 139.748656047794 5.56 35.668553363403454 139.748656047794 30.109 35.66854472785501 139.74868113135028 30.109 35.66854472785501 139.74868113135028 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24e41371-56e9-4a25-881b-93744dac2d75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24e41371-56e9-4a25-881b-93744dac2d75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24e41371-56e9-4a25-881b-93744dac2d75">
											<gml:posList>35.66854338203733 139.74867718934655 30.109 35.66854338203733 139.74867718934655 29.777 35.6685133020064 139.74866266247264 29.777 35.6685133020064 139.74866266247264 30.109 35.66854338203733 139.74867718934655 30.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5497</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">107.90995</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.29</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>