<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_bacc3e68-0257-4b80-b29f-3512c4fb981c">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66777573371453 139.74336539630713 0 35.66779201941331 139.74337462345548 0 35.667804505731134 139.74334150487027 0 35.66778821102439 139.74333228878322 0 35.66777573371453 139.74336539630713 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66777573371453 139.74336539630713 27.257 35.66778821102439 139.74333228878322 27.257 35.667804505731134 139.74334150487027 27.257 35.66779201941331 139.74337462345548 27.257 35.66777573371453 139.74336539630713 27.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66777573371453 139.74336539630713 27.257 35.66779201941331 139.74337462345548 27.257 35.66779201941331 139.74337462345548 30.67 35.66777573371453 139.74336539630713 30.67 35.66777573371453 139.74336539630713 27.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66779201941331 139.74337462345548 27.257 35.667804505731134 139.74334150487027 27.257 35.667804505731134 139.74334150487027 30.67 35.66779201941331 139.74337462345548 30.67 35.66779201941331 139.74337462345548 27.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667804505731134 139.74334150487027 27.257 35.66778821102439 139.74333228878322 27.257 35.66778821102439 139.74333228878322 30.67 35.667804505731134 139.74334150487027 30.67 35.667804505731134 139.74334150487027 27.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66778821102439 139.74333228878322 27.257 35.66777573371453 139.74336539630713 27.257 35.66777573371453 139.74336539630713 30.67 35.66778821102439 139.74333228878322 30.67 35.66778821102439 139.74333228878322 27.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66777573371453 139.74336539630713 30.67 35.66779201941331 139.74337462345548 30.67 35.667804505731134 139.74334150487027 30.67 35.66778821102439 139.74333228878322 30.67 35.66777573371453 139.74336539630713 30.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-22f46565-9804-47d4-9165-c782329c6079"/>
							<gml:surfaceMember xlink:href="#poly-8e4d0e3a-5de7-40f6-b0e9-29aa0ca05cbc"/>
							<gml:surfaceMember xlink:href="#poly-7f5fbb77-74b9-4ad2-bdbf-3cdf550e54c3"/>
							<gml:surfaceMember xlink:href="#poly-f006969c-d0df-474f-b09e-6523f85e7ff0"/>
							<gml:surfaceMember xlink:href="#poly-09a8c06c-8a64-42ec-b559-8aa2245aac76"/>
							<gml:surfaceMember xlink:href="#poly-8f86c0b0-3a0a-4664-82ee-b6a0e12a4fb5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bacc3e68-0257-4b80-b29f-3512c4fb981c_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c62607e-567b-4a63-9118-40293396499b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66779651419538 139.74334638508273 31.102 35.66779696533574 139.74334699210118 31.102 35.66779736242676 139.74334764336388 31.102 35.667797723487624 139.7433483278047 31.102 35.66779803049913 139.74334905648985 31.102 35.66779828344479 139.74334980732746 31.102 35.667798482332834 139.74335059136348 31.102 35.66779862714677 139.74335138650608 31.102 35.667798708872866 139.74335219276537 31.102 35.66779873652484 139.74335301013122 31.102 35.667798710086196 139.74335381651187 31.102 35.6677986205597 139.74335463400925 31.102 35.66779847693434 139.7433554294755 31.102 35.667798270196364 139.74335620292078 31.102 35.66779801837325 139.7433569543248 31.102 35.66779770342927 139.743357672662 31.102 35.66779735241388 139.7433583689478 31.102 35.66779693826112 139.74335901007493 31.102 35.667796488020436 139.74335960705898 31.102 35.66779600169182 139.74336015989982 31.102 35.66779547025332 139.7433606575618 31.102 35.6677949117241 139.74336108897876 31.102 35.667794317098696 139.74336146520668 31.102 35.66779370439634 139.74336177517947 31.102 35.667793064603266 139.7433620189072 31.102 35.667792415746945 139.7433621963697 31.102 35.66779175781913 139.74336229652104 31.102 35.66779109083633 139.74336234145304 31.102 35.66779042378749 139.7433622980179 31.102 35.667789765702864 139.74336218829725 31.102 35.66778911658245 139.74336201229116 31.102 35.667788485439964 139.7433617699895 31.102 35.66778786325344 139.74336145035642 31.102 35.667787277080556 139.74336107545344 31.102 35.66778671789933 139.74336063424477 31.102 35.667786194731754 139.7433601377662 31.102 35.66778569856409 139.74335958602782 31.102 35.66778525643751 139.74335897899928 31.102 35.66778485033282 139.74335832774676 31.102 35.66778448927203 139.74335764330596 31.102 35.667784191274286 139.7433569146108 31.102 35.66778392931495 139.7433561637834 31.102 35.6677837304352 139.74335539079343 31.102 35.667783594626755 139.74335458459498 31.102 35.66778350388695 139.74335377834598 31.102 35.66778347623498 139.74335296098022 31.102 35.667783511687354 139.7433521545896 31.102 35.66778360121383 139.74335133709238 31.102 35.66778374483916 139.74335054162628 31.102 35.667783942563375 139.74334976819125 31.102 35.66778419438645 139.7433490167873 31.102 35.667784509330374 139.74334829845023 31.102 35.66778486935944 139.7433476021544 31.102 35.66778527449841 139.7433469610374 31.102 35.66778572473902 139.7433463640534 31.102 35.66778622008129 139.74334581120237 31.102 35.66778674250603 139.7433453135505 31.102 35.667787310048915 139.74334488212335 31.102 35.66778789566053 139.74334450590547 31.102 35.667788508362854 139.74334419593256 31.102 35.66778914815589 139.7433439522047 31.102 35.66778979701218 139.74334377474204 31.102 35.66779045493999 139.74334367459056 31.102 35.66779112193103 139.7433436407043 31.102 35.66779178897162 139.7433436730934 31.102 35.667792447056264 139.7433437828139 31.102 35.6677930961767 139.74334395881985 31.102 35.667793736332946 139.7433442011113 31.102 35.66779434950579 139.74334452075436 31.102 35.66779493567872 139.74334489565723 31.102 35.66779549486 139.74334533686584 31.102 35.667796027041376 139.74334583333427 31.102 35.66779651419538 139.74334638508273 31.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da7bc3fa-b094-4d18-a119-48d91ea34d2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da7bc3fa-b094-4d18-a119-48d91ea34d2b_0">
											<gml:posList>35.66779112193103 139.7433436407043 32.836 35.66779112193103 139.7433436407043 31.102 35.66779045493999 139.74334367459056 31.102 35.66779045493999 139.74334367459056 32.836 35.66779112193103 139.7433436407043 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c37387af-4b5f-4479-a4a0-3068ba355969">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c37387af-4b5f-4479-a4a0-3068ba355969_0">
											<gml:posList>35.66779178897162 139.7433436730934 32.836 35.66779178897162 139.7433436730934 31.102 35.66779112193103 139.7433436407043 31.102 35.66779112193103 139.7433436407043 32.836 35.66779178897162 139.7433436730934 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6493ab51-1eaf-404f-9ea1-0e8df09e7381">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6493ab51-1eaf-404f-9ea1-0e8df09e7381_0">
											<gml:posList>35.66779045493999 139.74334367459056 32.836 35.66779045493999 139.74334367459056 31.102 35.66778979701218 139.74334377474204 31.102 35.66778979701218 139.74334377474204 32.836 35.66779045493999 139.74334367459056 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c414a4c-a420-45e4-8624-2d376f177e48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c414a4c-a420-45e4-8624-2d376f177e48_0">
											<gml:posList>35.667792447056264 139.7433437828139 32.836 35.667792447056264 139.7433437828139 31.102 35.66779178897162 139.7433436730934 31.102 35.66779178897162 139.7433436730934 32.836 35.667792447056264 139.7433437828139 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d29f18c0-aacb-44ff-b182-8a65d312d049">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d29f18c0-aacb-44ff-b182-8a65d312d049_0">
											<gml:posList>35.66778979701218 139.74334377474204 32.836 35.66778979701218 139.74334377474204 31.102 35.66778914815589 139.7433439522047 31.102 35.66778914815589 139.7433439522047 32.836 35.66778979701218 139.74334377474204 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bf35388-6522-4e79-85c7-af10a67cf89b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bf35388-6522-4e79-85c7-af10a67cf89b_0">
											<gml:posList>35.6677930961767 139.74334395881985 32.836 35.6677930961767 139.74334395881985 31.102 35.667792447056264 139.7433437828139 31.102 35.667792447056264 139.7433437828139 32.836 35.6677930961767 139.74334395881985 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83c5fb54-2274-4923-a9d0-abfa3b510085">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83c5fb54-2274-4923-a9d0-abfa3b510085_0">
											<gml:posList>35.66778914815589 139.7433439522047 32.836 35.66778914815589 139.7433439522047 31.102 35.667788508362854 139.74334419593256 31.102 35.667788508362854 139.74334419593256 32.836 35.66778914815589 139.7433439522047 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5da0ed83-8f6c-4f4d-af09-e14b1e0e11ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5da0ed83-8f6c-4f4d-af09-e14b1e0e11ae_0">
											<gml:posList>35.667793736332946 139.7433442011113 32.836 35.667793736332946 139.7433442011113 31.102 35.6677930961767 139.74334395881985 31.102 35.6677930961767 139.74334395881985 32.836 35.667793736332946 139.7433442011113 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9673663d-8bb4-4504-aebd-4ba923fbb502">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9673663d-8bb4-4504-aebd-4ba923fbb502_0">
											<gml:posList>35.667788508362854 139.74334419593256 32.836 35.667788508362854 139.74334419593256 31.102 35.66778789566053 139.74334450590547 31.102 35.66778789566053 139.74334450590547 32.836 35.667788508362854 139.74334419593256 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48650102-aad3-41a7-b31d-9fa2bc8603fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48650102-aad3-41a7-b31d-9fa2bc8603fe_0">
											<gml:posList>35.66779434950579 139.74334452075436 32.836 35.66779434950579 139.74334452075436 31.102 35.667793736332946 139.7433442011113 31.102 35.667793736332946 139.7433442011113 32.836 35.66779434950579 139.74334452075436 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cd8ff33-4d12-47bd-9be8-99bbd42f849c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cd8ff33-4d12-47bd-9be8-99bbd42f849c_0">
											<gml:posList>35.66778789566053 139.74334450590547 32.836 35.66778789566053 139.74334450590547 31.102 35.667787310048915 139.74334488212335 31.102 35.667787310048915 139.74334488212335 32.836 35.66778789566053 139.74334450590547 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6caeb71c-9e32-4bd2-bc02-cf0fb2a1e39c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6caeb71c-9e32-4bd2-bc02-cf0fb2a1e39c_0">
											<gml:posList>35.66779493567872 139.74334489565723 32.836 35.66779493567872 139.74334489565723 31.102 35.66779434950579 139.74334452075436 31.102 35.66779434950579 139.74334452075436 32.836 35.66779493567872 139.74334489565723 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95e4cfad-4b2f-4622-899d-fd79bb2dd17a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95e4cfad-4b2f-4622-899d-fd79bb2dd17a_0">
											<gml:posList>35.667787310048915 139.74334488212335 32.836 35.667787310048915 139.74334488212335 31.102 35.66778674250603 139.7433453135505 31.102 35.66778674250603 139.7433453135505 32.836 35.667787310048915 139.74334488212335 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cddd8f9c-dfdc-4523-8221-206aafb1c8f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cddd8f9c-dfdc-4523-8221-206aafb1c8f9_0">
											<gml:posList>35.66779549486 139.74334533686584 32.836 35.66779549486 139.74334533686584 31.102 35.66779493567872 139.74334489565723 31.102 35.66779493567872 139.74334489565723 32.836 35.66779549486 139.74334533686584 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51c7a8ac-4225-4e11-8776-cec9b8c7f9e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51c7a8ac-4225-4e11-8776-cec9b8c7f9e6_0">
											<gml:posList>35.66778674250603 139.7433453135505 32.836 35.66778674250603 139.7433453135505 31.102 35.66778622008129 139.74334581120237 31.102 35.66778622008129 139.74334581120237 32.836 35.66778674250603 139.7433453135505 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfaf7753-9402-4d05-b680-63e42ab0487e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfaf7753-9402-4d05-b680-63e42ab0487e_0">
											<gml:posList>35.667796027041376 139.74334583333427 32.836 35.667796027041376 139.74334583333427 31.102 35.66779549486 139.74334533686584 31.102 35.66779549486 139.74334533686584 32.836 35.667796027041376 139.74334583333427 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1adf6cbb-7170-4ff7-868c-fe56e4fbcecd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1adf6cbb-7170-4ff7-868c-fe56e4fbcecd_0">
											<gml:posList>35.66778622008129 139.74334581120237 32.836 35.66778622008129 139.74334581120237 31.102 35.66778572473902 139.7433463640534 31.102 35.66778572473902 139.7433463640534 32.836 35.66778622008129 139.74334581120237 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fa2e1df-350d-4718-9d12-7ad726c08ed7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fa2e1df-350d-4718-9d12-7ad726c08ed7_0">
											<gml:posList>35.66779651419538 139.74334638508273 32.836 35.66779651419538 139.74334638508273 31.102 35.667796027041376 139.74334583333427 31.102 35.667796027041376 139.74334583333427 32.836 35.66779651419538 139.74334638508273 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-569c6809-aeea-44df-b3cd-9f72fc24f657">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-569c6809-aeea-44df-b3cd-9f72fc24f657_0">
											<gml:posList>35.66778572473902 139.7433463640534 32.836 35.66778572473902 139.7433463640534 31.102 35.66778527449841 139.7433469610374 31.102 35.66778527449841 139.7433469610374 32.836 35.66778572473902 139.7433463640534 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3786b8c1-340b-45fe-a318-0ddb7f213ee2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3786b8c1-340b-45fe-a318-0ddb7f213ee2_0">
											<gml:posList>35.66779696533574 139.74334699210118 32.836 35.66779696533574 139.74334699210118 31.102 35.66779651419538 139.74334638508273 31.102 35.66779651419538 139.74334638508273 32.836 35.66779696533574 139.74334699210118 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6626f1a7-8d80-4772-bf9a-679216af4bcd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6626f1a7-8d80-4772-bf9a-679216af4bcd_0">
											<gml:posList>35.66778527449841 139.7433469610374 32.836 35.66778527449841 139.7433469610374 31.102 35.66778486935944 139.7433476021544 31.102 35.66778486935944 139.7433476021544 32.836 35.66778527449841 139.7433469610374 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1f3ceff-38fd-4b7d-ba9a-db91df5a25ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1f3ceff-38fd-4b7d-ba9a-db91df5a25ad_0">
											<gml:posList>35.66779736242676 139.74334764336388 32.836 35.66779736242676 139.74334764336388 31.102 35.66779696533574 139.74334699210118 31.102 35.66779696533574 139.74334699210118 32.836 35.66779736242676 139.74334764336388 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b55f52e7-721b-4e6f-9566-d0356598c2ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b55f52e7-721b-4e6f-9566-d0356598c2ee_0">
											<gml:posList>35.66778486935944 139.7433476021544 32.836 35.66778486935944 139.7433476021544 31.102 35.667784509330374 139.74334829845023 31.102 35.667784509330374 139.74334829845023 32.836 35.66778486935944 139.7433476021544 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68058aef-fb00-470d-8278-48a1d821024d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68058aef-fb00-470d-8278-48a1d821024d_0">
											<gml:posList>35.667797723487624 139.7433483278047 32.836 35.667797723487624 139.7433483278047 31.102 35.66779736242676 139.74334764336388 31.102 35.66779736242676 139.74334764336388 32.836 35.667797723487624 139.7433483278047 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2f57939-07f4-4e6b-af23-9d66e57c3bca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2f57939-07f4-4e6b-af23-9d66e57c3bca_0">
											<gml:posList>35.667784509330374 139.74334829845023 32.836 35.667784509330374 139.74334829845023 31.102 35.66778419438645 139.7433490167873 31.102 35.66778419438645 139.7433490167873 32.836 35.667784509330374 139.74334829845023 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71a2efca-39f1-40e2-816a-7bb3cf790e6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71a2efca-39f1-40e2-816a-7bb3cf790e6c_0">
											<gml:posList>35.66779803049913 139.74334905648985 32.836 35.66779803049913 139.74334905648985 31.102 35.667797723487624 139.7433483278047 31.102 35.667797723487624 139.7433483278047 32.836 35.66779803049913 139.74334905648985 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc32e4db-3a98-49be-94aa-813c5503569a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc32e4db-3a98-49be-94aa-813c5503569a_0">
											<gml:posList>35.66778419438645 139.7433490167873 32.836 35.66778419438645 139.7433490167873 31.102 35.667783942563375 139.74334976819125 31.102 35.667783942563375 139.74334976819125 32.836 35.66778419438645 139.7433490167873 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df230a32-b790-42f3-9100-830acd9175d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df230a32-b790-42f3-9100-830acd9175d3_0">
											<gml:posList>35.66779828344479 139.74334980732746 32.836 35.66779828344479 139.74334980732746 31.102 35.66779803049913 139.74334905648985 31.102 35.66779803049913 139.74334905648985 32.836 35.66779828344479 139.74334980732746 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38ac601a-8444-45bb-b2ea-348f369db6e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38ac601a-8444-45bb-b2ea-348f369db6e7_0">
											<gml:posList>35.667783942563375 139.74334976819125 32.836 35.667783942563375 139.74334976819125 31.102 35.66778374483916 139.74335054162628 31.102 35.66778374483916 139.74335054162628 32.836 35.667783942563375 139.74334976819125 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca286ad5-dda0-4c41-9ca1-3a456863f977">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca286ad5-dda0-4c41-9ca1-3a456863f977_0">
											<gml:posList>35.667798482332834 139.74335059136348 32.836 35.667798482332834 139.74335059136348 31.102 35.66779828344479 139.74334980732746 31.102 35.66779828344479 139.74334980732746 32.836 35.667798482332834 139.74335059136348 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-deeb3a4a-4669-4ff7-a5b1-753cee140c59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-deeb3a4a-4669-4ff7-a5b1-753cee140c59_0">
											<gml:posList>35.66778374483916 139.74335054162628 32.836 35.66778374483916 139.74335054162628 31.102 35.66778360121383 139.74335133709238 31.102 35.66778360121383 139.74335133709238 32.836 35.66778374483916 139.74335054162628 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a688404-ad56-486b-9b03-77da4a94c7bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a688404-ad56-486b-9b03-77da4a94c7bb_0">
											<gml:posList>35.66779862714677 139.74335138650608 32.836 35.66779862714677 139.74335138650608 31.102 35.667798482332834 139.74335059136348 31.102 35.667798482332834 139.74335059136348 32.836 35.66779862714677 139.74335138650608 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a80c5556-f784-4b21-a7eb-1a0c439731d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a80c5556-f784-4b21-a7eb-1a0c439731d8_0">
											<gml:posList>35.66778360121383 139.74335133709238 32.836 35.66778360121383 139.74335133709238 31.102 35.667783511687354 139.7433521545896 31.102 35.667783511687354 139.7433521545896 32.836 35.66778360121383 139.74335133709238 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16ee3f27-a54c-41dc-8a78-fae20349995c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16ee3f27-a54c-41dc-8a78-fae20349995c_0">
											<gml:posList>35.667798708872866 139.74335219276537 32.836 35.667798708872866 139.74335219276537 31.102 35.66779862714677 139.74335138650608 31.102 35.66779862714677 139.74335138650608 32.836 35.667798708872866 139.74335219276537 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59f592c8-703a-4450-9c4c-d5a4ade89648">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59f592c8-703a-4450-9c4c-d5a4ade89648_0">
											<gml:posList>35.667783511687354 139.7433521545896 32.836 35.667783511687354 139.7433521545896 31.102 35.66778347623498 139.74335296098022 31.102 35.66778347623498 139.74335296098022 32.836 35.667783511687354 139.7433521545896 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42c9b60a-5be8-45a5-9565-5058fe7fd56a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42c9b60a-5be8-45a5-9565-5058fe7fd56a_0">
											<gml:posList>35.66779873652484 139.74335301013122 32.836 35.66779873652484 139.74335301013122 31.102 35.667798708872866 139.74335219276537 31.102 35.667798708872866 139.74335219276537 32.836 35.66779873652484 139.74335301013122 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5489079f-49f7-4ed4-af9b-5a9614d453e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5489079f-49f7-4ed4-af9b-5a9614d453e7_0">
											<gml:posList>35.667792447056264 139.7433437828139 32.836 35.66779178897162 139.7433436730934 32.836 35.66779112193103 139.7433436407043 32.836 35.66779045493999 139.74334367459056 32.836 35.66778979701218 139.74334377474204 32.836 35.66778914815589 139.7433439522047 32.836 35.667788508362854 139.74334419593256 32.836 35.66778789566053 139.74334450590547 32.836 35.667787310048915 139.74334488212335 32.836 35.66778674250603 139.7433453135505 32.836 35.66778622008129 139.74334581120237 32.836 35.66778572473902 139.7433463640534 32.836 35.66778527449841 139.7433469610374 32.836 35.66778486935944 139.7433476021544 32.836 35.667784509330374 139.74334829845023 32.836 35.66778419438645 139.7433490167873 32.836 35.667783942563375 139.74334976819125 32.836 35.66778374483916 139.74335054162628 32.836 35.66778360121383 139.74335133709238 32.836 35.667783511687354 139.7433521545896 32.836 35.66778347623498 139.74335296098022 32.836 35.66778350388695 139.74335377834598 32.836 35.667783594626755 139.74335458459498 32.836 35.6677837304352 139.74335539079343 32.836 35.66778392931495 139.7433561637834 32.836 35.667784191274286 139.7433569146108 32.836 35.66778448927203 139.74335764330596 32.836 35.66778485033282 139.74335832774676 32.836 35.66778525643751 139.74335897899928 32.836 35.66778569856409 139.74335958602782 32.836 35.667786194731754 139.7433601377662 32.836 35.66778671789933 139.74336063424477 32.836 35.667787277080556 139.74336107545344 32.836 35.66778786325344 139.74336145035642 32.836 35.667788485439964 139.7433617699895 32.836 35.66778911658245 139.74336201229116 32.836 35.667789765702864 139.74336218829725 32.836 35.66779042378749 139.7433622980179 32.836 35.66779109083633 139.74336234145304 32.836 35.66779175781913 139.74336229652104 32.836 35.667792415746945 139.7433621963697 32.836 35.667793064603266 139.7433620189072 32.836 35.66779370439634 139.74336177517947 32.836 35.667794317098696 139.74336146520668 32.836 35.6677949117241 139.74336108897876 32.836 35.66779547025332 139.7433606575618 32.836 35.66779600169182 139.74336015989982 32.836 35.667796488020436 139.74335960705898 32.836 35.66779693826112 139.74335901007493 32.836 35.66779735241388 139.7433583689478 32.836 35.66779770342927 139.743357672662 32.836 35.66779801837325 139.7433569543248 32.836 35.667798270196364 139.74335620292078 32.836 35.66779847693434 139.7433554294755 32.836 35.6677986205597 139.74335463400925 32.836 35.667798710086196 139.74335381651187 32.836 35.66779873652484 139.74335301013122 32.836 35.667798708872866 139.74335219276537 32.836 35.66779862714677 139.74335138650608 32.836 35.667798482332834 139.74335059136348 32.836 35.66779828344479 139.74334980732746 32.836 35.66779803049913 139.74334905648985 32.836 35.667797723487624 139.7433483278047 32.836 35.66779736242676 139.74334764336388 32.836 35.66779696533574 139.74334699210118 32.836 35.66779651419538 139.74334638508273 32.836 35.667796027041376 139.74334583333427 32.836 35.66779549486 139.74334533686584 32.836 35.66779493567872 139.74334489565723 32.836 35.66779434950579 139.74334452075436 32.836 35.667793736332946 139.7433442011113 32.836 35.6677930961767 139.74334395881985 32.836 35.667792447056264 139.7433437828139 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16e1f8fa-45ec-4c8d-918d-cd09e915f94c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16e1f8fa-45ec-4c8d-918d-cd09e915f94c_0">
											<gml:posList>35.66778347623498 139.74335296098022 32.836 35.66778347623498 139.74335296098022 31.102 35.66778350388695 139.74335377834598 31.102 35.66778350388695 139.74335377834598 32.836 35.66778347623498 139.74335296098022 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b2e3a19-1ec5-48c3-8d65-a3168e65fc87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b2e3a19-1ec5-48c3-8d65-a3168e65fc87_0">
											<gml:posList>35.667798710086196 139.74335381651187 32.836 35.667798710086196 139.74335381651187 31.102 35.66779873652484 139.74335301013122 31.102 35.66779873652484 139.74335301013122 32.836 35.667798710086196 139.74335381651187 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0938d65-d310-4884-8083-e334004f9dc5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0938d65-d310-4884-8083-e334004f9dc5_0">
											<gml:posList>35.66778350388695 139.74335377834598 32.836 35.66778350388695 139.74335377834598 31.102 35.667783594626755 139.74335458459498 31.102 35.667783594626755 139.74335458459498 32.836 35.66778350388695 139.74335377834598 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e0ff8c2-0015-429e-87f5-d567045bb4db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e0ff8c2-0015-429e-87f5-d567045bb4db_0">
											<gml:posList>35.6677986205597 139.74335463400925 32.836 35.6677986205597 139.74335463400925 31.102 35.667798710086196 139.74335381651187 31.102 35.667798710086196 139.74335381651187 32.836 35.6677986205597 139.74335463400925 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-226044e0-d426-430f-b162-c4c9c7a8b975">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-226044e0-d426-430f-b162-c4c9c7a8b975_0">
											<gml:posList>35.667783594626755 139.74335458459498 32.836 35.667783594626755 139.74335458459498 31.102 35.6677837304352 139.74335539079343 31.102 35.6677837304352 139.74335539079343 32.836 35.667783594626755 139.74335458459498 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb32a3fc-6534-4548-922a-847095b5f0a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb32a3fc-6534-4548-922a-847095b5f0a4_0">
											<gml:posList>35.66779847693434 139.7433554294755 32.836 35.66779847693434 139.7433554294755 31.102 35.6677986205597 139.74335463400925 31.102 35.6677986205597 139.74335463400925 32.836 35.66779847693434 139.7433554294755 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96a33483-f59f-4715-bd0b-318d9671a6c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96a33483-f59f-4715-bd0b-318d9671a6c0_0">
											<gml:posList>35.6677837304352 139.74335539079343 32.836 35.6677837304352 139.74335539079343 31.102 35.66778392931495 139.7433561637834 31.102 35.66778392931495 139.7433561637834 32.836 35.6677837304352 139.74335539079343 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c809c6b-8841-4c8b-ab08-6bc24df803d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c809c6b-8841-4c8b-ab08-6bc24df803d0_0">
											<gml:posList>35.667798270196364 139.74335620292078 32.836 35.667798270196364 139.74335620292078 31.102 35.66779847693434 139.7433554294755 31.102 35.66779847693434 139.7433554294755 32.836 35.667798270196364 139.74335620292078 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fcace42-c793-4b8f-a445-99790b4e2b57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fcace42-c793-4b8f-a445-99790b4e2b57_0">
											<gml:posList>35.66778392931495 139.7433561637834 32.836 35.66778392931495 139.7433561637834 31.102 35.667784191274286 139.7433569146108 31.102 35.667784191274286 139.7433569146108 32.836 35.66778392931495 139.7433561637834 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca1e20dc-041c-433a-970a-311e68350c48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca1e20dc-041c-433a-970a-311e68350c48_0">
											<gml:posList>35.66779801837325 139.7433569543248 32.836 35.66779801837325 139.7433569543248 31.102 35.667798270196364 139.74335620292078 31.102 35.667798270196364 139.74335620292078 32.836 35.66779801837325 139.7433569543248 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-306efc39-54a0-4db6-948c-b0e39f510935">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-306efc39-54a0-4db6-948c-b0e39f510935_0">
											<gml:posList>35.667784191274286 139.7433569146108 32.836 35.667784191274286 139.7433569146108 31.102 35.66778448927203 139.74335764330596 31.102 35.66778448927203 139.74335764330596 32.836 35.667784191274286 139.7433569146108 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c473ab91-401e-43f6-b19a-f04d9904040d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c473ab91-401e-43f6-b19a-f04d9904040d_0">
											<gml:posList>35.66779770342927 139.743357672662 32.836 35.66779770342927 139.743357672662 31.102 35.66779801837325 139.7433569543248 31.102 35.66779801837325 139.7433569543248 32.836 35.66779770342927 139.743357672662 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e30d7a54-6959-4b3e-8083-2285672d7452">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e30d7a54-6959-4b3e-8083-2285672d7452_0">
											<gml:posList>35.66778448927203 139.74335764330596 32.836 35.66778448927203 139.74335764330596 31.102 35.66778485033282 139.74335832774676 31.102 35.66778485033282 139.74335832774676 32.836 35.66778448927203 139.74335764330596 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a688fdc2-b091-496c-97c2-d2d1f7ba1435">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a688fdc2-b091-496c-97c2-d2d1f7ba1435_0">
											<gml:posList>35.66779735241388 139.7433583689478 32.836 35.66779735241388 139.7433583689478 31.102 35.66779770342927 139.743357672662 31.102 35.66779770342927 139.743357672662 32.836 35.66779735241388 139.7433583689478 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb5cba7a-9418-43ee-ab12-605aa041910b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb5cba7a-9418-43ee-ab12-605aa041910b_0">
											<gml:posList>35.66778485033282 139.74335832774676 32.836 35.66778485033282 139.74335832774676 31.102 35.66778525643751 139.74335897899928 31.102 35.66778525643751 139.74335897899928 32.836 35.66778485033282 139.74335832774676 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c83a96b-65ce-4d79-9eb6-df0bdedd3990">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c83a96b-65ce-4d79-9eb6-df0bdedd3990_0">
											<gml:posList>35.66779693826112 139.74335901007493 32.836 35.66779693826112 139.74335901007493 31.102 35.66779735241388 139.7433583689478 31.102 35.66779735241388 139.7433583689478 32.836 35.66779693826112 139.74335901007493 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-962ef99b-a71c-428e-bbaa-82b58883da2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-962ef99b-a71c-428e-bbaa-82b58883da2d_0">
											<gml:posList>35.66778525643751 139.74335897899928 32.836 35.66778525643751 139.74335897899928 31.102 35.66778569856409 139.74335958602782 31.102 35.66778569856409 139.74335958602782 32.836 35.66778525643751 139.74335897899928 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98c7870f-07be-4471-9a18-c8098eeb7e75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98c7870f-07be-4471-9a18-c8098eeb7e75_0">
											<gml:posList>35.667796488020436 139.74335960705898 32.836 35.667796488020436 139.74335960705898 31.102 35.66779693826112 139.74335901007493 31.102 35.66779693826112 139.74335901007493 32.836 35.667796488020436 139.74335960705898 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a0a71ac-7f0e-4493-86c3-bf6a7c3974f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a0a71ac-7f0e-4493-86c3-bf6a7c3974f2_0">
											<gml:posList>35.66778569856409 139.74335958602782 32.836 35.66778569856409 139.74335958602782 31.102 35.667786194731754 139.7433601377662 31.102 35.667786194731754 139.7433601377662 32.836 35.66778569856409 139.74335958602782 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25859815-cf05-4f5e-a851-8e3b26913062">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25859815-cf05-4f5e-a851-8e3b26913062_0">
											<gml:posList>35.66779600169182 139.74336015989982 32.836 35.66779600169182 139.74336015989982 31.102 35.667796488020436 139.74335960705898 31.102 35.667796488020436 139.74335960705898 32.836 35.66779600169182 139.74336015989982 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4ee57cf-9509-4feb-aeba-761424e7dee0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4ee57cf-9509-4feb-aeba-761424e7dee0_0">
											<gml:posList>35.667786194731754 139.7433601377662 32.836 35.667786194731754 139.7433601377662 31.102 35.66778671789933 139.74336063424477 31.102 35.66778671789933 139.74336063424477 32.836 35.667786194731754 139.7433601377662 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6afb4ae0-aed4-4495-b03f-13549d34fff5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6afb4ae0-aed4-4495-b03f-13549d34fff5_0">
											<gml:posList>35.66779547025332 139.7433606575618 32.836 35.66779547025332 139.7433606575618 31.102 35.66779600169182 139.74336015989982 31.102 35.66779600169182 139.74336015989982 32.836 35.66779547025332 139.7433606575618 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37762052-9672-4345-b4e7-26532839124d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37762052-9672-4345-b4e7-26532839124d_0">
											<gml:posList>35.66778671789933 139.74336063424477 32.836 35.66778671789933 139.74336063424477 31.102 35.667787277080556 139.74336107545344 31.102 35.667787277080556 139.74336107545344 32.836 35.66778671789933 139.74336063424477 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc16dedb-ad4d-4325-87f1-a5af8cb5e40f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc16dedb-ad4d-4325-87f1-a5af8cb5e40f_0">
											<gml:posList>35.6677949117241 139.74336108897876 32.836 35.6677949117241 139.74336108897876 31.102 35.66779547025332 139.7433606575618 31.102 35.66779547025332 139.7433606575618 32.836 35.6677949117241 139.74336108897876 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f83f1e6-4382-4767-8ebc-c870c5c8c8b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f83f1e6-4382-4767-8ebc-c870c5c8c8b5_0">
											<gml:posList>35.667787277080556 139.74336107545344 32.836 35.667787277080556 139.74336107545344 31.102 35.66778786325344 139.74336145035642 31.102 35.66778786325344 139.74336145035642 32.836 35.667787277080556 139.74336107545344 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43d56766-b9fb-4112-8888-1aba13e7f5c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43d56766-b9fb-4112-8888-1aba13e7f5c9_0">
											<gml:posList>35.667794317098696 139.74336146520668 32.836 35.667794317098696 139.74336146520668 31.102 35.6677949117241 139.74336108897876 31.102 35.6677949117241 139.74336108897876 32.836 35.667794317098696 139.74336146520668 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-044c1fec-f847-4e1f-b5ae-e73104b7dbca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-044c1fec-f847-4e1f-b5ae-e73104b7dbca_0">
											<gml:posList>35.66778786325344 139.74336145035642 32.836 35.66778786325344 139.74336145035642 31.102 35.667788485439964 139.7433617699895 31.102 35.667788485439964 139.7433617699895 32.836 35.66778786325344 139.74336145035642 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ee86073-b967-49b2-ac2e-79aaffc13f2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ee86073-b967-49b2-ac2e-79aaffc13f2d_0">
											<gml:posList>35.66779370439634 139.74336177517947 32.836 35.66779370439634 139.74336177517947 31.102 35.667794317098696 139.74336146520668 31.102 35.667794317098696 139.74336146520668 32.836 35.66779370439634 139.74336177517947 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6f9c55c-a524-47ae-a3ba-552ef32ad1f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6f9c55c-a524-47ae-a3ba-552ef32ad1f9_0">
											<gml:posList>35.667788485439964 139.7433617699895 32.836 35.667788485439964 139.7433617699895 31.102 35.66778911658245 139.74336201229116 31.102 35.66778911658245 139.74336201229116 32.836 35.667788485439964 139.7433617699895 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab8b7d9c-7841-4ac4-9311-1001a3bba040">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab8b7d9c-7841-4ac4-9311-1001a3bba040_0">
											<gml:posList>35.667793064603266 139.7433620189072 32.836 35.667793064603266 139.7433620189072 31.102 35.66779370439634 139.74336177517947 31.102 35.66779370439634 139.74336177517947 32.836 35.667793064603266 139.7433620189072 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79c09e37-6641-40a6-b2ab-3773bc7949d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79c09e37-6641-40a6-b2ab-3773bc7949d5_0">
											<gml:posList>35.66778911658245 139.74336201229116 32.836 35.66778911658245 139.74336201229116 31.102 35.667789765702864 139.74336218829725 31.102 35.667789765702864 139.74336218829725 32.836 35.66778911658245 139.74336201229116 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4d2584d-6d07-4396-9a96-d91c8015b965">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4d2584d-6d07-4396-9a96-d91c8015b965_0">
											<gml:posList>35.667792415746945 139.7433621963697 32.836 35.667792415746945 139.7433621963697 31.102 35.667793064603266 139.7433620189072 31.102 35.667793064603266 139.7433620189072 32.836 35.667792415746945 139.7433621963697 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-319b769a-44d6-4789-a2a9-9c8b67bc8041">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-319b769a-44d6-4789-a2a9-9c8b67bc8041_0">
											<gml:posList>35.667789765702864 139.74336218829725 32.836 35.667789765702864 139.74336218829725 31.102 35.66779042378749 139.7433622980179 31.102 35.66779042378749 139.7433622980179 32.836 35.667789765702864 139.74336218829725 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-636eadc9-99b7-4636-8758-75e213e251fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-636eadc9-99b7-4636-8758-75e213e251fd_0">
											<gml:posList>35.66779175781913 139.74336229652104 32.836 35.66779175781913 139.74336229652104 31.102 35.667792415746945 139.7433621963697 31.102 35.667792415746945 139.7433621963697 32.836 35.66779175781913 139.74336229652104 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9a70cdc-3c54-4151-a0cf-c0aefe85fcfd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9a70cdc-3c54-4151-a0cf-c0aefe85fcfd_0">
											<gml:posList>35.66779109083633 139.74336234145304 32.836 35.66779109083633 139.74336234145304 31.102 35.66779175781913 139.74336229652104 31.102 35.66779175781913 139.74336229652104 32.836 35.66779109083633 139.74336234145304 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93b1082e-221b-4223-9ef0-e6008bbfd6bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93b1082e-221b-4223-9ef0-e6008bbfd6bb_0">
											<gml:posList>35.66779042378749 139.7433622980179 32.836 35.66779042378749 139.7433622980179 31.102 35.66779109083633 139.74336234145304 31.102 35.66779109083633 139.74336234145304 32.836 35.66779042378749 139.7433622980179 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-22f46565-9804-47d4-9165-c782329c6079">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22f46565-9804-47d4-9165-c782329c6079">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22f46565-9804-47d4-9165-c782329c6079">
											<gml:posList>35.66777573371453 139.7433653963071 27.257 35.66778821102438 139.7433322887832 27.257 35.66780450573113 139.74334150487027 27.257 35.66779201941331 139.74337462345548 27.257 35.66777573371453 139.7433653963071 27.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e4d0e3a-5de7-40f6-b0e9-29aa0ca05cbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e4d0e3a-5de7-40f6-b0e9-29aa0ca05cbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e4d0e3a-5de7-40f6-b0e9-29aa0ca05cbc">
											<gml:posList>35.66778821102438 139.7433322887832 31.102 35.66777573371453 139.7433653963071 31.102 35.66779201941331 139.74337462345548 31.102 35.66780450573113 139.74334150487027 31.102 35.66778821102438 139.7433322887832 31.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f5fbb77-74b9-4ad2-bdbf-3cdf550e54c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f5fbb77-74b9-4ad2-bdbf-3cdf550e54c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f5fbb77-74b9-4ad2-bdbf-3cdf550e54c3">
											<gml:posList>35.66778821102438 139.7433322887832 27.257 35.66777573371453 139.7433653963071 27.257 35.66777573371453 139.7433653963071 31.102 35.66778821102438 139.7433322887832 31.102 35.66778821102438 139.7433322887832 27.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f006969c-d0df-474f-b09e-6523f85e7ff0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f006969c-d0df-474f-b09e-6523f85e7ff0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f006969c-d0df-474f-b09e-6523f85e7ff0">
											<gml:posList>35.66777573371453 139.7433653963071 27.257 35.66779201941331 139.74337462345548 27.257 35.66779201941331 139.74337462345548 31.102 35.66777573371453 139.7433653963071 31.102 35.66777573371453 139.7433653963071 27.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09a8c06c-8a64-42ec-b559-8aa2245aac76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09a8c06c-8a64-42ec-b559-8aa2245aac76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09a8c06c-8a64-42ec-b559-8aa2245aac76">
											<gml:posList>35.66780450573113 139.74334150487027 27.257 35.66778821102438 139.7433322887832 27.257 35.66778821102438 139.7433322887832 31.102 35.66780450573113 139.74334150487027 31.102 35.66780450573113 139.74334150487027 27.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f86c0b0-3a0a-4664-82ee-b6a0e12a4fb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f86c0b0-3a0a-4664-82ee-b6a0e12a4fb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f86c0b0-3a0a-4664-82ee-b6a0e12a4fb5">
											<gml:posList>35.66779201941331 139.74337462345548 27.257 35.66780450573113 139.74334150487027 27.257 35.66780450573113 139.74334150487027 31.102 35.66779201941331 139.74337462345548 31.102 35.66779201941331 139.74337462345548 27.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1709</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>