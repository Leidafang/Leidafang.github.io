<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_bb4db51b-50b3-4f7a-b137-74e55a51b6ab">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">9.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66723647462793 139.73863533899578 0 35.667238639485994 139.73863732468791 0 35.667290490072524 139.73855022228645 0 35.66723573813736 139.73850124353712 0 35.66718415773679 139.73858801421682 0 35.66722095998484 139.73862132912151 0 35.667199986839044 139.73865802601995 0 35.66721586167971 139.73867159363948 0 35.66723647462793 139.73863533899578 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66723647462793 139.73863533899578 13.05 35.66721586167971 139.73867159363948 13.05 35.667199986839044 139.73865802601995 13.05 35.66722095998484 139.73862132912151 13.05 35.66718415773679 139.73858801421682 13.05 35.66723573813736 139.73850124353712 13.05 35.667290490072524 139.73855022228645 13.05 35.667238639485994 139.73863732468791 13.05 35.66723647462793 139.73863533899578 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66723647462793 139.73863533899578 13.05 35.667238639485994 139.73863732468791 13.05 35.667238639485994 139.73863732468791 22.16 35.66723647462793 139.73863533899578 22.16 35.66723647462793 139.73863533899578 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667238639485994 139.73863732468791 13.05 35.667290490072524 139.73855022228645 13.05 35.667290490072524 139.73855022228645 22.16 35.667238639485994 139.73863732468791 22.16 35.667238639485994 139.73863732468791 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667290490072524 139.73855022228645 13.05 35.66723573813736 139.73850124353712 13.05 35.66723573813736 139.73850124353712 22.16 35.667290490072524 139.73855022228645 22.16 35.667290490072524 139.73855022228645 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66723573813736 139.73850124353712 13.05 35.66718415773679 139.73858801421682 13.05 35.66718415773679 139.73858801421682 22.16 35.66723573813736 139.73850124353712 22.16 35.66723573813736 139.73850124353712 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718415773679 139.73858801421682 13.05 35.66722095998484 139.73862132912151 13.05 35.66722095998484 139.73862132912151 22.16 35.66718415773679 139.73858801421682 22.16 35.66718415773679 139.73858801421682 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66722095998484 139.73862132912151 13.05 35.667199986839044 139.73865802601995 13.05 35.667199986839044 139.73865802601995 22.16 35.66722095998484 139.73862132912151 22.16 35.66722095998484 139.73862132912151 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667199986839044 139.73865802601995 13.05 35.66721586167971 139.73867159363948 13.05 35.66721586167971 139.73867159363948 22.16 35.667199986839044 139.73865802601995 22.16 35.667199986839044 139.73865802601995 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66721586167971 139.73867159363948 13.05 35.66723647462793 139.73863533899578 13.05 35.66723647462793 139.73863533899578 22.16 35.66721586167971 139.73867159363948 22.16 35.66721586167971 139.73867159363948 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66723647462793 139.73863533899578 22.16 35.667238639485994 139.73863732468791 22.16 35.667290490072524 139.73855022228645 22.16 35.66723573813736 139.73850124353712 22.16 35.66718415773679 139.73858801421682 22.16 35.66722095998484 139.73862132912151 22.16 35.667199986839044 139.73865802601995 22.16 35.66721586167971 139.73867159363948 22.16 35.66723647462793 139.73863533899578 22.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-46df2f44-64a1-43aa-9a30-3ec61ad35138"/>
							<gml:surfaceMember xlink:href="#poly-78f36dd5-c439-40a7-b84a-358820610388"/>
							<gml:surfaceMember xlink:href="#poly-626d4652-0d80-4fe2-a88a-6c50ab614812"/>
							<gml:surfaceMember xlink:href="#poly-8b81f5f2-21f8-4806-be86-189baa286607"/>
							<gml:surfaceMember xlink:href="#poly-1ab10b61-b119-443c-9983-5b631ec09d91"/>
							<gml:surfaceMember xlink:href="#poly-0493ec21-8496-47c2-92dd-5f54f2796c56"/>
							<gml:surfaceMember xlink:href="#poly-b58ab300-1313-41da-a35f-1479496b218c"/>
							<gml:surfaceMember xlink:href="#poly-f078f1bc-9c52-4aa2-9f14-2bbe5c20bf17"/>
							<gml:surfaceMember xlink:href="#poly-a7afadc2-43c2-413e-ad53-fa389ef4ba88"/>
							<gml:surfaceMember xlink:href="#poly-54aa7d91-d260-4a17-a104-a20bfea28689"/>
							<gml:surfaceMember xlink:href="#poly-ef4bfffe-a546-454e-a9a5-5b09960fe283"/>
							<gml:surfaceMember xlink:href="#poly-49ec1dad-7fab-4bd6-ab40-4f6d14cd792a"/>
							<gml:surfaceMember xlink:href="#poly-a4645f7c-bbb0-41a6-9fb5-af316734dc92"/>
							<gml:surfaceMember xlink:href="#poly-71a342b6-c65a-47a7-a67a-d056a054d5fe"/>
							<gml:surfaceMember xlink:href="#poly-1b9faebb-3fff-4121-9934-7d95950763f9"/>
							<gml:surfaceMember xlink:href="#poly-34bb215d-846e-4323-ab20-3379bb199960"/>
							<gml:surfaceMember xlink:href="#poly-5b956fa3-b34d-4ea8-9403-9f542bd0ae2c"/>
							<gml:surfaceMember xlink:href="#poly-b78d6cb5-b43c-4441-b80a-6358b0424572"/>
							<gml:surfaceMember xlink:href="#poly-913f8ed7-c0bc-4806-a7f5-6d3a4b293ba3"/>
							<gml:surfaceMember xlink:href="#poly-1ed3d492-3872-43c3-97ab-e6ab40e37581"/>
							<gml:surfaceMember xlink:href="#poly-74104571-3f6c-4bd7-81ac-6a53af5888dd"/>
							<gml:surfaceMember xlink:href="#poly-79abfd3f-b2b2-48dd-a4ce-4bc7bff1f073"/>
							<gml:surfaceMember xlink:href="#poly-a030a1df-c922-431c-bb7d-7fd78a794269"/>
							<gml:surfaceMember xlink:href="#poly-5f2f9109-db21-4d46-86cf-a29f7c8c87f0"/>
							<gml:surfaceMember xlink:href="#poly-abee7db1-c026-4c08-92ce-39049eb460af"/>
							<gml:surfaceMember xlink:href="#poly-607df113-7f24-437a-9a4e-05f45665337f"/>
							<gml:surfaceMember xlink:href="#poly-7b5df15b-7650-42c3-94a4-3eea376f988c"/>
							<gml:surfaceMember xlink:href="#poly-2877943f-4d04-4c5f-9f27-e0ac29a011f1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bb4db51b-50b3-4f7a-b137-74e55a51b6ab_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-130b10d8-6e97-4166-b9f6-f64e9157115c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-130b10d8-6e97-4166-b9f6-f64e9157115c_0">
											<gml:posList>35.66722921923303 139.73852163079403 24.133 35.66727725931424 139.73856345978626 22.202 35.66722921923303 139.73852163079403 22.202 35.66722921923303 139.73852163079403 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc268d76-084d-466d-b5ad-7d78c64f0ec0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc268d76-084d-466d-b5ad-7d78c64f0ec0_0">
											<gml:posList>35.66722921923303 139.73852163079403 24.133 35.66727725931424 139.73856345978626 24.133 35.66727725931424 139.73856345978626 22.202 35.66722921923303 139.73852163079403 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13697ec5-550e-456a-9a55-7f8c5b034df8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13697ec5-550e-456a-9a55-7f8c5b034df8_0">
											<gml:posList>35.667274258230016 139.73856408189968 24.133 35.667229726906484 139.7385253194994 23.05 35.667274258230016 139.73856408189968 23.05 35.667274258230016 139.73856408189968 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ac0d0b1-1a12-40ce-b38d-790190bb0679">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ac0d0b1-1a12-40ce-b38d-790190bb0679_0">
											<gml:posList>35.667274258230016 139.73856408189968 24.133 35.667229726906484 139.7385253194994 24.133 35.667229726906484 139.7385253194994 23.05 35.667274258230016 139.73856408189968 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76ce0a72-b6bd-4829-bf89-e109deffb233">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76ce0a72-b6bd-4829-bf89-e109deffb233_0">
											<gml:posList>35.667190836778126 139.73858784063788 22.202 35.66722921923303 139.73852163079403 24.133 35.66722921923303 139.73852163079403 22.202 35.667190836778126 139.73858784063788 22.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a10683b-93a8-4f34-b862-893108065b6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a10683b-93a8-4f34-b862-893108065b6d_0">
											<gml:posList>35.667190836778126 139.73858784063788 22.202 35.667190836778126 139.73858784063788 24.133 35.66722921923303 139.73852163079403 24.133 35.667190836778126 139.73858784063788 22.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3322230-f5fd-40ec-91b5-90e73f630a72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3322230-f5fd-40ec-91b5-90e73f630a72_0">
											<gml:posList>35.667229726906484 139.7385253194994 24.133 35.667193846876245 139.73858721851533 23.05 35.667229726906484 139.7385253194994 23.05 35.667229726906484 139.7385253194994 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94c19efa-f9f0-4e69-bb3b-f7ce69dd48c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94c19efa-f9f0-4e69-bb3b-f7ce69dd48c1_0">
											<gml:posList>35.667229726906484 139.7385253194994 24.133 35.667193846876245 139.73858721851533 24.133 35.667193846876245 139.73858721851533 23.05 35.667229726906484 139.7385253194994 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe94d465-dae4-4a04-87b7-2415083cb1b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe94d465-dae4-4a04-87b7-2415083cb1b8_0">
											<gml:posList>35.66723836916642 139.7386259809434 23.05 35.667274258230016 139.73856408189968 23.05 35.667229726906484 139.7385253194994 23.05 35.66723836916642 139.7386259809434 23.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a16e8fe-13e0-4b8d-b5e7-7ae1aa781ccf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a16e8fe-13e0-4b8d-b5e7-7ae1aa781ccf_0">
											<gml:posList>35.667193846876245 139.73858721851533 23.05 35.66723836916642 139.7386259809434 23.05 35.667229726906484 139.7385253194994 23.05 35.667193846876245 139.73858721851533 23.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc47dc03-ee44-490a-9db6-cea2eda84558">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc47dc03-ee44-490a-9db6-cea2eda84558_0">
											<gml:posList>35.66722921923303 139.73852163079403 24.133 35.667190836778126 139.73858784063788 24.133 35.667229726906484 139.7385253194994 24.133 35.66722921923303 139.73852163079403 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82192b97-9085-4e43-ade9-9de7081e9f68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82192b97-9085-4e43-ade9-9de7081e9f68_0">
											<gml:posList>35.66722921923303 139.73852163079403 24.133 35.667274258230016 139.73856408189968 24.133 35.66727725931424 139.73856345978626 24.133 35.66722921923303 139.73852163079403 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-035b4059-9626-4a25-9ada-f2added18664">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-035b4059-9626-4a25-9ada-f2added18664_0">
											<gml:posList>35.667190836778126 139.73858784063788 24.133 35.66723887683668 139.73862966964984 24.133 35.667193846876245 139.73858721851533 24.133 35.667190836778126 139.73858784063788 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ef8608f-0bbf-4f2e-9d7f-c2040dc3936f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ef8608f-0bbf-4f2e-9d7f-c2040dc3936f_0">
											<gml:posList>35.66723836916642 139.7386259809434 24.133 35.66723887683668 139.73862966964984 24.133 35.66727725931424 139.73856345978626 24.133 35.66723836916642 139.7386259809434 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f55bb0d-f553-423d-bc34-b8d1b450c4e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f55bb0d-f553-423d-bc34-b8d1b450c4e0_0">
											<gml:posList>35.667190836778126 139.73858784063788 24.133 35.667193846876245 139.73858721851533 24.133 35.667229726906484 139.7385253194994 24.133 35.667190836778126 139.73858784063788 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ded34f26-07db-4e1b-80be-9537bfb26edd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ded34f26-07db-4e1b-80be-9537bfb26edd_0">
											<gml:posList>35.66722921923303 139.73852163079403 24.133 35.667229726906484 139.7385253194994 24.133 35.667274258230016 139.73856408189968 24.133 35.66722921923303 139.73852163079403 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2a4058c-0412-4728-99c2-f7b845ee6089">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2a4058c-0412-4728-99c2-f7b845ee6089_0">
											<gml:posList>35.667274258230016 139.73856408189968 24.133 35.66723836916642 139.7386259809434 24.133 35.66727725931424 139.73856345978626 24.133 35.667274258230016 139.73856408189968 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-263d47bc-005e-476d-9103-81b3cb8ebf0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-263d47bc-005e-476d-9103-81b3cb8ebf0e_0">
											<gml:posList>35.66723887683668 139.73862966964984 24.133 35.66723836916642 139.7386259809434 24.133 35.667193846876245 139.73858721851533 24.133 35.66723887683668 139.73862966964984 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b30d763-2038-49fd-94c5-657e6d75cc76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b30d763-2038-49fd-94c5-657e6d75cc76_0">
											<gml:posList>35.66723836916642 139.7386259809434 24.133 35.667274258230016 139.73856408189968 23.05 35.66723836916642 139.7386259809434 23.05 35.66723836916642 139.7386259809434 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-120d2799-7a8c-47c4-9b5e-1ee3ecdc6c29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-120d2799-7a8c-47c4-9b5e-1ee3ecdc6c29_0">
											<gml:posList>35.66723836916642 139.7386259809434 24.133 35.667274258230016 139.73856408189968 24.133 35.667274258230016 139.73856408189968 23.05 35.66723836916642 139.7386259809434 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6ac40b1-0e4b-4550-8ece-65b30ee939fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6ac40b1-0e4b-4550-8ece-65b30ee939fb_0">
											<gml:posList>35.66727725931424 139.73856345978626 22.202 35.66723887683668 139.73862966964984 24.133 35.66723887683668 139.73862966964984 22.202 35.66727725931424 139.73856345978626 22.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-238139a5-383a-4989-84df-0414ab5afb50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-238139a5-383a-4989-84df-0414ab5afb50_0">
											<gml:posList>35.66727725931424 139.73856345978626 22.202 35.66727725931424 139.73856345978626 24.133 35.66723887683668 139.73862966964984 24.133 35.66727725931424 139.73856345978626 22.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26e1797c-3ccf-4451-b835-38be258c111c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26e1797c-3ccf-4451-b835-38be258c111c_0">
											<gml:posList>35.667193846876245 139.73858721851533 24.133 35.66723836916642 139.7386259809434 23.05 35.667193846876245 139.73858721851533 23.05 35.667193846876245 139.73858721851533 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5f9b2b6-a349-4c91-9b0e-ae6663a4fedf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5f9b2b6-a349-4c91-9b0e-ae6663a4fedf_0">
											<gml:posList>35.667193846876245 139.73858721851533 24.133 35.66723836916642 139.7386259809434 24.133 35.66723836916642 139.7386259809434 23.05 35.667193846876245 139.73858721851533 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e381d63c-5a6f-40d7-8d38-6eeff60f13fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e381d63c-5a6f-40d7-8d38-6eeff60f13fe_0">
											<gml:posList>35.66723887683668 139.73862966964984 24.133 35.667190836778126 139.73858784063788 22.202 35.66723887683668 139.73862966964984 22.202 35.66723887683668 139.73862966964984 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18baf4f7-9b4b-44d6-a22f-ee0ce3a26cbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18baf4f7-9b4b-44d6-a22f-ee0ce3a26cbe_0">
											<gml:posList>35.66723887683668 139.73862966964984 24.133 35.667190836778126 139.73858784063788 24.133 35.667190836778126 139.73858784063788 22.202 35.66723887683668 139.73862966964984 24.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd0f0e51-ecc2-4591-9201-043d6ad3a408">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667190836778126 139.73858784063788 22.202 35.66722921923303 139.73852163079403 22.202 35.66727725931424 139.73856345978626 22.202 35.66723887683668 139.73862966964984 22.202 35.667190836778126 139.73858784063788 22.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-46df2f44-64a1-43aa-9a30-3ec61ad35138">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46df2f44-64a1-43aa-9a30-3ec61ad35138">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46df2f44-64a1-43aa-9a30-3ec61ad35138">
											<gml:posList>35.66722095998481 139.73862132912151 13.05 35.66718415773678 139.73858801421684 13.05 35.667235738137336 139.73850124353712 13.05 35.667290490072524 139.73855022228645 13.05 35.66723863948596 139.73863732468791 13.05 35.66723647462793 139.73863533899578 13.05 35.6672158616797 139.73867159363948 13.05 35.66719998683904 139.73865802601995 13.05 35.66722095998481 139.73862132912151 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78f36dd5-c439-40a7-b84a-358820610388">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78f36dd5-c439-40a7-b84a-358820610388">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78f36dd5-c439-40a7-b84a-358820610388">
											<gml:posList>35.667235738137336 139.73850124353712 23.039 35.66723603744316 139.73850359594408 23.039 35.667288570435616 139.738550589068 23.039 35.667290490072524 139.73855022228645 23.039 35.667235738137336 139.73850124353712 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-626d4652-0d80-4fe2-a88a-6c50ab614812">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-626d4652-0d80-4fe2-a88a-6c50ab614812">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-626d4652-0d80-4fe2-a88a-6c50ab614812">
											<gml:posList>35.66718415773678 139.73858801421684 23.039 35.66718608638755 139.738587647426 23.039 35.66723603744316 139.73850359594408 23.039 35.667235738137336 139.73850124353712 23.039 35.66718415773678 139.73858801421684 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b81f5f2-21f8-4806-be86-189baa286607">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b81f5f2-21f8-4806-be86-189baa286607">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b81f5f2-21f8-4806-be86-189baa286607">
											<gml:posList>35.66723946535238 139.73863300479442 22.202 35.667238637236146 139.7386344638215 22.202 35.667288570435616 139.738550589068 22.202 35.66723603744316 139.73850359594408 22.202 35.66718608638755 139.738587647426 22.202 35.66722060652942 139.73861888841188 22.202 35.66722132654156 139.7386175068334 22.202 35.66723946535238 139.73863300479442 22.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ab10b61-b119-443c-9983-5b631ec09d91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ab10b61-b119-443c-9983-5b631ec09d91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ab10b61-b119-443c-9983-5b631ec09d91">
											<gml:posList>35.667290490072524 139.73855022228645 23.039 35.667288570435616 139.738550589068 23.039 35.667238637236146 139.7386344638215 23.039 35.66723863948596 139.73863732468791 23.039 35.667290490072524 139.73855022228645 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0493ec21-8496-47c2-92dd-5f54f2796c56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0493ec21-8496-47c2-92dd-5f54f2796c56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0493ec21-8496-47c2-92dd-5f54f2796c56">
											<gml:posList>35.66722095998481 139.73862132912151 23.039 35.66722060652942 139.73861888841188 23.039 35.66718608638755 139.738587647426 23.039 35.66718415773678 139.73858801421684 23.039 35.66722095998481 139.73862132912151 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b58ab300-1313-41da-a35f-1479496b218c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b58ab300-1313-41da-a35f-1479496b218c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b58ab300-1313-41da-a35f-1479496b218c">
											<gml:posList>35.66722170700341 139.73861990332784 23.039 35.66722132654156 139.7386175068334 23.039 35.66722060652942 139.73861888841188 23.039 35.66722095998481 139.73862132912151 23.039 35.66722170700341 139.73861990332784 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f078f1bc-9c52-4aa2-9f14-2bbe5c20bf17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f078f1bc-9c52-4aa2-9f14-2bbe5c20bf17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f078f1bc-9c52-4aa2-9f14-2bbe5c20bf17">
											<gml:posList>35.66723755478106 139.73863343783802 23.039 35.66723946535238 139.73863300479442 23.039 35.66722132654156 139.7386175068334 23.039 35.66722170700341 139.73861990332784 23.039 35.66723755478106 139.73863343783802 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7afadc2-43c2-413e-ad53-fa389ef4ba88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7afadc2-43c2-413e-ad53-fa389ef4ba88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7afadc2-43c2-413e-ad53-fa389ef4ba88">
											<gml:posList>35.66723755478106 139.73863343783802 23.039 35.66723647462793 139.73863533899578 23.039 35.667238637236146 139.7386344638215 23.039 35.66723946535238 139.73863300479442 23.039 35.66723755478106 139.73863343783802 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54aa7d91-d260-4a17-a104-a20bfea28689">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54aa7d91-d260-4a17-a104-a20bfea28689">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54aa7d91-d260-4a17-a104-a20bfea28689">
											<gml:posList>35.66723647462793 139.73863533899578 23.039 35.66723863948596 139.73863732468791 23.039 35.667238637236146 139.7386344638215 23.039 35.66723647462793 139.73863533899578 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef4bfffe-a546-454e-a9a5-5b09960fe283">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef4bfffe-a546-454e-a9a5-5b09960fe283">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef4bfffe-a546-454e-a9a5-5b09960fe283">
											<gml:posList>35.66723755478106 139.73863343783802 25.321 35.66722170700341 139.73861990332784 25.321 35.66722095998481 139.73862132912151 25.321 35.66719998683904 139.73865802601995 25.321 35.6672158616797 139.73867159363948 25.321 35.66723755478106 139.73863343783802 25.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49ec1dad-7fab-4bd6-ab40-4f6d14cd792a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49ec1dad-7fab-4bd6-ab40-4f6d14cd792a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49ec1dad-7fab-4bd6-ab40-4f6d14cd792a">
											<gml:posList>35.66718608638755 139.738587647426 23.039 35.66718608638755 139.738587647426 22.202 35.66723603744316 139.73850359594408 22.202 35.66723603744316 139.73850359594408 23.039 35.66718608638755 139.738587647426 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4645f7c-bbb0-41a6-9fb5-af316734dc92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4645f7c-bbb0-41a6-9fb5-af316734dc92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4645f7c-bbb0-41a6-9fb5-af316734dc92">
											<gml:posList>35.66722132654156 139.7386175068334 23.039 35.66722132654156 139.7386175068334 22.202 35.66722060652942 139.73861888841188 22.202 35.66722060652942 139.73861888841188 23.039 35.66722132654156 139.7386175068334 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71a342b6-c65a-47a7-a67a-d056a054d5fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71a342b6-c65a-47a7-a67a-d056a054d5fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71a342b6-c65a-47a7-a67a-d056a054d5fe">
											<gml:posList>35.6672158616797 139.73867159363948 25.321 35.6672158616797 139.73867159363948 13.05 35.66723647462793 139.73863533899578 13.05 35.66723647462793 139.73863533899578 23.039 35.66723755478106 139.73863343783802 23.039 35.66723755478106 139.73863343783802 25.321 35.6672158616797 139.73867159363948 25.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b9faebb-3fff-4121-9934-7d95950763f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b9faebb-3fff-4121-9934-7d95950763f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b9faebb-3fff-4121-9934-7d95950763f9">
											<gml:posList>35.667288570435616 139.738550589068 23.039 35.667288570435616 139.738550589068 22.202 35.667238637236146 139.7386344638215 22.202 35.667238637236146 139.7386344638215 23.039 35.667288570435616 139.738550589068 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34bb215d-846e-4323-ab20-3379bb199960">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34bb215d-846e-4323-ab20-3379bb199960">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34bb215d-846e-4323-ab20-3379bb199960">
											<gml:posList>35.667290490072524 139.73855022228645 13.05 35.667235738137336 139.73850124353712 13.05 35.667235738137336 139.73850124353712 23.039 35.667290490072524 139.73855022228645 23.039 35.667290490072524 139.73855022228645 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b956fa3-b34d-4ea8-9403-9f542bd0ae2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b956fa3-b34d-4ea8-9403-9f542bd0ae2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b956fa3-b34d-4ea8-9403-9f542bd0ae2c">
											<gml:posList>35.66723603744316 139.73850359594408 23.039 35.66723603744316 139.73850359594408 22.202 35.667288570435616 139.738550589068 22.202 35.667288570435616 139.738550589068 23.039 35.66723603744316 139.73850359594408 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b78d6cb5-b43c-4441-b80a-6358b0424572">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b78d6cb5-b43c-4441-b80a-6358b0424572">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b78d6cb5-b43c-4441-b80a-6358b0424572">
											<gml:posList>35.667235738137336 139.73850124353712 13.05 35.66718415773678 139.73858801421684 13.05 35.66718415773678 139.73858801421684 23.039 35.667235738137336 139.73850124353712 23.039 35.667235738137336 139.73850124353712 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-913f8ed7-c0bc-4806-a7f5-6d3a4b293ba3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-913f8ed7-c0bc-4806-a7f5-6d3a4b293ba3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-913f8ed7-c0bc-4806-a7f5-6d3a4b293ba3">
											<gml:posList>35.66723863948596 139.73863732468791 13.05 35.667290490072524 139.73855022228645 13.05 35.667290490072524 139.73855022228645 23.039 35.66723863948596 139.73863732468791 23.039 35.66723863948596 139.73863732468791 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ed3d492-3872-43c3-97ab-e6ab40e37581">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ed3d492-3872-43c3-97ab-e6ab40e37581">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ed3d492-3872-43c3-97ab-e6ab40e37581">
											<gml:posList>35.66722060652942 139.73861888841188 23.039 35.66722060652942 139.73861888841188 22.202 35.66718608638755 139.738587647426 22.202 35.66718608638755 139.738587647426 23.039 35.66722060652942 139.73861888841188 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74104571-3f6c-4bd7-81ac-6a53af5888dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74104571-3f6c-4bd7-81ac-6a53af5888dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74104571-3f6c-4bd7-81ac-6a53af5888dd">
											<gml:posList>35.66718415773678 139.73858801421684 13.05 35.66722095998481 139.73862132912151 13.05 35.66722095998481 139.73862132912151 23.039 35.66718415773678 139.73858801421684 23.039 35.66718415773678 139.73858801421684 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79abfd3f-b2b2-48dd-a4ce-4bc7bff1f073">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79abfd3f-b2b2-48dd-a4ce-4bc7bff1f073">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79abfd3f-b2b2-48dd-a4ce-4bc7bff1f073">
											<gml:posList>35.66722095998481 139.73862132912151 25.321 35.66722170700341 139.73861990332784 25.321 35.66722170700341 139.73861990332784 23.039 35.66722095998481 139.73862132912151 23.039 35.66722095998481 139.73862132912151 25.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a030a1df-c922-431c-bb7d-7fd78a794269">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a030a1df-c922-431c-bb7d-7fd78a794269">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a030a1df-c922-431c-bb7d-7fd78a794269">
											<gml:posList>35.66723946535238 139.73863300479442 23.039 35.66723946535238 139.73863300479442 22.202 35.66722132654156 139.7386175068334 22.202 35.66722132654156 139.7386175068334 23.039 35.66723946535238 139.73863300479442 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f2f9109-db21-4d46-86cf-a29f7c8c87f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f2f9109-db21-4d46-86cf-a29f7c8c87f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f2f9109-db21-4d46-86cf-a29f7c8c87f0">
											<gml:posList>35.66722170700341 139.73861990332784 25.321 35.66723755478106 139.73863343783802 25.321 35.66723755478106 139.73863343783802 23.039 35.66722170700341 139.73861990332784 23.039 35.66722170700341 139.73861990332784 25.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abee7db1-c026-4c08-92ce-39049eb460af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abee7db1-c026-4c08-92ce-39049eb460af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abee7db1-c026-4c08-92ce-39049eb460af">
											<gml:posList>35.66723647462793 139.73863533899578 13.05 35.66723863948596 139.73863732468791 13.05 35.66723863948596 139.73863732468791 23.039 35.66723647462793 139.73863533899578 23.039 35.66723647462793 139.73863533899578 13.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-607df113-7f24-437a-9a4e-05f45665337f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-607df113-7f24-437a-9a4e-05f45665337f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-607df113-7f24-437a-9a4e-05f45665337f">
											<gml:posList>35.66719998683904 139.73865802601995 25.321 35.66722095998481 139.73862132912151 25.321 35.66722095998481 139.73862132912151 23.039 35.66722095998481 139.73862132912151 13.05 35.66719998683904 139.73865802601995 13.05 35.66719998683904 139.73865802601995 25.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b5df15b-7650-42c3-94a4-3eea376f988c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b5df15b-7650-42c3-94a4-3eea376f988c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b5df15b-7650-42c3-94a4-3eea376f988c">
											<gml:posList>35.66719998683904 139.73865802601995 25.321 35.66719998683904 139.73865802601995 13.05 35.6672158616797 139.73867159363948 13.05 35.6672158616797 139.73867159363948 25.321 35.66719998683904 139.73865802601995 25.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2877943f-4d04-4c5f-9f27-e0ac29a011f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2877943f-4d04-4c5f-9f27-e0ac29a011f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2877943f-4d04-4c5f-9f27-e0ac29a011f1">
											<gml:posList>35.667238637236146 139.7386344638215 23.039 35.667238637236146 139.7386344638215 22.202 35.66723946535238 139.73863300479442 22.202 35.66723946535238 139.73863300479442 23.039 35.667238637236146 139.7386344638215 23.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6980</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">81.84525</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>