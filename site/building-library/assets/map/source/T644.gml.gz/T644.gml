<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_bb638b8b-69d4-42dd-a3a7-907a0d92786f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">14.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669211438441344 139.73916487614693 0 35.66929174949499 139.7390480244497 0 35.66918466978897 139.73893735803665 0 35.66910435884119 139.7390542096882 0 35.669211438441344 139.73916487614693 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669211438441344 139.73916487614693 14.115 35.66910435884119 139.7390542096882 14.115 35.66918466978897 139.73893735803665 14.115 35.66929174949499 139.7390480244497 14.115 35.669211438441344 139.73916487614693 14.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669211438441344 139.73916487614693 14.115 35.66929174949499 139.7390480244497 14.115 35.66929174949499 139.7390480244497 28.68 35.669211438441344 139.73916487614693 28.68 35.669211438441344 139.73916487614693 14.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929174949499 139.7390480244497 14.115 35.66918466978897 139.73893735803665 14.115 35.66918466978897 139.73893735803665 28.68 35.66929174949499 139.7390480244497 28.68 35.66929174949499 139.7390480244497 14.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918466978897 139.73893735803665 14.115 35.66910435884119 139.7390542096882 14.115 35.66910435884119 139.7390542096882 28.68 35.66918466978897 139.73893735803665 28.68 35.66918466978897 139.73893735803665 14.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910435884119 139.7390542096882 14.115 35.669211438441344 139.73916487614693 14.115 35.669211438441344 139.73916487614693 28.68 35.66910435884119 139.7390542096882 28.68 35.66910435884119 139.7390542096882 14.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669211438441344 139.73916487614693 28.68 35.66929174949499 139.7390480244497 28.68 35.66918466978897 139.73893735803665 28.68 35.66910435884119 139.7390542096882 28.68 35.669211438441344 139.73916487614693 28.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ffba9799-f644-412f-88fb-e59c51f696a9"/>
							<gml:surfaceMember xlink:href="#poly-906e0b27-0261-4f23-a59d-2d872734bb02"/>
							<gml:surfaceMember xlink:href="#poly-5e1ddbab-f4a5-4566-8479-8365f7565838"/>
							<gml:surfaceMember xlink:href="#poly-6fbe3fbe-0d07-4a61-9365-bbb54b5f3845"/>
							<gml:surfaceMember xlink:href="#poly-2fbf8fda-c451-4fde-b5f3-73b4f1b6a145"/>
							<gml:surfaceMember xlink:href="#poly-ec7d6257-9a50-4f88-9b5e-6ca75555bafd"/>
							<gml:surfaceMember xlink:href="#poly-a18c59bc-88cc-40d7-8af0-9a9126eac60f"/>
							<gml:surfaceMember xlink:href="#poly-0ba32a43-1921-42bb-9b1b-f1446c7f8945"/>
							<gml:surfaceMember xlink:href="#poly-5b1b0c2d-10c6-4142-85bc-ea025a8ffabe"/>
							<gml:surfaceMember xlink:href="#poly-6fc3558d-c478-427d-9a59-505de866039d"/>
							<gml:surfaceMember xlink:href="#poly-17405e35-1dfd-457b-8d1c-07b390328782"/>
							<gml:surfaceMember xlink:href="#poly-18930787-d1c9-451c-b311-55c5042f5e16"/>
							<gml:surfaceMember xlink:href="#poly-1e6ede07-7d46-4913-9deb-3bd9d41eaf2a"/>
							<gml:surfaceMember xlink:href="#poly-8032163b-6eb8-4436-b9fe-c2eb030e2de3"/>
							<gml:surfaceMember xlink:href="#poly-1a116e9d-7d30-45fa-834f-1b0d4fd4f036"/>
							<gml:surfaceMember xlink:href="#poly-990fd4db-af57-4520-801d-f97aea70bdbd"/>
							<gml:surfaceMember xlink:href="#poly-961147d7-5906-45b6-abda-6e155ed6023e"/>
							<gml:surfaceMember xlink:href="#poly-0b53d9e8-9675-4d48-bb5a-f662cdbd25cd"/>
							<gml:surfaceMember xlink:href="#poly-adce712d-be89-4039-b7d8-d9eaffdd1938"/>
							<gml:surfaceMember xlink:href="#poly-f8733b93-019f-42f4-a071-ffbec8edb7f2"/>
							<gml:surfaceMember xlink:href="#poly-1c0fd738-4ace-49d2-800e-a576a94a788a"/>
							<gml:surfaceMember xlink:href="#poly-a30d194d-28d4-40b9-ac49-cbe2ed9e6d45"/>
							<gml:surfaceMember xlink:href="#poly-fb4ddf69-a85b-4d9e-9ced-3ecefc8a9387"/>
							<gml:surfaceMember xlink:href="#poly-09c35559-b931-473e-8c0e-d9f6cc92ebb1"/>
							<gml:surfaceMember xlink:href="#poly-e64a4178-d511-437b-8b49-2814d64f5967"/>
							<gml:surfaceMember xlink:href="#poly-7a0729b1-8f40-409a-9da8-10c0dc9270f4"/>
							<gml:surfaceMember xlink:href="#poly-df96b243-08f5-4fa4-bbdc-01c77b2f5596"/>
							<gml:surfaceMember xlink:href="#poly-ff6c91d9-8767-4bb0-95bd-b361e18505d6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bb638b8b-69d4-42dd-a3a7-907a0d92786f_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d06771bd-bd45-4de8-b0b0-fb99f53e3b0a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920715413821 139.73902311556077 29.038 35.66921252013174 139.7390152112888 29.038 35.669238861279624 139.7390420886079 29.038 35.66923348627063 139.73904999289124 29.038 35.669207587151675 139.73902356794147 29.038 35.66920715413821 139.73902311556077 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64caa6a6-21ff-4e01-94f7-bda201fbba17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64caa6a6-21ff-4e01-94f7-bda201fbba17_0">
											<gml:posList>35.669207587151675 139.73902356794147 29.038 35.669207587151675 139.73902356794147 29.509 35.66920715413821 139.73902311556077 29.509 35.66920715413821 139.73902311556077 29.038 35.669207587151675 139.73902356794147 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d407a0c2-6061-414b-9332-365a52fb788d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d407a0c2-6061-414b-9332-365a52fb788d_0">
											<gml:posList>35.66920715413821 139.73902311556077 29.038 35.66920715413821 139.73902311556077 29.509 35.66921252013174 139.7390152112888 29.509 35.66921252013174 139.7390152112888 29.038 35.66920715413821 139.73902311556077 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f05b49a8-bc97-46e6-917d-e89ff56e8518">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f05b49a8-bc97-46e6-917d-e89ff56e8518_0">
											<gml:posList>35.669207587151675 139.73902356794147 29.509 35.669207587151675 139.73902356794147 29.038 35.66923348627063 139.73904999289124 29.038 35.66923348627063 139.73904999289124 29.509 35.669207587151675 139.73902356794147 29.509</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da9364c6-29d4-43db-b880-7b9600a940ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da9364c6-29d4-43db-b880-7b9600a940ee_0">
											<gml:posList>35.669207587151675 139.73902356794147 29.509 35.66923348627063 139.73904999289124 29.509 35.669238861279624 139.7390420886079 29.509 35.66921252013174 139.7390152112888 29.509 35.66920715413821 139.73902311556077 29.509 35.669207587151675 139.73902356794147 29.509</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d52331dd-7ab1-4f45-ae0a-fd1cc6db29a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d52331dd-7ab1-4f45-ae0a-fd1cc6db29a8_0">
											<gml:posList>35.66921252013174 139.7390152112888 29.509 35.669238861279624 139.7390420886079 29.509 35.669238861279624 139.7390420886079 29.038 35.66921252013174 139.7390152112888 29.038 35.66921252013174 139.7390152112888 29.509</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b76e71d-5926-4336-87d9-e067e2a5612f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b76e71d-5926-4336-87d9-e067e2a5612f_0">
											<gml:posList>35.669238861279624 139.7390420886079 29.038 35.669238861279624 139.7390420886079 29.509 35.66923348627063 139.73904999289124 29.509 35.66923348627063 139.73904999289124 29.038 35.669238861279624 139.7390420886079 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bb638b8b-69d4-42dd-a3a7-907a0d92786f_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f4dc7a2-3fdd-49cb-a8ab-e64a965e32e2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669206443332136 139.73905928132035 34.442 35.669196637569804 139.73904927404033 34.442 35.66920492066414 139.739037091501 34.442 35.66921472641884 139.73904708773446 34.442 35.669206443332136 139.73905928132035 34.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75818b18-984d-4efa-93c7-cfbf19cac178">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75818b18-984d-4efa-93c7-cfbf19cac178_0">
											<gml:posList>35.669196637569804 139.73904927404033 34.442 35.669196637569804 139.73904927404033 37.197 35.66920492066414 139.739037091501 37.197 35.66920492066414 139.739037091501 34.442 35.669196637569804 139.73904927404033 34.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0e22275-f921-42bd-afa6-ddf41376afa9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0e22275-f921-42bd-afa6-ddf41376afa9_0">
											<gml:posList>35.669206443332136 139.73905928132035 34.442 35.669206443332136 139.73905928132035 37.197 35.669196637569804 139.73904927404033 37.197 35.669196637569804 139.73904927404033 34.442 35.669206443332136 139.73905928132035 34.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52077832-aca3-4ae8-ae41-d5c438dd56ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52077832-aca3-4ae8-ae41-d5c438dd56ad_0">
											<gml:posList>35.669206443332136 139.73905928132035 37.197 35.66921472641884 139.73904708773446 37.197 35.66920492066414 139.739037091501 37.197 35.669196637569804 139.73904927404033 37.197 35.669206443332136 139.73905928132035 37.197</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13a8c3a6-52ed-4611-8e9e-744353d9b282">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13a8c3a6-52ed-4611-8e9e-744353d9b282_0">
											<gml:posList>35.66920492066414 139.739037091501 34.442 35.66920492066414 139.739037091501 37.197 35.66921472641884 139.73904708773446 37.197 35.66921472641884 139.73904708773446 34.442 35.66920492066414 139.739037091501 34.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c692fef9-3b99-4da8-a805-a203dd683704">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c692fef9-3b99-4da8-a805-a203dd683704_0">
											<gml:posList>35.66921472641884 139.73904708773446 34.442 35.66921472641884 139.73904708773446 37.197 35.669206443332136 139.73905928132035 37.197 35.669206443332136 139.73905928132035 34.442 35.66921472641884 139.73904708773446 34.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bb638b8b-69d4-42dd-a3a7-907a0d92786f_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25a73db8-f757-498d-8968-9914f8813705">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920727702781 139.7391110092157 29.038 35.66919542859618 139.73912844283257 29.038 35.66917966000563 139.73911235615418 29.038 35.66919150843497 139.73909492253838 29.038 35.66920727702781 139.7391110092157 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-529d6b73-8a25-40a9-bec9-7113f30de90f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-529d6b73-8a25-40a9-bec9-7113f30de90f_0">
											<gml:posList>35.66919150843497 139.73909492253838 29.038 35.66919150843497 139.73909492253838 30.795 35.66920727702781 139.7391110092157 30.795 35.66920727702781 139.7391110092157 29.038 35.66919150843497 139.73909492253838 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9468d61-4c80-45b4-b5b4-8e337cafc3d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9468d61-4c80-45b4-b5b4-8e337cafc3d4_0">
											<gml:posList>35.66917966000563 139.73911235615418 29.038 35.66917966000563 139.73911235615418 30.795 35.66919150843497 139.73909492253838 30.795 35.66919150843497 139.73909492253838 29.038 35.66917966000563 139.73911235615418 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b10a9c52-0622-4555-a43b-dcb8a993cbf3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b10a9c52-0622-4555-a43b-dcb8a993cbf3_0">
											<gml:posList>35.66917966000563 139.73911235615418 30.795 35.66919542859618 139.73912844283257 30.795 35.66920727702781 139.7391110092157 30.795 35.66919150843497 139.73909492253838 30.795 35.66917966000563 139.73911235615418 30.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2c25fcb-0c9a-4f68-9300-81fb04244e56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2c25fcb-0c9a-4f68-9300-81fb04244e56_0">
											<gml:posList>35.66920727702781 139.7391110092157 29.038 35.66920727702781 139.7391110092157 30.795 35.66919542859618 139.73912844283257 30.795 35.66919542859618 139.73912844283257 29.038 35.66920727702781 139.7391110092157 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cab9a4c-0fb4-42e7-b7cb-74ca6675073e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6cab9a4c-0fb4-42e7-b7cb-74ca6675073e_0">
											<gml:posList>35.66919542859618 139.73912844283257 29.038 35.66919542859618 139.73912844283257 30.795 35.66917966000563 139.73911235615418 30.795 35.66917966000563 139.73911235615418 29.038 35.66919542859618 139.73912844283257 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ffba9799-f644-412f-88fb-e59c51f696a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffba9799-f644-412f-88fb-e59c51f696a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffba9799-f644-412f-88fb-e59c51f696a9">
											<gml:posList>35.669211438441316 139.7391648761469 14.115 35.66910435884119 139.7390542096882 14.115 35.66918466978896 139.73893735803662 14.115 35.66929174949498 139.73904802444966 14.115 35.669211438441316 139.7391648761469 14.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-906e0b27-0261-4f23-a59d-2d872734bb02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-906e0b27-0261-4f23-a59d-2d872734bb02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-906e0b27-0261-4f23-a59d-2d872734bb02">
											<gml:posList>35.669136817064555 139.73904240743926 16.857 35.66917733268898 139.738983462023 16.857 35.669163088489164 139.73896876539024 16.857 35.66912257287182 139.73902771080344 16.857 35.669136817064555 139.73904240743926 16.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e1ddbab-f4a5-4566-8479-8365f7565838">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e1ddbab-f4a5-4566-8479-8365f7565838">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e1ddbab-f4a5-4566-8479-8365f7565838">
											<gml:posList>35.66922441648872 139.73897843587392 29.858 35.669224662672256 139.73898202556674 29.858 35.6692752345974 139.73903429146637 29.858 35.669278154801766 139.73903397874096 29.858 35.66922441648872 139.73897843587392 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6fbe3fbe-0d07-4a61-9365-bbb54b5f3845">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fbe3fbe-0d07-4a61-9365-bbb54b5f3845">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fbe3fbe-0d07-4a61-9365-bbb54b5f3845">
											<gml:posList>35.669136817064555 139.73904240743926 27.024 35.66912257287182 139.73902771080344 25.431 35.66910435884119 139.7390542096882 25.431 35.66914404235371 139.73909522134014 29.858 35.66922441648872 139.73897843587392 29.858 35.66918466978896 139.73893735803662 25.431 35.669163088489164 139.73896876539024 25.431 35.66917733268898 139.738983462023 27.024 35.669136817064555 139.73904240743926 27.024</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2fbf8fda-c451-4fde-b5f3-73b4f1b6a145">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fbf8fda-c451-4fde-b5f3-73b4f1b6a145">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fbf8fda-c451-4fde-b5f3-73b4f1b6a145">
											<gml:posList>35.66914404235371 139.73909522134014 29.858 35.669146980585744 139.7390949085963 29.858 35.669224662672256 139.73898202556674 29.858 35.66922441648872 139.73897843587392 29.858 35.66914404235371 139.73909522134014 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec7d6257-9a50-4f88-9b5e-6ca75555bafd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec7d6257-9a50-4f88-9b5e-6ca75555bafd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec7d6257-9a50-4f88-9b5e-6ca75555bafd">
											<gml:posList>35.669146980585744 139.7390949085963 29.038 35.669175572897814 139.73907283803496 29.038 35.66920845316129 139.73902445061069 29.038 35.669224662672256 139.73898202556674 29.038 35.669146980585744 139.7390949085963 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a18c59bc-88cc-40d7-8af0-9a9126eac60f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a18c59bc-88cc-40d7-8af0-9a9126eac60f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a18c59bc-88cc-40d7-8af0-9a9126eac60f">
											<gml:posList>35.66922686490382 139.73904324046376 34.442 35.66920845316129 139.73902445061069 34.442 35.669175572897814 139.73907283803496 34.442 35.6691939846329 139.7390916278915 34.442 35.66922686490382 139.73904324046376 34.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ba32a43-1921-42bb-9b1b-f1446c7f8945">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ba32a43-1921-42bb-9b1b-f1446c7f8945">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ba32a43-1921-42bb-9b1b-f1446c7f8945">
											<gml:posList>35.6692752345974 139.73903429146637 29.038 35.669224662672256 139.73898202556674 29.038 35.66920845316129 139.73902445061069 29.038 35.66924542097537 139.73906217375512 29.038 35.66921253168323 139.73911056119692 29.038 35.669175572897814 139.73907283803496 29.038 35.669146980585744 139.7390949085963 29.038 35.66919760658813 139.73914722968357 29.038 35.6692752345974 139.73903429146637 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b1b0c2d-10c6-4142-85bc-ea025a8ffabe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b1b0c2d-10c6-4142-85bc-ea025a8ffabe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b1b0c2d-10c6-4142-85bc-ea025a8ffabe">
											<gml:posList>35.66921253168323 139.73911056119692 32.887 35.66924542097537 139.73906217375512 32.887 35.66922686490382 139.73904324046376 32.887 35.6691939846329 139.7390916278915 32.887 35.66921253168323 139.73911056119692 32.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6fc3558d-c478-427d-9a59-505de866039d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fc3558d-c478-427d-9a59-505de866039d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fc3558d-c478-427d-9a59-505de866039d">
											<gml:posList>35.669278154801766 139.73903397874096 29.858 35.6692752345974 139.73903429146637 29.858 35.66919760658813 139.73914722968357 29.858 35.669197843761545 139.7391508304324 29.858 35.669278154801766 139.73903397874096 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17405e35-1dfd-457b-8d1c-07b390328782">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17405e35-1dfd-457b-8d1c-07b390328782">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17405e35-1dfd-457b-8d1c-07b390328782">
											<gml:posList>35.669278154801766 139.73903397874096 29.858 35.669197843761545 139.7391508304324 29.858 35.669211438441316 139.7391648761469 28.838 35.66929174949498 139.73904802444966 28.838 35.669278154801766 139.73903397874096 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18930787-d1c9-451c-b311-55c5042f5e16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18930787-d1c9-451c-b311-55c5042f5e16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18930787-d1c9-451c-b311-55c5042f5e16">
											<gml:posList>35.669197843761545 139.7391508304324 29.858 35.66919760658813 139.73914722968357 29.858 35.669146980585744 139.7390949085963 29.858 35.66914404235371 139.73909522134014 29.858 35.669197843761545 139.7391508304324 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e6ede07-7d46-4913-9deb-3bd9d41eaf2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e6ede07-7d46-4913-9deb-3bd9d41eaf2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e6ede07-7d46-4913-9deb-3bd9d41eaf2a">
											<gml:posList>35.66917733268898 139.738983462023 16.857 35.66917733268898 139.738983462023 27.024 35.669163088489164 139.73896876539024 25.431 35.669163088489164 139.73896876539024 16.857 35.66917733268898 139.738983462023 16.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8032163b-6eb8-4436-b9fe-c2eb030e2de3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8032163b-6eb8-4436-b9fe-c2eb030e2de3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8032163b-6eb8-4436-b9fe-c2eb030e2de3">
											<gml:posList>35.66918466978896 139.73893735803662 25.431 35.66922441648872 139.73897843587392 29.858 35.669278154801766 139.73903397874096 29.858 35.66929174949498 139.73904802444966 28.838 35.66929174949498 139.73904802444966 14.115 35.66918466978896 139.73893735803662 14.115 35.66918466978896 139.73893735803662 25.431</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a116e9d-7d30-45fa-834f-1b0d4fd4f036">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a116e9d-7d30-45fa-834f-1b0d4fd4f036">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a116e9d-7d30-45fa-834f-1b0d4fd4f036">
											<gml:posList>35.66910435884119 139.7390542096882 14.115 35.66910435884119 139.7390542096882 25.431 35.66912257287182 139.73902771080344 25.431 35.66912257287182 139.73902771080344 16.857 35.669163088489164 139.73896876539024 16.857 35.669163088489164 139.73896876539024 25.431 35.66918466978896 139.73893735803662 25.431 35.66918466978896 139.73893735803662 14.115 35.66910435884119 139.7390542096882 14.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-990fd4db-af57-4520-801d-f97aea70bdbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-990fd4db-af57-4520-801d-f97aea70bdbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-990fd4db-af57-4520-801d-f97aea70bdbd">
											<gml:posList>35.669224662672256 139.73898202556674 29.858 35.669224662672256 139.73898202556674 29.038 35.6692752345974 139.73903429146637 29.038 35.6692752345974 139.73903429146637 29.858 35.669224662672256 139.73898202556674 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-961147d7-5906-45b6-abda-6e155ed6023e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-961147d7-5906-45b6-abda-6e155ed6023e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-961147d7-5906-45b6-abda-6e155ed6023e">
											<gml:posList>35.669136817064555 139.73904240743926 16.857 35.669136817064555 139.73904240743926 27.024 35.66917733268898 139.738983462023 27.024 35.66917733268898 139.738983462023 16.857 35.669136817064555 139.73904240743926 16.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b53d9e8-9675-4d48-bb5a-f662cdbd25cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b53d9e8-9675-4d48-bb5a-f662cdbd25cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b53d9e8-9675-4d48-bb5a-f662cdbd25cd">
											<gml:posList>35.669136817064555 139.73904240743926 16.857 35.66912257287182 139.73902771080344 16.857 35.66912257287182 139.73902771080344 25.431 35.669136817064555 139.73904240743926 27.024 35.669136817064555 139.73904240743926 16.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adce712d-be89-4039-b7d8-d9eaffdd1938">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adce712d-be89-4039-b7d8-d9eaffdd1938">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adce712d-be89-4039-b7d8-d9eaffdd1938">
											<gml:posList>35.669146980585744 139.7390949085963 29.858 35.669146980585744 139.7390949085963 29.038 35.669224662672256 139.73898202556674 29.038 35.669224662672256 139.73898202556674 29.858 35.669146980585744 139.7390949085963 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8733b93-019f-42f4-a071-ffbec8edb7f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8733b93-019f-42f4-a071-ffbec8edb7f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8733b93-019f-42f4-a071-ffbec8edb7f2">
											<gml:posList>35.66924542097537 139.73906217375512 29.038 35.66920845316129 139.73902445061069 29.038 35.66920845316129 139.73902445061069 34.442 35.66922686490382 139.73904324046376 34.442 35.66922686490382 139.73904324046376 32.887 35.66924542097537 139.73906217375512 32.887 35.66924542097537 139.73906217375512 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c0fd738-4ace-49d2-800e-a576a94a788a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c0fd738-4ace-49d2-800e-a576a94a788a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c0fd738-4ace-49d2-800e-a576a94a788a">
											<gml:posList>35.669175572897814 139.73907283803496 34.442 35.66920845316129 139.73902445061069 34.442 35.66920845316129 139.73902445061069 29.038 35.669175572897814 139.73907283803496 29.038 35.669175572897814 139.73907283803496 34.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a30d194d-28d4-40b9-ac49-cbe2ed9e6d45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a30d194d-28d4-40b9-ac49-cbe2ed9e6d45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a30d194d-28d4-40b9-ac49-cbe2ed9e6d45">
											<gml:posList>35.66922686490382 139.73904324046376 32.887 35.66922686490382 139.73904324046376 34.442 35.6691939846329 139.7390916278915 34.442 35.6691939846329 139.7390916278915 32.887 35.66922686490382 139.73904324046376 32.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb4ddf69-a85b-4d9e-9ced-3ecefc8a9387">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb4ddf69-a85b-4d9e-9ced-3ecefc8a9387">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb4ddf69-a85b-4d9e-9ced-3ecefc8a9387">
											<gml:posList>35.66924542097537 139.73906217375512 32.887 35.66921253168323 139.73911056119692 32.887 35.66921253168323 139.73911056119692 29.038 35.66924542097537 139.73906217375512 29.038 35.66924542097537 139.73906217375512 32.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09c35559-b931-473e-8c0e-d9f6cc92ebb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09c35559-b931-473e-8c0e-d9f6cc92ebb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09c35559-b931-473e-8c0e-d9f6cc92ebb1">
											<gml:posList>35.6692752345974 139.73903429146637 29.858 35.6692752345974 139.73903429146637 29.038 35.66919760658813 139.73914722968357 29.038 35.66919760658813 139.73914722968357 29.858 35.6692752345974 139.73903429146637 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e64a4178-d511-437b-8b49-2814d64f5967">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e64a4178-d511-437b-8b49-2814d64f5967">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e64a4178-d511-437b-8b49-2814d64f5967">
											<gml:posList>35.66921253168323 139.73911056119692 29.038 35.66921253168323 139.73911056119692 32.887 35.6691939846329 139.7390916278915 32.887 35.6691939846329 139.7390916278915 34.442 35.669175572897814 139.73907283803496 34.442 35.669175572897814 139.73907283803496 29.038 35.66921253168323 139.73911056119692 29.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a0729b1-8f40-409a-9da8-10c0dc9270f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a0729b1-8f40-409a-9da8-10c0dc9270f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a0729b1-8f40-409a-9da8-10c0dc9270f4">
											<gml:posList>35.669211438441316 139.7391648761469 14.115 35.66929174949498 139.73904802444966 14.115 35.66929174949498 139.73904802444966 28.838 35.669211438441316 139.7391648761469 28.838 35.669211438441316 139.7391648761469 14.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df96b243-08f5-4fa4-bbdc-01c77b2f5596">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df96b243-08f5-4fa4-bbdc-01c77b2f5596">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df96b243-08f5-4fa4-bbdc-01c77b2f5596">
											<gml:posList>35.669211438441316 139.7391648761469 28.838 35.669197843761545 139.7391508304324 29.858 35.66914404235371 139.73909522134014 29.858 35.66910435884119 139.7390542096882 25.431 35.66910435884119 139.7390542096882 14.115 35.669211438441316 139.7391648761469 14.115 35.669211438441316 139.7391648761469 28.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff6c91d9-8767-4bb0-95bd-b361e18505d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff6c91d9-8767-4bb0-95bd-b361e18505d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff6c91d9-8767-4bb0-95bd-b361e18505d6">
											<gml:posList>35.66919760658813 139.73914722968357 29.858 35.66919760658813 139.73914722968357 29.038 35.669146980585744 139.7390949085963 29.038 35.669146980585744 139.7390949085963 29.858 35.66919760658813 139.73914722968357 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4421</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">214.9335</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>