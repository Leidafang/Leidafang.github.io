<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_bc726e87-a262-47b9-a223-36cad8519012">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">5.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66778793168906 139.74237273154117 0 35.66769387987222 139.74232169576288 0 35.66767669962593 139.74236932303648 0 35.66777075142295 139.74242035885976 0 35.66778793168906 139.74237273154117 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66778793168906 139.74237273154117 28.586 35.66777075142295 139.74242035885976 28.586 35.66767669962593 139.74236932303648 28.586 35.66769387987222 139.74232169576288 28.586 35.66778793168906 139.74237273154117 28.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66778793168906 139.74237273154117 28.586 35.66769387987222 139.74232169576288 28.586 35.66769387987222 139.74232169576288 34.51 35.66778793168906 139.74237273154117 34.51 35.66778793168906 139.74237273154117 28.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66769387987222 139.74232169576288 28.586 35.66767669962593 139.74236932303648 28.586 35.66767669962593 139.74236932303648 34.51 35.66769387987222 139.74232169576288 34.51 35.66769387987222 139.74232169576288 28.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66767669962593 139.74236932303648 28.586 35.66777075142295 139.74242035885976 28.586 35.66777075142295 139.74242035885976 34.51 35.66767669962593 139.74236932303648 34.51 35.66767669962593 139.74236932303648 28.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66777075142295 139.74242035885976 28.586 35.66778793168906 139.74237273154117 28.586 35.66778793168906 139.74237273154117 34.51 35.66777075142295 139.74242035885976 34.51 35.66777075142295 139.74242035885976 28.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66778793168906 139.74237273154117 34.51 35.66769387987222 139.74232169576288 34.51 35.66767669962593 139.74236932303648 34.51 35.66777075142295 139.74242035885976 34.51 35.66778793168906 139.74237273154117 34.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7bf71829-5e55-42e8-85d9-77ecf2fe7795"/>
							<gml:surfaceMember xlink:href="#poly-e2c88c04-e40b-4287-b71a-521c18af94cc"/>
							<gml:surfaceMember xlink:href="#poly-240f1b88-dc19-45f6-be3f-31908821631d"/>
							<gml:surfaceMember xlink:href="#poly-5c8465aa-153b-4433-b2a2-66df8c77cbea"/>
							<gml:surfaceMember xlink:href="#poly-8f666579-4da4-472f-8748-7ab94b49a8bb"/>
							<gml:surfaceMember xlink:href="#poly-63739110-7576-4fc0-b9a5-07ff7bd70d9d"/>
							<gml:surfaceMember xlink:href="#poly-c2b38acd-3100-461f-adfb-2698e11f8d27"/>
							<gml:surfaceMember xlink:href="#poly-f95e624d-4b4f-45ee-92be-130799fa5c5c"/>
							<gml:surfaceMember xlink:href="#poly-c3141b23-10a1-4042-b3cd-5b4abcc37b1a"/>
							<gml:surfaceMember xlink:href="#poly-ca14657e-4a10-4e53-a5da-9b81353581c4"/>
							<gml:surfaceMember xlink:href="#poly-6396289f-96c8-4bec-a109-5dc7393102be"/>
							<gml:surfaceMember xlink:href="#poly-1d2952cd-fbe5-4591-b37b-e89ae0c24f3e"/>
							<gml:surfaceMember xlink:href="#poly-d38c8bd2-455a-4651-8994-232923bf2f69"/>
							<gml:surfaceMember xlink:href="#poly-e96b1190-6565-4414-945d-fbe4b783a89a"/>
							<gml:surfaceMember xlink:href="#poly-c9447017-6dfc-45dc-923e-c04c7be418a3"/>
							<gml:surfaceMember xlink:href="#poly-fc318253-8db5-49fd-ae94-f47006babec1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bc726e87-a262-47b9-a223-36cad8519012_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5252c8a9-8755-43a9-b048-689d54ae9a9b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667762262680256 139.74237552213432 34.693 35.66777638370847 139.7423828295485 34.693 35.66776886473295 139.7424046868669 34.693 35.66775473469231 139.7423973794598 34.693 35.667762262680256 139.74237552213432 34.693</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-707deb04-80e7-42e4-9692-2d5bfdf87c13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-707deb04-80e7-42e4-9692-2d5bfdf87c13_0">
											<gml:posList>35.66775473469231 139.7423973794598 34.693 35.66775473469231 139.7423973794598 36.788 35.667762262680256 139.74237552213432 36.788 35.667762262680256 139.74237552213432 34.693 35.66775473469231 139.7423973794598 34.693</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ac3ef09-f100-4748-beaa-5f589785c3f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ac3ef09-f100-4748-beaa-5f589785c3f9_0">
											<gml:posList>35.66776886473295 139.7424046868669 34.693 35.66776886473295 139.7424046868669 36.788 35.66775473469231 139.7423973794598 36.788 35.66775473469231 139.7423973794598 34.693 35.66776886473295 139.7424046868669 34.693</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b76b3ae-5dab-4c57-8987-e3ca71377158">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b76b3ae-5dab-4c57-8987-e3ca71377158_0">
											<gml:posList>35.66776886473295 139.7424046868669 36.788 35.66777638370847 139.7423828295485 36.788 35.667762262680256 139.74237552213432 36.788 35.66775473469231 139.7423973794598 36.788 35.66776886473295 139.7424046868669 36.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e29bb5dd-66b5-4e2c-8be1-2b44b6bcda75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e29bb5dd-66b5-4e2c-8be1-2b44b6bcda75_0">
											<gml:posList>35.667762262680256 139.74237552213432 34.693 35.667762262680256 139.74237552213432 36.788 35.66777638370847 139.7423828295485 36.788 35.66777638370847 139.7423828295485 34.693 35.667762262680256 139.74237552213432 34.693</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a05e2bac-6189-4d10-bd78-0c86f5803d2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a05e2bac-6189-4d10-bd78-0c86f5803d2f_0">
											<gml:posList>35.66777638370847 139.7423828295485 34.693 35.66777638370847 139.7423828295485 36.788 35.66776886473295 139.7424046868669 36.788 35.66776886473295 139.7424046868669 34.693 35.66777638370847 139.7423828295485 34.693</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7bf71829-5e55-42e8-85d9-77ecf2fe7795">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bf71829-5e55-42e8-85d9-77ecf2fe7795">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bf71829-5e55-42e8-85d9-77ecf2fe7795">
											<gml:posList>35.66778793168906 139.74237273154117 28.586 35.66777075142294 139.74242035885976 28.586 35.66767669962593 139.74236932303646 28.586 35.6676938798722 139.74232169576288 28.586 35.66778793168906 139.74237273154117 28.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2c88c04-e40b-4287-b71a-521c18af94cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2c88c04-e40b-4287-b71a-521c18af94cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2c88c04-e40b-4287-b71a-521c18af94cc">
											<gml:posList>35.66771142694793 139.74235395194304 36.717 35.66768701676465 139.7423407135269 36.717 35.66767669962593 139.74236932303646 36.717 35.66770109177866 139.74238256148007 36.717 35.66771142694793 139.74235395194304 36.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-240f1b88-dc19-45f6-be3f-31908821631d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-240f1b88-dc19-45f6-be3f-31908821631d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-240f1b88-dc19-45f6-be3f-31908821631d">
											<gml:posList>35.66777045181833 139.74241750935724 35.5 35.66770190132046 139.74238031824606 35.5 35.66770109177866 139.74238256148007 35.5 35.66777075142294 139.74242035885976 35.5 35.66777045181833 139.74241750935724 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c8465aa-153b-4433-b2a2-66df8c77cbea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c8465aa-153b-4433-b2a2-66df8c77cbea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c8465aa-153b-4433-b2a2-66df8c77cbea">
											<gml:posList>35.66771142694793 139.74235395194304 34.693 35.66770190132046 139.74238031824606 34.693 35.66777045181833 139.74241750935724 34.693 35.66778600404476 139.74237444584267 34.693 35.66769464846839 139.7423249092444 34.693 35.667688621867484 139.74234158433066 34.693 35.66771142694793 139.74235395194304 34.693</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8f666579-4da4-472f-8748-7ab94b49a8bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f666579-4da4-472f-8748-7ab94b49a8bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f666579-4da4-472f-8748-7ab94b49a8bb">
											<gml:posList>35.6676938798722 139.74232169576288 35.5 35.66768701676465 139.7423407135269 35.5 35.667688621867484 139.74234158433066 35.5 35.66769464846839 139.7423249092444 35.5 35.66778600404476 139.74237444584267 35.5 35.66778793168906 139.74237273154117 35.5 35.6676938798722 139.74232169576288 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63739110-7576-4fc0-b9a5-07ff7bd70d9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63739110-7576-4fc0-b9a5-07ff7bd70d9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63739110-7576-4fc0-b9a5-07ff7bd70d9d">
											<gml:posList>35.66778793168906 139.74237273154117 35.5 35.66778600404476 139.74237444584267 35.5 35.66777045181833 139.74241750935724 35.5 35.66777075142294 139.74242035885976 35.5 35.66778793168906 139.74237273154117 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2b38acd-3100-461f-adfb-2698e11f8d27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2b38acd-3100-461f-adfb-2698e11f8d27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2b38acd-3100-461f-adfb-2698e11f8d27">
											<gml:posList>35.66769464846839 139.7423249092444 35.5 35.66769464846839 139.7423249092444 34.693 35.66778600404476 139.74237444584267 34.693 35.66778600404476 139.74237444584267 35.5 35.66769464846839 139.7423249092444 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f95e624d-4b4f-45ee-92be-130799fa5c5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f95e624d-4b4f-45ee-92be-130799fa5c5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f95e624d-4b4f-45ee-92be-130799fa5c5c">
											<gml:posList>35.667688621867484 139.74234158433066 35.5 35.667688621867484 139.74234158433066 34.693 35.66769464846839 139.7423249092444 34.693 35.66769464846839 139.7423249092444 35.5 35.667688621867484 139.74234158433066 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3141b23-10a1-4042-b3cd-5b4abcc37b1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3141b23-10a1-4042-b3cd-5b4abcc37b1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3141b23-10a1-4042-b3cd-5b4abcc37b1a">
											<gml:posList>35.66767669962593 139.74236932303646 28.586 35.66767669962593 139.74236932303646 36.717 35.66768701676465 139.7423407135269 36.717 35.66768701676465 139.7423407135269 35.5 35.6676938798722 139.74232169576288 35.5 35.6676938798722 139.74232169576288 28.586 35.66767669962593 139.74236932303646 28.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca14657e-4a10-4e53-a5da-9b81353581c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca14657e-4a10-4e53-a5da-9b81353581c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca14657e-4a10-4e53-a5da-9b81353581c4">
											<gml:posList>35.66778793168906 139.74237273154117 28.586 35.6676938798722 139.74232169576288 28.586 35.6676938798722 139.74232169576288 35.5 35.66778793168906 139.74237273154117 35.5 35.66778793168906 139.74237273154117 28.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6396289f-96c8-4bec-a109-5dc7393102be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6396289f-96c8-4bec-a109-5dc7393102be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6396289f-96c8-4bec-a109-5dc7393102be">
											<gml:posList>35.667688621867484 139.74234158433066 35.5 35.66768701676465 139.7423407135269 35.5 35.66768701676465 139.7423407135269 36.717 35.66771142694793 139.74235395194304 36.717 35.66771142694793 139.74235395194304 34.693 35.667688621867484 139.74234158433066 34.693 35.667688621867484 139.74234158433066 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d2952cd-fbe5-4591-b37b-e89ae0c24f3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d2952cd-fbe5-4591-b37b-e89ae0c24f3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d2952cd-fbe5-4591-b37b-e89ae0c24f3e">
											<gml:posList>35.66771142694793 139.74235395194304 34.693 35.66771142694793 139.74235395194304 36.717 35.66770109177866 139.74238256148007 36.717 35.66770109177866 139.74238256148007 35.5 35.66770190132046 139.74238031824606 35.5 35.66770190132046 139.74238031824606 34.693 35.66771142694793 139.74235395194304 34.693</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d38c8bd2-455a-4651-8994-232923bf2f69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d38c8bd2-455a-4651-8994-232923bf2f69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d38c8bd2-455a-4651-8994-232923bf2f69">
											<gml:posList>35.66777075142294 139.74242035885976 28.586 35.66777075142294 139.74242035885976 35.5 35.66770109177866 139.74238256148007 35.5 35.66770109177866 139.74238256148007 36.717 35.66767669962593 139.74236932303646 36.717 35.66767669962593 139.74236932303646 28.586 35.66777075142294 139.74242035885976 28.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e96b1190-6565-4414-945d-fbe4b783a89a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e96b1190-6565-4414-945d-fbe4b783a89a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e96b1190-6565-4414-945d-fbe4b783a89a">
											<gml:posList>35.66778600404476 139.74237444584267 35.5 35.66778600404476 139.74237444584267 34.693 35.66777045181833 139.74241750935724 34.693 35.66777045181833 139.74241750935724 35.5 35.66778600404476 139.74237444584267 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9447017-6dfc-45dc-923e-c04c7be418a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9447017-6dfc-45dc-923e-c04c7be418a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9447017-6dfc-45dc-923e-c04c7be418a3">
											<gml:posList>35.66777075142294 139.74242035885976 28.586 35.66778793168906 139.74237273154117 28.586 35.66778793168906 139.74237273154117 35.5 35.66777075142294 139.74242035885976 35.5 35.66777075142294 139.74242035885976 28.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc318253-8db5-49fd-ae94-f47006babec1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc318253-8db5-49fd-ae94-f47006babec1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc318253-8db5-49fd-ae94-f47006babec1">
											<gml:posList>35.66777045181833 139.74241750935724 35.5 35.66777045181833 139.74241750935724 34.693 35.66770190132046 139.74238031824606 34.693 35.66770190132046 139.74238031824606 35.5 35.66777045181833 139.74241750935724 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-904</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">53.7966</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>