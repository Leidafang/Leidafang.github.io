<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_bce295c5-f7a4-45e4-92cf-c9632d78c6b3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">11.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67169384185287 139.74046990323828 0 35.671705600114535 139.7404521821723 0 35.671703651651185 139.74045024025585 0 35.671707685119884 139.74044417108615 0 35.671721080813974 139.74045753280976 0 35.67173955551983 139.74042970750162 0 35.67174365090244 139.74043378994145 0 35.67174489623617 139.74043565534808 0 35.671722317576666 139.74047165977942 0 35.67174117914283 139.74048963259494 0 35.67179853003378 139.74040334860035 0 35.67164941821816 139.74025461550283 0 35.67158108344559 139.74035742658822 0 35.67169384185287 139.74046990323828 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67169384185287 139.74046990323828 8.085 35.67158108344559 139.74035742658822 8.085 35.67164941821816 139.74025461550283 8.085 35.67179853003378 139.74040334860035 8.085 35.67174117914283 139.74048963259494 8.085 35.671722317576666 139.74047165977942 8.085 35.67174489623617 139.74043565534808 8.085 35.67174365090244 139.74043378994145 8.085 35.67173955551983 139.74042970750162 8.085 35.671721080813974 139.74045753280976 8.085 35.671707685119884 139.74044417108615 8.085 35.671703651651185 139.74045024025585 8.085 35.671705600114535 139.7404521821723 8.085 35.67169384185287 139.74046990323828 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67169384185287 139.74046990323828 8.085 35.671705600114535 139.7404521821723 8.085 35.671705600114535 139.7404521821723 19.68 35.67169384185287 139.74046990323828 19.68 35.67169384185287 139.74046990323828 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671705600114535 139.7404521821723 8.085 35.671703651651185 139.74045024025585 8.085 35.671703651651185 139.74045024025585 19.68 35.671705600114535 139.7404521821723 19.68 35.671705600114535 139.7404521821723 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671703651651185 139.74045024025585 8.085 35.671707685119884 139.74044417108615 8.085 35.671707685119884 139.74044417108615 19.68 35.671703651651185 139.74045024025585 19.68 35.671703651651185 139.74045024025585 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671707685119884 139.74044417108615 8.085 35.671721080813974 139.74045753280976 8.085 35.671721080813974 139.74045753280976 19.68 35.671707685119884 139.74044417108615 19.68 35.671707685119884 139.74044417108615 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671721080813974 139.74045753280976 8.085 35.67173955551983 139.74042970750162 8.085 35.67173955551983 139.74042970750162 19.68 35.671721080813974 139.74045753280976 19.68 35.671721080813974 139.74045753280976 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67173955551983 139.74042970750162 8.085 35.67174365090244 139.74043378994145 8.085 35.67174365090244 139.74043378994145 19.68 35.67173955551983 139.74042970750162 19.68 35.67173955551983 139.74042970750162 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67174365090244 139.74043378994145 8.085 35.67174489623617 139.74043565534808 8.085 35.67174489623617 139.74043565534808 19.68 35.67174365090244 139.74043378994145 19.68 35.67174365090244 139.74043378994145 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67174489623617 139.74043565534808 8.085 35.671722317576666 139.74047165977942 8.085 35.671722317576666 139.74047165977942 19.68 35.67174489623617 139.74043565534808 19.68 35.67174489623617 139.74043565534808 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671722317576666 139.74047165977942 8.085 35.67174117914283 139.74048963259494 8.085 35.67174117914283 139.74048963259494 19.68 35.671722317576666 139.74047165977942 19.68 35.671722317576666 139.74047165977942 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67174117914283 139.74048963259494 8.085 35.67179853003378 139.74040334860035 8.085 35.67179853003378 139.74040334860035 19.68 35.67174117914283 139.74048963259494 19.68 35.67174117914283 139.74048963259494 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179853003378 139.74040334860035 8.085 35.67164941821816 139.74025461550283 8.085 35.67164941821816 139.74025461550283 19.68 35.67179853003378 139.74040334860035 19.68 35.67179853003378 139.74040334860035 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67164941821816 139.74025461550283 8.085 35.67158108344559 139.74035742658822 8.085 35.67158108344559 139.74035742658822 19.68 35.67164941821816 139.74025461550283 19.68 35.67164941821816 139.74025461550283 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67158108344559 139.74035742658822 8.085 35.67169384185287 139.74046990323828 8.085 35.67169384185287 139.74046990323828 19.68 35.67158108344559 139.74035742658822 19.68 35.67158108344559 139.74035742658822 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67169384185287 139.74046990323828 19.68 35.671705600114535 139.7404521821723 19.68 35.671703651651185 139.74045024025585 19.68 35.671707685119884 139.74044417108615 19.68 35.671721080813974 139.74045753280976 19.68 35.67173955551983 139.74042970750162 19.68 35.67174365090244 139.74043378994145 19.68 35.67174489623617 139.74043565534808 19.68 35.671722317576666 139.74047165977942 19.68 35.67174117914283 139.74048963259494 19.68 35.67179853003378 139.74040334860035 19.68 35.67164941821816 139.74025461550283 19.68 35.67158108344559 139.74035742658822 19.68 35.67169384185287 139.74046990323828 19.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d4075607-46b3-4310-bb38-e6fdecc2677f"/>
							<gml:surfaceMember xlink:href="#poly-13e5edb5-34b8-490f-b3c2-bdb00c89a470"/>
							<gml:surfaceMember xlink:href="#poly-92f2be0b-f70a-4626-957c-98f7cfcc6d4e"/>
							<gml:surfaceMember xlink:href="#poly-27b7b983-4784-49aa-8e03-01d337fbc3ef"/>
							<gml:surfaceMember xlink:href="#poly-8bf1d236-4933-4e10-8771-1a981b77c782"/>
							<gml:surfaceMember xlink:href="#poly-9b315df6-33e8-4178-8b82-be5664cf09c6"/>
							<gml:surfaceMember xlink:href="#poly-fb8ad2fe-3ee3-440d-899b-4cf61ee51011"/>
							<gml:surfaceMember xlink:href="#poly-f49898b9-945a-43a4-b868-584cabfee0f2"/>
							<gml:surfaceMember xlink:href="#poly-0737c163-aa42-4996-b6e1-375846671643"/>
							<gml:surfaceMember xlink:href="#poly-63bbb2ee-10c1-41ee-b744-92d59862393b"/>
							<gml:surfaceMember xlink:href="#poly-c113d73c-1426-40e8-a113-00e077e8ca5f"/>
							<gml:surfaceMember xlink:href="#poly-348c46db-66fa-4a62-bb6a-995de96d3e77"/>
							<gml:surfaceMember xlink:href="#poly-6ee474bb-803c-4d22-ab1d-c6e897547c36"/>
							<gml:surfaceMember xlink:href="#poly-9d776e9a-9476-4009-9afc-c59bad2db611"/>
							<gml:surfaceMember xlink:href="#poly-c53fc26b-aa9c-43ca-95be-ba2d106ab109"/>
							<gml:surfaceMember xlink:href="#poly-80884fd4-b02a-4d55-9809-fa9fa037de03"/>
							<gml:surfaceMember xlink:href="#poly-b42b590a-913e-4d1b-a113-adca4cf2347b"/>
							<gml:surfaceMember xlink:href="#poly-5081c513-8612-4c0d-85b1-81dd98a8ae95"/>
							<gml:surfaceMember xlink:href="#poly-fd3be43b-6e4e-4619-bd0e-3e99d794c6df"/>
							<gml:surfaceMember xlink:href="#poly-f49df82e-b3a9-4931-a30a-883f23f23f54"/>
							<gml:surfaceMember xlink:href="#poly-3d03af62-0a02-4dd4-9e73-5426fb6a359c"/>
							<gml:surfaceMember xlink:href="#poly-305db19c-6091-4f4b-a021-b026bd122736"/>
							<gml:surfaceMember xlink:href="#poly-7c0ada1f-eddf-4a32-a355-5c4b011a58a4"/>
							<gml:surfaceMember xlink:href="#poly-e90b28de-a3bc-48c1-aa96-1e0df12d3862"/>
							<gml:surfaceMember xlink:href="#poly-4b0a233f-4ba6-4fca-a792-470f663583b0"/>
							<gml:surfaceMember xlink:href="#poly-84dc7924-8837-46c7-8858-d2cbd043e2b4"/>
							<gml:surfaceMember xlink:href="#poly-0cf2abaf-e86d-4e77-bf41-ad3c6d5018ac"/>
							<gml:surfaceMember xlink:href="#poly-6df5ff71-cd0d-400b-b8da-55e258df4ce6"/>
							<gml:surfaceMember xlink:href="#poly-13571ffb-e01b-47a3-a639-0e7090c462db"/>
							<gml:surfaceMember xlink:href="#poly-02a6a4b3-d285-4ac6-86ba-83858ee8fad5"/>
							<gml:surfaceMember xlink:href="#poly-2e6ba46d-19fc-42f7-828f-268a94d0e8bc"/>
							<gml:surfaceMember xlink:href="#poly-ca5cb94b-f5b6-4f75-adbf-b8adffc9b9f5"/>
							<gml:surfaceMember xlink:href="#poly-33a2259a-0306-4d56-8ce6-fa7e25c77d28"/>
							<gml:surfaceMember xlink:href="#poly-5c89bd85-cd20-4547-9bd5-17f49a309fca"/>
							<gml:surfaceMember xlink:href="#poly-cacad376-c925-4589-8a54-53855463ff0b"/>
							<gml:surfaceMember xlink:href="#poly-8ec5056a-e849-498a-8a62-66a22f848c97"/>
							<gml:surfaceMember xlink:href="#poly-380a37f2-9954-4c03-a47d-24b0947bd094"/>
							<gml:surfaceMember xlink:href="#poly-43b2d213-530b-4161-8a7a-fb76d0327684"/>
							<gml:surfaceMember xlink:href="#poly-f0131ea6-8f81-4d19-a9ac-4940a09f6ab7"/>
							<gml:surfaceMember xlink:href="#poly-da53a011-9309-4d12-9d91-9cb5d7e24d18"/>
							<gml:surfaceMember xlink:href="#poly-0358ec5d-c695-489d-bf1d-5676f1b70d0d"/>
							<gml:surfaceMember xlink:href="#poly-9511fb4d-e19b-4f16-991c-7c91188169ff"/>
							<gml:surfaceMember xlink:href="#poly-fed6b6bb-bd6f-468a-bcc7-695f4f1765a6"/>
							<gml:surfaceMember xlink:href="#poly-61133f19-4bd5-4bca-a82f-0fb5b929c581"/>
							<gml:surfaceMember xlink:href="#poly-0cd04ba8-fb4b-430e-8ebc-d6e415b61bbd"/>
							<gml:surfaceMember xlink:href="#poly-84a0d491-1314-4454-a977-56b9fe68d20d"/>
							<gml:surfaceMember xlink:href="#poly-bbf28ba2-5b34-4546-a5b7-99bb10cd31b0"/>
							<gml:surfaceMember xlink:href="#poly-aa427596-b400-4465-9a79-45fceb4015b1"/>
							<gml:surfaceMember xlink:href="#poly-ed691e5f-5b81-4efc-9c28-dc73913f6d0b"/>
							<gml:surfaceMember xlink:href="#poly-9cc80b6a-4096-432e-9454-d29b6bd4291a"/>
							<gml:surfaceMember xlink:href="#poly-cbf9eced-807f-43e9-97b2-c8ae0d378d41"/>
							<gml:surfaceMember xlink:href="#poly-b9c332d5-64b5-4678-a74a-c1f4eb8ec594"/>
							<gml:surfaceMember xlink:href="#poly-ff045b67-f9a5-4001-88a8-df0b083259a7"/>
							<gml:surfaceMember xlink:href="#poly-da38c0a8-ad68-4c5e-9d97-ce8e15e8e292"/>
							<gml:surfaceMember xlink:href="#poly-d327ad5e-5342-4ab1-ae5b-f4d3be8e711e"/>
							<gml:surfaceMember xlink:href="#poly-b258366b-bf82-418c-b277-6aa249acdb8d"/>
							<gml:surfaceMember xlink:href="#poly-1470ecdf-cb7d-4ea7-a794-8516714981cb"/>
							<gml:surfaceMember xlink:href="#poly-e8806180-e5c1-43d2-be8d-5cfb70ceb955"/>
							<gml:surfaceMember xlink:href="#poly-4291e7d1-237b-4976-8e93-fd31b039153e"/>
							<gml:surfaceMember xlink:href="#poly-fc69d152-fa20-4857-83d1-8debabf4cd99"/>
							<gml:surfaceMember xlink:href="#poly-5ec9ad07-bdb3-43f9-a299-bbaaf07e4eec"/>
							<gml:surfaceMember xlink:href="#poly-a5ebdd82-142d-4b72-9cec-3f3bf9cebed3"/>
							<gml:surfaceMember xlink:href="#poly-078f9b57-4690-44dc-926e-6c0cdab6c66d"/>
							<gml:surfaceMember xlink:href="#poly-56f43dd9-40ec-407d-9447-d1cc4d01b16a"/>
							<gml:surfaceMember xlink:href="#poly-e1f4b39c-0234-46dd-b824-184f9e3eb0e5"/>
							<gml:surfaceMember xlink:href="#poly-a2106bdf-e0ef-451e-8c09-a19ca51e14fc"/>
							<gml:surfaceMember xlink:href="#poly-d39c7274-9c63-4015-b918-98bd81aabfa9"/>
							<gml:surfaceMember xlink:href="#poly-adb3769c-659c-4473-9165-7241b46d1b36"/>
							<gml:surfaceMember xlink:href="#poly-d7c980af-6657-4a1a-8cd3-d87c14c3cb7c"/>
							<gml:surfaceMember xlink:href="#poly-88bfe3de-95a3-4ef6-ae92-1b34ed0a59c2"/>
							<gml:surfaceMember xlink:href="#poly-c753b531-02eb-48e6-a020-f6e9513dea9a"/>
							<gml:surfaceMember xlink:href="#poly-8bed861c-e29e-499a-a4e7-16cc118097d6"/>
							<gml:surfaceMember xlink:href="#poly-bbc19147-b73b-4c39-8d66-12a937a1a0f2"/>
							<gml:surfaceMember xlink:href="#poly-535e3657-b388-4681-9234-0efd184ac9c4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bce295c5-f7a4-45e4-92cf-c9632d78c6b3_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3d917f8-ec92-4ebc-ba77-f0aff6fad8ec">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671721080813974 139.74045753280978 8.16 35.67173956453356 139.74042970749116 8.16 35.67174365991613 139.740433789931 8.16 35.67174489623616 139.74043565534808 8.16 35.67172231757669 139.74047165977942 8.16 35.67174118814801 139.74048962153805 8.16 35.67173019513599 139.74050615975074 8.16 35.67169384185287 139.74046990323828 8.16 35.671705609128246 139.74045218216185 8.16 35.671703660664896 139.7404502402454 8.16 35.671707685119856 139.74044417108615 8.16 35.671721080813974 139.74045753280978 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45555b8c-55ba-489b-b8f3-784b7038f1b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45555b8c-55ba-489b-b8f3-784b7038f1b0_0">
											<gml:posList>35.67174365991613 139.740433789931 20.003 35.67174365991613 139.740433789931 8.16 35.67173956453356 139.74042970749116 8.16 35.67173956453356 139.74042970749116 20.003 35.67174365991613 139.740433789931 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8247738-c8cf-4f4b-beb9-406dbc3d4247">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8247738-c8cf-4f4b-beb9-406dbc3d4247_0">
											<gml:posList>35.67174489623616 139.74043565534808 20.003 35.67174489623616 139.74043565534808 8.16 35.67174365991613 139.740433789931 8.16 35.67174365991613 139.740433789931 20.003 35.67174489623616 139.74043565534808 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb4c15ed-41e8-4e5a-9534-8a474ceda8dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb4c15ed-41e8-4e5a-9534-8a474ceda8dc_0">
											<gml:posList>35.67173956453356 139.74042970749116 20.003 35.67173956453356 139.74042970749116 8.16 35.671721080813974 139.74045753280978 8.16 35.671721080813974 139.74045753280978 20.003 35.67173956453356 139.74042970749116 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2fd0c0d-0e46-4c46-b116-14b8f8a09ede">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2fd0c0d-0e46-4c46-b116-14b8f8a09ede_0">
											<gml:posList>35.671707685119856 139.74044417108615 20.003 35.671707685119856 139.74044417108615 8.16 35.671703660664896 139.7404502402454 8.16 35.671703660664896 139.7404502402454 20.003 35.671707685119856 139.74044417108615 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c152d109-8a63-4d9f-868b-2e7b63761f31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c152d109-8a63-4d9f-868b-2e7b63761f31_0">
											<gml:posList>35.671721080813974 139.74045753280978 20.003 35.671721080813974 139.74045753280978 8.16 35.671707685119856 139.74044417108615 8.16 35.671707685119856 139.74044417108615 20.003 35.671721080813974 139.74045753280978 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87b3d080-490d-4fd8-9366-5369f247cfc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87b3d080-490d-4fd8-9366-5369f247cfc9_0">
											<gml:posList>35.671703660664896 139.7404502402454 20.003 35.671703660664896 139.7404502402454 8.16 35.671705609128246 139.74045218216185 8.16 35.671705609128246 139.74045218216185 20.003 35.671703660664896 139.7404502402454 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e635cccb-5188-469b-9acc-2dbe03f53502">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e635cccb-5188-469b-9acc-2dbe03f53502_0">
											<gml:posList>35.67172231757669 139.74047165977942 20.003 35.67172231757669 139.74047165977942 8.16 35.67174489623616 139.74043565534808 8.16 35.67174489623616 139.74043565534808 20.003 35.67172231757669 139.74047165977942 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-859cf79e-81fe-4efb-adc5-7ad8d73b80ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-859cf79e-81fe-4efb-adc5-7ad8d73b80ea_0">
											<gml:posList>35.671705609128246 139.74045218216185 20.003 35.671705609128246 139.74045218216185 8.16 35.67169384185287 139.74046990323828 8.16 35.67169384185287 139.74046990323828 20.003 35.671705609128246 139.74045218216185 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23f323fc-23e8-4e5a-93cf-5afab1b3416f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23f323fc-23e8-4e5a-93cf-5afab1b3416f_0">
											<gml:posList>35.671721080813974 139.74045753280978 20.003 35.671707685119856 139.74044417108615 20.003 35.671703660664896 139.7404502402454 20.003 35.671705609128246 139.74045218216185 20.003 35.67169384185287 139.74046990323828 20.003 35.67173019513599 139.74050615975074 20.003 35.67174118814801 139.74048962153805 20.003 35.67172231757669 139.74047165977942 20.003 35.67174489623616 139.74043565534808 20.003 35.67174365991613 139.740433789931 20.003 35.67173956453356 139.74042970749116 20.003 35.671721080813974 139.74045753280978 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2112ee5-db0e-4318-bbda-19cf0a693cc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2112ee5-db0e-4318-bbda-19cf0a693cc8_0">
											<gml:posList>35.67174118814801 139.74048962153805 20.003 35.67174118814801 139.74048962153805 8.16 35.67172231757669 139.74047165977942 8.16 35.67172231757669 139.74047165977942 20.003 35.67174118814801 139.74048962153805 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cc10cef-a14b-4490-b693-8b153b9cff3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cc10cef-a14b-4490-b693-8b153b9cff3f_0">
											<gml:posList>35.67169384185287 139.74046990323828 20.003 35.67169384185287 139.74046990323828 8.16 35.67173019513599 139.74050615975074 8.16 35.67173019513599 139.74050615975074 20.003 35.67169384185287 139.74046990323828 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-458aa188-9f68-4689-9c52-84d1aade0587">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-458aa188-9f68-4689-9c52-84d1aade0587_0">
											<gml:posList>35.67173019513599 139.74050615975074 20.003 35.67173019513599 139.74050615975074 8.16 35.67174118814801 139.74048962153805 8.16 35.67174118814801 139.74048962153805 20.003 35.67173019513599 139.74050615975074 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bce295c5-f7a4-45e4-92cf-c9632d78c6b3_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32ffbb22-c710-4072-9adf-db4b0d8fdf67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176988489288 139.74038062611442 22.651 35.671757766681374 139.74039910982734 22.651 35.67171272638087 139.74035409254887 22.651 35.671714796952045 139.74035074307523 22.651 35.671722355337565 139.7403570639219 22.651 35.671728602835394 139.7403583380644 22.651 35.671756702236706 139.74038636345895 22.651 35.6717641567715 139.74037492174088 22.651 35.67176988489288 139.74038062611442 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-727ecfc1-02d6-42d0-9a61-464d8eba3e3d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6717641567715 139.74037492174088 23.068 35.67176614644147 139.74037185956718 23.068 35.67177188359378 139.74037758602304 23.068 35.67176988489288 139.74038062611442 23.068 35.6717641567715 139.74037492174088 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb2a7bcd-2077-4a7c-8fd3-379cd1107488">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb2a7bcd-2077-4a7c-8fd3-379cd1107488_0">
											<gml:posList>35.67171272638087 139.74035409254887 22.651 35.67171272638087 139.74035409254887 25.792 35.671714796952045 139.74035074307523 25.792 35.671714796952045 139.74035074307523 22.651 35.67171272638087 139.74035409254887 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74768b91-ca5e-44a2-b0c5-af65349f0d03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74768b91-ca5e-44a2-b0c5-af65349f0d03_0">
											<gml:posList>35.671714796952045 139.74035074307523 25.792 35.671722355337565 139.7403570639219 25.792 35.671722355337565 139.7403570639219 22.651 35.671714796952045 139.74035074307523 22.651 35.671714796952045 139.74035074307523 25.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e1d1dc5-92c7-420e-97a1-3f785eefb6b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e1d1dc5-92c7-420e-97a1-3f785eefb6b3_0">
											<gml:posList>35.671728602835394 139.7403583380644 25.792 35.671728602835394 139.7403583380644 22.651 35.671722355337565 139.7403570639219 22.651 35.671722355337565 139.7403570639219 25.792 35.671728602835394 139.7403583380644 25.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29ac98d0-5c57-4e98-923b-b489f193c305">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29ac98d0-5c57-4e98-923b-b489f193c305_0">
											<gml:posList>35.671728602835394 139.7403583380644 22.651 35.671728602835394 139.7403583380644 25.792 35.671756702236706 139.74038636345895 25.792 35.671756702236706 139.74038636345895 22.651 35.671728602835394 139.7403583380644 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45db2e39-2b12-4890-aaaa-f705fd42552e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45db2e39-2b12-4890-aaaa-f705fd42552e_0">
											<gml:posList>35.67176614644147 139.74037185956718 25.792 35.67177188359378 139.74037758602304 25.792 35.67177188359378 139.74037758602304 23.068 35.67176614644147 139.74037185956718 23.068 35.67176614644147 139.74037185956718 25.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4afb47b1-e457-4b58-9088-a27181a76f1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4afb47b1-e457-4b58-9088-a27181a76f1a_0">
											<gml:posList>35.671756702236706 139.74038636345895 25.792 35.671728602835394 139.7403583380644 25.792 35.671722355337565 139.7403570639219 25.792 35.671714796952045 139.74035074307523 25.792 35.67171272638087 139.74035409254887 25.792 35.671757766681374 139.74039910982734 25.792 35.67177188359378 139.74037758602304 25.792 35.67176614644147 139.74037185956718 25.792 35.671756702236706 139.74038636345895 25.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7428bc49-f14f-4a81-818d-8762fc1f0053">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7428bc49-f14f-4a81-818d-8762fc1f0053_0">
											<gml:posList>35.67171272638087 139.74035409254887 25.792 35.67171272638087 139.74035409254887 22.651 35.671757766681374 139.74039910982734 22.651 35.671757766681374 139.74039910982734 25.792 35.67171272638087 139.74035409254887 25.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2246ed67-9637-4aef-9395-d9c1171c2601">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2246ed67-9637-4aef-9395-d9c1171c2601_0">
											<gml:posList>35.67176988489288 139.74038062611442 22.651 35.6717641567715 139.74037492174088 22.651 35.6717641567715 139.74037492174088 23.068 35.67176988489288 139.74038062611442 23.068 35.67176988489288 139.74038062611442 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54ee8559-4250-4127-9fb2-334488494715">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54ee8559-4250-4127-9fb2-334488494715_0">
											<gml:posList>35.671756702236706 139.74038636345895 22.651 35.671756702236706 139.74038636345895 25.792 35.67176614644147 139.74037185956718 25.792 35.67176614644147 139.74037185956718 23.068 35.6717641567715 139.74037492174088 23.068 35.6717641567715 139.74037492174088 22.651 35.671756702236706 139.74038636345895 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9112d750-b887-4e63-90ed-216342f5532f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9112d750-b887-4e63-90ed-216342f5532f_0">
											<gml:posList>35.67176988489288 139.74038062611442 23.068 35.67177188359378 139.74037758602304 23.068 35.67177188359378 139.74037758602304 25.792 35.671757766681374 139.74039910982734 25.792 35.671757766681374 139.74039910982734 22.651 35.67176988489288 139.74038062611442 22.651 35.67176988489288 139.74038062611442 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bce295c5-f7a4-45e4-92cf-c9632d78c6b3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78ed6288-fe9d-4211-8c12-41860c1034c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78ed6288-fe9d-4211-8c12-41860c1034c0_0">
											<gml:posList>35.67172229069131 139.74037840572734 22.651 35.671728160814766 139.74036956176525 24.745 35.67172229069131 139.74037840572734 24.745 35.67172229069131 139.74037840572734 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-132792de-d894-46f6-8bb6-ff87bd9d5c0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-132792de-d894-46f6-8bb6-ff87bd9d5c0e_0">
											<gml:posList>35.67172229069131 139.74037840572734 22.651 35.671728160814766 139.74036956176525 22.651 35.671728160814766 139.74036956176525 24.745 35.67172229069131 139.74037840572734 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f44e5f3-0fb3-4fb0-87f0-cb78011c6a6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f44e5f3-0fb3-4fb0-87f0-cb78011c6a6a_0">
											<gml:posList>35.671728160814766 139.74036956176525 22.651 35.67172451646572 139.7403659317107 24.745 35.671728160814766 139.74036956176525 24.745 35.671728160814766 139.74036956176525 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d0ff004-93ab-4d99-8c04-f7f0fcf782c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d0ff004-93ab-4d99-8c04-f7f0fcf782c1_0">
											<gml:posList>35.671728160814766 139.74036956176525 22.651 35.67172451646572 139.7403659317107 22.651 35.67172451646572 139.7403659317107 24.745 35.671728160814766 139.74036956176525 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fd66222-15a7-4f6a-b06d-fb5b0772cbdc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fd66222-15a7-4f6a-b06d-fb5b0772cbdc_0">
											<gml:posList>35.67172451646572 139.7403659317107 22.651 35.67171864634252 139.74037477567265 24.745 35.67172451646572 139.7403659317107 24.745 35.67172451646572 139.7403659317107 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40c114e1-7fa2-48a3-8b50-2a06f8e294e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40c114e1-7fa2-48a3-8b50-2a06f8e294e7_0">
											<gml:posList>35.67172451646572 139.7403659317107 22.651 35.67171864634252 139.74037477567265 22.651 35.67171864634252 139.74037477567265 24.745 35.67172451646572 139.7403659317107 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-041cca06-0789-42c8-96df-0f86159ca254">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-041cca06-0789-42c8-96df-0f86159ca254_0">
											<gml:posList>35.67172229069131 139.74037840572734 24.745 35.67172451646572 139.7403659317107 24.745 35.67171864634252 139.74037477567265 24.745 35.67172229069131 139.74037840572734 24.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-224ca300-8598-433f-8d62-16be2f6934c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-224ca300-8598-433f-8d62-16be2f6934c2_0">
											<gml:posList>35.67172229069131 139.74037840572734 24.745 35.671728160814766 139.74036956176525 24.745 35.67172451646572 139.7403659317107 24.745 35.67172229069131 139.74037840572734 24.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7feaf328-f09f-4d85-93d0-3c567cb7869c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7feaf328-f09f-4d85-93d0-3c567cb7869c_0">
											<gml:posList>35.67172229069131 139.74037840572734 24.745 35.67171864634252 139.74037477567265 22.651 35.67172229069131 139.74037840572734 22.651 35.67172229069131 139.74037840572734 24.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69ced2d5-4025-4c38-9ba7-b245dc52c5b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69ced2d5-4025-4c38-9ba7-b245dc52c5b4_0">
											<gml:posList>35.67172229069131 139.74037840572734 24.745 35.67171864634252 139.74037477567265 24.745 35.67171864634252 139.74037477567265 22.651 35.67172229069131 139.74037840572734 24.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-948aa87f-45f6-4951-944a-9da37a00ef32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-948aa87f-45f6-4951-944a-9da37a00ef32_0">
											<gml:posList>35.67173876912854 139.7403801430069 22.651 35.67173278841826 139.74037417381373 24.745 35.67173876912854 139.7403801430069 24.745 35.67173876912854 139.7403801430069 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2698ca5f-5617-4de8-8ea4-7240ba69c011">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2698ca5f-5617-4de8-8ea4-7240ba69c011_0">
											<gml:posList>35.67173876912854 139.7403801430069 22.651 35.67173278841826 139.74037417381373 22.651 35.67173278841826 139.74037417381373 24.745 35.67173876912854 139.7403801430069 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8095721a-1575-4c77-b423-6dde5802808d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8095721a-1575-4c77-b423-6dde5802808d_0">
											<gml:posList>35.67172510863426 139.74038573729945 22.651 35.67173278841826 139.74037417381373 24.745 35.67173278841826 139.74037417381373 22.651 35.67172510863426 139.74038573729945 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-577e8c4a-d154-461c-88b0-5680a82db9e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-577e8c4a-d154-461c-88b0-5680a82db9e4_0">
											<gml:posList>35.67172510863426 139.74038573729945 22.651 35.67172510863426 139.74038573729945 24.745 35.67173278841826 139.74037417381373 24.745 35.67172510863426 139.74038573729945 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0ce34c4-249f-42aa-9bd4-0fb96350a5bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0ce34c4-249f-42aa-9bd4-0fb96350a5bb_0">
											<gml:posList>35.67172510863426 139.74038573729945 24.745 35.67173876912854 139.7403801430069 24.745 35.67173278841826 139.74037417381373 24.745 35.67172510863426 139.74038573729945 24.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d21bbda0-e302-4934-8171-2863a8047fee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d21bbda0-e302-4934-8171-2863a8047fee_0">
											<gml:posList>35.67172510863426 139.74038573729945 24.745 35.67173108934399 139.7403917064929 24.745 35.67173876912854 139.7403801430069 24.745 35.67172510863426 139.74038573729945 24.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef798dbc-61b7-4939-b80d-bc2a19b988c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef798dbc-61b7-4939-b80d-bc2a19b988c8_0">
											<gml:posList>35.67173108934399 139.7403917064929 22.651 35.67173876912854 139.7403801430069 24.745 35.67173108934399 139.7403917064929 24.745 35.67173108934399 139.7403917064929 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d54a134-3930-4081-9bdc-a7556aff66bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d54a134-3930-4081-9bdc-a7556aff66bc_0">
											<gml:posList>35.67173108934399 139.7403917064929 22.651 35.67173876912854 139.7403801430069 22.651 35.67173876912854 139.7403801430069 24.745 35.67173108934399 139.7403917064929 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7547c15-a512-46b0-8eeb-7953c2b95f77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7547c15-a512-46b0-8eeb-7953c2b95f77_0">
											<gml:posList>35.67172510863426 139.74038573729945 22.651 35.67173108934399 139.7403917064929 24.745 35.67172510863426 139.74038573729945 24.745 35.67172510863426 139.74038573729945 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d12bb6ba-65f8-45ed-81fe-eecc8f74f473">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d12bb6ba-65f8-45ed-81fe-eecc8f74f473_0">
											<gml:posList>35.67172510863426 139.74038573729945 22.651 35.67173108934399 139.7403917064929 22.651 35.67173108934399 139.7403917064929 24.745 35.67172510863426 139.74038573729945 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f616a93-0815-48c9-9970-cc22df89d230">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f616a93-0815-48c9-9970-cc22df89d230_0">
											<gml:posList>35.671741667802635 139.7403869663504 22.651 35.67173751730344 139.74039322345084 24.745 35.671741667802635 139.7403869663504 24.745 35.671741667802635 139.7403869663504 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a5c3a3c-6498-4e84-995b-2cfc0c12d5c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a5c3a3c-6498-4e84-995b-2cfc0c12d5c2_0">
											<gml:posList>35.671741667802635 139.7403869663504 22.651 35.67173751730344 139.74039322345084 22.651 35.67173751730344 139.74039322345084 24.745 35.671741667802635 139.7403869663504 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2cab7d7-8a3f-4856-88c6-73cb665d8f28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2cab7d7-8a3f-4856-88c6-73cb665d8f28_0">
											<gml:posList>35.671741667802635 139.7403869663504 24.745 35.6717489384719 139.7403942264842 22.651 35.671741667802635 139.7403869663504 22.651 35.671741667802635 139.7403869663504 24.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8ceeb77-4e73-429f-a06d-4eb802927912">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8ceeb77-4e73-429f-a06d-4eb802927912_0">
											<gml:posList>35.671741667802635 139.7403869663504 24.745 35.6717489384719 139.7403942264842 24.745 35.6717489384719 139.7403942264842 22.651 35.671741667802635 139.7403869663504 24.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95ab605e-7f5a-41ea-884f-133b217e4c90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95ab605e-7f5a-41ea-884f-133b217e4c90_0">
											<gml:posList>35.67173751730344 139.74039322345084 24.745 35.6717447879638 139.7404004725384 24.745 35.6717489384719 139.7403942264842 24.745 35.67173751730344 139.74039322345084 24.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56942883-062b-4628-91b0-9988aa2e89ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56942883-062b-4628-91b0-9988aa2e89ab_0">
											<gml:posList>35.671741667802635 139.7403869663504 24.745 35.67173751730344 139.74039322345084 24.745 35.6717489384719 139.7403942264842 24.745 35.671741667802635 139.7403869663504 24.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edc41e41-4b7b-488e-b8b3-cf3c5d0f324a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edc41e41-4b7b-488e-b8b3-cf3c5d0f324a_0">
											<gml:posList>35.67173751730344 139.74039322345084 24.745 35.6717447879638 139.7404004725384 22.651 35.6717447879638 139.7404004725384 24.745 35.67173751730344 139.74039322345084 24.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4ea5e5b-4246-4715-b50c-0ecce5396adb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4ea5e5b-4246-4715-b50c-0ecce5396adb_0">
											<gml:posList>35.67173751730344 139.74039322345084 24.745 35.67173751730344 139.74039322345084 22.651 35.6717447879638 139.7404004725384 22.651 35.67173751730344 139.74039322345084 24.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d3ab010-d53f-4fc2-a73c-10196165ae97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d3ab010-d53f-4fc2-a73c-10196165ae97_0">
											<gml:posList>35.6717447879638 139.7404004725384 22.651 35.6717489384719 139.7403942264842 24.745 35.6717447879638 139.7404004725384 24.745 35.6717447879638 139.7404004725384 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3da0223-e93d-4bd3-a736-52a392953b1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3da0223-e93d-4bd3-a736-52a392953b1f_0">
											<gml:posList>35.6717447879638 139.7404004725384 22.651 35.6717489384719 139.7403942264842 22.651 35.6717489384719 139.7403942264842 24.745 35.6717447879638 139.7404004725384 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-027427e3-d251-4555-9d80-22e3b581cad0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-027427e3-d251-4555-9d80-22e3b581cad0_0">
											<gml:posList>35.671692932886394 139.74043668764511 25.828 35.67169422035705 139.74043475302625 19.784 35.671692932886394 139.74043668764511 19.784 35.671692932886394 139.74043668764511 25.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b13a29ad-676a-4a55-b7ac-d23cf2d584a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b13a29ad-676a-4a55-b7ac-d23cf2d584a3_0">
											<gml:posList>35.671692932886394 139.74043668764511 25.828 35.67169422035705 139.74043475302625 25.828 35.67169422035705 139.74043475302625 19.784 35.671692932886394 139.74043668764511 25.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25b59653-667d-4b4f-abd8-3353b3e62eac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25b59653-667d-4b4f-abd8-3353b3e62eac_0">
											<gml:posList>35.6717085312251 139.74044263465032 23.068 35.67169981727251 139.74043396224366 23.068 35.6717085312251 139.74044263465032 25.828 35.6717085312251 139.74044263465032 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58ede65e-7525-4e38-b16e-ae924353bd0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58ede65e-7525-4e38-b16e-ae924353bd0c_0">
											<gml:posList>35.6717085312251 139.74044263465032 25.828 35.67169981727251 139.74043396224366 23.068 35.67169675926894 139.7404309169694 25.828 35.6717085312251 139.74044263465032 25.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81289772-e0d1-4aa4-9ebd-8e04830dabe4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81289772-e0d1-4aa4-9ebd-8e04830dabe4_0">
											<gml:posList>35.67169675926894 139.7404309169694 25.828 35.67169981727251 139.74043396224366 23.068 35.67169675926894 139.7404309169694 19.784 35.67169675926894 139.7404309169694 25.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22fc6233-94d1-434b-88dd-dfd0ec0ce08e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22fc6233-94d1-434b-88dd-dfd0ec0ce08e_0">
											<gml:posList>35.67170741268007 139.74044154234852 20.003 35.67170851320617 139.74044264571765 23.068 35.67170851320617 139.74044264571765 20.003 35.67170741268007 139.74044154234852 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee235f83-f218-4208-800f-33bdb204e40f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee235f83-f218-4208-800f-33bdb204e40f_0">
											<gml:posList>35.67170741268007 139.74044154234852 19.784 35.67169675926894 139.7404309169694 19.784 35.67170741268007 139.74044154234852 20.003 35.67170741268007 139.74044154234852 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4362f56-5853-46a3-8608-f6e7b6f7ca17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4362f56-5853-46a3-8608-f6e7b6f7ca17_0">
											<gml:posList>35.67170741268007 139.74044154234852 20.003 35.67169981727251 139.74043396224366 23.068 35.67170851320617 139.74044264571765 23.068 35.67170741268007 139.74044154234852 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0c038de-773d-4f8e-bbe0-4c74a56c94a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0c038de-773d-4f8e-bbe0-4c74a56c94a8_0">
											<gml:posList>35.67169675926894 139.7404309169694 19.784 35.67169981727251 139.74043396224366 23.068 35.67170741268007 139.74044154234852 20.003 35.67169675926894 139.7404309169694 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1592aaf-da1a-4182-8f41-fee4868578b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1592aaf-da1a-4182-8f41-fee4868578b2_0">
											<gml:posList>35.671692932886394 139.74043668764511 19.784 35.671691789464795 139.7404384011682 25.828 35.671692932886394 139.74043668764511 25.828 35.671692932886394 139.74043668764511 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff2de64a-86e4-4af1-9dd2-1fcbec638fc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff2de64a-86e4-4af1-9dd2-1fcbec638fc4_0">
											<gml:posList>35.671692932886394 139.74043668764511 19.784 35.671691789464795 139.7404384011682 19.784 35.671691789464795 139.7404384011682 25.828 35.671692932886394 139.74043668764511 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca4ebadf-bade-4f2b-b304-2ecdcad4a709">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca4ebadf-bade-4f2b-b304-2ecdcad4a709_0">
											<gml:posList>35.67170851320617 139.74044264571765 23.068 35.67170758587519 139.74044404969024 20.003 35.67170851320617 139.74044264571765 20.003 35.67170851320617 139.74044264571765 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ceeecd50-622e-4c71-9cf8-4512e8f457f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ceeecd50-622e-4c71-9cf8-4512e8f457f8_0">
											<gml:posList>35.67170851320617 139.74044264571765 23.068 35.67170758587519 139.74044404969024 23.068 35.67170758587519 139.74044404969024 20.003 35.67170851320617 139.74044264571765 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfd7e604-35d8-473c-85e1-c3da3ba3f24e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfd7e604-35d8-473c-85e1-c3da3ba3f24e_0">
											<gml:posList>35.67170243386156 139.7404490265581 19.784 35.67170243386156 139.7404490265581 20.003 35.671691789464795 139.7404384011682 19.784 35.67170243386156 139.7404490265581 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c02cd2fe-e758-4d9b-8d3d-8ee6cc229c80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c02cd2fe-e758-4d9b-8d3d-8ee6cc229c80_0">
											<gml:posList>35.671691789464795 139.7404384011682 19.784 35.67170243386156 139.7404490265581 20.003 35.671691789464795 139.7404384011682 25.828 35.671691789464795 139.7404384011682 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afb8dee5-b9c9-466d-b80b-ecd8e7c15021">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afb8dee5-b9c9-466d-b80b-ecd8e7c15021_0">
											<gml:posList>35.671691789464795 139.7404384011682 25.828 35.67170243386156 139.7404490265581 20.003 35.67170356142023 139.74045011884954 25.828 35.671691789464795 139.7404384011682 25.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c67abcc7-4a79-4926-95a3-dab5a4058e79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c67abcc7-4a79-4926-95a3-dab5a4058e79_0">
											<gml:posList>35.67170243386156 139.7404490265581 20.003 35.67170356142023 139.74045011884954 20.003 35.67170356142023 139.74045011884954 25.828 35.67170243386156 139.7404490265581 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8e8db0b-d845-4581-8ee4-b7e839513453">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8e8db0b-d845-4581-8ee4-b7e839513453_0">
											<gml:posList>35.67170243386156 139.7404490265581 19.784 35.67170741268007 139.74044154234852 20.003 35.67170243386156 139.7404490265581 20.003 35.67170243386156 139.7404490265581 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6be0a656-bcaa-4dc6-bb08-809369c3e39d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6be0a656-bcaa-4dc6-bb08-809369c3e39d_0">
											<gml:posList>35.67170243386156 139.7404490265581 19.784 35.67170741268007 139.74044154234852 19.784 35.67170741268007 139.74044154234852 20.003 35.67170243386156 139.7404490265581 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-173644b4-3014-4ae5-a26c-07fd60f5ed67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-173644b4-3014-4ae5-a26c-07fd60f5ed67_0">
											<gml:posList>35.6717085312251 139.74044263465032 23.068 35.6717085312251 139.74044263465032 25.828 35.67170758587519 139.74044404969024 23.068 35.6717085312251 139.74044263465032 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cd50de1-9e7f-4b43-81f5-52bd3f240ffa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cd50de1-9e7f-4b43-81f5-52bd3f240ffa_0">
											<gml:posList>35.67170758587519 139.74044404969024 20.003 35.67170758587519 139.74044404969024 23.068 35.67170356142023 139.74045011884954 20.003 35.67170758587519 139.74044404969024 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9351a74b-dd13-487c-8b11-b42b2cb40505">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9351a74b-dd13-487c-8b11-b42b2cb40505_0">
											<gml:posList>35.67170356142023 139.74045011884954 20.003 35.67170758587519 139.74044404969024 23.068 35.67170356142023 139.74045011884954 25.828 35.67170356142023 139.74045011884954 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37d01009-f4f7-4b66-a777-bb3de33fb22d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37d01009-f4f7-4b66-a777-bb3de33fb22d_0">
											<gml:posList>35.67170758587519 139.74044404969024 23.068 35.6717085312251 139.74044263465032 25.828 35.67170356142023 139.74045011884954 25.828 35.67170758587519 139.74044404969024 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52ca138c-0041-4cc8-8568-4d4af2ab5193">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52ca138c-0041-4cc8-8568-4d4af2ab5193_0">
											<gml:posList>35.67169422035705 139.74043475302625 19.785 35.67169675926894 139.7404309169694 25.828 35.67169675926894 139.7404309169694 19.784 35.67169422035705 139.74043475302625 19.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5978cade-638f-4dc1-b71d-6076a2afd90c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5978cade-638f-4dc1-b71d-6076a2afd90c_0">
											<gml:posList>35.67169422035705 139.74043475302625 19.785 35.67169422035705 139.74043475302625 25.828 35.67169675926894 139.7404309169694 25.828 35.67169422035705 139.74043475302625 19.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c0ec8be-4266-4727-a270-3a51ef7570a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c0ec8be-4266-4727-a270-3a51ef7570a8_0">
											<gml:posList>35.67169422035705 139.74043475302625 25.828 35.6717085312251 139.74044263465032 25.828 35.67169675926894 139.7404309169694 25.828 35.67169422035705 139.74043475302625 25.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fadb28f-214d-4204-9aa5-dcfb3ed45406">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fadb28f-214d-4204-9aa5-dcfb3ed45406_0">
											<gml:posList>35.6717085312251 139.74044263465032 25.828 35.67169422035705 139.74043475302625 25.828 35.67170356142023 139.74045011884954 25.828 35.6717085312251 139.74044263465032 25.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db359ab4-fa4c-4239-92ef-ab270da78ab5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db359ab4-fa4c-4239-92ef-ab270da78ab5_0">
											<gml:posList>35.671691789464795 139.7404384011682 25.828 35.67170356142023 139.74045011884954 25.828 35.671692932886394 139.74043668764511 25.828 35.671691789464795 139.7404384011682 25.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fecf6df-3acd-4038-a43d-f9991a7ccec2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fecf6df-3acd-4038-a43d-f9991a7ccec2_0">
											<gml:posList>35.67170356142023 139.74045011884954 25.828 35.67169422035705 139.74043475302625 25.828 35.671692932886394 139.74043668764511 25.828 35.67170356142023 139.74045011884954 25.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97f229b9-184a-4cb6-914a-1c7470fb306a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170741268007 139.74044154234852 19.784 35.67169422035705 139.74043475302625 19.784 35.67169675926894 139.7404309169694 19.784 35.67170741268007 139.74044154234852 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f3123dc-2a35-4b27-ad90-b0b03b1866ed">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671692932886394 139.74043668764511 19.784 35.67170243386156 139.7404490265581 19.784 35.671691789464795 139.7404384011682 19.784 35.671692932886394 139.74043668764511 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af6fed69-e8b0-44d6-b719-e771e88a28ee">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170243386156 139.7404490265581 19.784 35.67169422035705 139.74043475302625 19.784 35.67170741268007 139.74044154234852 19.784 35.67170243386156 139.7404490265581 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c52801b-cbf7-4eec-b204-951c741beebe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671692932886394 139.74043668764511 19.784 35.67169422035705 139.74043475302625 19.784 35.67170243386156 139.7404490265581 19.784 35.671692932886394 139.74043668764511 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56d89899-9d2a-4e5d-9f6f-c9c8959b0eaa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170851320617 139.74044264571765 20.003 35.67170758587519 139.74044404969024 20.003 35.67170741268007 139.74044154234852 20.003 35.67170851320617 139.74044264571765 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-665f197e-e278-444e-9d50-ac89b90f962e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170758587519 139.74044404969024 20.003 35.67170356142023 139.74045011884954 20.003 35.67170243386156 139.7404490265581 20.003 35.67170758587519 139.74044404969024 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66953ffb-85c5-4768-9669-3c35b4fd3607">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170758587519 139.74044404969024 20.003 35.67170243386156 139.7404490265581 20.003 35.67170741268007 139.74044154234852 20.003 35.67170758587519 139.74044404969024 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-569c4c76-f858-47cc-b945-5cb771f5775e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172229069131 139.74037840572734 22.651 35.67172451646572 139.7403659317107 22.651 35.671728160814766 139.74036956176525 22.651 35.67172229069131 139.74037840572734 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da11629b-4b0b-4251-8d0f-e82c6adfee95">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172229069131 139.74037840572734 22.651 35.67171864634252 139.74037477567265 22.651 35.67172451646572 139.7403659317107 22.651 35.67172229069131 139.74037840572734 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fb4577f-c579-4e70-9eff-08f87b301ed5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172510863426 139.74038573729945 22.651 35.67173876912854 139.7403801430069 22.651 35.67173108934399 139.7403917064929 22.651 35.67172510863426 139.74038573729945 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6117184-8bb7-49e3-b0d5-9dddfe11acad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172510863426 139.74038573729945 22.651 35.67173278841826 139.74037417381373 22.651 35.67173876912854 139.7403801430069 22.651 35.67172510863426 139.74038573729945 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f238fb5-901f-4ba2-b17a-50a2eed61dde">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6717489384719 139.7403942264842 22.651 35.6717447879638 139.7404004725384 22.651 35.67173751730344 139.74039322345084 22.651 35.6717489384719 139.7403942264842 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6164cef-5627-44e9-93c8-34c6e8d96bc0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671741667802635 139.7403869663504 22.651 35.6717489384719 139.7403942264842 22.651 35.67173751730344 139.74039322345084 22.651 35.671741667802635 139.7403869663504 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bce295c5-f7a4-45e4-92cf-c9632d78c6b3_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f76764b-6aeb-4c4b-8c81-514f712abc34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f76764b-6aeb-4c4b-8c81-514f712abc34_0">
											<gml:posList>35.67167426855713 139.74041734486596 22.651 35.6716749438105 139.74041633885756 23.068 35.67167426855713 139.74041734486596 23.068 35.67167426855713 139.74041734486596 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4326b15-32ee-47ff-877e-058da5f1ef26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4326b15-32ee-47ff-877e-058da5f1ef26_0">
											<gml:posList>35.67167426855713 139.74041734486596 22.651 35.6716749438105 139.74041633885756 22.651 35.6716749438105 139.74041633885756 23.068 35.67167426855713 139.74041734486596 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a6f10f5-929b-4180-b23d-1f63171a640f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a6f10f5-929b-4180-b23d-1f63171a640f_0">
											<gml:posList>35.67171557038842 139.7403368126131 22.651 35.67174729611641 139.7403684680718 24.101 35.67174729611641 139.7403684680718 22.651 35.67171557038842 139.7403368126131 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cd9ad0a-cc1b-4c9e-90cb-44c6573dfbf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cd9ad0a-cc1b-4c9e-90cb-44c6573dfbf5_0">
											<gml:posList>35.67171557038842 139.7403368126131 22.651 35.67171557038842 139.7403368126131 24.101 35.67174729611641 139.7403684680718 24.101 35.67171557038842 139.7403368126131 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a168062-030e-4d10-9c38-b10a31d2216d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a168062-030e-4d10-9c38-b10a31d2216d_0">
											<gml:posList>35.67174590960679 139.7403705464117 22.651 35.67171550089775 139.7403402039518 24.101 35.67171550089775 139.7403402039518 22.651 35.67174590960679 139.7403705464117 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06e38855-bde3-4576-80a7-eb0bb369cd19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06e38855-bde3-4576-80a7-eb0bb369cd19_0">
											<gml:posList>35.67174590960679 139.7403705464117 22.651 35.67174590960679 139.7403705464117 24.101 35.67171550089775 139.7403402039518 24.101 35.67174590960679 139.7403705464117 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d570c721-67e5-4fac-ba77-634e02d516d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d570c721-67e5-4fac-ba77-634e02d516d8_0">
											<gml:posList>35.67174729611641 139.7403684680718 22.651 35.67174590960679 139.7403705464117 24.101 35.67174590960679 139.7403705464117 22.651 35.67174729611641 139.7403684680718 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4710f156-8934-4fc0-bcf8-7982dd19b27a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4710f156-8934-4fc0-bcf8-7982dd19b27a_0">
											<gml:posList>35.67174729611641 139.7403684680718 22.651 35.67174729611641 139.7403684680718 24.101 35.67174590960679 139.7403705464117 24.101 35.67174729611641 139.7403684680718 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-251f0e87-c182-4560-8d04-b19ff80618c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-251f0e87-c182-4560-8d04-b19ff80618c3_0">
											<gml:posList>35.67166654762085 139.74041062653407 23.068 35.67166654762085 139.74041062653407 24.101 35.67166694376423 139.74041002956739 23.068 35.67166654762085 139.74041062653407 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4df81325-7c93-45bd-915f-8d855a664292">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4df81325-7c93-45bd-915f-8d855a664292_0">
											<gml:posList>35.67166694376423 139.74041002956739 22.651 35.67166694376423 139.74041002956739 23.068 35.67171557038842 139.7403368126131 22.651 35.67166694376423 139.74041002956739 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6cdb774-9ab0-4c16-b236-f8ec25a286ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6cdb774-9ab0-4c16-b236-f8ec25a286ca_0">
											<gml:posList>35.67171557038842 139.7403368126131 22.651 35.67166694376423 139.74041002956739 23.068 35.67171557038842 139.7403368126131 24.101 35.67171557038842 139.7403368126131 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d38b15d-08d7-4504-80e3-3fe84672ec25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d38b15d-08d7-4504-80e3-3fe84672ec25_0">
											<gml:posList>35.67166694376423 139.74041002956739 23.068 35.67166654762085 139.74041062653407 24.101 35.67171557038842 139.7403368126131 24.101 35.67166694376423 139.74041002956739 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6513e6f3-47d5-4533-a3af-efade2c81e66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6513e6f3-47d5-4533-a3af-efade2c81e66_0">
											<gml:posList>35.67171550089775 139.7403402039518 22.651 35.671668927021486 139.74041033656897 24.101 35.671668927021486 139.74041033656897 22.651 35.67171550089775 139.7403402039518 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65d03278-7b1f-48a4-beaf-9d42d0b164b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65d03278-7b1f-48a4-beaf-9d42d0b164b4_0">
											<gml:posList>35.67171550089775 139.7403402039518 22.651 35.67171550089775 139.7403402039518 24.101 35.671668927021486 139.74041033656897 24.101 35.67171550089775 139.7403402039518 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05cc75e1-8896-495b-aaf4-f9afaadf5f7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05cc75e1-8896-495b-aaf4-f9afaadf5f7b_0">
											<gml:posList>35.67174729611641 139.7403684680718 24.101 35.67171550089775 139.7403402039518 24.101 35.67174590960679 139.7403705464117 24.101 35.67174729611641 139.7403684680718 24.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c850f030-7f04-4921-9ec9-51fd8681c13a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c850f030-7f04-4921-9ec9-51fd8681c13a_0">
											<gml:posList>35.671677794345435 139.740419185535 24.101 35.671668927021486 139.74041033656897 24.101 35.671676731962336 139.74042078849973 24.101 35.671677794345435 139.740419185535 24.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc20c1a8-82ef-47d7-b43e-5498f08f2d60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc20c1a8-82ef-47d7-b43e-5498f08f2d60_0">
											<gml:posList>35.671668927021486 139.74041033656897 24.101 35.67166654762085 139.74041062653407 24.101 35.671676731962336 139.74042078849973 24.101 35.671668927021486 139.74041033656897 24.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fe3a61d-51cc-4253-a6be-8401bb06ff00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fe3a61d-51cc-4253-a6be-8401bb06ff00_0">
											<gml:posList>35.67171557038842 139.7403368126131 24.101 35.67171550089775 139.7403402039518 24.101 35.67174729611641 139.7403684680718 24.101 35.67171557038842 139.7403368126131 24.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08e21343-be7c-4a64-a057-e8c03ce852c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08e21343-be7c-4a64-a057-e8c03ce852c3_0">
											<gml:posList>35.67166654762085 139.74041062653407 24.101 35.67171550089775 139.7403402039518 24.101 35.67171557038842 139.7403368126131 24.101 35.67166654762085 139.74041062653407 24.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0e30fcb-681c-4a17-be4f-40f10a8a7010">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0e30fcb-681c-4a17-be4f-40f10a8a7010_0">
											<gml:posList>35.67166654762085 139.74041062653407 24.101 35.671668927021486 139.74041033656897 24.101 35.67171550089775 139.7403402039518 24.101 35.67166654762085 139.74041062653407 24.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29a77efb-e6b9-4684-976a-4e8f8cc47a6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29a77efb-e6b9-4684-976a-4e8f8cc47a6f_0">
											<gml:posList>35.67167426855713 139.74041734486596 23.068 35.67166694376423 139.74041002956739 22.651 35.67167426855713 139.74041734486596 22.651 35.67167426855713 139.74041734486596 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48780e15-72c0-4cc3-9ecb-a0ae33c4c0ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48780e15-72c0-4cc3-9ecb-a0ae33c4c0ed_0">
											<gml:posList>35.67167426855713 139.74041734486596 23.068 35.67166694376423 139.74041002956739 23.068 35.67166694376423 139.74041002956739 22.651 35.67167426855713 139.74041734486596 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63e9f337-e2b0-4430-a1be-b81ac6e321ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63e9f337-e2b0-4430-a1be-b81ac6e321ec_0">
											<gml:posList>35.67167672294862 139.7404207885102 19.784 35.671677794345435 139.740419185535 23.068 35.671677794345435 139.740419185535 19.784 35.67167672294862 139.7404207885102 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f21b573f-c36f-46af-a6bb-96e82c65ebcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f21b573f-c36f-46af-a6bb-96e82c65ebcb_0">
											<gml:posList>35.67167672294862 139.7404207885102 19.784 35.67167672294862 139.7404207885102 23.068 35.671677794345435 139.740419185535 23.068 35.67167672294862 139.7404207885102 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa5872b3-576c-4392-8ae1-04f7a0a8d16e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa5872b3-576c-4392-8ae1-04f7a0a8d16e_0">
											<gml:posList>35.671677794345435 139.740419185535 19.784 35.671676731962336 139.74042078849973 24.101 35.671676731962336 139.74042078849973 19.784 35.671677794345435 139.740419185535 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5626610d-a594-408c-be4d-698e8aab95e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5626610d-a594-408c-be4d-698e8aab95e6_0">
											<gml:posList>35.671677794345435 139.740419185535 19.784 35.671677794345435 139.740419185535 24.101 35.671676731962336 139.74042078849973 24.101 35.671677794345435 139.740419185535 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92c8a405-3363-4f0a-8e49-7a9f207e586a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92c8a405-3363-4f0a-8e49-7a9f207e586a_0">
											<gml:posList>35.671677794345435 139.740419185535 23.068 35.6716749438105 139.74041633885756 23.068 35.671677794345435 139.740419185535 24.101 35.671677794345435 139.740419185535 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5d10a15-06ec-4200-8c1b-308ae5462eb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5d10a15-06ec-4200-8c1b-308ae5462eb5_0">
											<gml:posList>35.671677794345435 139.740419185535 24.101 35.6716749438105 139.74041633885756 23.068 35.671668927021486 139.74041033656897 24.101 35.671677794345435 139.740419185535 24.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73ad3160-cbf9-437f-ad22-f97d51e1926c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73ad3160-cbf9-437f-ad22-f97d51e1926c_0">
											<gml:posList>35.6716749438105 139.74041633885756 22.651 35.671668927021486 139.74041033656897 22.651 35.6716749438105 139.74041633885756 23.068 35.6716749438105 139.74041633885756 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c22e1fec-86a9-4ccf-97df-a4e712839a6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c22e1fec-86a9-4ccf-97df-a4e712839a6a_0">
											<gml:posList>35.6716749438105 139.74041633885756 23.068 35.671668927021486 139.74041033656897 22.651 35.671668927021486 139.74041033656897 24.101 35.6716749438105 139.74041633885756 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ea623e3-8ebe-4053-bf8d-4adb3802c9ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ea623e3-8ebe-4053-bf8d-4adb3802c9ad_0">
											<gml:posList>35.67166654762085 139.74041062653407 23.068 35.67167672294862 139.7404207885102 23.068 35.67166654762085 139.74041062653407 24.101 35.67166654762085 139.74041062653407 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bef64fc4-4bad-4c4e-9ff4-1c3f1ba1a80d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bef64fc4-4bad-4c4e-9ff4-1c3f1ba1a80d_0">
											<gml:posList>35.67166654762085 139.74041062653407 24.101 35.67167672294862 139.7404207885102 23.068 35.671676731962336 139.74042078849973 24.101 35.67166654762085 139.74041062653407 24.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b6ead68-d603-4260-9b0c-883fd0107ef7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b6ead68-d603-4260-9b0c-883fd0107ef7_0">
											<gml:posList>35.67167672294862 139.7404207885102 23.068 35.671676731962336 139.74042078849973 19.784 35.671676731962336 139.74042078849973 24.101 35.67167672294862 139.7404207885102 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-967d70bf-e2d5-4509-a3b1-d261c6a8082d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6716749438105 139.74041633885756 23.068 35.671677794345435 139.740419185535 23.068 35.67167426855713 139.74041734486596 23.068 35.6716749438105 139.74041633885756 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7fcd6e9-1abb-42df-8df4-7957bba92c2e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671677794345435 139.740419185535 23.068 35.67167672294862 139.7404207885102 23.068 35.67167426855713 139.74041734486596 23.068 35.671677794345435 139.740419185535 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88a45729-ace4-4365-9921-abe4c25c9198">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67167426855713 139.74041734486596 23.068 35.67166654762085 139.74041062653407 23.068 35.67166694376423 139.74041002956739 23.068 35.67167426855713 139.74041734486596 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b26cef43-aa23-4081-a3e9-17c9017ccfe6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67167426855713 139.74041734486596 23.068 35.67167672294862 139.7404207885102 23.068 35.67166654762085 139.74041062653407 23.068 35.67167426855713 139.74041734486596 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cd7e239-48df-41b7-af63-be4acfdf83d6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67174729611641 139.7403684680718 22.651 35.67174590960679 139.7403705464117 22.651 35.67171550089775 139.7403402039518 22.651 35.67174729611641 139.7403684680718 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c5c6c76-8981-4abf-8ebd-9897f7980a9f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67174729611641 139.7403684680718 22.651 35.67171550089775 139.7403402039518 22.651 35.67171557038842 139.7403368126131 22.651 35.67174729611641 139.7403684680718 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a25af60-39c3-49ac-a72e-e96563e87ab2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67171550089775 139.7403402039518 22.651 35.67166694376423 139.74041002956739 22.651 35.67171557038842 139.7403368126131 22.651 35.67171550089775 139.7403402039518 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2717e102-1f7f-492a-af5c-9ec99bd04fb8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6716749438105 139.74041633885756 22.651 35.67167426855713 139.74041734486596 22.651 35.671668927021486 139.74041033656897 22.651 35.6716749438105 139.74041633885756 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19644641-1143-4ad3-a2f0-8e2b29cca5c0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671668927021486 139.74041033656897 22.651 35.67167426855713 139.74041734486596 22.651 35.67166694376423 139.74041002956739 22.651 35.671668927021486 139.74041033656897 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52e30aba-f08d-407a-9bc2-9c743d518621">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67171550089775 139.7403402039518 22.651 35.671668927021486 139.74041033656897 22.651 35.67166694376423 139.74041002956739 22.651 35.67171550089775 139.7403402039518 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bce295c5-f7a4-45e4-92cf-c9632d78c6b3_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2db871df-1063-4f9d-8910-a948cbff0ed0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170118574342 139.7404201857455 22.651 35.67171741862475 139.7403957321998 22.651 35.671733340109625 139.74041160957913 22.651 35.67171709820287 139.7404360520905 22.651 35.67170118574342 139.7404201857455 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa6e31ee-1980-4b15-a81d-7db2f0056131">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa6e31ee-1980-4b15-a81d-7db2f0056131_0">
											<gml:posList>35.67171741862475 139.7403957321998 22.651 35.67171741862475 139.7403957321998 25.132 35.671733340109625 139.74041160957913 25.132 35.671733340109625 139.74041160957913 22.651 35.67171741862475 139.7403957321998 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b097e5e-11f0-4f36-b22d-7517e9dabeec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b097e5e-11f0-4f36-b22d-7517e9dabeec_0">
											<gml:posList>35.67170118574342 139.7404201857455 22.651 35.67170118574342 139.7404201857455 25.132 35.67171741862475 139.7403957321998 25.132 35.67171741862475 139.7403957321998 22.651 35.67170118574342 139.7404201857455 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bd42b5a-64ec-47b8-b933-92b581ef8da0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bd42b5a-64ec-47b8-b933-92b581ef8da0_0">
											<gml:posList>35.671733340109625 139.74041160957913 25.132 35.67171741862475 139.7403957321998 25.132 35.67170118574342 139.7404201857455 25.132 35.67171709820287 139.7404360520905 25.132 35.671733340109625 139.74041160957913 25.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-caa7a0cd-15b8-4968-9530-a3bfbb40d582">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-caa7a0cd-15b8-4968-9530-a3bfbb40d582_0">
											<gml:posList>35.671733340109625 139.74041160957913 22.651 35.671733340109625 139.74041160957913 25.132 35.67171709820287 139.7404360520905 25.132 35.67171709820287 139.7404360520905 22.651 35.671733340109625 139.74041160957913 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e21a819-3aba-4c01-a8fe-5959ea213ada">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e21a819-3aba-4c01-a8fe-5959ea213ada_0">
											<gml:posList>35.67171709820287 139.7404360520905 22.651 35.67171709820287 139.7404360520905 25.132 35.67170118574342 139.7404201857455 25.132 35.67170118574342 139.7404201857455 22.651 35.67171709820287 139.7404360520905 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d4075607-46b3-4310-bb38-e6fdecc2677f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4075607-46b3-4310-bb38-e6fdecc2677f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4075607-46b3-4310-bb38-e6fdecc2677f">
											<gml:posList>35.671798530033755 139.74040334860035 8.085 35.67174117914281 139.74048963259494 8.085 35.67172231757669 139.74047165977942 8.085 35.67174489623616 139.74043565534808 8.085 35.671743650902414 139.74043378994145 8.085 35.671739555519835 139.74042970750162 8.085 35.671721080813974 139.74045753280978 8.085 35.671707685119856 139.74044417108615 8.085 35.67170365165118 139.74045024025585 8.085 35.671705600114535 139.7404521821723 8.085 35.67169384185287 139.74046990323828 8.085 35.67158108344559 139.7403574265882 8.085 35.67164941821816 139.74025461550283 8.085 35.671798530033755 139.74040334860035 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-13e5edb5-34b8-490f-b3c2-bdb00c89a470">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13e5edb5-34b8-490f-b3c2-bdb00c89a470">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13e5edb5-34b8-490f-b3c2-bdb00c89a470">
											<gml:posList>35.671649918558074 139.7402605468572 20.003 35.671713171590795 139.74032365908184 20.003 35.67171535037696 139.74032037576052 20.003 35.67164941821816 139.74025461550283 20.003 35.671649918558074 139.7402605468572 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92f2be0b-f70a-4626-957c-98f7cfcc6d4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92f2be0b-f70a-4626-957c-98f7cfcc6d4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92f2be0b-f70a-4626-957c-98f7cfcc6d4e">
											<gml:posList>35.67158108344559 139.7403574265882 20.003 35.671585932366824 139.74035682445805 20.003 35.671649918558074 139.7402605468572 20.003 35.67164941821816 139.74025461550283 20.003 35.67158108344559 139.7403574265882 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27b7b983-4784-49aa-8e03-01d337fbc3ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27b7b983-4784-49aa-8e03-01d337fbc3ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27b7b983-4784-49aa-8e03-01d337fbc3ef">
											<gml:posList>35.67171535037696 139.74032037576052 23.068 35.67171586908237 139.74032674895662 23.068 35.67177248284833 139.7403832190184 23.068 35.671777683262 139.74038256124857 23.068 35.67171535037696 139.74032037576052 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8bf1d236-4933-4e10-8771-1a981b77c782">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bf1d236-4933-4e10-8771-1a981b77c782">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bf1d236-4933-4e10-8771-1a981b77c782">
											<gml:posList>35.67170243386156 139.7404490265581 19.784 35.67170741268007 139.74044154234852 19.784 35.67169675926894 139.7404309169694 19.784 35.6716958139277 139.74043234305566 19.784 35.67167972104839 139.74041628913525 19.784 35.67167479624557 139.7404236849097 19.784 35.67165791856607 139.74040684760794 19.784 35.671713171590795 139.74032365908184 19.784 35.671649918558074 139.7402605468572 19.784 35.671585932366824 139.74035682445805 19.784 35.67166463774317 139.74043532857945 19.784 35.671667307866905 139.74043799872328 19.784 35.67167933624573 139.7404199017666 19.784 35.67169422035705 139.74043475302625 19.784 35.671691789464795 139.7404384011682 19.784 35.67170243386156 139.7404490265581 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b315df6-33e8-4178-8b82-be5664cf09c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b315df6-33e8-4178-8b82-be5664cf09c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b315df6-33e8-4178-8b82-be5664cf09c6">
											<gml:posList>35.67165791856607 139.74040684760794 23.068 35.67166310096106 139.74040620090793 23.068 35.67171586908237 139.74032674895662 23.068 35.67171535037696 139.74032037576052 23.068 35.67165791856607 139.74040684760794 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb8ad2fe-3ee3-440d-899b-4cf61ee51011">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb8ad2fe-3ee3-440d-899b-4cf61ee51011">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb8ad2fe-3ee3-440d-899b-4cf61ee51011">
											<gml:posList>35.67167919335957 139.74040994909114 22.651 35.67169527720896 139.74042598092777 22.651 35.671696222550125 139.74042455484144 22.651 35.67171380384265 139.7404420983121 22.651 35.671712867506486 139.7404435133417 22.651 35.67172054409656 139.74045117067973 22.651 35.67173900979576 139.74042335642716 22.651 35.67174310517856 139.74042743886665 22.651 35.67177248284833 139.7403832190184 22.651 35.67171586908237 139.74032674895662 22.651 35.67166310096106 139.74040620090793 22.651 35.67167426855713 139.74041734486596 22.651 35.67167919335957 139.74040994909114 22.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f49898b9-945a-43a4-b868-584cabfee0f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f49898b9-945a-43a4-b868-584cabfee0f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f49898b9-945a-43a4-b868-584cabfee0f2">
											<gml:posList>35.67166463774317 139.74043532857945 20.003 35.671585932366824 139.74035682445805 20.003 35.67158108344559 139.7403574265882 20.003 35.67166513808271 139.74044127098256 20.003 35.671667307866905 139.74043799872328 20.003 35.67166463774317 139.74043532857945 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0737c163-aa42-4996-b6e1-375846671643">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0737c163-aa42-4996-b6e1-375846671643">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0737c163-aa42-4996-b6e1-375846671643">
											<gml:posList>35.671777683262 139.74038256124857 23.068 35.67177248284833 139.7403832190184 23.068 35.67174310517856 139.74042743886665 23.068 35.671743650902414 139.74043378994145 23.068 35.671777683262 139.74038256124857 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63bbb2ee-10c1-41ee-b744-92d59862393b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63bbb2ee-10c1-41ee-b744-92d59862393b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63bbb2ee-10c1-41ee-b744-92d59862393b">
											<gml:posList>35.67167479624557 139.7404236849097 23.068 35.67167426855713 139.74041734486596 23.068 35.67166310096106 139.74040620090793 23.068 35.67165791856607 139.74040684760794 23.068 35.67167479624557 139.7404236849097 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c113d73c-1426-40e8-a113-00e077e8ca5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c113d73c-1426-40e8-a113-00e077e8ca5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c113d73c-1426-40e8-a113-00e077e8ca5f">
											<gml:posList>35.67167972104839 139.74041628913525 23.068 35.67167919335957 139.74040994909114 23.068 35.67167426855713 139.74041734486596 23.068 35.67167479624557 139.7404236849097 23.068 35.67167972104839 139.74041628913525 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-348c46db-66fa-4a62-bb6a-995de96d3e77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-348c46db-66fa-4a62-bb6a-995de96d3e77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-348c46db-66fa-4a62-bb6a-995de96d3e77">
											<gml:posList>35.67167972104839 139.74041628913525 23.068 35.6716958139277 139.74043234305566 23.068 35.67169527720896 139.74042598092777 23.068 35.67167919335957 139.74040994909114 23.068 35.67167972104839 139.74041628913525 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ee474bb-803c-4d22-ab1d-c6e897547c36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ee474bb-803c-4d22-ab1d-c6e897547c36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ee474bb-803c-4d22-ab1d-c6e897547c36">
											<gml:posList>35.67167933624573 139.7404199017666 26.87 35.67167972741563 139.7404245408174 26.87 35.67169043496081 139.74043523240937 26.87 35.67169422035705 139.74043475302625 26.87 35.67167933624573 139.7404199017666 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d776e9a-9476-4009-9afc-c59bad2db611">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d776e9a-9476-4009-9afc-c59bad2db611">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d776e9a-9476-4009-9afc-c59bad2db611">
											<gml:posList>35.67169675926894 139.7404309169694 23.068 35.671696222550125 139.74042455484144 23.068 35.67169527720896 139.74042598092777 23.068 35.6716958139277 139.74043234305566 23.068 35.67169675926894 139.7404309169694 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c53fc26b-aa9c-43ca-95be-ba2d106ab109">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c53fc26b-aa9c-43ca-95be-ba2d106ab109">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c53fc26b-aa9c-43ca-95be-ba2d106ab109">
											<gml:posList>35.671739555519835 139.74042970750162 23.068 35.671743650902414 139.74043378994145 23.068 35.67174310517856 139.74042743886665 23.068 35.67173900979576 139.74042335642716 23.068 35.671739555519835 139.74042970750162 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-80884fd4-b02a-4d55-9809-fa9fa037de03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80884fd4-b02a-4d55-9809-fa9fa037de03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80884fd4-b02a-4d55-9809-fa9fa037de03">
											<gml:posList>35.67166513808271 139.74044127098256 26.87 35.67166893249271 139.7404407915894 26.87 35.67167972741563 139.7404245408174 26.87 35.67167933624573 139.7404199017666 26.87 35.67166513808271 139.74044127098256 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b42b590a-913e-4d1b-a113-adca4cf2347b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b42b590a-913e-4d1b-a113-adca4cf2347b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b42b590a-913e-4d1b-a113-adca4cf2347b">
											<gml:posList>35.67170862145604 139.74044275605667 23.068 35.67171380384265 139.7404420983121 23.068 35.671696222550125 139.74042455484144 23.068 35.67169675926894 139.7404309169694 23.068 35.67170862145604 139.74044275605667 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5081c513-8612-4c0d-85b1-81dd98a8ae95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5081c513-8612-4c0d-85b1-81dd98a8ae95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5081c513-8612-4c0d-85b1-81dd98a8ae95">
											<gml:posList>35.671798530033755 139.74040334860035 20.003 35.671777683262 139.74038256124857 20.003 35.671743650902414 139.74043378994145 20.003 35.67174489623616 139.74043565534808 20.003 35.67172231757669 139.74047165977942 20.003 35.67174117914281 139.74048963259494 20.003 35.671798530033755 139.74040334860035 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fd3be43b-6e4e-4619-bd0e-3e99d794c6df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd3be43b-6e4e-4619-bd0e-3e99d794c6df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd3be43b-6e4e-4619-bd0e-3e99d794c6df">
											<gml:posList>35.671691789464795 139.7404384011682 26.87 35.67169422035705 139.74043475302625 26.87 35.67169043496081 139.74043523240937 26.87 35.67168800407707 139.74043889159756 26.87 35.671691789464795 139.7404384011682 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f49df82e-b3a9-4931-a30a-883f23f23f54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f49df82e-b3a9-4931-a30a-883f23f23f54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f49df82e-b3a9-4931-a30a-883f23f23f54">
											<gml:posList>35.671739555519835 139.74042970750162 23.068 35.67173900979576 139.74042335642716 23.068 35.67172054409656 139.74045117067973 23.068 35.671721080813974 139.74045753280978 23.068 35.671739555519835 139.74042970750162 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d03af62-0a02-4dd4-9e73-5426fb6a359c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d03af62-0a02-4dd4-9e73-5426fb6a359c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d03af62-0a02-4dd4-9e73-5426fb6a359c">
											<gml:posList>35.67170862145604 139.74044275605667 23.068 35.671707685119856 139.74044417108615 23.068 35.671712867506486 139.7404435133417 23.068 35.67171380384265 139.7404420983121 23.068 35.67170862145604 139.74044275605667 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-305db19c-6091-4f4b-a021-b026bd122736">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-305db19c-6091-4f4b-a021-b026bd122736">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-305db19c-6091-4f4b-a021-b026bd122736">
											<gml:posList>35.67169345969844 139.74046526417595 26.742 35.67170182372342 139.7404526504978 26.742 35.67168800407707 139.74043889159756 26.742 35.67169043496081 139.74043523240937 26.742 35.67167972741563 139.7404245408174 26.742 35.67166893249271 139.7404407915894 26.742 35.67169345969844 139.74046526417595 26.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c0ada1f-eddf-4a32-a355-5c4b011a58a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c0ada1f-eddf-4a32-a355-5c4b011a58a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c0ada1f-eddf-4a32-a355-5c4b011a58a4">
											<gml:posList>35.671691789464795 139.7404384011682 26.87 35.67168800407707 139.74043889159756 26.87 35.67170182372342 139.7404526504978 26.87 35.671705600114535 139.7404521821723 26.87 35.671691789464795 139.7404384011682 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e90b28de-a3bc-48c1-aa96-1e0df12d3862">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e90b28de-a3bc-48c1-aa96-1e0df12d3862">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e90b28de-a3bc-48c1-aa96-1e0df12d3862">
											<gml:posList>35.67170741268007 139.74044154234852 20.003 35.67170243386156 139.7404490265581 20.003 35.67170365165118 139.74045024025585 20.003 35.671707685119856 139.74044417108615 20.003 35.67170862145604 139.74044275605667 20.003 35.67170741268007 139.74044154234852 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b0a233f-4ba6-4fca-a792-470f663583b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b0a233f-4ba6-4fca-a792-470f663583b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b0a233f-4ba6-4fca-a792-470f663583b0">
											<gml:posList>35.671721080813974 139.74045753280978 23.068 35.67172054409656 139.74045117067973 23.068 35.671712867506486 139.7404435133417 23.068 35.671707685119856 139.74044417108615 23.068 35.671721080813974 139.74045753280978 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84dc7924-8837-46c7-8858-d2cbd043e2b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84dc7924-8837-46c7-8858-d2cbd043e2b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84dc7924-8837-46c7-8858-d2cbd043e2b4">
											<gml:posList>35.67169384185287 139.74046990323828 26.87 35.67169345969844 139.74046526417595 26.87 35.67166893249271 139.7404407915894 26.87 35.67166513808271 139.74044127098256 26.87 35.67169384185287 139.74046990323828 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0cf2abaf-e86d-4e77-bf41-ad3c6d5018ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cf2abaf-e86d-4e77-bf41-ad3c6d5018ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cf2abaf-e86d-4e77-bf41-ad3c6d5018ac">
											<gml:posList>35.671705600114535 139.7404521821723 26.87 35.67170182372342 139.7404526504978 26.87 35.67169345969844 139.74046526417595 26.87 35.67169384185287 139.74046990323828 26.87 35.671705600114535 139.7404521821723 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6df5ff71-cd0d-400b-b8da-55e258df4ce6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6df5ff71-cd0d-400b-b8da-55e258df4ce6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6df5ff71-cd0d-400b-b8da-55e258df4ce6">
											<gml:posList>35.67166463774317 139.74043532857945 20.003 35.67166463774317 139.74043532857945 19.784 35.671585932366824 139.74035682445805 19.784 35.671585932366824 139.74035682445805 20.003 35.67166463774317 139.74043532857945 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13571ffb-e01b-47a3-a639-0e7090c462db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13571ffb-e01b-47a3-a639-0e7090c462db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13571ffb-e01b-47a3-a639-0e7090c462db">
											<gml:posList>35.67167426855713 139.74041734486596 23.068 35.67167426855713 139.74041734486596 22.651 35.67166310096106 139.74040620090793 22.651 35.67166310096106 139.74040620090793 23.068 35.67167426855713 139.74041734486596 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02a6a4b3-d285-4ac6-86ba-83858ee8fad5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02a6a4b3-d285-4ac6-86ba-83858ee8fad5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02a6a4b3-d285-4ac6-86ba-83858ee8fad5">
											<gml:posList>35.67167919335957 139.74040994909114 23.068 35.67167919335957 139.74040994909114 22.651 35.67167426855713 139.74041734486596 22.651 35.67167426855713 139.74041734486596 23.068 35.67167919335957 139.74040994909114 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e6ba46d-19fc-42f7-828f-268a94d0e8bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e6ba46d-19fc-42f7-828f-268a94d0e8bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e6ba46d-19fc-42f7-828f-268a94d0e8bc">
											<gml:posList>35.67167972741563 139.7404245408174 26.87 35.67167972741563 139.7404245408174 26.742 35.67169043496081 139.74043523240937 26.742 35.67169043496081 139.74043523240937 26.87 35.67167972741563 139.7404245408174 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca5cb94b-f5b6-4f75-adbf-b8adffc9b9f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca5cb94b-f5b6-4f75-adbf-b8adffc9b9f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca5cb94b-f5b6-4f75-adbf-b8adffc9b9f5">
											<gml:posList>35.67168800407707 139.74043889159756 26.87 35.67168800407707 139.74043889159756 26.742 35.67170182372342 139.7404526504978 26.742 35.67170182372342 139.7404526504978 26.87 35.67168800407707 139.74043889159756 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33a2259a-0306-4d56-8ce6-fa7e25c77d28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33a2259a-0306-4d56-8ce6-fa7e25c77d28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33a2259a-0306-4d56-8ce6-fa7e25c77d28">
											<gml:posList>35.671649918558074 139.7402605468572 20.003 35.671649918558074 139.7402605468572 19.784 35.671713171590795 139.74032365908184 19.784 35.671713171590795 139.74032365908184 20.003 35.671649918558074 139.7402605468572 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c89bd85-cd20-4547-9bd5-17f49a309fca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c89bd85-cd20-4547-9bd5-17f49a309fca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c89bd85-cd20-4547-9bd5-17f49a309fca">
											<gml:posList>35.67164941821816 139.74025461550283 8.085 35.67158108344559 139.7403574265882 8.085 35.67158108344559 139.7403574265882 20.003 35.67164941821816 139.74025461550283 20.003 35.67164941821816 139.74025461550283 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cacad376-c925-4589-8a54-53855463ff0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cacad376-c925-4589-8a54-53855463ff0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cacad376-c925-4589-8a54-53855463ff0b">
											<gml:posList>35.671585932366824 139.74035682445805 20.003 35.671585932366824 139.74035682445805 19.784 35.671649918558074 139.7402605468572 19.784 35.671649918558074 139.7402605468572 20.003 35.671585932366824 139.74035682445805 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ec5056a-e849-498a-8a62-66a22f848c97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ec5056a-e849-498a-8a62-66a22f848c97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ec5056a-e849-498a-8a62-66a22f848c97">
											<gml:posList>35.671777683262 139.74038256124857 20.003 35.671798530033755 139.74040334860035 20.003 35.671798530033755 139.74040334860035 8.085 35.67164941821816 139.74025461550283 8.085 35.67164941821816 139.74025461550283 20.003 35.67171535037696 139.74032037576052 20.003 35.67171535037696 139.74032037576052 23.068 35.671777683262 139.74038256124857 23.068 35.671777683262 139.74038256124857 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-380a37f2-9954-4c03-a47d-24b0947bd094">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-380a37f2-9954-4c03-a47d-24b0947bd094">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-380a37f2-9954-4c03-a47d-24b0947bd094">
											<gml:posList>35.67171586908237 139.74032674895662 23.068 35.67171586908237 139.74032674895662 22.651 35.67177248284833 139.7403832190184 22.651 35.67177248284833 139.7403832190184 23.068 35.67171586908237 139.74032674895662 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43b2d213-530b-4161-8a7a-fb76d0327684">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43b2d213-530b-4161-8a7a-fb76d0327684">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43b2d213-530b-4161-8a7a-fb76d0327684">
											<gml:posList>35.67165791856607 139.74040684760794 19.784 35.67165791856607 139.74040684760794 23.068 35.67171535037696 139.74032037576052 23.068 35.67171535037696 139.74032037576052 20.003 35.671713171590795 139.74032365908184 20.003 35.671713171590795 139.74032365908184 19.784 35.67165791856607 139.74040684760794 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0131ea6-8f81-4d19-a9ac-4940a09f6ab7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0131ea6-8f81-4d19-a9ac-4940a09f6ab7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0131ea6-8f81-4d19-a9ac-4940a09f6ab7">
											<gml:posList>35.67166310096106 139.74040620090793 23.068 35.67166310096106 139.74040620090793 22.651 35.67171586908237 139.74032674895662 22.651 35.67171586908237 139.74032674895662 23.068 35.67166310096106 139.74040620090793 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da53a011-9309-4d12-9d91-9cb5d7e24d18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da53a011-9309-4d12-9d91-9cb5d7e24d18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da53a011-9309-4d12-9d91-9cb5d7e24d18">
											<gml:posList>35.67177248284833 139.7403832190184 23.068 35.67177248284833 139.7403832190184 22.651 35.67174310517856 139.74042743886665 22.651 35.67174310517856 139.74042743886665 23.068 35.67177248284833 139.7403832190184 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0358ec5d-c695-489d-bf1d-5676f1b70d0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0358ec5d-c695-489d-bf1d-5676f1b70d0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0358ec5d-c695-489d-bf1d-5676f1b70d0d">
											<gml:posList>35.671777683262 139.74038256124857 20.003 35.671777683262 139.74038256124857 23.068 35.671743650902414 139.74043378994145 23.068 35.671743650902414 139.74043378994145 20.003 35.671777683262 139.74038256124857 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9511fb4d-e19b-4f16-991c-7c91188169ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9511fb4d-e19b-4f16-991c-7c91188169ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9511fb4d-e19b-4f16-991c-7c91188169ff">
											<gml:posList>35.67169384185287 139.74046990323828 8.085 35.67169384185287 139.74046990323828 26.87 35.67166513808271 139.74044127098256 26.87 35.67166513808271 139.74044127098256 20.003 35.67158108344559 139.7403574265882 20.003 35.67158108344559 139.7403574265882 8.085 35.67169384185287 139.74046990323828 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fed6b6bb-bd6f-468a-bcc7-695f4f1765a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fed6b6bb-bd6f-468a-bcc7-695f4f1765a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fed6b6bb-bd6f-468a-bcc7-695f4f1765a6">
											<gml:posList>35.67165791856607 139.74040684760794 19.784 35.67167479624557 139.7404236849097 19.784 35.67167479624557 139.7404236849097 23.068 35.67165791856607 139.74040684760794 23.068 35.67165791856607 139.74040684760794 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61133f19-4bd5-4bca-a82f-0fb5b929c581">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61133f19-4bd5-4bca-a82f-0fb5b929c581">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61133f19-4bd5-4bca-a82f-0fb5b929c581">
											<gml:posList>35.67169527720896 139.74042598092777 23.068 35.67169527720896 139.74042598092777 22.651 35.67167919335957 139.74040994909114 22.651 35.67167919335957 139.74040994909114 23.068 35.67169527720896 139.74042598092777 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0cd04ba8-fb4b-430e-8ebc-d6e415b61bbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cd04ba8-fb4b-430e-8ebc-d6e415b61bbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cd04ba8-fb4b-430e-8ebc-d6e415b61bbd">
											<gml:posList>35.67167479624557 139.7404236849097 19.784 35.67167972104839 139.74041628913525 19.784 35.67167972104839 139.74041628913525 23.068 35.67167479624557 139.7404236849097 23.068 35.67167479624557 139.7404236849097 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84a0d491-1314-4454-a977-56b9fe68d20d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84a0d491-1314-4454-a977-56b9fe68d20d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84a0d491-1314-4454-a977-56b9fe68d20d">
											<gml:posList>35.67167972104839 139.74041628913525 19.784 35.6716958139277 139.74043234305566 19.784 35.6716958139277 139.74043234305566 23.068 35.67167972104839 139.74041628913525 23.068 35.67167972104839 139.74041628913525 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bbf28ba2-5b34-4546-a5b7-99bb10cd31b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbf28ba2-5b34-4546-a5b7-99bb10cd31b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbf28ba2-5b34-4546-a5b7-99bb10cd31b0">
											<gml:posList>35.671696222550125 139.74042455484144 23.068 35.671696222550125 139.74042455484144 22.651 35.67169527720896 139.74042598092777 22.651 35.67169527720896 139.74042598092777 23.068 35.671696222550125 139.74042455484144 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa427596-b400-4465-9a79-45fceb4015b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa427596-b400-4465-9a79-45fceb4015b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa427596-b400-4465-9a79-45fceb4015b1">
											<gml:posList>35.67174310517856 139.74042743886665 23.068 35.67174310517856 139.74042743886665 22.651 35.67173900979576 139.74042335642716 22.651 35.67173900979576 139.74042335642716 23.068 35.67174310517856 139.74042743886665 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed691e5f-5b81-4efc-9c28-dc73913f6d0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed691e5f-5b81-4efc-9c28-dc73913f6d0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed691e5f-5b81-4efc-9c28-dc73913f6d0b">
											<gml:posList>35.67167933624573 139.7404199017666 26.87 35.67169422035705 139.74043475302625 26.87 35.67169422035705 139.74043475302625 19.784 35.67167933624573 139.7404199017666 19.784 35.67167933624573 139.7404199017666 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cc80b6a-4096-432e-9454-d29b6bd4291a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cc80b6a-4096-432e-9454-d29b6bd4291a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cc80b6a-4096-432e-9454-d29b6bd4291a">
											<gml:posList>35.671667307866905 139.74043799872328 20.003 35.67166513808271 139.74044127098256 20.003 35.67166513808271 139.74044127098256 26.87 35.67167933624573 139.7404199017666 26.87 35.67167933624573 139.7404199017666 19.784 35.671667307866905 139.74043799872328 19.784 35.671667307866905 139.74043799872328 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbf9eced-807f-43e9-97b2-c8ae0d378d41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbf9eced-807f-43e9-97b2-c8ae0d378d41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbf9eced-807f-43e9-97b2-c8ae0d378d41">
											<gml:posList>35.6716958139277 139.74043234305566 19.784 35.67169675926894 139.7404309169694 19.784 35.67169675926894 139.7404309169694 23.068 35.6716958139277 139.74043234305566 23.068 35.6716958139277 139.74043234305566 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9c332d5-64b5-4678-a74a-c1f4eb8ec594">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9c332d5-64b5-4678-a74a-c1f4eb8ec594">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9c332d5-64b5-4678-a74a-c1f4eb8ec594">
											<gml:posList>35.671739555519835 139.74042970750162 23.068 35.671739555519835 139.74042970750162 8.085 35.671743650902414 139.74043378994145 8.085 35.671743650902414 139.74043378994145 20.003 35.671743650902414 139.74043378994145 23.068 35.671739555519835 139.74042970750162 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff045b67-f9a5-4001-88a8-df0b083259a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff045b67-f9a5-4001-88a8-df0b083259a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff045b67-f9a5-4001-88a8-df0b083259a7">
											<gml:posList>35.67166893249271 139.7404407915894 26.87 35.67166893249271 139.7404407915894 26.742 35.67167972741563 139.7404245408174 26.742 35.67167972741563 139.7404245408174 26.87 35.67166893249271 139.7404407915894 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da38c0a8-ad68-4c5e-9d97-ce8e15e8e292">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da38c0a8-ad68-4c5e-9d97-ce8e15e8e292">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da38c0a8-ad68-4c5e-9d97-ce8e15e8e292">
											<gml:posList>35.67171380384265 139.7404420983121 23.068 35.67171380384265 139.7404420983121 22.651 35.671696222550125 139.74042455484144 22.651 35.671696222550125 139.74042455484144 23.068 35.67171380384265 139.7404420983121 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d327ad5e-5342-4ab1-ae5b-f4d3be8e711e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d327ad5e-5342-4ab1-ae5b-f4d3be8e711e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d327ad5e-5342-4ab1-ae5b-f4d3be8e711e">
											<gml:posList>35.671743650902414 139.74043378994145 8.085 35.67174489623616 139.74043565534808 8.085 35.67174489623616 139.74043565534808 20.003 35.671743650902414 139.74043378994145 20.003 35.671743650902414 139.74043378994145 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b258366b-bf82-418c-b277-6aa249acdb8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b258366b-bf82-418c-b277-6aa249acdb8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b258366b-bf82-418c-b277-6aa249acdb8d">
											<gml:posList>35.671691789464795 139.7404384011682 19.784 35.67169422035705 139.74043475302625 19.784 35.67169422035705 139.74043475302625 26.87 35.671691789464795 139.7404384011682 26.87 35.671691789464795 139.7404384011682 19.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1470ecdf-cb7d-4ea7-a794-8516714981cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1470ecdf-cb7d-4ea7-a794-8516714981cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1470ecdf-cb7d-4ea7-a794-8516714981cb">
											<gml:posList>35.671667307866905 139.74043799872328 20.003 35.671667307866905 139.74043799872328 19.784 35.67166463774317 139.74043532857945 19.784 35.67166463774317 139.74043532857945 20.003 35.671667307866905 139.74043799872328 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8806180-e5c1-43d2-be8d-5cfb70ceb955">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8806180-e5c1-43d2-be8d-5cfb70ceb955">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8806180-e5c1-43d2-be8d-5cfb70ceb955">
											<gml:posList>35.67170862145604 139.74044275605667 23.068 35.67169675926894 139.7404309169694 23.068 35.67169675926894 139.7404309169694 19.784 35.67170741268007 139.74044154234852 19.784 35.67170741268007 139.74044154234852 20.003 35.67170862145604 139.74044275605667 20.003 35.67170862145604 139.74044275605667 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4291e7d1-237b-4976-8e93-fd31b039153e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4291e7d1-237b-4976-8e93-fd31b039153e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4291e7d1-237b-4976-8e93-fd31b039153e">
											<gml:posList>35.67169043496081 139.74043523240937 26.87 35.67169043496081 139.74043523240937 26.742 35.67168800407707 139.74043889159756 26.742 35.67168800407707 139.74043889159756 26.87 35.67169043496081 139.74043523240937 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc69d152-fa20-4857-83d1-8debabf4cd99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc69d152-fa20-4857-83d1-8debabf4cd99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc69d152-fa20-4857-83d1-8debabf4cd99">
											<gml:posList>35.67173900979576 139.74042335642716 23.068 35.67173900979576 139.74042335642716 22.651 35.67172054409656 139.74045117067973 22.651 35.67172054409656 139.74045117067973 23.068 35.67173900979576 139.74042335642716 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ec9ad07-bdb3-43f9-a299-bbaaf07e4eec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ec9ad07-bdb3-43f9-a299-bbaaf07e4eec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ec9ad07-bdb3-43f9-a299-bbaaf07e4eec">
											<gml:posList>35.671712867506486 139.7404435133417 23.068 35.671712867506486 139.7404435133417 22.651 35.67171380384265 139.7404420983121 22.651 35.67171380384265 139.7404420983121 23.068 35.671712867506486 139.7404435133417 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5ebdd82-142d-4b72-9cec-3f3bf9cebed3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5ebdd82-142d-4b72-9cec-3f3bf9cebed3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5ebdd82-142d-4b72-9cec-3f3bf9cebed3">
											<gml:posList>35.671707685119856 139.74044417108615 20.003 35.671707685119856 139.74044417108615 23.068 35.67170862145604 139.74044275605667 23.068 35.67170862145604 139.74044275605667 20.003 35.671707685119856 139.74044417108615 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-078f9b57-4690-44dc-926e-6c0cdab6c66d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-078f9b57-4690-44dc-926e-6c0cdab6c66d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-078f9b57-4690-44dc-926e-6c0cdab6c66d">
											<gml:posList>35.671721080813974 139.74045753280978 23.068 35.671721080813974 139.74045753280978 8.085 35.671739555519835 139.74042970750162 8.085 35.671739555519835 139.74042970750162 23.068 35.671721080813974 139.74045753280978 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56f43dd9-40ec-407d-9447-d1cc4d01b16a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56f43dd9-40ec-407d-9447-d1cc4d01b16a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56f43dd9-40ec-407d-9447-d1cc4d01b16a">
											<gml:posList>35.671705600114535 139.7404521821723 26.87 35.671705600114535 139.7404521821723 8.085 35.67170365165118 139.74045024025585 8.085 35.67170365165118 139.74045024025585 20.003 35.67170243386156 139.7404490265581 20.003 35.67170243386156 139.7404490265581 19.784 35.671691789464795 139.7404384011682 19.784 35.671691789464795 139.7404384011682 26.87 35.671705600114535 139.7404521821723 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1f4b39c-0234-46dd-b824-184f9e3eb0e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1f4b39c-0234-46dd-b824-184f9e3eb0e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1f4b39c-0234-46dd-b824-184f9e3eb0e5">
											<gml:posList>35.67170741268007 139.74044154234852 20.003 35.67170741268007 139.74044154234852 19.784 35.67170243386156 139.7404490265581 19.784 35.67170243386156 139.7404490265581 20.003 35.67170741268007 139.74044154234852 20.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2106bdf-e0ef-451e-8c09-a19ca51e14fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2106bdf-e0ef-451e-8c09-a19ca51e14fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2106bdf-e0ef-451e-8c09-a19ca51e14fc">
											<gml:posList>35.67174117914281 139.74048963259494 8.085 35.671798530033755 139.74040334860035 8.085 35.671798530033755 139.74040334860035 20.003 35.67174117914281 139.74048963259494 20.003 35.67174117914281 139.74048963259494 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d39c7274-9c63-4015-b918-98bd81aabfa9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d39c7274-9c63-4015-b918-98bd81aabfa9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d39c7274-9c63-4015-b918-98bd81aabfa9">
											<gml:posList>35.67170365165118 139.74045024025585 8.085 35.671707685119856 139.74044417108615 8.085 35.671707685119856 139.74044417108615 20.003 35.67170365165118 139.74045024025585 20.003 35.67170365165118 139.74045024025585 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adb3769c-659c-4473-9165-7241b46d1b36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adb3769c-659c-4473-9165-7241b46d1b36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adb3769c-659c-4473-9165-7241b46d1b36">
											<gml:posList>35.67172054409656 139.74045117067973 23.068 35.67172054409656 139.74045117067973 22.651 35.671712867506486 139.7404435133417 22.651 35.671712867506486 139.7404435133417 23.068 35.67172054409656 139.74045117067973 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7c980af-6657-4a1a-8cd3-d87c14c3cb7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7c980af-6657-4a1a-8cd3-d87c14c3cb7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7c980af-6657-4a1a-8cd3-d87c14c3cb7c">
											<gml:posList>35.671721080813974 139.74045753280978 23.068 35.671707685119856 139.74044417108615 23.068 35.671707685119856 139.74044417108615 20.003 35.671707685119856 139.74044417108615 8.085 35.671721080813974 139.74045753280978 8.085 35.671721080813974 139.74045753280978 23.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88bfe3de-95a3-4ef6-ae92-1b34ed0a59c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88bfe3de-95a3-4ef6-ae92-1b34ed0a59c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88bfe3de-95a3-4ef6-ae92-1b34ed0a59c2">
											<gml:posList>35.67169345969844 139.74046526417595 26.87 35.67169345969844 139.74046526417595 26.742 35.67166893249271 139.7404407915894 26.742 35.67166893249271 139.7404407915894 26.87 35.67169345969844 139.74046526417595 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c753b531-02eb-48e6-a020-f6e9513dea9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c753b531-02eb-48e6-a020-f6e9513dea9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c753b531-02eb-48e6-a020-f6e9513dea9a">
											<gml:posList>35.67174489623616 139.74043565534808 8.085 35.67172231757669 139.74047165977942 8.085 35.67172231757669 139.74047165977942 20.003 35.67174489623616 139.74043565534808 20.003 35.67174489623616 139.74043565534808 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bed861c-e29e-499a-a4e7-16cc118097d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bed861c-e29e-499a-a4e7-16cc118097d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bed861c-e29e-499a-a4e7-16cc118097d6">
											<gml:posList>35.67170182372342 139.7404526504978 26.87 35.67170182372342 139.7404526504978 26.742 35.67169345969844 139.74046526417595 26.742 35.67169345969844 139.74046526417595 26.87 35.67170182372342 139.7404526504978 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bbc19147-b73b-4c39-8d66-12a937a1a0f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbc19147-b73b-4c39-8d66-12a937a1a0f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbc19147-b73b-4c39-8d66-12a937a1a0f2">
											<gml:posList>35.67169384185287 139.74046990323828 26.87 35.67169384185287 139.74046990323828 8.085 35.671705600114535 139.7404521821723 8.085 35.671705600114535 139.7404521821723 26.87 35.67169384185287 139.74046990323828 26.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-535e3657-b388-4681-9234-0efd184ac9c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-535e3657-b388-4681-9234-0efd184ac9c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-535e3657-b388-4681-9234-0efd184ac9c4">
											<gml:posList>35.67172231757669 139.74047165977942 8.085 35.67174117914281 139.74048963259494 8.085 35.67174117914281 139.74048963259494 20.003 35.67172231757669 139.74047165977942 20.003 35.67172231757669 139.74047165977942 8.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3498</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">256.0422</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.1</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>