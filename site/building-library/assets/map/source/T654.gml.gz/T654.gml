<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_bf0cce03-7404-4154-b000-c2edc201a4e1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">26.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66895260832653 139.7486939560074 0 35.66888182035985 139.74865106158128 0 35.66887911593106 139.74865062259536 0 35.66887578092976 139.7486507365781 0 35.66887298745123 139.74865184413363 0 35.66887046453983 139.7486531723244 0 35.668868482918114 139.7486551627065 0 35.66886659205506 139.7486580366769 0 35.668845545434046 139.74872278874895 0 35.66892796201428 139.7487669964816 0 35.66895260832653 139.7486939560074 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895260832653 139.7486939560074 5.49 35.66892796201428 139.7487669964816 5.49 35.668845545434046 139.74872278874895 5.49 35.66886659205506 139.7486580366769 5.49 35.668868482918114 139.7486551627065 5.49 35.66887046453983 139.7486531723244 5.49 35.66887298745123 139.74865184413363 5.49 35.66887578092976 139.7486507365781 5.49 35.66887911593106 139.74865062259536 5.49 35.66888182035985 139.74865106158128 5.49 35.66895260832653 139.7486939560074 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895260832653 139.7486939560074 5.49 35.66888182035985 139.74865106158128 5.49 35.66888182035985 139.74865106158128 31.660000000000004 35.66895260832653 139.7486939560074 31.660000000000004 35.66895260832653 139.7486939560074 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66888182035985 139.74865106158128 5.49 35.66887911593106 139.74865062259536 5.49 35.66887911593106 139.74865062259536 31.660000000000004 35.66888182035985 139.74865106158128 31.660000000000004 35.66888182035985 139.74865106158128 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887911593106 139.74865062259536 5.49 35.66887578092976 139.7486507365781 5.49 35.66887578092976 139.7486507365781 31.660000000000004 35.66887911593106 139.74865062259536 31.660000000000004 35.66887911593106 139.74865062259536 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887578092976 139.7486507365781 5.49 35.66887298745123 139.74865184413363 5.49 35.66887298745123 139.74865184413363 31.660000000000004 35.66887578092976 139.7486507365781 31.660000000000004 35.66887578092976 139.7486507365781 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887298745123 139.74865184413363 5.49 35.66887046453983 139.7486531723244 5.49 35.66887046453983 139.7486531723244 31.660000000000004 35.66887298745123 139.74865184413363 31.660000000000004 35.66887298745123 139.74865184413363 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887046453983 139.7486531723244 5.49 35.668868482918114 139.7486551627065 5.49 35.668868482918114 139.7486551627065 31.660000000000004 35.66887046453983 139.7486531723244 31.660000000000004 35.66887046453983 139.7486531723244 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668868482918114 139.7486551627065 5.49 35.66886659205506 139.7486580366769 5.49 35.66886659205506 139.7486580366769 31.660000000000004 35.668868482918114 139.7486551627065 31.660000000000004 35.668868482918114 139.7486551627065 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66886659205506 139.7486580366769 5.49 35.668845545434046 139.74872278874895 5.49 35.668845545434046 139.74872278874895 31.660000000000004 35.66886659205506 139.7486580366769 31.660000000000004 35.66886659205506 139.7486580366769 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668845545434046 139.74872278874895 5.49 35.66892796201428 139.7487669964816 5.49 35.66892796201428 139.7487669964816 31.660000000000004 35.668845545434046 139.74872278874895 31.660000000000004 35.668845545434046 139.74872278874895 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66892796201428 139.7487669964816 5.49 35.66895260832653 139.7486939560074 5.49 35.66895260832653 139.7486939560074 31.660000000000004 35.66892796201428 139.7487669964816 31.660000000000004 35.66892796201428 139.7487669964816 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895260832653 139.7486939560074 31.660000000000004 35.66888182035985 139.74865106158128 31.660000000000004 35.66887911593106 139.74865062259536 31.660000000000004 35.66887578092976 139.7486507365781 31.660000000000004 35.66887298745123 139.74865184413363 31.660000000000004 35.66887046453983 139.7486531723244 31.660000000000004 35.668868482918114 139.7486551627065 31.660000000000004 35.66886659205506 139.7486580366769 31.660000000000004 35.668845545434046 139.74872278874895 31.660000000000004 35.66892796201428 139.7487669964816 31.660000000000004 35.66895260832653 139.7486939560074 31.660000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e59ed363-d7a1-4369-a324-1164a4e2d7d5"/>
							<gml:surfaceMember xlink:href="#poly-6dc4278d-d258-48c9-a343-289916bcd916"/>
							<gml:surfaceMember xlink:href="#poly-8c787848-eb1e-4a6e-b5a9-68e191e197a2"/>
							<gml:surfaceMember xlink:href="#poly-d021ecd6-e40b-4dcc-949b-05d043f4a073"/>
							<gml:surfaceMember xlink:href="#poly-1cb18675-1e49-464d-924a-a5d82d234f13"/>
							<gml:surfaceMember xlink:href="#poly-3827cb68-3205-484d-b939-335b0e9bd9d5"/>
							<gml:surfaceMember xlink:href="#poly-81f9f338-4f5f-43e5-a4fe-d01b17631855"/>
							<gml:surfaceMember xlink:href="#poly-3f3d9840-ebf7-4f72-a1a9-f4021b598718"/>
							<gml:surfaceMember xlink:href="#poly-b9ca8c03-b8d4-4cfb-91c7-9cfdb648868d"/>
							<gml:surfaceMember xlink:href="#poly-ac053424-6806-43ea-8925-256ef0566f9c"/>
							<gml:surfaceMember xlink:href="#poly-b588ad72-265d-4bcb-9903-c56f292db80b"/>
							<gml:surfaceMember xlink:href="#poly-4b9564e7-86c9-4c88-a96d-3d5d2d6bd2bb"/>
							<gml:surfaceMember xlink:href="#poly-e2c99701-7a25-42c1-990c-b468620bbf2e"/>
							<gml:surfaceMember xlink:href="#poly-3d66db58-cb53-4060-98fa-40e2b7191222"/>
							<gml:surfaceMember xlink:href="#poly-11b0f6a2-3c2c-4934-a64a-6bfbf06b73a4"/>
							<gml:surfaceMember xlink:href="#poly-9b9bc08f-be3c-477e-b311-bfc116053e44"/>
							<gml:surfaceMember xlink:href="#poly-24ab0ced-b89c-4fd0-beca-448baa785dec"/>
							<gml:surfaceMember xlink:href="#poly-d951f448-c635-4f71-8a3e-414fb412e5de"/>
							<gml:surfaceMember xlink:href="#poly-eefaff81-76a2-46a6-acbc-9ad8e07f3edc"/>
							<gml:surfaceMember xlink:href="#poly-42233a4f-82a6-43fc-b382-dd1906fa1549"/>
							<gml:surfaceMember xlink:href="#poly-d793a887-65ee-47e3-b8f7-cc701b124221"/>
							<gml:surfaceMember xlink:href="#poly-7b758934-cc85-4700-ba42-2dd0921ef259"/>
							<gml:surfaceMember xlink:href="#poly-cc355167-ae9e-4c95-bf66-323cff3c6648"/>
							<gml:surfaceMember xlink:href="#poly-a944f768-3c01-4a2e-a1d8-004d3d7910a1"/>
							<gml:surfaceMember xlink:href="#poly-8ec63830-45ed-4c26-ad5e-13996797f332"/>
							<gml:surfaceMember xlink:href="#poly-a7cc3cf2-b4b2-4080-b248-42c9f9505f25"/>
							<gml:surfaceMember xlink:href="#poly-e69cadcb-d574-4154-bd59-4240b83812a0"/>
							<gml:surfaceMember xlink:href="#poly-4a3de6de-1a40-4fd5-be42-4c9e00bbe2c5"/>
							<gml:surfaceMember xlink:href="#poly-5726b45b-2b67-4703-b115-4fff8ad175ce"/>
							<gml:surfaceMember xlink:href="#poly-28de6194-5402-4f4b-81fe-60b340399062"/>
							<gml:surfaceMember xlink:href="#poly-5d875295-4b17-43e8-908a-579376ce8540"/>
							<gml:surfaceMember xlink:href="#poly-416db246-6938-4ffb-b6f6-926e94792ca8"/>
							<gml:surfaceMember xlink:href="#poly-a5bd50e8-9eea-45b4-a5be-647157e6e74d"/>
							<gml:surfaceMember xlink:href="#poly-345bd717-0db0-494c-acfb-64520932d675"/>
							<gml:surfaceMember xlink:href="#poly-3f836883-a3de-4a22-a423-2cc5ea8b7d7e"/>
							<gml:surfaceMember xlink:href="#poly-30a4e1ca-43e6-4e76-94ab-d2f984592aba"/>
							<gml:surfaceMember xlink:href="#poly-f8837e48-da46-45ff-a593-d296edeb31f9"/>
							<gml:surfaceMember xlink:href="#poly-90547f43-d210-4dcd-8346-9f2022444af6"/>
							<gml:surfaceMember xlink:href="#poly-b739cd14-95ac-40d2-934e-7bb410e32caf"/>
							<gml:surfaceMember xlink:href="#poly-d037bf89-4b3e-4be2-899a-c2870dc5728d"/>
							<gml:surfaceMember xlink:href="#poly-3aa118e4-12f8-4342-be24-7581460fb270"/>
							<gml:surfaceMember xlink:href="#poly-e88e27c1-6e1b-424b-8efa-22a978eaf1d5"/>
							<gml:surfaceMember xlink:href="#poly-cb5679d0-73cd-40e5-a255-5b6de26cfb0f"/>
							<gml:surfaceMember xlink:href="#poly-1e293a9f-5c2e-4987-a142-6aa47a39aec3"/>
							<gml:surfaceMember xlink:href="#poly-e7bcd896-bea6-476e-818c-ff40828d8435"/>
							<gml:surfaceMember xlink:href="#poly-304a182d-a0cd-44f3-919f-fe2cd350e423"/>
							<gml:surfaceMember xlink:href="#poly-4e10cb53-5e0c-4839-8a4a-e6dccf8c488b"/>
							<gml:surfaceMember xlink:href="#poly-cb53cb58-f624-4096-a9ef-b3aeaf6e0913"/>
							<gml:surfaceMember xlink:href="#poly-aeea27c0-e3f3-443c-893a-6e5dcd8e0b14"/>
							<gml:surfaceMember xlink:href="#poly-be1d92a0-3cc0-4a41-aba7-267eba70b629"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bf0cce03-7404-4154-b000-c2edc201a4e1_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9be784f5-afca-4166-8596-e8358f7153a4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889225461837 139.7487356412525 31.312 35.6688765654096 139.7487280802133 31.312 35.66888237556319 139.74870998064634 31.312 35.66889806478086 139.74871755272858 31.312 35.66889225461837 139.7487356412525 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad82b87f-dc41-4237-9a67-fd03adf4dc43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893352593204 139.74874481012307 31.312 35.66892701355593 139.74876412550628 31.312 35.66890713979955 139.74875346493008 31.312 35.66891349029938 139.74873467993237 31.312 35.66893352593204 139.74874481012307 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f792b373-41d4-411f-92f0-09c1501b23c3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66892701355593 139.74876412550628 31.6 35.66893352593204 139.74874481012307 31.6 35.66893490552886 139.74874551561555 31.6 35.66892784456428 139.74876660999337 31.6 35.66890655513316 139.74875521082384 31.6 35.66890713979955 139.74875346493008 31.6 35.66892701355593 139.74876412550628 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb3542f7-5aee-4d56-a356-8f78d404e453">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb3542f7-5aee-4d56-a356-8f78d404e453_0">
											<gml:posList>35.66888237556319 139.74870998064634 31.312 35.6688765654096 139.7487280802133 31.312 35.6688765654096 139.7487280802133 34.1 35.66888237556319 139.74870998064634 34.1 35.66888237556319 139.74870998064634 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e248a60c-be48-48e9-b00d-90eff2051c5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e248a60c-be48-48e9-b00d-90eff2051c5b_0">
											<gml:posList>35.6688765654096 139.7487280802133 31.312 35.66889225461837 139.7487356412525 31.312 35.66889225461837 139.7487356412525 34.1 35.6688765654096 139.7487280802133 34.1 35.6688765654096 139.7487280802133 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5a7b6e3-ea7b-4c6f-a68d-a198830cd15b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5a7b6e3-ea7b-4c6f-a68d-a198830cd15b_0">
											<gml:posList>35.66889225461837 139.7487356412525 34.1 35.66889806478086 139.74871755272858 34.1 35.66888237556319 139.74870998064634 34.1 35.6688765654096 139.7487280802133 34.1 35.66889225461837 139.7487356412525 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9f4579e-9d90-43b3-9d2a-8e1032f94ba2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9f4579e-9d90-43b3-9d2a-8e1032f94ba2_0">
											<gml:posList>35.66889806478086 139.74871755272858 31.312 35.66888237556319 139.74870998064634 31.312 35.66888237556319 139.74870998064634 34.1 35.66889806478086 139.74871755272858 34.1 35.66889806478086 139.74871755272858 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-859e8fc6-acd1-49c6-845d-0f705edd817a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-859e8fc6-acd1-49c6-845d-0f705edd817a_0">
											<gml:posList>35.66889806478086 139.74871755272858 31.312 35.66889806478086 139.74871755272858 34.1 35.66889225461837 139.7487356412525 34.1 35.66889225461837 139.7487356412525 31.312 35.66889806478086 139.74871755272858 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59a1cc48-5e7f-4a54-95ca-303d326f85d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59a1cc48-5e7f-4a54-95ca-303d326f85d2_0">
											<gml:posList>35.66890655513316 139.74875521082384 33.08 35.66891349029938 139.74873467993237 33.08 35.66891349029938 139.74873467993237 31.312 35.66890713979955 139.74875346493008 31.312 35.66890713979955 139.74875346493008 31.6 35.66890655513316 139.74875521082384 31.6 35.66890655513316 139.74875521082384 33.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f6168c5-d060-40aa-b619-7aad57c3aa29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f6168c5-d060-40aa-b619-7aad57c3aa29_0">
											<gml:posList>35.66892701355593 139.74876412550628 31.6 35.66890713979955 139.74875346493008 31.6 35.66890713979955 139.74875346493008 31.312 35.66892701355593 139.74876412550628 31.312 35.66892701355593 139.74876412550628 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d52f6a45-e405-47d0-a786-be68ac755cda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d52f6a45-e405-47d0-a786-be68ac755cda_0">
											<gml:posList>35.66890655513316 139.74875521082384 31.6 35.66892784456428 139.74876660999337 31.6 35.66892784456428 139.74876660999337 33.08 35.66890655513316 139.74875521082384 33.08 35.66890655513316 139.74875521082384 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fcf5056-2b33-4613-85ec-f8dcd0eea259">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fcf5056-2b33-4613-85ec-f8dcd0eea259_0">
											<gml:posList>35.66893490552886 139.74874551561555 33.08 35.66891349029938 139.74873467993237 33.08 35.66890655513316 139.74875521082384 33.08 35.66892784456428 139.74876660999337 33.08 35.66893490552886 139.74874551561555 33.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a76ed30-9e41-49c2-8547-5bf7e42be8d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a76ed30-9e41-49c2-8547-5bf7e42be8d1_0">
											<gml:posList>35.66893352593204 139.74874481012307 31.6 35.66893352593204 139.74874481012307 31.312 35.66891349029938 139.74873467993237 31.312 35.66891349029938 139.74873467993237 33.08 35.66893490552886 139.74874551561555 33.08 35.66893490552886 139.74874551561555 31.6 35.66893352593204 139.74874481012307 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d18458b-fb08-43c5-ba4a-2a30bf4aabbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d18458b-fb08-43c5-ba4a-2a30bf4aabbb_0">
											<gml:posList>35.66892701355593 139.74876412550628 31.312 35.66893352593204 139.74874481012307 31.312 35.66893352593204 139.74874481012307 31.6 35.66892701355593 139.74876412550628 31.6 35.66892701355593 139.74876412550628 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f67d52e-4389-4916-8c9c-19b512c75247">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f67d52e-4389-4916-8c9c-19b512c75247_0">
											<gml:posList>35.66892784456428 139.74876660999337 31.6 35.66893490552886 139.74874551561555 31.6 35.66893490552886 139.74874551561555 33.08 35.66892784456428 139.74876660999337 33.08 35.66892784456428 139.74876660999337 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bf0cce03-7404-4154-b000-c2edc201a4e1_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cc8f98f-1f09-438d-af10-8125be34e80c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689066710204 139.7487020570742 31.312 35.66890356766584 139.74871114020846 31.312 35.668891944764326 139.74870516551306 31.312 35.66889505713992 139.74869609341644 31.312 35.6689066710204 139.7487020570742 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2efc8d30-626c-4404-954b-699a5c048937">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894481506301 139.74869910065297 31.312 35.6688795828551 139.748660894932 31.312 35.668878176775834 139.74866098478523 31.312 35.66887611301295 139.74866152822116 31.312 35.668873554652365 139.7486637180412 31.312 35.66885315768674 139.7487165949283 31.312 35.66889973257747 139.74874357547716 31.312 35.668905481872514 139.74872865723478 31.312 35.66890738454498 139.74872975983288 31.312 35.66890076248573 139.74874691029967 31.312 35.668850228955094 139.7487176363477 31.312 35.66887159764062 139.7486622509828 31.312 35.66887367779205 139.74865937681247 31.312 35.668876696365274 139.74865791554578 31.312 35.66887979707958 139.74865790122524 31.312 35.6688813476348 139.74865817573917 31.312 35.66894856360104 139.74869742874074 31.312 35.668944910665715 139.74870687698004 31.312 35.66894229574559 139.7487055431664 31.312 35.66894481506301 139.74869910065297 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67a14d1f-74d0-4a5e-baef-9189de91e6d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894047154825 139.7487134982563 37.536 35.66893639680595 139.7487255648556 37.536 35.66891898508217 139.7487167353352 37.536 35.668923059831364 139.74870467978417 37.536 35.66894047154825 139.7487134982563 37.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b79e3217-bfb7-492b-9a33-dac872b4369c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b79e3217-bfb7-492b-9a33-dac872b4369c_0">
											<gml:posList>35.66889505713992 139.74869609341644 31.312 35.66889505713992 139.74869609341644 32.977 35.6689066710204 139.7487020570742 32.977 35.6689066710204 139.7487020570742 31.312 35.66889505713992 139.74869609341644 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-914f7cc7-5c42-4995-9b62-3b33144d90ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-914f7cc7-5c42-4995-9b62-3b33144d90ff_0">
											<gml:posList>35.66887979707958 139.74865790122524 31.312 35.668876696365274 139.74865791554578 31.312 35.668876696365274 139.74865791554578 33.474 35.66887979707958 139.74865790122524 33.474 35.66887979707958 139.74865790122524 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-969446ad-9aa6-4e86-bda6-65d8deb07627">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-969446ad-9aa6-4e86-bda6-65d8deb07627_0">
											<gml:posList>35.66887979707958 139.74865790122524 31.312 35.66887979707958 139.74865790122524 33.474 35.6688813476348 139.74865817573917 33.474 35.6688813476348 139.74865817573917 31.312 35.66887979707958 139.74865790122524 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9566550-a6d1-4c10-8506-6641052f6cb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9566550-a6d1-4c10-8506-6641052f6cb0_0">
											<gml:posList>35.66887367779205 139.74865937681247 31.312 35.66887367779205 139.74865937681247 33.474 35.668876696365274 139.74865791554578 33.474 35.668876696365274 139.74865791554578 31.312 35.66887367779205 139.74865937681247 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc52291c-3489-4a97-92e1-0625d6ce623a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc52291c-3489-4a97-92e1-0625d6ce623a_0">
											<gml:posList>35.66887159764062 139.7486622509828 31.312 35.66887159764062 139.7486622509828 33.474 35.66887367779205 139.74865937681247 33.474 35.66887367779205 139.74865937681247 31.312 35.66887159764062 139.7486622509828 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11be9662-69a7-4224-9bf0-a5e2ad6a37a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11be9662-69a7-4224-9bf0-a5e2ad6a37a7_0">
											<gml:posList>35.668878176775834 139.74866098478523 31.312 35.6688795828551 139.748660894932 31.312 35.6688795828551 139.748660894932 33.474 35.668878176775834 139.74866098478523 33.474 35.668878176775834 139.74866098478523 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb1004ea-3a02-46a6-9c26-16d75c56016b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb1004ea-3a02-46a6-9c26-16d75c56016b_0">
											<gml:posList>35.66887611301295 139.74866152822116 31.312 35.668878176775834 139.74866098478523 31.312 35.668878176775834 139.74866098478523 33.474 35.66887611301295 139.74866152822116 33.474 35.66887611301295 139.74866152822116 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac1323ca-eb98-4d0e-bf3b-48bec6801fe2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac1323ca-eb98-4d0e-bf3b-48bec6801fe2_0">
											<gml:posList>35.668873554652365 139.7486637180412 31.312 35.66887611301295 139.74866152822116 31.312 35.66887611301295 139.74866152822116 33.474 35.668873554652365 139.7486637180412 33.474 35.668873554652365 139.7486637180412 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e52d9c5-6c13-4cad-93cc-39f0e9ef86aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e52d9c5-6c13-4cad-93cc-39f0e9ef86aa_0">
											<gml:posList>35.6688813476348 139.74865817573917 31.312 35.6688813476348 139.74865817573917 33.474 35.66894856360104 139.74869742874074 33.474 35.66894856360104 139.74869742874074 31.312 35.6688813476348 139.74865817573917 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10994878-ef0c-4ab3-8a99-d6736364678e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10994878-ef0c-4ab3-8a99-d6736364678e_0">
											<gml:posList>35.6688795828551 139.748660894932 31.312 35.66894481506301 139.74869910065297 31.312 35.66894481506301 139.74869910065297 33.474 35.6688795828551 139.748660894932 33.474 35.6688795828551 139.748660894932 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-042433ff-bb11-4269-a815-9c6b7756398c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-042433ff-bb11-4269-a815-9c6b7756398c_0">
											<gml:posList>35.66887159764062 139.7486622509828 31.312 35.668850228955094 139.7487176363477 31.312 35.668850228955094 139.7487176363477 33.474 35.66887159764062 139.7486622509828 33.474 35.66887159764062 139.7486622509828 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5f5b0b7-6309-4ec6-b179-9f9b07030c30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5f5b0b7-6309-4ec6-b179-9f9b07030c30_0">
											<gml:posList>35.668873554652365 139.7486637180412 31.312 35.668873554652365 139.7486637180412 33.474 35.66885315768674 139.7487165949283 33.474 35.66885315768674 139.7487165949283 31.312 35.668873554652365 139.7486637180412 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5bfd1b3-fa81-4d4d-830a-81ecb1bd7e67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5bfd1b3-fa81-4d4d-830a-81ecb1bd7e67_0">
											<gml:posList>35.668891944764326 139.74870516551306 31.312 35.668891944764326 139.74870516551306 32.977 35.66889505713992 139.74869609341644 32.977 35.66889505713992 139.74869609341644 31.312 35.668891944764326 139.74870516551306 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6507a0ab-0369-481f-8195-2dbe03072a49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6507a0ab-0369-481f-8195-2dbe03072a49_0">
											<gml:posList>35.66894856360104 139.74869742874074 33.474 35.668944910665715 139.74870687698004 33.474 35.668944910665715 139.74870687698004 31.312 35.66894856360104 139.74869742874074 31.312 35.66894856360104 139.74869742874074 33.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a9765fb-81e6-489c-bf85-c2936c73b246">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a9765fb-81e6-489c-bf85-c2936c73b246_0">
											<gml:posList>35.66894229574559 139.7487055431664 31.312 35.66894229574559 139.7487055431664 33.474 35.66894481506301 139.74869910065297 33.474 35.66894481506301 139.74869910065297 31.312 35.66894229574559 139.7487055431664 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-836a2f05-dbed-41dc-a665-c0ea516ae839">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-836a2f05-dbed-41dc-a665-c0ea516ae839_0">
											<gml:posList>35.668944910665715 139.74870687698004 33.474 35.66894856360104 139.74869742874074 33.474 35.6688813476348 139.74865817573917 33.474 35.66887979707958 139.74865790122524 33.474 35.668876696365274 139.74865791554578 33.474 35.66887367779205 139.74865937681247 33.474 35.66887159764062 139.7486622509828 33.474 35.668850228955094 139.7487176363477 33.474 35.66890076248573 139.74874691029967 33.474 35.66890738454498 139.74872975983288 33.474 35.668905481872514 139.74872865723478 33.474 35.66889973257747 139.74874357547716 33.474 35.66885315768674 139.7487165949283 33.474 35.668873554652365 139.7486637180412 33.474 35.66887611301295 139.74866152822116 33.474 35.668878176775834 139.74866098478523 33.474 35.6688795828551 139.748660894932 33.474 35.66894481506301 139.74869910065297 33.474 35.66894229574559 139.7487055431664 33.474 35.668944910665715 139.74870687698004 33.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86aac9c6-a633-4d2f-9dc5-8eea5b830f36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86aac9c6-a633-4d2f-9dc5-8eea5b830f36_0">
											<gml:posList>35.668891944764326 139.74870516551306 32.977 35.66890356766584 139.74871114020846 32.977 35.6689066710204 139.7487020570742 32.977 35.66889505713992 139.74869609341644 32.977 35.668891944764326 139.74870516551306 32.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2d3086d-30f4-4883-ba7d-c06dfe02a66b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2d3086d-30f4-4883-ba7d-c06dfe02a66b_0">
											<gml:posList>35.66894229574559 139.7487055431664 31.312 35.668944910665715 139.74870687698004 31.312 35.668944910665715 139.74870687698004 33.474 35.66894229574559 139.7487055431664 33.474 35.66894229574559 139.7487055431664 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc83763c-1198-44b6-81c9-01bc72577cbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc83763c-1198-44b6-81c9-01bc72577cbe_0">
											<gml:posList>35.6689066710204 139.7487020570742 31.312 35.6689066710204 139.7487020570742 32.977 35.66890356766584 139.74871114020846 32.977 35.66890356766584 139.74871114020846 31.312 35.6689066710204 139.7487020570742 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4e68be1-9ff5-4010-9ee9-50168792c757">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4e68be1-9ff5-4010-9ee9-50168792c757_0">
											<gml:posList>35.66890356766584 139.74871114020846 31.312 35.66890356766584 139.74871114020846 32.977 35.668891944764326 139.74870516551306 32.977 35.668891944764326 139.74870516551306 31.312 35.66890356766584 139.74871114020846 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0454980-deb8-4c4b-a403-3fdf4b18dec3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0454980-deb8-4c4b-a403-3fdf4b18dec3_0">
											<gml:posList>35.66894047154825 139.7487134982563 37.536 35.668923059831364 139.74870467978417 37.536 35.668923059831364 139.74870467978417 37.742 35.66894047154825 139.7487134982563 37.742 35.66894047154825 139.7487134982563 37.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e78af14-e66e-44c4-a464-04404943b89e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e78af14-e66e-44c4-a464-04404943b89e_0">
											<gml:posList>35.668923059831364 139.74870467978417 37.536 35.66891898508217 139.7487167353352 37.536 35.66891898508217 139.7487167353352 37.742 35.668923059831364 139.74870467978417 37.742 35.668923059831364 139.74870467978417 37.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9dbb9ad1-8bcf-4f74-aab2-320047d57ab4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9dbb9ad1-8bcf-4f74-aab2-320047d57ab4_0">
											<gml:posList>35.66894047154825 139.7487134982563 37.742 35.668923059831364 139.74870467978417 37.742 35.66891898508217 139.7487167353352 37.742 35.66893639680595 139.7487255648556 37.742 35.66894047154825 139.7487134982563 37.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af763cd1-bed2-4cd4-9333-c486baa2e0a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af763cd1-bed2-4cd4-9333-c486baa2e0a3_0">
											<gml:posList>35.66893639680595 139.7487255648556 37.536 35.66894047154825 139.7487134982563 37.536 35.66894047154825 139.7487134982563 37.742 35.66893639680595 139.7487255648556 37.742 35.66893639680595 139.7487255648556 37.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72de73f9-4731-4cac-90ca-e07e05656bb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72de73f9-4731-4cac-90ca-e07e05656bb0_0">
											<gml:posList>35.66893639680595 139.7487255648556 37.536 35.66893639680595 139.7487255648556 37.742 35.66891898508217 139.7487167353352 37.742 35.66891898508217 139.7487167353352 37.536 35.66893639680595 139.7487255648556 37.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56681053-ec94-40aa-82db-9ba5e9fdabea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56681053-ec94-40aa-82db-9ba5e9fdabea_0">
											<gml:posList>35.66890738454498 139.74872975983288 31.312 35.668905481872514 139.74872865723478 31.312 35.668905481872514 139.74872865723478 33.474 35.66890738454498 139.74872975983288 33.474 35.66890738454498 139.74872975983288 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47a39b75-8bef-48a5-b2af-787d0e85dcff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47a39b75-8bef-48a5-b2af-787d0e85dcff_0">
											<gml:posList>35.66885315768674 139.7487165949283 31.312 35.66885315768674 139.7487165949283 33.474 35.66889973257747 139.74874357547716 33.474 35.66889973257747 139.74874357547716 31.312 35.66885315768674 139.7487165949283 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c1936ac-005b-41f5-9f4b-ce9c0dc26095">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c1936ac-005b-41f5-9f4b-ce9c0dc26095_0">
											<gml:posList>35.668850228955094 139.7487176363477 31.312 35.66890076248573 139.74874691029967 31.312 35.66890076248573 139.74874691029967 33.474 35.668850228955094 139.7487176363477 33.474 35.668850228955094 139.7487176363477 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79ffe5ff-b763-4ff8-a7a9-bbabe4f8d128">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79ffe5ff-b763-4ff8-a7a9-bbabe4f8d128_0">
											<gml:posList>35.66889973257747 139.74874357547716 31.312 35.66889973257747 139.74874357547716 33.474 35.668905481872514 139.74872865723478 33.474 35.668905481872514 139.74872865723478 31.312 35.66889973257747 139.74874357547716 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be1e71f3-5249-4648-ada8-279b0af6b99f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be1e71f3-5249-4648-ada8-279b0af6b99f_0">
											<gml:posList>35.66890076248573 139.74874691029967 31.312 35.66890738454498 139.74872975983288 31.312 35.66890738454498 139.74872975983288 33.474 35.66890076248573 139.74874691029967 33.474 35.66890076248573 139.74874691029967 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e59ed363-d7a1-4369-a324-1164a4e2d7d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e59ed363-d7a1-4369-a324-1164a4e2d7d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e59ed363-d7a1-4369-a324-1164a4e2d7d5">
											<gml:posList>35.668952608326485 139.7486939560074 5.49 35.66892796201424 139.74876699648158 5.49 35.668845545434046 139.74872278874892 5.49 35.668866592055025 139.74865803667686 5.49 35.6688684829181 139.7486551627065 5.49 35.66887046453982 139.7486531723244 5.49 35.6688729874512 139.74865184413363 5.49 35.66887578092975 139.74865073657807 5.49 35.66887911593104 139.74865062259536 5.49 35.66888182035986 139.74865106158128 5.49 35.668952608326485 139.7486939560074 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6dc4278d-d258-48c9-a343-289916bcd916">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dc4278d-d258-48c9-a343-289916bcd916">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dc4278d-d258-48c9-a343-289916bcd916">
											<gml:posList>35.66893574771322 139.7487382464188 31.6 35.668938063418445 139.7487370730931 31.6 35.66893642233813 139.74873624636993 31.6 35.66893574771322 139.7487382464188 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c787848-eb1e-4a6e-b5a9-68e191e197a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c787848-eb1e-4a6e-b5a9-68e191e197a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c787848-eb1e-4a6e-b5a9-68e191e197a2">
											<gml:posList>35.668866592055025 139.74865803667686 31.6 35.668845545434046 139.74872278874892 31.6 35.66884781609381 139.7487216486098 31.6 35.668868143185044 139.74865912859795 31.6 35.668866592055025 139.74865803667686 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d021ecd6-e40b-4dcc-949b-05d043f4a073">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d021ecd6-e40b-4dcc-949b-05d043f4a073">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d021ecd6-e40b-4dcc-949b-05d043f4a073">
											<gml:posList>35.6688684829181 139.7486551627065 31.6 35.668866592055025 139.74865803667686 31.6 35.668868143185044 139.74865912859795 31.6 35.66886971890172 139.74865672994065 31.6 35.6688684829181 139.7486551627065 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1cb18675-1e49-464d-924a-a5d82d234f13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cb18675-1e49-464d-924a-a5d82d234f13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cb18675-1e49-464d-924a-a5d82d234f13">
											<gml:posList>35.6688684829181 139.7486551627065 31.6 35.66886971890172 139.74865672994065 31.6 35.668871403287966 139.74865504916187 31.6 35.66887046453982 139.7486531723244 31.6 35.6688684829181 139.7486551627065 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3827cb68-3205-484d-b939-335b0e9bd9d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3827cb68-3205-484d-b939-335b0e9bd9d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3827cb68-3205-484d-b939-335b0e9bd9d5">
											<gml:posList>35.6688729874512 139.74865184413363 31.6 35.66887046453982 139.7486531723244 31.6 35.668871403287966 139.74865504916187 31.6 35.66887363786108 139.74865386487437 31.6 35.6688729874512 139.74865184413363 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81f9f338-4f5f-43e5-a4fe-d01b17631855">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81f9f338-4f5f-43e5-a4fe-d01b17631855">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81f9f338-4f5f-43e5-a4fe-d01b17631855">
											<gml:posList>35.6688729874512 139.74865184413363 31.6 35.66887363786108 139.74865386487437 31.6 35.66887606187783 139.74865290130776 31.6 35.66887578092975 139.74865073657807 31.6 35.6688729874512 139.74865184413363 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f3d9840-ebf7-4f72-a1a9-f4021b598718">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f3d9840-ebf7-4f72-a1a9-f4021b598718">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f3d9840-ebf7-4f72-a1a9-f4021b598718">
											<gml:posList>35.66887911593104 139.74865062259536 31.6 35.66887578092975 139.74865073657807 31.6 35.66887606187783 139.74865290130776 31.6 35.66887904535153 139.74865279874243 31.6 35.66887911593104 139.74865062259536 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9ca8c03-b8d4-4cfb-91c7-9cfdb648868d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9ca8c03-b8d4-4cfb-91c7-9cfdb648868d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9ca8c03-b8d4-4cfb-91c7-9cfdb648868d">
											<gml:posList>35.66887911593104 139.74865062259536 31.6 35.66887904535153 139.74865279874243 31.6 35.66888128101217 139.7486531609011 31.6 35.66888182035986 139.74865106158128 31.6 35.66887911593104 139.74865062259536 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ac053424-6806-43ea-8925-256ef0566f9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac053424-6806-43ea-8925-256ef0566f9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac053424-6806-43ea-8925-256ef0566f9c">
											<gml:posList>35.66892796201424 139.74876699648158 31.6 35.66892701355593 139.74876412550628 31.6 35.66884781609381 139.7487216486098 31.6 35.668845545434046 139.74872278874892 31.6 35.66892796201424 139.74876699648158 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b588ad72-265d-4bcb-9903-c56f292db80b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b588ad72-265d-4bcb-9903-c56f292db80b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b588ad72-265d-4bcb-9903-c56f292db80b">
											<gml:posList>35.66892701355593 139.74876412550628 31.312 35.66893574771322 139.7487382464188 31.312 35.66893642233813 139.74873624636993 31.312 35.66891200445018 139.7487238674093 31.312 35.668921710062705 139.74869511532142 31.312 35.66894611893984 139.7487074942843 31.312 35.66894679356424 139.74870549423494 31.312 35.66895033760492 139.74869500778036 31.312 35.66888128101217 139.7486531609011 31.312 35.66887904535153 139.74865279874243 31.312 35.66887606187783 139.74865290130776 31.312 35.66887363786108 139.74865386487437 31.312 35.668871403287966 139.74865504916187 31.312 35.66886971890172 139.74865672994065 31.312 35.668868143185044 139.74865912859795 31.312 35.66884781609381 139.7487216486098 31.312 35.66892701355593 139.74876412550628 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b9564e7-86c9-4c88-a96d-3d5d2d6bd2bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b9564e7-86c9-4c88-a96d-3d5d2d6bd2bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b9564e7-86c9-4c88-a96d-3d5d2d6bd2bb">
											<gml:posList>35.66888182035986 139.74865106158128 31.6 35.66888128101217 139.7486531609011 31.6 35.66895033760492 139.74869500778036 31.6 35.668952608326485 139.7486939560074 31.6 35.66888182035986 139.74865106158128 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2c99701-7a25-42c1-990c-b468620bbf2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2c99701-7a25-42c1-990c-b468620bbf2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2c99701-7a25-42c1-990c-b468620bbf2e">
											<gml:posList>35.66891200445018 139.7487238674093 37.742 35.66891331998861 139.7487232032576 37.742 35.668922252019875 139.74869672747403 37.742 35.668921710062705 139.74869511532142 37.742 35.66891200445018 139.7487238674093 37.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d66db58-cb53-4060-98fa-40e2b7191222">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d66db58-cb53-4060-98fa-40e2b7191222">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d66db58-cb53-4060-98fa-40e2b7191222">
											<gml:posList>35.668938063418445 139.7487370730931 37.742 35.66893751244809 139.74873546094943 37.742 35.66891331998861 139.7487232032576 37.742 35.66891200445018 139.7487238674093 37.742 35.668938063418445 139.7487370730931 37.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11b0f6a2-3c2c-4934-a64a-6bfbf06b73a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11b0f6a2-3c2c-4934-a64a-6bfbf06b73a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11b0f6a2-3c2c-4934-a64a-6bfbf06b73a4">
											<gml:posList>35.66894643546827 139.74870898516872 37.536 35.668922252019875 139.74869672747403 37.536 35.66891331998861 139.7487232032576 37.536 35.66893751244809 139.74873546094943 37.536 35.66894643546827 139.74870898516872 37.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b9bc08f-be3c-477e-b311-bfc116053e44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b9bc08f-be3c-477e-b311-bfc116053e44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b9bc08f-be3c-477e-b311-bfc116053e44">
											<gml:posList>35.668938063418445 139.7487370730931 31.6 35.66893574771322 139.7487382464188 31.6 35.66892701355593 139.74876412550628 31.6 35.66892796201424 139.74876699648158 31.6 35.668938063418445 139.7487370730931 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24ab0ced-b89c-4fd0-beca-448baa785dec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24ab0ced-b89c-4fd0-beca-448baa785dec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24ab0ced-b89c-4fd0-beca-448baa785dec">
											<gml:posList>35.668921710062705 139.74869511532142 37.742 35.668922252019875 139.74869672747403 37.742 35.66894643546827 139.74870898516872 37.742 35.66894776002035 139.748708321007 37.742 35.668921710062705 139.74869511532142 37.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d951f448-c635-4f71-8a3e-414fb412e5de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d951f448-c635-4f71-8a3e-414fb412e5de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d951f448-c635-4f71-8a3e-414fb412e5de">
											<gml:posList>35.66894776002035 139.748708321007 37.742 35.66894643546827 139.74870898516872 37.742 35.66893751244809 139.74873546094943 37.742 35.668938063418445 139.7487370730931 37.742 35.66894776002035 139.748708321007 37.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eefaff81-76a2-46a6-acbc-9ad8e07f3edc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eefaff81-76a2-46a6-acbc-9ad8e07f3edc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eefaff81-76a2-46a6-acbc-9ad8e07f3edc">
											<gml:posList>35.66894611893984 139.7487074942843 31.6 35.66894776002035 139.748708321007 31.6 35.66894679356424 139.74870549423494 31.6 35.66894611893984 139.7487074942843 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42233a4f-82a6-43fc-b382-dd1906fa1549">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42233a4f-82a6-43fc-b382-dd1906fa1549">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42233a4f-82a6-43fc-b382-dd1906fa1549">
											<gml:posList>35.668952608326485 139.7486939560074 31.6 35.66895033760492 139.74869500778036 31.6 35.66894679356424 139.74870549423494 31.6 35.66894776002035 139.748708321007 31.6 35.668952608326485 139.7486939560074 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d793a887-65ee-47e3-b8f7-cc701b124221">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d793a887-65ee-47e3-b8f7-cc701b124221">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d793a887-65ee-47e3-b8f7-cc701b124221">
											<gml:posList>35.66894679356424 139.74870549423494 31.6 35.66894679356424 139.74870549423494 31.312 35.66894611893984 139.7487074942843 31.312 35.66894611893984 139.7487074942843 31.6 35.66894679356424 139.74870549423494 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b758934-cc85-4700-ba42-2dd0921ef259">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b758934-cc85-4700-ba42-2dd0921ef259">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b758934-cc85-4700-ba42-2dd0921ef259">
											<gml:posList>35.66887911593104 139.74865062259536 5.49 35.66887578092975 139.74865073657807 5.49 35.66887578092975 139.74865073657807 31.6 35.66887911593104 139.74865062259536 31.6 35.66887911593104 139.74865062259536 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc355167-ae9e-4c95-bf66-323cff3c6648">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc355167-ae9e-4c95-bf66-323cff3c6648">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc355167-ae9e-4c95-bf66-323cff3c6648">
											<gml:posList>35.66888182035986 139.74865106158128 5.49 35.66887911593104 139.74865062259536 5.49 35.66887911593104 139.74865062259536 31.6 35.66888182035986 139.74865106158128 31.6 35.66888182035986 139.74865106158128 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a944f768-3c01-4a2e-a1d8-004d3d7910a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a944f768-3c01-4a2e-a1d8-004d3d7910a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a944f768-3c01-4a2e-a1d8-004d3d7910a1">
											<gml:posList>35.66887578092975 139.74865073657807 5.49 35.6688729874512 139.74865184413363 5.49 35.6688729874512 139.74865184413363 31.6 35.66887578092975 139.74865073657807 31.6 35.66887578092975 139.74865073657807 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ec63830-45ed-4c26-ad5e-13996797f332">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ec63830-45ed-4c26-ad5e-13996797f332">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ec63830-45ed-4c26-ad5e-13996797f332">
											<gml:posList>35.6688729874512 139.74865184413363 5.49 35.66887046453982 139.7486531723244 5.49 35.66887046453982 139.7486531723244 31.6 35.6688729874512 139.74865184413363 31.6 35.6688729874512 139.74865184413363 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7cc3cf2-b4b2-4080-b248-42c9f9505f25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7cc3cf2-b4b2-4080-b248-42c9f9505f25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7cc3cf2-b4b2-4080-b248-42c9f9505f25">
											<gml:posList>35.66887606187783 139.74865290130776 31.6 35.66887606187783 139.74865290130776 31.312 35.66887904535153 139.74865279874243 31.312 35.66887904535153 139.74865279874243 31.6 35.66887606187783 139.74865290130776 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e69cadcb-d574-4154-bd59-4240b83812a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e69cadcb-d574-4154-bd59-4240b83812a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e69cadcb-d574-4154-bd59-4240b83812a0">
											<gml:posList>35.66887904535153 139.74865279874243 31.6 35.66887904535153 139.74865279874243 31.312 35.66888128101217 139.7486531609011 31.312 35.66888128101217 139.7486531609011 31.6 35.66887904535153 139.74865279874243 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a3de6de-1a40-4fd5-be42-4c9e00bbe2c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a3de6de-1a40-4fd5-be42-4c9e00bbe2c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a3de6de-1a40-4fd5-be42-4c9e00bbe2c5">
											<gml:posList>35.66887363786108 139.74865386487437 31.6 35.66887363786108 139.74865386487437 31.312 35.66887606187783 139.74865290130776 31.312 35.66887606187783 139.74865290130776 31.6 35.66887363786108 139.74865386487437 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5726b45b-2b67-4703-b115-4fff8ad175ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5726b45b-2b67-4703-b115-4fff8ad175ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5726b45b-2b67-4703-b115-4fff8ad175ce">
											<gml:posList>35.66887046453982 139.7486531723244 5.49 35.6688684829181 139.7486551627065 5.49 35.6688684829181 139.7486551627065 31.6 35.66887046453982 139.7486531723244 31.6 35.66887046453982 139.7486531723244 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28de6194-5402-4f4b-81fe-60b340399062">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28de6194-5402-4f4b-81fe-60b340399062">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28de6194-5402-4f4b-81fe-60b340399062">
											<gml:posList>35.668871403287966 139.74865504916187 31.6 35.668871403287966 139.74865504916187 31.312 35.66887363786108 139.74865386487437 31.312 35.66887363786108 139.74865386487437 31.6 35.668871403287966 139.74865504916187 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d875295-4b17-43e8-908a-579376ce8540">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d875295-4b17-43e8-908a-579376ce8540">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d875295-4b17-43e8-908a-579376ce8540">
											<gml:posList>35.66886971890172 139.74865672994065 31.6 35.66886971890172 139.74865672994065 31.312 35.668871403287966 139.74865504916187 31.312 35.668871403287966 139.74865504916187 31.6 35.66886971890172 139.74865672994065 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-416db246-6938-4ffb-b6f6-926e94792ca8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-416db246-6938-4ffb-b6f6-926e94792ca8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-416db246-6938-4ffb-b6f6-926e94792ca8">
											<gml:posList>35.6688684829181 139.7486551627065 5.49 35.668866592055025 139.74865803667686 5.49 35.668866592055025 139.74865803667686 31.6 35.6688684829181 139.7486551627065 31.6 35.6688684829181 139.7486551627065 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5bd50e8-9eea-45b4-a5be-647157e6e74d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5bd50e8-9eea-45b4-a5be-647157e6e74d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5bd50e8-9eea-45b4-a5be-647157e6e74d">
											<gml:posList>35.668868143185044 139.74865912859795 31.6 35.668868143185044 139.74865912859795 31.312 35.66886971890172 139.74865672994065 31.312 35.66886971890172 139.74865672994065 31.6 35.668868143185044 139.74865912859795 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-345bd717-0db0-494c-acfb-64520932d675">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-345bd717-0db0-494c-acfb-64520932d675">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-345bd717-0db0-494c-acfb-64520932d675">
											<gml:posList>35.668952608326485 139.7486939560074 5.49 35.66888182035986 139.74865106158128 5.49 35.66888182035986 139.74865106158128 31.6 35.668952608326485 139.7486939560074 31.6 35.668952608326485 139.7486939560074 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f836883-a3de-4a22-a423-2cc5ea8b7d7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f836883-a3de-4a22-a423-2cc5ea8b7d7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f836883-a3de-4a22-a423-2cc5ea8b7d7e">
											<gml:posList>35.66888128101217 139.7486531609011 31.6 35.66888128101217 139.7486531609011 31.312 35.66895033760492 139.74869500778036 31.312 35.66895033760492 139.74869500778036 31.6 35.66888128101217 139.7486531609011 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30a4e1ca-43e6-4e76-94ab-d2f984592aba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30a4e1ca-43e6-4e76-94ab-d2f984592aba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30a4e1ca-43e6-4e76-94ab-d2f984592aba">
											<gml:posList>35.66884781609381 139.7487216486098 31.6 35.66884781609381 139.7487216486098 31.312 35.668868143185044 139.74865912859795 31.312 35.668868143185044 139.74865912859795 31.6 35.66884781609381 139.7487216486098 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8837e48-da46-45ff-a593-d296edeb31f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8837e48-da46-45ff-a593-d296edeb31f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8837e48-da46-45ff-a593-d296edeb31f9">
											<gml:posList>35.668866592055025 139.74865803667686 5.49 35.668845545434046 139.74872278874892 5.49 35.668845545434046 139.74872278874892 31.6 35.668866592055025 139.74865803667686 31.6 35.668866592055025 139.74865803667686 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90547f43-d210-4dcd-8346-9f2022444af6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90547f43-d210-4dcd-8346-9f2022444af6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90547f43-d210-4dcd-8346-9f2022444af6">
											<gml:posList>35.66895033760492 139.74869500778036 31.6 35.66895033760492 139.74869500778036 31.312 35.66894679356424 139.74870549423494 31.312 35.66894679356424 139.74870549423494 31.6 35.66895033760492 139.74869500778036 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b739cd14-95ac-40d2-934e-7bb410e32caf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b739cd14-95ac-40d2-934e-7bb410e32caf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b739cd14-95ac-40d2-934e-7bb410e32caf">
											<gml:posList>35.668921710062705 139.74869511532142 31.312 35.668921710062705 139.74869511532142 37.742 35.66894776002035 139.748708321007 37.742 35.66894776002035 139.748708321007 31.6 35.66894611893984 139.7487074942843 31.6 35.66894611893984 139.7487074942843 31.312 35.668921710062705 139.74869511532142 31.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d037bf89-4b3e-4be2-899a-c2870dc5728d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d037bf89-4b3e-4be2-899a-c2870dc5728d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d037bf89-4b3e-4be2-899a-c2870dc5728d">
											<gml:posList>35.668922252019875 139.74869672747403 37.742 35.668922252019875 139.74869672747403 37.536 35.66894643546827 139.74870898516872 37.536 35.66894643546827 139.74870898516872 37.742 35.668922252019875 139.74869672747403 37.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3aa118e4-12f8-4342-be24-7581460fb270">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3aa118e4-12f8-4342-be24-7581460fb270">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3aa118e4-12f8-4342-be24-7581460fb270">
											<gml:posList>35.66891200445018 139.7487238674093 37.742 35.668921710062705 139.74869511532142 37.742 35.668921710062705 139.74869511532142 31.312 35.66891200445018 139.7487238674093 31.312 35.66891200445018 139.7487238674093 37.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e88e27c1-6e1b-424b-8efa-22a978eaf1d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e88e27c1-6e1b-424b-8efa-22a978eaf1d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e88e27c1-6e1b-424b-8efa-22a978eaf1d5">
											<gml:posList>35.66891331998861 139.7487232032576 37.742 35.66891331998861 139.7487232032576 37.536 35.668922252019875 139.74869672747403 37.536 35.668922252019875 139.74869672747403 37.742 35.66891331998861 139.7487232032576 37.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb5679d0-73cd-40e5-a255-5b6de26cfb0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb5679d0-73cd-40e5-a255-5b6de26cfb0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb5679d0-73cd-40e5-a255-5b6de26cfb0f">
											<gml:posList>35.66894643546827 139.74870898516872 37.742 35.66894643546827 139.74870898516872 37.536 35.66893751244809 139.74873546094943 37.536 35.66893751244809 139.74873546094943 37.742 35.66894643546827 139.74870898516872 37.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e293a9f-5c2e-4987-a142-6aa47a39aec3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e293a9f-5c2e-4987-a142-6aa47a39aec3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e293a9f-5c2e-4987-a142-6aa47a39aec3">
											<gml:posList>35.66893751244809 139.74873546094943 37.742 35.66893751244809 139.74873546094943 37.536 35.66891331998861 139.7487232032576 37.536 35.66891331998861 139.7487232032576 37.742 35.66893751244809 139.74873546094943 37.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7bcd896-bea6-476e-818c-ff40828d8435">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7bcd896-bea6-476e-818c-ff40828d8435">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7bcd896-bea6-476e-818c-ff40828d8435">
											<gml:posList>35.668938063418445 139.7487370730931 37.742 35.66891200445018 139.7487238674093 37.742 35.66891200445018 139.7487238674093 31.312 35.66893642233813 139.74873624636993 31.312 35.66893642233813 139.74873624636993 31.6 35.668938063418445 139.7487370730931 31.6 35.668938063418445 139.7487370730931 37.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-304a182d-a0cd-44f3-919f-fe2cd350e423">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-304a182d-a0cd-44f3-919f-fe2cd350e423">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-304a182d-a0cd-44f3-919f-fe2cd350e423">
											<gml:posList>35.66894776002035 139.748708321007 31.6 35.66894776002035 139.748708321007 37.742 35.668938063418445 139.7487370730931 37.742 35.668938063418445 139.7487370730931 31.6 35.66892796201424 139.74876699648158 31.6 35.66892796201424 139.74876699648158 5.49 35.668952608326485 139.7486939560074 5.49 35.668952608326485 139.7486939560074 31.6 35.66894776002035 139.748708321007 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e10cb53-5e0c-4839-8a4a-e6dccf8c488b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e10cb53-5e0c-4839-8a4a-e6dccf8c488b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e10cb53-5e0c-4839-8a4a-e6dccf8c488b">
											<gml:posList>35.66893642233813 139.74873624636993 31.6 35.66893642233813 139.74873624636993 31.312 35.66893574771322 139.7487382464188 31.312 35.66893574771322 139.7487382464188 31.6 35.66893642233813 139.74873624636993 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb53cb58-f624-4096-a9ef-b3aeaf6e0913">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb53cb58-f624-4096-a9ef-b3aeaf6e0913">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb53cb58-f624-4096-a9ef-b3aeaf6e0913">
											<gml:posList>35.66892701355593 139.74876412550628 31.6 35.66892701355593 139.74876412550628 31.312 35.66884781609381 139.7487216486098 31.312 35.66884781609381 139.7487216486098 31.6 35.66892701355593 139.74876412550628 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aeea27c0-e3f3-443c-893a-6e5dcd8e0b14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aeea27c0-e3f3-443c-893a-6e5dcd8e0b14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aeea27c0-e3f3-443c-893a-6e5dcd8e0b14">
											<gml:posList>35.668845545434046 139.74872278874892 5.49 35.66892796201424 139.74876699648158 5.49 35.66892796201424 139.74876699648158 31.6 35.668845545434046 139.74872278874892 31.6 35.668845545434046 139.74872278874892 5.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be1d92a0-3cc0-4a41-aba7-267eba70b629">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be1d92a0-3cc0-4a41-aba7-267eba70b629">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be1d92a0-3cc0-4a41-aba7-267eba70b629">
											<gml:posList>35.66893574771322 139.7487382464188 31.6 35.66893574771322 139.7487382464188 31.312 35.66892701355593 139.74876412550628 31.312 35.66892701355593 139.74876412550628 31.6 35.66893574771322 139.7487382464188 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9401</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">73.5697</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.12</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>