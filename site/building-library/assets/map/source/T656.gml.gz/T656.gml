<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_bfb94a70-93b7-4ef8-84ff-f9057fa4dd81">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">15.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67068113736332 139.7379181214452 0 35.67052622852978 139.73796506469597 0 35.67053531398429 139.7380101116675 0 35.670690186789066 139.73796317958752 0 35.67068113736332 139.7379181214452 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068113736332 139.7379181214452 16.52 35.670690186789066 139.73796317958752 16.52 35.67053531398429 139.7380101116675 16.52 35.67052622852978 139.73796506469597 16.52 35.67068113736332 139.7379181214452 16.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068113736332 139.7379181214452 16.52 35.67052622852978 139.73796506469597 16.52 35.67052622852978 139.73796506469597 31.99 35.67068113736332 139.7379181214452 31.99 35.67068113736332 139.7379181214452 16.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052622852978 139.73796506469597 16.52 35.67053531398429 139.7380101116675 16.52 35.67053531398429 139.7380101116675 31.99 35.67052622852978 139.73796506469597 31.99 35.67052622852978 139.73796506469597 16.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67053531398429 139.7380101116675 16.52 35.670690186789066 139.73796317958752 16.52 35.670690186789066 139.73796317958752 31.99 35.67053531398429 139.7380101116675 31.99 35.67053531398429 139.7380101116675 16.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670690186789066 139.73796317958752 16.52 35.67068113736332 139.7379181214452 16.52 35.67068113736332 139.7379181214452 31.99 35.670690186789066 139.73796317958752 31.99 35.670690186789066 139.73796317958752 16.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068113736332 139.7379181214452 31.99 35.67052622852978 139.73796506469597 31.99 35.67053531398429 139.7380101116675 31.99 35.670690186789066 139.73796317958752 31.99 35.67068113736332 139.7379181214452 31.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-32baa493-bd5a-4a62-afc0-c9b1b9155e8d"/>
							<gml:surfaceMember xlink:href="#poly-70bea875-3e5b-4979-af2d-523254581458"/>
							<gml:surfaceMember xlink:href="#poly-9bea7c6c-01de-4fd4-a378-f95a14ba1657"/>
							<gml:surfaceMember xlink:href="#poly-c2ccb09a-c6e6-4638-a99d-bd9ecd692bf1"/>
							<gml:surfaceMember xlink:href="#poly-4eef021c-f046-482d-ba18-cd8523f690a4"/>
							<gml:surfaceMember xlink:href="#poly-a0b10853-d073-476c-abf0-c12dba4efe51"/>
							<gml:surfaceMember xlink:href="#poly-6d12f12f-3ddc-48e2-b925-9261a5c5d289"/>
							<gml:surfaceMember xlink:href="#poly-ce4fae3a-7111-4cc1-9f60-8b44a1312b2b"/>
							<gml:surfaceMember xlink:href="#poly-a1369414-69b0-4e20-a957-1787dbd1294c"/>
							<gml:surfaceMember xlink:href="#poly-540cf72b-3671-406c-8b77-2397fb3d8789"/>
							<gml:surfaceMember xlink:href="#poly-279f8804-ee54-4eb2-bc76-471f9aa0c6fd"/>
							<gml:surfaceMember xlink:href="#poly-cb563860-2a5a-4316-be52-bd03e016a913"/>
							<gml:surfaceMember xlink:href="#poly-88115669-b611-492f-9bf9-a0bcd6ce5a41"/>
							<gml:surfaceMember xlink:href="#poly-a6493163-1534-4181-874e-5472d399bc14"/>
							<gml:surfaceMember xlink:href="#poly-e79fe1d7-fab6-49be-8f40-595bf8a9c67b"/>
							<gml:surfaceMember xlink:href="#poly-152a31a1-41aa-4ba3-9204-c20787db22db"/>
							<gml:surfaceMember xlink:href="#poly-c488a21d-02b7-4064-99cb-2e0e6e3d6b6a"/>
							<gml:surfaceMember xlink:href="#poly-b4989e78-e15e-473c-9baa-a0ef8c488b47"/>
							<gml:surfaceMember xlink:href="#poly-3d553f7c-3090-4fff-a7bc-451101ed80bb"/>
							<gml:surfaceMember xlink:href="#poly-081e811d-1a87-4c3d-8e1d-7d0443327a49"/>
							<gml:surfaceMember xlink:href="#poly-378d40a2-497c-4644-b6e0-4b5c6d472593"/>
							<gml:surfaceMember xlink:href="#poly-16ed003f-b9b6-4ee8-9ca0-c6fc464b60af"/>
							<gml:surfaceMember xlink:href="#poly-f8b81b6c-1ace-474e-a550-854129acf5d7"/>
							<gml:surfaceMember xlink:href="#poly-c911c958-69e0-4031-94b8-9a91319a0b72"/>
							<gml:surfaceMember xlink:href="#poly-4d6c79a9-3ca5-4c4f-a873-d048b6e5e658"/>
							<gml:surfaceMember xlink:href="#poly-b7f7c9b4-3c4f-451c-b39e-bd71b979b930"/>
							<gml:surfaceMember xlink:href="#poly-47845075-7157-419a-9f52-39d1c87a3dc3"/>
							<gml:surfaceMember xlink:href="#poly-e6b595a9-c4b4-4156-b9c2-566eedcbecf5"/>
							<gml:surfaceMember xlink:href="#poly-5557a663-64dd-4690-9fed-9205f514249c"/>
							<gml:surfaceMember xlink:href="#poly-69bf6788-dcfc-4507-abb0-4521461ea8f3"/>
							<gml:surfaceMember xlink:href="#poly-4ffa5645-f09f-4e84-95bf-98659b134c80"/>
							<gml:surfaceMember xlink:href="#poly-ae8325e6-06c7-4ad9-880d-3443d4af5842"/>
							<gml:surfaceMember xlink:href="#poly-6b4d7133-076e-4d76-abae-fb53826e5b24"/>
							<gml:surfaceMember xlink:href="#poly-fc2006d8-90e1-445a-8bf9-9a3822e2e787"/>
							<gml:surfaceMember xlink:href="#poly-293dae2a-c300-48cd-8904-e01a6d3000b0"/>
							<gml:surfaceMember xlink:href="#poly-fb300093-b653-4279-9324-a651dd258066"/>
							<gml:surfaceMember xlink:href="#poly-64aa0ac5-5d77-4de7-a481-93f709f4444a"/>
							<gml:surfaceMember xlink:href="#poly-58290a73-4b3d-4bd8-9713-5af91ebcd15b"/>
							<gml:surfaceMember xlink:href="#poly-68e7ac6e-4783-472e-bd07-9b30059db97c"/>
							<gml:surfaceMember xlink:href="#poly-e46d3dc3-8ea6-4110-b59b-2150f3c5a667"/>
							<gml:surfaceMember xlink:href="#poly-e7728a86-c087-44ee-82d0-11df1948578e"/>
							<gml:surfaceMember xlink:href="#poly-9f653f85-4738-42c2-b0fe-d676addb0575"/>
							<gml:surfaceMember xlink:href="#poly-a1661a0d-55cc-424d-b044-e33e9a44f5a2"/>
							<gml:surfaceMember xlink:href="#poly-1b39cab4-4b8d-49ad-98b5-4289e6b92c5e"/>
							<gml:surfaceMember xlink:href="#poly-25b1af8b-70f0-451a-8cb6-7741d7b7d69d"/>
							<gml:surfaceMember xlink:href="#poly-ad893f75-eb4a-4f62-98e8-59bcddf3b39d"/>
							<gml:surfaceMember xlink:href="#poly-b2f8fa4e-d744-48f3-8566-335e762aa2f5"/>
							<gml:surfaceMember xlink:href="#poly-8d536d73-d887-4bf1-95a2-01c800a48e1b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bfb94a70-93b7-4ef8-84ff-f9057fa4dd81_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee4e06fa-dcad-494a-a3f5-0d7db7aea688">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670587813335636 139.73798023531972 32.691 35.670584753759215 139.7379639014994 32.691 35.67059906437341 139.73795987467406 32.691 35.67060212395038 139.73797620849717 32.691 35.670587813335636 139.73798023531972 32.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7487cd60-4cf3-4eaa-b4bf-3c62e3908dc4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670561046014754 139.73799598601593 37.54 35.670542653407644 139.73800156416596 37.54 35.670540382042624 139.73799029965974 37.54 35.67055877465797 139.73798473255357 37.54 35.670561046014754 139.73799598601593 37.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8eedd67a-e5e3-4936-a85e-643f44861098">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8eedd67a-e5e3-4936-a85e-643f44861098_0">
											<gml:posList>35.670584753759215 139.7379639014994 32.691 35.670584753759215 139.7379639014994 35.241 35.67059906437341 139.73795987467406 35.241 35.67059906437341 139.73795987467406 32.691 35.670584753759215 139.7379639014994 32.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7823adc-4714-4fcb-83f6-e7aaf99fce68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7823adc-4714-4fcb-83f6-e7aaf99fce68_0">
											<gml:posList>35.67059906437341 139.73795987467406 32.691 35.67059906437341 139.73795987467406 35.241 35.67060212395038 139.73797620849717 35.241 35.67060212395038 139.73797620849717 32.691 35.67059906437341 139.73795987467406 32.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4587fa86-b4b5-4e12-a32c-1876b4f088b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4587fa86-b4b5-4e12-a32c-1876b4f088b7_0">
											<gml:posList>35.670587813335636 139.73798023531972 35.241 35.67060212395038 139.73797620849717 35.241 35.67059906437341 139.73795987467406 35.241 35.670584753759215 139.7379639014994 35.241 35.670587813335636 139.73798023531972 35.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d943c2b0-4078-408b-b96a-9c01e2cd84b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d943c2b0-4078-408b-b96a-9c01e2cd84b7_0">
											<gml:posList>35.670584753759215 139.7379639014994 32.691 35.670587813335636 139.73798023531972 32.691 35.670587813335636 139.73798023531972 35.241 35.670584753759215 139.7379639014994 35.241 35.670584753759215 139.7379639014994 32.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-063ba8e6-ddd5-4bb6-8699-c27eb556e554">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-063ba8e6-ddd5-4bb6-8699-c27eb556e554_0">
											<gml:posList>35.670587813335636 139.73798023531972 32.691 35.67060212395038 139.73797620849717 32.691 35.67060212395038 139.73797620849717 35.241 35.670587813335636 139.73798023531972 35.241 35.670587813335636 139.73798023531972 32.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0c65ee8-fcea-470f-8df8-40fb5523ddea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0c65ee8-fcea-470f-8df8-40fb5523ddea_0">
											<gml:posList>35.670540382042624 139.73799029965974 37.54 35.670540382042624 139.73799029965974 38.439 35.67055877465797 139.73798473255357 38.439 35.67055877465797 139.73798473255357 37.54 35.670540382042624 139.73799029965974 37.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89bbe8dd-9095-4a68-9d83-e7ec973d0267">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89bbe8dd-9095-4a68-9d83-e7ec973d0267_0">
											<gml:posList>35.670561046014754 139.73799598601593 37.54 35.67055877465797 139.73798473255357 37.54 35.67055877465797 139.73798473255357 38.439 35.670561046014754 139.73799598601593 38.439 35.670561046014754 139.73799598601593 37.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46acdb02-27af-4f65-af12-50849d184309">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46acdb02-27af-4f65-af12-50849d184309_0">
											<gml:posList>35.670561046014754 139.73799598601593 38.439 35.67055877465797 139.73798473255357 38.439 35.670540382042624 139.73799029965974 38.439 35.670542653407644 139.73800156416596 38.439 35.670561046014754 139.73799598601593 38.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f523d3ea-b677-4eb2-93f9-5ad826a312a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f523d3ea-b677-4eb2-93f9-5ad826a312a3_0">
											<gml:posList>35.670540382042624 139.73799029965974 37.54 35.670542653407644 139.73800156416596 37.54 35.670542653407644 139.73800156416596 38.439 35.670540382042624 139.73799029965974 38.439 35.670540382042624 139.73799029965974 37.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9951393a-c993-4bec-b403-be103974586b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9951393a-c993-4bec-b403-be103974586b_0">
											<gml:posList>35.670542653407644 139.73800156416596 37.54 35.670561046014754 139.73799598601593 37.54 35.670561046014754 139.73799598601593 38.439 35.670542653407644 139.73800156416596 38.439 35.670542653407644 139.73800156416596 37.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bfb94a70-93b7-4ef8-84ff-f9057fa4dd81_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ed4c151-37e3-40df-8908-4e47492be5f5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057540291389 139.7379707281806 32.691 35.6705799637352 139.73799333450486 32.691 35.67056919491777 139.73799660596444 32.691 35.67056463408832 139.73797398859676 32.691 35.67057540291389 139.7379707281806 32.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4969181-efeb-4b6d-9c7f-a158b73b0e4d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67053531398425 139.7380101116675 16.67 35.670517074565936 139.73801563439898 16.67 35.67050802515966 139.7379705763479 16.67 35.67052622852979 139.73796506469597 16.67 35.67053531398425 139.7380101116675 16.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc9c134a-a665-4dff-b3e0-a69ed87c5558">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705799637352 139.73799333450486 33.102 35.67058058810466 139.73799639358387 33.102 35.67056981026467 139.7379996540075 33.102 35.67056919491777 139.73799660596444 33.102 35.6705799637352 139.73799333450486 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05f3542a-7cdf-47e9-bb23-b610b1b7ca7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05f3542a-7cdf-47e9-bb23-b610b1b7ca7a_0">
											<gml:posList>35.67050802515966 139.7379705763479 16.67 35.670517074565936 139.73801563439898 16.67 35.670517074565936 139.73801563439898 31.391 35.67050802515966 139.7379705763479 33.102 35.67050802515966 139.7379705763479 16.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e02d16b-4fdd-48a0-ba85-fe571a790a1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e02d16b-4fdd-48a0-ba85-fe571a790a1f_0">
											<gml:posList>35.67052622852979 139.73796506469597 16.67 35.67050802515966 139.7379705763479 16.67 35.67050802515966 139.7379705763479 33.102 35.67052622852979 139.73796506469597 33.102 35.67052622852979 139.73796506469597 16.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-667e263e-f580-4b22-990f-ffd71308cac4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-667e263e-f580-4b22-990f-ffd71308cac4_0">
											<gml:posList>35.67050802515966 139.7379705763479 33.102 35.670517074565936 139.73801563439898 31.391 35.67053531398425 139.7380101116675 31.391 35.67052622852979 139.73796506469597 33.102 35.67050802515966 139.7379705763479 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcb3a654-b581-477b-91df-ce8f2a304f4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcb3a654-b581-477b-91df-ce8f2a304f4e_0">
											<gml:posList>35.670517074565936 139.73801563439898 16.67 35.67053531398425 139.7380101116675 16.67 35.67053531398425 139.7380101116675 31.391 35.670517074565936 139.73801563439898 31.391 35.670517074565936 139.73801563439898 16.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49b22762-3f94-4229-94fb-29386e2c3a51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49b22762-3f94-4229-94fb-29386e2c3a51_0">
											<gml:posList>35.67053531398425 139.7380101116675 16.67 35.67052622852979 139.73796506469597 16.67 35.67052622852979 139.73796506469597 33.102 35.67053531398425 139.7380101116675 31.391 35.67053531398425 139.7380101116675 16.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0dad55d-efd6-4cd4-9519-4260e44655de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0dad55d-efd6-4cd4-9519-4260e44655de_0">
											<gml:posList>35.67056981026467 139.7379996540075 33.713 35.67056463408832 139.73797398859676 33.713 35.67056463408832 139.73797398859676 32.691 35.67056919491777 139.73799660596444 32.691 35.67056919491777 139.73799660596444 33.102 35.67056981026467 139.7379996540075 33.102 35.67056981026467 139.7379996540075 33.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96ba2feb-ee07-42f6-be5a-e9b6f6920724">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96ba2feb-ee07-42f6-be5a-e9b6f6920724_0">
											<gml:posList>35.67056463408832 139.73797398859676 32.691 35.67056463408832 139.73797398859676 33.713 35.67057540291389 139.7379707281806 33.713 35.67057540291389 139.7379707281806 32.691 35.67056463408832 139.73797398859676 32.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65aec475-5c63-4da8-afb5-5332f4fb2d49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65aec475-5c63-4da8-afb5-5332f4fb2d49_0">
											<gml:posList>35.67056981026467 139.7379996540075 33.713 35.67058058810466 139.73799639358387 33.713 35.67057540291389 139.7379707281806 33.713 35.67056463408832 139.73797398859676 33.713 35.67056981026467 139.7379996540075 33.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6779e074-674b-4a4b-b942-64fa3dd09e94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6779e074-674b-4a4b-b942-64fa3dd09e94_0">
											<gml:posList>35.6705799637352 139.73799333450486 32.691 35.6705799637352 139.73799333450486 33.102 35.67056919491777 139.73799660596444 33.102 35.67056919491777 139.73799660596444 32.691 35.6705799637352 139.73799333450486 32.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2121f2fe-53f5-4eeb-bbf3-2c86fdf13d3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2121f2fe-53f5-4eeb-bbf3-2c86fdf13d3c_0">
											<gml:posList>35.67058058810466 139.73799639358387 33.102 35.67058058810466 139.73799639358387 33.713 35.67056981026467 139.7379996540075 33.713 35.67056981026467 139.7379996540075 33.102 35.67058058810466 139.73799639358387 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9e4f1e8-5c97-403a-b515-1134e4d82625">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9e4f1e8-5c97-403a-b515-1134e4d82625_0">
											<gml:posList>35.67058058810466 139.73799639358387 33.102 35.6705799637352 139.73799333450486 33.102 35.6705799637352 139.73799333450486 32.691 35.67057540291389 139.7379707281806 32.691 35.67057540291389 139.7379707281806 33.713 35.67058058810466 139.73799639358387 33.713 35.67058058810466 139.73799639358387 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-32baa493-bd5a-4a62-afc0-c9b1b9155e8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32baa493-bd5a-4a62-afc0-c9b1b9155e8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32baa493-bd5a-4a62-afc0-c9b1b9155e8d">
											<gml:posList>35.670681137363275 139.73791812144518 16.52 35.67069018678906 139.73796317958752 16.52 35.67053531398425 139.7380101116675 16.52 35.67052622852979 139.73796506469597 16.52 35.670681137363275 139.73791812144518 16.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70bea875-3e5b-4979-af2d-523254581458">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70bea875-3e5b-4979-af2d-523254581458">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70bea875-3e5b-4979-af2d-523254581458">
											<gml:posList>35.67052622852979 139.73796506469597 33.102 35.670529322047344 139.73796734759625 33.102 35.67064391313621 139.7379326253451 33.102 35.6706457849884 139.73792883423837 33.102 35.67052622852979 139.73796506469597 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9bea7c6c-01de-4fd4-a378-f95a14ba1657">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bea7c6c-01de-4fd4-a378-f95a14ba1657">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bea7c6c-01de-4fd4-a378-f95a14ba1657">
											<gml:posList>35.67056493272211 139.73797547949002 32.691 35.67056919491777 139.73799660596444 32.691 35.670651776930214 139.7379715873226 32.691 35.67064391313621 139.7379326253451 32.691 35.670529322047344 139.73796734759625 32.691 35.670532923636216 139.73798518305492 32.691 35.67056493272211 139.73797547949002 32.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2ccb09a-c6e6-4638-a99d-bd9ecd692bf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2ccb09a-c6e6-4638-a99d-bd9ecd692bf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2ccb09a-c6e6-4638-a99d-bd9ecd692bf1">
											<gml:posList>35.67053044545751 139.73798593714903 33.102 35.670532923636216 139.73798518305492 33.102 35.670529322047344 139.73796734759625 33.102 35.67052622852979 139.73796506469597 33.102 35.67053044545751 139.73798593714903 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4eef021c-f046-482d-ba18-cd8523f690a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4eef021c-f046-482d-ba18-cd8523f690a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4eef021c-f046-482d-ba18-cd8523f690a4">
											<gml:posList>35.67053044545751 139.73798593714903 37.844 35.67053277235348 139.73798764655533 37.844 35.670563537843385 139.73797832004408 37.844 35.67056493272211 139.73797547949002 37.844 35.67053044545751 139.73798593714903 37.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a0b10853-d073-476c-abf0-c12dba4efe51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0b10853-d073-476c-abf0-c12dba4efe51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0b10853-d073-476c-abf0-c12dba4efe51">
											<gml:posList>35.67056981026467 139.7379996540075 33.102 35.670654879470064 139.7379738812622 33.102 35.670651776930214 139.7379715873226 33.102 35.67056919491777 139.73799660596444 33.102 35.67056981026467 139.7379996540075 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d12f12f-3ddc-48e2-b925-9261a5c5d289">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d12f12f-3ddc-48e2-b925-9261a5c5d289">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d12f12f-3ddc-48e2-b925-9261a5c5d289">
											<gml:posList>35.67056493272211 139.73797547949002 37.844 35.670563537843385 139.73797832004408 37.844 35.6705674923826 139.73799794458938 37.844 35.67056981026467 139.7379996540075 37.844 35.67056493272211 139.73797547949002 37.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce4fae3a-7111-4cc1-9f60-8b44a1312b2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce4fae3a-7111-4cc1-9f60-8b44a1312b2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce4fae3a-7111-4cc1-9f60-8b44a1312b2b">
											<gml:posList>35.6705674923826 139.73799794458938 37.54 35.670563537843385 139.73797832004408 37.54 35.67053277235348 139.73798764655533 37.54 35.67053671787746 139.73800727110427 37.54 35.6705674923826 139.73799794458938 37.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a1369414-69b0-4e20-a957-1787dbd1294c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1369414-69b0-4e20-a957-1787dbd1294c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1369414-69b0-4e20-a957-1787dbd1294c">
											<gml:posList>35.67053531398425 139.7380101116675 37.844 35.67053671787746 139.73800727110427 37.844 35.67053277235348 139.73798764655533 37.844 35.67053044545751 139.73798593714903 37.844 35.67053531398425 139.7380101116675 37.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-540cf72b-3671-406c-8b77-2397fb3d8789">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-540cf72b-3671-406c-8b77-2397fb3d8789">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-540cf72b-3671-406c-8b77-2397fb3d8789">
											<gml:posList>35.67056981026467 139.7379996540075 37.844 35.6705674923826 139.73799794458938 37.844 35.67053671787746 139.73800727110427 37.844 35.67053531398425 139.7380101116675 37.844 35.67056981026467 139.7379996540075 37.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-279f8804-ee54-4eb2-bc76-471f9aa0c6fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-279f8804-ee54-4eb2-bc76-471f9aa0c6fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-279f8804-ee54-4eb2-bc76-471f9aa0c6fd">
											<gml:posList>35.670663754051915 139.73792338912406 27.122 35.67066445988798 139.7379268789144 27.122 35.670678986532465 139.73792247624715 27.122 35.670681137363275 139.73791812144518 27.122 35.670663754051915 139.73792338912406 27.122</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb563860-2a5a-4316-be52-bd03e016a913">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb563860-2a5a-4316-be52-bd03e016a913">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb563860-2a5a-4316-be52-bd03e016a913">
											<gml:posList>35.6706457849884 139.73792883423837 30.17 35.67064629175227 139.73793135219083 30.17 35.67066220616875 139.7379265170684 30.17 35.670663754051915 139.73792338912406 30.17 35.6706457849884 139.73792883423837 30.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88115669-b611-492f-9bf9-a0bcd6ce5a41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88115669-b611-492f-9bf9-a0bcd6ce5a41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88115669-b611-492f-9bf9-a0bcd6ce5a41">
											<gml:posList>35.670681137363275 139.73791812144518 27.122 35.670678986532465 139.73792247624715 27.122 35.67068663329172 139.7379605437484 27.122 35.67069018678906 139.73796317958752 27.122 35.670681137363275 139.73791812144518 27.122</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6493163-1534-4181-874e-5472d399bc14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6493163-1534-4181-874e-5472d399bc14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6493163-1534-4181-874e-5472d399bc14">
											<gml:posList>35.67068663329172 139.7379605437484 26.778 35.670678986532465 139.73792247624715 26.778 35.67066445988798 139.7379268789144 26.778 35.67067213367828 139.7379649353307 26.778 35.67068663329172 139.7379605437484 26.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e79fe1d7-fab6-49be-8f40-595bf8a9c67b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e79fe1d7-fab6-49be-8f40-595bf8a9c67b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e79fe1d7-fab6-49be-8f40-595bf8a9c67b">
											<gml:posList>35.670663754051915 139.73792338912406 30.17 35.67066220616875 139.7379265170684 30.17 35.67067027812894 139.73796655029753 30.17 35.67067283952188 139.73796843616807 30.17 35.670663754051915 139.73792338912406 30.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-152a31a1-41aa-4ba3-9204-c20787db22db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-152a31a1-41aa-4ba3-9204-c20787db22db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-152a31a1-41aa-4ba3-9204-c20787db22db">
											<gml:posList>35.67067027812894 139.73796655029753 29.914 35.67066220616875 139.7379265170684 29.914 35.67064629175227 139.73793135219083 29.914 35.670654372707084 139.7379713633092 29.914 35.67067027812894 139.73796655029753 29.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c488a21d-02b7-4064-99cb-2e0e6e3d6b6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c488a21d-02b7-4064-99cb-2e0e6e3d6b6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c488a21d-02b7-4064-99cb-2e0e6e3d6b6a">
											<gml:posList>35.6706457849884 139.73792883423837 33.102 35.67064391313621 139.7379326253451 33.102 35.670651776930214 139.7379715873226 33.102 35.670654879470064 139.7379738812622 33.102 35.6706457849884 139.73792883423837 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4989e78-e15e-473c-9baa-a0ef8c488b47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4989e78-e15e-473c-9baa-a0ef8c488b47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4989e78-e15e-473c-9baa-a0ef8c488b47">
											<gml:posList>35.67067283952188 139.73796843616807 27.122 35.67069018678906 139.73796317958752 27.122 35.67068663329172 139.7379605437484 27.122 35.67067213367828 139.7379649353307 27.122 35.67067283952188 139.73796843616807 27.122</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d553f7c-3090-4fff-a7bc-451101ed80bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d553f7c-3090-4fff-a7bc-451101ed80bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d553f7c-3090-4fff-a7bc-451101ed80bb">
											<gml:posList>35.670654879470064 139.7379738812622 30.17 35.67067283952188 139.73796843616807 30.17 35.67067027812894 139.73796655029753 30.17 35.670654372707084 139.7379713633092 30.17 35.670654879470064 139.7379738812622 30.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-081e811d-1a87-4c3d-8e1d-7d0443327a49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-081e811d-1a87-4c3d-8e1d-7d0443327a49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-081e811d-1a87-4c3d-8e1d-7d0443327a49">
											<gml:posList>35.67068663329172 139.7379605437484 27.122 35.67068663329172 139.7379605437484 26.778 35.67067213367828 139.7379649353307 26.778 35.67067213367828 139.7379649353307 27.122 35.67068663329172 139.7379605437484 27.122</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-378d40a2-497c-4644-b6e0-4b5c6d472593">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-378d40a2-497c-4644-b6e0-4b5c6d472593">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-378d40a2-497c-4644-b6e0-4b5c6d472593">
											<gml:posList>35.67067027812894 139.73796655029753 30.17 35.67067027812894 139.73796655029753 29.914 35.670654372707084 139.7379713633092 29.914 35.670654372707084 139.7379713633092 30.17 35.67067027812894 139.73796655029753 30.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16ed003f-b9b6-4ee8-9ca0-c6fc464b60af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16ed003f-b9b6-4ee8-9ca0-c6fc464b60af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16ed003f-b9b6-4ee8-9ca0-c6fc464b60af">
											<gml:posList>35.67052622852979 139.73796506469597 16.52 35.67053531398425 139.7380101116675 16.52 35.67053531398425 139.7380101116675 37.844 35.67053044545751 139.73798593714903 37.844 35.67053044545751 139.73798593714903 33.102 35.67052622852979 139.73796506469597 33.102 35.67052622852979 139.73796506469597 16.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8b81b6c-1ace-474e-a550-854129acf5d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8b81b6c-1ace-474e-a550-854129acf5d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8b81b6c-1ace-474e-a550-854129acf5d7">
											<gml:posList>35.670532923636216 139.73798518305492 33.102 35.670532923636216 139.73798518305492 32.691 35.670529322047344 139.73796734759625 32.691 35.670529322047344 139.73796734759625 33.102 35.670532923636216 139.73798518305492 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c911c958-69e0-4031-94b8-9a91319a0b72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c911c958-69e0-4031-94b8-9a91319a0b72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c911c958-69e0-4031-94b8-9a91319a0b72">
											<gml:posList>35.67053671787746 139.73800727110427 37.844 35.67053671787746 139.73800727110427 37.54 35.67053277235348 139.73798764655533 37.54 35.67053277235348 139.73798764655533 37.844 35.67053671787746 139.73800727110427 37.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d6c79a9-3ca5-4c4f-a873-d048b6e5e658">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d6c79a9-3ca5-4c4f-a873-d048b6e5e658">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d6c79a9-3ca5-4c4f-a873-d048b6e5e658">
											<gml:posList>35.670532923636216 139.73798518305492 33.102 35.67053044545751 139.73798593714903 33.102 35.67053044545751 139.73798593714903 37.844 35.67056493272211 139.73797547949002 37.844 35.67056493272211 139.73797547949002 32.691 35.670532923636216 139.73798518305492 32.691 35.670532923636216 139.73798518305492 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7f7c9b4-3c4f-451c-b39e-bd71b979b930">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7f7c9b4-3c4f-451c-b39e-bd71b979b930">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7f7c9b4-3c4f-451c-b39e-bd71b979b930">
											<gml:posList>35.67053277235348 139.73798764655533 37.844 35.67053277235348 139.73798764655533 37.54 35.670563537843385 139.73797832004408 37.54 35.670563537843385 139.73797832004408 37.844 35.67053277235348 139.73798764655533 37.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47845075-7157-419a-9f52-39d1c87a3dc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47845075-7157-419a-9f52-39d1c87a3dc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47845075-7157-419a-9f52-39d1c87a3dc3">
											<gml:posList>35.6705674923826 139.73799794458938 37.844 35.6705674923826 139.73799794458938 37.54 35.67053671787746 139.73800727110427 37.54 35.67053671787746 139.73800727110427 37.844 35.6705674923826 139.73799794458938 37.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6b595a9-c4b4-4156-b9c2-566eedcbecf5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6b595a9-c4b4-4156-b9c2-566eedcbecf5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6b595a9-c4b4-4156-b9c2-566eedcbecf5">
											<gml:posList>35.67056981026467 139.7379996540075 33.102 35.67056981026467 139.7379996540075 37.844 35.67053531398425 139.7380101116675 37.844 35.67056981026467 139.7379996540075 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5557a663-64dd-4690-9fed-9205f514249c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5557a663-64dd-4690-9fed-9205f514249c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5557a663-64dd-4690-9fed-9205f514249c">
											<gml:posList>35.670563537843385 139.73797832004408 37.844 35.670563537843385 139.73797832004408 37.54 35.6705674923826 139.73799794458938 37.54 35.6705674923826 139.73799794458938 37.844 35.670563537843385 139.73797832004408 37.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69bf6788-dcfc-4507-abb0-4521461ea8f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69bf6788-dcfc-4507-abb0-4521461ea8f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69bf6788-dcfc-4507-abb0-4521461ea8f3">
											<gml:posList>35.67056493272211 139.73797547949002 32.691 35.67056493272211 139.73797547949002 37.844 35.67056981026467 139.7379996540075 37.844 35.67056981026467 139.7379996540075 33.102 35.67056919491777 139.73799660596444 33.102 35.67056919491777 139.73799660596444 32.691 35.67056493272211 139.73797547949002 32.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ffa5645-f09f-4e84-95bf-98659b134c80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ffa5645-f09f-4e84-95bf-98659b134c80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ffa5645-f09f-4e84-95bf-98659b134c80">
											<gml:posList>35.670529322047344 139.73796734759625 33.102 35.670529322047344 139.73796734759625 32.691 35.67064391313621 139.7379326253451 32.691 35.67064391313621 139.7379326253451 33.102 35.670529322047344 139.73796734759625 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae8325e6-06c7-4ad9-880d-3443d4af5842">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae8325e6-06c7-4ad9-880d-3443d4af5842">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae8325e6-06c7-4ad9-880d-3443d4af5842">
											<gml:posList>35.67052622852979 139.73796506469597 33.102 35.6706457849884 139.73792883423837 33.102 35.6706457849884 139.73792883423837 30.17 35.670663754051915 139.73792338912406 30.17 35.670663754051915 139.73792338912406 27.122 35.670681137363275 139.73791812144518 27.122 35.670681137363275 139.73791812144518 16.52 35.67052622852979 139.73796506469597 16.52 35.67052622852979 139.73796506469597 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b4d7133-076e-4d76-abae-fb53826e5b24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b4d7133-076e-4d76-abae-fb53826e5b24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b4d7133-076e-4d76-abae-fb53826e5b24">
											<gml:posList>35.670651776930214 139.7379715873226 33.102 35.670651776930214 139.7379715873226 32.691 35.67056919491777 139.73799660596444 32.691 35.67056919491777 139.73799660596444 33.102 35.670651776930214 139.7379715873226 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc2006d8-90e1-445a-8bf9-9a3822e2e787">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc2006d8-90e1-445a-8bf9-9a3822e2e787">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc2006d8-90e1-445a-8bf9-9a3822e2e787">
											<gml:posList>35.670654879470064 139.7379738812622 30.17 35.670654879470064 139.7379738812622 33.102 35.67056981026467 139.7379996540075 33.102 35.670654879470064 139.7379738812622 30.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-293dae2a-c300-48cd-8904-e01a6d3000b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-293dae2a-c300-48cd-8904-e01a6d3000b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-293dae2a-c300-48cd-8904-e01a6d3000b0">
											<gml:posList>35.67053531398425 139.7380101116675 37.844 35.67053531398425 139.7380101116675 16.52 35.67069018678906 139.73796317958752 16.52 35.67053531398425 139.7380101116675 37.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb300093-b653-4279-9324-a651dd258066">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb300093-b653-4279-9324-a651dd258066">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb300093-b653-4279-9324-a651dd258066">
											<gml:posList>35.670654879470064 139.7379738812622 30.17 35.67056981026467 139.7379996540075 33.102 35.67069018678906 139.73796317958752 16.52 35.670654879470064 139.7379738812622 30.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64aa0ac5-5d77-4de7-a481-93f709f4444a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64aa0ac5-5d77-4de7-a481-93f709f4444a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64aa0ac5-5d77-4de7-a481-93f709f4444a">
											<gml:posList>35.67064391313621 139.7379326253451 33.102 35.67064391313621 139.7379326253451 32.691 35.670651776930214 139.7379715873226 32.691 35.670651776930214 139.7379715873226 33.102 35.67064391313621 139.7379326253451 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58290a73-4b3d-4bd8-9713-5af91ebcd15b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58290a73-4b3d-4bd8-9713-5af91ebcd15b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58290a73-4b3d-4bd8-9713-5af91ebcd15b">
											<gml:posList>35.6706457849884 139.73792883423837 33.102 35.670654879470064 139.7379738812622 33.102 35.670654879470064 139.7379738812622 30.17 35.670654372707084 139.7379713633092 30.17 35.670654372707084 139.7379713633092 29.914 35.67064629175227 139.73793135219083 29.914 35.67064629175227 139.73793135219083 30.17 35.6706457849884 139.73792883423837 30.17 35.6706457849884 139.73792883423837 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68e7ac6e-4783-472e-bd07-9b30059db97c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68e7ac6e-4783-472e-bd07-9b30059db97c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68e7ac6e-4783-472e-bd07-9b30059db97c">
											<gml:posList>35.67064629175227 139.73793135219083 30.17 35.67064629175227 139.73793135219083 29.914 35.67066220616875 139.7379265170684 29.914 35.67066220616875 139.7379265170684 30.17 35.67064629175227 139.73793135219083 30.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e46d3dc3-8ea6-4110-b59b-2150f3c5a667">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e46d3dc3-8ea6-4110-b59b-2150f3c5a667">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e46d3dc3-8ea6-4110-b59b-2150f3c5a667">
											<gml:posList>35.67067283952188 139.73796843616807 27.122 35.67067283952188 139.73796843616807 30.17 35.670654879470064 139.7379738812622 30.17 35.67067283952188 139.73796843616807 27.122</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7728a86-c087-44ee-82d0-11df1948578e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7728a86-c087-44ee-82d0-11df1948578e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7728a86-c087-44ee-82d0-11df1948578e">
											<gml:posList>35.67066220616875 139.7379265170684 30.17 35.67066220616875 139.7379265170684 29.914 35.67067027812894 139.73796655029753 29.914 35.67067027812894 139.73796655029753 30.17 35.67066220616875 139.7379265170684 30.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f653f85-4738-42c2-b0fe-d676addb0575">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f653f85-4738-42c2-b0fe-d676addb0575">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f653f85-4738-42c2-b0fe-d676addb0575">
											<gml:posList>35.670663754051915 139.73792338912406 30.17 35.67067283952188 139.73796843616807 30.17 35.67067283952188 139.73796843616807 27.122 35.67067213367828 139.7379649353307 27.122 35.67067213367828 139.7379649353307 26.778 35.67066445988798 139.7379268789144 26.778 35.67066445988798 139.7379268789144 27.122 35.670663754051915 139.73792338912406 27.122 35.670663754051915 139.73792338912406 30.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1661a0d-55cc-424d-b044-e33e9a44f5a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1661a0d-55cc-424d-b044-e33e9a44f5a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1661a0d-55cc-424d-b044-e33e9a44f5a2">
											<gml:posList>35.67066445988798 139.7379268789144 27.122 35.67066445988798 139.7379268789144 26.778 35.670678986532465 139.73792247624715 26.778 35.670678986532465 139.73792247624715 27.122 35.67066445988798 139.7379268789144 27.122</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b39cab4-4b8d-49ad-98b5-4289e6b92c5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b39cab4-4b8d-49ad-98b5-4289e6b92c5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b39cab4-4b8d-49ad-98b5-4289e6b92c5e">
											<gml:posList>35.67067283952188 139.73796843616807 27.122 35.670654879470064 139.7379738812622 30.17 35.67069018678906 139.73796317958752 16.52 35.67067283952188 139.73796843616807 27.122</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25b1af8b-70f0-451a-8cb6-7741d7b7d69d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25b1af8b-70f0-451a-8cb6-7741d7b7d69d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25b1af8b-70f0-451a-8cb6-7741d7b7d69d">
											<gml:posList>35.67067283952188 139.73796843616807 27.122 35.67069018678906 139.73796317958752 16.52 35.67069018678906 139.73796317958752 27.122 35.67067283952188 139.73796843616807 27.122</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad893f75-eb4a-4f62-98e8-59bcddf3b39d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad893f75-eb4a-4f62-98e8-59bcddf3b39d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad893f75-eb4a-4f62-98e8-59bcddf3b39d">
											<gml:posList>35.670678986532465 139.73792247624715 27.122 35.670678986532465 139.73792247624715 26.778 35.67068663329172 139.7379605437484 26.778 35.67068663329172 139.7379605437484 27.122 35.670678986532465 139.73792247624715 27.122</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2f8fa4e-d744-48f3-8566-335e762aa2f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2f8fa4e-d744-48f3-8566-335e762aa2f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2f8fa4e-d744-48f3-8566-335e762aa2f5">
											<gml:posList>35.67069018678906 139.73796317958752 16.52 35.670681137363275 139.73791812144518 16.52 35.670681137363275 139.73791812144518 27.122 35.67069018678906 139.73796317958752 27.122 35.67069018678906 139.73796317958752 16.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d536d73-d887-4bf1-95a2-01c800a48e1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d536d73-d887-4bf1-95a2-01c800a48e1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d536d73-d887-4bf1-95a2-01c800a48e1b">
											<gml:posList>35.67056981026467 139.7379996540075 33.102 35.67053531398425 139.7380101116675 37.844 35.67069018678906 139.73796317958752 16.52 35.67056981026467 139.7379996540075 33.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5218</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">83.1068</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>