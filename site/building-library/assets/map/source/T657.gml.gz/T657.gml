<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c03893d6-e5b5-4d79-9522-3fe949709c77">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">17.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670496080607286 139.74103416455006 0 35.67043199735693 139.7410398719179 0 35.67043518280258 139.74107985573795 0 35.67049926605486 139.74107414840182 0 35.670496080607286 139.74103416455006 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670496080607286 139.74103416455006 8.9 35.67049926605486 139.74107414840182 8.9 35.67043518280258 139.74107985573795 8.9 35.67043199735693 139.7410398719179 8.9 35.670496080607286 139.74103416455006 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670496080607286 139.74103416455006 8.9 35.67043199735693 139.7410398719179 8.9 35.67043199735693 139.7410398719179 25.949999999999996 35.670496080607286 139.74103416455006 25.949999999999996 35.670496080607286 139.74103416455006 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67043199735693 139.7410398719179 8.9 35.67043518280258 139.74107985573795 8.9 35.67043518280258 139.74107985573795 25.949999999999996 35.67043199735693 139.7410398719179 25.949999999999996 35.67043199735693 139.7410398719179 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67043518280258 139.74107985573795 8.9 35.67049926605486 139.74107414840182 8.9 35.67049926605486 139.74107414840182 25.949999999999996 35.67043518280258 139.74107985573795 25.949999999999996 35.67043518280258 139.74107985573795 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049926605486 139.74107414840182 8.9 35.670496080607286 139.74103416455006 8.9 35.670496080607286 139.74103416455006 25.949999999999996 35.67049926605486 139.74107414840182 25.949999999999996 35.67049926605486 139.74107414840182 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670496080607286 139.74103416455006 25.949999999999996 35.67043199735693 139.7410398719179 25.949999999999996 35.67043518280258 139.74107985573795 25.949999999999996 35.67049926605486 139.74107414840182 25.949999999999996 35.670496080607286 139.74103416455006 25.949999999999996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e9186f49-ca29-44b4-9a59-ede4d70b58ee"/>
							<gml:surfaceMember xlink:href="#poly-5e6c3d90-baa4-4203-8de3-b81adb8251e0"/>
							<gml:surfaceMember xlink:href="#poly-bfedff36-d8c9-4e5a-adac-5f0adeb8ecdb"/>
							<gml:surfaceMember xlink:href="#poly-467c8495-92f2-4597-bdac-509b142ed8c8"/>
							<gml:surfaceMember xlink:href="#poly-c8e9073c-8b50-4a0e-9d07-1b8c9204ab52"/>
							<gml:surfaceMember xlink:href="#poly-9e133869-82e2-45f0-ad38-c4dab8aa7ba2"/>
							<gml:surfaceMember xlink:href="#poly-c22a32ad-1532-4ea4-95cc-18829bfc557f"/>
							<gml:surfaceMember xlink:href="#poly-85198fac-74e0-4be4-8be4-20f5d5886949"/>
							<gml:surfaceMember xlink:href="#poly-f1237bd4-323a-47da-b18f-ada2ee673c71"/>
							<gml:surfaceMember xlink:href="#poly-eea6c510-e744-442f-b677-2295ed08d9e3"/>
							<gml:surfaceMember xlink:href="#poly-40b05d4e-fb68-4d1a-a4a3-88324b48fc6c"/>
							<gml:surfaceMember xlink:href="#poly-72be8ece-8869-4fd8-8dfe-a17973ce45a0"/>
							<gml:surfaceMember xlink:href="#poly-4090108d-1612-4b43-88a3-ad93e39dfdbe"/>
							<gml:surfaceMember xlink:href="#poly-56554c99-8f89-4e0a-81b1-5283df565d39"/>
							<gml:surfaceMember xlink:href="#poly-0642d279-394e-454c-b563-ad6c3f421e1e"/>
							<gml:surfaceMember xlink:href="#poly-eb577417-a2f3-40a6-96ad-c564ac685bb6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e9186f49-ca29-44b4-9a59-ede4d70b58ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9186f49-ca29-44b4-9a59-ede4d70b58ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9186f49-ca29-44b4-9a59-ede4d70b58ee">
											<gml:posList>35.6704960806073 139.74103416455006 8.9 35.67049926605486 139.7410741484018 8.9 35.67043518280258 139.74107985573792 8.9 35.67043199735692 139.7410398719179 8.9 35.6704960806073 139.74103416455006 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e6c3d90-baa4-4203-8de3-b81adb8251e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e6c3d90-baa4-4203-8de3-b81adb8251e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e6c3d90-baa4-4203-8de3-b81adb8251e0">
											<gml:posList>35.67046108268439 139.7410372867488 27.503 35.67043199735692 139.7410398719179 27.503 35.67043460438864 139.74104256420608 27.503 35.67045930032951 139.74104037070998 27.503 35.67046108268439 139.7410372867488 27.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bfedff36-d8c9-4e5a-adac-5f0adeb8ecdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfedff36-d8c9-4e5a-adac-5f0adeb8ecdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfedff36-d8c9-4e5a-adac-5f0adeb8ecdb">
											<gml:posList>35.67046975711566 139.74107677823133 27.503 35.67049926605486 139.7410741484018 21.815 35.6704960806073 139.74103416455006 21.815 35.67046975711566 139.74107677823133 27.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-467c8495-92f2-4597-bdac-509b142ed8c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-467c8495-92f2-4597-bdac-509b142ed8c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-467c8495-92f2-4597-bdac-509b142ed8c8">
											<gml:posList>35.6704960806073 139.74103416455006 21.815 35.67046108268439 139.7410372867488 27.503 35.67046975711566 139.74107677823133 27.503 35.6704960806073 139.74103416455006 21.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8e9073c-8b50-4a0e-9d07-1b8c9204ab52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8e9073c-8b50-4a0e-9d07-1b8c9204ab52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8e9073c-8b50-4a0e-9d07-1b8c9204ab52">
											<gml:posList>35.67046108268439 139.7410372867488 27.503 35.67045930032951 139.74104037070998 27.503 35.670466726482076 139.74107414165968 27.503 35.67046975711566 139.74107677823133 27.503 35.67046108268439 139.7410372867488 27.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e133869-82e2-45f0-ad38-c4dab8aa7ba2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e133869-82e2-45f0-ad38-c4dab8aa7ba2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e133869-82e2-45f0-ad38-c4dab8aa7ba2">
											<gml:posList>35.67043732569892 139.7410767603174 26.787 35.670466726482076 139.74107414165968 26.787 35.67045930032951 139.74104037070998 26.787 35.67043460438864 139.74104256420608 26.787 35.67043732569892 139.7410767603174 26.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c22a32ad-1532-4ea4-95cc-18829bfc557f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c22a32ad-1532-4ea4-95cc-18829bfc557f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c22a32ad-1532-4ea4-95cc-18829bfc557f">
											<gml:posList>35.67043518280258 139.74107985573792 27.503 35.67043732569892 139.7410767603174 27.503 35.67043460438864 139.74104256420608 27.503 35.67043199735692 139.7410398719179 27.503 35.67043518280258 139.74107985573792 27.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-85198fac-74e0-4be4-8be4-20f5d5886949">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85198fac-74e0-4be4-8be4-20f5d5886949">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85198fac-74e0-4be4-8be4-20f5d5886949">
											<gml:posList>35.67043518280258 139.74107985573792 27.503 35.67046975711566 139.74107677823133 27.503 35.670466726482076 139.74107414165968 27.503 35.67043732569892 139.7410767603174 27.503 35.67043518280258 139.74107985573792 27.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1237bd4-323a-47da-b18f-ada2ee673c71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1237bd4-323a-47da-b18f-ada2ee673c71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1237bd4-323a-47da-b18f-ada2ee673c71">
											<gml:posList>35.67043199735692 139.7410398719179 8.9 35.67043518280258 139.74107985573792 8.9 35.67043518280258 139.74107985573792 27.503 35.67043199735692 139.7410398719179 27.503 35.67043199735692 139.7410398719179 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eea6c510-e744-442f-b677-2295ed08d9e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eea6c510-e744-442f-b677-2295ed08d9e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eea6c510-e744-442f-b677-2295ed08d9e3">
											<gml:posList>35.67043732569892 139.7410767603174 27.503 35.67043732569892 139.7410767603174 26.787 35.67043460438864 139.74104256420608 26.787 35.67043460438864 139.74104256420608 27.503 35.67043732569892 139.7410767603174 27.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40b05d4e-fb68-4d1a-a4a3-88324b48fc6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40b05d4e-fb68-4d1a-a4a3-88324b48fc6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40b05d4e-fb68-4d1a-a4a3-88324b48fc6c">
											<gml:posList>35.67043460438864 139.74104256420608 27.503 35.67043460438864 139.74104256420608 26.787 35.67045930032951 139.74104037070998 26.787 35.67045930032951 139.74104037070998 27.503 35.67043460438864 139.74104256420608 27.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72be8ece-8869-4fd8-8dfe-a17973ce45a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72be8ece-8869-4fd8-8dfe-a17973ce45a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72be8ece-8869-4fd8-8dfe-a17973ce45a0">
											<gml:posList>35.670466726482076 139.74107414165968 27.503 35.670466726482076 139.74107414165968 26.787 35.67043732569892 139.7410767603174 26.787 35.67043732569892 139.7410767603174 27.503 35.670466726482076 139.74107414165968 27.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4090108d-1612-4b43-88a3-ad93e39dfdbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4090108d-1612-4b43-88a3-ad93e39dfdbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4090108d-1612-4b43-88a3-ad93e39dfdbe">
											<gml:posList>35.67045930032951 139.74104037070998 27.503 35.67045930032951 139.74104037070998 26.787 35.670466726482076 139.74107414165968 26.787 35.670466726482076 139.74107414165968 27.503 35.67045930032951 139.74104037070998 27.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56554c99-8f89-4e0a-81b1-5283df565d39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56554c99-8f89-4e0a-81b1-5283df565d39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56554c99-8f89-4e0a-81b1-5283df565d39">
											<gml:posList>35.6704960806073 139.74103416455006 21.815 35.6704960806073 139.74103416455006 8.9 35.67043199735692 139.7410398719179 8.9 35.67043199735692 139.7410398719179 27.503 35.67046108268439 139.7410372867488 27.503 35.6704960806073 139.74103416455006 21.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0642d279-394e-454c-b563-ad6c3f421e1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0642d279-394e-454c-b563-ad6c3f421e1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0642d279-394e-454c-b563-ad6c3f421e1e">
											<gml:posList>35.67046975711566 139.74107677823133 27.503 35.67043518280258 139.74107985573792 27.503 35.67043518280258 139.74107985573792 8.9 35.67049926605486 139.7410741484018 8.9 35.67049926605486 139.7410741484018 21.815 35.67046975711566 139.74107677823133 27.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb577417-a2f3-40a6-96ad-c564ac685bb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb577417-a2f3-40a6-96ad-c564ac685bb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb577417-a2f3-40a6-96ad-c564ac685bb6">
											<gml:posList>35.67049926605486 139.7410741484018 8.9 35.6704960806073 139.74103416455006 8.9 35.6704960806073 139.74103416455006 21.815 35.67049926605486 139.7410741484018 21.815 35.67049926605486 139.7410741484018 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9837</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">167.65994</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>