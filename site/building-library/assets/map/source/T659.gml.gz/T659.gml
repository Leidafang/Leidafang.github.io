<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c0f5dd64-00bb-4eff-be18-677fc424fc5b">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:measuredHeight uom="m">7.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67183393994386 139.7466946863162 0 35.67181554648698 139.74666206391012 0 35.671800603471944 139.7466144146077 0 35.67170984914 139.74677156005495 0 35.67178831747682 139.7468395988164 0 35.67185523415771 139.74672500793938 0 35.67183393994386 139.7466946863162 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67183393994386 139.7466946863162 10.81 35.67185523415771 139.74672500793938 10.81 35.67178831747682 139.7468395988164 10.81 35.67170984914 139.74677156005495 10.81 35.671800603471944 139.7466144146077 10.81 35.67181554648698 139.74666206391012 10.81 35.67183393994386 139.7466946863162 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67183393994386 139.7466946863162 10.81 35.67181554648698 139.74666206391012 10.81 35.67181554648698 139.74666206391012 18.19 35.67183393994386 139.7466946863162 18.19 35.67183393994386 139.7466946863162 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181554648698 139.74666206391012 10.81 35.671800603471944 139.7466144146077 10.81 35.671800603471944 139.7466144146077 18.19 35.67181554648698 139.74666206391012 18.19 35.67181554648698 139.74666206391012 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671800603471944 139.7466144146077 10.81 35.67170984914 139.74677156005495 10.81 35.67170984914 139.74677156005495 18.19 35.671800603471944 139.7466144146077 18.19 35.671800603471944 139.7466144146077 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170984914 139.74677156005495 10.81 35.67178831747682 139.7468395988164 10.81 35.67178831747682 139.7468395988164 18.19 35.67170984914 139.74677156005495 18.19 35.67170984914 139.74677156005495 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178831747682 139.7468395988164 10.81 35.67185523415771 139.74672500793938 10.81 35.67185523415771 139.74672500793938 18.19 35.67178831747682 139.7468395988164 18.19 35.67178831747682 139.7468395988164 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67185523415771 139.74672500793938 10.81 35.67183393994386 139.7466946863162 10.81 35.67183393994386 139.7466946863162 18.19 35.67185523415771 139.74672500793938 18.19 35.67185523415771 139.74672500793938 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67183393994386 139.7466946863162 18.19 35.67181554648698 139.74666206391012 18.19 35.671800603471944 139.7466144146077 18.19 35.67170984914 139.74677156005495 18.19 35.67178831747682 139.7468395988164 18.19 35.67185523415771 139.74672500793938 18.19 35.67183393994386 139.7466946863162 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-331d6be0-5156-41c4-9ac3-6b9b669873d0"/>
							<gml:surfaceMember xlink:href="#poly-9e45c878-bf89-4f32-be40-be35f4564b2e"/>
							<gml:surfaceMember xlink:href="#poly-f1f916b2-be08-4e7d-a6c4-a12cce2db63e"/>
							<gml:surfaceMember xlink:href="#poly-c8396fcc-1972-4670-bd33-5ccc80ad2700"/>
							<gml:surfaceMember xlink:href="#poly-ebe8ea4f-0367-4595-b841-627ca1f12266"/>
							<gml:surfaceMember xlink:href="#poly-bceed2e7-f57e-415f-8933-ad948574cd28"/>
							<gml:surfaceMember xlink:href="#poly-3c6f58d3-1371-47da-87aa-5b0e05f46582"/>
							<gml:surfaceMember xlink:href="#poly-af1ccbea-da59-44c7-8f4d-57fefbc59526"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-331d6be0-5156-41c4-9ac3-6b9b669873d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-331d6be0-5156-41c4-9ac3-6b9b669873d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-331d6be0-5156-41c4-9ac3-6b9b669873d0">
											<gml:posList>35.67170984913997 139.74677156005492 10.81 35.67180060347191 139.74661441460773 10.81 35.67181554648697 139.74666206391012 10.81 35.67183393994383 139.7466946863162 10.81 35.67185523415768 139.74672500793938 10.81 35.671788317476796 139.7468395988164 10.81 35.67170984913997 139.74677156005492 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e45c878-bf89-4f32-be40-be35f4564b2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e45c878-bf89-4f32-be40-be35f4564b2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e45c878-bf89-4f32-be40-be35f4564b2e">
											<gml:posList>35.67170984913997 139.74677156005492 18.1 35.671788317476796 139.7468395988164 18.1 35.67185523415768 139.74672500793938 18.1 35.67183393994383 139.7466946863162 18.1 35.67181554648697 139.74666206391012 18.1 35.67180060347191 139.74661441460773 18.1 35.67170984913997 139.74677156005492 18.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1f916b2-be08-4e7d-a6c4-a12cce2db63e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1f916b2-be08-4e7d-a6c4-a12cce2db63e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1f916b2-be08-4e7d-a6c4-a12cce2db63e">
											<gml:posList>35.67181554648697 139.74666206391012 10.81 35.67180060347191 139.74661441460773 10.81 35.67180060347191 139.74661441460773 18.1 35.67181554648697 139.74666206391012 18.1 35.67181554648697 139.74666206391012 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8396fcc-1972-4670-bd33-5ccc80ad2700">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8396fcc-1972-4670-bd33-5ccc80ad2700">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8396fcc-1972-4670-bd33-5ccc80ad2700">
											<gml:posList>35.67183393994383 139.7466946863162 10.81 35.67181554648697 139.74666206391012 10.81 35.67181554648697 139.74666206391012 18.1 35.67183393994383 139.7466946863162 18.1 35.67183393994383 139.7466946863162 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebe8ea4f-0367-4595-b841-627ca1f12266">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebe8ea4f-0367-4595-b841-627ca1f12266">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebe8ea4f-0367-4595-b841-627ca1f12266">
											<gml:posList>35.67180060347191 139.74661441460773 10.81 35.67170984913997 139.74677156005492 10.81 35.67170984913997 139.74677156005492 18.1 35.67180060347191 139.74661441460773 18.1 35.67180060347191 139.74661441460773 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bceed2e7-f57e-415f-8933-ad948574cd28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bceed2e7-f57e-415f-8933-ad948574cd28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bceed2e7-f57e-415f-8933-ad948574cd28">
											<gml:posList>35.67185523415768 139.74672500793938 10.81 35.67183393994383 139.7466946863162 10.81 35.67183393994383 139.7466946863162 18.1 35.67185523415768 139.74672500793938 18.1 35.67185523415768 139.74672500793938 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c6f58d3-1371-47da-87aa-5b0e05f46582">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c6f58d3-1371-47da-87aa-5b0e05f46582">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c6f58d3-1371-47da-87aa-5b0e05f46582">
											<gml:posList>35.671788317476796 139.7468395988164 10.81 35.67185523415768 139.74672500793938 10.81 35.67185523415768 139.74672500793938 18.1 35.671788317476796 139.7468395988164 18.1 35.671788317476796 139.7468395988164 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af1ccbea-da59-44c7-8f4d-57fefbc59526">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af1ccbea-da59-44c7-8f4d-57fefbc59526">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af1ccbea-da59-44c7-8f4d-57fefbc59526">
											<gml:posList>35.67170984913997 139.74677156005492 10.81 35.671788317476796 139.7468395988164 10.81 35.671788317476796 139.7468395988164 18.1 35.67170984913997 139.74677156005492 18.1 35.67170984913997 139.74677156005492 10.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-550</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>