<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c108ffdc-1f7e-4fe6-bdf7-eb7f1d95c077">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">32.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67119076631374 139.73893808915597 0 35.671269095051564 139.73891436872384 0 35.67124346850717 139.73878735450734 0 35.671152181106784 139.7388149676078 0 35.67118240441985 139.7389647207522 0 35.6711953810616 139.73896072878452 0 35.67119076631374 139.73893808915597 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119076631374 139.73893808915597 17.184 35.6711953810616 139.73896072878452 17.184 35.67118240441985 139.7389647207522 17.184 35.671152181106784 139.7388149676078 17.184 35.67124346850717 139.73878735450734 17.184 35.671269095051564 139.73891436872384 17.184 35.67119076631374 139.73893808915597 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119076631374 139.73893808915597 17.184 35.671269095051564 139.73891436872384 17.184 35.671269095051564 139.73891436872384 49.25 35.67119076631374 139.73893808915597 49.25 35.67119076631374 139.73893808915597 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671269095051564 139.73891436872384 17.184 35.67124346850717 139.73878735450734 17.184 35.67124346850717 139.73878735450734 49.25 35.671269095051564 139.73891436872384 49.25 35.671269095051564 139.73891436872384 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67124346850717 139.73878735450734 17.184 35.671152181106784 139.7388149676078 17.184 35.671152181106784 139.7388149676078 49.25 35.67124346850717 139.73878735450734 49.25 35.67124346850717 139.73878735450734 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671152181106784 139.7388149676078 17.184 35.67118240441985 139.7389647207522 17.184 35.67118240441985 139.7389647207522 49.25 35.671152181106784 139.7388149676078 49.25 35.671152181106784 139.7388149676078 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67118240441985 139.7389647207522 17.184 35.6711953810616 139.73896072878452 17.184 35.6711953810616 139.73896072878452 49.25 35.67118240441985 139.7389647207522 49.25 35.67118240441985 139.7389647207522 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6711953810616 139.73896072878452 17.184 35.67119076631374 139.73893808915597 17.184 35.67119076631374 139.73893808915597 49.25 35.6711953810616 139.73896072878452 49.25 35.6711953810616 139.73896072878452 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119076631374 139.73893808915597 49.25 35.671269095051564 139.73891436872384 49.25 35.67124346850717 139.73878735450734 49.25 35.671152181106784 139.7388149676078 49.25 35.67118240441985 139.7389647207522 49.25 35.6711953810616 139.73896072878452 49.25 35.67119076631374 139.73893808915597 49.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ff9032df-10b7-4c98-b7ce-03b61a9347c4"/>
							<gml:surfaceMember xlink:href="#poly-fcc0b403-abe7-49c1-8454-2eebb643d13b"/>
							<gml:surfaceMember xlink:href="#poly-e214946e-6771-4402-847f-a9c0bfbb478c"/>
							<gml:surfaceMember xlink:href="#poly-21f08bdc-cab3-4d94-85ff-ab20c3ae510f"/>
							<gml:surfaceMember xlink:href="#poly-66c7914f-a75f-4985-bb3e-fd2f0d7851ea"/>
							<gml:surfaceMember xlink:href="#poly-2ba5b979-5bae-43aa-b324-a7117c8bbe9f"/>
							<gml:surfaceMember xlink:href="#poly-b0d9ba8d-4338-47b7-9f26-2d0a8a54dffd"/>
							<gml:surfaceMember xlink:href="#poly-7a3d8a8b-a331-49c6-b084-c4f668797235"/>
							<gml:surfaceMember xlink:href="#poly-ed41c35e-2064-48ea-ae4d-8a51aca2affb"/>
							<gml:surfaceMember xlink:href="#poly-88319e7d-450f-4a42-bc21-70e2acf24e4b"/>
							<gml:surfaceMember xlink:href="#poly-e0b4fb4c-f056-4946-88ae-21b23072f715"/>
							<gml:surfaceMember xlink:href="#poly-de21c1bc-cbf6-498f-bdc6-a8cda855cf4e"/>
							<gml:surfaceMember xlink:href="#poly-528ada7a-020c-4000-9730-fc06fe1339e3"/>
							<gml:surfaceMember xlink:href="#poly-e02a53ea-6016-4a65-94b4-7062713a8543"/>
							<gml:surfaceMember xlink:href="#poly-62d325f0-cd57-44a2-b93f-31527a7f5d12"/>
							<gml:surfaceMember xlink:href="#poly-fff25222-2328-454a-817a-683ea7e0b815"/>
							<gml:surfaceMember xlink:href="#poly-6af04924-7661-4ed3-8424-d98663faa852"/>
							<gml:surfaceMember xlink:href="#poly-14d825ec-3b97-4558-b76c-f76dac8adf75"/>
							<gml:surfaceMember xlink:href="#poly-56ff7696-6f10-4791-8259-4bd60b4b9fe4"/>
							<gml:surfaceMember xlink:href="#poly-adb9826c-a9e4-4da8-8200-6fd9cda3273b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c108ffdc-1f7e-4fe6-bdf7-eb7f1d95c077_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-937f543f-6d78-4d28-bfd6-a8c79b3a2bd9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671272877501906 139.73893313207284 17.184 35.67125323226647 139.7389391202487 17.184 35.67124943178096 139.73892034587882 17.184 35.671269095051564 139.73891436872384 17.184 35.671272877501906 139.73893313207284 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbc4483d-63a1-4d98-9913-a57775be1877">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbc4483d-63a1-4d98-9913-a57775be1877_0">
											<gml:posList>35.67124943178096 139.73892034587882 47.568 35.67124943178096 139.73892034587882 17.184 35.67125323226647 139.7389391202487 17.184 35.67125323226647 139.7389391202487 47.568 35.67124943178096 139.73892034587882 47.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a5cc470-f229-4f38-870e-c4a9783af39d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a5cc470-f229-4f38-870e-c4a9783af39d_0">
											<gml:posList>35.671269095051564 139.73891436872384 47.568 35.671269095051564 139.73891436872384 17.184 35.67124943178096 139.73892034587882 17.184 35.67124943178096 139.73892034587882 47.568 35.671269095051564 139.73891436872384 47.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c15f6e6-c1cc-4498-ae63-dffdc570df35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c15f6e6-c1cc-4498-ae63-dffdc570df35_0">
											<gml:posList>35.671269095051564 139.73891436872384 47.568 35.67124943178096 139.73892034587882 47.568 35.67125323226647 139.7389391202487 47.568 35.671272877501906 139.73893313207284 47.568 35.671269095051564 139.73891436872384 47.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b106c3c6-3835-4682-ba26-9631abfe135d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b106c3c6-3835-4682-ba26-9631abfe135d_0">
											<gml:posList>35.67125323226647 139.7389391202487 47.568 35.67125323226647 139.7389391202487 17.184 35.671272877501906 139.73893313207284 17.184 35.671272877501906 139.73893313207284 47.568 35.67125323226647 139.7389391202487 47.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a154df71-44e7-48e2-9607-72f15f6a3e7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a154df71-44e7-48e2-9607-72f15f6a3e7c_0">
											<gml:posList>35.671272877501906 139.73893313207284 47.568 35.671272877501906 139.73893313207284 17.184 35.671269095051564 139.73891436872384 17.184 35.671269095051564 139.73891436872384 47.568 35.671272877501906 139.73893313207284 47.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c108ffdc-1f7e-4fe6-bdf7-eb7f1d95c077_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8264385f-3b3c-445a-932c-ad274a5db8d3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671214991347405 139.7388756817586 48.973 35.67120566438175 139.73887854271132 48.973 35.671203148913754 139.73886624001568 48.973 35.6712124758791 139.7388633790616 48.973 35.671214991347405 139.7388756817586 48.973</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-beb9e6d7-ebda-4f3b-b126-fe746ccddf6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-beb9e6d7-ebda-4f3b-b126-fe746ccddf6b_0">
											<gml:posList>35.67120566438175 139.73887854271132 48.973 35.67120566438175 139.73887854271132 51.073 35.671203148913754 139.73886624001568 51.073 35.671203148913754 139.73886624001568 48.973 35.67120566438175 139.73887854271132 48.973</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50cc18df-403d-4b92-b35a-0ec846ac68ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50cc18df-403d-4b92-b35a-0ec846ac68ec_0">
											<gml:posList>35.671203148913754 139.73886624001568 48.973 35.671203148913754 139.73886624001568 51.073 35.6712124758791 139.7388633790616 51.073 35.6712124758791 139.7388633790616 48.973 35.671203148913754 139.73886624001568 48.973</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83b78cb6-fa57-478e-8e7d-b2dbd75fe715">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83b78cb6-fa57-478e-8e7d-b2dbd75fe715_0">
											<gml:posList>35.671203148913754 139.73886624001568 51.073 35.67120566438175 139.73887854271132 51.073 35.671214991347405 139.7388756817586 51.073 35.6712124758791 139.7388633790616 51.073 35.671203148913754 139.73886624001568 51.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce297e9b-5899-40e1-8ba8-7828ea818786">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce297e9b-5899-40e1-8ba8-7828ea818786_0">
											<gml:posList>35.671214991347405 139.7388756817586 48.973 35.671214991347405 139.7388756817586 51.073 35.67120566438175 139.73887854271132 51.073 35.67120566438175 139.73887854271132 48.973 35.671214991347405 139.7388756817586 48.973</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f857a4e-1953-40e3-8023-ba3ad9148d62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f857a4e-1953-40e3-8023-ba3ad9148d62_0">
											<gml:posList>35.6712124758791 139.7388633790616 48.973 35.6712124758791 139.7388633790616 51.073 35.671214991347405 139.7388756817586 51.073 35.671214991347405 139.7388756817586 48.973 35.6712124758791 139.7388633790616 48.973</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ff9032df-10b7-4c98-b7ce-03b61a9347c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff9032df-10b7-4c98-b7ce-03b61a9347c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff9032df-10b7-4c98-b7ce-03b61a9347c4">
											<gml:posList>35.67119076631371 139.73893808915597 17.184 35.67119538106158 139.73896072878452 17.184 35.67118240441985 139.7389647207522 17.184 35.67115218110678 139.7388149676078 17.184 35.67124346850716 139.7387873545073 17.184 35.671269095051564 139.73891436872384 17.184 35.67119076631371 139.73893808915597 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcc0b403-abe7-49c1-8454-2eebb643d13b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcc0b403-abe7-49c1-8454-2eebb643d13b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcc0b403-abe7-49c1-8454-2eebb643d13b">
											<gml:posList>35.67118240441985 139.7389647207522 49.737 35.67118473525094 139.7389599680696 49.737 35.67115605023887 139.73881782405533 49.737 35.67115218110678 139.7388149676078 49.737 35.67118240441985 139.7389647207522 49.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e214946e-6771-4402-847f-a9c0bfbb478c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e214946e-6771-4402-847f-a9c0bfbb478c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e214946e-6771-4402-847f-a9c0bfbb478c">
											<gml:posList>35.67119538106158 139.73896072878452 49.737 35.67119152996899 139.73895788335383 49.737 35.67118473525094 139.7389599680696 49.737 35.67118240441985 139.7389647207522 49.737 35.67119538106158 139.73896072878452 49.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21f08bdc-cab3-4d94-85ff-ab20c3ae510f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21f08bdc-cab3-4d94-85ff-ab20c3ae510f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21f08bdc-cab3-4d94-85ff-ab20c3ae510f">
											<gml:posList>35.67119076631371 139.73893808915597 49.737 35.67118690618955 139.7389352216444 49.737 35.67119152996899 139.73895788335383 49.737 35.67119538106158 139.73896072878452 49.737 35.67119076631371 139.73893808915597 49.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66c7914f-a75f-4985-bb3e-fd2f0d7851ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66c7914f-a75f-4985-bb3e-fd2f0d7851ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66c7914f-a75f-4985-bb3e-fd2f0d7851ea">
											<gml:posList>35.67115218110678 139.7388149676078 49.737 35.67115605023887 139.73881782405533 49.737 35.671241137656914 139.73879207405935 49.737 35.67124346850716 139.7387873545073 49.737 35.67115218110678 139.7388149676078 49.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ba5b979-5bae-43aa-b324-a7117c8bbe9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ba5b979-5bae-43aa-b324-a7117c8bbe9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ba5b979-5bae-43aa-b324-a7117c8bbe9f">
											<gml:posList>35.67118690618955 139.7389352216444 48.973 35.67126523492688 139.73891150121065 48.973 35.671241137656914 139.73879207405935 48.973 35.67115605023887 139.73881782405533 48.973 35.67118473525094 139.7389599680696 48.973 35.67119152996899 139.73895788335383 48.973 35.67118690618955 139.7389352216444 48.973</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0d9ba8d-4338-47b7-9f26-2d0a8a54dffd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0d9ba8d-4338-47b7-9f26-2d0a8a54dffd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0d9ba8d-4338-47b7-9f26-2d0a8a54dffd">
											<gml:posList>35.67119076631371 139.73893808915597 49.737 35.671269095051564 139.73891436872384 49.737 35.67126523492688 139.73891150121065 49.737 35.67118690618955 139.7389352216444 49.737 35.67119076631371 139.73893808915597 49.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a3d8a8b-a331-49c6-b084-c4f668797235">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a3d8a8b-a331-49c6-b084-c4f668797235">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a3d8a8b-a331-49c6-b084-c4f668797235">
											<gml:posList>35.67124346850716 139.7387873545073 49.737 35.671241137656914 139.73879207405935 49.737 35.67126523492688 139.73891150121065 49.737 35.671269095051564 139.73891436872384 49.737 35.67124346850716 139.7387873545073 49.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed41c35e-2064-48ea-ae4d-8a51aca2affb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed41c35e-2064-48ea-ae4d-8a51aca2affb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed41c35e-2064-48ea-ae4d-8a51aca2affb">
											<gml:posList>35.67115218110678 139.7388149676078 17.184 35.67118240441985 139.7389647207522 17.184 35.67118240441985 139.7389647207522 49.737 35.67115218110678 139.7388149676078 49.737 35.67115218110678 139.7388149676078 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88319e7d-450f-4a42-bc21-70e2acf24e4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88319e7d-450f-4a42-bc21-70e2acf24e4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88319e7d-450f-4a42-bc21-70e2acf24e4b">
											<gml:posList>35.67118473525094 139.7389599680696 49.737 35.67118473525094 139.7389599680696 48.973 35.67115605023887 139.73881782405533 48.973 35.67115605023887 139.73881782405533 49.737 35.67118473525094 139.7389599680696 49.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0b4fb4c-f056-4946-88ae-21b23072f715">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0b4fb4c-f056-4946-88ae-21b23072f715">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0b4fb4c-f056-4946-88ae-21b23072f715">
											<gml:posList>35.67119152996899 139.73895788335383 49.737 35.67119152996899 139.73895788335383 48.973 35.67118473525094 139.7389599680696 48.973 35.67118473525094 139.7389599680696 49.737 35.67119152996899 139.73895788335383 49.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de21c1bc-cbf6-498f-bdc6-a8cda855cf4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de21c1bc-cbf6-498f-bdc6-a8cda855cf4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de21c1bc-cbf6-498f-bdc6-a8cda855cf4e">
											<gml:posList>35.67118240441985 139.7389647207522 17.184 35.67119538106158 139.73896072878452 17.184 35.67119538106158 139.73896072878452 49.737 35.67118240441985 139.7389647207522 49.737 35.67118240441985 139.7389647207522 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-528ada7a-020c-4000-9730-fc06fe1339e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-528ada7a-020c-4000-9730-fc06fe1339e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-528ada7a-020c-4000-9730-fc06fe1339e3">
											<gml:posList>35.67118690618955 139.7389352216444 49.737 35.67118690618955 139.7389352216444 48.973 35.67119152996899 139.73895788335383 48.973 35.67119152996899 139.73895788335383 49.737 35.67118690618955 139.7389352216444 49.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e02a53ea-6016-4a65-94b4-7062713a8543">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e02a53ea-6016-4a65-94b4-7062713a8543">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e02a53ea-6016-4a65-94b4-7062713a8543">
											<gml:posList>35.67119538106158 139.73896072878452 17.184 35.67119076631371 139.73893808915597 17.184 35.67119076631371 139.73893808915597 49.737 35.67119538106158 139.73896072878452 49.737 35.67119538106158 139.73896072878452 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62d325f0-cd57-44a2-b93f-31527a7f5d12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62d325f0-cd57-44a2-b93f-31527a7f5d12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62d325f0-cd57-44a2-b93f-31527a7f5d12">
											<gml:posList>35.67124346850716 139.7387873545073 17.184 35.67115218110678 139.7388149676078 17.184 35.67115218110678 139.7388149676078 49.737 35.67124346850716 139.7387873545073 49.737 35.67124346850716 139.7387873545073 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fff25222-2328-454a-817a-683ea7e0b815">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fff25222-2328-454a-817a-683ea7e0b815">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fff25222-2328-454a-817a-683ea7e0b815">
											<gml:posList>35.67115605023887 139.73881782405533 49.737 35.67115605023887 139.73881782405533 48.973 35.671241137656914 139.73879207405935 48.973 35.671241137656914 139.73879207405935 49.737 35.67115605023887 139.73881782405533 49.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6af04924-7661-4ed3-8424-d98663faa852">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6af04924-7661-4ed3-8424-d98663faa852">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6af04924-7661-4ed3-8424-d98663faa852">
											<gml:posList>35.67126523492688 139.73891150121065 49.737 35.67126523492688 139.73891150121065 48.973 35.67118690618955 139.7389352216444 48.973 35.67118690618955 139.7389352216444 49.737 35.67126523492688 139.73891150121065 49.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14d825ec-3b97-4558-b76c-f76dac8adf75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14d825ec-3b97-4558-b76c-f76dac8adf75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14d825ec-3b97-4558-b76c-f76dac8adf75">
											<gml:posList>35.67119076631371 139.73893808915597 17.184 35.671269095051564 139.73891436872384 17.184 35.671269095051564 139.73891436872384 49.737 35.67119076631371 139.73893808915597 49.737 35.67119076631371 139.73893808915597 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56ff7696-6f10-4791-8259-4bd60b4b9fe4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56ff7696-6f10-4791-8259-4bd60b4b9fe4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56ff7696-6f10-4791-8259-4bd60b4b9fe4">
											<gml:posList>35.671241137656914 139.73879207405935 49.737 35.671241137656914 139.73879207405935 48.973 35.67126523492688 139.73891150121065 48.973 35.67126523492688 139.73891150121065 49.737 35.671241137656914 139.73879207405935 49.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adb9826c-a9e4-4da8-8200-6fd9cda3273b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adb9826c-a9e4-4da8-8200-6fd9cda3273b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adb9826c-a9e4-4da8-8200-6fd9cda3273b">
											<gml:posList>35.671269095051564 139.73891436872384 17.184 35.67124346850716 139.7387873545073 17.184 35.67124346850716 139.7387873545073 49.737 35.671269095051564 139.73891436872384 49.737 35.671269095051564 139.73891436872384 17.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5069</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">130.6404</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>