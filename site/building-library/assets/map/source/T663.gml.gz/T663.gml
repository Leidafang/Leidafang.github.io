<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c2703c15-16f2-4a73-a720-c481d6724bdb">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="説明注記">
				<gen:value>通気孔</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">5.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66854453267382 139.7410657602836 0 35.668541290517176 139.7410693981504 0 35.66853831955079 139.7410740519374 0 35.66853796314011 139.74107945384426 0 35.668538688393205 139.7410848765987 0 35.66854058507499 139.74108983407334 0 35.66854356265908 139.74109381825622 0 35.66854744059178 139.7410964648369 0 35.66855176802615 139.74109756445966 0 35.668556184235555 139.74109688557314 0 35.66856014858262 139.74109467181108 0 35.66856339065537 139.74109092348442 0 35.668565640524385 139.74108627052618 0 35.66856644761312 139.74108085705294 0 35.668565992873205 139.74107556653755 0 35.6685640961824 139.74107059801568 0 35.66856111859755 139.74106661383263 0 35.66855724066421 139.74106396725298 0 35.66855291322954 139.74106286763188 0 35.66854849702029 139.7410635465203 0 35.66854453267382 139.7410657602836 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854453267382 139.7410657602836 12.016 35.66854849702029 139.7410635465203 12.016 35.66855291322954 139.74106286763188 12.016 35.66855724066421 139.74106396725298 12.016 35.66856111859755 139.74106661383263 12.016 35.6685640961824 139.74107059801568 12.016 35.668565992873205 139.74107556653755 12.016 35.66856644761312 139.74108085705294 12.016 35.668565640524385 139.74108627052618 12.016 35.66856339065537 139.74109092348442 12.016 35.66856014858262 139.74109467181108 12.016 35.668556184235555 139.74109688557314 12.016 35.66855176802615 139.74109756445966 12.016 35.66854744059178 139.7410964648369 12.016 35.66854356265908 139.74109381825622 12.016 35.66854058507499 139.74108983407334 12.016 35.668538688393205 139.7410848765987 12.016 35.66853796314011 139.74107945384426 12.016 35.66853831955079 139.7410740519374 12.016 35.668541290517176 139.7410693981504 12.016 35.66854453267382 139.7410657602836 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854453267382 139.7410657602836 12.016 35.668541290517176 139.7410693981504 12.016 35.668541290517176 139.7410693981504 17.46 35.66854453267382 139.7410657602836 17.46 35.66854453267382 139.7410657602836 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668541290517176 139.7410693981504 12.016 35.66853831955079 139.7410740519374 12.016 35.66853831955079 139.7410740519374 17.46 35.668541290517176 139.7410693981504 17.46 35.668541290517176 139.7410693981504 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853831955079 139.7410740519374 12.016 35.66853796314011 139.74107945384426 12.016 35.66853796314011 139.74107945384426 17.46 35.66853831955079 139.7410740519374 17.46 35.66853831955079 139.7410740519374 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853796314011 139.74107945384426 12.016 35.668538688393205 139.7410848765987 12.016 35.668538688393205 139.7410848765987 17.46 35.66853796314011 139.74107945384426 17.46 35.66853796314011 139.74107945384426 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668538688393205 139.7410848765987 12.016 35.66854058507499 139.74108983407334 12.016 35.66854058507499 139.74108983407334 17.46 35.668538688393205 139.7410848765987 17.46 35.668538688393205 139.7410848765987 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854058507499 139.74108983407334 12.016 35.66854356265908 139.74109381825622 12.016 35.66854356265908 139.74109381825622 17.46 35.66854058507499 139.74108983407334 17.46 35.66854058507499 139.74108983407334 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854356265908 139.74109381825622 12.016 35.66854744059178 139.7410964648369 12.016 35.66854744059178 139.7410964648369 17.46 35.66854356265908 139.74109381825622 17.46 35.66854356265908 139.74109381825622 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854744059178 139.7410964648369 12.016 35.66855176802615 139.74109756445966 12.016 35.66855176802615 139.74109756445966 17.46 35.66854744059178 139.7410964648369 17.46 35.66854744059178 139.7410964648369 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855176802615 139.74109756445966 12.016 35.668556184235555 139.74109688557314 12.016 35.668556184235555 139.74109688557314 17.46 35.66855176802615 139.74109756445966 17.46 35.66855176802615 139.74109756445966 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668556184235555 139.74109688557314 12.016 35.66856014858262 139.74109467181108 12.016 35.66856014858262 139.74109467181108 17.46 35.668556184235555 139.74109688557314 17.46 35.668556184235555 139.74109688557314 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856014858262 139.74109467181108 12.016 35.66856339065537 139.74109092348442 12.016 35.66856339065537 139.74109092348442 17.46 35.66856014858262 139.74109467181108 17.46 35.66856014858262 139.74109467181108 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856339065537 139.74109092348442 12.016 35.668565640524385 139.74108627052618 12.016 35.668565640524385 139.74108627052618 17.46 35.66856339065537 139.74109092348442 17.46 35.66856339065537 139.74109092348442 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668565640524385 139.74108627052618 12.016 35.66856644761312 139.74108085705294 12.016 35.66856644761312 139.74108085705294 17.46 35.668565640524385 139.74108627052618 17.46 35.668565640524385 139.74108627052618 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856644761312 139.74108085705294 12.016 35.668565992873205 139.74107556653755 12.016 35.668565992873205 139.74107556653755 17.46 35.66856644761312 139.74108085705294 17.46 35.66856644761312 139.74108085705294 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668565992873205 139.74107556653755 12.016 35.6685640961824 139.74107059801568 12.016 35.6685640961824 139.74107059801568 17.46 35.668565992873205 139.74107556653755 17.46 35.668565992873205 139.74107556653755 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6685640961824 139.74107059801568 12.016 35.66856111859755 139.74106661383263 12.016 35.66856111859755 139.74106661383263 17.46 35.6685640961824 139.74107059801568 17.46 35.6685640961824 139.74107059801568 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856111859755 139.74106661383263 12.016 35.66855724066421 139.74106396725298 12.016 35.66855724066421 139.74106396725298 17.46 35.66856111859755 139.74106661383263 17.46 35.66856111859755 139.74106661383263 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855724066421 139.74106396725298 12.016 35.66855291322954 139.74106286763188 12.016 35.66855291322954 139.74106286763188 17.46 35.66855724066421 139.74106396725298 17.46 35.66855724066421 139.74106396725298 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855291322954 139.74106286763188 12.016 35.66854849702029 139.7410635465203 12.016 35.66854849702029 139.7410635465203 17.46 35.66855291322954 139.74106286763188 17.46 35.66855291322954 139.74106286763188 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854849702029 139.7410635465203 12.016 35.66854453267382 139.7410657602836 12.016 35.66854453267382 139.7410657602836 17.46 35.66854849702029 139.7410635465203 17.46 35.66854849702029 139.7410635465203 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854453267382 139.7410657602836 17.46 35.668541290517176 139.7410693981504 17.46 35.66853831955079 139.7410740519374 17.46 35.66853796314011 139.74107945384426 17.46 35.668538688393205 139.7410848765987 17.46 35.66854058507499 139.74108983407334 17.46 35.66854356265908 139.74109381825622 17.46 35.66854744059178 139.7410964648369 17.46 35.66855176802615 139.74109756445966 17.46 35.668556184235555 139.74109688557314 17.46 35.66856014858262 139.74109467181108 17.46 35.66856339065537 139.74109092348442 17.46 35.668565640524385 139.74108627052618 17.46 35.66856644761312 139.74108085705294 17.46 35.668565992873205 139.74107556653755 17.46 35.6685640961824 139.74107059801568 17.46 35.66856111859755 139.74106661383263 17.46 35.66855724066421 139.74106396725298 17.46 35.66855291322954 139.74106286763188 17.46 35.66854849702029 139.7410635465203 17.46 35.66854453267382 139.7410657602836 17.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f519e90b-b202-480e-bdd7-98e5c3626c2c"/>
							<gml:surfaceMember xlink:href="#poly-999dbcf2-e10d-4809-aa6d-2dbbe8d5bb7b"/>
							<gml:surfaceMember xlink:href="#poly-54337ada-12ca-455d-b543-b01ef2e79106"/>
							<gml:surfaceMember xlink:href="#poly-c6d2d238-75d2-4b9f-99dd-df4d7d629e1b"/>
							<gml:surfaceMember xlink:href="#poly-760c03fc-af87-46ca-b23b-20a67f2fb84f"/>
							<gml:surfaceMember xlink:href="#poly-91a0912d-f591-46c1-94e0-f91a35641a03"/>
							<gml:surfaceMember xlink:href="#poly-a76c7425-042d-412e-8583-b18eb8f0929a"/>
							<gml:surfaceMember xlink:href="#poly-e2b49473-c216-4569-b255-cc89316e61f3"/>
							<gml:surfaceMember xlink:href="#poly-6db9cea1-bd7b-4a05-a084-926f17723024"/>
							<gml:surfaceMember xlink:href="#poly-a0ca40bc-e43d-440f-88c0-96bc8357eac3"/>
							<gml:surfaceMember xlink:href="#poly-4c5881c0-2485-4aff-87c5-a2285aa97ee8"/>
							<gml:surfaceMember xlink:href="#poly-d606772b-016b-4742-8586-4005d1945c77"/>
							<gml:surfaceMember xlink:href="#poly-df668b95-4ea3-4b24-ae42-9619f1198741"/>
							<gml:surfaceMember xlink:href="#poly-7e73d809-0725-4f2c-88d3-085635a0bd17"/>
							<gml:surfaceMember xlink:href="#poly-7ca8a045-29b3-4507-849f-22be48ff2574"/>
							<gml:surfaceMember xlink:href="#poly-1b04e447-f1fa-48c0-a4d4-7a1f095c5273"/>
							<gml:surfaceMember xlink:href="#poly-540d4222-977b-49f7-b291-05103470478d"/>
							<gml:surfaceMember xlink:href="#poly-662efb11-d07c-4b4b-bea5-4cdbf0781d7b"/>
							<gml:surfaceMember xlink:href="#poly-4023a50b-8315-45e6-a741-37496a1dd88f"/>
							<gml:surfaceMember xlink:href="#poly-bff35606-c70b-4519-a3f2-bdf29f3b9f60"/>
							<gml:surfaceMember xlink:href="#poly-cc9b02b4-eeaa-427e-91f8-200fc67b4c04"/>
							<gml:surfaceMember xlink:href="#poly-07b10f4e-d8d0-49d9-a3ff-9b541ccfc8ea"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f519e90b-b202-480e-bdd7-98e5c3626c2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f519e90b-b202-480e-bdd7-98e5c3626c2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f519e90b-b202-480e-bdd7-98e5c3626c2c">
											<gml:posList>35.66854453267382 139.74106576028356 12.016 35.668548497020275 139.7410635465203 12.016 35.668552913229504 139.7410628676319 12.016 35.66855724066421 139.74106396725296 12.016 35.66856111859755 139.74106661383263 12.016 35.66856409618237 139.74107059801568 12.016 35.66856599287319 139.74107556653755 12.016 35.66856644761314 139.74108085705294 12.016 35.66856564052434 139.74108627052618 12.016 35.66856339065537 139.74109092348442 12.016 35.66856014858259 139.74109467181108 12.016 35.66855618423556 139.74109688557314 12.016 35.66855176802614 139.74109756445966 12.016 35.668547440591745 139.7410964648369 12.016 35.66854356265904 139.74109381825622 12.016 35.668540585074986 139.74108983407334 12.016 35.668538688393205 139.7410848765987 12.016 35.66853796314012 139.74107945384426 12.016 35.668538319550784 139.7410740519374 12.016 35.66854129051717 139.74106939815036 12.016 35.66854453267382 139.74106576028356 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-999dbcf2-e10d-4809-aa6d-2dbbe8d5bb7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-999dbcf2-e10d-4809-aa6d-2dbbe8d5bb7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-999dbcf2-e10d-4809-aa6d-2dbbe8d5bb7b">
											<gml:posList>35.668552913229504 139.7410628676319 17.2 35.668548497020275 139.7410635465203 17.2 35.66854453267382 139.74106576028356 17.2 35.66854129051717 139.74106939815036 17.2 35.668538319550784 139.7410740519374 17.2 35.66853796314012 139.74107945384426 17.2 35.668538688393205 139.7410848765987 17.2 35.668540585074986 139.74108983407334 17.2 35.66854356265904 139.74109381825622 17.2 35.668547440591745 139.7410964648369 17.2 35.66855176802614 139.74109756445966 17.2 35.66855618423556 139.74109688557314 17.2 35.66856014858259 139.74109467181108 17.2 35.66856339065537 139.74109092348442 17.2 35.66856564052434 139.74108627052618 17.2 35.66856644761314 139.74108085705294 17.2 35.66856599287319 139.74107556653755 17.2 35.66856409618237 139.74107059801568 17.2 35.66856111859755 139.74106661383263 17.2 35.66855724066421 139.74106396725296 17.2 35.668552913229504 139.7410628676319 17.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54337ada-12ca-455d-b543-b01ef2e79106">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54337ada-12ca-455d-b543-b01ef2e79106">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54337ada-12ca-455d-b543-b01ef2e79106">
											<gml:posList>35.668538319550784 139.7410740519374 12.016 35.66853796314012 139.74107945384426 12.016 35.66853796314012 139.74107945384426 17.2 35.668538319550784 139.7410740519374 17.2 35.668538319550784 139.7410740519374 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6d2d238-75d2-4b9f-99dd-df4d7d629e1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6d2d238-75d2-4b9f-99dd-df4d7d629e1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6d2d238-75d2-4b9f-99dd-df4d7d629e1b">
											<gml:posList>35.66853796314012 139.74107945384426 12.016 35.668538688393205 139.7410848765987 12.016 35.668538688393205 139.7410848765987 17.2 35.66853796314012 139.74107945384426 17.2 35.66853796314012 139.74107945384426 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-760c03fc-af87-46ca-b23b-20a67f2fb84f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-760c03fc-af87-46ca-b23b-20a67f2fb84f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-760c03fc-af87-46ca-b23b-20a67f2fb84f">
											<gml:posList>35.668538688393205 139.7410848765987 12.016 35.668540585074986 139.74108983407334 12.016 35.668540585074986 139.74108983407334 17.2 35.668538688393205 139.7410848765987 17.2 35.668538688393205 139.7410848765987 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91a0912d-f591-46c1-94e0-f91a35641a03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91a0912d-f591-46c1-94e0-f91a35641a03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91a0912d-f591-46c1-94e0-f91a35641a03">
											<gml:posList>35.66854129051717 139.74106939815036 12.016 35.668538319550784 139.7410740519374 12.016 35.668538319550784 139.7410740519374 17.2 35.66854129051717 139.74106939815036 17.2 35.66854129051717 139.74106939815036 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a76c7425-042d-412e-8583-b18eb8f0929a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a76c7425-042d-412e-8583-b18eb8f0929a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a76c7425-042d-412e-8583-b18eb8f0929a">
											<gml:posList>35.668552913229504 139.7410628676319 12.016 35.668548497020275 139.7410635465203 12.016 35.668548497020275 139.7410635465203 17.2 35.668552913229504 139.7410628676319 17.2 35.668552913229504 139.7410628676319 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2b49473-c216-4569-b255-cc89316e61f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2b49473-c216-4569-b255-cc89316e61f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2b49473-c216-4569-b255-cc89316e61f3">
											<gml:posList>35.66855724066421 139.74106396725296 12.016 35.668552913229504 139.7410628676319 12.016 35.668552913229504 139.7410628676319 17.2 35.66855724066421 139.74106396725296 17.2 35.66855724066421 139.74106396725296 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6db9cea1-bd7b-4a05-a084-926f17723024">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6db9cea1-bd7b-4a05-a084-926f17723024">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6db9cea1-bd7b-4a05-a084-926f17723024">
											<gml:posList>35.668548497020275 139.7410635465203 12.016 35.66854453267382 139.74106576028356 12.016 35.66854453267382 139.74106576028356 17.2 35.668548497020275 139.7410635465203 17.2 35.668548497020275 139.7410635465203 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0ca40bc-e43d-440f-88c0-96bc8357eac3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0ca40bc-e43d-440f-88c0-96bc8357eac3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0ca40bc-e43d-440f-88c0-96bc8357eac3">
											<gml:posList>35.66856111859755 139.74106661383263 12.016 35.66855724066421 139.74106396725296 12.016 35.66855724066421 139.74106396725296 17.2 35.66856111859755 139.74106661383263 17.2 35.66856111859755 139.74106661383263 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c5881c0-2485-4aff-87c5-a2285aa97ee8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c5881c0-2485-4aff-87c5-a2285aa97ee8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c5881c0-2485-4aff-87c5-a2285aa97ee8">
											<gml:posList>35.66854453267382 139.74106576028356 12.016 35.66854129051717 139.74106939815036 12.016 35.66854129051717 139.74106939815036 17.2 35.66854453267382 139.74106576028356 17.2 35.66854453267382 139.74106576028356 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d606772b-016b-4742-8586-4005d1945c77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d606772b-016b-4742-8586-4005d1945c77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d606772b-016b-4742-8586-4005d1945c77">
											<gml:posList>35.66856409618237 139.74107059801568 12.016 35.66856111859755 139.74106661383263 12.016 35.66856111859755 139.74106661383263 17.2 35.66856409618237 139.74107059801568 17.2 35.66856409618237 139.74107059801568 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df668b95-4ea3-4b24-ae42-9619f1198741">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df668b95-4ea3-4b24-ae42-9619f1198741">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df668b95-4ea3-4b24-ae42-9619f1198741">
											<gml:posList>35.66856599287319 139.74107556653755 12.016 35.66856409618237 139.74107059801568 12.016 35.66856409618237 139.74107059801568 17.2 35.66856599287319 139.74107556653755 17.2 35.66856599287319 139.74107556653755 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e73d809-0725-4f2c-88d3-085635a0bd17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e73d809-0725-4f2c-88d3-085635a0bd17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e73d809-0725-4f2c-88d3-085635a0bd17">
											<gml:posList>35.66856644761314 139.74108085705294 12.016 35.66856599287319 139.74107556653755 12.016 35.66856599287319 139.74107556653755 17.2 35.66856644761314 139.74108085705294 17.2 35.66856644761314 139.74108085705294 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ca8a045-29b3-4507-849f-22be48ff2574">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ca8a045-29b3-4507-849f-22be48ff2574">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ca8a045-29b3-4507-849f-22be48ff2574">
											<gml:posList>35.66856564052434 139.74108627052618 12.016 35.66856644761314 139.74108085705294 12.016 35.66856644761314 139.74108085705294 17.2 35.66856564052434 139.74108627052618 17.2 35.66856564052434 139.74108627052618 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b04e447-f1fa-48c0-a4d4-7a1f095c5273">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b04e447-f1fa-48c0-a4d4-7a1f095c5273">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b04e447-f1fa-48c0-a4d4-7a1f095c5273">
											<gml:posList>35.66856339065537 139.74109092348442 12.016 35.66856564052434 139.74108627052618 12.016 35.66856564052434 139.74108627052618 17.2 35.66856339065537 139.74109092348442 17.2 35.66856339065537 139.74109092348442 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-540d4222-977b-49f7-b291-05103470478d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-540d4222-977b-49f7-b291-05103470478d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-540d4222-977b-49f7-b291-05103470478d">
											<gml:posList>35.668540585074986 139.74108983407334 12.016 35.66854356265904 139.74109381825622 12.016 35.66854356265904 139.74109381825622 17.2 35.668540585074986 139.74108983407334 17.2 35.668540585074986 139.74108983407334 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-662efb11-d07c-4b4b-bea5-4cdbf0781d7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-662efb11-d07c-4b4b-bea5-4cdbf0781d7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-662efb11-d07c-4b4b-bea5-4cdbf0781d7b">
											<gml:posList>35.66856014858259 139.74109467181108 12.016 35.66856339065537 139.74109092348442 12.016 35.66856339065537 139.74109092348442 17.2 35.66856014858259 139.74109467181108 17.2 35.66856014858259 139.74109467181108 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4023a50b-8315-45e6-a741-37496a1dd88f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4023a50b-8315-45e6-a741-37496a1dd88f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4023a50b-8315-45e6-a741-37496a1dd88f">
											<gml:posList>35.66854356265904 139.74109381825622 12.016 35.668547440591745 139.7410964648369 12.016 35.668547440591745 139.7410964648369 17.2 35.66854356265904 139.74109381825622 17.2 35.66854356265904 139.74109381825622 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bff35606-c70b-4519-a3f2-bdf29f3b9f60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bff35606-c70b-4519-a3f2-bdf29f3b9f60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bff35606-c70b-4519-a3f2-bdf29f3b9f60">
											<gml:posList>35.66855618423556 139.74109688557314 12.016 35.66856014858259 139.74109467181108 12.016 35.66856014858259 139.74109467181108 17.2 35.66855618423556 139.74109688557314 17.2 35.66855618423556 139.74109688557314 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc9b02b4-eeaa-427e-91f8-200fc67b4c04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc9b02b4-eeaa-427e-91f8-200fc67b4c04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc9b02b4-eeaa-427e-91f8-200fc67b4c04">
											<gml:posList>35.668547440591745 139.7410964648369 12.016 35.66855176802614 139.74109756445966 12.016 35.66855176802614 139.74109756445966 17.2 35.668547440591745 139.7410964648369 17.2 35.668547440591745 139.7410964648369 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07b10f4e-d8d0-49d9-a3ff-9b541ccfc8ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07b10f4e-d8d0-49d9-a3ff-9b541ccfc8ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07b10f4e-d8d0-49d9-a3ff-9b541ccfc8ea">
											<gml:posList>35.66855176802614 139.74109756445966 12.016 35.66855618423556 139.74109688557314 12.016 35.66855618423556 139.74109688557314 17.2 35.66855176802614 139.74109756445966 17.2 35.66855176802614 139.74109756445966 12.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1493</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">7.66385</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>