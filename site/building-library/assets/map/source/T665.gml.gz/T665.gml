<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c302dbbf-d8dd-434d-8b91-f0df95742c31">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">26.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670447633356474 139.74274538678773 0 35.67043644193722 139.74276220080506 0 35.67045893005515 139.7427846545622 0 35.670470112463775 139.74276784055346 0 35.670478889421034 139.74277661242655 0 35.670499672663475 139.7427973669982 0 35.670539192391836 139.74273016098053 0 35.670487775011395 139.74267819113123 0 35.670443114082225 139.74274087397006 0 35.670447633356474 139.74274538678773 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670447633356474 139.74274538678773 7.3 35.670443114082225 139.74274087397006 7.3 35.670487775011395 139.74267819113123 7.3 35.670539192391836 139.74273016098053 7.3 35.670499672663475 139.7427973669982 7.3 35.670478889421034 139.74277661242655 7.3 35.670470112463775 139.74276784055346 7.3 35.67045893005515 139.7427846545622 7.3 35.67043644193722 139.74276220080506 7.3 35.670447633356474 139.74274538678773 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670447633356474 139.74274538678773 7.3 35.67043644193722 139.74276220080506 7.3 35.67043644193722 139.74276220080506 33.88 35.670447633356474 139.74274538678773 33.88 35.670447633356474 139.74274538678773 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67043644193722 139.74276220080506 7.3 35.67045893005515 139.7427846545622 7.3 35.67045893005515 139.7427846545622 33.88 35.67043644193722 139.74276220080506 33.88 35.67043644193722 139.74276220080506 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045893005515 139.7427846545622 7.3 35.670470112463775 139.74276784055346 7.3 35.670470112463775 139.74276784055346 33.88 35.67045893005515 139.7427846545622 33.88 35.67045893005515 139.7427846545622 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670470112463775 139.74276784055346 7.3 35.670478889421034 139.74277661242655 7.3 35.670478889421034 139.74277661242655 33.88 35.670470112463775 139.74276784055346 33.88 35.670470112463775 139.74276784055346 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670478889421034 139.74277661242655 7.3 35.670499672663475 139.7427973669982 7.3 35.670499672663475 139.7427973669982 33.88 35.670478889421034 139.74277661242655 33.88 35.670478889421034 139.74277661242655 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670499672663475 139.7427973669982 7.3 35.670539192391836 139.74273016098053 7.3 35.670539192391836 139.74273016098053 33.88 35.670499672663475 139.7427973669982 33.88 35.670499672663475 139.7427973669982 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670539192391836 139.74273016098053 7.3 35.670487775011395 139.74267819113123 7.3 35.670487775011395 139.74267819113123 33.88 35.670539192391836 139.74273016098053 33.88 35.670539192391836 139.74273016098053 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670487775011395 139.74267819113123 7.3 35.670443114082225 139.74274087397006 7.3 35.670443114082225 139.74274087397006 33.88 35.670487775011395 139.74267819113123 33.88 35.670487775011395 139.74267819113123 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670443114082225 139.74274087397006 7.3 35.670447633356474 139.74274538678773 7.3 35.670447633356474 139.74274538678773 33.88 35.670443114082225 139.74274087397006 33.88 35.670443114082225 139.74274087397006 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670447633356474 139.74274538678773 33.88 35.67043644193722 139.74276220080506 33.88 35.67045893005515 139.7427846545622 33.88 35.670470112463775 139.74276784055346 33.88 35.670478889421034 139.74277661242655 33.88 35.670499672663475 139.7427973669982 33.88 35.670539192391836 139.74273016098053 33.88 35.670487775011395 139.74267819113123 33.88 35.670443114082225 139.74274087397006 33.88 35.670447633356474 139.74274538678773 33.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-40f4fe83-fddf-408f-a7b6-d0ccf16b00c1"/>
							<gml:surfaceMember xlink:href="#poly-6697f32c-f78e-49d6-888a-485f81f923cc"/>
							<gml:surfaceMember xlink:href="#poly-c7602eb4-7730-4dee-9e2d-700911426ec9"/>
							<gml:surfaceMember xlink:href="#poly-a7a8cc7f-7fe9-4a05-a0ca-0166b7f8fd46"/>
							<gml:surfaceMember xlink:href="#poly-f8d46ea2-5a43-4488-a28d-fa840bc57845"/>
							<gml:surfaceMember xlink:href="#poly-cf0f515c-8efe-4b7f-bba0-8f01727cb156"/>
							<gml:surfaceMember xlink:href="#poly-d0cf6eaf-6b7f-4c35-9ca2-67f07af58b9f"/>
							<gml:surfaceMember xlink:href="#poly-75de3f5e-d1ac-49d5-8e81-5345012cdee3"/>
							<gml:surfaceMember xlink:href="#poly-ffe24486-e447-48d4-82c6-1348ed1a3124"/>
							<gml:surfaceMember xlink:href="#poly-246a64ec-9559-4f29-be17-272885578c7f"/>
							<gml:surfaceMember xlink:href="#poly-09aaf0b7-51fd-4592-b476-e5c66409d72b"/>
							<gml:surfaceMember xlink:href="#poly-9be534ce-289b-43cc-89ca-0c37a340f04b"/>
							<gml:surfaceMember xlink:href="#poly-7b45d8c0-bf2d-4b1a-9fdd-21d1bba4d6a3"/>
							<gml:surfaceMember xlink:href="#poly-eeda7e13-4428-472f-a26d-5060fdcc9ac5"/>
							<gml:surfaceMember xlink:href="#poly-7d1943d9-10a4-4a02-ade7-06989d83a99a"/>
							<gml:surfaceMember xlink:href="#poly-37b6d6a1-15ce-48f3-9c53-d45cd78851b1"/>
							<gml:surfaceMember xlink:href="#poly-65edd63c-1118-494f-afb3-02ddf04537cf"/>
							<gml:surfaceMember xlink:href="#poly-7238f06c-32e4-4f24-8e9b-289432a1c7db"/>
							<gml:surfaceMember xlink:href="#poly-7262aa73-c54d-4213-be2e-eb4130cf6552"/>
							<gml:surfaceMember xlink:href="#poly-d374feda-a228-4c2c-b30b-c35307232465"/>
							<gml:surfaceMember xlink:href="#poly-6d629cc1-7151-43f4-bd80-5f886a2ee24f"/>
							<gml:surfaceMember xlink:href="#poly-5edc1da7-4616-48e5-97fc-3e10e86a2993"/>
							<gml:surfaceMember xlink:href="#poly-fd948171-1faf-440a-9f5f-1a4a8760752b"/>
							<gml:surfaceMember xlink:href="#poly-27f3e2ca-36a2-4a9e-ae4f-56885870ae5b"/>
							<gml:surfaceMember xlink:href="#poly-f724c239-dc1a-4f58-8584-63647d4a609a"/>
							<gml:surfaceMember xlink:href="#poly-f4eea799-a2c0-4a84-9833-7a477a97eb25"/>
							<gml:surfaceMember xlink:href="#poly-866b6d32-9ed0-4151-8b3c-174f9fb55997"/>
							<gml:surfaceMember xlink:href="#poly-cdd83c32-560e-496e-bac2-4b8e227e859d"/>
							<gml:surfaceMember xlink:href="#poly-1781b75a-650a-417c-9eb0-d4eeef0ff0cf"/>
							<gml:surfaceMember xlink:href="#poly-3d4199d6-559e-4957-ad78-525ad8039ab9"/>
							<gml:surfaceMember xlink:href="#poly-40546ee7-f548-42f5-851c-c50eeaf9a51f"/>
							<gml:surfaceMember xlink:href="#poly-2b686018-c84c-4534-b19f-ce46a887588a"/>
							<gml:surfaceMember xlink:href="#poly-bfff5486-9c7e-49a7-a3ad-4235b8024a22"/>
							<gml:surfaceMember xlink:href="#poly-3744db00-a6e5-4ee1-810b-97448e8226b4"/>
							<gml:surfaceMember xlink:href="#poly-e36d9b09-7bff-4257-8277-717d533168c5"/>
							<gml:surfaceMember xlink:href="#poly-fa3c5a43-59bf-48b6-8f53-f0e652a30d56"/>
							<gml:surfaceMember xlink:href="#poly-6055604f-b073-49da-86f2-f419e86ec9a1"/>
							<gml:surfaceMember xlink:href="#poly-ec8defc1-9acf-4382-9da7-1b37a2461c9b"/>
							<gml:surfaceMember xlink:href="#poly-73f941f9-734a-4efb-85ae-1822f9adaea7"/>
							<gml:surfaceMember xlink:href="#poly-0fa40b62-81e2-4867-aca8-3b6e24f7b5dc"/>
							<gml:surfaceMember xlink:href="#poly-9f94949c-5fde-4d53-bf26-3620b3d2d6d2"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c302dbbf-d8dd-434d-8b91-f0df95742c31_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b72823bf-6eb6-47d4-8bd2-d13657e87cd3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67048872108659 139.74270165234879 34.671 35.67050460481952 139.74271567421178 34.671 35.6704985553282 139.74272595408567 34.671 35.67048268061849 139.74271194325777 34.671 35.67048872108659 139.74270165234879 34.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f346f64c-d67f-4950-a319-29762efa6002">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052076072452 139.74273203758386 34.671 35.67051038835114 139.7427472489828 34.671 35.67050297334491 139.74273964647588 34.671 35.67051334571734 139.74272443507738 34.671 35.67052076072452 139.74273203758386 34.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-678d2ad0-4ddb-4546-915a-f26be2454ee8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67046066547625 139.74273110028165 37.754 35.67046819697167 139.74273778581158 37.754 35.67046204842718 139.7427481983463 37.754 35.670454507918606 139.7427415128261 37.754 35.67046066547625 139.74273110028165 37.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-757647a1-2c24-4af1-95d2-cdae3f51030a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-757647a1-2c24-4af1-95d2-cdae3f51030a_0">
											<gml:posList>35.67048872108659 139.74270165234879 34.671 35.67048268061849 139.74271194325777 34.671 35.67048268061849 139.74271194325777 36.021 35.67048872108659 139.74270165234879 36.021 35.67048872108659 139.74270165234879 34.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66d7878d-7ef6-452a-bc4a-f12140cb4bd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66d7878d-7ef6-452a-bc4a-f12140cb4bd4_0">
											<gml:posList>35.67048872108659 139.74270165234879 34.671 35.67048872108659 139.74270165234879 36.021 35.67050460481952 139.74271567421178 36.021 35.67050460481952 139.74271567421178 34.671 35.67048872108659 139.74270165234879 34.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c1d7104-9129-44a3-b0c6-0823c323807e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c1d7104-9129-44a3-b0c6-0823c323807e_0">
											<gml:posList>35.6704985553282 139.74272595408567 36.021 35.67050460481952 139.74271567421178 36.021 35.67048872108659 139.74270165234879 36.021 35.67048268061849 139.74271194325777 36.021 35.6704985553282 139.74272595408567 36.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c26a2982-f5d8-403c-8d9e-7e94ff8f0833">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c26a2982-f5d8-403c-8d9e-7e94ff8f0833_0">
											<gml:posList>35.6704985553282 139.74272595408567 34.671 35.6704985553282 139.74272595408567 36.021 35.67048268061849 139.74271194325777 36.021 35.67048268061849 139.74271194325777 34.671 35.6704985553282 139.74272595408567 34.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14950767-0058-45f3-a1a1-420f69165b92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14950767-0058-45f3-a1a1-420f69165b92_0">
											<gml:posList>35.67050460481952 139.74271567421178 34.671 35.67050460481952 139.74271567421178 36.021 35.6704985553282 139.74272595408567 36.021 35.6704985553282 139.74272595408567 34.671 35.67050460481952 139.74271567421178 34.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8498a1ca-a04a-489f-888d-c7d1296b717d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8498a1ca-a04a-489f-888d-c7d1296b717d_0">
											<gml:posList>35.67051334571734 139.74272443507738 34.671 35.67051334571734 139.74272443507738 36.021 35.67052076072452 139.74273203758386 36.021 35.67052076072452 139.74273203758386 34.671 35.67051334571734 139.74272443507738 34.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edf3650e-a8ca-4b5d-ac8b-1a140b25cfda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edf3650e-a8ca-4b5d-ac8b-1a140b25cfda_0">
											<gml:posList>35.67050297334491 139.74273964647588 34.671 35.67050297334491 139.74273964647588 36.021 35.67051334571734 139.74272443507738 36.021 35.67051334571734 139.74272443507738 34.671 35.67050297334491 139.74273964647588 34.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cf050f5-76a5-4041-b5e9-46492c67fb2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cf050f5-76a5-4041-b5e9-46492c67fb2e_0">
											<gml:posList>35.67046066547625 139.74273110028165 40.587 35.67046819697167 139.74273778581158 40.587 35.67046819697167 139.74273778581158 37.754 35.67046066547625 139.74273110028165 37.754 35.67046066547625 139.74273110028165 40.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46c68a30-b27b-41c5-bf66-ed69391c830d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46c68a30-b27b-41c5-bf66-ed69391c830d_0">
											<gml:posList>35.67052076072452 139.74273203758386 36.021 35.67051334571734 139.74272443507738 36.021 35.67050297334491 139.74273964647588 36.021 35.67051038835114 139.7427472489828 36.021 35.67052076072452 139.74273203758386 36.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b1f5f8d-6939-418c-b700-a63866d7610d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b1f5f8d-6939-418c-b700-a63866d7610d_0">
											<gml:posList>35.670454507918606 139.7427415128261 37.754 35.670454507918606 139.7427415128261 40.587 35.67046066547625 139.74273110028165 40.587 35.67046066547625 139.74273110028165 37.754 35.670454507918606 139.7427415128261 37.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12bf89ef-ff0b-448b-89ae-6fc64248fdc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12bf89ef-ff0b-448b-89ae-6fc64248fdc1_0">
											<gml:posList>35.67046204842718 139.7427481983463 40.587 35.67046819697167 139.74273778581158 40.587 35.67046066547625 139.74273110028165 40.587 35.670454507918606 139.7427415128261 40.587 35.67046204842718 139.7427481983463 40.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-950cd015-06ed-4e2e-aad3-8cfe99cedef3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-950cd015-06ed-4e2e-aad3-8cfe99cedef3_0">
											<gml:posList>35.67051038835114 139.7427472489828 34.671 35.67052076072452 139.74273203758386 34.671 35.67052076072452 139.74273203758386 36.021 35.67051038835114 139.7427472489828 36.021 35.67051038835114 139.7427472489828 34.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37da6a56-0e71-4352-bb78-6dfc74a3e954">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37da6a56-0e71-4352-bb78-6dfc74a3e954_0">
											<gml:posList>35.67046819697167 139.74273778581158 37.754 35.67046819697167 139.74273778581158 40.587 35.67046204842718 139.7427481983463 40.587 35.67046204842718 139.7427481983463 37.754 35.67046819697167 139.74273778581158 37.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-452e96e9-d292-4b47-8cce-986c0b1fd69d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-452e96e9-d292-4b47-8cce-986c0b1fd69d_0">
											<gml:posList>35.67051038835114 139.7427472489828 34.671 35.67051038835114 139.7427472489828 36.021 35.67050297334491 139.74273964647588 36.021 35.67050297334491 139.74273964647588 34.671 35.67051038835114 139.7427472489828 34.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-431518ec-2e61-4720-b8e6-00e8b8b05bf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-431518ec-2e61-4720-b8e6-00e8b8b05bf9_0">
											<gml:posList>35.67046204842718 139.7427481983463 40.587 35.670454507918606 139.7427415128261 40.587 35.670454507918606 139.7427415128261 37.754 35.67046204842718 139.7427481983463 37.754 35.67046204842718 139.7427481983463 40.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-40f4fe83-fddf-408f-a7b6-d0ccf16b00c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40f4fe83-fddf-408f-a7b6-d0ccf16b00c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40f4fe83-fddf-408f-a7b6-d0ccf16b00c1">
											<gml:posList>35.67053919239182 139.7427301609805 7.3 35.67049967266346 139.74279736699816 7.3 35.67047888942104 139.74277661242655 7.3 35.67047011246376 139.74276784055346 7.3 35.67044763335647 139.74274538678773 7.3 35.670443114082204 139.74274087397004 7.3 35.670487775011395 139.74267819113123 7.3 35.67053919239182 139.7427301609805 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6697f32c-f78e-49d6-888a-485f81f923cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6697f32c-f78e-49d6-888a-485f81f923cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6697f32c-f78e-49d6-888a-485f81f923cc">
											<gml:posList>35.67044763335647 139.74274538678773 7.3 35.67047011246376 139.74276784055346 7.3 35.67045893005513 139.74278465456217 7.3 35.67043644193721 139.74276220080506 7.3 35.67044763335647 139.74274538678773 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c7602eb4-7730-4dee-9e2d-700911426ec9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7602eb4-7730-4dee-9e2d-700911426ec9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7602eb4-7730-4dee-9e2d-700911426ec9">
											<gml:posList>35.67045885495159 139.74272076301838 35.1 35.67045734075416 139.74272090833117 35.1 35.670458188684194 139.7427217579357 35.1 35.67045885495159 139.74272076301838 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7a8cc7f-7fe9-4a05-a0ca-0166b7f8fd46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7a8cc7f-7fe9-4a05-a0ca-0166b7f8fd46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7a8cc7f-7fe9-4a05-a0ca-0166b7f8fd46">
											<gml:posList>35.67047075166545 139.74276681252812 35.1 35.670470085405974 139.74276781849147 35.1 35.67047157252906 139.74276762902505 35.1 35.67047075166545 139.74276681252812 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8d46ea2-5a43-4488-a28d-fa840bc57845">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8d46ea2-5a43-4488-a28d-fa840bc57845">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8d46ea2-5a43-4488-a28d-fa840bc57845">
											<gml:posList>35.67043644193721 139.74276220080506 31.935 35.67044190835782 139.74276765148645 31.935 35.670447373439764 139.74275933851905 31.935 35.67044188008563 139.74275403146973 31.935 35.67043644193721 139.74276220080506 31.935</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf0f515c-8efe-4b7f-bba0-8f01727cb156">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf0f515c-8efe-4b7f-bba0-8f01727cb156">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf0f515c-8efe-4b7f-bba0-8f01727cb156">
											<gml:posList>35.67044763335647 139.74274538678773 31.935 35.67044188008563 139.74275403146973 31.935 35.670447373439764 139.74275933851905 31.935 35.67045300958244 139.7427507602468 31.935 35.67044763335647 139.74274538678773 31.935</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0cf6eaf-6b7f-4c35-9ca2-67f07af58b9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0cf6eaf-6b7f-4c35-9ca2-67f07af58b9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0cf6eaf-6b7f-4c35-9ca2-67f07af58b9f">
											<gml:posList>35.670443114082204 139.74274087397004 38.27 35.67044405144293 139.74274078454079 38.27 35.67045742271722 139.74272202391182 38.27 35.67045734075416 139.74272090833117 38.27 35.670443114082204 139.74274087397004 38.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-75de3f5e-d1ac-49d5-8e81-5345012cdee3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75de3f5e-d1ac-49d5-8e81-5345012cdee3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75de3f5e-d1ac-49d5-8e81-5345012cdee3">
											<gml:posList>35.67044190835782 139.74276765148645 31.935 35.67045890300566 139.74278464354646 30.913 35.67046463826784 139.7427760209777 30.913 35.670447373439764 139.74275933851905 31.935 35.67044190835782 139.74276765148645 31.935</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ffe24486-e447-48d4-82c6-1348ed1a3124">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffe24486-e447-48d4-82c6-1348ed1a3124">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffe24486-e447-48d4-82c6-1348ed1a3124">
											<gml:posList>35.670470085405974 139.74276781849147 38.27 35.67046998539927 139.74276668083843 38.27 35.67044405144293 139.74274078454079 38.27 35.670443114082204 139.74274087397004 38.27 35.670470085405974 139.74276781849147 38.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-246a64ec-9559-4f29-be17-272885578c7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-246a64ec-9559-4f29-be17-272885578c7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-246a64ec-9559-4f29-be17-272885578c7f">
											<gml:posList>35.67045300958244 139.7427507602468 31.935 35.670447373439764 139.74275933851905 31.935 35.67046463826784 139.7427760209777 32.703 35.670470094419706 139.7427678184813 32.703 35.67045300958244 139.7427507602468 31.935</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09aaf0b7-51fd-4592-b476-e5c66409d72b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09aaf0b7-51fd-4592-b476-e5c66409d72b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09aaf0b7-51fd-4592-b476-e5c66409d72b">
											<gml:posList>35.67046998539927 139.74276668083843 37.754 35.67048281545527 139.74274739059803 37.754 35.67045742271722 139.74272202391182 37.754 35.67044405144293 139.74274078454079 37.754 35.67046998539927 139.74276668083843 37.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9be534ce-289b-43cc-89ca-0c37a340f04b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9be534ce-289b-43cc-89ca-0c37a340f04b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9be534ce-289b-43cc-89ca-0c37a340f04b">
											<gml:posList>35.67045734075416 139.74272090833117 38.27 35.67045742271722 139.74272202391182 38.27 35.67048281545527 139.74274739059803 38.27 35.67048374379397 139.7427472901327 38.27 35.67045734075416 139.74272090833117 38.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b45d8c0-bf2d-4b1a-9fdd-21d1bba4d6a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b45d8c0-bf2d-4b1a-9fdd-21d1bba4d6a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b45d8c0-bf2d-4b1a-9fdd-21d1bba4d6a3">
											<gml:posList>35.67045734075416 139.74272090833117 35.1 35.67045885495159 139.74272076301838 35.1 35.67048789355367 139.74268000258618 35.1 35.670487775011395 139.74267819113123 35.1 35.67045734075416 139.74272090833117 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eeda7e13-4428-472f-a26d-5060fdcc9ac5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eeda7e13-4428-472f-a26d-5060fdcc9ac5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eeda7e13-4428-472f-a26d-5060fdcc9ac5">
											<gml:posList>35.67048374379397 139.7427472901327 38.27 35.67048281545527 139.74274739059803 38.27 35.67046998539927 139.74276668083843 38.27 35.670470085405974 139.74276781849147 38.27 35.67048374379397 139.7427472901327 38.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d1943d9-10a4-4a02-ade7-06989d83a99a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d1943d9-10a4-4a02-ade7-06989d83a99a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d1943d9-10a4-4a02-ade7-06989d83a99a">
											<gml:posList>35.67047157252906 139.74276762902505 35.1 35.670470085405974 139.74276781849147 35.1 35.67047888942104 139.74277661242655 35.1 35.67049967266346 139.74279736699816 35.1 35.670499463935876 139.74279548936693 35.1 35.67047157252906 139.74276762902505 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37b6d6a1-15ce-48f3-9c53-d45cd78851b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37b6d6a1-15ce-48f3-9c53-d45cd78851b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37b6d6a1-15ce-48f3-9c53-d45cd78851b1">
											<gml:posList>35.67048374379397 139.7427472901327 34.671 35.67047075166545 139.74276681252812 34.671 35.67047157252906 139.74276762902505 34.671 35.670499463935876 139.74279548936693 34.671 35.67053775037067 139.74273039458197 34.671 35.67048789355367 139.74268000258618 34.671 35.67045885495159 139.74272076301838 34.671 35.670458188684194 139.7427217579357 34.671 35.67048374379397 139.7427472901327 34.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65edd63c-1118-494f-afb3-02ddf04537cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65edd63c-1118-494f-afb3-02ddf04537cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65edd63c-1118-494f-afb3-02ddf04537cf">
											<gml:posList>35.670487775011395 139.74267819113123 35.1 35.67048789355367 139.74268000258618 35.1 35.67053775037067 139.74273039458197 35.1 35.67053919239182 139.7427301609805 35.1 35.670487775011395 139.74267819113123 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7238f06c-32e4-4f24-8e9b-289432a1c7db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7238f06c-32e4-4f24-8e9b-289432a1c7db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7238f06c-32e4-4f24-8e9b-289432a1c7db">
											<gml:posList>35.67053919239182 139.7427301609805 35.1 35.67053775037067 139.74273039458197 35.1 35.670499463935876 139.74279548936693 35.1 35.67049967266346 139.74279736699816 35.1 35.67053919239182 139.7427301609805 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7262aa73-c54d-4213-be2e-eb4130cf6552">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7262aa73-c54d-4213-be2e-eb4130cf6552">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7262aa73-c54d-4213-be2e-eb4130cf6552">
											<gml:posList>35.67046998539927 139.74276668083843 38.27 35.67046998539927 139.74276668083843 37.754 35.67044405144293 139.74274078454079 37.754 35.67044405144293 139.74274078454079 38.27 35.67046998539927 139.74276668083843 38.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d374feda-a228-4c2c-b30b-c35307232465">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d374feda-a228-4c2c-b30b-c35307232465">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d374feda-a228-4c2c-b30b-c35307232465">
											<gml:posList>35.67045742271722 139.74272202391182 38.27 35.67045742271722 139.74272202391182 37.754 35.67048281545527 139.74274739059803 37.754 35.67048281545527 139.74274739059803 38.27 35.67045742271722 139.74272202391182 38.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d629cc1-7151-43f4-bd80-5f886a2ee24f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d629cc1-7151-43f4-bd80-5f886a2ee24f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d629cc1-7151-43f4-bd80-5f886a2ee24f">
											<gml:posList>35.67045885495159 139.74272076301838 35.1 35.67045885495159 139.74272076301838 34.671 35.67048789355367 139.74268000258618 34.671 35.67048789355367 139.74268000258618 35.1 35.67045885495159 139.74272076301838 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5edc1da7-4616-48e5-97fc-3e10e86a2993">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5edc1da7-4616-48e5-97fc-3e10e86a2993">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5edc1da7-4616-48e5-97fc-3e10e86a2993">
											<gml:posList>35.67053919239182 139.7427301609805 7.3 35.670487775011395 139.74267819113123 7.3 35.670487775011395 139.74267819113123 35.1 35.67053919239182 139.7427301609805 35.1 35.67053919239182 139.7427301609805 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd948171-1faf-440a-9f5f-1a4a8760752b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd948171-1faf-440a-9f5f-1a4a8760752b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd948171-1faf-440a-9f5f-1a4a8760752b">
											<gml:posList>35.67048789355367 139.74268000258618 35.1 35.67048789355367 139.74268000258618 34.671 35.67053775037067 139.74273039458197 34.671 35.67053775037067 139.74273039458197 35.1 35.67048789355367 139.74268000258618 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27f3e2ca-36a2-4a9e-ae4f-56885870ae5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27f3e2ca-36a2-4a9e-ae4f-56885870ae5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27f3e2ca-36a2-4a9e-ae4f-56885870ae5b">
											<gml:posList>35.670443114082204 139.74274087397004 31.935 35.670443114082204 139.74274087397004 38.27 35.67045734075416 139.74272090833117 38.27 35.67045734075416 139.74272090833117 35.1 35.670487775011395 139.74267819113123 35.1 35.670487775011395 139.74267819113123 7.3 35.670443114082204 139.74274087397004 7.3 35.670443114082204 139.74274087397004 31.935</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f724c239-dc1a-4f58-8584-63647d4a609a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f724c239-dc1a-4f58-8584-63647d4a609a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f724c239-dc1a-4f58-8584-63647d4a609a">
											<gml:posList>35.670458188684194 139.7427217579357 35.1 35.670458188684194 139.7427217579357 34.671 35.67045885495159 139.74272076301838 34.671 35.67045885495159 139.74272076301838 35.1 35.670458188684194 139.7427217579357 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4eea799-a2c0-4a84-9833-7a477a97eb25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4eea799-a2c0-4a84-9833-7a477a97eb25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4eea799-a2c0-4a84-9833-7a477a97eb25">
											<gml:posList>35.67044405144293 139.74274078454079 38.27 35.67044405144293 139.74274078454079 37.754 35.67045742271722 139.74272202391182 37.754 35.67045742271722 139.74272202391182 38.27 35.67044405144293 139.74274078454079 38.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-866b6d32-9ed0-4151-8b3c-174f9fb55997">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-866b6d32-9ed0-4151-8b3c-174f9fb55997">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-866b6d32-9ed0-4151-8b3c-174f9fb55997">
											<gml:posList>35.670458188684194 139.7427217579357 35.1 35.67045734075416 139.74272090833117 35.1 35.67045734075416 139.74272090833117 38.27 35.67048374379397 139.7427472901327 38.27 35.67048374379397 139.7427472901327 34.671 35.670458188684194 139.7427217579357 34.671 35.670458188684194 139.7427217579357 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdd83c32-560e-496e-bac2-4b8e227e859d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdd83c32-560e-496e-bac2-4b8e227e859d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdd83c32-560e-496e-bac2-4b8e227e859d">
											<gml:posList>35.670443114082204 139.74274087397004 7.3 35.67044763335647 139.74274538678773 7.3 35.67044763335647 139.74274538678773 31.935 35.670443114082204 139.74274087397004 31.935 35.670443114082204 139.74274087397004 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1781b75a-650a-417c-9eb0-d4eeef0ff0cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1781b75a-650a-417c-9eb0-d4eeef0ff0cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1781b75a-650a-417c-9eb0-d4eeef0ff0cf">
											<gml:posList>35.67043644193721 139.74276220080506 7.3 35.67043644193721 139.74276220080506 31.935 35.67044188008563 139.74275403146973 31.935 35.67044763335647 139.74274538678773 31.935 35.67044763335647 139.74274538678773 7.3 35.67043644193721 139.74276220080506 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d4199d6-559e-4957-ad78-525ad8039ab9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d4199d6-559e-4957-ad78-525ad8039ab9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d4199d6-559e-4957-ad78-525ad8039ab9">
											<gml:posList>35.67048281545527 139.74274739059803 38.27 35.67048281545527 139.74274739059803 37.754 35.67046998539927 139.74276668083843 37.754 35.67046998539927 139.74276668083843 38.27 35.67048281545527 139.74274739059803 38.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40546ee7-f548-42f5-851c-c50eeaf9a51f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40546ee7-f548-42f5-851c-c50eeaf9a51f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40546ee7-f548-42f5-851c-c50eeaf9a51f">
											<gml:posList>35.67048374379397 139.7427472901327 34.671 35.67048374379397 139.7427472901327 38.27 35.670470085405974 139.74276781849147 38.27 35.670470085405974 139.74276781849147 35.1 35.67047075166545 139.74276681252812 35.1 35.67047075166545 139.74276681252812 34.671 35.67048374379397 139.7427472901327 34.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b686018-c84c-4534-b19f-ce46a887588a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b686018-c84c-4534-b19f-ce46a887588a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b686018-c84c-4534-b19f-ce46a887588a">
											<gml:posList>35.670470085405974 139.74276781849147 35.1 35.670470085405974 139.74276781849147 38.27 35.670443114082204 139.74274087397004 38.27 35.670443114082204 139.74274087397004 31.935 35.67044763335647 139.74274538678773 31.935 35.67045300958244 139.7427507602468 31.935 35.670470094419706 139.7427678184813 32.703 35.67047888942104 139.74277661242655 32.703 35.67047888942104 139.74277661242655 35.1 35.670470085405974 139.74276781849147 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfff5486-9c7e-49a7-a3ad-4235b8024a22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfff5486-9c7e-49a7-a3ad-4235b8024a22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfff5486-9c7e-49a7-a3ad-4235b8024a22">
											<gml:posList>35.67053775037067 139.74273039458197 35.1 35.67053775037067 139.74273039458197 34.671 35.670499463935876 139.74279548936693 34.671 35.670499463935876 139.74279548936693 35.1 35.67053775037067 139.74273039458197 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3744db00-a6e5-4ee1-810b-97448e8226b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3744db00-a6e5-4ee1-810b-97448e8226b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3744db00-a6e5-4ee1-810b-97448e8226b4">
											<gml:posList>35.67049967266346 139.74279736699816 7.3 35.67053919239182 139.7427301609805 7.3 35.67053919239182 139.7427301609805 35.1 35.67049967266346 139.74279736699816 35.1 35.67049967266346 139.74279736699816 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e36d9b09-7bff-4257-8277-717d533168c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e36d9b09-7bff-4257-8277-717d533168c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e36d9b09-7bff-4257-8277-717d533168c5">
											<gml:posList>35.67047157252906 139.74276762902505 35.1 35.67047157252906 139.74276762902505 34.671 35.67047075166545 139.74276681252812 34.671 35.67047075166545 139.74276681252812 35.1 35.67047157252906 139.74276762902505 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa3c5a43-59bf-48b6-8f53-f0e652a30d56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa3c5a43-59bf-48b6-8f53-f0e652a30d56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa3c5a43-59bf-48b6-8f53-f0e652a30d56">
											<gml:posList>35.670447373439764 139.74275933851905 31.935 35.67046463826784 139.7427760209777 30.913 35.67046463826784 139.7427760209777 32.703 35.670447373439764 139.74275933851905 31.935</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6055604f-b073-49da-86f2-f419e86ec9a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6055604f-b073-49da-86f2-f419e86ec9a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6055604f-b073-49da-86f2-f419e86ec9a1">
											<gml:posList>35.67047888942104 139.74277661242655 7.3 35.67047888942104 139.74277661242655 32.703 35.670470094419706 139.7427678184813 32.703 35.67047011246376 139.74276784055346 7.3 35.67047888942104 139.74277661242655 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec8defc1-9acf-4382-9da7-1b37a2461c9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec8defc1-9acf-4382-9da7-1b37a2461c9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec8defc1-9acf-4382-9da7-1b37a2461c9b">
											<gml:posList>35.67045893005513 139.74278465456217 7.3 35.67045890300566 139.74278464354646 30.913 35.67044190835782 139.74276765148645 31.935 35.67043644193721 139.74276220080506 31.935 35.67043644193721 139.74276220080506 7.3 35.67045893005513 139.74278465456217 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73f941f9-734a-4efb-85ae-1822f9adaea7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73f941f9-734a-4efb-85ae-1822f9adaea7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73f941f9-734a-4efb-85ae-1822f9adaea7">
											<gml:posList>35.67047011246376 139.74276784055346 7.3 35.670470094419706 139.7427678184813 32.703 35.67046463826784 139.7427760209777 32.703 35.67046463826784 139.7427760209777 30.913 35.67045890300566 139.74278464354646 30.913 35.67045893005513 139.74278465456217 7.3 35.67047011246376 139.74276784055346 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fa40b62-81e2-4867-aca8-3b6e24f7b5dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fa40b62-81e2-4867-aca8-3b6e24f7b5dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fa40b62-81e2-4867-aca8-3b6e24f7b5dc">
											<gml:posList>35.670499463935876 139.74279548936693 35.1 35.670499463935876 139.74279548936693 34.671 35.67047157252906 139.74276762902505 34.671 35.67047157252906 139.74276762902505 35.1 35.670499463935876 139.74279548936693 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f94949c-5fde-4d53-bf26-3620b3d2d6d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f94949c-5fde-4d53-bf26-3620b3d2d6d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f94949c-5fde-4d53-bf26-3620b3d2d6d2">
											<gml:posList>35.67049967266346 139.74279736699816 35.1 35.67047888942104 139.74277661242655 35.1 35.67047888942104 139.74277661242655 32.703 35.67047888942104 139.74277661242655 7.3 35.67049967266346 139.74279736699816 7.3 35.67049967266346 139.74279736699816 35.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8976</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">59.0365</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.27</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>