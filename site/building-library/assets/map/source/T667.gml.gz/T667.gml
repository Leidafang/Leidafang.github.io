<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c3931e0f-5737-4c45-99d3-b5fcda9de299">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66821299722042 139.73779299163988 0 35.668222395618265 139.73782338997466 0 35.66824979628935 139.73781066552218 0 35.66824038887456 139.73778026718924 0 35.66821299722042 139.73779299163988 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66821299722042 139.73779299163988 28.884 35.66824038887456 139.73778026718924 28.884 35.66824979628935 139.73781066552218 28.884 35.668222395618265 139.73782338997466 28.884 35.66821299722042 139.73779299163988 28.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66821299722042 139.73779299163988 28.884 35.668222395618265 139.73782338997466 28.884 35.668222395618265 139.73782338997466 31.884 35.66821299722042 139.73779299163988 31.884 35.66821299722042 139.73779299163988 28.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668222395618265 139.73782338997466 28.884 35.66824979628935 139.73781066552218 28.884 35.66824979628935 139.73781066552218 31.884 35.668222395618265 139.73782338997466 31.884 35.668222395618265 139.73782338997466 28.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66824979628935 139.73781066552218 28.884 35.66824038887456 139.73778026718924 28.884 35.66824038887456 139.73778026718924 31.884 35.66824979628935 139.73781066552218 31.884 35.66824979628935 139.73781066552218 28.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66824038887456 139.73778026718924 28.884 35.66821299722042 139.73779299163988 28.884 35.66821299722042 139.73779299163988 31.884 35.66824038887456 139.73778026718924 31.884 35.66824038887456 139.73778026718924 28.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66821299722042 139.73779299163988 31.884 35.668222395618265 139.73782338997466 31.884 35.66824979628935 139.73781066552218 31.884 35.66824038887456 139.73778026718924 31.884 35.66821299722042 139.73779299163988 31.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2c4e12b1-70d6-4c19-a0b7-d2029bf12ad6"/>
							<gml:surfaceMember xlink:href="#poly-d058aa32-d18e-4aca-8d46-b9979cb07b50"/>
							<gml:surfaceMember xlink:href="#poly-788071fe-9afc-4294-bec0-cdceef433824"/>
							<gml:surfaceMember xlink:href="#poly-7104d882-8596-4189-b2ae-d09d63e3089b"/>
							<gml:surfaceMember xlink:href="#poly-c4f94e6d-4101-4382-9072-733d05c01271"/>
							<gml:surfaceMember xlink:href="#poly-225ab2ae-ffe6-4cd6-939f-ef9214560fc3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2c4e12b1-70d6-4c19-a0b7-d2029bf12ad6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c4e12b1-70d6-4c19-a0b7-d2029bf12ad6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c4e12b1-70d6-4c19-a0b7-d2029bf12ad6">
											<gml:posList>35.668212997220394 139.73779299163988 28.884 35.668240388874544 139.73778026718924 28.884 35.66824979628931 139.73781066552218 28.884 35.66822239561826 139.73782338997466 28.884 35.668212997220394 139.73779299163988 28.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d058aa32-d18e-4aca-8d46-b9979cb07b50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d058aa32-d18e-4aca-8d46-b9979cb07b50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d058aa32-d18e-4aca-8d46-b9979cb07b50">
											<gml:posList>35.668240388874544 139.73778026718924 31.909 35.668212997220394 139.73779299163988 31.909 35.66822239561826 139.73782338997466 31.909 35.66824979628931 139.73781066552218 31.909 35.668240388874544 139.73778026718924 31.909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-788071fe-9afc-4294-bec0-cdceef433824">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-788071fe-9afc-4294-bec0-cdceef433824">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-788071fe-9afc-4294-bec0-cdceef433824">
											<gml:posList>35.668240388874544 139.73778026718924 28.884 35.668212997220394 139.73779299163988 28.884 35.668212997220394 139.73779299163988 31.909 35.668240388874544 139.73778026718924 31.909 35.668240388874544 139.73778026718924 28.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7104d882-8596-4189-b2ae-d09d63e3089b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7104d882-8596-4189-b2ae-d09d63e3089b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7104d882-8596-4189-b2ae-d09d63e3089b">
											<gml:posList>35.66824979628931 139.73781066552218 28.884 35.668240388874544 139.73778026718924 28.884 35.668240388874544 139.73778026718924 31.909 35.66824979628931 139.73781066552218 31.909 35.66824979628931 139.73781066552218 28.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4f94e6d-4101-4382-9072-733d05c01271">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4f94e6d-4101-4382-9072-733d05c01271">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4f94e6d-4101-4382-9072-733d05c01271">
											<gml:posList>35.668212997220394 139.73779299163988 28.884 35.66822239561826 139.73782338997466 28.884 35.66822239561826 139.73782338997466 31.909 35.668212997220394 139.73779299163988 31.909 35.668212997220394 139.73779299163988 28.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-225ab2ae-ffe6-4cd6-939f-ef9214560fc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-225ab2ae-ffe6-4cd6-939f-ef9214560fc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-225ab2ae-ffe6-4cd6-939f-ef9214560fc3">
											<gml:posList>35.66822239561826 139.73782338997466 28.884 35.66824979628931 139.73781066552218 28.884 35.66824979628931 139.73781066552218 31.909 35.66822239561826 139.73782338997466 31.909 35.66822239561826 139.73782338997466 28.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8136</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">3</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>