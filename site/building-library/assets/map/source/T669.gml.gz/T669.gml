<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c3d31a8c-fee1-4250-9dff-3d20e2be2988">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66731001636424 139.74262622333322 0 35.66731850200134 139.74263115122378 0 35.66733127666321 139.74259817598838 0 35.667322791016524 139.7425932370547 0 35.66731001636424 139.74262622333322 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66731001636424 139.74262622333322 30.474 35.667322791016524 139.7425932370547 30.474 35.66733127666321 139.74259817598838 30.474 35.66731850200134 139.74263115122378 30.474 35.66731001636424 139.74262622333322 30.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66731001636424 139.74262622333322 30.474 35.66731850200134 139.74263115122378 30.474 35.66731850200134 139.74263115122378 33.474000000000004 35.66731001636424 139.74262622333322 33.474000000000004 35.66731001636424 139.74262622333322 30.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66731850200134 139.74263115122378 30.474 35.66733127666321 139.74259817598838 30.474 35.66733127666321 139.74259817598838 33.474000000000004 35.66731850200134 139.74263115122378 33.474000000000004 35.66731850200134 139.74263115122378 30.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66733127666321 139.74259817598838 30.474 35.667322791016524 139.7425932370547 30.474 35.667322791016524 139.7425932370547 33.474000000000004 35.66733127666321 139.74259817598838 33.474000000000004 35.66733127666321 139.74259817598838 30.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667322791016524 139.7425932370547 30.474 35.66731001636424 139.74262622333322 30.474 35.66731001636424 139.74262622333322 33.474000000000004 35.667322791016524 139.7425932370547 33.474000000000004 35.667322791016524 139.7425932370547 30.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66731001636424 139.74262622333322 33.474000000000004 35.66731850200134 139.74263115122378 33.474000000000004 35.66733127666321 139.74259817598838 33.474000000000004 35.667322791016524 139.7425932370547 33.474000000000004 35.66731001636424 139.74262622333322 33.474000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-81de80d5-acce-4e5b-9012-248805e2aee9"/>
							<gml:surfaceMember xlink:href="#poly-fa064611-aee5-499d-b6ff-16f78d60ee44"/>
							<gml:surfaceMember xlink:href="#poly-0970817b-a4b5-4be7-8cc9-c978d6c87073"/>
							<gml:surfaceMember xlink:href="#poly-c4a07947-bf8c-4ec9-8f6d-241cb7219e39"/>
							<gml:surfaceMember xlink:href="#poly-7ebd34e4-7ee7-419d-a328-18867140966d"/>
							<gml:surfaceMember xlink:href="#poly-be743de7-1137-4c7e-825a-f2b43bdbfc5b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-81de80d5-acce-4e5b-9012-248805e2aee9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81de80d5-acce-4e5b-9012-248805e2aee9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81de80d5-acce-4e5b-9012-248805e2aee9">
											<gml:posList>35.66731001636424 139.7426262233332 30.474 35.667322791016524 139.74259323705468 30.474 35.66733127666324 139.74259817598838 30.474 35.66731850200131 139.74263115122378 30.474 35.66731001636424 139.7426262233332 30.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa064611-aee5-499d-b6ff-16f78d60ee44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa064611-aee5-499d-b6ff-16f78d60ee44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa064611-aee5-499d-b6ff-16f78d60ee44">
											<gml:posList>35.667322791016524 139.74259323705468 32.1 35.66731001636424 139.7426262233332 32.1 35.66731850200131 139.74263115122378 32.1 35.66733127666324 139.74259817598838 32.1 35.667322791016524 139.74259323705468 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0970817b-a4b5-4be7-8cc9-c978d6c87073">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0970817b-a4b5-4be7-8cc9-c978d6c87073">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0970817b-a4b5-4be7-8cc9-c978d6c87073">
											<gml:posList>35.66733127666324 139.74259817598838 30.474 35.667322791016524 139.74259323705468 30.474 35.667322791016524 139.74259323705468 32.1 35.66733127666324 139.74259817598838 32.1 35.66733127666324 139.74259817598838 30.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4a07947-bf8c-4ec9-8f6d-241cb7219e39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4a07947-bf8c-4ec9-8f6d-241cb7219e39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4a07947-bf8c-4ec9-8f6d-241cb7219e39">
											<gml:posList>35.667322791016524 139.74259323705468 30.474 35.66731001636424 139.7426262233332 30.474 35.66731001636424 139.7426262233332 32.1 35.667322791016524 139.74259323705468 32.1 35.667322791016524 139.74259323705468 30.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ebd34e4-7ee7-419d-a328-18867140966d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ebd34e4-7ee7-419d-a328-18867140966d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ebd34e4-7ee7-419d-a328-18867140966d">
											<gml:posList>35.66731850200131 139.74263115122378 30.474 35.66733127666324 139.74259817598838 30.474 35.66733127666324 139.74259817598838 32.1 35.66731850200131 139.74263115122378 32.1 35.66731850200131 139.74263115122378 30.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be743de7-1137-4c7e-825a-f2b43bdbfc5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be743de7-1137-4c7e-825a-f2b43bdbfc5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be743de7-1137-4c7e-825a-f2b43bdbfc5b">
											<gml:posList>35.66731001636424 139.7426262233332 30.474 35.66731850200131 139.74263115122378 30.474 35.66731850200131 139.74263115122378 32.1 35.66731001636424 139.7426262233332 32.1 35.66731001636424 139.7426262233332 30.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4775</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>