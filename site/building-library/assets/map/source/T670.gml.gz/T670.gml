<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c3d6fcf2-b5bd-4ec5-b9e7-d75b5dab2d97">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二・六丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672096483203774 139.73763554674505 0 35.6721254599376 139.73762118484697 0 35.672119478436244 139.73760305363686 0 35.672090501704545 139.7376174155404 0 35.672096483203774 139.73763554674505 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672096483203774 139.73763554674505 10.017 35.672090501704545 139.7376174155404 10.017 35.672119478436244 139.73760305363686 10.017 35.6721254599376 139.73762118484697 10.017 35.672096483203774 139.73763554674505 10.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672096483203774 139.73763554674505 10.017 35.6721254599376 139.73762118484697 10.017 35.6721254599376 139.73762118484697 13.017 35.672096483203774 139.73763554674505 13.017 35.672096483203774 139.73763554674505 10.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6721254599376 139.73762118484697 10.017 35.672119478436244 139.73760305363686 10.017 35.672119478436244 139.73760305363686 13.017 35.6721254599376 139.73762118484697 13.017 35.6721254599376 139.73762118484697 10.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672119478436244 139.73760305363686 10.017 35.672090501704545 139.7376174155404 10.017 35.672090501704545 139.7376174155404 13.017 35.672119478436244 139.73760305363686 13.017 35.672119478436244 139.73760305363686 10.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672090501704545 139.7376174155404 10.017 35.672096483203774 139.73763554674505 10.017 35.672096483203774 139.73763554674505 13.017 35.672090501704545 139.7376174155404 13.017 35.672090501704545 139.7376174155404 10.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672096483203774 139.73763554674505 13.017 35.6721254599376 139.73762118484697 13.017 35.672119478436244 139.73760305363686 13.017 35.672090501704545 139.7376174155404 13.017 35.672096483203774 139.73763554674505 13.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9a41177d-6737-4179-8041-d802bfe8b498"/>
							<gml:surfaceMember xlink:href="#poly-54291f70-7678-4ead-9180-d2e8c9ce0c54"/>
							<gml:surfaceMember xlink:href="#poly-5a72f800-bf41-41ed-94d0-7bce7477de25"/>
							<gml:surfaceMember xlink:href="#poly-873cfa01-61d3-4b9f-9751-102c5f4b523b"/>
							<gml:surfaceMember xlink:href="#poly-f1f1a8a1-cea5-4a01-a8cb-79a462298c67"/>
							<gml:surfaceMember xlink:href="#poly-e43a9271-bc1f-40e5-a969-c953a1bff1c9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9a41177d-6737-4179-8041-d802bfe8b498">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a41177d-6737-4179-8041-d802bfe8b498">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a41177d-6737-4179-8041-d802bfe8b498">
											<gml:posList>35.67209648320376 139.73763554674505 10.017 35.672090501704524 139.7376174155404 10.017 35.672119478436215 139.73760305363686 10.017 35.6721254599376 139.73762118484697 10.017 35.67209648320376 139.73763554674505 10.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54291f70-7678-4ead-9180-d2e8c9ce0c54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54291f70-7678-4ead-9180-d2e8c9ce0c54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54291f70-7678-4ead-9180-d2e8c9ce0c54">
											<gml:posList>35.6721254599376 139.73762118484697 12.579 35.672119478436215 139.73760305363686 12.579 35.672090501704524 139.7376174155404 12.579 35.67209648320376 139.73763554674505 12.579 35.6721254599376 139.73762118484697 12.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a72f800-bf41-41ed-94d0-7bce7477de25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a72f800-bf41-41ed-94d0-7bce7477de25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a72f800-bf41-41ed-94d0-7bce7477de25">
											<gml:posList>35.672119478436215 139.73760305363686 12.579 35.672119478436215 139.73760305363686 10.017 35.672090501704524 139.7376174155404 10.017 35.672090501704524 139.7376174155404 12.579 35.672119478436215 139.73760305363686 12.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-873cfa01-61d3-4b9f-9751-102c5f4b523b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-873cfa01-61d3-4b9f-9751-102c5f4b523b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-873cfa01-61d3-4b9f-9751-102c5f4b523b">
											<gml:posList>35.6721254599376 139.73762118484697 12.579 35.6721254599376 139.73762118484697 10.017 35.672119478436215 139.73760305363686 10.017 35.672119478436215 139.73760305363686 12.579 35.6721254599376 139.73762118484697 12.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1f1a8a1-cea5-4a01-a8cb-79a462298c67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1f1a8a1-cea5-4a01-a8cb-79a462298c67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1f1a8a1-cea5-4a01-a8cb-79a462298c67">
											<gml:posList>35.672090501704524 139.7376174155404 12.579 35.672090501704524 139.7376174155404 10.017 35.67209648320376 139.73763554674505 10.017 35.67209648320376 139.73763554674505 12.579 35.672090501704524 139.7376174155404 12.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e43a9271-bc1f-40e5-a969-c953a1bff1c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e43a9271-bc1f-40e5-a969-c953a1bff1c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e43a9271-bc1f-40e5-a969-c953a1bff1c9">
											<gml:posList>35.67209648320376 139.73763554674505 12.579 35.67209648320376 139.73763554674505 10.017 35.6721254599376 139.73762118484697 10.017 35.6721254599376 139.73762118484697 12.579 35.67209648320376 139.73763554674505 12.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8600</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>