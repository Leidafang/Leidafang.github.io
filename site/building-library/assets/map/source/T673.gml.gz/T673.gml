<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c4393fce-9dc2-41cf-85ad-1e7047526ad8">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">18.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66911163845811 139.73914190703988 0 35.669102995391505 139.73915484111072 0 35.66909000534703 139.73914171153132 0 35.669025722057604 139.7392373355758 0 35.66912368857629 139.73933641446249 0 35.6692125509209 139.73920430941183 0 35.669129162107176 139.73912008147866 0 35.66911163845811 139.73914190703988 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911163845811 139.73914190703988 12.73 35.669129162107176 139.73912008147866 12.73 35.6692125509209 139.73920430941183 12.73 35.66912368857629 139.73933641446249 12.73 35.669025722057604 139.7392373355758 12.73 35.66909000534703 139.73914171153132 12.73 35.669102995391505 139.73915484111072 12.73 35.66911163845811 139.73914190703988 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911163845811 139.73914190703988 12.73 35.669102995391505 139.73915484111072 12.73 35.669102995391505 139.73915484111072 31.44 35.66911163845811 139.73914190703988 31.44 35.66911163845811 139.73914190703988 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669102995391505 139.73915484111072 12.73 35.66909000534703 139.73914171153132 12.73 35.66909000534703 139.73914171153132 31.44 35.669102995391505 139.73915484111072 31.44 35.669102995391505 139.73915484111072 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909000534703 139.73914171153132 12.73 35.669025722057604 139.7392373355758 12.73 35.669025722057604 139.7392373355758 31.44 35.66909000534703 139.73914171153132 31.44 35.66909000534703 139.73914171153132 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669025722057604 139.7392373355758 12.73 35.66912368857629 139.73933641446249 12.73 35.66912368857629 139.73933641446249 31.44 35.669025722057604 139.7392373355758 31.44 35.669025722057604 139.7392373355758 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66912368857629 139.73933641446249 12.73 35.6692125509209 139.73920430941183 12.73 35.6692125509209 139.73920430941183 31.44 35.66912368857629 139.73933641446249 31.44 35.66912368857629 139.73933641446249 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6692125509209 139.73920430941183 12.73 35.669129162107176 139.73912008147866 12.73 35.669129162107176 139.73912008147866 31.44 35.6692125509209 139.73920430941183 31.44 35.6692125509209 139.73920430941183 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669129162107176 139.73912008147866 12.73 35.66911163845811 139.73914190703988 12.73 35.66911163845811 139.73914190703988 31.44 35.669129162107176 139.73912008147866 31.44 35.669129162107176 139.73912008147866 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911163845811 139.73914190703988 31.44 35.669102995391505 139.73915484111072 31.44 35.66909000534703 139.73914171153132 31.44 35.669025722057604 139.7392373355758 31.44 35.66912368857629 139.73933641446249 31.44 35.6692125509209 139.73920430941183 31.44 35.669129162107176 139.73912008147866 31.44 35.66911163845811 139.73914190703988 31.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3a6ff71a-1a42-45e0-89ad-c53bed430332"/>
							<gml:surfaceMember xlink:href="#poly-dc2b8e73-3ee8-4eee-8841-259758e08446"/>
							<gml:surfaceMember xlink:href="#poly-728b261d-07de-48dc-b6d5-e14dd448e38f"/>
							<gml:surfaceMember xlink:href="#poly-c73bf23b-94fd-4e42-b643-57252ce9c02e"/>
							<gml:surfaceMember xlink:href="#poly-48e35b19-1a0c-4e0f-8982-d32daae860a6"/>
							<gml:surfaceMember xlink:href="#poly-3a73263a-a21d-4da6-877b-01fae0bdf83d"/>
							<gml:surfaceMember xlink:href="#poly-df3638c4-1459-4ec6-b05c-20b688505372"/>
							<gml:surfaceMember xlink:href="#poly-c03bf462-d795-4468-925c-732e397e2589"/>
							<gml:surfaceMember xlink:href="#poly-4338a4de-519d-4864-9c8f-90374374c6dc"/>
							<gml:surfaceMember xlink:href="#poly-0ecb8981-0bf7-4f74-a7dd-b3a6304c6d2d"/>
							<gml:surfaceMember xlink:href="#poly-0beed3ca-8242-49c4-b2e2-4dc6d475b66b"/>
							<gml:surfaceMember xlink:href="#poly-2ade4321-256c-486d-859c-38be29f3f0e7"/>
							<gml:surfaceMember xlink:href="#poly-32b253ed-c210-46bc-a142-f5aaa57d4cbe"/>
							<gml:surfaceMember xlink:href="#poly-b90d0a32-1088-4e07-a95c-50907234c013"/>
							<gml:surfaceMember xlink:href="#poly-2110b35b-e887-46f6-96b0-ed09d6047459"/>
							<gml:surfaceMember xlink:href="#poly-953f58d5-92e9-4b86-89de-a35dfc8c8956"/>
							<gml:surfaceMember xlink:href="#poly-3e59286b-5bb6-4711-a1af-86f53098b5cd"/>
							<gml:surfaceMember xlink:href="#poly-0acd5163-1bd4-4879-962e-2aa506d0d398"/>
							<gml:surfaceMember xlink:href="#poly-33dda12e-100c-4c25-83b5-90911b014ec6"/>
							<gml:surfaceMember xlink:href="#poly-534c451b-9514-4268-b6fe-630ecbe18f00"/>
							<gml:surfaceMember xlink:href="#poly-bd7d30df-52fe-4328-89c1-160d5c02f64b"/>
							<gml:surfaceMember xlink:href="#poly-47d30b4b-1e0a-4525-a505-f946c5ddd010"/>
							<gml:surfaceMember xlink:href="#poly-bda5cb94-ede9-4dff-9537-d04f069cba9d"/>
							<gml:surfaceMember xlink:href="#poly-b3e7a635-2fde-4574-bfd3-d3a1f0ffceb6"/>
							<gml:surfaceMember xlink:href="#poly-8e599d39-a144-4302-8f8a-79b8e186f65e"/>
							<gml:surfaceMember xlink:href="#poly-a652f3ba-51e4-4a02-94e2-95cec0c3d834"/>
							<gml:surfaceMember xlink:href="#poly-15be691a-c0e0-49ed-80aa-f0e4809d80b1"/>
							<gml:surfaceMember xlink:href="#poly-4bf03751-f646-460b-9413-8b6c84bf0fb1"/>
							<gml:surfaceMember xlink:href="#poly-e4792050-b5e8-434e-a45e-ae5f751542e1"/>
							<gml:surfaceMember xlink:href="#poly-0076d5a8-8b02-4a72-8115-79dbd04f1a8a"/>
							<gml:surfaceMember xlink:href="#poly-6b1ffe43-7c94-455b-88bb-321919850970"/>
							<gml:surfaceMember xlink:href="#poly-e57b340e-68e2-459f-bc3d-020f24940242"/>
							<gml:surfaceMember xlink:href="#poly-69def3ad-9e46-48ba-af51-d33069b98d37"/>
							<gml:surfaceMember xlink:href="#poly-1a52ee75-e50c-472c-a89b-e7229cdc9c3a"/>
							<gml:surfaceMember xlink:href="#poly-2219eaa4-5fbe-48fe-8a56-fbf2cf1df76d"/>
							<gml:surfaceMember xlink:href="#poly-e9de2b12-8cd8-434e-a916-4f2b15e5fd98"/>
							<gml:surfaceMember xlink:href="#poly-fc1c14d3-5109-4d32-8add-9c2829c4362e"/>
							<gml:surfaceMember xlink:href="#poly-ea191d3b-8892-48e8-b36c-b0bc340a9bd8"/>
							<gml:surfaceMember xlink:href="#poly-5167f2c6-2c88-49f6-8b2a-afd06b0ade29"/>
							<gml:surfaceMember xlink:href="#poly-177ef18f-41de-44bf-ba86-b460973bf46c"/>
							<gml:surfaceMember xlink:href="#poly-b54c77a1-68b8-4e13-8056-efeb5e113240"/>
							<gml:surfaceMember xlink:href="#poly-4ae20f8b-9400-49b8-93da-a39e4d0e14ff"/>
							<gml:surfaceMember xlink:href="#poly-70b57e1e-ba40-47cb-9d2b-46cb6e7f866b"/>
							<gml:surfaceMember xlink:href="#poly-e3127257-659d-4976-bd30-a0baa258af52"/>
							<gml:surfaceMember xlink:href="#poly-6339a29b-9ad3-473e-829a-9ffe1a1a11e4"/>
							<gml:surfaceMember xlink:href="#poly-b5f94e29-548d-4ab5-805a-2a10ad14c4a8"/>
							<gml:surfaceMember xlink:href="#poly-af234ddd-8d79-445f-9389-626bf3407959"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c4393fce-9dc2-41cf-85ad-1e7047526ad8_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e158784-be1c-488d-9fd9-a82910e587dd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669111638458105 139.73914190703988 12.73 35.66908250105495 139.73911244823344 12.73 35.66909861694973 139.73908856975697 12.73 35.669129162107154 139.73912008147866 12.73 35.669111638458105 139.73914190703988 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a315ec2d-f190-4c23-9127-e5391ddae2cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a315ec2d-f190-4c23-9127-e5391ddae2cd_0">
											<gml:posList>35.66909861694973 139.73908856975697 12.73 35.66908250105495 139.73911244823344 12.73 35.66908250105495 139.73911244823344 30.059 35.669090559002946 139.73910050899642 30.059 35.66909861694973 139.73908856975697 30.059 35.66909861694973 139.73908856975697 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0c84ae1-35ec-49c2-97b2-1aacb913c83a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0c84ae1-35ec-49c2-97b2-1aacb913c83a_0">
											<gml:posList>35.66908250105495 139.73911244823344 30.059 35.66908250105495 139.73911244823344 12.73 35.669111638458105 139.73914190703988 12.73 35.669111638458105 139.73914190703988 31.791 35.66908250105495 139.73911244823344 30.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1c92a8c-c266-4846-91c8-78b2fd119c6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1c92a8c-c266-4846-91c8-78b2fd119c6c_0">
											<gml:posList>35.669090559002946 139.73910050899642 30.059 35.66908250105495 139.73911244823344 30.059 35.669111638458105 139.73914190703988 31.791 35.669120400283134 139.73913099426045 31.791 35.669090559002946 139.73910050899642 30.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d183f409-df14-4ef8-a90a-fe81e64a1109">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d183f409-df14-4ef8-a90a-fe81e64a1109_0">
											<gml:posList>35.669120400283134 139.73913099426045 27.689 35.669090559002946 139.73910050899642 30.059 35.669120400283134 139.73913099426045 31.791 35.669120400283134 139.73913099426045 27.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bcab64e-8221-4cc9-a73e-cbd726d5b6bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bcab64e-8221-4cc9-a73e-cbd726d5b6bc_0">
											<gml:posList>35.66909861694973 139.73908856975697 30.059 35.669090559002946 139.73910050899642 30.059 35.669120400283134 139.73913099426045 27.689 35.669129162107154 139.73912008147866 27.689 35.66909861694973 139.73908856975697 30.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ad16f7e-bcc1-492e-b1d3-d023be0d6733">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ad16f7e-bcc1-492e-b1d3-d023be0d6733_0">
											<gml:posList>35.66909861694973 139.73908856975697 30.059 35.669129162107154 139.73912008147866 27.689 35.669129162107154 139.73912008147866 12.73 35.66909861694973 139.73908856975697 12.73 35.66909861694973 139.73908856975697 30.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3190dc4b-58c5-4b71-9c6a-981317b4f85e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3190dc4b-58c5-4b71-9c6a-981317b4f85e_0">
											<gml:posList>35.669111638458105 139.73914190703988 12.73 35.669129162107154 139.73912008147866 12.73 35.669129162107154 139.73912008147866 27.689 35.669120400283134 139.73913099426045 27.689 35.669120400283134 139.73913099426045 31.791 35.669111638458105 139.73914190703988 31.791 35.669111638458105 139.73914190703988 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c4393fce-9dc2-41cf-85ad-1e7047526ad8_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c520217a-d178-4b49-81da-40ec531faf67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669151476722355 139.73919642792538 31.416 35.66916153335888 139.73918145971055 31.416 35.6691741264755 139.73919418106863 31.416 35.66916406983741 139.7392091492842 31.416 35.669151476722355 139.73919642792538 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b61d1a8-786a-4d99-817d-2be540e54a59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b61d1a8-786a-4d99-817d-2be540e54a59_0">
											<gml:posList>35.66916153335888 139.73918145971055 31.416 35.66916153335888 139.73918145971055 34.347 35.6691741264755 139.73919418106863 34.347 35.6691741264755 139.73919418106863 31.416 35.66916153335888 139.73918145971055 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e85bac1-8d7f-4c74-9090-2a0f1dd3a8ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e85bac1-8d7f-4c74-9090-2a0f1dd3a8ef_0">
											<gml:posList>35.669151476722355 139.73919642792538 31.416 35.669151476722355 139.73919642792538 34.347 35.66916153335888 139.73918145971055 34.347 35.66916153335888 139.73918145971055 31.416 35.669151476722355 139.73919642792538 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-515051a3-9109-4da0-adcd-a0c1b6d50961">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-515051a3-9109-4da0-adcd-a0c1b6d50961_0">
											<gml:posList>35.669151476722355 139.73919642792538 34.347 35.66916406983741 139.7392091492842 34.347 35.6691741264755 139.73919418106863 34.347 35.66916153335888 139.73918145971055 34.347 35.669151476722355 139.73919642792538 34.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90e02804-8887-43b1-8c8a-b3fb020eda12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90e02804-8887-43b1-8c8a-b3fb020eda12_0">
											<gml:posList>35.6691741264755 139.73919418106863 31.416 35.6691741264755 139.73919418106863 34.347 35.66916406983741 139.7392091492842 34.347 35.66916406983741 139.7392091492842 31.416 35.6691741264755 139.73919418106863 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b6e0eda-28b2-49af-81a9-f2b7b60ce3ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b6e0eda-28b2-49af-81a9-f2b7b60ce3ca_0">
											<gml:posList>35.66916406983741 139.7392091492842 31.416 35.66916406983741 139.7392091492842 34.347 35.669151476722355 139.73919642792538 34.347 35.669151476722355 139.73919642792538 31.416 35.66916406983741 139.7392091492842 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c4393fce-9dc2-41cf-85ad-1e7047526ad8_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f499a79-8915-446c-bed7-5c3e61b0bb4b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669139112452356 139.73917665889746 34.759 35.6691316158543 139.73916874765612 34.759 35.66914390592984 139.739151269356 34.759 35.66915140252904 139.7391591805969 34.759 35.669139112452356 139.73917665889746 34.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6877468-900e-437b-a49f-19228587d7dd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669194645908526 139.73919952537977 31.416 35.669201664138164 139.7392066197806 31.416 35.66919469560583 139.73921697815308 31.416 35.6691876773768 139.73920988375198 31.416 35.669194645908526 139.73919952537977 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-775ab010-f1f7-4c5e-8b1b-1d2ed17a9bea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914112524713 139.73921474344735 31.416 35.66913563282381 139.73922236064902 31.416 35.66913213252895 139.73921856490338 31.416 35.669137624960676 139.73921095874786 31.416 35.66914112524713 139.73921474344735 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e227e24-5c19-4fd7-bc90-99ea1bd0f2ef">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669180278542285 139.7392232582111 31.416 35.66918835220497 139.7392314117992 31.416 35.66918415667795 139.73923764672048 31.416 35.669176083024325 139.73922950417827 31.416 35.669180278542285 139.7392232582111 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6435cf63-d974-48d3-af0e-c5e1a0517fdc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669127244118194 139.7392378350165 31.416 35.66912187639457 139.7392320089823 31.416 35.6691279811043 139.73922356260744 31.416 35.669133348819685 139.73922937759545 31.416 35.669127244118194 139.7392378350165 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da0919fe-9d86-4819-a789-36079329f65a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918835220497 139.7392314117992 32.144 35.669189281352295 139.73923234962683 32.144 35.669185085825234 139.7392385845481 32.144 35.66918415667795 139.73923764672048 32.144 35.66918835220497 139.7392314117992 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3c3eef0-1a1a-46c8-bb66-df6a04ce862c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66912393964619 139.73924240092802 31.416 35.669117465786705 139.73925137794626 31.416 35.669112116108444 139.73924557398288 31.416 35.66911858997613 139.73923660801086 31.416 35.66912393964619 139.73924240092802 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16faefed-46e7-48ad-baf5-1e2cc1778193">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690834680554 139.73925402471306 31.416 35.66907687359429 139.73924708446637 31.416 35.66908305912654 139.7392382513897 31.416 35.66908965357951 139.73924518059013 31.416 35.6690834680554 139.73925402471306 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-606f4a6d-28d1-4a0f-8b5b-08098178c122">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910811063275 139.7392643238877 31.416 35.66910306768924 139.73925886199285 31.416 35.66910893829434 139.73925073623317 31.416 35.66911397222447 139.7392561981385 31.416 35.66910811063275 139.7392643238877 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd70a24c-7051-4ff9-8ecf-c4ab91b35c8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd70a24c-7051-4ff9-8ecf-c4ab91b35c8f_0">
											<gml:posList>35.66907687359429 139.73924708446637 31.416 35.66907687359429 139.73924708446637 32.256 35.66908305912654 139.7392382513897 32.256 35.66908305912654 139.7392382513897 31.416 35.66907687359429 139.73924708446637 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0601385b-05cf-4f0f-be1d-6911a233b125">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0601385b-05cf-4f0f-be1d-6911a233b125_0">
											<gml:posList>35.66907687359429 139.73924708446637 31.416 35.6690834680554 139.73925402471306 31.416 35.6690834680554 139.73925402471306 32.256 35.66907687359429 139.73924708446637 32.256 35.66907687359429 139.73924708446637 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0906f11-d503-43a7-92c8-0d26eef1b2a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0906f11-d503-43a7-92c8-0d26eef1b2a3_0">
											<gml:posList>35.66908305912654 139.7392382513897 32.256 35.66907687359429 139.73924708446637 32.256 35.6690834680554 139.73925402471306 32.256 35.66908965357951 139.73924518059013 32.256 35.66908305912654 139.7392382513897 32.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99727e0a-2666-4768-bbcc-e5925306e632">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99727e0a-2666-4768-bbcc-e5925306e632_0">
											<gml:posList>35.66908965357951 139.73924518059013 31.416 35.66908305912654 139.7392382513897 31.416 35.66908305912654 139.7392382513897 32.256 35.66908965357951 139.73924518059013 32.256 35.66908965357951 139.73924518059013 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a95931d6-0562-4be2-abed-fea3f1027947">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a95931d6-0562-4be2-abed-fea3f1027947_0">
											<gml:posList>35.66908965357951 139.73924518059013 31.416 35.66908965357951 139.73924518059013 32.256 35.6690834680554 139.73925402471306 32.256 35.6690834680554 139.73925402471306 31.416 35.66908965357951 139.73924518059013 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c48d941d-1c80-4255-b239-47e2b1da5e2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c48d941d-1c80-4255-b239-47e2b1da5e2d_0">
											<gml:posList>35.66910306768924 139.73925886199285 31.416 35.66910811063275 139.7392643238877 31.416 35.66910811063275 139.7392643238877 33.458 35.66910306768924 139.73925886199285 33.458 35.66910306768924 139.73925886199285 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dfb8c25-0c6a-4b81-810b-41cad6e8dca4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dfb8c25-0c6a-4b81-810b-41cad6e8dca4_0">
											<gml:posList>35.66910893829434 139.73925073623317 31.416 35.66910306768924 139.73925886199285 31.416 35.66910306768924 139.73925886199285 33.458 35.66910893829434 139.73925073623317 33.458 35.66910893829434 139.73925073623317 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a9df11e-40ec-4524-9361-58975572cad0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a9df11e-40ec-4524-9361-58975572cad0_0">
											<gml:posList>35.66910893829434 139.73925073623317 33.458 35.66910306768924 139.73925886199285 33.458 35.66910811063275 139.7392643238877 33.458 35.66911397222447 139.7392561981385 33.458 35.66910893829434 139.73925073623317 33.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4173a70-3fde-4e3a-8d45-28f35f149f03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4173a70-3fde-4e3a-8d45-28f35f149f03_0">
											<gml:posList>35.66910811063275 139.7392643238877 31.416 35.66911397222447 139.7392561981385 31.416 35.66911397222447 139.7392561981385 33.458 35.66910811063275 139.7392643238877 33.458 35.66910811063275 139.7392643238877 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23a280ec-b809-4c87-862c-7c2022277cf1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23a280ec-b809-4c87-862c-7c2022277cf1_0">
											<gml:posList>35.66910893829434 139.73925073623317 31.416 35.66910893829434 139.73925073623317 33.458 35.66911397222447 139.7392561981385 33.458 35.66911397222447 139.7392561981385 31.416 35.66910893829434 139.73925073623317 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-355ea092-15fb-4385-bbc5-381214008c68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-355ea092-15fb-4385-bbc5-381214008c68_0">
											<gml:posList>35.669112116108444 139.73924557398288 31.416 35.669117465786705 139.73925137794626 31.416 35.669117465786705 139.73925137794626 33.458 35.669112116108444 139.73924557398288 33.458 35.669112116108444 139.73924557398288 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7a9c805-3454-4b8c-9635-221e3664f683">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7a9c805-3454-4b8c-9635-221e3664f683_0">
											<gml:posList>35.66911858997613 139.73923660801086 31.416 35.669112116108444 139.73924557398288 31.416 35.669112116108444 139.73924557398288 33.458 35.66911858997613 139.73923660801086 33.458 35.66911858997613 139.73923660801086 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df387a7d-574e-46cd-bb5e-c2b3a16f9bf8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df387a7d-574e-46cd-bb5e-c2b3a16f9bf8_0">
											<gml:posList>35.669112116108444 139.73924557398288 33.458 35.669117465786705 139.73925137794626 33.458 35.66912393964619 139.73924240092802 33.458 35.66911858997613 139.73923660801086 33.458 35.669112116108444 139.73924557398288 33.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-134e38e0-8497-4542-b232-90fd70835764">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-134e38e0-8497-4542-b232-90fd70835764_0">
											<gml:posList>35.669117465786705 139.73925137794626 31.416 35.66912393964619 139.73924240092802 31.416 35.66912393964619 139.73924240092802 33.458 35.669117465786705 139.73925137794626 33.458 35.669117465786705 139.73925137794626 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3dad108-0c12-4a19-8866-87033e346ee6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3dad108-0c12-4a19-8866-87033e346ee6_0">
											<gml:posList>35.66912393964619 139.73924240092802 31.416 35.66911858997613 139.73923660801086 31.416 35.66911858997613 139.73923660801086 33.458 35.66912393964619 139.73924240092802 33.458 35.66912393964619 139.73924240092802 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3edddd79-8ee4-4233-b0e6-060c8402e5a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3edddd79-8ee4-4233-b0e6-060c8402e5a4_0">
											<gml:posList>35.66912187639457 139.7392320089823 31.416 35.669127244118194 139.7392378350165 31.416 35.669127244118194 139.7392378350165 33.458 35.66912187639457 139.7392320089823 33.458 35.66912187639457 139.7392320089823 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52e1531e-7f96-4a0c-ab96-7010bd144fd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52e1531e-7f96-4a0c-ab96-7010bd144fd8_0">
											<gml:posList>35.6691279811043 139.73922356260744 31.416 35.66912187639457 139.7392320089823 31.416 35.66912187639457 139.7392320089823 33.458 35.6691279811043 139.73922356260744 33.458 35.6691279811043 139.73922356260744 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-338acac8-cba5-47c9-8062-579db14e8213">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-338acac8-cba5-47c9-8062-579db14e8213_0">
											<gml:posList>35.6691279811043 139.73922356260744 33.458 35.66912187639457 139.7392320089823 33.458 35.669127244118194 139.7392378350165 33.458 35.669133348819685 139.73922937759545 33.458 35.6691279811043 139.73922356260744 33.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76d7d8ff-281f-4fcd-a3c7-3ffb13ac1d90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76d7d8ff-281f-4fcd-a3c7-3ffb13ac1d90_0">
											<gml:posList>35.669127244118194 139.7392378350165 31.416 35.669133348819685 139.73922937759545 31.416 35.669133348819685 139.73922937759545 33.458 35.669127244118194 139.7392378350165 33.458 35.669127244118194 139.7392378350165 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82409f8e-5cdf-4493-b5b3-5827ea438b94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82409f8e-5cdf-4493-b5b3-5827ea438b94_0">
											<gml:posList>35.669133348819685 139.73922937759545 31.416 35.6691279811043 139.73922356260744 31.416 35.6691279811043 139.73922356260744 33.458 35.669133348819685 139.73922937759545 33.458 35.669133348819685 139.73922937759545 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab316b86-6a72-42fc-b5bd-6898956c1d55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab316b86-6a72-42fc-b5bd-6898956c1d55_0">
											<gml:posList>35.66913213252895 139.73921856490338 31.416 35.66913563282381 139.73922236064902 31.416 35.66913563282381 139.73922236064902 33.458 35.66913213252895 139.73921856490338 33.458 35.66913213252895 139.73921856490338 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7269535a-2ea6-472b-9fc7-b36c0d9cbbe0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7269535a-2ea6-472b-9fc7-b36c0d9cbbe0_0">
											<gml:posList>35.669137624960676 139.73921095874786 31.416 35.66913213252895 139.73921856490338 31.416 35.66913213252895 139.73921856490338 33.458 35.669137624960676 139.73921095874786 33.458 35.669137624960676 139.73921095874786 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0eba9734-4a23-45f9-82e5-8807f79c606e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0eba9734-4a23-45f9-82e5-8807f79c606e_0">
											<gml:posList>35.669139112452356 139.73917665889746 34.759 35.669139112452356 139.73917665889746 37.374 35.6691316158543 139.73916874765612 37.374 35.6691316158543 139.73916874765612 34.759 35.669139112452356 139.73917665889746 34.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8410a18b-9ff4-4827-b1f7-cfed12aa66d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8410a18b-9ff4-4827-b1f7-cfed12aa66d0_0">
											<gml:posList>35.66913213252895 139.73921856490338 33.458 35.66913563282381 139.73922236064902 33.458 35.66914112524713 139.73921474344735 33.458 35.669137624960676 139.73921095874786 33.458 35.66913213252895 139.73921856490338 33.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00be0c06-696b-408c-9d23-5e6ab74911ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00be0c06-696b-408c-9d23-5e6ab74911ae_0">
											<gml:posList>35.66914390592984 139.739151269356 34.759 35.6691316158543 139.73916874765612 34.759 35.6691316158543 139.73916874765612 37.374 35.66914390592984 139.739151269356 37.374 35.66914390592984 139.739151269356 34.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2005269b-bd46-45fd-b865-f4f31a26c923">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2005269b-bd46-45fd-b865-f4f31a26c923_0">
											<gml:posList>35.66914112524713 139.73921474344735 31.416 35.66914112524713 139.73921474344735 33.458 35.66913563282381 139.73922236064902 33.458 35.66913563282381 139.73922236064902 31.416 35.66914112524713 139.73921474344735 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19f241a6-0949-4de9-8981-dfe8ebc933a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19f241a6-0949-4de9-8981-dfe8ebc933a8_0">
											<gml:posList>35.669137624960676 139.73921095874786 31.416 35.669137624960676 139.73921095874786 33.458 35.66914112524713 139.73921474344735 33.458 35.66914112524713 139.73921474344735 31.416 35.669137624960676 139.73921095874786 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd680b15-75e9-4c5b-a030-c96ee6bc44f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd680b15-75e9-4c5b-a030-c96ee6bc44f1_0">
											<gml:posList>35.66914390592984 139.739151269356 37.374 35.6691316158543 139.73916874765612 37.374 35.669139112452356 139.73917665889746 37.374 35.66915140252904 139.7391591805969 37.374 35.66914390592984 139.739151269356 37.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e20ebcc1-f317-4d29-9e47-fefe2da206eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e20ebcc1-f317-4d29-9e47-fefe2da206eb_0">
											<gml:posList>35.669139112452356 139.73917665889746 34.759 35.66915140252904 139.7391591805969 34.759 35.66915140252904 139.7391591805969 37.374 35.669139112452356 139.73917665889746 37.374 35.669139112452356 139.73917665889746 34.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68b201f7-58be-4314-9bf3-3f72ed157d12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68b201f7-58be-4314-9bf3-3f72ed157d12_0">
											<gml:posList>35.66915140252904 139.7391591805969 34.759 35.66914390592984 139.739151269356 34.759 35.66914390592984 139.739151269356 37.374 35.66915140252904 139.7391591805969 37.374 35.66915140252904 139.7391591805969 34.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34db6db6-fb3f-4c09-8679-18c78f61e918">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34db6db6-fb3f-4c09-8679-18c78f61e918_0">
											<gml:posList>35.669176083024325 139.73922950417827 31.416 35.669176083024325 139.73922950417827 33.575 35.669180278542285 139.7392232582111 33.575 35.669180278542285 139.7392232582111 31.416 35.669176083024325 139.73922950417827 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c42fa8d-c89e-4129-8a27-d50b9e86ad0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c42fa8d-c89e-4129-8a27-d50b9e86ad0e_0">
											<gml:posList>35.66918415667795 139.73923764672048 32.144 35.669185085825234 139.7392385845481 32.144 35.669185085825234 139.7392385845481 33.575 35.669176083024325 139.73922950417827 33.575 35.669176083024325 139.73922950417827 31.416 35.66918415667795 139.73923764672048 31.416 35.66918415667795 139.73923764672048 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddbb8f6a-fdf4-4d4c-8cfc-086e58575286">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddbb8f6a-fdf4-4d4c-8cfc-086e58575286_0">
											<gml:posList>35.669180278542285 139.7392232582111 33.575 35.669176083024325 139.73922950417827 33.575 35.669185085825234 139.7392385845481 33.575 35.669189281352295 139.73923234962683 33.575 35.669180278542285 139.7392232582111 33.575</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b1e4fc1-bd9b-4e84-8186-0808af4cd088">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b1e4fc1-bd9b-4e84-8186-0808af4cd088_0">
											<gml:posList>35.669180278542285 139.7392232582111 31.416 35.669180278542285 139.7392232582111 33.575 35.669189281352295 139.73923234962683 33.575 35.669189281352295 139.73923234962683 32.144 35.66918835220497 139.7392314117992 32.144 35.66918835220497 139.7392314117992 31.416 35.669180278542285 139.7392232582111 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fbb7bb2-389f-43e6-a972-8265b285f207">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fbb7bb2-389f-43e6-a972-8265b285f207_0">
											<gml:posList>35.66918415667795 139.73923764672048 32.144 35.66918415667795 139.73923764672048 31.416 35.66918835220497 139.7392314117992 31.416 35.66918835220497 139.7392314117992 32.144 35.66918415667795 139.73923764672048 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3c30a13-ae9e-41bc-b55f-863f3dc7e238">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3c30a13-ae9e-41bc-b55f-863f3dc7e238_0">
											<gml:posList>35.669185085825234 139.7392385845481 32.144 35.669189281352295 139.73923234962683 32.144 35.669189281352295 139.73923234962683 33.575 35.669185085825234 139.7392385845481 33.575 35.669185085825234 139.7392385845481 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ecfcf17-2008-4e38-9bdb-e67916f93a72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ecfcf17-2008-4e38-9bdb-e67916f93a72_0">
											<gml:posList>35.6691876773768 139.73920988375198 31.416 35.6691876773768 139.73920988375198 32.468 35.669194645908526 139.73919952537977 32.468 35.669194645908526 139.73919952537977 31.416 35.6691876773768 139.73920988375198 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22d80153-f28d-4827-8508-28507ebd0926">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22d80153-f28d-4827-8508-28507ebd0926_0">
											<gml:posList>35.6691876773768 139.73920988375198 31.416 35.66919469560583 139.73921697815308 31.416 35.66919469560583 139.73921697815308 32.468 35.6691876773768 139.73920988375198 32.468 35.6691876773768 139.73920988375198 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecb9c61e-2265-49b3-b13b-18b16e3fbcf6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecb9c61e-2265-49b3-b13b-18b16e3fbcf6_0">
											<gml:posList>35.669194645908526 139.73919952537977 32.468 35.6691876773768 139.73920988375198 32.468 35.66919469560583 139.73921697815308 32.468 35.669201664138164 139.7392066197806 32.468 35.669194645908526 139.73919952537977 32.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9aecb9e8-00b9-48cb-aa7f-c7a4cd47a41e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9aecb9e8-00b9-48cb-aa7f-c7a4cd47a41e_0">
											<gml:posList>35.669194645908526 139.73919952537977 31.416 35.669194645908526 139.73919952537977 32.468 35.669201664138164 139.7392066197806 32.468 35.669201664138164 139.7392066197806 31.416 35.669194645908526 139.73919952537977 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50a41768-540c-4dff-936d-b875ae8458b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50a41768-540c-4dff-936d-b875ae8458b7_0">
											<gml:posList>35.66919469560583 139.73921697815308 31.416 35.669201664138164 139.7392066197806 31.416 35.669201664138164 139.7392066197806 32.468 35.66919469560583 139.73921697815308 32.468 35.66919469560583 139.73921697815308 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3a6ff71a-1a42-45e0-89ad-c53bed430332">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a6ff71a-1a42-45e0-89ad-c53bed430332">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a6ff71a-1a42-45e0-89ad-c53bed430332">
											<gml:posList>35.6691029953915 139.7391548411107 12.73 35.669111638458105 139.73914190703988 12.73 35.669129162107154 139.73912008147866 12.73 35.6692125509209 139.73920430941183 12.73 35.669123688576285 139.73933641446246 12.73 35.669025722057604 139.7392373355758 12.73 35.66909000534703 139.73914171153132 12.73 35.6691029953915 139.7391548411107 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc2b8e73-3ee8-4eee-8841-259758e08446">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc2b8e73-3ee8-4eee-8841-259758e08446">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc2b8e73-3ee8-4eee-8841-259758e08446">
											<gml:posList>35.66912940098388 139.73912585830146 32.144 35.66914171446494 139.739138303822 32.144 35.669143929266085 139.73913500948558 32.144 35.669129162107154 139.73912008147866 32.144 35.66912940098388 139.73912585830146 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-728b261d-07de-48dc-b6d5-e14dd448e38f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-728b261d-07de-48dc-b6d5-e14dd448e38f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-728b261d-07de-48dc-b6d5-e14dd448e38f">
											<gml:posList>35.669111638458105 139.73914190703988 32.144 35.66911420962465 139.7391447870476 32.144 35.66912940098388 139.73912585830146 32.144 35.669129162107154 139.73912008147866 32.144 35.669111638458105 139.73914190703988 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c73bf23b-94fd-4e42-b643-57252ce9c02e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c73bf23b-94fd-4e42-b643-57252ce9c02e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c73bf23b-94fd-4e42-b643-57252ce9c02e">
											<gml:posList>35.669143929266085 139.73913500948558 37.374 35.669144348166 139.73914046576144 37.374 35.669160702964604 139.73915696045512 37.374 35.66916515533831 139.7391564360593 37.374 35.669143929266085 139.73913500948558 37.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48e35b19-1a0c-4e0f-8982-d32daae860a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48e35b19-1a0c-4e0f-8982-d32daae860a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48e35b19-1a0c-4e0f-8982-d32daae860a6">
											<gml:posList>35.6691029953915 139.7391548411107 32.144 35.66909000534703 139.73914171153132 32.144 35.669090478752345 139.7391477089975 32.144 35.66910347781852 139.73916084961343 32.144 35.6691029953915 139.7391548411107 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a73263a-a21d-4da6-877b-01fae0bdf83d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a73263a-a21d-4da6-877b-01fae0bdf83d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a73263a-a21d-4da6-877b-01fae0bdf83d">
											<gml:posList>35.6691029953915 139.7391548411107 32.144 35.66910347781852 139.73916084961343 32.144 35.66911420962465 139.7391447870476 32.144 35.669111638458105 139.73914190703988 32.144 35.6691029953915 139.7391548411107 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df3638c4-1459-4ec6-b05c-20b688505372">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df3638c4-1459-4ec6-b05c-20b688505372">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df3638c4-1459-4ec6-b05c-20b688505372">
											<gml:posList>35.6691155329816 139.73917723889105 37.374 35.669119976333064 139.73917670346114 37.374 35.669144348166 139.73914046576144 37.374 35.669143929266085 139.73913500948558 37.374 35.6691155329816 139.73917723889105 37.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c03bf462-d795-4468-925c-732e397e2589">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c03bf462-d795-4468-925c-732e397e2589">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c03bf462-d795-4468-925c-732e397e2589">
											<gml:posList>35.669160702964604 139.73915696045512 34.759 35.669144348166 139.73914046576144 34.759 35.669119976333064 139.73917670346114 34.759 35.66913632212168 139.73919320921388 34.759 35.669160702964604 139.73915696045512 34.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4338a4de-519d-4864-9c8f-90374374c6dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4338a4de-519d-4864-9c8f-90374374c6dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4338a4de-519d-4864-9c8f-90374374c6dc">
											<gml:posList>35.66916515533831 139.7391564360593 37.374 35.669160702964604 139.73915696045512 37.374 35.66913632212168 139.73919320921388 37.374 35.669136750032685 139.73919866547894 37.374 35.66916515533831 139.7391564360593 37.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ecb8981-0bf7-4f74-a7dd-b3a6304c6d2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ecb8981-0bf7-4f74-a7dd-b3a6304c6d2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ecb8981-0bf7-4f74-a7dd-b3a6304c6d2d">
											<gml:posList>35.66920764789535 139.73920487851876 32.144 35.6692125509209 139.73920430941183 32.144 35.66916515533831 139.7391564360593 32.144 35.669162940536594 139.739159730396 32.144 35.66920764789535 139.73920487851876 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0beed3ca-8242-49c4-b2e2-4dc6d475b66b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0beed3ca-8242-49c4-b2e2-4dc6d475b66b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0beed3ca-8242-49c4-b2e2-4dc6d475b66b">
											<gml:posList>35.669136750032685 139.73919866547894 37.374 35.66913632212168 139.73919320921388 37.374 35.669119976333064 139.73917670346114 37.374 35.6691155329816 139.73917723889105 37.374 35.669136750032685 139.73919866547894 37.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ade4321-256c-486d-859c-38be29f3f0e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ade4321-256c-486d-859c-38be29f3f0e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ade4321-256c-486d-859c-38be29f3f0e7">
											<gml:posList>35.669025722057604 139.7392373355758 32.144 35.669030616052474 139.73923674439064 32.144 35.669090478752345 139.7391477089975 32.144 35.66909000534703 139.73914171153132 32.144 35.669025722057604 139.7392373355758 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32b253ed-c210-46bc-a142-f5aaa57d4cbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32b253ed-c210-46bc-a142-f5aaa57d4cbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32b253ed-c210-46bc-a142-f5aaa57d4cbe">
											<gml:posList>35.669030616052474 139.73923674439064 31.416 35.66909727118316 139.73930415773228 31.416 35.66915689115734 139.7392158847805 31.416 35.66918270883466 139.73924195639637 31.416 35.66920764789535 139.73920487851876 31.416 35.669162940536594 139.739159730396 31.416 35.669136750032685 139.73919866547894 31.416 35.6691155329816 139.73917723889105 31.416 35.66914171446494 139.739138303822 31.416 35.66912940098388 139.73912585830146 31.416 35.66911420962465 139.7391447870476 31.416 35.66910347781852 139.73916084961343 31.416 35.669090478752345 139.7391477089975 31.416 35.669030616052474 139.73923674439064 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b90d0a32-1088-4e07-a95c-50907234c013">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b90d0a32-1088-4e07-a95c-50907234c013">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b90d0a32-1088-4e07-a95c-50907234c013">
											<gml:posList>35.6692125509209 139.73920430941183 32.144 35.66920764789535 139.73920487851876 32.144 35.66918270883466 139.73924195639637 32.144 35.669183191257346 139.7392479649056 32.144 35.6692125509209 139.73920430941183 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2110b35b-e887-46f6-96b0-ed09d6047459">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2110b35b-e887-46f6-96b0-ed09d6047459">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2110b35b-e887-46f6-96b0-ed09d6047459">
											<gml:posList>35.669179528793954 139.73924426876172 32.144 35.669183191257346 139.7392479649056 32.144 35.66918270883466 139.73924195639637 32.144 35.66915689115734 139.7392158847805 32.144 35.66915736455897 139.73922188225214 32.144 35.669179528793954 139.73924426876172 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-953f58d5-92e9-4b86-89de-a35dfc8c8956">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-953f58d5-92e9-4b86-89de-a35dfc8c8956">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-953f58d5-92e9-4b86-89de-a35dfc8c8956">
											<gml:posList>35.66909727118316 139.73930415773228 32.144 35.669097735575285 139.73931016625664 32.144 35.66910221923477 139.73930353334902 32.144 35.66915736455897 139.73922188225214 32.144 35.66915689115734 139.7392158847805 32.144 35.66909727118316 139.73930415773228 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e59286b-5bb6-4711-a1af-86f53098b5cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e59286b-5bb6-4711-a1af-86f53098b5cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e59286b-5bb6-4711-a1af-86f53098b5cd">
											<gml:posList>35.669097735575285 139.73931016625664 32.144 35.66909727118316 139.73930415773228 32.144 35.669030616052474 139.73923674439064 32.144 35.669025722057604 139.7392373355758 32.144 35.669097735575285 139.73931016625664 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0acd5163-1bd4-4879-962e-2aa506d0d398">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0acd5163-1bd4-4879-962e-2aa506d0d398">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0acd5163-1bd4-4879-962e-2aa506d0d398">
											<gml:posList>35.66915736455897 139.73922188225214 28.44 35.66910221923477 139.73930353334902 28.44 35.66912448276961 139.73932612962506 28.44 35.669179528793954 139.73924426876172 28.44 35.66915736455897 139.73922188225214 28.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33dda12e-100c-4c25-83b5-90911b014ec6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33dda12e-100c-4c25-83b5-90911b014ec6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33dda12e-100c-4c25-83b5-90911b014ec6">
											<gml:posList>35.669123688576285 139.73933641446246 32.144 35.669183191257346 139.7392479649056 32.144 35.669179528793954 139.73924426876172 32.144 35.66912448276961 139.73932612962506 32.144 35.66910221923477 139.73930353334902 32.144 35.669097735575285 139.73931016625664 32.144 35.669123688576285 139.73933641446246 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-534c451b-9514-4268-b6fe-630ecbe18f00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-534c451b-9514-4268-b6fe-630ecbe18f00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-534c451b-9514-4268-b6fe-630ecbe18f00">
											<gml:posList>35.669119976333064 139.73917670346114 37.374 35.669119976333064 139.73917670346114 34.759 35.669144348166 139.73914046576144 34.759 35.669144348166 139.73914046576144 37.374 35.669119976333064 139.73917670346114 37.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd7d30df-52fe-4328-89c1-160d5c02f64b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd7d30df-52fe-4328-89c1-160d5c02f64b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd7d30df-52fe-4328-89c1-160d5c02f64b">
											<gml:posList>35.669160702964604 139.73915696045512 37.374 35.669160702964604 139.73915696045512 34.759 35.66913632212168 139.73919320921388 34.759 35.66913632212168 139.73919320921388 37.374 35.669160702964604 139.73915696045512 37.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47d30b4b-1e0a-4525-a505-f946c5ddd010">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47d30b4b-1e0a-4525-a505-f946c5ddd010">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47d30b4b-1e0a-4525-a505-f946c5ddd010">
											<gml:posList>35.66913632212168 139.73919320921388 37.374 35.66913632212168 139.73919320921388 34.759 35.669119976333064 139.73917670346114 34.759 35.669119976333064 139.73917670346114 37.374 35.66913632212168 139.73919320921388 37.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bda5cb94-ede9-4dff-9537-d04f069cba9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bda5cb94-ede9-4dff-9537-d04f069cba9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bda5cb94-ede9-4dff-9537-d04f069cba9d">
											<gml:posList>35.66910221923477 139.73930353334902 32.144 35.66910221923477 139.73930353334902 28.44 35.66915736455897 139.73922188225214 28.44 35.66915736455897 139.73922188225214 32.144 35.66910221923477 139.73930353334902 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3e7a635-2fde-4574-bfd3-d3a1f0ffceb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3e7a635-2fde-4574-bfd3-d3a1f0ffceb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3e7a635-2fde-4574-bfd3-d3a1f0ffceb6">
											<gml:posList>35.669179528793954 139.73924426876172 32.144 35.669179528793954 139.73924426876172 28.44 35.66912448276961 139.73932612962506 28.44 35.66912448276961 139.73932612962506 32.144 35.669179528793954 139.73924426876172 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e599d39-a144-4302-8f8a-79b8e186f65e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e599d39-a144-4302-8f8a-79b8e186f65e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e599d39-a144-4302-8f8a-79b8e186f65e">
											<gml:posList>35.669129162107154 139.73912008147866 12.73 35.669111638458105 139.73914190703988 12.73 35.669111638458105 139.73914190703988 32.144 35.669129162107154 139.73912008147866 32.144 35.669129162107154 139.73912008147866 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a652f3ba-51e4-4a02-94e2-95cec0c3d834">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a652f3ba-51e4-4a02-94e2-95cec0c3d834">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a652f3ba-51e4-4a02-94e2-95cec0c3d834">
											<gml:posList>35.66912940098388 139.73912585830146 32.144 35.66912940098388 139.73912585830146 31.416 35.66914171446494 139.739138303822 31.416 35.66914171446494 139.739138303822 32.144 35.66912940098388 139.73912585830146 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15be691a-c0e0-49ed-80aa-f0e4809d80b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15be691a-c0e0-49ed-80aa-f0e4809d80b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15be691a-c0e0-49ed-80aa-f0e4809d80b1">
											<gml:posList>35.66911420962465 139.7391447870476 32.144 35.66911420962465 139.7391447870476 31.416 35.66912940098388 139.73912585830146 31.416 35.66912940098388 139.73912585830146 32.144 35.66911420962465 139.7391447870476 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4bf03751-f646-460b-9413-8b6c84bf0fb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4bf03751-f646-460b-9413-8b6c84bf0fb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4bf03751-f646-460b-9413-8b6c84bf0fb1">
											<gml:posList>35.6691029953915 139.7391548411107 12.73 35.66909000534703 139.73914171153132 12.73 35.66909000534703 139.73914171153132 32.144 35.6691029953915 139.7391548411107 32.144 35.6691029953915 139.7391548411107 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4792050-b5e8-434e-a45e-ae5f751542e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4792050-b5e8-434e-a45e-ae5f751542e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4792050-b5e8-434e-a45e-ae5f751542e1">
											<gml:posList>35.669111638458105 139.73914190703988 12.73 35.6691029953915 139.7391548411107 12.73 35.6691029953915 139.7391548411107 32.144 35.669111638458105 139.73914190703988 32.144 35.669111638458105 139.73914190703988 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0076d5a8-8b02-4a72-8115-79dbd04f1a8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0076d5a8-8b02-4a72-8115-79dbd04f1a8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0076d5a8-8b02-4a72-8115-79dbd04f1a8a">
											<gml:posList>35.669144348166 139.73914046576144 37.374 35.669144348166 139.73914046576144 34.759 35.669160702964604 139.73915696045512 34.759 35.669160702964604 139.73915696045512 37.374 35.669144348166 139.73914046576144 37.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b1ffe43-7c94-455b-88bb-321919850970">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b1ffe43-7c94-455b-88bb-321919850970">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b1ffe43-7c94-455b-88bb-321919850970">
											<gml:posList>35.66910347781852 139.73916084961343 32.144 35.66910347781852 139.73916084961343 31.416 35.66911420962465 139.7391447870476 31.416 35.66911420962465 139.7391447870476 32.144 35.66910347781852 139.73916084961343 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e57b340e-68e2-459f-bc3d-020f24940242">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e57b340e-68e2-459f-bc3d-020f24940242">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e57b340e-68e2-459f-bc3d-020f24940242">
											<gml:posList>35.669090478752345 139.7391477089975 32.144 35.669090478752345 139.7391477089975 31.416 35.66910347781852 139.73916084961343 31.416 35.66910347781852 139.73916084961343 32.144 35.669090478752345 139.7391477089975 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69def3ad-9e46-48ba-af51-d33069b98d37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69def3ad-9e46-48ba-af51-d33069b98d37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69def3ad-9e46-48ba-af51-d33069b98d37">
											<gml:posList>35.6691155329816 139.73917723889105 31.416 35.6691155329816 139.73917723889105 37.374 35.669143929266085 139.73913500948558 37.374 35.669143929266085 139.73913500948558 32.144 35.66914171446494 139.739138303822 32.144 35.66914171446494 139.739138303822 31.416 35.6691155329816 139.73917723889105 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a52ee75-e50c-472c-a89b-e7229cdc9c3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a52ee75-e50c-472c-a89b-e7229cdc9c3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a52ee75-e50c-472c-a89b-e7229cdc9c3a">
											<gml:posList>35.66916515533831 139.7391564360593 32.144 35.6692125509209 139.73920430941183 32.144 35.6692125509209 139.73920430941183 12.73 35.669129162107154 139.73912008147866 12.73 35.669129162107154 139.73912008147866 32.144 35.669143929266085 139.73913500948558 32.144 35.669143929266085 139.73913500948558 37.374 35.66916515533831 139.7391564360593 37.374 35.66916515533831 139.7391564360593 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2219eaa4-5fbe-48fe-8a56-fbf2cf1df76d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2219eaa4-5fbe-48fe-8a56-fbf2cf1df76d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2219eaa4-5fbe-48fe-8a56-fbf2cf1df76d">
											<gml:posList>35.66916515533831 139.7391564360593 37.374 35.669136750032685 139.73919866547894 37.374 35.669136750032685 139.73919866547894 31.416 35.669162940536594 139.739159730396 31.416 35.669162940536594 139.739159730396 32.144 35.66916515533831 139.7391564360593 32.144 35.66916515533831 139.7391564360593 37.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9de2b12-8cd8-434e-a916-4f2b15e5fd98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9de2b12-8cd8-434e-a916-4f2b15e5fd98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9de2b12-8cd8-434e-a916-4f2b15e5fd98">
											<gml:posList>35.669162940536594 139.739159730396 32.144 35.669162940536594 139.739159730396 31.416 35.66920764789535 139.73920487851876 31.416 35.66920764789535 139.73920487851876 32.144 35.669162940536594 139.739159730396 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc1c14d3-5109-4d32-8add-9c2829c4362e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc1c14d3-5109-4d32-8add-9c2829c4362e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc1c14d3-5109-4d32-8add-9c2829c4362e">
											<gml:posList>35.6691155329816 139.73917723889105 31.416 35.669136750032685 139.73919866547894 31.416 35.669136750032685 139.73919866547894 37.374 35.6691155329816 139.73917723889105 37.374 35.6691155329816 139.73917723889105 31.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea191d3b-8892-48e8-b36c-b0bc340a9bd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea191d3b-8892-48e8-b36c-b0bc340a9bd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea191d3b-8892-48e8-b36c-b0bc340a9bd8">
											<gml:posList>35.66909000534703 139.73914171153132 12.73 35.669025722057604 139.7392373355758 12.73 35.669025722057604 139.7392373355758 32.144 35.66909000534703 139.73914171153132 32.144 35.66909000534703 139.73914171153132 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5167f2c6-2c88-49f6-8b2a-afd06b0ade29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5167f2c6-2c88-49f6-8b2a-afd06b0ade29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5167f2c6-2c88-49f6-8b2a-afd06b0ade29">
											<gml:posList>35.669030616052474 139.73923674439064 32.144 35.669030616052474 139.73923674439064 31.416 35.669090478752345 139.7391477089975 31.416 35.669090478752345 139.7391477089975 32.144 35.669030616052474 139.73923674439064 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-177ef18f-41de-44bf-ba86-b460973bf46c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-177ef18f-41de-44bf-ba86-b460973bf46c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-177ef18f-41de-44bf-ba86-b460973bf46c">
											<gml:posList>35.66920764789535 139.73920487851876 32.144 35.66920764789535 139.73920487851876 31.416 35.66918270883466 139.73924195639637 31.416 35.66918270883466 139.73924195639637 32.144 35.66920764789535 139.73920487851876 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b54c77a1-68b8-4e13-8056-efeb5e113240">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b54c77a1-68b8-4e13-8056-efeb5e113240">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b54c77a1-68b8-4e13-8056-efeb5e113240">
											<gml:posList>35.66918270883466 139.73924195639637 32.144 35.66918270883466 139.73924195639637 31.416 35.66915689115734 139.7392158847805 31.416 35.66915689115734 139.7392158847805 32.144 35.66918270883466 139.73924195639637 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ae20f8b-9400-49b8-93da-a39e4d0e14ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ae20f8b-9400-49b8-93da-a39e4d0e14ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ae20f8b-9400-49b8-93da-a39e4d0e14ff">
											<gml:posList>35.66915736455897 139.73922188225214 32.144 35.66915736455897 139.73922188225214 28.44 35.669179528793954 139.73924426876172 28.44 35.669179528793954 139.73924426876172 32.144 35.66915736455897 139.73922188225214 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70b57e1e-ba40-47cb-9d2b-46cb6e7f866b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70b57e1e-ba40-47cb-9d2b-46cb6e7f866b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70b57e1e-ba40-47cb-9d2b-46cb6e7f866b">
											<gml:posList>35.66915689115734 139.7392158847805 32.144 35.66915689115734 139.7392158847805 31.416 35.66909727118316 139.73930415773228 31.416 35.66909727118316 139.73930415773228 32.144 35.66915689115734 139.7392158847805 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3127257-659d-4976-bd30-a0baa258af52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3127257-659d-4976-bd30-a0baa258af52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3127257-659d-4976-bd30-a0baa258af52">
											<gml:posList>35.66909727118316 139.73930415773228 32.144 35.66909727118316 139.73930415773228 31.416 35.669030616052474 139.73923674439064 31.416 35.669030616052474 139.73923674439064 32.144 35.66909727118316 139.73930415773228 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6339a29b-9ad3-473e-829a-9ffe1a1a11e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6339a29b-9ad3-473e-829a-9ffe1a1a11e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6339a29b-9ad3-473e-829a-9ffe1a1a11e4">
											<gml:posList>35.669123688576285 139.73933641446246 12.73 35.6692125509209 139.73920430941183 12.73 35.6692125509209 139.73920430941183 32.144 35.669183191257346 139.7392479649056 32.144 35.669123688576285 139.73933641446246 32.144 35.669123688576285 139.73933641446246 12.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5f94e29-548d-4ab5-805a-2a10ad14c4a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5f94e29-548d-4ab5-805a-2a10ad14c4a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5f94e29-548d-4ab5-805a-2a10ad14c4a8">
											<gml:posList>35.669097735575285 139.73931016625664 32.144 35.669025722057604 139.7392373355758 32.144 35.669025722057604 139.7392373355758 12.73 35.669123688576285 139.73933641446246 12.73 35.669123688576285 139.73933641446246 32.144 35.669097735575285 139.73931016625664 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af234ddd-8d79-445f-9389-626bf3407959">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af234ddd-8d79-445f-9389-626bf3407959">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af234ddd-8d79-445f-9389-626bf3407959">
											<gml:posList>35.66912448276961 139.73932612962506 32.144 35.66912448276961 139.73932612962506 28.44 35.66910221923477 139.73930353334902 28.44 35.66910221923477 139.73930353334902 32.144 35.66912448276961 139.73932612962506 32.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2466</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">222.1827</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>