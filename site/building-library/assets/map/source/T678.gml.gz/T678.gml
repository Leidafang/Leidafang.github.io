<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c53a57fa-3b74-430e-829c-1082e5d3d606">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">25.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67295138890517 139.73811147484784 0 35.67294225248913 139.7381159043445 0 35.67296922595015 139.73820128474262 0 35.67304752583051 139.73816407516355 0 35.67300776727005 139.7380399583382 0 35.67293908163933 139.7380728263246 0 35.67295138890517 139.73811147484784 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67295138890517 139.73811147484784 8.44 35.67293908163933 139.7380728263246 8.44 35.67300776727005 139.7380399583382 8.44 35.67304752583051 139.73816407516355 8.44 35.67296922595015 139.73820128474262 8.44 35.67294225248913 139.7381159043445 8.44 35.67295138890517 139.73811147484784 8.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67295138890517 139.73811147484784 8.44 35.67294225248913 139.7381159043445 8.44 35.67294225248913 139.7381159043445 32.48 35.67295138890517 139.73811147484784 32.48 35.67295138890517 139.73811147484784 8.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67294225248913 139.7381159043445 8.44 35.67296922595015 139.73820128474262 8.44 35.67296922595015 139.73820128474262 32.48 35.67294225248913 139.7381159043445 32.48 35.67294225248913 139.7381159043445 8.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67296922595015 139.73820128474262 8.44 35.67304752583051 139.73816407516355 8.44 35.67304752583051 139.73816407516355 32.48 35.67296922595015 139.73820128474262 32.48 35.67296922595015 139.73820128474262 8.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67304752583051 139.73816407516355 8.44 35.67300776727005 139.7380399583382 8.44 35.67300776727005 139.7380399583382 32.48 35.67304752583051 139.73816407516355 32.48 35.67304752583051 139.73816407516355 8.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67300776727005 139.7380399583382 8.44 35.67293908163933 139.7380728263246 8.44 35.67293908163933 139.7380728263246 32.48 35.67300776727005 139.7380399583382 32.48 35.67300776727005 139.7380399583382 8.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67293908163933 139.7380728263246 8.44 35.67295138890517 139.73811147484784 8.44 35.67295138890517 139.73811147484784 32.48 35.67293908163933 139.7380728263246 32.48 35.67293908163933 139.7380728263246 8.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67295138890517 139.73811147484784 32.48 35.67294225248913 139.7381159043445 32.48 35.67296922595015 139.73820128474262 32.48 35.67304752583051 139.73816407516355 32.48 35.67300776727005 139.7380399583382 32.48 35.67293908163933 139.7380728263246 32.48 35.67295138890517 139.73811147484784 32.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-84e2bbd6-6ee0-4daa-987f-c80704bbdfd8"/>
							<gml:surfaceMember xlink:href="#poly-0b7a2224-055a-45e1-ba02-93ed9a48f54d"/>
							<gml:surfaceMember xlink:href="#poly-fbd86876-8672-4d4f-a7ec-05f6baab48af"/>
							<gml:surfaceMember xlink:href="#poly-d7cfb612-9728-4c8a-8186-f09cb21bf551"/>
							<gml:surfaceMember xlink:href="#poly-04eceb4b-70c9-4607-bd01-770c69ac784e"/>
							<gml:surfaceMember xlink:href="#poly-13b1d360-372b-459b-a449-68411a3cf2bd"/>
							<gml:surfaceMember xlink:href="#poly-95144249-3cc6-4739-acd0-a78409477e43"/>
							<gml:surfaceMember xlink:href="#poly-e73e59b4-e3f1-4e7f-b5aa-28f3ea2ef8e2"/>
							<gml:surfaceMember xlink:href="#poly-ed391e20-f8e3-430f-a9f5-dbf692928434"/>
							<gml:surfaceMember xlink:href="#poly-00cda651-753b-4967-a6c8-2ea935ddbacd"/>
							<gml:surfaceMember xlink:href="#poly-470081fe-c97e-430a-850a-6e6a01efd660"/>
							<gml:surfaceMember xlink:href="#poly-d9ab9ced-99b6-4a3a-ba0f-21d5d7f24a2f"/>
							<gml:surfaceMember xlink:href="#poly-fac0a064-9025-4d9e-80f7-dae9fda0e884"/>
							<gml:surfaceMember xlink:href="#poly-ec1422f3-f78b-401e-a82c-d12a97214deb"/>
							<gml:surfaceMember xlink:href="#poly-f6caabbc-4e8c-46a3-86a4-6aae6e452e5d"/>
							<gml:surfaceMember xlink:href="#poly-3e8e1cf0-70e0-4a70-9561-40bdb8f6f3a6"/>
							<gml:surfaceMember xlink:href="#poly-428ec280-ae52-4c32-9bfe-708bc17acf5b"/>
							<gml:surfaceMember xlink:href="#poly-6fbb77b1-7598-4d7d-86e4-7494052d3a3f"/>
							<gml:surfaceMember xlink:href="#poly-0679e883-9832-41a7-97c6-feed3ad0cf7c"/>
							<gml:surfaceMember xlink:href="#poly-de2415c6-7d25-4c7f-84cf-89b3968719db"/>
							<gml:surfaceMember xlink:href="#poly-3d02d151-1fb6-459c-b8c7-86834aeedd31"/>
							<gml:surfaceMember xlink:href="#poly-d818cc30-3eb4-46dc-8070-c90b6ed9226d"/>
							<gml:surfaceMember xlink:href="#poly-d52b4e9d-a19e-4c40-be7a-953e4e48acd5"/>
							<gml:surfaceMember xlink:href="#poly-6637c4b0-788d-473c-9cf3-242c96f4be9c"/>
							<gml:surfaceMember xlink:href="#poly-0e768931-bedc-4f19-83c1-11ec1ff1f9f2"/>
							<gml:surfaceMember xlink:href="#poly-33ea4da9-19a7-4e51-9aea-4554fddbe93f"/>
							<gml:surfaceMember xlink:href="#poly-478cd84b-a566-4aaf-b4d3-77413eeba84c"/>
							<gml:surfaceMember xlink:href="#poly-a8152353-c746-4d36-987c-d36833a9c949"/>
							<gml:surfaceMember xlink:href="#poly-c6649e98-19e5-4e6d-833e-59a1ca30255a"/>
							<gml:surfaceMember xlink:href="#poly-c4c5ade8-3593-44dc-af76-17bcf07e7d7f"/>
							<gml:surfaceMember xlink:href="#poly-c74b3a6a-6761-4269-a099-d245e963775a"/>
							<gml:surfaceMember xlink:href="#poly-f1e841e8-ec4a-4150-9dd9-f73be1f8b5d1"/>
							<gml:surfaceMember xlink:href="#poly-3c7665bd-690c-44cf-b9da-cd600837d93c"/>
							<gml:surfaceMember xlink:href="#poly-4fa29d00-c03a-45fc-baa8-8b02ae24291c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c53a57fa-3b74-430e-829c-1082e5d3d606_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e533580-be02-4d56-a549-3a379ffc727f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67297851196864 139.7380782475477 39.765 35.67298243367429 139.73809057091344 39.765 35.672964827518086 139.73809899830403 39.765 35.67296090581327 139.73808667494058 39.765 35.67297851196864 139.7380782475477 39.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61aa6212-9bab-4ee0-b98a-835f388b7ab6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67301792417328 139.7381177365818 32.331 35.673003120215995 139.73812481295465 32.331 35.67299614430283 139.7381029157924 32.331 35.673010948258835 139.73809583941616 32.331 35.67301792417328 139.7381177365818 32.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-009ca1c9-0ba3-4152-b68b-eb1896195346">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-009ca1c9-0ba3-4152-b68b-eb1896195346_0">
											<gml:posList>35.67296090581327 139.73808667494058 39.765 35.672964827518086 139.73809899830403 39.765 35.672964827518086 139.73809899830403 42.191 35.67296090581327 139.73808667494058 42.191 35.67296090581327 139.73808667494058 39.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bddbf03a-21df-4193-bb6f-475e8229af0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bddbf03a-21df-4193-bb6f-475e8229af0a_0">
											<gml:posList>35.67297851196864 139.7380782475477 39.765 35.67296090581327 139.73808667494058 39.765 35.67296090581327 139.73808667494058 42.191 35.67297851196864 139.7380782475477 42.191 35.67297851196864 139.7380782475477 39.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0a75f65-48c4-4178-8002-81612015087a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0a75f65-48c4-4178-8002-81612015087a_0">
											<gml:posList>35.67297851196864 139.7380782475477 42.191 35.67296090581327 139.73808667494058 42.191 35.672964827518086 139.73809899830403 42.191 35.67298243367429 139.73809057091344 42.191 35.67297851196864 139.7380782475477 42.191</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d7f6158-eaac-43a8-9c3c-e3e300b286a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d7f6158-eaac-43a8-9c3c-e3e300b286a4_0">
											<gml:posList>35.672964827518086 139.73809899830403 39.765 35.67298243367429 139.73809057091344 39.765 35.67298243367429 139.73809057091344 42.191 35.672964827518086 139.73809899830403 42.191 35.672964827518086 139.73809899830403 39.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-292202fa-6aea-4542-b427-1a9541a09190">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-292202fa-6aea-4542-b427-1a9541a09190_0">
											<gml:posList>35.67297851196864 139.7380782475477 39.765 35.67297851196864 139.7380782475477 42.191 35.67298243367429 139.73809057091344 42.191 35.67298243367429 139.73809057091344 39.765 35.67297851196864 139.7380782475477 39.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7c27173-f2b9-4dc4-80fb-67d7785a6f7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7c27173-f2b9-4dc4-80fb-67d7785a6f7a_0">
											<gml:posList>35.67299614430283 139.7381029157924 32.331 35.673003120215995 139.73812481295465 32.331 35.673003120215995 139.73812481295465 34.685 35.67299614430283 139.7381029157924 34.685 35.67299614430283 139.7381029157924 32.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd1d4fce-fd10-4646-a4eb-41ddc61d051c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd1d4fce-fd10-4646-a4eb-41ddc61d051c_0">
											<gml:posList>35.67299614430283 139.7381029157924 32.331 35.67299614430283 139.7381029157924 34.685 35.673010948258835 139.73809583941616 34.685 35.673010948258835 139.73809583941616 32.331 35.67299614430283 139.7381029157924 32.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad07b10f-620b-4b94-bafb-c31dd31dc862">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad07b10f-620b-4b94-bafb-c31dd31dc862_0">
											<gml:posList>35.67301792417328 139.7381177365818 34.685 35.673010948258835 139.73809583941616 34.685 35.67299614430283 139.7381029157924 34.685 35.673003120215995 139.73812481295465 34.685 35.67301792417328 139.7381177365818 34.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c18ea7b-ce1f-464f-8cd3-20c0d502d932">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c18ea7b-ce1f-464f-8cd3-20c0d502d932_0">
											<gml:posList>35.673003120215995 139.73812481295465 32.331 35.67301792417328 139.7381177365818 32.331 35.67301792417328 139.7381177365818 34.685 35.673003120215995 139.73812481295465 34.685 35.673003120215995 139.73812481295465 32.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e11d06b-1e59-4eb3-98b4-3e253e39efc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e11d06b-1e59-4eb3-98b4-3e253e39efc4_0">
											<gml:posList>35.67301792417328 139.7381177365818 32.331 35.673010948258835 139.73809583941616 32.331 35.673010948258835 139.73809583941616 34.685 35.67301792417328 139.7381177365818 34.685 35.67301792417328 139.7381177365818 32.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c53a57fa-3b74-430e-829c-1082e5d3d606_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20fec2ac-ffa1-4647-ac57-61bf27b0b7b5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672930008250795 139.7380771673772 8.62 35.672939072625596 139.7380728263353 8.62 35.67295138890517 139.73811147484784 8.62 35.67294225249787 139.7381159153911 8.62 35.672930008250795 139.7380771673772 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae8e8d6d-9019-49a1-b4a7-62bef9dc4c1b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67296054579458 139.73811013837795 32.332 35.672991216906524 139.73809545413107 32.332 35.67299437053986 139.7381053702489 32.332 35.67298627926989 139.7381092351297 32.332 35.67298982145284 139.73812036591409 32.332 35.672967250604934 139.7381311631704 32.332 35.67296054579458 139.73811013837795 32.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d20e92c0-27b8-4468-9a68-e0a74e59153a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d20e92c0-27b8-4468-9a68-e0a74e59153a_0">
											<gml:posList>35.672939072625596 139.7380728263353 33.484 35.672939072625596 139.7380728263353 8.62 35.672930008250795 139.7380771673772 8.62 35.672930008250795 139.7380771673772 33.484 35.672939072625596 139.7380728263353 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0df7d5a-09bb-48be-8183-6e2759044cee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0df7d5a-09bb-48be-8183-6e2759044cee_0">
											<gml:posList>35.672930008250795 139.7380771673772 33.484 35.672930008250795 139.7380771673772 8.62 35.67294225249787 139.7381159153911 8.62 35.67294225249787 139.7381159153911 33.484 35.672930008250795 139.7380771673772 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a805af3-9b58-4bef-8b07-027de5d11a07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a805af3-9b58-4bef-8b07-027de5d11a07_0">
											<gml:posList>35.67294225249787 139.7381159153911 33.484 35.67295138890517 139.73811147484784 33.484 35.672939072625596 139.7380728263353 33.484 35.672930008250795 139.7380771673772 33.484 35.67294225249787 139.7381159153911 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cad2a084-ee88-4927-a941-992600d7a883">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cad2a084-ee88-4927-a941-992600d7a883_0">
											<gml:posList>35.67295138890517 139.73811147484784 33.484 35.67295138890517 139.73811147484784 8.62 35.672939072625596 139.7380728263353 8.62 35.672939072625596 139.7380728263353 33.484 35.67295138890517 139.73811147484784 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a574238-a8c7-484c-bf03-7d8a8d4023ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a574238-a8c7-484c-bf03-7d8a8d4023ff_0">
											<gml:posList>35.67294225249787 139.7381159153911 33.484 35.67294225249787 139.7381159153911 8.62 35.67295138890517 139.73811147484784 8.62 35.67295138890517 139.73811147484784 33.484 35.67294225249787 139.7381159153911 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed231478-1288-47d8-b595-5fd828ce3a4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed231478-1288-47d8-b595-5fd828ce3a4d_0">
											<gml:posList>35.67296054579458 139.73811013837795 32.909 35.67296054579458 139.73811013837795 32.332 35.672967250604934 139.7381311631704 32.332 35.672967250604934 139.7381311631704 32.909 35.67296054579458 139.73811013837795 32.909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4181d2fa-db07-4d0c-9198-b663d67f72ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4181d2fa-db07-4d0c-9198-b663d67f72ac_0">
											<gml:posList>35.672991216906524 139.73809545413107 32.909 35.672991216906524 139.73809545413107 32.332 35.67296054579458 139.73811013837795 32.332 35.67296054579458 139.73811013837795 32.909 35.672991216906524 139.73809545413107 32.909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a6fbb91-8216-415f-adbe-59df4f7c1eb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a6fbb91-8216-415f-adbe-59df4f7c1eb9_0">
											<gml:posList>35.67296054579458 139.73811013837795 32.909 35.672967250604934 139.7381311631704 32.909 35.67298982145284 139.73812036591409 32.909 35.67298627926989 139.7381092351297 32.909 35.67299437053986 139.7381053702489 32.909 35.672991216906524 139.73809545413107 32.909 35.67296054579458 139.73811013837795 32.909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d824c60d-a85a-4fe5-8ccc-a622b1217e44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d824c60d-a85a-4fe5-8ccc-a622b1217e44_0">
											<gml:posList>35.672967250604934 139.7381311631704 32.909 35.672967250604934 139.7381311631704 32.332 35.67298982145284 139.73812036591409 32.332 35.67298982145284 139.73812036591409 32.909 35.672967250604934 139.7381311631704 32.909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e434bc09-e9ef-479d-b48b-0eac9c7c903e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e434bc09-e9ef-479d-b48b-0eac9c7c903e_0">
											<gml:posList>35.67298982145284 139.73812036591409 32.909 35.67298982145284 139.73812036591409 32.332 35.67298627926989 139.7381092351297 32.332 35.67298627926989 139.7381092351297 32.909 35.67298982145284 139.73812036591409 32.909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14245079-63b9-44d4-996b-f454aa9f5cae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14245079-63b9-44d4-996b-f454aa9f5cae_0">
											<gml:posList>35.67298627926989 139.7381092351297 32.909 35.67298627926989 139.7381092351297 32.332 35.67299437053986 139.7381053702489 32.332 35.67299437053986 139.7381053702489 32.909 35.67298627926989 139.7381092351297 32.909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0ceb747-5b69-43b2-8b9a-bf96580a2bc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0ceb747-5b69-43b2-8b9a-bf96580a2bc7_0">
											<gml:posList>35.67299437053986 139.7381053702489 32.909 35.67299437053986 139.7381053702489 32.332 35.672991216906524 139.73809545413107 32.332 35.672991216906524 139.73809545413107 32.909 35.67299437053986 139.7381053702489 32.909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c53a57fa-3b74-430e-829c-1082e5d3d606_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53eb8f68-ecb4-4ecd-abe8-993f568c3642">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673029449047334 139.73815868377662 32.331 35.67298430783272 139.73818089688237 32.331 35.67297371819948 139.7381485760044 32.331 35.673018868421906 139.73812636287272 32.331 35.673029449047334 139.73815868377662 32.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a50fa79b-89da-4f38-b86e-ef7716412bde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a50fa79b-89da-4f38-b86e-ef7716412bde_0">
											<gml:posList>35.67297371819948 139.7381485760044 32.331 35.67297371819948 139.7381485760044 34.603 35.673018868421906 139.73812636287272 34.603 35.673018868421906 139.73812636287272 32.331 35.67297371819948 139.7381485760044 32.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef1580bd-518b-4ad6-931b-ca1d736a69b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef1580bd-518b-4ad6-931b-ca1d736a69b0_0">
											<gml:posList>35.673018868421906 139.73812636287272 32.331 35.673018868421906 139.73812636287272 34.603 35.673029449047334 139.73815868377662 34.603 35.673029449047334 139.73815868377662 32.331 35.673018868421906 139.73812636287272 32.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-845c8c90-8220-4123-a052-c5d2d0cc4d6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-845c8c90-8220-4123-a052-c5d2d0cc4d6a_0">
											<gml:posList>35.673029449047334 139.73815868377662 34.603 35.673018868421906 139.73812636287272 34.603 35.67297371819948 139.7381485760044 34.603 35.67298430783272 139.73818089688237 34.603 35.673029449047334 139.73815868377662 34.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9d60826-cb46-493b-a736-88eca6a26d07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9d60826-cb46-493b-a736-88eca6a26d07_0">
											<gml:posList>35.67298430783272 139.73818089688237 32.331 35.67298430783272 139.73818089688237 34.603 35.67297371819948 139.7381485760044 34.603 35.67297371819948 139.7381485760044 32.331 35.67298430783272 139.73818089688237 32.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44b44143-7432-4940-b8ff-69aaa28456e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44b44143-7432-4940-b8ff-69aaa28456e2_0">
											<gml:posList>35.673029449047334 139.73815868377662 32.331 35.673029449047334 139.73815868377662 34.603 35.67298430783272 139.73818089688237 34.603 35.67298430783272 139.73818089688237 32.331 35.673029449047334 139.73815868377662 32.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-84e2bbd6-6ee0-4daa-987f-c80704bbdfd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84e2bbd6-6ee0-4daa-987f-c80704bbdfd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84e2bbd6-6ee0-4daa-987f-c80704bbdfd8">
											<gml:posList>35.67295138890517 139.73811147484784 8.44 35.672939081639306 139.73807282632458 8.44 35.67300776727005 139.73803995833816 8.44 35.673047525830476 139.73816407516358 8.44 35.67296922595013 139.73820128474262 8.44 35.67294225248913 139.7381159043445 8.44 35.67295138890517 139.73811147484784 8.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b7a2224-055a-45e1-ba02-93ed9a48f54d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b7a2224-055a-45e1-ba02-93ed9a48f54d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b7a2224-055a-45e1-ba02-93ed9a48f54d">
											<gml:posList>35.67295525742388 139.73811353596983 33.484 35.672942950167425 139.738074898491 33.484 35.672939081639306 139.73807282632458 33.484 35.67295138890517 139.73811147484784 33.484 35.67295525742388 139.73811353596983 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fbd86876-8672-4d4f-a7ec-05f6baab48af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbd86876-8672-4d4f-a7ec-05f6baab48af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbd86876-8672-4d4f-a7ec-05f6baab48af">
											<gml:posList>35.67294611200278 139.73811797652377 33.484 35.67295525742388 139.73811353596983 33.484 35.67295138890517 139.73811147484784 33.484 35.67294225248913 139.7381159043445 33.484 35.67294611200278 139.73811797652377 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d7cfb612-9728-4c8a-8186-f09cb21bf551">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7cfb612-9728-4c8a-8186-f09cb21bf551">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7cfb612-9728-4c8a-8186-f09cb21bf551">
											<gml:posList>35.672960075237924 139.7381078081012 39.982 35.67295174388215 139.7380816375231 39.982 35.67294922798865 139.73808029282552 39.982 35.672958968987935 139.73811089142063 39.982 35.672960075237924 139.7381078081012 39.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04eceb4b-70c9-4607-bd01-770c69ac784e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04eceb4b-70c9-4607-bd01-770c69ac784e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04eceb4b-70c9-4607-bd01-770c69ac784e">
											<gml:posList>35.67296922595013 139.73820128474262 33.484 35.67297094382609 139.7381965437058 33.484 35.67294611200278 139.73811797652377 33.484 35.67294225248913 139.7381159043445 33.484 35.67296922595013 139.73820128474262 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-13b1d360-372b-459b-a449-68411a3cf2bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13b1d360-372b-459b-a449-68411a3cf2bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13b1d360-372b-459b-a449-68411a3cf2bd">
											<gml:posList>35.67294922798865 139.73808029282552 39.982 35.67295174388215 139.7380816375231 39.982 35.67298277539954 139.73806677609278 39.982 35.67298387264341 139.7380637038291 39.982 35.67294922798865 139.73808029282552 39.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-95144249-3cc6-4739-acd0-a78409477e43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95144249-3cc6-4739-acd0-a78409477e43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95144249-3cc6-4739-acd0-a78409477e43">
											<gml:posList>35.67295174388215 139.7380816375231 39.765 35.672960075237924 139.7381078081012 39.765 35.672991115772234 139.7380929466687 39.765 35.67298277539954 139.73806677609278 39.765 35.67295174388215 139.7380816375231 39.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e73e59b4-e3f1-4e7f-b5aa-28f3ea2ef8e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e73e59b4-e3f1-4e7f-b5aa-28f3ea2ef8e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e73e59b4-e3f1-4e7f-b5aa-28f3ea2ef8e2">
											<gml:posList>35.672942950167425 139.738074898491 33.484 35.673006076441446 139.7380446993484 33.484 35.67300776727005 139.73803995833816 33.484 35.672939081639306 139.73807282632458 33.484 35.672942950167425 139.738074898491 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed391e20-f8e3-430f-a9f5-dbf692928434">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed391e20-f8e3-430f-a9f5-dbf692928434">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed391e20-f8e3-430f-a9f5-dbf692928434">
											<gml:posList>35.672942950167425 139.738074898491 32.332 35.67294922798865 139.73808029282552 32.332 35.67298387264341 139.7380637038291 32.332 35.673006076441446 139.7380446993484 32.332 35.672942950167425 139.738074898491 32.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00cda651-753b-4967-a6c8-2ea935ddbacd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00cda651-753b-4967-a6c8-2ea935ddbacd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00cda651-753b-4967-a6c8-2ea935ddbacd">
											<gml:posList>35.672958968987935 139.73811089142063 39.982 35.672993622660584 139.7380943024247 39.982 35.672991115772234 139.7380929466687 39.982 35.672960075237924 139.7381078081012 39.982 35.672958968987935 139.73811089142063 39.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-470081fe-c97e-430a-850a-6e6a01efd660">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-470081fe-c97e-430a-850a-6e6a01efd660">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-470081fe-c97e-430a-850a-6e6a01efd660">
											<gml:posList>35.672993622660584 139.7380943024247 39.982 35.67298387264341 139.7380637038291 39.982 35.67298277539954 139.73806677609278 39.982 35.672991115772234 139.7380929466687 39.982 35.672993622660584 139.7380943024247 39.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d9ab9ced-99b6-4a3a-ba0f-21d5d7f24a2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9ab9ced-99b6-4a3a-ba0f-21d5d7f24a2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9ab9ced-99b6-4a3a-ba0f-21d5d7f24a2f">
											<gml:posList>35.673006076441446 139.7380446993484 32.332 35.67298387264341 139.7380637038291 32.332 35.672993622660584 139.7380943024247 32.332 35.672958968987935 139.73811089142063 32.332 35.67294922798865 139.73808029282552 32.332 35.672942950167425 139.738074898491 32.332 35.67295525742388 139.73811353596983 32.332 35.67294611200278 139.73811797652377 32.332 35.67297094382609 139.7381965437058 32.332 35.67304365729523 139.73816199194354 32.332 35.673006076441446 139.7380446993484 32.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fac0a064-9025-4d9e-80f7-dae9fda0e884">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fac0a064-9025-4d9e-80f7-dae9fda0e884">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fac0a064-9025-4d9e-80f7-dae9fda0e884">
											<gml:posList>35.67296922595013 139.73820128474262 33.484 35.673047525830476 139.73816407516358 33.484 35.67304365729523 139.73816199194354 33.484 35.67297094382609 139.7381965437058 33.484 35.67296922595013 139.73820128474262 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec1422f3-f78b-401e-a82c-d12a97214deb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec1422f3-f78b-401e-a82c-d12a97214deb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec1422f3-f78b-401e-a82c-d12a97214deb">
											<gml:posList>35.673006076441446 139.7380446993484 33.484 35.67304365729523 139.73816199194354 33.484 35.673047525830476 139.73816407516358 33.484 35.67300776727005 139.73803995833816 33.484 35.673006076441446 139.7380446993484 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6caabbc-4e8c-46a3-86a4-6aae6e452e5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6caabbc-4e8c-46a3-86a4-6aae6e452e5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6caabbc-4e8c-46a3-86a4-6aae6e452e5d">
											<gml:posList>35.67296922595013 139.73820128474262 33.484 35.67296922595013 139.73820128474262 8.44 35.673047525830476 139.73816407516358 8.44 35.673047525830476 139.73816407516358 33.484 35.67296922595013 139.73820128474262 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e8e1cf0-70e0-4a70-9561-40bdb8f6f3a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e8e1cf0-70e0-4a70-9561-40bdb8f6f3a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e8e1cf0-70e0-4a70-9561-40bdb8f6f3a6">
											<gml:posList>35.672939081639306 139.73807282632458 33.484 35.672939081639306 139.73807282632458 8.44 35.67295138890517 139.73811147484784 8.44 35.67295138890517 139.73811147484784 33.484 35.672939081639306 139.73807282632458 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-428ec280-ae52-4c32-9bfe-708bc17acf5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-428ec280-ae52-4c32-9bfe-708bc17acf5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-428ec280-ae52-4c32-9bfe-708bc17acf5b">
											<gml:posList>35.67295138890517 139.73811147484784 33.484 35.67295138890517 139.73811147484784 8.44 35.67294225248913 139.7381159043445 8.44 35.67294225248913 139.7381159043445 33.484 35.67295138890517 139.73811147484784 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6fbb77b1-7598-4d7d-86e4-7494052d3a3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fbb77b1-7598-4d7d-86e4-7494052d3a3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fbb77b1-7598-4d7d-86e4-7494052d3a3f">
											<gml:posList>35.67295525742388 139.73811353596983 32.332 35.672942950167425 139.738074898491 32.332 35.672942950167425 139.738074898491 33.484 35.67295525742388 139.73811353596983 33.484 35.67295525742388 139.73811353596983 32.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0679e883-9832-41a7-97c6-feed3ad0cf7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0679e883-9832-41a7-97c6-feed3ad0cf7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0679e883-9832-41a7-97c6-feed3ad0cf7c">
											<gml:posList>35.67294611200278 139.73811797652377 32.332 35.67295525742388 139.73811353596983 32.332 35.67295525742388 139.73811353596983 33.484 35.67294611200278 139.73811797652377 33.484 35.67294611200278 139.73811797652377 32.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de2415c6-7d25-4c7f-84cf-89b3968719db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de2415c6-7d25-4c7f-84cf-89b3968719db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de2415c6-7d25-4c7f-84cf-89b3968719db">
											<gml:posList>35.67294922798865 139.73808029282552 39.982 35.67294922798865 139.73808029282552 32.332 35.672958968987935 139.73811089142063 32.332 35.672958968987935 139.73811089142063 39.982 35.67294922798865 139.73808029282552 39.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d02d151-1fb6-459c-b8c7-86834aeedd31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d02d151-1fb6-459c-b8c7-86834aeedd31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d02d151-1fb6-459c-b8c7-86834aeedd31">
											<gml:posList>35.67294225248913 139.7381159043445 33.484 35.67294225248913 139.7381159043445 8.44 35.67296922595013 139.73820128474262 8.44 35.67296922595013 139.73820128474262 33.484 35.67294225248913 139.7381159043445 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d818cc30-3eb4-46dc-8070-c90b6ed9226d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d818cc30-3eb4-46dc-8070-c90b6ed9226d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d818cc30-3eb4-46dc-8070-c90b6ed9226d">
											<gml:posList>35.672960075237924 139.7381078081012 39.765 35.67295174388215 139.7380816375231 39.765 35.67295174388215 139.7380816375231 39.982 35.672960075237924 139.7381078081012 39.982 35.672960075237924 139.7381078081012 39.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d52b4e9d-a19e-4c40-be7a-953e4e48acd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d52b4e9d-a19e-4c40-be7a-953e4e48acd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d52b4e9d-a19e-4c40-be7a-953e4e48acd5">
											<gml:posList>35.67297094382609 139.7381965437058 32.332 35.67294611200278 139.73811797652377 32.332 35.67294611200278 139.73811797652377 33.484 35.67297094382609 139.7381965437058 33.484 35.67297094382609 139.7381965437058 32.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6637c4b0-788d-473c-9cf3-242c96f4be9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6637c4b0-788d-473c-9cf3-242c96f4be9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6637c4b0-788d-473c-9cf3-242c96f4be9c">
											<gml:posList>35.67294922798865 139.73808029282552 39.982 35.67298387264341 139.7380637038291 39.982 35.67298387264341 139.7380637038291 32.332 35.67294922798865 139.73808029282552 32.332 35.67294922798865 139.73808029282552 39.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e768931-bedc-4f19-83c1-11ec1ff1f9f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e768931-bedc-4f19-83c1-11ec1ff1f9f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e768931-bedc-4f19-83c1-11ec1ff1f9f2">
											<gml:posList>35.67295174388215 139.7380816375231 39.765 35.67298277539954 139.73806677609278 39.765 35.67298277539954 139.73806677609278 39.982 35.67295174388215 139.7380816375231 39.982 35.67295174388215 139.7380816375231 39.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33ea4da9-19a7-4e51-9aea-4554fddbe93f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33ea4da9-19a7-4e51-9aea-4554fddbe93f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33ea4da9-19a7-4e51-9aea-4554fddbe93f">
											<gml:posList>35.67300776727005 139.73803995833816 33.484 35.67300776727005 139.73803995833816 8.44 35.672939081639306 139.73807282632458 8.44 35.672939081639306 139.73807282632458 33.484 35.67300776727005 139.73803995833816 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-478cd84b-a566-4aaf-b4d3-77413eeba84c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-478cd84b-a566-4aaf-b4d3-77413eeba84c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-478cd84b-a566-4aaf-b4d3-77413eeba84c">
											<gml:posList>35.673006076441446 139.7380446993484 33.484 35.672942950167425 139.738074898491 33.484 35.672942950167425 139.738074898491 32.332 35.673006076441446 139.7380446993484 32.332 35.673006076441446 139.7380446993484 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8152353-c746-4d36-987c-d36833a9c949">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8152353-c746-4d36-987c-d36833a9c949">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8152353-c746-4d36-987c-d36833a9c949">
											<gml:posList>35.672991115772234 139.7380929466687 39.765 35.672960075237924 139.7381078081012 39.765 35.672960075237924 139.7381078081012 39.982 35.672991115772234 139.7380929466687 39.982 35.672991115772234 139.7380929466687 39.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6649e98-19e5-4e6d-833e-59a1ca30255a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6649e98-19e5-4e6d-833e-59a1ca30255a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6649e98-19e5-4e6d-833e-59a1ca30255a">
											<gml:posList>35.672993622660584 139.7380943024247 39.982 35.672958968987935 139.73811089142063 39.982 35.672958968987935 139.73811089142063 32.332 35.672993622660584 139.7380943024247 32.332 35.672993622660584 139.7380943024247 39.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4c5ade8-3593-44dc-af76-17bcf07e7d7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4c5ade8-3593-44dc-af76-17bcf07e7d7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4c5ade8-3593-44dc-af76-17bcf07e7d7f">
											<gml:posList>35.67298277539954 139.73806677609278 39.765 35.672991115772234 139.7380929466687 39.765 35.672991115772234 139.7380929466687 39.982 35.67298277539954 139.73806677609278 39.982 35.67298277539954 139.73806677609278 39.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c74b3a6a-6761-4269-a099-d245e963775a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c74b3a6a-6761-4269-a099-d245e963775a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c74b3a6a-6761-4269-a099-d245e963775a">
											<gml:posList>35.672993622660584 139.7380943024247 39.982 35.672993622660584 139.7380943024247 32.332 35.67298387264341 139.7380637038291 32.332 35.67298387264341 139.7380637038291 39.982 35.672993622660584 139.7380943024247 39.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1e841e8-ec4a-4150-9dd9-f73be1f8b5d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1e841e8-ec4a-4150-9dd9-f73be1f8b5d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1e841e8-ec4a-4150-9dd9-f73be1f8b5d1">
											<gml:posList>35.67304365729523 139.73816199194354 32.332 35.67297094382609 139.7381965437058 32.332 35.67297094382609 139.7381965437058 33.484 35.67304365729523 139.73816199194354 33.484 35.67304365729523 139.73816199194354 32.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c7665bd-690c-44cf-b9da-cd600837d93c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c7665bd-690c-44cf-b9da-cd600837d93c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c7665bd-690c-44cf-b9da-cd600837d93c">
											<gml:posList>35.67304365729523 139.73816199194354 33.484 35.673006076441446 139.7380446993484 33.484 35.673006076441446 139.7380446993484 32.332 35.67304365729523 139.73816199194354 32.332 35.67304365729523 139.73816199194354 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fa29d00-c03a-45fc-baa8-8b02ae24291c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fa29d00-c03a-45fc-baa8-8b02ae24291c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fa29d00-c03a-45fc-baa8-8b02ae24291c">
											<gml:posList>35.673047525830476 139.73816407516358 33.484 35.673047525830476 139.73816407516358 8.44 35.67300776727005 139.73803995833816 8.44 35.67300776727005 139.73803995833816 33.484 35.673047525830476 139.73816407516358 33.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8356</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">112.0216</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.19</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>