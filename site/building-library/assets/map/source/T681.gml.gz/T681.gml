<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c606e45a-3b13-401a-a6d1-0b036bf8d3ed">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">11.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66868515278562 139.73979987854347 0 35.66863402316085 139.73974867361315 0 35.66859900062187 139.73980129351597 0 35.66865150115971 139.73985359041538 0 35.66868515278562 139.73979987854347 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868515278562 139.73979987854347 11.329 35.66865150115971 139.73985359041538 11.329 35.66859900062187 139.73980129351597 11.329 35.66863402316085 139.73974867361315 11.329 35.66868515278562 139.73979987854347 11.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868515278562 139.73979987854347 11.329 35.66863402316085 139.73974867361315 11.329 35.66863402316085 139.73974867361315 23.14 35.66868515278562 139.73979987854347 23.14 35.66868515278562 139.73979987854347 11.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863402316085 139.73974867361315 11.329 35.66859900062187 139.73980129351597 11.329 35.66859900062187 139.73980129351597 23.14 35.66863402316085 139.73974867361315 23.14 35.66863402316085 139.73974867361315 11.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66859900062187 139.73980129351597 11.329 35.66865150115971 139.73985359041538 11.329 35.66865150115971 139.73985359041538 23.14 35.66859900062187 139.73980129351597 23.14 35.66859900062187 139.73980129351597 11.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865150115971 139.73985359041538 11.329 35.66868515278562 139.73979987854347 11.329 35.66868515278562 139.73979987854347 23.14 35.66865150115971 139.73985359041538 23.14 35.66865150115971 139.73985359041538 11.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868515278562 139.73979987854347 23.14 35.66863402316085 139.73974867361315 23.14 35.66859900062187 139.73980129351597 23.14 35.66865150115971 139.73985359041538 23.14 35.66868515278562 139.73979987854347 23.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c7a51967-8625-43b3-bc93-5463394e7003"/>
							<gml:surfaceMember xlink:href="#poly-1a072369-6515-4ae1-8acf-59fb1f8e288f"/>
							<gml:surfaceMember xlink:href="#poly-48dcd173-0279-4010-80ee-f2e27ab751d7"/>
							<gml:surfaceMember xlink:href="#poly-c50ba1e6-c02a-4550-a4ff-179805abf4da"/>
							<gml:surfaceMember xlink:href="#poly-2be7567b-4375-44f0-a5da-d381aa20a6b9"/>
							<gml:surfaceMember xlink:href="#poly-8a31ce58-5c04-4ccf-a98d-fde785919df6"/>
							<gml:surfaceMember xlink:href="#poly-6c88aab1-dbcc-4be5-aa2d-67de9e18a33f"/>
							<gml:surfaceMember xlink:href="#poly-5b1f51ca-3cda-4e9b-8dbd-099d8667bbde"/>
							<gml:surfaceMember xlink:href="#poly-e97b7d06-6873-4272-b5ad-05a0c4561486"/>
							<gml:surfaceMember xlink:href="#poly-cc37d4cc-16bf-4688-bae3-644b76fa47bf"/>
							<gml:surfaceMember xlink:href="#poly-825cf27a-c8c2-47bb-bcb2-da359c89d7a5"/>
							<gml:surfaceMember xlink:href="#poly-5c591f3d-8cc0-47d4-9b61-56710a5289a9"/>
							<gml:surfaceMember xlink:href="#poly-c5bb4f8b-0a9a-4ed7-9213-97f82e485ff9"/>
							<gml:surfaceMember xlink:href="#poly-de828c09-3dc6-4ea8-b833-01a7a6015cf0"/>
							<gml:surfaceMember xlink:href="#poly-acf77a22-d991-4f7b-9410-7a0b8d01f16f"/>
							<gml:surfaceMember xlink:href="#poly-9a61fa4e-37cf-4226-82d5-a02f0c5c40d5"/>
							<gml:surfaceMember xlink:href="#poly-19af6a11-d10f-4657-a833-f6c7161099b1"/>
							<gml:surfaceMember xlink:href="#poly-fb02ef4c-4038-48da-9ee5-1976d12e2719"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c7a51967-8625-43b3-bc93-5463394e7003">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7a51967-8625-43b3-bc93-5463394e7003">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7a51967-8625-43b3-bc93-5463394e7003">
											<gml:posList>35.66868515278565 139.73979987854347 11.329 35.668651501159715 139.7398535904154 11.329 35.668599000621825 139.73980129351597 11.329 35.668634023160855 139.73974867361315 11.329 35.66868515278565 139.73979987854347 11.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a072369-6515-4ae1-8acf-59fb1f8e288f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a072369-6515-4ae1-8acf-59fb1f8e288f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a072369-6515-4ae1-8acf-59fb1f8e288f">
											<gml:posList>35.668599000621825 139.73980129351597 19.87 35.66861551754417 139.73981774385948 25.546 35.66862652844414 139.73980113989896 25.546 35.668634023160855 139.73974867361315 19.87 35.668599000621825 139.73980129351597 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48dcd173-0279-4010-80ee-f2e27ab751d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48dcd173-0279-4010-80ee-f2e27ab751d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48dcd173-0279-4010-80ee-f2e27ab751d7">
											<gml:posList>35.66861551754417 139.73981774385948 25.546 35.668617022690434 139.73981755432177 25.546 35.6686266831103 139.73980298440352 25.546 35.66862652844414 139.73980113989896 25.546 35.66861551754417 139.73981774385948 25.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c50ba1e6-c02a-4550-a4ff-179805abf4da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c50ba1e6-c02a-4550-a4ff-179805abf4da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c50ba1e6-c02a-4550-a4ff-179805abf4da">
											<gml:posList>35.668651501159715 139.7398535904154 25.546 35.66865133747202 139.73985173487466 25.546 35.668617022690434 139.73981755432177 25.546 35.66861551754417 139.73981774385948 25.546 35.668651501159715 139.7398535904154 25.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2be7567b-4375-44f0-a5da-d381aa20a6b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2be7567b-4375-44f0-a5da-d381aa20a6b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2be7567b-4375-44f0-a5da-d381aa20a6b9">
											<gml:posList>35.66866100690969 139.73983716494376 25.311 35.6686266831103 139.73980298440352 25.311 35.668617022690434 139.73981755432177 25.311 35.66865133747202 139.73985173487466 25.311 35.66866100690969 139.73983716494376 25.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a31ce58-5c04-4ccf-a98d-fde785919df6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a31ce58-5c04-4ccf-a98d-fde785919df6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a31ce58-5c04-4ccf-a98d-fde785919df6">
											<gml:posList>35.66862652844414 139.73980113989896 25.546 35.6686266831103 139.73980298440352 25.546 35.66866100690969 139.73983716494376 25.546 35.66866252107828 139.73983698644184 25.546 35.66862652844414 139.73980113989896 25.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c88aab1-dbcc-4be5-aa2d-67de9e18a33f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c88aab1-dbcc-4be5-aa2d-67de9e18a33f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c88aab1-dbcc-4be5-aa2d-67de9e18a33f">
											<gml:posList>35.66862652844414 139.73980113989896 25.546 35.66866252107828 139.73983698644184 25.546 35.66868515278565 139.73979987854347 19.87 35.668634023160855 139.73974867361315 19.87 35.66862652844414 139.73980113989896 25.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b1f51ca-3cda-4e9b-8dbd-099d8667bbde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b1f51ca-3cda-4e9b-8dbd-099d8667bbde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b1f51ca-3cda-4e9b-8dbd-099d8667bbde">
											<gml:posList>35.66866252107828 139.73983698644184 25.546 35.66866100690969 139.73983716494376 25.546 35.66865133747202 139.73985173487466 25.546 35.668651501159715 139.7398535904154 25.546 35.66866252107828 139.73983698644184 25.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e97b7d06-6873-4272-b5ad-05a0c4561486">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e97b7d06-6873-4272-b5ad-05a0c4561486">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e97b7d06-6873-4272-b5ad-05a0c4561486">
											<gml:posList>35.6686266831103 139.73980298440352 25.546 35.6686266831103 139.73980298440352 25.311 35.66866100690969 139.73983716494376 25.311 35.66866100690969 139.73983716494376 25.546 35.6686266831103 139.73980298440352 25.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc37d4cc-16bf-4688-bae3-644b76fa47bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc37d4cc-16bf-4688-bae3-644b76fa47bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc37d4cc-16bf-4688-bae3-644b76fa47bf">
											<gml:posList>35.66868515278565 139.73979987854347 11.329 35.668634023160855 139.73974867361315 11.329 35.668634023160855 139.73974867361315 19.87 35.66868515278565 139.73979987854347 19.87 35.66868515278565 139.73979987854347 11.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-825cf27a-c8c2-47bb-bcb2-da359c89d7a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-825cf27a-c8c2-47bb-bcb2-da359c89d7a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-825cf27a-c8c2-47bb-bcb2-da359c89d7a5">
											<gml:posList>35.668634023160855 139.73974867361315 11.329 35.668599000621825 139.73980129351597 11.329 35.668599000621825 139.73980129351597 19.87 35.668634023160855 139.73974867361315 19.87 35.668634023160855 139.73974867361315 11.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c591f3d-8cc0-47d4-9b61-56710a5289a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c591f3d-8cc0-47d4-9b61-56710a5289a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c591f3d-8cc0-47d4-9b61-56710a5289a9">
											<gml:posList>35.668617022690434 139.73981755432177 25.546 35.668617022690434 139.73981755432177 25.311 35.6686266831103 139.73980298440352 25.311 35.6686266831103 139.73980298440352 25.546 35.668617022690434 139.73981755432177 25.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5bb4f8b-0a9a-4ed7-9213-97f82e485ff9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5bb4f8b-0a9a-4ed7-9213-97f82e485ff9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5bb4f8b-0a9a-4ed7-9213-97f82e485ff9">
											<gml:posList>35.668651501159715 139.7398535904154 11.329 35.66868515278565 139.73979987854347 11.329 35.66868515278565 139.73979987854347 19.87 35.668651501159715 139.7398535904154 11.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de828c09-3dc6-4ea8-b833-01a7a6015cf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de828c09-3dc6-4ea8-b833-01a7a6015cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de828c09-3dc6-4ea8-b833-01a7a6015cf0">
											<gml:posList>35.668651501159715 139.7398535904154 11.329 35.66868515278565 139.73979987854347 19.87 35.66866252107828 139.73983698644184 25.546 35.668651501159715 139.7398535904154 11.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-acf77a22-d991-4f7b-9410-7a0b8d01f16f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acf77a22-d991-4f7b-9410-7a0b8d01f16f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acf77a22-d991-4f7b-9410-7a0b8d01f16f">
											<gml:posList>35.668651501159715 139.7398535904154 25.546 35.66861551754417 139.73981774385948 25.546 35.668599000621825 139.73980129351597 19.87 35.668599000621825 139.73980129351597 11.329 35.668651501159715 139.7398535904154 11.329 35.668651501159715 139.7398535904154 25.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a61fa4e-37cf-4226-82d5-a02f0c5c40d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a61fa4e-37cf-4226-82d5-a02f0c5c40d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a61fa4e-37cf-4226-82d5-a02f0c5c40d5">
											<gml:posList>35.66865133747202 139.73985173487466 25.546 35.66865133747202 139.73985173487466 25.311 35.668617022690434 139.73981755432177 25.311 35.668617022690434 139.73981755432177 25.546 35.66865133747202 139.73985173487466 25.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19af6a11-d10f-4657-a833-f6c7161099b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19af6a11-d10f-4657-a833-f6c7161099b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19af6a11-d10f-4657-a833-f6c7161099b1">
											<gml:posList>35.66866100690969 139.73983716494376 25.546 35.66866100690969 139.73983716494376 25.311 35.66865133747202 139.73985173487466 25.311 35.66865133747202 139.73985173487466 25.546 35.66866100690969 139.73983716494376 25.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb02ef4c-4038-48da-9ee5-1976d12e2719">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb02ef4c-4038-48da-9ee5-1976d12e2719">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb02ef4c-4038-48da-9ee5-1976d12e2719">
											<gml:posList>35.668651501159715 139.7398535904154 11.329 35.66866252107828 139.73983698644184 25.546 35.668651501159715 139.7398535904154 25.546 35.668651501159715 139.7398535904154 11.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7822</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">46.03715</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>