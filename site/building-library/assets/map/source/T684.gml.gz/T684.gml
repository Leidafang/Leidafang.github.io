<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c72b2bce-3fbc-4fe8-8559-df90bf095919">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="説明注記">
				<gen:value>トイレ</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">3.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6747247690697 139.74788134196507 0 35.674681870974986 139.74785343915474 0 35.674670388281726 139.747879952795 0 35.67466423808003 139.7478759493442 0 35.67463551334696 139.7479423052317 0 35.67468822287332 139.74797658270737 0 35.67471694762499 139.74791022678846 0 35.674713295384166 139.74790785560597 0 35.6747247690697 139.74788134196507 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6747247690697 139.74788134196507 19.42 35.674713295384166 139.74790785560597 19.42 35.67471694762499 139.74791022678846 19.42 35.67468822287332 139.74797658270737 19.42 35.67463551334696 139.7479423052317 19.42 35.67466423808003 139.7478759493442 19.42 35.674670388281726 139.747879952795 19.42 35.674681870974986 139.74785343915474 19.42 35.6747247690697 139.74788134196507 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6747247690697 139.74788134196507 19.42 35.674681870974986 139.74785343915474 19.42 35.674681870974986 139.74785343915474 22.65 35.6747247690697 139.74788134196507 22.65 35.6747247690697 139.74788134196507 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674681870974986 139.74785343915474 19.42 35.674670388281726 139.747879952795 19.42 35.674670388281726 139.747879952795 22.65 35.674681870974986 139.74785343915474 22.65 35.674681870974986 139.74785343915474 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674670388281726 139.747879952795 19.42 35.67466423808003 139.7478759493442 19.42 35.67466423808003 139.7478759493442 22.65 35.674670388281726 139.747879952795 22.65 35.674670388281726 139.747879952795 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67466423808003 139.7478759493442 19.42 35.67463551334696 139.7479423052317 19.42 35.67463551334696 139.7479423052317 22.65 35.67466423808003 139.7478759493442 22.65 35.67466423808003 139.7478759493442 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67463551334696 139.7479423052317 19.42 35.67468822287332 139.74797658270737 19.42 35.67468822287332 139.74797658270737 22.65 35.67463551334696 139.7479423052317 22.65 35.67463551334696 139.7479423052317 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67468822287332 139.74797658270737 19.42 35.67471694762499 139.74791022678846 19.42 35.67471694762499 139.74791022678846 22.65 35.67468822287332 139.74797658270737 22.65 35.67468822287332 139.74797658270737 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67471694762499 139.74791022678846 19.42 35.674713295384166 139.74790785560597 19.42 35.674713295384166 139.74790785560597 22.65 35.67471694762499 139.74791022678846 22.65 35.67471694762499 139.74791022678846 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674713295384166 139.74790785560597 19.42 35.6747247690697 139.74788134196507 19.42 35.6747247690697 139.74788134196507 22.65 35.674713295384166 139.74790785560597 22.65 35.674713295384166 139.74790785560597 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6747247690697 139.74788134196507 22.65 35.674681870974986 139.74785343915474 22.65 35.674670388281726 139.747879952795 22.65 35.67466423808003 139.7478759493442 22.65 35.67463551334696 139.7479423052317 22.65 35.67468822287332 139.74797658270737 22.65 35.67471694762499 139.74791022678846 22.65 35.674713295384166 139.74790785560597 22.65 35.6747247690697 139.74788134196507 22.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2e4ed231-6774-4b0e-9ec9-5e80f057ca0d"/>
							<gml:surfaceMember xlink:href="#poly-c4129bae-2ce6-443a-aa75-1c15efeca526"/>
							<gml:surfaceMember xlink:href="#poly-60d878ee-6163-416b-9e0f-62b1e3348a36"/>
							<gml:surfaceMember xlink:href="#poly-5b2df466-ace3-4a1f-9b87-86a1a4a5639e"/>
							<gml:surfaceMember xlink:href="#poly-76d88344-ca30-494b-8ca2-b661e1acd894"/>
							<gml:surfaceMember xlink:href="#poly-220b3952-9893-4c67-8d3b-b08515b1c436"/>
							<gml:surfaceMember xlink:href="#poly-b3c05156-c8e1-4f9e-ba08-d12a6a250b2c"/>
							<gml:surfaceMember xlink:href="#poly-3c1f4284-14a6-459f-bf58-b1b24563dee3"/>
							<gml:surfaceMember xlink:href="#poly-b68e9654-1926-4221-8673-f0af1a5ef295"/>
							<gml:surfaceMember xlink:href="#poly-aa1cca28-571a-425d-92c8-9bdc9484588d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2e4ed231-6774-4b0e-9ec9-5e80f057ca0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e4ed231-6774-4b0e-9ec9-5e80f057ca0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e4ed231-6774-4b0e-9ec9-5e80f057ca0d">
											<gml:posList>35.67468187097495 139.74785343915474 19.42 35.674724778083416 139.74788134195546 19.42 35.67471329538415 139.74790785560594 19.42 35.67471694762498 139.74791022678846 19.42 35.674688222873314 139.7479765827074 19.42 35.67463551334694 139.7479423052317 19.42 35.67466423808001 139.7478759493442 19.42 35.674670388281726 139.747879952795 19.42 35.67468187097495 139.74785343915474 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c4129bae-2ce6-443a-aa75-1c15efeca526">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4129bae-2ce6-443a-aa75-1c15efeca526">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4129bae-2ce6-443a-aa75-1c15efeca526">
											<gml:posList>35.67471329538415 139.74790785560594 22.089 35.674724778083416 139.74788134195546 22.089 35.67468187097495 139.74785343915474 22.339 35.674670388281726 139.747879952795 22.339 35.67471329538415 139.74790785560594 22.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60d878ee-6163-416b-9e0f-62b1e3348a36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60d878ee-6163-416b-9e0f-62b1e3348a36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60d878ee-6163-416b-9e0f-62b1e3348a36">
											<gml:posList>35.67471694762498 139.74791022678846 22.809 35.67466423808001 139.7478759493442 22.809 35.67463551334694 139.7479423052317 22.809 35.674688222873314 139.7479765827074 22.809 35.67471694762498 139.74791022678846 22.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b2df466-ace3-4a1f-9b87-86a1a4a5639e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b2df466-ace3-4a1f-9b87-86a1a4a5639e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b2df466-ace3-4a1f-9b87-86a1a4a5639e">
											<gml:posList>35.67468187097495 139.74785343915474 19.42 35.674670388281726 139.747879952795 19.42 35.674670388281726 139.747879952795 22.339 35.67468187097495 139.74785343915474 22.339 35.67468187097495 139.74785343915474 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76d88344-ca30-494b-8ca2-b661e1acd894">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76d88344-ca30-494b-8ca2-b661e1acd894">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76d88344-ca30-494b-8ca2-b661e1acd894">
											<gml:posList>35.674724778083416 139.74788134195546 22.089 35.674724778083416 139.74788134195546 19.42 35.67468187097495 139.74785343915474 19.42 35.67468187097495 139.74785343915474 22.339 35.674724778083416 139.74788134195546 22.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-220b3952-9893-4c67-8d3b-b08515b1c436">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-220b3952-9893-4c67-8d3b-b08515b1c436">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-220b3952-9893-4c67-8d3b-b08515b1c436">
											<gml:posList>35.674670388281726 139.747879952795 19.42 35.67466423808001 139.7478759493442 19.42 35.67466423808001 139.7478759493442 22.809 35.67471694762498 139.74791022678846 22.809 35.67471694762498 139.74791022678846 19.42 35.67471329538415 139.74790785560594 19.42 35.67471329538415 139.74790785560594 22.089 35.674670388281726 139.747879952795 22.339 35.674670388281726 139.747879952795 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3c05156-c8e1-4f9e-ba08-d12a6a250b2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3c05156-c8e1-4f9e-ba08-d12a6a250b2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3c05156-c8e1-4f9e-ba08-d12a6a250b2c">
											<gml:posList>35.67471329538415 139.74790785560594 22.089 35.67471329538415 139.74790785560594 19.42 35.674724778083416 139.74788134195546 19.42 35.674724778083416 139.74788134195546 22.089 35.67471329538415 139.74790785560594 22.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c1f4284-14a6-459f-bf58-b1b24563dee3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c1f4284-14a6-459f-bf58-b1b24563dee3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c1f4284-14a6-459f-bf58-b1b24563dee3">
											<gml:posList>35.67466423808001 139.7478759493442 19.42 35.67463551334694 139.7479423052317 19.42 35.67463551334694 139.7479423052317 22.809 35.67466423808001 139.7478759493442 22.809 35.67466423808001 139.7478759493442 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b68e9654-1926-4221-8673-f0af1a5ef295">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b68e9654-1926-4221-8673-f0af1a5ef295">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b68e9654-1926-4221-8673-f0af1a5ef295">
											<gml:posList>35.674688222873314 139.7479765827074 19.42 35.67471694762498 139.74791022678846 19.42 35.67471694762498 139.74791022678846 22.809 35.674688222873314 139.7479765827074 22.809 35.674688222873314 139.7479765827074 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa1cca28-571a-425d-92c8-9bdc9484588d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa1cca28-571a-425d-92c8-9bdc9484588d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa1cca28-571a-425d-92c8-9bdc9484588d">
											<gml:posList>35.67463551334694 139.7479423052317 19.42 35.674688222873314 139.7479765827074 19.42 35.674688222873314 139.7479765827074 22.809 35.67463551334694 139.7479423052317 22.809 35.67463551334694 139.7479423052317 19.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4608</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">46.2984</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">217</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>