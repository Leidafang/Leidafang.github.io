<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c8091f6d-c71d-4c4c-b7b1-5a218c0d5d87">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">20.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668636123834176 139.7381850188013 0 35.66865376519161 139.73815267720877 0 35.668670694281055 139.73816572455914 0 35.66871576660371 139.73820457518073 0 35.668731761989854 139.73817670915676 0 35.66859935020037 139.73806265051286 0 35.66855128321277 139.7381465468194 0 35.66858790390403 139.73817809494133 0 35.66860113574673 139.7381548826091 0 35.668636123834176 139.7381850188013 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668636123834176 139.7381850188013 20.63 35.66860113574673 139.7381548826091 20.63 35.66858790390403 139.73817809494133 20.63 35.66855128321277 139.7381465468194 20.63 35.66859935020037 139.73806265051286 20.63 35.668731761989854 139.73817670915676 20.63 35.66871576660371 139.73820457518073 20.63 35.668670694281055 139.73816572455914 20.63 35.66865376519161 139.73815267720877 20.63 35.668636123834176 139.7381850188013 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668636123834176 139.7381850188013 20.63 35.66865376519161 139.73815267720877 20.63 35.66865376519161 139.73815267720877 41.3 35.668636123834176 139.7381850188013 41.3 35.668636123834176 139.7381850188013 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865376519161 139.73815267720877 20.63 35.668670694281055 139.73816572455914 20.63 35.668670694281055 139.73816572455914 41.3 35.66865376519161 139.73815267720877 41.3 35.66865376519161 139.73815267720877 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668670694281055 139.73816572455914 20.63 35.66871576660371 139.73820457518073 20.63 35.66871576660371 139.73820457518073 41.3 35.668670694281055 139.73816572455914 41.3 35.668670694281055 139.73816572455914 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66871576660371 139.73820457518073 20.63 35.668731761989854 139.73817670915676 20.63 35.668731761989854 139.73817670915676 41.3 35.66871576660371 139.73820457518073 41.3 35.66871576660371 139.73820457518073 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668731761989854 139.73817670915676 20.63 35.66859935020037 139.73806265051286 20.63 35.66859935020037 139.73806265051286 41.3 35.668731761989854 139.73817670915676 41.3 35.668731761989854 139.73817670915676 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66859935020037 139.73806265051286 20.63 35.66855128321277 139.7381465468194 20.63 35.66855128321277 139.7381465468194 41.3 35.66859935020037 139.73806265051286 41.3 35.66859935020037 139.73806265051286 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855128321277 139.7381465468194 20.63 35.66858790390403 139.73817809494133 20.63 35.66858790390403 139.73817809494133 41.3 35.66855128321277 139.7381465468194 41.3 35.66855128321277 139.7381465468194 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858790390403 139.73817809494133 20.63 35.66860113574673 139.7381548826091 20.63 35.66860113574673 139.7381548826091 41.3 35.66858790390403 139.73817809494133 41.3 35.66858790390403 139.73817809494133 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860113574673 139.7381548826091 20.63 35.668636123834176 139.7381850188013 20.63 35.668636123834176 139.7381850188013 41.3 35.66860113574673 139.7381548826091 41.3 35.66860113574673 139.7381548826091 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668636123834176 139.7381850188013 41.3 35.66865376519161 139.73815267720877 41.3 35.668670694281055 139.73816572455914 41.3 35.66871576660371 139.73820457518073 41.3 35.668731761989854 139.73817670915676 41.3 35.66859935020037 139.73806265051286 41.3 35.66855128321277 139.7381465468194 41.3 35.66858790390403 139.73817809494133 41.3 35.66860113574673 139.7381548826091 41.3 35.668636123834176 139.7381850188013 41.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f4c355c7-1fcd-4057-9e32-c87e73cc2639"/>
							<gml:surfaceMember xlink:href="#poly-7dac933f-50b3-4605-80d8-9db2ebc90812"/>
							<gml:surfaceMember xlink:href="#poly-9a3773d7-3f30-4d7a-a907-227387990d7d"/>
							<gml:surfaceMember xlink:href="#poly-25eb266c-f00b-4c81-9f6d-ed128661589a"/>
							<gml:surfaceMember xlink:href="#poly-25256ea4-400b-4182-a252-49960e6e7b00"/>
							<gml:surfaceMember xlink:href="#poly-d05a16b2-fdc1-404a-82d9-fa81603c9cf2"/>
							<gml:surfaceMember xlink:href="#poly-18fedb39-9c73-4388-b738-f94ea57c2d40"/>
							<gml:surfaceMember xlink:href="#poly-5928a61a-f5e6-4eda-b53b-cc052414fad5"/>
							<gml:surfaceMember xlink:href="#poly-47feea03-0185-4ac6-8748-9fa146afc732"/>
							<gml:surfaceMember xlink:href="#poly-bbd9460b-80c7-4c59-ab20-d2a73c0f392a"/>
							<gml:surfaceMember xlink:href="#poly-f893b618-56a0-4e79-a4cb-2a1c99b0e6d0"/>
							<gml:surfaceMember xlink:href="#poly-6cc1572e-76a6-4600-8731-5a417986e7ae"/>
							<gml:surfaceMember xlink:href="#poly-59c1952b-e17c-49da-84cd-30888ad95a82"/>
							<gml:surfaceMember xlink:href="#poly-d533e0b1-fecb-4bc9-81fd-004027d10c6d"/>
							<gml:surfaceMember xlink:href="#poly-acc1a80f-50af-4330-80e9-f6e816076558"/>
							<gml:surfaceMember xlink:href="#poly-a5022035-3105-4ffa-9531-9031c5390560"/>
							<gml:surfaceMember xlink:href="#poly-46ec3862-2f6f-4e8d-8bea-9b526559114f"/>
							<gml:surfaceMember xlink:href="#poly-b0971cfc-8377-4f37-8302-ce296e3b7f24"/>
							<gml:surfaceMember xlink:href="#poly-a28bace5-4188-46e6-923f-f64cfc6d2870"/>
							<gml:surfaceMember xlink:href="#poly-430dd3f1-631f-4313-8156-8214f688d471"/>
							<gml:surfaceMember xlink:href="#poly-bb053a79-a3e4-4f19-8738-d8b443ddc8ba"/>
							<gml:surfaceMember xlink:href="#poly-17614915-bf07-4c7d-a5d2-ea4cf23dc2f5"/>
							<gml:surfaceMember xlink:href="#poly-7beda4f9-35df-42bb-953f-f56fd334355d"/>
							<gml:surfaceMember xlink:href="#poly-917fbbfa-b600-4f11-aee5-9d15852a8e9e"/>
							<gml:surfaceMember xlink:href="#poly-114db649-623e-4021-81b9-d8e5cab47277"/>
							<gml:surfaceMember xlink:href="#poly-23fb8262-4dcf-43fd-973f-d6d9ad18cd87"/>
							<gml:surfaceMember xlink:href="#poly-d379d5e8-05e3-4a2b-b92b-259ab9ba6665"/>
							<gml:surfaceMember xlink:href="#poly-e9ae2607-7bf6-4bab-9703-1be93a4cd09a"/>
							<gml:surfaceMember xlink:href="#poly-65867029-2684-4c91-bb80-94982fcfcef4"/>
							<gml:surfaceMember xlink:href="#poly-7e27974a-0700-4eb2-aebd-1e3b19c93f0d"/>
							<gml:surfaceMember xlink:href="#poly-ee148d83-9c48-4bce-be35-1b384153ebf3"/>
							<gml:surfaceMember xlink:href="#poly-41540aa6-271b-41fd-8c38-d519e0ca79d8"/>
							<gml:surfaceMember xlink:href="#poly-26187d77-ef96-4188-8058-c3432269782e"/>
							<gml:surfaceMember xlink:href="#poly-01099634-2096-429c-ad91-ee937c8f6435"/>
							<gml:surfaceMember xlink:href="#poly-6d4ba46f-0b3d-4ac1-a7d5-7ec2be84c61c"/>
							<gml:surfaceMember xlink:href="#poly-a747ac71-bfa9-4ae4-ba66-ca1d2322b882"/>
							<gml:surfaceMember xlink:href="#poly-4c4c7b4d-301d-49c3-a1bb-f1f59ee5487c"/>
							<gml:surfaceMember xlink:href="#poly-54a681ef-0eea-4401-a312-b4faf73d796a"/>
							<gml:surfaceMember xlink:href="#poly-e056b801-5596-4864-9224-7181470a5e2d"/>
							<gml:surfaceMember xlink:href="#poly-a3c03a15-29dc-4451-bda1-68118a9a3a20"/>
							<gml:surfaceMember xlink:href="#poly-fb1e93b1-c050-49b0-9f3f-a08e70780fe1"/>
							<gml:surfaceMember xlink:href="#poly-5d612928-ded5-448b-a985-2216b8a636be"/>
							<gml:surfaceMember xlink:href="#poly-033c2389-20a0-4350-a7f3-4951b98bee4b"/>
							<gml:surfaceMember xlink:href="#poly-a5b8bef1-12ec-4d69-a2af-536404ed7004"/>
							<gml:surfaceMember xlink:href="#poly-7f69f6bc-04ed-4a88-b07a-f8304e17fff8"/>
							<gml:surfaceMember xlink:href="#poly-c2ef2477-da74-4325-a966-10672ff28910"/>
							<gml:surfaceMember xlink:href="#poly-83034db7-c8bb-4654-9a53-0bf53d088479"/>
							<gml:surfaceMember xlink:href="#poly-7e270e69-8b12-4fbf-b79e-119c437c5007"/>
							<gml:surfaceMember xlink:href="#poly-129557f7-b025-4cdf-a4de-8b6090e8c3c7"/>
							<gml:surfaceMember xlink:href="#poly-d0bff647-f0d4-4cce-abda-b2dfae710a1c"/>
							<gml:surfaceMember xlink:href="#poly-15723afb-affb-4659-9319-6d9e9f4443cb"/>
							<gml:surfaceMember xlink:href="#poly-25701699-7ea6-4da4-817f-8763e8f29cff"/>
							<gml:surfaceMember xlink:href="#poly-9f31c38b-c18c-474e-867d-bfec87ce3c31"/>
							<gml:surfaceMember xlink:href="#poly-ddfb6466-de49-478f-8cb0-3226fc46af26"/>
							<gml:surfaceMember xlink:href="#poly-9d3294f1-98ae-4350-88e8-0b0d891eda09"/>
							<gml:surfaceMember xlink:href="#poly-b4d139ab-8a47-453b-84fb-aedb046bb85e"/>
							<gml:surfaceMember xlink:href="#poly-704591fe-e9c6-491b-b2a7-cd89e39c8d9b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c8091f6d-c71d-4c4c-b7b1-5a218c0d5d87_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b28ab8a-634a-499d-b8e6-1f9a34f5c18a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b28ab8a-634a-499d-b8e6-1f9a34f5c18a_0">
											<gml:posList>35.66862317448336 139.73810947941027 41.105 35.66862712605761 139.7381025820024 43.09 35.66862712605761 139.7381025820024 41.105 35.66862317448336 139.73810947941027 41.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-710e538c-f250-470b-a583-450b5a5cc93c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-710e538c-f250-470b-a583-450b5a5cc93c_0">
											<gml:posList>35.66862317448336 139.73810947941027 41.105 35.66862317448336 139.73810947941027 43.09 35.66862712605761 139.7381025820024 43.09 35.66862317448336 139.73810947941027 41.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ac133bd-e5f1-4bbd-be0e-fe9088997d93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ac133bd-e5f1-4bbd-be0e-fe9088997d93_0">
											<gml:posList>35.66862317448336 139.73810947941027 41.105 35.66864784385112 139.73813073579487 43.09 35.66862317448336 139.73810947941027 43.09 35.66862317448336 139.73810947941027 41.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-720610ca-1a5f-4f45-b35d-c89c1f6e1983">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-720610ca-1a5f-4f45-b35d-c89c1f6e1983_0">
											<gml:posList>35.66862317448336 139.73810947941027 41.105 35.66864784385112 139.73813073579487 41.105 35.66864784385112 139.73813073579487 43.09 35.66862317448336 139.73810947941027 41.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8de87f11-7929-446f-a8ac-04a0a50b117f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8de87f11-7929-446f-a8ac-04a0a50b117f_0">
											<gml:posList>35.66865179542656 139.73812383838592 43.09 35.66862712605761 139.7381025820024 43.09 35.66862317448336 139.73810947941027 43.09 35.66865179542656 139.73812383838592 43.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c47c0a93-03e9-411d-8aa0-a368b573e12c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c47c0a93-03e9-411d-8aa0-a368b573e12c_0">
											<gml:posList>35.66864784385112 139.73813073579487 43.09 35.66865179542656 139.73812383838592 43.09 35.66862317448336 139.73810947941027 43.09 35.66864784385112 139.73813073579487 43.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-455b8701-169b-43e6-9147-8cfa6369e873">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-455b8701-169b-43e6-9147-8cfa6369e873_0">
											<gml:posList>35.66865179542656 139.73812383838592 41.105 35.66862712605761 139.7381025820024 43.09 35.66865179542656 139.73812383838592 43.09 35.66865179542656 139.73812383838592 41.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8d7a851-4874-4753-9c53-27de5b86c10f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8d7a851-4874-4753-9c53-27de5b86c10f_0">
											<gml:posList>35.66865179542656 139.73812383838592 41.105 35.66862712605761 139.7381025820024 41.105 35.66862712605761 139.7381025820024 43.09 35.66865179542656 139.73812383838592 41.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39cd00b0-c336-4b11-8c98-abaee399c951">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39cd00b0-c336-4b11-8c98-abaee399c951_0">
											<gml:posList>35.668636123834155 139.73818501880132 20.69 35.66865376519157 139.73815267720877 42.059 35.66865376519157 139.73815267720877 20.69 35.668636123834155 139.73818501880132 20.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dccd4463-0dfb-4898-9d28-874860b1fd26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dccd4463-0dfb-4898-9d28-874860b1fd26_0">
											<gml:posList>35.668636123834155 139.73818501880132 20.69 35.668636123834155 139.73818501880132 42.059 35.66865376519157 139.73815267720877 42.059 35.668636123834155 139.73818501880132 20.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec165e0c-1fc1-45af-9229-b90a211cfdda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec165e0c-1fc1-45af-9229-b90a211cfdda_0">
											<gml:posList>35.66864784385112 139.73813073579487 41.105 35.66865179542656 139.73812383838592 43.09 35.66864784385112 139.73813073579487 43.09 35.66864784385112 139.73813073579487 41.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9540c4c-e5df-40a9-82b1-f6c7f66edf3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9540c4c-e5df-40a9-82b1-f6c7f66edf3e_0">
											<gml:posList>35.66864784385112 139.73813073579487 41.105 35.66865179542656 139.73812383838592 41.105 35.66865179542656 139.73812383838592 43.09 35.66864784385112 139.73813073579487 41.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6dc3330-5c5a-4708-bc6c-4e82ea28f856">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6dc3330-5c5a-4708-bc6c-4e82ea28f856_0">
											<gml:posList>35.668636123834155 139.73818501880132 20.69 35.668696926782275 139.73823739318743 32.194 35.668636123834155 139.73818501880132 42.059 35.668636123834155 139.73818501880132 20.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24784be7-44f1-422f-a5cc-f45ff0365eb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24784be7-44f1-422f-a5cc-f45ff0365eb5_0">
											<gml:posList>35.668636123834155 139.73818501880132 20.69 35.668696926782275 139.73823739318743 20.69 35.668696926782275 139.73823739318743 32.194 35.668636123834155 139.73818501880132 20.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e85f290-69fc-40ba-bf88-19581593f64d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e85f290-69fc-40ba-bf88-19581593f64d_0">
											<gml:posList>35.668715766603704 139.7382045751807 32.194 35.668636123834155 139.73818501880132 42.059 35.668696926782275 139.73823739318743 32.194 35.668715766603704 139.7382045751807 32.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d79263ed-e820-495f-b037-541eadd01a76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d79263ed-e820-495f-b037-541eadd01a76_0">
											<gml:posList>35.668715766603704 139.7382045751807 32.194 35.66865376519157 139.73815267720877 42.059 35.668636123834155 139.73818501880132 42.059 35.668715766603704 139.7382045751807 32.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19d93784-9e50-4905-83d7-a87393530199">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19d93784-9e50-4905-83d7-a87393530199_0">
											<gml:posList>35.66865376519157 139.73815267720877 20.69 35.668715766603704 139.7382045751807 32.194 35.668715766603704 139.7382045751807 20.69 35.66865376519157 139.73815267720877 20.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35a87df0-1da6-491c-b13d-efddb2dfd97e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35a87df0-1da6-491c-b13d-efddb2dfd97e_0">
											<gml:posList>35.66865376519157 139.73815267720877 20.69 35.66865376519157 139.73815267720877 42.059 35.668715766603704 139.7382045751807 32.194 35.66865376519157 139.73815267720877 20.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d2eb37c-6e82-4960-8eb8-856e0a3f4906">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d2eb37c-6e82-4960-8eb8-856e0a3f4906_0">
											<gml:posList>35.668715766603704 139.7382045751807 20.69 35.668696926782275 139.73823739318743 32.194 35.668696926782275 139.73823739318743 20.69 35.668715766603704 139.7382045751807 20.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c2098b1-9fac-481b-89b3-4744cae4c952">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c2098b1-9fac-481b-89b3-4744cae4c952_0">
											<gml:posList>35.668715766603704 139.7382045751807 20.69 35.668715766603704 139.7382045751807 32.194 35.668696926782275 139.73823739318743 32.194 35.668715766603704 139.7382045751807 20.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e32852b2-883c-4265-9ce8-b1eca859a41d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865179542656 139.73812383838592 41.105 35.66864784385112 139.73813073579487 41.105 35.66862317448336 139.73810947941027 41.105 35.66865179542656 139.73812383838592 41.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66c438fe-79ed-455e-82e9-baa75930d314">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862712605761 139.7381025820024 41.105 35.66865179542656 139.73812383838592 41.105 35.66862317448336 139.73810947941027 41.105 35.66862712605761 139.7381025820024 41.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72766fba-6438-437d-9eb5-704ef48777a8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668636123834155 139.73818501880132 20.69 35.668715766603704 139.7382045751807 20.69 35.668696926782275 139.73823739318743 20.69 35.668636123834155 139.73818501880132 20.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cdae0c7-18d8-4e6d-9473-dc806abd16aa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668636123834155 139.73818501880132 20.69 35.66865376519157 139.73815267720877 20.69 35.668715766603704 139.7382045751807 20.69 35.668636123834155 139.73818501880132 20.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c8091f6d-c71d-4c4c-b7b1-5a218c0d5d87_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bc7a448-8e7b-4a71-81d4-3f272ddd9425">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bc7a448-8e7b-4a71-81d4-3f272ddd9425_0">
											<gml:posList>35.668614232606764 139.73812055813747 43.409 35.66862947619441 139.73813368479793 45.204 35.66862947619441 139.73813368479793 43.407 35.668614232606764 139.73812055813747 43.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-431e88ec-173d-427e-9a17-e762519d0c3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-431e88ec-173d-427e-9a17-e762519d0c3d_0">
											<gml:posList>35.668614232606764 139.73812055813747 43.409 35.668614232606764 139.73812055813747 45.204 35.66862947619441 139.73813368479793 45.204 35.668614232606764 139.73812055813747 43.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da0ca14b-bdb3-443d-b0f8-53685dc38b67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da0ca14b-bdb3-443d-b0f8-53685dc38b67_0">
											<gml:posList>35.66860506024968 139.73813654156632 45.204 35.668614232606764 139.73812055813747 43.409 35.66860506024968 139.73813654156632 43.408 35.66860506024968 139.73813654156632 45.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-524e5164-f1a9-437a-8fd7-fc3ca985b916">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-524e5164-f1a9-437a-8fd7-fc3ca985b916_0">
											<gml:posList>35.66860506024968 139.73813654156632 45.204 35.668614232606764 139.73812055813747 45.204 35.668614232606764 139.73812055813747 43.409 35.66860506024968 139.73813654156632 45.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25ff67c9-2310-4dad-a055-59d30ce109ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25ff67c9-2310-4dad-a055-59d30ce109ea_0">
											<gml:posList>35.6686203038356 139.73814966822835 45.204 35.668614232606764 139.73812055813747 45.204 35.66860506024968 139.73813654156632 45.204 35.6686203038356 139.73814966822835 45.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-261db56c-71f3-4765-b995-305bd0ca807d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-261db56c-71f3-4765-b995-305bd0ca807d_0">
											<gml:posList>35.6686203038356 139.73814966822835 45.204 35.66862947619441 139.73813368479793 45.204 35.668614232606764 139.73812055813747 45.204 35.6686203038356 139.73814966822835 45.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0242d9b6-33e5-4d8f-a14b-e812bdb8ec3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0242d9b6-33e5-4d8f-a14b-e812bdb8ec3d_0">
											<gml:posList>35.6686203038356 139.73814966822835 43.407 35.66862159103447 139.73814743540493 44.562 35.6686203038356 139.73814966822835 45.204 35.6686203038356 139.73814966822835 43.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f95a09e-f9a9-4a18-a552-7d427c4155bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f95a09e-f9a9-4a18-a552-7d427c4155bb_0">
											<gml:posList>35.6686203038356 139.73814966822835 45.204 35.66862159103447 139.73814743540493 44.562 35.66862947619441 139.73813368479793 45.204 35.6686203038356 139.73814966822835 45.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e65a5dc-b087-4714-9e76-1b0684816d39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e65a5dc-b087-4714-9e76-1b0684816d39_0">
											<gml:posList>35.6686203038356 139.73814966822835 43.407 35.66862159103447 139.73814743540493 43.407 35.66862159103447 139.73814743540493 44.562 35.6686203038356 139.73814966822835 43.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d3b933d-51f1-459d-89bd-13fa60a91280">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d3b933d-51f1-459d-89bd-13fa60a91280_0">
											<gml:posList>35.66862947619441 139.73813368479793 45.204 35.66862159103447 139.73814743540493 44.562 35.66862947619441 139.73813368479793 43.407 35.66862947619441 139.73813368479793 45.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-464fb8d5-dfc2-4946-b764-5918aea60aae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-464fb8d5-dfc2-4946-b764-5918aea60aae_0">
											<gml:posList>35.66862159103447 139.73814743540493 44.562 35.66862159103447 139.73814743540493 43.407 35.66862947619441 139.73813368479793 43.407 35.66862159103447 139.73814743540493 44.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-235d73a0-49d9-4083-9a8e-009cb49fe0db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-235d73a0-49d9-4083-9a8e-009cb49fe0db_0">
											<gml:posList>35.66861969048322 139.73814913874764 43.407 35.6686203038356 139.73814966822835 43.407 35.668619681469494 139.73814913875836 44.575 35.66861969048322 139.73814913874764 43.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d186a2c7-54da-4ced-a4ee-38cd43bc3cc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d186a2c7-54da-4ced-a4ee-38cd43bc3cc4_0">
											<gml:posList>35.668619672447036 139.73814912772306 43.407 35.668619681469494 139.73814913875836 44.575 35.66860506024968 139.73813654156632 43.408 35.668619672447036 139.73814912772306 43.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d85fb002-2848-43d8-8733-9b64dc16b1af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d85fb002-2848-43d8-8733-9b64dc16b1af_0">
											<gml:posList>35.6686203038356 139.73814966822835 43.407 35.6686203038356 139.73814966822835 45.204 35.668619681469494 139.73814913875836 44.575 35.6686203038356 139.73814966822835 43.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25fb20c8-ff5f-432d-9c1a-60190a0b660f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25fb20c8-ff5f-432d-9c1a-60190a0b660f_0">
											<gml:posList>35.66860506024968 139.73813654156632 43.408 35.668619681469494 139.73814913875836 44.575 35.66860506024968 139.73813654156632 45.204 35.66860506024968 139.73813654156632 43.408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2b81612-7d0c-4b9c-adf5-ff1deeaddf0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2b81612-7d0c-4b9c-adf5-ff1deeaddf0b_0">
											<gml:posList>35.668619681469494 139.73814913875836 44.575 35.6686203038356 139.73814966822835 45.204 35.66860506024968 139.73813654156632 45.204 35.668619681469494 139.73814913875836 44.575</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e61c9027-9355-4f4a-a79f-f0ec37642a08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e61c9027-9355-4f4a-a79f-f0ec37642a08_0">
											<gml:posList>35.66857039420643 139.7381375216343 45.831 35.6685637242224 139.73814914995455 46.477 35.66857039420643 139.7381375216343 46.477 35.66857039420643 139.7381375216343 45.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ed16fbc-df7f-4ace-99d5-6feaf214976f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ed16fbc-df7f-4ace-99d5-6feaf214976f_0">
											<gml:posList>35.66857039420643 139.7381375216343 45.831 35.6685637242224 139.73814914995455 45.831 35.6685637242224 139.73814914995455 46.477 35.66857039420643 139.7381375216343 45.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3547eb5-ee26-4f7e-8f63-37fb98c5c823">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3547eb5-ee26-4f7e-8f63-37fb98c5c823_0">
											<gml:posList>35.66857039420643 139.7381375216343 45.831 35.66858606173426 139.738151023352 46.477 35.66858606173426 139.738151023352 45.831 35.66857039420643 139.7381375216343 45.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2384bba8-e91f-4478-ab41-539b864aa35f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2384bba8-e91f-4478-ab41-539b864aa35f_0">
											<gml:posList>35.66857039420643 139.7381375216343 45.831 35.66857039420643 139.7381375216343 46.477 35.66858606173426 139.738151023352 46.477 35.66857039420643 139.7381375216343 45.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-136861de-746d-49c1-94c0-04e5f263352e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-136861de-746d-49c1-94c0-04e5f263352e_0">
											<gml:posList>35.6685637242224 139.73814914995455 46.477 35.66858606173426 139.738151023352 46.477 35.66857039420643 139.7381375216343 46.477 35.6685637242224 139.73814914995455 46.477</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-221a02ec-afb8-4e7d-a3dc-8e39dc307607">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-221a02ec-afb8-4e7d-a3dc-8e39dc307607_0">
											<gml:posList>35.6685637242224 139.73814914995455 46.477 35.66857939174894 139.7381626516734 46.477 35.66858606173426 139.738151023352 46.477 35.6685637242224 139.73814914995455 46.477</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7a6bb75-b052-4f5c-ac76-7b9f3a65cc04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7a6bb75-b052-4f5c-ac76-7b9f3a65cc04_0">
											<gml:posList>35.66857939174894 139.7381626516734 45.831 35.6685637242224 139.73814914995455 46.477 35.6685637242224 139.73814914995455 45.831 35.66857939174894 139.7381626516734 45.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28f38c23-14aa-4caa-b363-29c8c577cbc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28f38c23-14aa-4caa-b363-29c8c577cbc4_0">
											<gml:posList>35.66857939174894 139.7381626516734 45.831 35.66857939174894 139.7381626516734 46.477 35.6685637242224 139.73814914995455 46.477 35.66857939174894 139.7381626516734 45.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d75e414f-5270-4ecf-add0-f43a7ea0d393">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d75e414f-5270-4ecf-add0-f43a7ea0d393_0">
											<gml:posList>35.66857939174894 139.7381626516734 45.831 35.66858606173426 139.738151023352 46.477 35.66857939174894 139.7381626516734 46.477 35.66857939174894 139.7381626516734 45.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad95e2e3-0e35-408c-83f0-6ded166e57aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad95e2e3-0e35-408c-83f0-6ded166e57aa_0">
											<gml:posList>35.66857939174894 139.7381626516734 45.831 35.66858606173426 139.738151023352 45.831 35.66858606173426 139.738151023352 46.477 35.66857939174894 139.7381626516734 45.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3086db72-e2bf-4343-8c33-c4b72e9fa95a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668619672447036 139.73814912772306 43.407 35.66860506024968 139.73813654156632 43.408 35.668620959654625 139.73814690594563 43.407 35.668619672447036 139.73814912772306 43.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a456d17-1f07-442c-ab6b-f2290d81df1e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860506024968 139.73813654156632 43.408 35.668614232606764 139.73812055813747 43.409 35.668620959654625 139.73814690594563 43.407 35.66860506024968 139.73813654156632 43.408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f60c218-5f4c-475d-8895-5ce30e17e055">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668620959654625 139.73814690594563 43.407 35.66862947619441 139.73813368479793 43.407 35.66862159103447 139.73814743540493 43.407 35.668620959654625 139.73814690594563 43.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-033578c6-5186-492b-a19e-100cacf8a6c1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668620959654625 139.73814690594563 43.407 35.668614232606764 139.73812055813747 43.409 35.66862947619441 139.73813368479793 43.407 35.668620959654625 139.73814690594563 43.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f73a05d8-d421-4f87-ab55-9e95c88d6ce6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686203038356 139.73814966822835 43.407 35.668620959654625 139.73814690594563 43.407 35.66862159103447 139.73814743540493 43.407 35.6686203038356 139.73814966822835 43.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b124767-8543-41bb-a4c7-e39d02dc3ea8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686203038356 139.73814966822835 43.407 35.66861969048322 139.73814913874764 43.407 35.668620959654625 139.73814690594563 43.407 35.6686203038356 139.73814966822835 43.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9d0e050-8308-47df-a9ae-5074a149ce01">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858606173426 139.738151023352 45.831 35.6685637242224 139.73814914995455 45.831 35.66857039420643 139.7381375216343 45.831 35.66858606173426 139.738151023352 45.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7e9542c-6719-46bd-9275-b13c10621d15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858606173426 139.738151023352 45.831 35.66857939174894 139.7381626516734 45.831 35.6685637242224 139.73814914995455 45.831 35.66858606173426 139.738151023352 45.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f4c355c7-1fcd-4057-9e32-c87e73cc2639">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4c355c7-1fcd-4057-9e32-c87e73cc2639">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4c355c7-1fcd-4057-9e32-c87e73cc2639">
											<gml:posList>35.66859935020037 139.73806265051283 20.63 35.66873176198982 139.73817670915676 20.63 35.668715766603704 139.7382045751807 20.63 35.66867069428104 139.73816572455914 20.63 35.66865376519157 139.73815267720877 20.63 35.668636123834155 139.73818501880132 20.63 35.66860113574671 139.7381548826091 20.63 35.66858790390401 139.73817809494133 20.63 35.66855128321275 139.7381465468194 20.63 35.66859935020037 139.73806265051283 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7dac933f-50b3-4605-80d8-9db2ebc90812">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dac933f-50b3-4605-80d8-9db2ebc90812">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dac933f-50b3-4605-80d8-9db2ebc90812">
											<gml:posList>35.668580461166016 139.7381357754587 42.059 35.668565785844905 139.73812315624747 42.059 35.66856456017048 139.73812340071504 42.059 35.66858066965187 139.73813725537667 42.059 35.668581173730566 139.7381363821433 42.059 35.668580461166016 139.7381357754587 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a3773d7-3f30-4d7a-a907-227387990d7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a3773d7-3f30-4d7a-a907-227387990d7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a3773d7-3f30-4d7a-a907-227387990d7d">
											<gml:posList>35.668585477553556 139.7381759990785 45.831 35.66859876352186 139.7381528419124 45.831 35.6685645781892 139.73812338964763 45.831 35.66855128321275 139.7381465468194 45.831 35.668585477553556 139.7381759990785 45.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25eb266c-f00b-4c81-9f6d-ed128661589a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25eb266c-f00b-4c81-9f6d-ed128661589a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25eb266c-f00b-4c81-9f6d-ed128661589a">
											<gml:posList>35.66856456017048 139.73812340071504 42.059 35.668565785844905 139.73812315624747 42.059 35.66859956771831 139.73806415251227 42.059 35.66859935020037 139.73806265051283 42.059 35.66856456017048 139.73812340071504 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25256ea4-400b-4182-a252-49960e6e7b00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25256ea4-400b-4182-a252-49960e6e7b00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25256ea4-400b-4182-a252-49960e6e7b00">
											<gml:posList>35.66859876352186 139.7381528419124 44.078 35.668599438625705 139.73815167023358 44.079 35.668582291851614 139.73813691102438 44.081 35.66858066965187 139.73813725537667 44.078 35.66859876352186 139.7381528419124 44.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d05a16b2-fdc1-404a-82d9-fa81603c9cf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d05a16b2-fdc1-404a-82d9-fa81603c9cf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d05a16b2-fdc1-404a-82d9-fa81603c9cf2">
											<gml:posList>35.66858066965187 139.73813725537667 44.078 35.668582291851614 139.73813691102438 44.081 35.66860485818266 139.73809758251267 44.081 35.668604568179674 139.7380956056205 44.078 35.66858066965187 139.73813725537667 44.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18fedb39-9c73-4388-b738-f94ea57c2d40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18fedb39-9c73-4388-b738-f94ea57c2d40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18fedb39-9c73-4388-b738-f94ea57c2d40">
											<gml:posList>35.668585477553556 139.7381759990785 42.059 35.66858790390401 139.73817809494133 42.059 35.66860113574671 139.7381548826091 42.059 35.66859876352186 139.7381528419124 42.059 35.668585477553556 139.7381759990785 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5928a61a-f5e6-4eda-b53b-cc052414fad5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5928a61a-f5e6-4eda-b53b-cc052414fad5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5928a61a-f5e6-4eda-b53b-cc052414fad5">
											<gml:posList>35.66859876352186 139.7381528419124 44.078 35.66861214901287 139.7381643691096 44.081 35.66861282411685 139.73816319743065 44.08 35.668599438625705 139.73815167023358 44.079 35.66859876352186 139.7381528419124 44.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47feea03-0185-4ac6-8748-9fa146afc732">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47feea03-0185-4ac6-8748-9fa146afc732">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47feea03-0185-4ac6-8748-9fa146afc732">
											<gml:posList>35.668599429603255 139.73815165919828 43.408 35.66861280608939 139.73816319745202 43.41 35.66862096134855 139.73814904887087 43.407 35.668628330582095 139.7381553915832 43.407 35.66862021140328 139.73816957326025 43.408 35.66862546998385 139.73817409588634 43.406 35.66864795515968 139.7381347122301 43.406 35.6686048491602 139.73809757147734 43.41 35.66858228282915 139.7381368999891 43.41 35.668599429603255 139.73815165919828 43.408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbd9460b-80c7-4c59-ab20-d2a73c0f392a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbd9460b-80c7-4c59-ab20-d2a73c0f392a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbd9460b-80c7-4c59-ab20-d2a73c0f392a">
											<gml:posList>35.668628339604545 139.7381554026185 44.668 35.66862097037101 139.7381490599062 44.668 35.66861217607151 139.7381643911695 44.668 35.668619545312986 139.73817074492854 44.668 35.668628339604545 139.7381554026185 44.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f893b618-56a0-4e79-a4cb-2a1c99b0e6d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f893b618-56a0-4e79-a4cb-2a1c99b0e6d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f893b618-56a0-4e79-a4cb-2a1c99b0e6d0">
											<gml:posList>35.6686254790063 139.73817410692163 44.077 35.66862022042574 139.73816958429555 44.078 35.6686195543267 139.73817074491785 44.079 35.66862576000301 139.7381760948713 44.078 35.6686254790063 139.73817410692163 44.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6cc1572e-76a6-4600-8731-5a417986e7ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cc1572e-76a6-4600-8731-5a417986e7ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cc1572e-76a6-4600-8731-5a417986e7ae">
											<gml:posList>35.66865351165477 139.7381512194349 41.105 35.66867045878057 139.73816427780955 41.105 35.6686854549876 139.7381381251136 41.105 35.66859956771831 139.73806415251227 41.105 35.668565785844905 139.73812315624747 41.105 35.668580461166016 139.7381357754587 41.105 35.668581173730566 139.7381363821433 41.105 35.668604568179674 139.7380956056205 41.105 35.66864957736814 139.73813437892346 41.105 35.66862626407327 139.7381752105917 41.105 35.66863589730399 139.73818351681155 41.105 35.66865351165477 139.7381512194349 41.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-59c1952b-e17c-49da-84cd-30888ad95a82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59c1952b-e17c-49da-84cd-30888ad95a82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59c1952b-e17c-49da-84cd-30888ad95a82">
											<gml:posList>35.668604568179674 139.7380956056205 44.078 35.66860485818266 139.73809758251267 44.081 35.668647964182135 139.7381347232654 44.077 35.668604568179674 139.7380956056205 44.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d533e0b1-fecb-4bc9-81fd-004027d10c6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d533e0b1-fecb-4bc9-81fd-004027d10c6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d533e0b1-fecb-4bc9-81fd-004027d10c6d">
											<gml:posList>35.668647964182135 139.7381347232654 44.077 35.66864957736814 139.73813437892346 44.078 35.668604568179674 139.7380956056205 44.078 35.668647964182135 139.7381347232654 44.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-acc1a80f-50af-4330-80e9-f6e816076558">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acc1a80f-50af-4330-80e9-f6e816076558">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acc1a80f-50af-4330-80e9-f6e816076558">
											<gml:posList>35.66863589730399 139.73818351681155 42.059 35.66862626407327 139.7381752105917 42.059 35.66862576000301 139.7381760948713 42.059 35.668636123834155 139.73818501880132 42.059 35.66863589730399 139.73818351681155 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a5022035-3105-4ffa-9531-9031c5390560">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5022035-3105-4ffa-9531-9031c5390560">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5022035-3105-4ffa-9531-9031c5390560">
											<gml:posList>35.66864957736814 139.73813437892346 44.078 35.668647964182135 139.7381347232654 44.077 35.6686254790063 139.73817410692163 44.077 35.66862576000301 139.7381760948713 44.078 35.66864957736814 139.73813437892346 44.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46ec3862-2f6f-4e8d-8bea-9b526559114f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46ec3862-2f6f-4e8d-8bea-9b526559114f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46ec3862-2f6f-4e8d-8bea-9b526559114f">
											<gml:posList>35.66859935020037 139.73806265051283 42.059 35.66859956771831 139.73806415251227 42.059 35.6686854549876 139.7381381251136 42.059 35.66868667163957 139.73813786961057 42.059 35.66859935020037 139.73806265051283 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0971cfc-8377-4f37-8302-ce296e3b7f24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0971cfc-8377-4f37-8302-ce296e3b7f24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0971cfc-8377-4f37-8302-ce296e3b7f24">
											<gml:posList>35.66865376519157 139.73815267720877 42.059 35.66865351165477 139.7381512194349 42.059 35.66863589730399 139.73818351681155 42.059 35.668636123834155 139.73818501880132 42.059 35.66865376519157 139.73815267720877 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a28bace5-4188-46e6-923f-f64cfc6d2870">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a28bace5-4188-46e6-923f-f64cfc6d2870">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a28bace5-4188-46e6-923f-f64cfc6d2870">
											<gml:posList>35.66865376519157 139.73815267720877 42.059 35.66867069428104 139.73816572455914 42.059 35.66867045878057 139.73816427780955 42.059 35.66865351165477 139.7381512194349 42.059 35.66865376519157 139.73815267720877 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-430dd3f1-631f-4313-8156-8214f688d471">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-430dd3f1-631f-4313-8156-8214f688d471">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-430dd3f1-631f-4313-8156-8214f688d471">
											<gml:posList>35.66868667163957 139.73813786961057 42.059 35.6686854549876 139.7381381251136 42.059 35.66867045878057 139.73816427780955 42.059 35.66867069428104 139.73816572455914 42.059 35.66868667163957 139.73813786961057 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb053a79-a3e4-4f19-8738-d8b443ddc8ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb053a79-a3e4-4f19-8738-d8b443ddc8ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb053a79-a3e4-4f19-8738-d8b443ddc8ba">
											<gml:posList>35.66868667163957 139.73813786961057 37.67 35.66867069428104 139.73816572455914 37.67 35.66868575747567 139.7381787078532 37.67 35.6687017438509 139.73815085289124 37.67 35.66868667163957 139.73813786961057 37.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17614915-bf07-4c7d-a5d2-ea4cf23dc2f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17614915-bf07-4c7d-a5d2-ea4cf23dc2f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17614915-bf07-4c7d-a5d2-ea4cf23dc2f5">
											<gml:posList>35.66870082969134 139.7381917021874 34.328 35.66871682507451 139.73816383616608 34.328 35.6687017438509 139.73815085289124 34.328 35.66868575747567 139.7381787078532 34.328 35.66870082969134 139.7381917021874 34.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7beda4f9-35df-42bb-953f-f56fd334355d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7beda4f9-35df-42bb-953f-f56fd334355d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7beda4f9-35df-42bb-953f-f56fd334355d">
											<gml:posList>35.668715766603704 139.7382045751807 32.194 35.66873176198982 139.73817670915676 32.194 35.66871682507451 139.73816383616608 32.194 35.66870082969134 139.7381917021874 32.194 35.668715766603704 139.7382045751807 32.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-917fbbfa-b600-4f11-aee5-9d15852a8e9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-917fbbfa-b600-4f11-aee5-9d15852a8e9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-917fbbfa-b600-4f11-aee5-9d15852a8e9e">
											<gml:posList>35.66867045878057 139.73816427780955 42.059 35.66867045878057 139.73816427780955 41.105 35.66865351165477 139.7381512194349 41.105 35.66865351165477 139.7381512194349 42.059 35.66867045878057 139.73816427780955 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-114db649-623e-4021-81b9-d8e5cab47277">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-114db649-623e-4021-81b9-d8e5cab47277">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-114db649-623e-4021-81b9-d8e5cab47277">
											<gml:posList>35.66863589730399 139.73818351681155 42.059 35.66863589730399 139.73818351681155 41.105 35.66862626407327 139.7381752105917 41.105 35.66862626407327 139.7381752105917 42.059 35.66863589730399 139.73818351681155 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23fb8262-4dcf-43fd-973f-d6d9ad18cd87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23fb8262-4dcf-43fd-973f-d6d9ad18cd87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23fb8262-4dcf-43fd-973f-d6d9ad18cd87">
											<gml:posList>35.668565785844905 139.73812315624747 42.059 35.668565785844905 139.73812315624747 41.105 35.66859956771831 139.73806415251227 41.105 35.66859956771831 139.73806415251227 42.059 35.668565785844905 139.73812315624747 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d379d5e8-05e3-4a2b-b92b-259ab9ba6665">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d379d5e8-05e3-4a2b-b92b-259ab9ba6665">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d379d5e8-05e3-4a2b-b92b-259ab9ba6665">
											<gml:posList>35.66859956771831 139.73806415251227 42.059 35.66859956771831 139.73806415251227 41.105 35.6686854549876 139.7381381251136 41.105 35.6686854549876 139.7381381251136 42.059 35.66859956771831 139.73806415251227 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9ae2607-7bf6-4bab-9703-1be93a4cd09a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9ae2607-7bf6-4bab-9703-1be93a4cd09a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9ae2607-7bf6-4bab-9703-1be93a4cd09a">
											<gml:posList>35.66855128321275 139.7381465468194 20.63 35.66855128321275 139.7381465468194 45.831 35.6685645781892 139.73812338964763 45.831 35.66856456017048 139.73812340071504 42.059 35.66859935020037 139.73806265051283 42.059 35.66859935020037 139.73806265051283 20.63 35.66855128321275 139.7381465468194 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65867029-2684-4c91-bb80-94982fcfcef4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65867029-2684-4c91-bb80-94982fcfcef4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65867029-2684-4c91-bb80-94982fcfcef4">
											<gml:posList>35.668604568179674 139.7380956056205 44.078 35.66864957736814 139.73813437892346 44.078 35.66864957736814 139.73813437892346 41.105 35.668604568179674 139.7380956056205 41.105 35.668604568179674 139.7380956056205 44.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e27974a-0700-4eb2-aebd-1e3b19c93f0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e27974a-0700-4eb2-aebd-1e3b19c93f0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e27974a-0700-4eb2-aebd-1e3b19c93f0d">
											<gml:posList>35.66860485818266 139.73809758251267 44.081 35.6686048491602 139.73809757147734 43.41 35.66864795515968 139.7381347122301 43.406 35.668647964182135 139.7381347232654 44.077 35.66860485818266 139.73809758251267 44.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee148d83-9c48-4bce-be35-1b384153ebf3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee148d83-9c48-4bce-be35-1b384153ebf3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee148d83-9c48-4bce-be35-1b384153ebf3">
											<gml:posList>35.668581173730566 139.7381363821433 42.059 35.66858066965187 139.73813725537667 42.059 35.66858066965187 139.73813725537667 44.078 35.668604568179674 139.7380956056205 44.078 35.668604568179674 139.7380956056205 41.105 35.668581173730566 139.7381363821433 41.105 35.668581173730566 139.7381363821433 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41540aa6-271b-41fd-8c38-d519e0ca79d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41540aa6-271b-41fd-8c38-d519e0ca79d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41540aa6-271b-41fd-8c38-d519e0ca79d8">
											<gml:posList>35.668582291851614 139.73813691102438 44.081 35.66858228282915 139.7381368999891 43.41 35.6686048491602 139.73809757147734 43.41 35.66860485818266 139.73809758251267 44.081 35.668582291851614 139.73813691102438 44.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26187d77-ef96-4188-8058-c3432269782e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26187d77-ef96-4188-8058-c3432269782e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26187d77-ef96-4188-8058-c3432269782e">
											<gml:posList>35.6687017438509 139.73815085289124 34.328 35.66871682507451 139.73816383616608 34.328 35.66871682507451 139.73816383616608 32.194 35.66873176198982 139.73817670915676 32.194 35.66873176198982 139.73817670915676 20.63 35.66859935020037 139.73806265051283 20.63 35.66859935020037 139.73806265051283 42.059 35.66868667163957 139.73813786961057 42.059 35.66868667163957 139.73813786961057 37.67 35.6687017438509 139.73815085289124 37.67 35.6687017438509 139.73815085289124 34.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01099634-2096-429c-ad91-ee937c8f6435">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01099634-2096-429c-ad91-ee937c8f6435">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01099634-2096-429c-ad91-ee937c8f6435">
											<gml:posList>35.668580461166016 139.7381357754587 42.059 35.668580461166016 139.7381357754587 41.105 35.668565785844905 139.73812315624747 41.105 35.668565785844905 139.73812315624747 42.059 35.668580461166016 139.7381357754587 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d4ba46f-0b3d-4ac1-a7d5-7ec2be84c61c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d4ba46f-0b3d-4ac1-a7d5-7ec2be84c61c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d4ba46f-0b3d-4ac1-a7d5-7ec2be84c61c">
											<gml:posList>35.668581173730566 139.7381363821433 42.059 35.668581173730566 139.7381363821433 41.105 35.668580461166016 139.7381357754587 41.105 35.668580461166016 139.7381357754587 42.059 35.668581173730566 139.7381363821433 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a747ac71-bfa9-4ae4-ba66-ca1d2322b882">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a747ac71-bfa9-4ae4-ba66-ca1d2322b882">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a747ac71-bfa9-4ae4-ba66-ca1d2322b882">
											<gml:posList>35.6685645781892 139.73812338964763 45.831 35.66859876352186 139.7381528419124 45.831 35.66859876352186 139.7381528419124 44.078 35.66858066965187 139.73813725537667 44.078 35.66858066965187 139.73813725537667 42.059 35.66856456017048 139.73812340071504 42.059 35.6685645781892 139.73812338964763 45.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c4c7b4d-301d-49c3-a1bb-f1f59ee5487c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c4c7b4d-301d-49c3-a1bb-f1f59ee5487c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c4c7b4d-301d-49c3-a1bb-f1f59ee5487c">
											<gml:posList>35.668599438625705 139.73815167023358 44.079 35.668599429603255 139.73815165919828 43.408 35.66858228282915 139.7381368999891 43.41 35.668582291851614 139.73813691102438 44.081 35.668599438625705 139.73815167023358 44.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54a681ef-0eea-4401-a312-b4faf73d796a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54a681ef-0eea-4401-a312-b4faf73d796a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54a681ef-0eea-4401-a312-b4faf73d796a">
											<gml:posList>35.6686854549876 139.7381381251136 42.059 35.6686854549876 139.7381381251136 41.105 35.66867045878057 139.73816427780955 41.105 35.66867045878057 139.73816427780955 42.059 35.6686854549876 139.7381381251136 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e056b801-5596-4864-9224-7181470a5e2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e056b801-5596-4864-9224-7181470a5e2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e056b801-5596-4864-9224-7181470a5e2d">
											<gml:posList>35.66867069428104 139.73816572455914 37.67 35.66868667163957 139.73813786961057 37.67 35.66868667163957 139.73813786961057 42.059 35.66867069428104 139.73816572455914 42.059 35.66867069428104 139.73816572455914 37.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3c03a15-29dc-4451-bda1-68118a9a3a20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3c03a15-29dc-4451-bda1-68118a9a3a20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3c03a15-29dc-4451-bda1-68118a9a3a20">
											<gml:posList>35.66862097037101 139.7381490599062 44.668 35.668628339604545 139.7381554026185 44.668 35.668628330582095 139.7381553915832 43.407 35.66862096134855 139.73814904887087 43.407 35.66862097037101 139.7381490599062 44.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb1e93b1-c050-49b0-9f3f-a08e70780fe1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb1e93b1-c050-49b0-9f3f-a08e70780fe1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb1e93b1-c050-49b0-9f3f-a08e70780fe1">
											<gml:posList>35.668647964182135 139.7381347232654 44.077 35.66864795515968 139.7381347122301 43.406 35.66862546998385 139.73817409588634 43.406 35.6686254790063 139.73817410692163 44.077 35.668647964182135 139.7381347232654 44.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d612928-ded5-448b-a985-2216b8a636be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d612928-ded5-448b-a985-2216b8a636be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d612928-ded5-448b-a985-2216b8a636be">
											<gml:posList>35.66862576000301 139.7381760948713 44.078 35.66862576000301 139.7381760948713 42.059 35.66862626407327 139.7381752105917 42.059 35.66862626407327 139.7381752105917 41.105 35.66864957736814 139.73813437892346 41.105 35.66864957736814 139.73813437892346 44.078 35.66862576000301 139.7381760948713 44.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-033c2389-20a0-4350-a7f3-4951b98bee4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-033c2389-20a0-4350-a7f3-4951b98bee4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-033c2389-20a0-4350-a7f3-4951b98bee4b">
											<gml:posList>35.66861282411685 139.73816319743065 44.08 35.66861214901287 139.7381643691096 44.081 35.66861217607151 139.7381643911695 44.668 35.66862097037101 139.7381490599062 44.668 35.66862096134855 139.73814904887087 43.407 35.66861280608939 139.73816319745202 43.41 35.66861282411685 139.73816319743065 44.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5b8bef1-12ec-4d69-a2af-536404ed7004">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5b8bef1-12ec-4d69-a2af-536404ed7004">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5b8bef1-12ec-4d69-a2af-536404ed7004">
											<gml:posList>35.66861282411685 139.73816319743065 44.08 35.66861280608939 139.73816319745202 43.41 35.668599429603255 139.73815165919828 43.408 35.668599438625705 139.73815167023358 44.079 35.66861282411685 139.73816319743065 44.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f69f6bc-04ed-4a88-b07a-f8304e17fff8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f69f6bc-04ed-4a88-b07a-f8304e17fff8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f69f6bc-04ed-4a88-b07a-f8304e17fff8">
											<gml:posList>35.66865376519157 139.73815267720877 42.059 35.66865376519157 139.73815267720877 20.63 35.66867069428104 139.73816572455914 20.63 35.66867069428104 139.73816572455914 37.67 35.66867069428104 139.73816572455914 42.059 35.66865376519157 139.73815267720877 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2ef2477-da74-4325-a966-10672ff28910">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2ef2477-da74-4325-a966-10672ff28910">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2ef2477-da74-4325-a966-10672ff28910">
											<gml:posList>35.66855128321275 139.7381465468194 20.63 35.66858790390401 139.73817809494133 20.63 35.66858790390401 139.73817809494133 42.059 35.668585477553556 139.7381759990785 42.059 35.668585477553556 139.7381759990785 45.831 35.66855128321275 139.7381465468194 45.831 35.66855128321275 139.7381465468194 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83034db7-c8bb-4654-9a53-0bf53d088479">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83034db7-c8bb-4654-9a53-0bf53d088479">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83034db7-c8bb-4654-9a53-0bf53d088479">
											<gml:posList>35.668619545312986 139.73817074492854 44.668 35.6686195543267 139.73817074491785 44.079 35.66862022042574 139.73816958429555 44.078 35.66862021140328 139.73816957326025 43.408 35.668628330582095 139.7381553915832 43.407 35.668628339604545 139.7381554026185 44.668 35.668619545312986 139.73817074492854 44.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e270e69-8b12-4fbf-b79e-119c437c5007">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e270e69-8b12-4fbf-b79e-119c437c5007">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e270e69-8b12-4fbf-b79e-119c437c5007">
											<gml:posList>35.668585477553556 139.7381759990785 45.831 35.668585477553556 139.7381759990785 42.059 35.66859876352186 139.7381528419124 42.059 35.66859876352186 139.7381528419124 44.078 35.66859876352186 139.7381528419124 45.831 35.668585477553556 139.7381759990785 45.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-129557f7-b025-4cdf-a4de-8b6090e8c3c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-129557f7-b025-4cdf-a4de-8b6090e8c3c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-129557f7-b025-4cdf-a4de-8b6090e8c3c7">
											<gml:posList>35.6687017438509 139.73815085289124 34.328 35.6687017438509 139.73815085289124 37.67 35.66868575747567 139.7381787078532 37.67 35.66868575747567 139.7381787078532 34.328 35.6687017438509 139.73815085289124 34.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0bff647-f0d4-4cce-abda-b2dfae710a1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0bff647-f0d4-4cce-abda-b2dfae710a1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0bff647-f0d4-4cce-abda-b2dfae710a1c">
											<gml:posList>35.66858790390401 139.73817809494133 20.63 35.66860113574671 139.7381548826091 20.63 35.66860113574671 139.7381548826091 42.059 35.66858790390401 139.73817809494133 42.059 35.66858790390401 139.73817809494133 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15723afb-affb-4659-9319-6d9e9f4443cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15723afb-affb-4659-9319-6d9e9f4443cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15723afb-affb-4659-9319-6d9e9f4443cb">
											<gml:posList>35.66865351165477 139.7381512194349 42.059 35.66865351165477 139.7381512194349 41.105 35.66863589730399 139.73818351681155 41.105 35.66863589730399 139.73818351681155 42.059 35.66865351165477 139.7381512194349 42.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25701699-7ea6-4da4-817f-8763e8f29cff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25701699-7ea6-4da4-817f-8763e8f29cff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25701699-7ea6-4da4-817f-8763e8f29cff">
											<gml:posList>35.668636123834155 139.73818501880132 20.63 35.66865376519157 139.73815267720877 20.63 35.66865376519157 139.73815267720877 42.059 35.668636123834155 139.73818501880132 42.059 35.668636123834155 139.73818501880132 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f31c38b-c18c-474e-867d-bfec87ce3c31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f31c38b-c18c-474e-867d-bfec87ce3c31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f31c38b-c18c-474e-867d-bfec87ce3c31">
											<gml:posList>35.66860113574671 139.7381548826091 20.63 35.668636123834155 139.73818501880132 20.63 35.668636123834155 139.73818501880132 42.059 35.66862576000301 139.7381760948713 42.059 35.66862576000301 139.7381760948713 44.078 35.6686195543267 139.73817074491785 44.079 35.668619545312986 139.73817074492854 44.668 35.66861217607151 139.7381643911695 44.668 35.66861214901287 139.7381643691096 44.081 35.66859876352186 139.7381528419124 44.078 35.66859876352186 139.7381528419124 42.059 35.66860113574671 139.7381548826091 42.059 35.66860113574671 139.7381548826091 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ddfb6466-de49-478f-8cb0-3226fc46af26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddfb6466-de49-478f-8cb0-3226fc46af26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddfb6466-de49-478f-8cb0-3226fc46af26">
											<gml:posList>35.6686254790063 139.73817410692163 44.077 35.66862546998385 139.73817409588634 43.406 35.66862021140328 139.73816957326025 43.408 35.66862022042574 139.73816958429555 44.078 35.6686254790063 139.73817410692163 44.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d3294f1-98ae-4350-88e8-0b0d891eda09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d3294f1-98ae-4350-88e8-0b0d891eda09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d3294f1-98ae-4350-88e8-0b0d891eda09">
											<gml:posList>35.66871682507451 139.73816383616608 32.194 35.66871682507451 139.73816383616608 34.328 35.66870082969134 139.7381917021874 34.328 35.66870082969134 139.7381917021874 32.194 35.66871682507451 139.73816383616608 32.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4d139ab-8a47-453b-84fb-aedb046bb85e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4d139ab-8a47-453b-84fb-aedb046bb85e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4d139ab-8a47-453b-84fb-aedb046bb85e">
											<gml:posList>35.66870082969134 139.7381917021874 32.194 35.66870082969134 139.7381917021874 34.328 35.66868575747567 139.7381787078532 34.328 35.66868575747567 139.7381787078532 37.67 35.66867069428104 139.73816572455914 37.67 35.66867069428104 139.73816572455914 20.63 35.668715766603704 139.7382045751807 20.63 35.668715766603704 139.7382045751807 32.194 35.66870082969134 139.7381917021874 32.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-704591fe-e9c6-491b-b2a7-cd89e39c8d9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-704591fe-e9c6-491b-b2a7-cd89e39c8d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-704591fe-e9c6-491b-b2a7-cd89e39c8d9b">
											<gml:posList>35.668715766603704 139.7382045751807 20.63 35.66873176198982 139.73817670915676 20.63 35.66873176198982 139.73817670915676 32.194 35.668715766603704 139.7382045751807 32.194 35.668715766603704 139.7382045751807 20.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7833</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">133.31305</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>