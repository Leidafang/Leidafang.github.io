<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c86733f6-1d06-4d47-81ac-2838ef60dc32">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672792350489 139.73878606920815 0 35.67277932062546 139.7387567116923 0 35.672760194495496 139.73876945992373 0 35.672773233369675 139.73879881742408 0 35.672792350489 139.73878606920815 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672792350489 139.73878606920815 8.069 35.672773233369675 139.73879881742408 8.069 35.672760194495496 139.73876945992373 8.069 35.67277932062546 139.7387567116923 8.069 35.672792350489 139.73878606920815 8.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672792350489 139.73878606920815 8.069 35.67277932062546 139.7387567116923 8.069 35.67277932062546 139.7387567116923 11.069 35.672792350489 139.73878606920815 11.069 35.672792350489 139.73878606920815 8.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67277932062546 139.7387567116923 8.069 35.672760194495496 139.73876945992373 8.069 35.672760194495496 139.73876945992373 11.069 35.67277932062546 139.7387567116923 11.069 35.67277932062546 139.7387567116923 8.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672760194495496 139.73876945992373 8.069 35.672773233369675 139.73879881742408 8.069 35.672773233369675 139.73879881742408 11.069 35.672760194495496 139.73876945992373 11.069 35.672760194495496 139.73876945992373 8.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672773233369675 139.73879881742408 8.069 35.672792350489 139.73878606920815 8.069 35.672792350489 139.73878606920815 11.069 35.672773233369675 139.73879881742408 11.069 35.672773233369675 139.73879881742408 8.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672792350489 139.73878606920815 11.069 35.67277932062546 139.7387567116923 11.069 35.672760194495496 139.73876945992373 11.069 35.672773233369675 139.73879881742408 11.069 35.672792350489 139.73878606920815 11.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9d7897e2-b92f-40bf-8b51-08b66000efb8"/>
							<gml:surfaceMember xlink:href="#poly-83854922-776e-42a5-944a-8e370753f621"/>
							<gml:surfaceMember xlink:href="#poly-2c66f593-a3f7-41eb-a5a8-b240ce5f5525"/>
							<gml:surfaceMember xlink:href="#poly-9a91f8a5-f08b-49bb-b2f9-a662b3734cec"/>
							<gml:surfaceMember xlink:href="#poly-aca7e8cd-03a0-43c6-a0b7-5da4ef9463ef"/>
							<gml:surfaceMember xlink:href="#poly-ea5c2cc8-c5d8-4915-9462-1fe91055a840"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9d7897e2-b92f-40bf-8b51-08b66000efb8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d7897e2-b92f-40bf-8b51-08b66000efb8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d7897e2-b92f-40bf-8b51-08b66000efb8">
											<gml:posList>35.67279235048898 139.73878606920817 8.069 35.67277323336966 139.73879881742405 8.069 35.67276019449548 139.73876945992373 8.069 35.67277932062546 139.7387567116923 8.069 35.67279235048898 139.73878606920817 8.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83854922-776e-42a5-944a-8e370753f621">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83854922-776e-42a5-944a-8e370753f621">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83854922-776e-42a5-944a-8e370753f621">
											<gml:posList>35.67277932062546 139.7387567116923 10.911 35.67276019449548 139.73876945992373 10.911 35.67277323336966 139.73879881742405 10.911 35.67279235048898 139.73878606920817 10.911 35.67277932062546 139.7387567116923 10.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c66f593-a3f7-41eb-a5a8-b240ce5f5525">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c66f593-a3f7-41eb-a5a8-b240ce5f5525">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c66f593-a3f7-41eb-a5a8-b240ce5f5525">
											<gml:posList>35.67277932062546 139.7387567116923 10.911 35.67277932062546 139.7387567116923 8.069 35.67276019449548 139.73876945992373 8.069 35.67276019449548 139.73876945992373 10.911 35.67277932062546 139.7387567116923 10.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a91f8a5-f08b-49bb-b2f9-a662b3734cec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a91f8a5-f08b-49bb-b2f9-a662b3734cec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a91f8a5-f08b-49bb-b2f9-a662b3734cec">
											<gml:posList>35.67279235048898 139.73878606920817 10.911 35.67279235048898 139.73878606920817 8.069 35.67277932062546 139.7387567116923 8.069 35.67277932062546 139.7387567116923 10.911 35.67279235048898 139.73878606920817 10.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aca7e8cd-03a0-43c6-a0b7-5da4ef9463ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aca7e8cd-03a0-43c6-a0b7-5da4ef9463ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aca7e8cd-03a0-43c6-a0b7-5da4ef9463ef">
											<gml:posList>35.67276019449548 139.73876945992373 10.911 35.67276019449548 139.73876945992373 8.069 35.67277323336966 139.73879881742405 8.069 35.67277323336966 139.73879881742405 10.911 35.67276019449548 139.73876945992373 10.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea5c2cc8-c5d8-4915-9462-1fe91055a840">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea5c2cc8-c5d8-4915-9462-1fe91055a840">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea5c2cc8-c5d8-4915-9462-1fe91055a840">
											<gml:posList>35.67277323336966 139.73879881742405 10.911 35.67277323336966 139.73879881742405 8.069 35.67279235048898 139.73878606920817 8.069 35.67279235048898 139.73878606920817 10.911 35.67277323336966 139.73879881742405 10.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1486</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>