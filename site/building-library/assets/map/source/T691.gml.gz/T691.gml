<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c879f5d2-5501-44bf-8f8c-bcb8f66d7200">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">13.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67070493781441 139.7417543640796 0 35.67066666812813 139.74180522076745 0 35.670743170209086 139.74189162603813 0 35.67078134987808 139.74184087990878 0 35.67070493781441 139.7417543640796 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070493781441 139.7417543640796 8.26 35.67078134987808 139.74184087990878 8.26 35.670743170209086 139.74189162603813 8.26 35.67066666812813 139.74180522076745 8.26 35.67070493781441 139.7417543640796 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070493781441 139.7417543640796 8.26 35.67066666812813 139.74180522076745 8.26 35.67066666812813 139.74180522076745 22.11 35.67070493781441 139.7417543640796 22.11 35.67070493781441 139.7417543640796 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066666812813 139.74180522076745 8.26 35.670743170209086 139.74189162603813 8.26 35.670743170209086 139.74189162603813 22.11 35.67066666812813 139.74180522076745 22.11 35.67066666812813 139.74180522076745 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670743170209086 139.74189162603813 8.26 35.67078134987808 139.74184087990878 8.26 35.67078134987808 139.74184087990878 22.11 35.670743170209086 139.74189162603813 22.11 35.670743170209086 139.74189162603813 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078134987808 139.74184087990878 8.26 35.67070493781441 139.7417543640796 8.26 35.67070493781441 139.7417543640796 22.11 35.67078134987808 139.74184087990878 22.11 35.67078134987808 139.74184087990878 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070493781441 139.7417543640796 22.11 35.67066666812813 139.74180522076745 22.11 35.670743170209086 139.74189162603813 22.11 35.67078134987808 139.74184087990878 22.11 35.67070493781441 139.7417543640796 22.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9271f232-228b-4468-83cc-68b7e5fedea0"/>
							<gml:surfaceMember xlink:href="#poly-f34fd5e7-e13d-4d42-8c54-89e866011812"/>
							<gml:surfaceMember xlink:href="#poly-e42627f9-ca3c-4845-a75b-89324564cc31"/>
							<gml:surfaceMember xlink:href="#poly-9f57a65e-08f7-4e09-ac03-018133a1718d"/>
							<gml:surfaceMember xlink:href="#poly-7987dddb-f126-48af-9b99-5852f5327d2d"/>
							<gml:surfaceMember xlink:href="#poly-919cf9c9-2e2c-4af7-834b-ff652873e85e"/>
							<gml:surfaceMember xlink:href="#poly-63615cfd-f1de-42db-885e-5fc90cef38dd"/>
							<gml:surfaceMember xlink:href="#poly-1a760d86-64b2-456d-8e01-5df3a5274385"/>
							<gml:surfaceMember xlink:href="#poly-922b7129-0262-4cbe-a9e3-b1e0818d2c1f"/>
							<gml:surfaceMember xlink:href="#poly-70bde48b-ea31-4916-82cd-86cf9aeefe4c"/>
							<gml:surfaceMember xlink:href="#poly-4a59469f-7ba8-4eb2-b431-3c9e038ce7ff"/>
							<gml:surfaceMember xlink:href="#poly-f0b274bf-dabb-4348-b4f3-15f37773745c"/>
							<gml:surfaceMember xlink:href="#poly-b6c1c0c4-b6ef-46e3-af0d-27cfbb0a4f6c"/>
							<gml:surfaceMember xlink:href="#poly-145070ab-8ceb-42ee-8baf-b3f8db62998c"/>
							<gml:surfaceMember xlink:href="#poly-2e7411cf-f459-418a-9c80-6fb5d1edfd19"/>
							<gml:surfaceMember xlink:href="#poly-f3298e88-0167-4d65-ab5b-eb515602cd03"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9271f232-228b-4468-83cc-68b7e5fedea0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9271f232-228b-4468-83cc-68b7e5fedea0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9271f232-228b-4468-83cc-68b7e5fedea0">
											<gml:posList>35.6707049378144 139.7417543640796 8.26 35.67078134987806 139.74184087990875 8.26 35.670743170209086 139.74189162603813 8.26 35.67066666812813 139.74180522076745 8.26 35.6707049378144 139.7417543640796 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f34fd5e7-e13d-4d42-8c54-89e866011812">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f34fd5e7-e13d-4d42-8c54-89e866011812">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f34fd5e7-e13d-4d42-8c54-89e866011812">
											<gml:posList>35.67066666812813 139.74180522076745 23.023 35.670671210884784 139.74180500570182 23.023 35.67070512233133 139.74175994225254 23.023 35.6707049378144 139.7417543640796 23.023 35.67066666812813 139.74180522076745 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e42627f9-ca3c-4845-a75b-89324564cc31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e42627f9-ca3c-4845-a75b-89324564cc31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e42627f9-ca3c-4845-a75b-89324564cc31">
											<gml:posList>35.6707049378144 139.7417543640796 23.023 35.67070512233133 139.74175994225254 23.023 35.67075008545742 139.74181083648222 23.023 35.67075451995701 139.74181050003085 23.023 35.6707049378144 139.7417543640796 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f57a65e-08f7-4e09-ac03-018133a1718d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f57a65e-08f7-4e09-ac03-018133a1718d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f57a65e-08f7-4e09-ac03-018133a1718d">
											<gml:posList>35.67075008545742 139.74181083648222 22.391 35.67070512233133 139.74175994225254 22.391 35.670671210884784 139.74180500570182 22.391 35.670717842873465 139.74185766544016 22.391 35.67075008545742 139.74181083648222 22.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7987dddb-f126-48af-9b99-5852f5327d2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7987dddb-f126-48af-9b99-5852f5327d2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7987dddb-f126-48af-9b99-5852f5327d2d">
											<gml:posList>35.670718126612066 139.7418633429178 23.023 35.670717842873465 139.74185766544016 23.023 35.670671210884784 139.74180500570182 23.023 35.67066666812813 139.74180522076745 23.023 35.670718126612066 139.7418633429178 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-919cf9c9-2e2c-4af7-834b-ff652873e85e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-919cf9c9-2e2c-4af7-834b-ff652873e85e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-919cf9c9-2e2c-4af7-834b-ff652873e85e">
											<gml:posList>35.67078134987806 139.74184087990875 17.117 35.67075451995701 139.74181050003085 23.023 35.670718126612066 139.7418633429178 23.023 35.67078134987806 139.74184087990875 17.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63615cfd-f1de-42db-885e-5fc90cef38dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63615cfd-f1de-42db-885e-5fc90cef38dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63615cfd-f1de-42db-885e-5fc90cef38dd">
											<gml:posList>35.67075451995701 139.74181050003085 23.023 35.67075008545742 139.74181083648222 23.023 35.670717842873465 139.74185766544016 23.023 35.670718126612066 139.7418633429178 23.023 35.67075451995701 139.74181050003085 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a760d86-64b2-456d-8e01-5df3a5274385">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a760d86-64b2-456d-8e01-5df3a5274385">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a760d86-64b2-456d-8e01-5df3a5274385">
											<gml:posList>35.670718126612066 139.7418633429178 23.023 35.670743170209086 139.74189162603813 17.117 35.67078134987806 139.74184087990875 17.117 35.670718126612066 139.7418633429178 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-922b7129-0262-4cbe-a9e3-b1e0818d2c1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-922b7129-0262-4cbe-a9e3-b1e0818d2c1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-922b7129-0262-4cbe-a9e3-b1e0818d2c1f">
											<gml:posList>35.67070512233133 139.74175994225254 23.023 35.67070512233133 139.74175994225254 22.391 35.67075008545742 139.74181083648222 22.391 35.67075008545742 139.74181083648222 23.023 35.67070512233133 139.74175994225254 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70bde48b-ea31-4916-82cd-86cf9aeefe4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70bde48b-ea31-4916-82cd-86cf9aeefe4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70bde48b-ea31-4916-82cd-86cf9aeefe4c">
											<gml:posList>35.670717842873465 139.74185766544016 23.023 35.670717842873465 139.74185766544016 22.391 35.670671210884784 139.74180500570182 22.391 35.670671210884784 139.74180500570182 23.023 35.670717842873465 139.74185766544016 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a59469f-7ba8-4eb2-b431-3c9e038ce7ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a59469f-7ba8-4eb2-b431-3c9e038ce7ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a59469f-7ba8-4eb2-b431-3c9e038ce7ff">
											<gml:posList>35.6707049378144 139.7417543640796 8.26 35.67066666812813 139.74180522076745 8.26 35.67066666812813 139.74180522076745 23.023 35.6707049378144 139.7417543640796 23.023 35.6707049378144 139.7417543640796 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0b274bf-dabb-4348-b4f3-15f37773745c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0b274bf-dabb-4348-b4f3-15f37773745c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0b274bf-dabb-4348-b4f3-15f37773745c">
											<gml:posList>35.670671210884784 139.74180500570182 23.023 35.670671210884784 139.74180500570182 22.391 35.67070512233133 139.74175994225254 22.391 35.67070512233133 139.74175994225254 23.023 35.670671210884784 139.74180500570182 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6c1c0c4-b6ef-46e3-af0d-27cfbb0a4f6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6c1c0c4-b6ef-46e3-af0d-27cfbb0a4f6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6c1c0c4-b6ef-46e3-af0d-27cfbb0a4f6c">
											<gml:posList>35.670743170209086 139.74189162603813 17.117 35.670718126612066 139.7418633429178 23.023 35.67066666812813 139.74180522076745 23.023 35.67066666812813 139.74180522076745 8.26 35.670743170209086 139.74189162603813 8.26 35.670743170209086 139.74189162603813 17.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-145070ab-8ceb-42ee-8baf-b3f8db62998c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-145070ab-8ceb-42ee-8baf-b3f8db62998c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-145070ab-8ceb-42ee-8baf-b3f8db62998c">
											<gml:posList>35.67075008545742 139.74181083648222 23.023 35.67075008545742 139.74181083648222 22.391 35.670717842873465 139.74185766544016 22.391 35.670717842873465 139.74185766544016 23.023 35.67075008545742 139.74181083648222 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e7411cf-f459-418a-9c80-6fb5d1edfd19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e7411cf-f459-418a-9c80-6fb5d1edfd19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e7411cf-f459-418a-9c80-6fb5d1edfd19">
											<gml:posList>35.6707049378144 139.7417543640796 23.023 35.67075451995701 139.74181050003085 23.023 35.67078134987806 139.74184087990875 17.117 35.67078134987806 139.74184087990875 8.26 35.6707049378144 139.7417543640796 8.26 35.6707049378144 139.7417543640796 23.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3298e88-0167-4d65-ab5b-eb515602cd03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3298e88-0167-4d65-ab5b-eb515602cd03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3298e88-0167-4d65-ab5b-eb515602cd03">
											<gml:posList>35.670743170209086 139.74189162603813 8.26 35.67078134987806 139.74184087990875 8.26 35.67078134987806 139.74184087990875 17.117 35.670743170209086 139.74189162603813 17.117 35.670743170209086 139.74189162603813 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4523</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">72.2022</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>