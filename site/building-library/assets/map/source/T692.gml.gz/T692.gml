<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c8ad3ab2-40d1-47f8-a086-450749bbbbdb">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101008003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">32.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>2</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6726503014903 139.7470296420106 0 35.67264473665615 139.74693696726132 0 35.672574467277016 139.74686391474413 0 35.672299562342666 139.74726056054442 0 35.672410152950235 139.74737576768914 0 35.6726503014903 139.7470296420106 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6726503014903 139.7470296420106 11.45 35.672410152950235 139.74737576768914 11.45 35.672299562342666 139.74726056054442 11.45 35.672574467277016 139.74686391474413 11.45 35.67264473665615 139.74693696726132 11.45 35.6726503014903 139.7470296420106 11.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6726503014903 139.7470296420106 11.45 35.67264473665615 139.74693696726132 11.45 35.67264473665615 139.74693696726132 44.120000000000005 35.6726503014903 139.7470296420106 44.120000000000005 35.6726503014903 139.7470296420106 11.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67264473665615 139.74693696726132 11.45 35.672574467277016 139.74686391474413 11.45 35.672574467277016 139.74686391474413 44.120000000000005 35.67264473665615 139.74693696726132 44.120000000000005 35.67264473665615 139.74693696726132 11.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672574467277016 139.74686391474413 11.45 35.672299562342666 139.74726056054442 11.45 35.672299562342666 139.74726056054442 44.120000000000005 35.672574467277016 139.74686391474413 44.120000000000005 35.672574467277016 139.74686391474413 11.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672299562342666 139.74726056054442 11.45 35.672410152950235 139.74737576768914 11.45 35.672410152950235 139.74737576768914 44.120000000000005 35.672299562342666 139.74726056054442 44.120000000000005 35.672299562342666 139.74726056054442 11.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672410152950235 139.74737576768914 11.45 35.6726503014903 139.7470296420106 11.45 35.6726503014903 139.7470296420106 44.120000000000005 35.672410152950235 139.74737576768914 44.120000000000005 35.672410152950235 139.74737576768914 11.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6726503014903 139.7470296420106 44.120000000000005 35.67264473665615 139.74693696726132 44.120000000000005 35.672574467277016 139.74686391474413 44.120000000000005 35.672299562342666 139.74726056054442 44.120000000000005 35.672410152950235 139.74737576768914 44.120000000000005 35.6726503014903 139.7470296420106 44.120000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-37a2e6ed-4a1b-4e43-9736-bbf16d9fb1c6"/>
							<gml:surfaceMember xlink:href="#poly-72cf46cc-ccd9-41f4-8abb-bf0dfb4522be"/>
							<gml:surfaceMember xlink:href="#poly-ec7a156e-0352-4e8b-be01-12e8686286a8"/>
							<gml:surfaceMember xlink:href="#poly-f8ad0477-20ff-4847-b8cc-ed4a9dee1e93"/>
							<gml:surfaceMember xlink:href="#poly-e97effab-2549-4729-83db-11d0ef554f93"/>
							<gml:surfaceMember xlink:href="#poly-fd1434a2-d868-44c0-8c56-52b743bf2497"/>
							<gml:surfaceMember xlink:href="#poly-ea920f77-a698-4f55-a26b-d1c2c580dea7"/>
							<gml:surfaceMember xlink:href="#poly-074525f1-f4bd-4fb7-b24d-e14358d3ae33"/>
							<gml:surfaceMember xlink:href="#poly-0778506e-2653-448c-8f1d-35a866fc73bd"/>
							<gml:surfaceMember xlink:href="#poly-050e684e-b1d1-40d7-ba76-fec1077558b6"/>
							<gml:surfaceMember xlink:href="#poly-4711526b-3f2d-4159-961c-407f270e4291"/>
							<gml:surfaceMember xlink:href="#poly-7424ad38-d09e-457e-849f-639dd45538e0"/>
							<gml:surfaceMember xlink:href="#poly-86bd9382-b8b7-4407-a857-97cfa7632524"/>
							<gml:surfaceMember xlink:href="#poly-25da28de-4742-4989-b326-4eef5ff1dfe5"/>
							<gml:surfaceMember xlink:href="#poly-6a2bb02a-a809-4648-bde6-05d7b24537e3"/>
							<gml:surfaceMember xlink:href="#poly-9f7f93d3-c21d-4e55-9af6-65181b50c387"/>
							<gml:surfaceMember xlink:href="#poly-a91ce662-0a7b-424f-babe-ed3a8c81aced"/>
							<gml:surfaceMember xlink:href="#poly-858d7c77-a4f5-4c4e-9d4e-369a9984339d"/>
							<gml:surfaceMember xlink:href="#poly-f2435d4a-e0a6-4595-b604-9becaf7e6914"/>
							<gml:surfaceMember xlink:href="#poly-a0ad6bb4-18a7-4a9b-9290-51947899c47f"/>
							<gml:surfaceMember xlink:href="#poly-c18d1ab6-fd43-4094-9c82-57dfe68edda9"/>
							<gml:surfaceMember xlink:href="#poly-09d747fa-799a-496b-9e1a-63feeab5e2fd"/>
							<gml:surfaceMember xlink:href="#poly-b8a6c842-71cf-4654-888d-f36877d3b267"/>
							<gml:surfaceMember xlink:href="#poly-64a21da6-1f24-4c16-9999-3c31d8479e6b"/>
							<gml:surfaceMember xlink:href="#poly-51a80922-1392-4819-a709-16093fb4276a"/>
							<gml:surfaceMember xlink:href="#poly-7d5c859c-5a3b-4c27-94c2-ffb51e693146"/>
							<gml:surfaceMember xlink:href="#poly-b05c3c9b-dac9-47c4-bc12-b582e55a3c34"/>
							<gml:surfaceMember xlink:href="#poly-7f2f27e6-d36f-4093-bd05-18e6fa754ca0"/>
							<gml:surfaceMember xlink:href="#poly-4e236bf8-4d1f-478f-b9e3-e06a44ff4c03"/>
							<gml:surfaceMember xlink:href="#poly-58aa7908-6919-4b69-b036-3d8079d7691a"/>
							<gml:surfaceMember xlink:href="#poly-20c85836-67d6-4522-9bd5-388740621d61"/>
							<gml:surfaceMember xlink:href="#poly-697bde9e-096c-41af-b74e-bea8bea54fce"/>
							<gml:surfaceMember xlink:href="#poly-b159c232-cc19-41d2-bda7-08fde2c88449"/>
							<gml:surfaceMember xlink:href="#poly-79802162-1de7-4dc9-8393-ab2ecaafff3d"/>
							<gml:surfaceMember xlink:href="#poly-162b23a8-13c1-461e-a8e4-bb81e0582f93"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c8ad3ab2-40d1-47f8-a086-450749bbbbdb_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ef6ac77-9014-4777-a66b-d31bd1187b0d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67245157022563 139.74704697808878 44.4 35.67244339422045 139.74705878459775 44.4 35.672443033402494 139.74705840940354 44.4 35.672451218421365 139.74704660288486 44.4 35.67245157022563 139.74704697808878 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc251a75-559d-4d7a-977a-b5899bbb228b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67247209176482 139.74706834211952 43.872 35.672463915757554 139.74708014862935 43.872 35.67244339422045 139.74705878459775 43.872 35.67245157022563 139.74704697808878 43.872 35.67247209176482 139.74706834211952 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b96f3ec3-5624-4f9e-a505-766003945744">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67246061470861 139.7470899062816 43.872 35.67247821834106 139.74706449132816 43.872 35.67253852006753 139.74712725925886 43.872 35.672520907408284 139.74715267422735 43.872 35.67246061470861 139.7470899062816 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-150ea6ef-36bc-41dd-ac41-1fe7f21055b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-150ea6ef-36bc-41dd-ac41-1fe7f21055b7_0">
											<gml:posList>35.672463915757554 139.74708014862935 43.872 35.67247209176482 139.74706834211952 43.872 35.67247209176482 139.74706834211952 45.07 35.672463915757554 139.74708014862935 45.07 35.672463915757554 139.74708014862935 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abfff3dd-8b58-4e2e-a985-1c1c79ed0fc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abfff3dd-8b58-4e2e-a985-1c1c79ed0fc2_0">
											<gml:posList>35.672451218421365 139.74704660288486 44.4 35.672443033402494 139.74705840940354 44.4 35.672443033402494 139.74705840940354 45.07 35.672451218421365 139.74704660288486 45.07 35.672451218421365 139.74704660288486 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2af7a92-5b90-4b31-8b9a-a64a1fed2565">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2af7a92-5b90-4b31-8b9a-a64a1fed2565_0">
											<gml:posList>35.67244339422045 139.74705878459775 44.4 35.67245157022563 139.74704697808878 44.4 35.67245157022563 139.74704697808878 43.872 35.67244339422045 139.74705878459775 43.872 35.67244339422045 139.74705878459775 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3da50c34-9c5e-42d8-9630-31e2919928b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3da50c34-9c5e-42d8-9630-31e2919928b3_0">
											<gml:posList>35.672463915757554 139.74708014862935 43.872 35.672463915757554 139.74708014862935 45.07 35.672443033402494 139.74705840940354 45.07 35.672443033402494 139.74705840940354 44.4 35.67244339422045 139.74705878459775 44.4 35.67244339422045 139.74705878459775 43.872 35.672463915757554 139.74708014862935 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-918a76a1-70bb-4d96-98be-2ea27eb081ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-918a76a1-70bb-4d96-98be-2ea27eb081ee_0">
											<gml:posList>35.67247209176482 139.74706834211952 45.07 35.672451218421365 139.74704660288486 45.07 35.672443033402494 139.74705840940354 45.07 35.672463915757554 139.74708014862935 45.07 35.67247209176482 139.74706834211952 45.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-baae4e37-b983-4f48-bb7d-3ba91755c86a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-baae4e37-b983-4f48-bb7d-3ba91755c86a_0">
											<gml:posList>35.672451218421365 139.74704660288486 45.07 35.67247209176482 139.74706834211952 45.07 35.67247209176482 139.74706834211952 43.872 35.67245157022563 139.74704697808878 43.872 35.67245157022563 139.74704697808878 44.4 35.672451218421365 139.74704660288486 44.4 35.672451218421365 139.74704660288486 45.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-485b9d8b-da99-4385-98fd-5ee59f29b66c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-485b9d8b-da99-4385-98fd-5ee59f29b66c_0">
											<gml:posList>35.67247821834106 139.74706449132816 43.872 35.67246061470861 139.7470899062816 43.872 35.67246061470861 139.7470899062816 46.887 35.67247821834106 139.74706449132816 46.887 35.67247821834106 139.74706449132816 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8791ea8-2622-47eb-9fe4-800a8fad2861">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8791ea8-2622-47eb-9fe4-800a8fad2861_0">
											<gml:posList>35.67246061470861 139.7470899062816 43.872 35.672520907408284 139.74715267422735 43.872 35.672520907408284 139.74715267422735 46.887 35.67246061470861 139.7470899062816 46.887 35.67246061470861 139.7470899062816 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a4f3853-0a0e-44de-987a-63253f17d1ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a4f3853-0a0e-44de-987a-63253f17d1ba_0">
											<gml:posList>35.67253852006753 139.74712725925886 46.887 35.67247821834106 139.74706449132816 46.887 35.67246061470861 139.7470899062816 46.887 35.672520907408284 139.74715267422735 46.887 35.67253852006753 139.74712725925886 46.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38ad4ac0-4d63-43b6-a3d5-81d8fb67127e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38ad4ac0-4d63-43b6-a3d5-81d8fb67127e_0">
											<gml:posList>35.67247821834106 139.74706449132816 46.887 35.67253852006753 139.74712725925886 46.887 35.67253852006753 139.74712725925886 43.872 35.67247821834106 139.74706449132816 43.872 35.67247821834106 139.74706449132816 46.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa19ec1a-bdee-456d-b619-7cabcb3c6758">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa19ec1a-bdee-456d-b619-7cabcb3c6758_0">
											<gml:posList>35.672520907408284 139.74715267422735 43.872 35.67253852006753 139.74712725925886 43.872 35.67253852006753 139.74712725925886 46.887 35.672520907408284 139.74715267422735 46.887 35.672520907408284 139.74715267422735 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c8ad3ab2-40d1-47f8-a086-450749bbbbdb_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c039149-9f60-4f0e-a704-4ad3db41cec8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672428045329646 139.74717416015574 43.872 35.67243950797874 139.74715763325398 43.872 35.672451288689345 139.7471699043495 43.872 35.67243983505231 139.74718643124228 43.872 35.672428045329646 139.74717416015574 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb070c71-b3ac-4a2c-9438-31ccbf38299e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb070c71-b3ac-4a2c-9438-31ccbf38299e_0">
											<gml:posList>35.67243950797874 139.74715763325398 43.872 35.67243950797874 139.74715763325398 45.768 35.672451288689345 139.7471699043495 45.768 35.672451288689345 139.7471699043495 43.872 35.67243950797874 139.74715763325398 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-046cc49e-3934-4f71-b3dd-107ce9191f2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-046cc49e-3934-4f71-b3dd-107ce9191f2c_0">
											<gml:posList>35.672428045329646 139.74717416015574 45.768 35.67243950797874 139.74715763325398 45.768 35.67243950797874 139.74715763325398 43.872 35.672428045329646 139.74717416015574 43.872 35.672428045329646 139.74717416015574 45.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef822a90-6dca-4a0d-943a-d8262a0f7a79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef822a90-6dca-4a0d-943a-d8262a0f7a79_0">
											<gml:posList>35.672428045329646 139.74717416015574 45.768 35.67243983505231 139.74718643124228 45.768 35.672451288689345 139.7471699043495 45.768 35.67243950797874 139.74715763325398 45.768 35.672428045329646 139.74717416015574 45.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-551b7195-f081-4346-adb1-4e7b16726ecd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-551b7195-f081-4346-adb1-4e7b16726ecd_0">
											<gml:posList>35.67243983505231 139.74718643124228 43.872 35.672451288689345 139.7471699043495 43.872 35.672451288689345 139.7471699043495 45.768 35.67243983505231 139.74718643124228 45.768 35.67243983505231 139.74718643124228 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c34bbc12-4c8e-4f0b-a07d-fc92ee408a9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c34bbc12-4c8e-4f0b-a07d-fc92ee408a9e_0">
											<gml:posList>35.672428045329646 139.74717416015574 45.768 35.672428045329646 139.74717416015574 43.872 35.67243983505231 139.74718643124228 43.872 35.67243983505231 139.74718643124228 45.768 35.672428045329646 139.74717416015574 45.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c8ad3ab2-40d1-47f8-a086-450749bbbbdb_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-093a32a2-6f31-438f-b125-5ac4f00a149c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67254394783936 139.7469784120972 43.872 35.672532574576095 139.74699385638735 43.872 35.67252352662128 139.74698383585914 43.872 35.67253489989121 139.7469684026159 43.872 35.67254394783936 139.7469784120972 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b33180f-4595-4f3e-9989-942bf3d4c278">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67258689266044 139.74700832412182 43.872 35.672580271362094 139.74700104051965 43.872 35.67259277920637 139.74698399324743 43.872 35.67259940050574 139.74699127684931 43.872 35.67258689266044 139.74700832412182 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea6271c6-5460-4acd-9695-0df44e2d0335">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67260648049852 139.74699715704446 43.872 35.67261245232604 139.7470037675074 43.872 35.67260016056284 139.74702047210454 43.872 35.67259418873622 139.74701386164136 43.872 35.67260648049852 139.74699715704446 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02366558-9a83-4723-a8c6-7390054d7458">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672462993508546 139.7470258558428 44.4 35.67247789582273 139.74700436530844 44.4 35.67247973603949 139.7470063406592 44.4 35.67246484274659 139.74702784223052 44.4 35.672462993508546 139.7470258558428 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0353b0b-9da9-4b96-908b-a3a193f5a534">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67250170560395 139.74702325136758 43.872 35.67248240914216 139.74705109840033 43.872 35.67246518909215 139.74703317734006 43.872 35.67246716106233 139.7470303362546 43.872 35.67246484274659 139.74702784223052 43.872 35.67247973603949 139.7470063406592 43.872 35.67248223477264 139.74700903332672 43.872 35.67248466595099 139.7470055068595 43.872 35.67250170560395 139.74702325136758 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29a605d2-2763-4f34-84aa-6d55781b965a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67248240914216 139.74705109840033 43.872 35.67250170560395 139.74702325136758 43.872 35.67250170560395 139.74702325136758 47.783 35.67248240914216 139.74705109840033 47.783 35.67248240914216 139.74705109840033 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6677b8e0-5ef9-44a0-9d53-425c84d02c74">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67245973723966 139.7470352047267 44.4 35.67245163325835 139.74704688964857 44.4 35.67244976602483 139.74704494746626 44.4 35.67245786999805 139.74703325149795 44.4 35.67245973723966 139.7470352047267 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04dbaa8f-4690-4ddd-9f6e-199863ffa7e9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67252800034754 139.74707593722465 43.872 35.67250651309108 139.74705282886103 43.872 35.6725374172564 139.747009647749 43.872 35.672558913526835 139.7470327450537 43.872 35.67252800034754 139.74707593722465 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f95a62fb-23eb-4fbb-ab85-1e60345537d9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67245973723966 139.7470352047267 43.872 35.672476858162206 139.74705315903256 43.872 35.672468754187086 139.74706485500164 43.872 35.67245163325835 139.74704688964857 43.872 35.67245973723966 139.7470352047267 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6ec30f0-b058-44d6-a919-e65dcac3cb11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672468754187086 139.74706485500164 43.872 35.672476858162206 139.74705315903256 43.872 35.672476858162206 139.74705315903256 45.07 35.672468754187086 139.74706485500164 45.07 35.672468754187086 139.74706485500164 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3165c2a-ace0-48f5-8120-eba27e859c7a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67249556533001 139.74705829763948 43.872 35.67251134347362 139.7470766289858 43.872 35.67250344575162 139.74708684449766 43.872 35.67248766760162 139.74706850210458 43.872 35.67249556533001 139.74705829763948 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53e5b869-efae-4f92-a879-4208c2b9513a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67253866629381 139.74707971471824 43.872 35.67255323506065 139.7470959043469 43.872 35.67253539613176 139.74712001607656 43.872 35.67252082736813 139.74710382644707 43.872 35.67253866629381 139.74707971471824 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09f460c5-c7b6-411f-af72-ed8fc6c2441e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67240344400604 139.74711979343712 49.472 35.672411544362255 139.74712821323627 49.472 35.67240172953603 139.7471423744057 49.472 35.67239362918078 139.74713395460617 49.472 35.67240344400604 139.74711979343712 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6babd25e-071b-4fa7-bf46-948ae3d36ca7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242275003744 139.74729429698564 43.872 35.672587206977425 139.74705700599165 43.872 35.67252691422857 139.7469942380661 43.872 35.672429630473914 139.74713460078365 43.872 35.67242762793318 139.74713251514027 43.872 35.67252634336999 139.7469900630828 43.872 35.6725906682542 139.74705701331334 43.872 35.67242275359722 139.74729927897204 43.872 35.67237545041461 139.747250040095 43.872 35.67237745840534 139.74724714374668 43.872 35.67242275003744 139.74729429698564 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-486f8719-b31d-423f-b7ee-c051aba5f51b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672389171991 139.74714038848293 49.472 35.67239774142301 139.7471493159192 49.472 35.67238747635879 139.74716410722013 49.472 35.67237890693577 139.74715519082994 49.472 35.672389171991 139.74714038848293 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d86026a8-35fa-45af-990d-a12bd18f3a4c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67240971783368 139.74717054554048 49.472 35.67239791909562 139.7471582744706 49.472 35.67240686949999 139.747145362492 49.472 35.67241865922563 139.74715763357105 49.472 35.67240971783368 139.74717054554048 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25fe9f0f-712a-46b8-b232-d56b8992558c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67247523440857 139.74713946746536 43.872 35.67250001341963 139.74716503568627 43.872 35.67249207157789 139.74717658786807 43.872 35.67246730158297 139.7471510196364 43.872 35.67247523440857 139.74713946746536 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a90c00a-19bc-48cc-ba67-437efe19dd1a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672423095802586 139.74721057487596 43.872 35.67241131509606 139.74719830377876 43.872 35.672428045329646 139.74717416015574 43.872 35.67243983505231 139.74718643124228 43.872 35.672423095802586 139.74721057487596 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58eeb93c-5a4e-4e51-9fa2-3ad72bef0fb8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67243983505231 139.74718643124228 43.872 35.67243983505231 139.74718643124228 45.768 35.672423095802586 139.74721057487596 45.768 35.672423095802586 139.74721057487596 43.872 35.67243983505231 139.74718643124228 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60f8af7f-68b1-44bd-b3ea-64e6bd0fdb64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672373808361485 139.7471722521602 49.472 35.67239671127128 139.7471960880682 49.472 35.672372111153564 139.74723158492125 49.472 35.67234920825069 139.7472077490104 49.472 35.672373808361485 139.7471722521602 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a3f72a3-08e3-45ea-9696-23fd90417d7a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242220205392 139.74723383985236 43.872 35.67246448808131 139.74717450762034 43.872 35.67248104095272 139.74719223058983 43.872 35.67243875491672 139.74725156282474 43.872 35.67242220205392 139.74723383985236 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54e33e0c-61af-4e04-b571-c6feab857c35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54e33e0c-61af-4e04-b571-c6feab857c35_0">
											<gml:posList>35.67258689266044 139.74700832412182 46.753 35.672580271362094 139.74700104051965 46.753 35.672580271362094 139.74700104051965 43.872 35.67258689266044 139.74700832412182 43.872 35.67258689266044 139.74700832412182 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e51de26-fe83-473d-9397-5f4d40c205e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e51de26-fe83-473d-9397-5f4d40c205e0_0">
											<gml:posList>35.672558913526835 139.7470327450537 43.872 35.6725374172564 139.747009647749 43.872 35.6725374172564 139.747009647749 47.426 35.672558913526835 139.7470327450537 47.426 35.672558913526835 139.7470327450537 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba19661c-bcc5-4372-9bb3-2567f5d7ef7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba19661c-bcc5-4372-9bb3-2567f5d7ef7e_0">
											<gml:posList>35.67250651309108 139.74705282886103 43.872 35.67250651309108 139.74705282886103 47.426 35.6725374172564 139.747009647749 47.426 35.6725374172564 139.747009647749 43.872 35.67250651309108 139.74705282886103 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1549c579-555f-4da8-825b-4b8d3bd012e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1549c579-555f-4da8-825b-4b8d3bd012e5_0">
											<gml:posList>35.67252800034754 139.74707593722465 43.872 35.672558913526835 139.7470327450537 43.872 35.672558913526835 139.7470327450537 47.426 35.67252800034754 139.74707593722465 47.426 35.67252800034754 139.74707593722465 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f2bea2b-d5ce-4340-adbb-fbd6e0f1c3fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f2bea2b-d5ce-4340-adbb-fbd6e0f1c3fa_0">
											<gml:posList>35.67249556533001 139.74705829763948 43.872 35.67248766760162 139.74706850210458 43.872 35.67248766760162 139.74706850210458 46.67 35.67249556533001 139.74705829763948 46.67 35.67249556533001 139.74705829763948 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a61c6cad-3b1a-44a2-a776-f96e91cc4dcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a61c6cad-3b1a-44a2-a776-f96e91cc4dcb_0">
											<gml:posList>35.67252691422857 139.7469942380661 43.872 35.67252691422857 139.7469942380661 48.309 35.672429630473914 139.74713460078365 48.309 35.672429630473914 139.74713460078365 43.872 35.67252691422857 139.7469942380661 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-060d7a73-52e9-424e-bd45-b327a0daffb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-060d7a73-52e9-424e-bd45-b327a0daffb8_0">
											<gml:posList>35.67250344575162 139.74708684449766 43.872 35.67251134347362 139.7470766289858 43.872 35.67251134347362 139.7470766289858 46.67 35.67250344575162 139.74708684449766 46.67 35.67250344575162 139.74708684449766 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4f4c19d-b3ea-4be5-b337-5b3cb964781a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4f4c19d-b3ea-4be5-b337-5b3cb964781a_0">
											<gml:posList>35.67253866629381 139.74707971471824 43.872 35.67252082736813 139.74710382644707 43.872 35.67252082736813 139.74710382644707 46.98 35.67253866629381 139.74707971471824 46.98 35.67253866629381 139.74707971471824 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d085c44-6a38-4a41-b453-9a80dc9e1edb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d085c44-6a38-4a41-b453-9a80dc9e1edb_0">
											<gml:posList>35.67253539613176 139.74712001607656 43.872 35.67255323506065 139.7470959043469 43.872 35.67255323506065 139.7470959043469 46.98 35.67253539613176 139.74712001607656 46.98 35.67253539613176 139.74712001607656 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49db758a-d0e5-4ad9-be2d-cf5aef39ae4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49db758a-d0e5-4ad9-be2d-cf5aef39ae4a_0">
											<gml:posList>35.67249207157789 139.74717658786807 43.872 35.67250001341963 139.74716503568627 43.872 35.67250001341963 139.74716503568627 46.055 35.67249207157789 139.74717658786807 46.055 35.67249207157789 139.74717658786807 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1f4e585-2e02-4f92-ab9e-d8be09fb4077">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1f4e585-2e02-4f92-ab9e-d8be09fb4077_0">
											<gml:posList>35.67243875491672 139.74725156282474 43.872 35.67248104095272 139.74719223058983 43.872 35.67248104095272 139.74719223058983 47.17 35.67243875491672 139.74725156282474 47.17 35.67243875491672 139.74725156282474 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77edf6a7-99d4-416b-a774-e17cf2dface0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77edf6a7-99d4-416b-a774-e17cf2dface0_0">
											<gml:posList>35.67242220205392 139.74723383985236 43.872 35.67243875491672 139.74725156282474 43.872 35.67243875491672 139.74725156282474 47.17 35.67242220205392 139.74723383985236 47.17 35.67242220205392 139.74723383985236 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90b06e5c-1660-4254-880e-7347eeaa84c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90b06e5c-1660-4254-880e-7347eeaa84c4_0">
											<gml:posList>35.67254394783936 139.7469784120972 43.872 35.67253489989121 139.7469684026159 43.872 35.67253489989121 139.7469684026159 45.25 35.67254394783936 139.7469784120972 45.25 35.67254394783936 139.7469784120972 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7580d84-e056-47ef-ba6f-92267b87059f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7580d84-e056-47ef-ba6f-92267b87059f_0">
											<gml:posList>35.67253489989121 139.7469684026159 43.872 35.67252352662128 139.74698383585914 43.872 35.67252352662128 139.74698383585914 45.25 35.67253489989121 139.7469684026159 45.25 35.67253489989121 139.7469684026159 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21809938-6b9a-4c65-b80d-dbe1829c723f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21809938-6b9a-4c65-b80d-dbe1829c723f_0">
											<gml:posList>35.67252352662128 139.74698383585914 45.25 35.672532574576095 139.74699385638735 45.25 35.67254394783936 139.7469784120972 45.25 35.67253489989121 139.7469684026159 45.25 35.67252352662128 139.74698383585914 45.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d2ea0bd-77e5-4abc-9919-c6248ca0e514">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d2ea0bd-77e5-4abc-9919-c6248ca0e514_0">
											<gml:posList>35.672532574576095 139.74699385638735 43.872 35.67254394783936 139.7469784120972 43.872 35.67254394783936 139.7469784120972 45.25 35.672532574576095 139.74699385638735 45.25 35.672532574576095 139.74699385638735 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f47b8b3b-98b6-4286-a184-3acd14782f63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f47b8b3b-98b6-4286-a184-3acd14782f63_0">
											<gml:posList>35.67259940050574 139.74699127684931 43.872 35.67259277920637 139.74698399324743 43.872 35.67259277920637 139.74698399324743 46.753 35.67259940050574 139.74699127684931 46.753 35.67259940050574 139.74699127684931 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f98ea85-e290-45d1-8c7d-1880a58898a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f98ea85-e290-45d1-8c7d-1880a58898a8_0">
											<gml:posList>35.67252352662128 139.74698383585914 43.872 35.672532574576095 139.74699385638735 43.872 35.672532574576095 139.74699385638735 45.25 35.67252352662128 139.74698383585914 45.25 35.67252352662128 139.74698383585914 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00d8fbdf-7ef8-43d3-8607-80db452cd074">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00d8fbdf-7ef8-43d3-8607-80db452cd074_0">
											<gml:posList>35.67259277920637 139.74698399324743 43.872 35.672580271362094 139.74700104051965 43.872 35.672580271362094 139.74700104051965 46.753 35.67259277920637 139.74698399324743 46.753 35.67259277920637 139.74698399324743 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3211602d-93bd-4dda-bcb6-7a6df685c11b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3211602d-93bd-4dda-bcb6-7a6df685c11b_0">
											<gml:posList>35.67259277920637 139.74698399324743 46.753 35.672580271362094 139.74700104051965 46.753 35.67258689266044 139.74700832412182 46.753 35.67259940050574 139.74699127684931 46.753 35.67259277920637 139.74698399324743 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-750d67e2-27a0-4978-bec6-a4163515e1df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-750d67e2-27a0-4978-bec6-a4163515e1df_0">
											<gml:posList>35.67258689266044 139.74700832412182 43.872 35.67259940050574 139.74699127684931 43.872 35.67259940050574 139.74699127684931 46.753 35.67258689266044 139.74700832412182 46.753 35.67258689266044 139.74700832412182 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-559c53ce-c59e-4ecf-b2f9-7f996150c67e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-559c53ce-c59e-4ecf-b2f9-7f996150c67e_0">
											<gml:posList>35.67260648049852 139.74699715704446 43.872 35.67260648049852 139.74699715704446 46.753 35.67261245232604 139.7470037675074 46.753 35.67261245232604 139.7470037675074 43.872 35.67260648049852 139.74699715704446 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57755df0-3e25-4c49-9fee-33435cad0e6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57755df0-3e25-4c49-9fee-33435cad0e6d_0">
											<gml:posList>35.67260648049852 139.74699715704446 43.872 35.67259418873622 139.74701386164136 43.872 35.67259418873622 139.74701386164136 46.753 35.67260648049852 139.74699715704446 46.753 35.67260648049852 139.74699715704446 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eb285c1-950c-496b-8f93-3b2f8dd76aeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9eb285c1-950c-496b-8f93-3b2f8dd76aeb_0">
											<gml:posList>35.67247973603949 139.7470063406592 44.4 35.67247789582273 139.74700436530844 44.4 35.67247789582273 139.74700436530844 47.783 35.67248223477264 139.74700903332672 47.783 35.67248223477264 139.74700903332672 43.872 35.67247973603949 139.7470063406592 43.872 35.67247973603949 139.7470063406592 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-558da1b4-7be2-4875-857f-ad24d326d212">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-558da1b4-7be2-4875-857f-ad24d326d212_0">
											<gml:posList>35.67248466595099 139.7470055068595 43.872 35.67248223477264 139.74700903332672 43.872 35.67248223477264 139.74700903332672 47.783 35.67248466595099 139.7470055068595 47.783 35.67248466595099 139.7470055068595 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7818037d-f593-4c6b-a5df-60758632ce45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7818037d-f593-4c6b-a5df-60758632ce45_0">
											<gml:posList>35.67260016056284 139.74702047210454 46.753 35.67261245232604 139.7470037675074 46.753 35.67260648049852 139.74699715704446 46.753 35.67259418873622 139.74701386164136 46.753 35.67260016056284 139.74702047210454 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5023110b-7467-472d-91bb-194a3dc4fda3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5023110b-7467-472d-91bb-194a3dc4fda3_0">
											<gml:posList>35.67260016056284 139.74702047210454 43.872 35.67261245232604 139.7470037675074 43.872 35.67261245232604 139.7470037675074 46.753 35.67260016056284 139.74702047210454 46.753 35.67260016056284 139.74702047210454 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57fba7bb-8a2f-41a6-a68a-da738c256489">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57fba7bb-8a2f-41a6-a68a-da738c256489_0">
											<gml:posList>35.67248466595099 139.7470055068595 43.872 35.67248466595099 139.7470055068595 47.783 35.67250170560395 139.74702325136758 47.783 35.67250170560395 139.74702325136758 43.872 35.67248466595099 139.7470055068595 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4526c8b-29fd-486f-85ef-d8daa54d33ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4526c8b-29fd-486f-85ef-d8daa54d33ab_0">
											<gml:posList>35.67247789582273 139.74700436530844 44.4 35.672462993508546 139.7470258558428 44.4 35.672462993508546 139.7470258558428 47.783 35.67247789582273 139.74700436530844 47.783 35.67247789582273 139.74700436530844 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4a64d94-fa7e-4f8a-a97d-c6e7db1bb5ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4a64d94-fa7e-4f8a-a97d-c6e7db1bb5ab_0">
											<gml:posList>35.67247973603949 139.7470063406592 44.4 35.67247973603949 139.7470063406592 43.872 35.67246484274659 139.74702784223052 43.872 35.67246484274659 139.74702784223052 44.4 35.67247973603949 139.7470063406592 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c783492-074c-4096-a01f-896746816a8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c783492-074c-4096-a01f-896746816a8f_0">
											<gml:posList>35.67260016056284 139.74702047210454 43.872 35.67260016056284 139.74702047210454 46.753 35.67259418873622 139.74701386164136 46.753 35.67259418873622 139.74701386164136 43.872 35.67260016056284 139.74702047210454 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9baad43-2afc-4d6a-b9ef-87758aab3b97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9baad43-2afc-4d6a-b9ef-87758aab3b97_0">
											<gml:posList>35.67252634336999 139.7469900630828 48.309 35.6725906682542 139.74705701331334 48.309 35.6725906682542 139.74705701331334 43.872 35.67252634336999 139.7469900630828 43.872 35.67252634336999 139.7469900630828 48.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2032320c-5d18-4c91-851f-d2de84d2670f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2032320c-5d18-4c91-851f-d2de84d2670f_0">
											<gml:posList>35.672587206977425 139.74705700599165 43.872 35.672587206977425 139.74705700599165 48.309 35.67252691422857 139.7469942380661 48.309 35.67252691422857 139.7469942380661 43.872 35.672587206977425 139.74705700599165 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff2199a1-2cf2-4400-ba98-16e9fd810559">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff2199a1-2cf2-4400-ba98-16e9fd810559_0">
											<gml:posList>35.67248223477264 139.74700903332672 47.783 35.67247789582273 139.74700436530844 47.783 35.672462993508546 139.7470258558428 47.783 35.67246716106233 139.7470303362546 47.783 35.67246518909215 139.74703317734006 47.783 35.67248240914216 139.74705109840033 47.783 35.67250170560395 139.74702325136758 47.783 35.67248466595099 139.7470055068595 47.783 35.67248223477264 139.74700903332672 47.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc409fee-f65b-4c92-b2d2-979c08308dd2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc409fee-f65b-4c92-b2d2-979c08308dd2_0">
											<gml:posList>35.67246716106233 139.7470303362546 43.872 35.67246716106233 139.7470303362546 47.783 35.672462993508546 139.7470258558428 47.783 35.672462993508546 139.7470258558428 44.4 35.67246484274659 139.74702784223052 44.4 35.67246484274659 139.74702784223052 43.872 35.67246716106233 139.7470303362546 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6d36ad7-98db-4117-b7ab-15103e932cc5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6d36ad7-98db-4117-b7ab-15103e932cc5_0">
											<gml:posList>35.67246716106233 139.7470303362546 43.872 35.67246518909215 139.74703317734006 43.872 35.67246518909215 139.74703317734006 47.783 35.67246716106233 139.7470303362546 47.783 35.67246716106233 139.7470303362546 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-782692c7-d1ee-4f2a-a58e-b16d01939af0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-782692c7-d1ee-4f2a-a58e-b16d01939af0_0">
											<gml:posList>35.67245786999805 139.74703325149795 44.4 35.67244976602483 139.74704494746626 44.4 35.67244976602483 139.74704494746626 45.07 35.67245786999805 139.74703325149795 45.07 35.67245786999805 139.74703325149795 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-686c7091-a670-4932-ac95-263c10639ccd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-686c7091-a670-4932-ac95-263c10639ccd_0">
											<gml:posList>35.67245163325835 139.74704688964857 43.872 35.67245163325835 139.74704688964857 44.4 35.67245973723966 139.7470352047267 44.4 35.67245973723966 139.7470352047267 43.872 35.67245163325835 139.74704688964857 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48128485-f319-4896-8162-4cf7c0f8b8cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48128485-f319-4896-8162-4cf7c0f8b8cf_0">
											<gml:posList>35.67246518909215 139.74703317734006 43.872 35.67248240914216 139.74705109840033 43.872 35.67248240914216 139.74705109840033 47.783 35.67246518909215 139.74703317734006 47.783 35.67246518909215 139.74703317734006 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df63399e-93d9-4705-994e-d2fb1e55a8b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df63399e-93d9-4705-994e-d2fb1e55a8b3_0">
											<gml:posList>35.67252800034754 139.74707593722465 47.426 35.672558913526835 139.7470327450537 47.426 35.6725374172564 139.747009647749 47.426 35.67250651309108 139.74705282886103 47.426 35.67252800034754 139.74707593722465 47.426</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a52f612-86c9-4916-bca1-d7a2d33f4916">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a52f612-86c9-4916-bca1-d7a2d33f4916_0">
											<gml:posList>35.67245973723966 139.7470352047267 44.4 35.67245786999805 139.74703325149795 44.4 35.67245786999805 139.74703325149795 45.07 35.672476858162206 139.74705315903256 45.07 35.672476858162206 139.74705315903256 43.872 35.67245973723966 139.7470352047267 43.872 35.67245973723966 139.7470352047267 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a091630-fbb1-4655-a989-d8df69a4b912">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a091630-fbb1-4655-a989-d8df69a4b912_0">
											<gml:posList>35.672468754187086 139.74706485500164 45.07 35.672476858162206 139.74705315903256 45.07 35.67245786999805 139.74703325149795 45.07 35.67244976602483 139.74704494746626 45.07 35.672468754187086 139.74706485500164 45.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05852582-3841-4235-8ac5-666ecf7bcd05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05852582-3841-4235-8ac5-666ecf7bcd05_0">
											<gml:posList>35.672468754187086 139.74706485500164 43.872 35.672468754187086 139.74706485500164 45.07 35.67244976602483 139.74704494746626 45.07 35.67244976602483 139.74704494746626 44.4 35.67245163325835 139.74704688964857 44.4 35.67245163325835 139.74704688964857 43.872 35.672468754187086 139.74706485500164 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70c9f4f9-f7b5-4352-a53e-605325bdb314">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70c9f4f9-f7b5-4352-a53e-605325bdb314_0">
											<gml:posList>35.67252634336999 139.7469900630828 48.309 35.67252634336999 139.7469900630828 43.872 35.67242762793318 139.74713251514027 43.872 35.67242762793318 139.74713251514027 48.309 35.67252634336999 139.7469900630828 48.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b735d8c-6a38-4cc9-beb5-acad1d8558f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b735d8c-6a38-4cc9-beb5-acad1d8558f6_0">
											<gml:posList>35.67252800034754 139.74707593722465 43.872 35.67252800034754 139.74707593722465 47.426 35.67250651309108 139.74705282886103 47.426 35.67250651309108 139.74705282886103 43.872 35.67252800034754 139.74707593722465 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08c7575b-3af2-4838-a061-0225ff26e193">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08c7575b-3af2-4838-a061-0225ff26e193_0">
											<gml:posList>35.67251134347362 139.7470766289858 43.872 35.67249556533001 139.74705829763948 43.872 35.67249556533001 139.74705829763948 46.67 35.67251134347362 139.7470766289858 46.67 35.67251134347362 139.7470766289858 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ee997ec-6670-48e4-b97f-4be9b1dcaab0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ee997ec-6670-48e4-b97f-4be9b1dcaab0_0">
											<gml:posList>35.67250344575162 139.74708684449766 46.67 35.67251134347362 139.7470766289858 46.67 35.67249556533001 139.74705829763948 46.67 35.67248766760162 139.74706850210458 46.67 35.67250344575162 139.74708684449766 46.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87f9d214-42e4-4337-a5ef-9cb666e05a71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87f9d214-42e4-4337-a5ef-9cb666e05a71_0">
											<gml:posList>35.67248766760162 139.74706850210458 43.872 35.67250344575162 139.74708684449766 43.872 35.67250344575162 139.74708684449766 46.67 35.67248766760162 139.74706850210458 46.67 35.67248766760162 139.74706850210458 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c52c030b-faf9-453e-b7a3-c91670167472">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c52c030b-faf9-453e-b7a3-c91670167472_0">
											<gml:posList>35.67255323506065 139.7470959043469 43.872 35.67253866629381 139.74707971471824 43.872 35.67253866629381 139.74707971471824 46.98 35.67255323506065 139.7470959043469 46.98 35.67255323506065 139.7470959043469 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-856f21bc-7c7b-444c-86c2-15d8b66d44f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-856f21bc-7c7b-444c-86c2-15d8b66d44f6_0">
											<gml:posList>35.67253539613176 139.74712001607656 46.98 35.67255323506065 139.7470959043469 46.98 35.67253866629381 139.74707971471824 46.98 35.67252082736813 139.74710382644707 46.98 35.67253539613176 139.74712001607656 46.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0262491a-f102-48c2-8d36-d41358820cdc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0262491a-f102-48c2-8d36-d41358820cdc_0">
											<gml:posList>35.67252082736813 139.74710382644707 43.872 35.67253539613176 139.74712001607656 43.872 35.67253539613176 139.74712001607656 46.98 35.67252082736813 139.74710382644707 46.98 35.67252082736813 139.74710382644707 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f7d7133-5917-421f-aab8-d9ffaf54c90f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f7d7133-5917-421f-aab8-d9ffaf54c90f_0">
											<gml:posList>35.672411544362255 139.74712821323627 49.472 35.67240344400604 139.74711979343712 49.472 35.67240344400604 139.74711979343712 50.293 35.672411544362255 139.74712821323627 50.293 35.672411544362255 139.74712821323627 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcda1f13-6102-4531-89c0-125fc05d3c9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcda1f13-6102-4531-89c0-125fc05d3c9e_0">
											<gml:posList>35.67240344400604 139.74711979343712 49.472 35.67239362918078 139.74713395460617 49.472 35.67239362918078 139.74713395460617 50.293 35.67240344400604 139.74711979343712 50.293 35.67240344400604 139.74711979343712 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ac5e2fe-9302-4ce9-9806-4a49151d3f17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ac5e2fe-9302-4ce9-9806-4a49151d3f17_0">
											<gml:posList>35.67240172953603 139.7471423744057 50.293 35.672411544362255 139.74712821323627 50.293 35.67240344400604 139.74711979343712 50.293 35.67239362918078 139.74713395460617 50.293 35.67240172953603 139.7471423744057 50.293</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6acc89fe-fe8e-4361-af14-588beb6bd870">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6acc89fe-fe8e-4361-af14-588beb6bd870_0">
											<gml:posList>35.672429630473914 139.74713460078365 48.309 35.67242762793318 139.74713251514027 48.309 35.67242762793318 139.74713251514027 43.872 35.672429630473914 139.74713460078365 43.872 35.672429630473914 139.74713460078365 48.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68d9e472-98d3-48fd-81f6-45a8c6053e3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68d9e472-98d3-48fd-81f6-45a8c6053e3f_0">
											<gml:posList>35.67240172953603 139.7471423744057 49.472 35.672411544362255 139.74712821323627 49.472 35.672411544362255 139.74712821323627 50.293 35.67240172953603 139.7471423744057 50.293 35.67240172953603 139.7471423744057 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d078bc92-592a-4c5b-bbd9-2c574d796bbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d078bc92-592a-4c5b-bbd9-2c574d796bbf_0">
											<gml:posList>35.67239362918078 139.74713395460617 49.472 35.67240172953603 139.7471423744057 49.472 35.67240172953603 139.7471423744057 50.293 35.67239362918078 139.74713395460617 50.293 35.67239362918078 139.74713395460617 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c312e4d-a5ad-4749-a3ee-8f21a53c7577">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c312e4d-a5ad-4749-a3ee-8f21a53c7577_0">
											<gml:posList>35.67237545041461 139.747250040095 48.309 35.67242275359722 139.74729927897204 48.309 35.6725906682542 139.74705701331334 48.309 35.67252634336999 139.7469900630828 48.309 35.67242762793318 139.74713251514027 48.309 35.672429630473914 139.74713460078365 48.309 35.67252691422857 139.7469942380661 48.309 35.672587206977425 139.74705700599165 48.309 35.67242275003744 139.74729429698564 48.309 35.67237745840534 139.74724714374668 48.309 35.67237545041461 139.747250040095 48.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efca555e-19f1-4cd6-8be6-db61ec1aef2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efca555e-19f1-4cd6-8be6-db61ec1aef2f_0">
											<gml:posList>35.67239774142301 139.7471493159192 49.472 35.672389171991 139.74714038848293 49.472 35.672389171991 139.74714038848293 50.394 35.67239774142301 139.7471493159192 50.394 35.67239774142301 139.7471493159192 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c186679c-5cc2-4e0d-bdf6-172c1f62f1db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c186679c-5cc2-4e0d-bdf6-172c1f62f1db_0">
											<gml:posList>35.67247523440857 139.74713946746536 43.872 35.67246730158297 139.7471510196364 43.872 35.67246730158297 139.7471510196364 46.055 35.67247523440857 139.74713946746536 46.055 35.67247523440857 139.74713946746536 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78bd1bf9-59d8-4cd7-a608-36b6ca24969a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78bd1bf9-59d8-4cd7-a608-36b6ca24969a_0">
											<gml:posList>35.672389171991 139.74714038848293 49.472 35.67237890693577 139.74715519082994 49.472 35.67237890693577 139.74715519082994 50.394 35.672389171991 139.74714038848293 50.394 35.672389171991 139.74714038848293 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f833e768-a4ab-4ee0-bd85-b5eed0ecdb99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f833e768-a4ab-4ee0-bd85-b5eed0ecdb99_0">
											<gml:posList>35.67241865922563 139.74715763357105 49.472 35.67240686949999 139.747145362492 49.472 35.67240686949999 139.747145362492 50.293 35.67241865922563 139.74715763357105 50.293 35.67241865922563 139.74715763357105 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-589a82a4-c893-4cb6-9e11-72db1805dc6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-589a82a4-c893-4cb6-9e11-72db1805dc6c_0">
											<gml:posList>35.67240686949999 139.747145362492 49.472 35.67239791909562 139.7471582744706 49.472 35.67239791909562 139.7471582744706 50.293 35.67240686949999 139.747145362492 50.293 35.67240686949999 139.747145362492 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f280c50b-a26e-45dc-b6d4-608294009f99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f280c50b-a26e-45dc-b6d4-608294009f99_0">
											<gml:posList>35.67238747635879 139.74716410722013 50.394 35.67239774142301 139.7471493159192 50.394 35.672389171991 139.74714038848293 50.394 35.67237890693577 139.74715519082994 50.394 35.67238747635879 139.74716410722013 50.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4685ed5-e484-4c74-a83b-1314d38c245e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4685ed5-e484-4c74-a83b-1314d38c245e_0">
											<gml:posList>35.67250001341963 139.74716503568627 43.872 35.67247523440857 139.74713946746536 43.872 35.67247523440857 139.74713946746536 46.055 35.67250001341963 139.74716503568627 46.055 35.67250001341963 139.74716503568627 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5681265f-102c-4ea8-b495-8e4d54744364">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5681265f-102c-4ea8-b495-8e4d54744364_0">
											<gml:posList>35.67238747635879 139.74716410722013 49.472 35.67239774142301 139.7471493159192 49.472 35.67239774142301 139.7471493159192 50.394 35.67238747635879 139.74716410722013 50.394 35.67238747635879 139.74716410722013 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c77437bf-2af3-4a6e-8675-e6b952de5ba0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c77437bf-2af3-4a6e-8675-e6b952de5ba0_0">
											<gml:posList>35.67240971783368 139.74717054554048 50.293 35.67241865922563 139.74715763357105 50.293 35.67240686949999 139.747145362492 50.293 35.67239791909562 139.7471582744706 50.293 35.67240971783368 139.74717054554048 50.293</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36946926-bb68-4b8c-a438-7fb7f1adea1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36946926-bb68-4b8c-a438-7fb7f1adea1c_0">
											<gml:posList>35.67249207157789 139.74717658786807 46.055 35.67250001341963 139.74716503568627 46.055 35.67247523440857 139.74713946746536 46.055 35.67246730158297 139.7471510196364 46.055 35.67249207157789 139.74717658786807 46.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0da2bcd-40a4-40ee-97ae-baa7a58b2883">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0da2bcd-40a4-40ee-97ae-baa7a58b2883_0">
											<gml:posList>35.67237890693577 139.74715519082994 49.472 35.67238747635879 139.74716410722013 49.472 35.67238747635879 139.74716410722013 50.394 35.67237890693577 139.74715519082994 50.394 35.67237890693577 139.74715519082994 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2616c352-3228-48f9-a1a9-31e3707bb4cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2616c352-3228-48f9-a1a9-31e3707bb4cc_0">
											<gml:posList>35.67246730158297 139.7471510196364 43.872 35.67249207157789 139.74717658786807 43.872 35.67249207157789 139.74717658786807 46.055 35.67246730158297 139.7471510196364 46.055 35.67246730158297 139.7471510196364 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26cc52ee-6a6b-4333-8603-86d48e423097">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26cc52ee-6a6b-4333-8603-86d48e423097_0">
											<gml:posList>35.67241865922563 139.74715763357105 49.472 35.67241865922563 139.74715763357105 50.293 35.67240971783368 139.74717054554048 50.293 35.67240971783368 139.74717054554048 49.472 35.67241865922563 139.74715763357105 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1eb5edf8-29ad-4538-a07e-b052c7261486">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1eb5edf8-29ad-4538-a07e-b052c7261486_0">
											<gml:posList>35.67239791909562 139.7471582744706 49.472 35.67240971783368 139.74717054554048 49.472 35.67240971783368 139.74717054554048 50.293 35.67239791909562 139.7471582744706 50.293 35.67239791909562 139.7471582744706 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b5cafb0-173b-4635-b48d-c92abf452dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b5cafb0-173b-4635-b48d-c92abf452dc2_0">
											<gml:posList>35.67242275003744 139.74729429698564 43.872 35.67242275003744 139.74729429698564 48.309 35.672587206977425 139.74705700599165 48.309 35.672587206977425 139.74705700599165 43.872 35.67242275003744 139.74729429698564 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b43a90d-e325-4e24-b71e-0984624b523b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b43a90d-e325-4e24-b71e-0984624b523b_0">
											<gml:posList>35.67242275359722 139.74729927897204 43.872 35.6725906682542 139.74705701331334 43.872 35.6725906682542 139.74705701331334 48.309 35.67242275359722 139.74729927897204 48.309 35.67242275359722 139.74729927897204 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c80e0cd-df7e-407d-92ca-667e9d968ae6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c80e0cd-df7e-407d-92ca-667e9d968ae6_0">
											<gml:posList>35.672428045329646 139.74717416015574 45.768 35.67243983505231 139.74718643124228 45.768 35.67243983505231 139.74718643124228 43.872 35.672428045329646 139.74717416015574 43.872 35.672428045329646 139.74717416015574 45.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe341d16-4641-4137-9e04-dd8884d9eca4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe341d16-4641-4137-9e04-dd8884d9eca4_0">
											<gml:posList>35.67248104095272 139.74719223058983 43.872 35.67246448808131 139.74717450762034 43.872 35.67246448808131 139.74717450762034 47.17 35.67248104095272 139.74719223058983 47.17 35.67248104095272 139.74719223058983 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-190ce444-c9cd-4151-ac45-7035d1d6426f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-190ce444-c9cd-4151-ac45-7035d1d6426f_0">
											<gml:posList>35.672373808361485 139.7471722521602 49.472 35.672373808361485 139.7471722521602 51.182 35.67239671127128 139.7471960880682 51.182 35.67239671127128 139.7471960880682 49.472 35.672373808361485 139.7471722521602 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-673bdb23-3d1b-4a35-98a6-a6bcf82476a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-673bdb23-3d1b-4a35-98a6-a6bcf82476a8_0">
											<gml:posList>35.67241131509606 139.74719830377876 45.768 35.672428045329646 139.74717416015574 45.768 35.672428045329646 139.74717416015574 43.872 35.67241131509606 139.74719830377876 43.872 35.67241131509606 139.74719830377876 45.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9663cabb-d4a0-4052-a321-34fafe7a79e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9663cabb-d4a0-4052-a321-34fafe7a79e2_0">
											<gml:posList>35.67234920825069 139.7472077490104 49.472 35.67234920825069 139.7472077490104 51.182 35.672373808361485 139.7471722521602 51.182 35.672373808361485 139.7471722521602 49.472 35.67234920825069 139.7472077490104 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf3f2246-a66d-42e6-a848-f4722b284737">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf3f2246-a66d-42e6-a848-f4722b284737_0">
											<gml:posList>35.672428045329646 139.74717416015574 45.768 35.67241131509606 139.74719830377876 45.768 35.672423095802586 139.74721057487596 45.768 35.67243983505231 139.74718643124228 45.768 35.672428045329646 139.74717416015574 45.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f809ba81-8974-4f7b-a3a2-599cb15708da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f809ba81-8974-4f7b-a3a2-599cb15708da_0">
											<gml:posList>35.672372111153564 139.74723158492125 51.182 35.67239671127128 139.7471960880682 51.182 35.672373808361485 139.7471722521602 51.182 35.67234920825069 139.7472077490104 51.182 35.672372111153564 139.74723158492125 51.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2c41d60-73e0-45fe-bae1-1de423c5e377">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2c41d60-73e0-45fe-bae1-1de423c5e377_0">
											<gml:posList>35.67242220205392 139.74723383985236 43.872 35.67242220205392 139.74723383985236 47.17 35.67246448808131 139.74717450762034 47.17 35.67246448808131 139.74717450762034 43.872 35.67242220205392 139.74723383985236 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b4cf4e7-a963-4eb2-bb1d-ef7c9ba74050">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b4cf4e7-a963-4eb2-bb1d-ef7c9ba74050_0">
											<gml:posList>35.67241131509606 139.74719830377876 45.768 35.67241131509606 139.74719830377876 43.872 35.672423095802586 139.74721057487596 43.872 35.672423095802586 139.74721057487596 45.768 35.67241131509606 139.74719830377876 45.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88101e07-2526-4a96-bb56-f1137c1c6d03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88101e07-2526-4a96-bb56-f1137c1c6d03_0">
											<gml:posList>35.67248104095272 139.74719223058983 47.17 35.67246448808131 139.74717450762034 47.17 35.67242220205392 139.74723383985236 47.17 35.67243875491672 139.74725156282474 47.17 35.67248104095272 139.74719223058983 47.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-594137e8-0d7d-464e-856d-37d902e623db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-594137e8-0d7d-464e-856d-37d902e623db_0">
											<gml:posList>35.67239671127128 139.7471960880682 49.472 35.67239671127128 139.7471960880682 51.182 35.672372111153564 139.74723158492125 51.182 35.672372111153564 139.74723158492125 49.472 35.67239671127128 139.7471960880682 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15b5b9ce-b55b-4427-8582-c47e2aa6b89c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15b5b9ce-b55b-4427-8582-c47e2aa6b89c_0">
											<gml:posList>35.67234920825069 139.7472077490104 49.472 35.672372111153564 139.74723158492125 49.472 35.672372111153564 139.74723158492125 51.182 35.67234920825069 139.7472077490104 51.182 35.67234920825069 139.7472077490104 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4517823-7081-4d31-b15a-d137973d8087">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4517823-7081-4d31-b15a-d137973d8087_0">
											<gml:posList>35.67237545041461 139.747250040095 43.872 35.67237545041461 139.747250040095 48.309 35.67237745840534 139.74724714374668 48.309 35.67237745840534 139.74724714374668 43.872 35.67237545041461 139.747250040095 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b9f9976-57f0-4a88-b9a0-310609507347">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b9f9976-57f0-4a88-b9a0-310609507347_0">
											<gml:posList>35.67237745840534 139.74724714374668 43.872 35.67237745840534 139.74724714374668 48.309 35.67242275003744 139.74729429698564 48.309 35.67242275003744 139.74729429698564 43.872 35.67237745840534 139.74724714374668 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27e7d7a2-da3c-4257-97bc-9f430fd1fe19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27e7d7a2-da3c-4257-97bc-9f430fd1fe19_0">
											<gml:posList>35.67237545041461 139.747250040095 43.872 35.67242275359722 139.74729927897204 43.872 35.67242275359722 139.74729927897204 48.309 35.67237545041461 139.747250040095 48.309 35.67237545041461 139.747250040095 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-37a2e6ed-4a1b-4e43-9736-bbf16d9fb1c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37a2e6ed-4a1b-4e43-9736-bbf16d9fb1c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37a2e6ed-4a1b-4e43-9736-bbf16d9fb1c6">
											<gml:posList>35.67265030149029 139.7470296420106 11.45 35.67241015295022 139.74737576768914 11.45 35.67229956234266 139.74726056054442 11.45 35.67257446727702 139.74686391474413 11.45 35.672644736656146 139.7469369672613 11.45 35.67265030149029 139.7470296420106 11.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72cf46cc-ccd9-41f4-8abb-bf0dfb4522be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72cf46cc-ccd9-41f4-8abb-bf0dfb4522be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72cf46cc-ccd9-41f4-8abb-bf0dfb4522be">
											<gml:posList>35.672335953372496 139.74721378360826 44.4 35.67233559810024 139.74720855898144 44.4 35.67229956234266 139.74726056054442 44.4 35.67230384355241 139.7472601251336 44.4 35.672335953372496 139.74721378360826 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec7a156e-0352-4e8b-be01-12e8686286a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec7a156e-0352-4e8b-be01-12e8686286a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec7a156e-0352-4e8b-be01-12e8686286a8">
											<gml:posList>35.67233790733535 139.7472109646442 44.4 35.67233559810024 139.74720855898144 44.4 35.672335953372496 139.74721378360826 44.4 35.67233790733535 139.7472109646442 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8ad0477-20ff-4847-b8cc-ed4a9dee1e93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8ad0477-20ff-4847-b8cc-ed4a9dee1e93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8ad0477-20ff-4847-b8cc-ed4a9dee1e93">
											<gml:posList>35.67230384355241 139.7472601251336 44.4 35.67229956234266 139.74726056054442 44.4 35.67241015295022 139.74737576768914 44.4 35.67240981569665 139.74737052094434 44.4 35.67230384355241 139.7472601251336 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e97effab-2549-4729-83db-11d0ef554f93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e97effab-2549-4729-83db-11d0ef554f93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e97effab-2549-4729-83db-11d0ef554f93">
											<gml:posList>35.67233928445157 139.74720819048585 50.974 35.67233559810024 139.74720855898144 50.974 35.67237545041461 139.747250040095 50.974 35.672375149731714 139.74724552238504 50.974 35.67233928445157 139.74720819048585 50.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fd1434a2-d868-44c0-8c56-52b743bf2497">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd1434a2-d868-44c0-8c56-52b743bf2497">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd1434a2-d868-44c0-8c56-52b743bf2497">
											<gml:posList>35.67240508884247 139.74711326316373 50.974 35.67240478814653 139.74710873440608 50.974 35.67233559810024 139.74720855898144 50.974 35.67233928445157 139.74720819048585 50.974 35.67240508884247 139.74711326316373 50.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea920f77-a698-4f55-a26b-d1c2c580dea7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea920f77-a698-4f55-a26b-d1c2c580dea7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea920f77-a698-4f55-a26b-d1c2c580dea7">
											<gml:posList>35.67233928445157 139.74720819048585 49.472 35.672375149731714 139.74724552238504 49.472 35.67244095415955 139.74715060609748 49.472 35.67240508884247 139.74711326316373 49.472 35.67233928445157 139.74720819048585 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-074525f1-f4bd-4fb7-b24d-e14358d3ae33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-074525f1-f4bd-4fb7-b24d-e14358d3ae33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-074525f1-f4bd-4fb7-b24d-e14358d3ae33">
											<gml:posList>35.672409069363546 139.74710831003313 44.4 35.67240478814653 139.74710873440608 44.4 35.67240710640523 139.74711115110492 44.4 35.672409069363546 139.74710831003313 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0778506e-2653-448c-8f1d-35a866fc73bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0778506e-2653-448c-8f1d-35a866fc73bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0778506e-2653-448c-8f1d-35a866fc73bd">
											<gml:posList>35.672375149731714 139.74724552238504 50.974 35.67237545041461 139.747250040095 50.974 35.672444640502725 139.7471502265522 50.974 35.67244095415955 139.74715060609748 50.974 35.672375149731714 139.74724552238504 50.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-050e684e-b1d1-40d7-ba76-fec1077558b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-050e684e-b1d1-40d7-ba76-fec1077558b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-050e684e-b1d1-40d7-ba76-fec1077558b6">
											<gml:posList>35.67244095415955 139.74715060609748 50.974 35.672444640502725 139.7471502265522 50.974 35.67240478814653 139.74710873440608 50.974 35.67240508884247 139.74711326316373 50.974 35.67244095415955 139.74715060609748 50.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4711526b-3f2d-4159-961c-407f270e4291">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4711526b-3f2d-4159-961c-407f270e4291">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4711526b-3f2d-4159-961c-407f270e4291">
											<gml:posList>35.67240981569665 139.74737052094434 43.872 35.67264719085398 139.74702838604995 43.872 35.67264180849672 139.7469387820546 43.872 35.672574822564236 139.74686913938496 43.872 35.672409069363546 139.74710831003313 43.872 35.67240710640523 139.74711115110492 43.872 35.672444640502725 139.7471502265522 43.872 35.67237545041461 139.747250040095 43.872 35.67233790733535 139.7472109646442 43.872 35.672335953372496 139.74721378360826 43.872 35.67230384355241 139.7472601251336 43.872 35.67240981569665 139.74737052094434 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7424ad38-d09e-457e-849f-639dd45538e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7424ad38-d09e-457e-849f-639dd45538e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7424ad38-d09e-457e-849f-639dd45538e0">
											<gml:posList>35.672574822564236 139.74686913938496 44.4 35.67257446727702 139.74686391474413 44.4 35.67240478814653 139.74710873440608 44.4 35.672409069363546 139.74710831003313 44.4 35.672574822564236 139.74686913938496 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-86bd9382-b8b7-4407-a857-97cfa7632524">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86bd9382-b8b7-4407-a857-97cfa7632524">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86bd9382-b8b7-4407-a857-97cfa7632524">
											<gml:posList>35.67240981569665 139.74737052094434 44.4 35.67241015295022 139.74737576768914 44.4 35.67265030149029 139.7470296420106 44.4 35.67264719085398 139.74702838604995 44.4 35.67240981569665 139.74737052094434 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25da28de-4742-4989-b326-4eef5ff1dfe5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25da28de-4742-4989-b326-4eef5ff1dfe5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25da28de-4742-4989-b326-4eef5ff1dfe5">
											<gml:posList>35.67264719085398 139.74702838604995 44.4 35.67265030149029 139.7470296420106 44.4 35.672644736656146 139.7469369672613 44.4 35.67264180849672 139.7469387820546 44.4 35.67264719085398 139.74702838604995 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a2bb02a-a809-4648-bde6-05d7b24537e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a2bb02a-a809-4648-bde6-05d7b24537e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a2bb02a-a809-4648-bde6-05d7b24537e3">
											<gml:posList>35.672574822564236 139.74686913938496 44.4 35.67264180849672 139.7469387820546 44.4 35.672644736656146 139.7469369672613 44.4 35.67257446727702 139.74686391474413 44.4 35.672574822564236 139.74686913938496 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f7f93d3-c21d-4e55-9af6-65181b50c387">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f7f93d3-c21d-4e55-9af6-65181b50c387">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f7f93d3-c21d-4e55-9af6-65181b50c387">
											<gml:posList>35.672409069363546 139.74710831003313 43.872 35.672409069363546 139.74710831003313 44.4 35.67240710640523 139.74711115110492 44.4 35.67240710640523 139.74711115110492 43.872 35.672409069363546 139.74710831003313 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a91ce662-0a7b-424f-babe-ed3a8c81aced">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a91ce662-0a7b-424f-babe-ed3a8c81aced">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a91ce662-0a7b-424f-babe-ed3a8c81aced">
											<gml:posList>35.67240508884247 139.74711326316373 49.472 35.67240508884247 139.74711326316373 50.974 35.67233928445157 139.74720819048585 50.974 35.67233928445157 139.74720819048585 49.472 35.67240508884247 139.74711326316373 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-858d7c77-a4f5-4c4e-9d4e-369a9984339d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-858d7c77-a4f5-4c4e-9d4e-369a9984339d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-858d7c77-a4f5-4c4e-9d4e-369a9984339d">
											<gml:posList>35.672375149731714 139.74724552238504 49.472 35.672375149731714 139.74724552238504 50.974 35.67244095415955 139.74715060609748 50.974 35.67244095415955 139.74715060609748 49.472 35.672375149731714 139.74724552238504 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2435d4a-e0a6-4595-b604-9becaf7e6914">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2435d4a-e0a6-4595-b604-9becaf7e6914">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2435d4a-e0a6-4595-b604-9becaf7e6914">
											<gml:posList>35.67240981569665 139.74737052094434 43.872 35.67240981569665 139.74737052094434 44.4 35.67264719085398 139.74702838604995 44.4 35.67264719085398 139.74702838604995 43.872 35.67240981569665 139.74737052094434 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0ad6bb4-18a7-4a9b-9290-51947899c47f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0ad6bb4-18a7-4a9b-9290-51947899c47f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0ad6bb4-18a7-4a9b-9290-51947899c47f">
											<gml:posList>35.67257446727702 139.74686391474413 44.4 35.672644736656146 139.7469369672613 44.4 35.672644736656146 139.7469369672613 11.45 35.67257446727702 139.74686391474413 11.45 35.67257446727702 139.74686391474413 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c18d1ab6-fd43-4094-9c82-57dfe68edda9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c18d1ab6-fd43-4094-9c82-57dfe68edda9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c18d1ab6-fd43-4094-9c82-57dfe68edda9">
											<gml:posList>35.67264180849672 139.7469387820546 43.872 35.67264180849672 139.7469387820546 44.4 35.672574822564236 139.74686913938496 44.4 35.672574822564236 139.74686913938496 43.872 35.67264180849672 139.7469387820546 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09d747fa-799a-496b-9e1a-63feeab5e2fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09d747fa-799a-496b-9e1a-63feeab5e2fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09d747fa-799a-496b-9e1a-63feeab5e2fd">
											<gml:posList>35.672644736656146 139.7469369672613 44.4 35.67265030149029 139.7470296420106 44.4 35.67265030149029 139.7470296420106 11.45 35.672644736656146 139.7469369672613 11.45 35.672644736656146 139.7469369672613 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8a6c842-71cf-4654-888d-f36877d3b267">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8a6c842-71cf-4654-888d-f36877d3b267">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8a6c842-71cf-4654-888d-f36877d3b267">
											<gml:posList>35.67264719085398 139.74702838604995 43.872 35.67264719085398 139.74702838604995 44.4 35.67264180849672 139.7469387820546 44.4 35.67264180849672 139.7469387820546 43.872 35.67264719085398 139.74702838604995 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64a21da6-1f24-4c16-9999-3c31d8479e6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64a21da6-1f24-4c16-9999-3c31d8479e6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64a21da6-1f24-4c16-9999-3c31d8479e6b">
											<gml:posList>35.672574822564236 139.74686913938496 43.872 35.672574822564236 139.74686913938496 44.4 35.672409069363546 139.74710831003313 44.4 35.672409069363546 139.74710831003313 43.872 35.672574822564236 139.74686913938496 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51a80922-1392-4819-a709-16093fb4276a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51a80922-1392-4819-a709-16093fb4276a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51a80922-1392-4819-a709-16093fb4276a">
											<gml:posList>35.67233559810024 139.74720855898144 44.4 35.67233559810024 139.74720855898144 50.974 35.67240478814653 139.74710873440608 50.974 35.67240478814653 139.74710873440608 44.4 35.67257446727702 139.74686391474413 44.4 35.67257446727702 139.74686391474413 11.45 35.67229956234266 139.74726056054442 11.45 35.67229956234266 139.74726056054442 44.4 35.67233559810024 139.74720855898144 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d5c859c-5a3b-4c27-94c2-ffb51e693146">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d5c859c-5a3b-4c27-94c2-ffb51e693146">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d5c859c-5a3b-4c27-94c2-ffb51e693146">
											<gml:posList>35.672444640502725 139.7471502265522 50.974 35.672444640502725 139.7471502265522 43.872 35.67240710640523 139.74711115110492 43.872 35.67240710640523 139.74711115110492 44.4 35.67240478814653 139.74710873440608 44.4 35.67240478814653 139.74710873440608 50.974 35.672444640502725 139.7471502265522 50.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b05c3c9b-dac9-47c4-bc12-b582e55a3c34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b05c3c9b-dac9-47c4-bc12-b582e55a3c34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b05c3c9b-dac9-47c4-bc12-b582e55a3c34">
											<gml:posList>35.67244095415955 139.74715060609748 49.472 35.67244095415955 139.74715060609748 50.974 35.67240508884247 139.74711326316373 50.974 35.67240508884247 139.74711326316373 49.472 35.67244095415955 139.74715060609748 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f2f27e6-d36f-4093-bd05-18e6fa754ca0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f2f27e6-d36f-4093-bd05-18e6fa754ca0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f2f27e6-d36f-4093-bd05-18e6fa754ca0">
											<gml:posList>35.672444640502725 139.7471502265522 50.974 35.67237545041461 139.747250040095 50.974 35.67237545041461 139.747250040095 43.872 35.672444640502725 139.7471502265522 43.872 35.672444640502725 139.7471502265522 50.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e236bf8-4d1f-478f-b9e3-e06a44ff4c03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e236bf8-4d1f-478f-b9e3-e06a44ff4c03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e236bf8-4d1f-478f-b9e3-e06a44ff4c03">
											<gml:posList>35.67265030149029 139.7470296420106 44.4 35.67241015295022 139.74737576768914 44.4 35.67241015295022 139.74737576768914 11.45 35.67265030149029 139.7470296420106 11.45 35.67265030149029 139.7470296420106 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58aa7908-6919-4b69-b036-3d8079d7691a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58aa7908-6919-4b69-b036-3d8079d7691a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58aa7908-6919-4b69-b036-3d8079d7691a">
											<gml:posList>35.67233790733535 139.7472109646442 43.872 35.67233790733535 139.7472109646442 44.4 35.672335953372496 139.74721378360826 44.4 35.672335953372496 139.74721378360826 43.872 35.67233790733535 139.7472109646442 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20c85836-67d6-4522-9bd5-388740621d61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20c85836-67d6-4522-9bd5-388740621d61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20c85836-67d6-4522-9bd5-388740621d61">
											<gml:posList>35.67233928445157 139.74720819048585 49.472 35.67233928445157 139.74720819048585 50.974 35.672375149731714 139.74724552238504 50.974 35.672375149731714 139.74724552238504 49.472 35.67233928445157 139.74720819048585 49.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-697bde9e-096c-41af-b74e-bea8bea54fce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-697bde9e-096c-41af-b74e-bea8bea54fce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-697bde9e-096c-41af-b74e-bea8bea54fce">
											<gml:posList>35.67233790733535 139.7472109646442 44.4 35.67233790733535 139.7472109646442 43.872 35.67237545041461 139.747250040095 43.872 35.67237545041461 139.747250040095 50.974 35.67233559810024 139.74720855898144 50.974 35.67233559810024 139.74720855898144 44.4 35.67233790733535 139.7472109646442 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b159c232-cc19-41d2-bda7-08fde2c88449">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b159c232-cc19-41d2-bda7-08fde2c88449">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b159c232-cc19-41d2-bda7-08fde2c88449">
											<gml:posList>35.672335953372496 139.74721378360826 43.872 35.672335953372496 139.74721378360826 44.4 35.67230384355241 139.7472601251336 44.4 35.67230384355241 139.7472601251336 43.872 35.672335953372496 139.74721378360826 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79802162-1de7-4dc9-8393-ab2ecaafff3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79802162-1de7-4dc9-8393-ab2ecaafff3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79802162-1de7-4dc9-8393-ab2ecaafff3d">
											<gml:posList>35.67230384355241 139.7472601251336 43.872 35.67230384355241 139.7472601251336 44.4 35.67240981569665 139.74737052094434 44.4 35.67240981569665 139.74737052094434 43.872 35.67230384355241 139.7472601251336 43.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-162b23a8-13c1-461e-a8e4-bb81e0582f93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-162b23a8-13c1-461e-a8e4-bb81e0582f93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-162b23a8-13c1-461e-a8e4-bb81e0582f93">
											<gml:posList>35.67241015295022 139.74737576768914 44.4 35.67229956234266 139.74726056054442 44.4 35.67229956234266 139.74726056054442 11.45 35.67241015295022 139.74737576768914 11.45 35.67241015295022 139.74737576768914 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区霞が関三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-2083</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">739.9907</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.93</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>