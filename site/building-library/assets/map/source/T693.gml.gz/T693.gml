<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c8da615a-a61f-4ae0-b713-eb44694b0ce2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101008003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671713904385335 139.745463601504 0 35.67174318148656 139.7454395986249 0 35.67174865113924 139.74544964489667 0 35.67176590213627 139.74543554176182 0 35.67178123850005 139.74546573699675 0 35.67178367559044 139.74547037383616 0 35.6718186280316 139.74544183566934 0 35.67168035201277 139.74518780869397 0 35.6715719137024 139.74518350934457 0 35.67161009299655 139.74525350172928 0 35.6716027962449 139.7452594748169 0 35.671713904385335 139.745463601504 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671713904385335 139.745463601504 7.49 35.6716027962449 139.7452594748169 7.49 35.67161009299655 139.74525350172928 7.49 35.6715719137024 139.74518350934457 7.49 35.67168035201277 139.74518780869397 7.49 35.6718186280316 139.74544183566934 7.49 35.67178367559044 139.74547037383616 7.49 35.67178123850005 139.74546573699675 7.49 35.67176590213627 139.74543554176182 7.49 35.67174865113924 139.74544964489667 7.49 35.67174318148656 139.7454395986249 7.49 35.671713904385335 139.745463601504 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671713904385335 139.745463601504 7.49 35.67174318148656 139.7454395986249 7.49 35.67174318148656 139.7454395986249 22.07 35.671713904385335 139.745463601504 22.07 35.671713904385335 139.745463601504 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67174318148656 139.7454395986249 7.49 35.67174865113924 139.74544964489667 7.49 35.67174865113924 139.74544964489667 22.07 35.67174318148656 139.7454395986249 22.07 35.67174318148656 139.7454395986249 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67174865113924 139.74544964489667 7.49 35.67176590213627 139.74543554176182 7.49 35.67176590213627 139.74543554176182 22.07 35.67174865113924 139.74544964489667 22.07 35.67174865113924 139.74544964489667 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176590213627 139.74543554176182 7.49 35.67178123850005 139.74546573699675 7.49 35.67178123850005 139.74546573699675 22.07 35.67176590213627 139.74543554176182 22.07 35.67176590213627 139.74543554176182 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178123850005 139.74546573699675 7.49 35.67178367559044 139.74547037383616 7.49 35.67178367559044 139.74547037383616 22.07 35.67178123850005 139.74546573699675 22.07 35.67178123850005 139.74546573699675 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178367559044 139.74547037383616 7.49 35.6718186280316 139.74544183566934 7.49 35.6718186280316 139.74544183566934 22.07 35.67178367559044 139.74547037383616 22.07 35.67178367559044 139.74547037383616 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6718186280316 139.74544183566934 7.49 35.67168035201277 139.74518780869397 7.49 35.67168035201277 139.74518780869397 22.07 35.6718186280316 139.74544183566934 22.07 35.6718186280316 139.74544183566934 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67168035201277 139.74518780869397 7.49 35.6715719137024 139.74518350934457 7.49 35.6715719137024 139.74518350934457 22.07 35.67168035201277 139.74518780869397 22.07 35.67168035201277 139.74518780869397 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715719137024 139.74518350934457 7.49 35.67161009299655 139.74525350172928 7.49 35.67161009299655 139.74525350172928 22.07 35.6715719137024 139.74518350934457 22.07 35.6715719137024 139.74518350934457 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67161009299655 139.74525350172928 7.49 35.6716027962449 139.7452594748169 7.49 35.6716027962449 139.7452594748169 22.07 35.67161009299655 139.74525350172928 22.07 35.67161009299655 139.74525350172928 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6716027962449 139.7452594748169 7.49 35.671713904385335 139.745463601504 7.49 35.671713904385335 139.745463601504 22.07 35.6716027962449 139.7452594748169 22.07 35.6716027962449 139.7452594748169 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671713904385335 139.745463601504 22.07 35.67174318148656 139.7454395986249 22.07 35.67174865113924 139.74544964489667 22.07 35.67176590213627 139.74543554176182 22.07 35.67178123850005 139.74546573699675 22.07 35.67178367559044 139.74547037383616 22.07 35.6718186280316 139.74544183566934 22.07 35.67168035201277 139.74518780869397 22.07 35.6715719137024 139.74518350934457 22.07 35.67161009299655 139.74525350172928 22.07 35.6716027962449 139.7452594748169 22.07 35.671713904385335 139.745463601504 22.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e302723c-6d56-445d-895a-c6cfe5293e0e"/>
							<gml:surfaceMember xlink:href="#poly-f33f6351-7ac4-4e6a-9a58-756e1df45f67"/>
							<gml:surfaceMember xlink:href="#poly-b5d41bc0-b663-4b31-a2db-59c18b6bb065"/>
							<gml:surfaceMember xlink:href="#poly-0feae9ef-b323-4232-9ff8-d2055c0cdbd4"/>
							<gml:surfaceMember xlink:href="#poly-12673067-7a6a-4e9d-a384-069355f5aec5"/>
							<gml:surfaceMember xlink:href="#poly-849cb878-2a16-4076-9701-8fa915eaf118"/>
							<gml:surfaceMember xlink:href="#poly-27d3f4ed-bf8a-4434-8b09-b4c872342aa5"/>
							<gml:surfaceMember xlink:href="#poly-71704e03-745f-4964-a7fc-214a74b886ad"/>
							<gml:surfaceMember xlink:href="#poly-8db2a07d-0f77-4b1a-ad9f-f61517b96a3f"/>
							<gml:surfaceMember xlink:href="#poly-96558aed-6423-4d3c-a850-dd2aafaa1da8"/>
							<gml:surfaceMember xlink:href="#poly-60adbeef-4210-40dc-8e52-68eb9f5ed471"/>
							<gml:surfaceMember xlink:href="#poly-7d2cefe9-f193-4259-8191-2f002c993085"/>
							<gml:surfaceMember xlink:href="#poly-63409d44-fea4-45a6-aa4a-dfae0b7f1351"/>
							<gml:surfaceMember xlink:href="#poly-58fd55a4-c1e5-4dd1-894e-9b3433a810e8"/>
							<gml:surfaceMember xlink:href="#poly-08d0f225-df12-4e7d-a25c-4c4259b42f97"/>
							<gml:surfaceMember xlink:href="#poly-59f84fa6-2b04-419e-a5aa-f37b2ec6e545"/>
							<gml:surfaceMember xlink:href="#poly-70b04728-667c-4484-8862-923fba34183f"/>
							<gml:surfaceMember xlink:href="#poly-807481de-9e01-4cc5-bd77-5687cdb8ee85"/>
							<gml:surfaceMember xlink:href="#poly-3591b704-9be5-4c90-9b17-34bbf0e50ef9"/>
							<gml:surfaceMember xlink:href="#poly-caf9f7e7-81ae-453c-8290-cbf7012eba20"/>
							<gml:surfaceMember xlink:href="#poly-913404c4-3061-423e-a644-502e9eb9735e"/>
							<gml:surfaceMember xlink:href="#poly-7fa8665e-ced5-4eeb-bab6-d72f928a6f83"/>
							<gml:surfaceMember xlink:href="#poly-fb390c82-795b-460d-b7b3-58d2461a77e3"/>
							<gml:surfaceMember xlink:href="#poly-074df4dd-8d33-4be0-878f-c85562b6dd0d"/>
							<gml:surfaceMember xlink:href="#poly-fcc01fe9-263f-4c88-ba64-f80cb87ed831"/>
							<gml:surfaceMember xlink:href="#poly-6a98dcfc-e4b1-4b73-a25c-969a50ab11e1"/>
							<gml:surfaceMember xlink:href="#poly-f4cbbe17-35fd-4e42-91c4-82704eedc593"/>
							<gml:surfaceMember xlink:href="#poly-f058b7af-7bbb-430b-a06a-89a4c455984f"/>
							<gml:surfaceMember xlink:href="#poly-8d5926af-8f6e-428e-8a17-4a832eab0956"/>
							<gml:surfaceMember xlink:href="#poly-d7c86354-cd54-4d12-87f3-48a56cf99ff6"/>
							<gml:surfaceMember xlink:href="#poly-3abfac9e-29c3-4b74-92b8-130db3d59360"/>
							<gml:surfaceMember xlink:href="#poly-b00d77aa-7465-4e4f-9094-3fac1b9a057f"/>
							<gml:surfaceMember xlink:href="#poly-b819e40a-e869-412f-9353-51065728004a"/>
							<gml:surfaceMember xlink:href="#poly-905ee95a-f18b-4d18-bfe3-769c4b50f3de"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c8da615a-a61f-4ae0-b713-eb44694b0ce2_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed34d56f-b00d-4b8a-8c5a-1dc71c000ee1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176938738231 139.7454313402893 21.324 35.67177444105617 139.74542719232892 21.324 35.671786472425886 139.7454492057658 21.324 35.67180074162254 139.7454374919277 21.324 35.67175733659922 139.74535807135462 21.324 35.671760732738484 139.74535528392258 21.324 35.671733158906825 139.74530480982799 21.324 35.67172924929343 139.74530801758993 21.324 35.67167222424095 139.74520369136118 21.324 35.67162335032042 139.74520166835592 21.324 35.67161162149608 139.74521130268906 21.324 35.67163461023154 139.7452533532836 21.324 35.67162006179668 139.7452652994119 21.324 35.671717829208816 139.74544417755348 21.324 35.671738079936034 139.74542755254402 21.324 35.6717415458421 139.74543390045116 21.324 35.67173972615889 139.74543539371658 21.324 35.67173746970445 139.74543125377284 21.324 35.67171753427158 139.7454476243674 21.324 35.67161707716398 139.74526381142232 21.324 35.67163138237365 139.74525206439722 21.324 35.67160835752627 139.74520993651942 21.324 35.67162214025013 139.74519862087115 21.324 35.67167385371144 139.74520093900693 21.324 35.671730409439 139.74530442622122 21.324 35.67173398574649 139.7453014949862 21.324 35.67176387016743 139.74535617524222 21.324 35.67176066320332 139.74535880781647 21.324 35.67180409529957 139.74543827254934 21.324 35.67178587144924 139.74545323838012 21.324 35.671773840088335 139.7454312359893 21.324 35.671770660147615 139.74543384643832 21.324 35.67176938738231 139.7454313402893 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d837f480-b70f-4eb8-909c-9ea1d6d52b4d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67174172987417 139.74543904789394 22.3 35.67173972615889 139.74543539371658 22.3 35.6717415458421 139.74543390045116 22.3 35.67174354955743 139.74543755462858 22.3 35.67174172987417 139.74543904789394 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2923a6d6-a1f9-41a4-a181-a1ce22432fad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671765911149954 139.74543554175193 22.3 35.67176539669045 139.7454346144141 22.3 35.67176938738231 139.7454313402893 22.3 35.671770660147615 139.74543384643832 22.3 35.67176669648072 139.74543709844053 22.3 35.671765911149954 139.74543554175193 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a282dcd7-c57e-4d2a-971c-ad9c5a00c338">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a282dcd7-c57e-4d2a-971c-ad9c5a00c338_0">
											<gml:posList>35.67177444105617 139.74542719232892 23.196 35.671786472425886 139.7454492057658 23.196 35.671786472425886 139.7454492057658 21.324 35.67177444105617 139.74542719232892 21.324 35.67177444105617 139.74542719232892 23.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4aa10cf7-6eea-4da0-98a7-ea0b260b16d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4aa10cf7-6eea-4da0-98a7-ea0b260b16d2_0">
											<gml:posList>35.67162214025013 139.74519862087115 23.196 35.67167385371144 139.74520093900693 23.196 35.67167385371144 139.74520093900693 21.324 35.67162214025013 139.74519862087115 21.324 35.67162214025013 139.74519862087115 23.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89717568-a4b6-4886-ae5e-d49c858293dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89717568-a4b6-4886-ae5e-d49c858293dd_0">
											<gml:posList>35.67167222424095 139.74520369136118 23.196 35.67162335032042 139.74520166835592 23.196 35.67162335032042 139.74520166835592 21.324 35.67167222424095 139.74520369136118 21.324 35.67167222424095 139.74520369136118 23.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d93d5001-31eb-4ec5-b299-0147ccb49352">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d93d5001-31eb-4ec5-b299-0147ccb49352_0">
											<gml:posList>35.67160835752627 139.74520993651942 21.324 35.67160835752627 139.74520993651942 23.196 35.67162214025013 139.74519862087115 23.196 35.67162214025013 139.74519862087115 21.324 35.67160835752627 139.74520993651942 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b4e9657-ffce-4c87-a94f-bbc731c10694">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b4e9657-ffce-4c87-a94f-bbc731c10694_0">
											<gml:posList>35.67162335032042 139.74520166835592 23.196 35.67161162149608 139.74521130268906 23.196 35.67161162149608 139.74521130268906 21.324 35.67162335032042 139.74520166835592 21.324 35.67162335032042 139.74520166835592 23.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48841e60-e10e-49f2-9e43-6550b6a14e79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48841e60-e10e-49f2-9e43-6550b6a14e79_0">
											<gml:posList>35.67163138237365 139.74525206439722 21.324 35.67163138237365 139.74525206439722 23.196 35.67160835752627 139.74520993651942 23.196 35.67160835752627 139.74520993651942 21.324 35.67163138237365 139.74525206439722 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c290c470-7c5c-42df-bccc-4d251cdc9967">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c290c470-7c5c-42df-bccc-4d251cdc9967_0">
											<gml:posList>35.67161162149608 139.74521130268906 21.324 35.67161162149608 139.74521130268906 23.196 35.67163461023154 139.7452533532836 23.196 35.67163461023154 139.7452533532836 21.324 35.67161162149608 139.74521130268906 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33488314-d546-4723-bfc1-93aab9e4dc07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33488314-d546-4723-bfc1-93aab9e4dc07_0">
											<gml:posList>35.67167385371144 139.74520093900693 21.324 35.67167385371144 139.74520093900693 23.196 35.671730409439 139.74530442622122 23.196 35.671730409439 139.74530442622122 21.324 35.67167385371144 139.74520093900693 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67268b7c-1e11-4e97-b8f3-16a3c53ef7b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67268b7c-1e11-4e97-b8f3-16a3c53ef7b6_0">
											<gml:posList>35.67172924929343 139.74530801758993 21.324 35.67172924929343 139.74530801758993 23.196 35.67167222424095 139.74520369136118 23.196 35.67167222424095 139.74520369136118 21.324 35.67172924929343 139.74530801758993 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9fde0ad-0ad3-4e14-8635-644eafa1f889">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9fde0ad-0ad3-4e14-8635-644eafa1f889_0">
											<gml:posList>35.67161707716398 139.74526381142232 21.324 35.67161707716398 139.74526381142232 23.196 35.67163138237365 139.74525206439722 23.196 35.67163138237365 139.74525206439722 21.324 35.67161707716398 139.74526381142232 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-649a5dd0-d28f-4d32-9974-3cdc42b6caf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-649a5dd0-d28f-4d32-9974-3cdc42b6caf4_0">
											<gml:posList>35.67163461023154 139.7452533532836 21.324 35.67163461023154 139.7452533532836 23.196 35.67162006179668 139.7452652994119 23.196 35.67162006179668 139.7452652994119 21.324 35.67163461023154 139.7452533532836 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b921903e-cab9-43fd-8732-9e8113289166">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b921903e-cab9-43fd-8732-9e8113289166_0">
											<gml:posList>35.671730409439 139.74530442622122 21.324 35.671730409439 139.74530442622122 23.196 35.67173398574649 139.7453014949862 23.196 35.67173398574649 139.7453014949862 21.324 35.671730409439 139.74530442622122 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba7a1a43-db05-4e61-8058-f1b5aaf850c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba7a1a43-db05-4e61-8058-f1b5aaf850c0_0">
											<gml:posList>35.671733158906825 139.74530480982799 21.324 35.671733158906825 139.74530480982799 23.196 35.67172924929343 139.74530801758993 23.196 35.67172924929343 139.74530801758993 21.324 35.671733158906825 139.74530480982799 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47b707a0-e7fa-4e45-aa47-0397421416ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47b707a0-e7fa-4e45-aa47-0397421416ca_0">
											<gml:posList>35.671738079936034 139.74542755254402 23.196 35.671717829208816 139.74544417755348 23.196 35.67162006179668 139.7452652994119 23.196 35.67163461023154 139.7452533532836 23.196 35.67161162149608 139.74521130268906 23.196 35.67162335032042 139.74520166835592 23.196 35.67167222424095 139.74520369136118 23.196 35.67172924929343 139.74530801758993 23.196 35.671733158906825 139.74530480982799 23.196 35.671760732738484 139.74535528392258 23.196 35.67175733659922 139.74535807135462 23.196 35.67180074162254 139.7454374919277 23.196 35.671786472425886 139.7454492057658 23.196 35.67177444105617 139.74542719232892 23.196 35.67176539669045 139.7454346144141 23.196 35.671765911149954 139.74543554175193 23.196 35.67176669648072 139.74543709844053 23.196 35.671773840088335 139.7454312359893 23.196 35.67178587144924 139.74545323838012 23.196 35.67180409529957 139.74543827254934 23.196 35.67176066320332 139.74535880781647 23.196 35.67176387016743 139.74535617524222 23.196 35.67173398574649 139.7453014949862 23.196 35.671730409439 139.74530442622122 23.196 35.67167385371144 139.74520093900693 23.196 35.67162214025013 139.74519862087115 23.196 35.67160835752627 139.74520993651942 23.196 35.67163138237365 139.74525206439722 23.196 35.67161707716398 139.74526381142232 23.196 35.67171753427158 139.7454476243674 23.196 35.67173746970445 139.74543125377284 23.196 35.67174172987417 139.74543904789394 23.196 35.67174354955743 139.74543755462858 23.196 35.671738079936034 139.74542755254402 23.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ca8b386-f09e-48be-ae57-4af20e86e9f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ca8b386-f09e-48be-ae57-4af20e86e9f0_0">
											<gml:posList>35.67173398574649 139.7453014949862 21.324 35.67173398574649 139.7453014949862 23.196 35.67176387016743 139.74535617524222 23.196 35.67176387016743 139.74535617524222 21.324 35.67173398574649 139.7453014949862 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e6fc68a-9b4a-4895-8281-82c78ada955a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e6fc68a-9b4a-4895-8281-82c78ada955a_0">
											<gml:posList>35.671760732738484 139.74535528392258 21.324 35.671760732738484 139.74535528392258 23.196 35.671733158906825 139.74530480982799 23.196 35.671733158906825 139.74530480982799 21.324 35.671760732738484 139.74535528392258 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-378e33ff-b005-4c6a-986d-5adf11c6cc94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-378e33ff-b005-4c6a-986d-5adf11c6cc94_0">
											<gml:posList>35.67162006179668 139.7452652994119 21.324 35.67162006179668 139.7452652994119 23.196 35.671717829208816 139.74544417755348 23.196 35.671717829208816 139.74544417755348 21.324 35.67162006179668 139.7452652994119 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b86858cb-a5cd-4f2b-89e9-05747b778d53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b86858cb-a5cd-4f2b-89e9-05747b778d53_0">
											<gml:posList>35.67171753427158 139.7454476243674 21.324 35.67171753427158 139.7454476243674 23.196 35.67161707716398 139.74526381142232 23.196 35.67161707716398 139.74526381142232 21.324 35.67171753427158 139.7454476243674 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb981834-2c6f-4043-a06b-273685506846">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb981834-2c6f-4043-a06b-273685506846_0">
											<gml:posList>35.67175733659922 139.74535807135462 21.324 35.67175733659922 139.74535807135462 23.196 35.671760732738484 139.74535528392258 23.196 35.671760732738484 139.74535528392258 21.324 35.67175733659922 139.74535807135462 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce8670ff-8fd2-4701-ad88-226b44cfbd49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce8670ff-8fd2-4701-ad88-226b44cfbd49_0">
											<gml:posList>35.67176387016743 139.74535617524222 21.324 35.67176387016743 139.74535617524222 23.196 35.67176066320332 139.74535880781647 23.196 35.67176066320332 139.74535880781647 21.324 35.67176387016743 139.74535617524222 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2487d137-6bab-46f6-b7d1-e4d799884ae6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2487d137-6bab-46f6-b7d1-e4d799884ae6_0">
											<gml:posList>35.67180074162254 139.7454374919277 21.324 35.67180074162254 139.7454374919277 23.196 35.67175733659922 139.74535807135462 23.196 35.67175733659922 139.74535807135462 21.324 35.67180074162254 139.7454374919277 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b00c59a-3c0a-4c65-9cef-691e6a6bb528">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b00c59a-3c0a-4c65-9cef-691e6a6bb528_0">
											<gml:posList>35.67176066320332 139.74535880781647 21.324 35.67176066320332 139.74535880781647 23.196 35.67180409529957 139.74543827254934 23.196 35.67180409529957 139.74543827254934 21.324 35.67176066320332 139.74535880781647 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-277f9d39-58ba-4704-a5f4-2d0510a2150e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-277f9d39-58ba-4704-a5f4-2d0510a2150e_0">
											<gml:posList>35.67176539669045 139.7454346144141 23.196 35.67177444105617 139.74542719232892 23.196 35.67177444105617 139.74542719232892 21.324 35.67176938738231 139.7454313402893 21.324 35.67176938738231 139.7454313402893 22.3 35.67176539669045 139.7454346144141 22.3 35.67176539669045 139.7454346144141 23.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae85b376-de39-4670-8bc4-2a485c7640d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae85b376-de39-4670-8bc4-2a485c7640d9_0">
											<gml:posList>35.671738079936034 139.74542755254402 21.324 35.671738079936034 139.74542755254402 23.196 35.67174354955743 139.74543755462858 23.196 35.67174354955743 139.74543755462858 22.3 35.6717415458421 139.74543390045116 22.3 35.6717415458421 139.74543390045116 21.324 35.671738079936034 139.74542755254402 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c38b84cf-6aa5-4955-a19a-ea23022c5ade">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c38b84cf-6aa5-4955-a19a-ea23022c5ade_0">
											<gml:posList>35.671770660147615 139.74543384643832 22.3 35.67176938738231 139.7454313402893 22.3 35.67176938738231 139.7454313402893 21.324 35.671770660147615 139.74543384643832 21.324 35.671770660147615 139.74543384643832 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ceafdb3-9926-4a5d-ae93-a93db5ca5ae2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ceafdb3-9926-4a5d-ae93-a93db5ca5ae2_0">
											<gml:posList>35.671770660147615 139.74543384643832 22.3 35.671770660147615 139.74543384643832 21.324 35.671773840088335 139.7454312359893 21.324 35.671773840088335 139.7454312359893 23.196 35.67176669648072 139.74543709844053 23.196 35.67176669648072 139.74543709844053 22.3 35.671770660147615 139.74543384643832 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-632ca506-b0e0-43b9-b5d7-6fde5ccb8a1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-632ca506-b0e0-43b9-b5d7-6fde5ccb8a1e_0">
											<gml:posList>35.67173972615889 139.74543539371658 21.324 35.6717415458421 139.74543390045116 21.324 35.6717415458421 139.74543390045116 22.3 35.67173972615889 139.74543539371658 22.3 35.67173972615889 139.74543539371658 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d32dd30-2430-4bfb-a2c1-752e6822f473">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d32dd30-2430-4bfb-a2c1-752e6822f473_0">
											<gml:posList>35.671765911149954 139.74543554175193 23.196 35.67176539669045 139.7454346144141 23.196 35.67176539669045 139.7454346144141 22.3 35.671765911149954 139.74543554175193 22.3 35.671765911149954 139.74543554175193 23.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6322807-4dc1-4799-9979-feaa4a526428">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6322807-4dc1-4799-9979-feaa4a526428_0">
											<gml:posList>35.67174172987417 139.74543904789394 23.196 35.67173746970445 139.74543125377284 23.196 35.67173746970445 139.74543125377284 21.324 35.67173972615889 139.74543539371658 21.324 35.67173972615889 139.74543539371658 22.3 35.67174172987417 139.74543904789394 22.3 35.67174172987417 139.74543904789394 23.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24c11905-7336-4e25-aa8d-c7774b4b24ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24c11905-7336-4e25-aa8d-c7774b4b24ee_0">
											<gml:posList>35.671717829208816 139.74544417755348 21.324 35.671717829208816 139.74544417755348 23.196 35.671738079936034 139.74542755254402 23.196 35.671738079936034 139.74542755254402 21.324 35.671717829208816 139.74544417755348 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-725ea742-6ec4-4455-84eb-b0d95fec28c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-725ea742-6ec4-4455-84eb-b0d95fec28c6_0">
											<gml:posList>35.67176669648072 139.74543709844053 22.3 35.67176669648072 139.74543709844053 23.196 35.671765911149954 139.74543554175193 23.196 35.671765911149954 139.74543554175193 22.3 35.67176669648072 139.74543709844053 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eeb97bfd-d119-4b20-b7cc-0ab1b2932117">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eeb97bfd-d119-4b20-b7cc-0ab1b2932117_0">
											<gml:posList>35.67174172987417 139.74543904789394 23.196 35.67174172987417 139.74543904789394 22.3 35.67174354955743 139.74543755462858 22.3 35.67174354955743 139.74543755462858 23.196 35.67174172987417 139.74543904789394 23.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eddc60f-c812-40de-95ae-416f4abeb915">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9eddc60f-c812-40de-95ae-416f4abeb915_0">
											<gml:posList>35.67173746970445 139.74543125377284 21.324 35.67173746970445 139.74543125377284 23.196 35.67171753427158 139.7454476243674 23.196 35.67171753427158 139.7454476243674 21.324 35.67173746970445 139.74543125377284 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77012913-2216-408e-ae17-2403292477cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77012913-2216-408e-ae17-2403292477cd_0">
											<gml:posList>35.67178587144924 139.74545323838012 21.324 35.67178587144924 139.74545323838012 23.196 35.671773840088335 139.7454312359893 23.196 35.671773840088335 139.7454312359893 21.324 35.67178587144924 139.74545323838012 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12d734a1-9fc0-49ec-83f1-73fd5b95a073">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12d734a1-9fc0-49ec-83f1-73fd5b95a073_0">
											<gml:posList>35.671786472425886 139.7454492057658 21.324 35.671786472425886 139.7454492057658 23.196 35.67180074162254 139.7454374919277 23.196 35.67180074162254 139.7454374919277 21.324 35.671786472425886 139.7454492057658 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83990c29-fc59-4d36-99a2-42752d3ef128">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83990c29-fc59-4d36-99a2-42752d3ef128_0">
											<gml:posList>35.67180409529957 139.74543827254934 21.324 35.67180409529957 139.74543827254934 23.196 35.67178587144924 139.74545323838012 23.196 35.67178587144924 139.74545323838012 21.324 35.67180409529957 139.74543827254934 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c8da615a-a61f-4ae0-b713-eb44694b0ce2_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aae45568-25cf-43ff-8f80-91eeab3a99b2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671708320316654 139.74534625021457 21.324 35.67173997635498 139.74532133887416 21.324 35.67175233338429 139.745344920524 21.324 35.67172067734114 139.74536983185897 21.324 35.671708320316654 139.74534625021457 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a500fd3-a725-4589-a1f5-74686b139edd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a500fd3-a725-4589-a1f5-74686b139edd_0">
											<gml:posList>35.67172067734114 139.74536983185897 21.324 35.67172067734114 139.74536983185897 24.717 35.671708320316654 139.74534625021457 24.717 35.671708320316654 139.74534625021457 21.324 35.67172067734114 139.74536983185897 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9db19550-10a9-4b3c-ada3-7a684b4171f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9db19550-10a9-4b3c-ada3-7a684b4171f6_0">
											<gml:posList>35.671708320316654 139.74534625021457 21.324 35.671708320316654 139.74534625021457 24.717 35.67173997635498 139.74532133887416 24.717 35.67173997635498 139.74532133887416 21.324 35.671708320316654 139.74534625021457 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebeec2f8-e358-4727-af6a-2530dac5c7b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebeec2f8-e358-4727-af6a-2530dac5c7b1_0">
											<gml:posList>35.67175233338429 139.745344920524 24.717 35.67173997635498 139.74532133887416 24.717 35.671708320316654 139.74534625021457 24.717 35.67172067734114 139.74536983185897 24.717 35.67175233338429 139.745344920524 24.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63249853-4293-4804-bf8e-8bc2fb58e8ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63249853-4293-4804-bf8e-8bc2fb58e8ae_0">
											<gml:posList>35.67175233338429 139.745344920524 21.324 35.67175233338429 139.745344920524 24.717 35.67172067734114 139.74536983185897 24.717 35.67172067734114 139.74536983185897 21.324 35.67175233338429 139.745344920524 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3667253-ccc3-4aa8-8a15-5c23ca8d2bf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3667253-ccc3-4aa8-8a15-5c23ca8d2bf4_0">
											<gml:posList>35.67173997635498 139.74532133887416 24.717 35.67175233338429 139.745344920524 24.717 35.67175233338429 139.745344920524 21.324 35.67173997635498 139.74532133887416 21.324 35.67173997635498 139.74532133887416 24.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c8da615a-a61f-4ae0-b713-eb44694b0ce2_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5283804a-4d64-4722-93f9-c5859397e243">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6717259643157 139.74531490313205 21.324 35.671718649549895 139.7453208983354 21.324 35.67167200415087 139.74523550534425 21.324 35.67167931891249 139.74522951013665 21.324 35.6717259643157 139.74531490313205 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ee54c5f-ed45-420a-93c8-1492235047af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ee54c5f-ed45-420a-93c8-1492235047af_0">
											<gml:posList>35.67167200415087 139.74523550534425 21.324 35.67167200415087 139.74523550534425 24.12 35.67167931891249 139.74522951013665 24.12 35.67167931891249 139.74522951013665 21.324 35.67167200415087 139.74523550534425 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e77c2c2a-21f8-4a65-8857-31f9e5fc35df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e77c2c2a-21f8-4a65-8857-31f9e5fc35df_0">
											<gml:posList>35.67167931891249 139.74522951013665 21.324 35.67167931891249 139.74522951013665 24.12 35.6717259643157 139.74531490313205 24.12 35.6717259643157 139.74531490313205 21.324 35.67167931891249 139.74522951013665 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac148684-968b-4ce1-88d7-c5157c448d8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac148684-968b-4ce1-88d7-c5157c448d8a_0">
											<gml:posList>35.67167200415087 139.74523550534425 24.12 35.671718649549895 139.7453208983354 24.12 35.6717259643157 139.74531490313205 24.12 35.67167931891249 139.74522951013665 24.12 35.67167200415087 139.74523550534425 24.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee2c3713-4c4c-490a-9c35-9d900a78ec2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee2c3713-4c4c-490a-9c35-9d900a78ec2f_0">
											<gml:posList>35.671718649549895 139.7453208983354 21.324 35.671718649549895 139.7453208983354 24.12 35.67167200415087 139.74523550534425 24.12 35.67167200415087 139.74523550534425 21.324 35.671718649549895 139.7453208983354 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1b2ccc4-e968-40a8-8292-67cfbec5246b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1b2ccc4-e968-40a8-8292-67cfbec5246b_0">
											<gml:posList>35.6717259643157 139.74531490313205 21.324 35.6717259643157 139.74531490313205 24.12 35.671718649549895 139.7453208983354 24.12 35.671718649549895 139.7453208983354 21.324 35.6717259643157 139.74531490313205 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c8da615a-a61f-4ae0-b713-eb44694b0ce2_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-529636a3-9bca-438f-a80d-bc165164d07a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67174865113921 139.74544964489667 7.49 35.67176590213624 139.74543554176182 7.49 35.67178123850004 139.74546573699672 7.49 35.671764753222604 139.74547923173392 7.49 35.67174865113921 139.74544964489667 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0b288b0-ff4b-45b4-8f55-8159d131d7a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0b288b0-ff4b-45b4-8f55-8159d131d7a1_0">
											<gml:posList>35.67176590213624 139.74543554176182 22.3 35.67176590213624 139.74543554176182 7.49 35.67174865113921 139.74544964489667 7.49 35.67174865113921 139.74544964489667 22.3 35.67176590213624 139.74543554176182 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-396827dc-a3f6-4c88-830a-ae50d328f014">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-396827dc-a3f6-4c88-830a-ae50d328f014_0">
											<gml:posList>35.67176815881628 139.74543999100754 22.3 35.67175941135432 139.74544666160662 22.3 35.67175941135432 139.74544666160662 19.245 35.67176815881628 139.74543999100754 19.245 35.67176815881628 139.74543999100754 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78686039-5b84-49dc-a43f-f5cf3a2583b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78686039-5b84-49dc-a43f-f5cf3a2583b4_0">
											<gml:posList>35.67176815881628 139.74543999100754 22.3 35.67176590213624 139.74543554176182 22.3 35.67174865113921 139.74544964489667 22.3 35.67175066389198 139.74545333220425 22.3 35.67175941135432 139.74544666160662 22.3 35.67176815881628 139.74543999100754 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fc09d50-fc49-441f-abde-0ff0a9cdbaa2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fc09d50-fc49-441f-abde-0ff0a9cdbaa2_0">
											<gml:posList>35.67176815881628 139.74543999100754 22.3 35.67176815881628 139.74543999100754 19.245 35.671779126250094 139.74546157479904 20.567 35.67178123850004 139.74546573699672 20.567 35.67178123850004 139.74546573699672 7.49 35.67176590213624 139.74543554176182 7.49 35.67176590213624 139.74543554176182 22.3 35.67176815881628 139.74543999100754 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e23a4f0-fca8-438b-8643-0cc608c1c5fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e23a4f0-fca8-438b-8643-0cc608c1c5fa_0">
											<gml:posList>35.67177037879501 139.7454682564431 20.567 35.671779126250094 139.74546157479904 20.567 35.67176815881628 139.74543999100754 19.245 35.67175941135432 139.74544666160662 19.245 35.67177037879501 139.7454682564431 20.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03fc2760-efb7-4df0-8de0-ab06db55b9f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03fc2760-efb7-4df0-8de0-ab06db55b9f4_0">
											<gml:posList>35.67175941135432 139.74544666160662 22.3 35.67177037879501 139.7454682564431 20.567 35.67175941135432 139.74544666160662 19.245 35.67175941135432 139.74544666160662 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06d53edd-c801-4c3c-8102-5437d8f6fb20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06d53edd-c801-4c3c-8102-5437d8f6fb20_0">
											<gml:posList>35.67175941135432 139.74544666160662 22.3 35.67175066389198 139.74545333220425 22.3 35.67176218086224 139.74547450667197 20.567 35.67177037879501 139.7454682564431 20.567 35.67175941135432 139.74544666160662 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad08f44c-3be1-42b6-9a8c-99a73502f46b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad08f44c-3be1-42b6-9a8c-99a73502f46b_0">
											<gml:posList>35.67174865113921 139.74544964489667 22.3 35.67174865113921 139.74544964489667 7.49 35.671764753222604 139.74547923173392 7.49 35.671764753222604 139.74547923173392 20.567 35.67176218086224 139.74547450667197 20.567 35.67175066389198 139.74545333220425 22.3 35.67174865113921 139.74544964489667 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4fdd616-5e49-425b-8aa5-b71c3c86cf0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4fdd616-5e49-425b-8aa5-b71c3c86cf0b_0">
											<gml:posList>35.67176218086224 139.74547450667197 20.567 35.671764753222604 139.74547923173392 20.567 35.67178123850004 139.74546573699672 20.567 35.671779126250094 139.74546157479904 20.567 35.67177037879501 139.7454682564431 20.567 35.67176218086224 139.74547450667197 20.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1395e503-0093-4298-b95b-9f5f1f231ce1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1395e503-0093-4298-b95b-9f5f1f231ce1_0">
											<gml:posList>35.671764753222604 139.74547923173392 20.567 35.671764753222604 139.74547923173392 7.49 35.67178123850004 139.74546573699672 7.49 35.67178123850004 139.74546573699672 20.567 35.671764753222604 139.74547923173392 20.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e302723c-6d56-445d-895a-c6cfe5293e0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e302723c-6d56-445d-895a-c6cfe5293e0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e302723c-6d56-445d-895a-c6cfe5293e0e">
											<gml:posList>35.67174318148656 139.7454395986249 7.49 35.671713904385314 139.745463601504 7.49 35.67160279624488 139.7452594748169 7.49 35.67161009299651 139.74525350172928 7.49 35.671571913702415 139.74518350934454 7.49 35.67168035201276 139.74518780869397 7.49 35.67181862803159 139.74544183566937 7.49 35.67178367559043 139.74547037383616 7.49 35.67178123850004 139.74546573699672 7.49 35.67176590213624 139.74543554176182 7.49 35.67174865113921 139.74544964489667 7.49 35.67174318148656 139.7454395986249 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f33f6351-7ac4-4e6a-9a58-756e1df45f67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f33f6351-7ac4-4e6a-9a58-756e1df45f67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f33f6351-7ac4-4e6a-9a58-756e1df45f67">
											<gml:posList>35.67168035201276 139.74518780869397 22.3 35.671571913702415 139.74518350934454 22.3 35.67158104916366 139.7451897294842 22.3 35.67167775126 139.74519356674787 22.3 35.67168035201276 139.74518780869397 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5d41bc0-b663-4b31-a2db-59c18b6bb065">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5d41bc0-b663-4b31-a2db-59c18b6bb065">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5d41bc0-b663-4b31-a2db-59c18b6bb065">
											<gml:posList>35.67161009299651 139.74525350172928 22.3 35.67161671927809 139.74525512932127 22.3 35.67158104916366 139.7451897294842 22.3 35.671571913702415 139.74518350934454 22.3 35.67161009299651 139.74525350172928 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0feae9ef-b323-4232-9ff8-d2055c0cdbd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0feae9ef-b323-4232-9ff8-d2055c0cdbd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0feae9ef-b323-4232-9ff8-d2055c0cdbd4">
											<gml:posList>35.67161009299651 139.74525350172928 22.3 35.67160279624488 139.7452594748169 22.3 35.67160942252641 139.74526110240922 22.3 35.67161671927809 139.74525512932127 22.3 35.67161009299651 139.74525350172928 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-12673067-7a6a-4e9d-a384-069355f5aec5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12673067-7a6a-4e9d-a384-069355f5aec5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12673067-7a6a-4e9d-a384-069355f5aec5">
											<gml:posList>35.67168035201276 139.74518780869397 22.3 35.67167775126 139.74519356674787 22.3 35.67181201076645 139.745440208048 22.3 35.67181862803159 139.74544183566937 22.3 35.67168035201276 139.74518780869397 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-849cb878-2a16-4076-9701-8fa915eaf118">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-849cb878-2a16-4076-9701-8fa915eaf118">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-849cb878-2a16-4076-9701-8fa915eaf118">
											<gml:posList>35.67176734734579 139.7454273216178 21.324 35.67178506676033 139.7454622089824 21.324 35.67181201076645 139.745440208048 21.324 35.67167775126 139.74519356674787 21.324 35.67158104916366 139.7451897294842 21.324 35.67161671927809 139.74525512932127 21.324 35.67160942252641 139.74526110240922 21.324 35.671715223477264 139.74545548092206 21.324 35.67174450057688 139.7454314780396 21.324 35.67174997925199 139.74544153534754 21.324 35.67176734734579 139.7454273216178 21.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27d3f4ed-bf8a-4434-8b09-b4c872342aa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27d3f4ed-bf8a-4434-8b09-b4c872342aa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27d3f4ed-bf8a-4434-8b09-b4c872342aa5">
											<gml:posList>35.671713904385314 139.745463601504 22.3 35.671715223477264 139.74545548092206 22.3 35.67160942252641 139.74526110240922 22.3 35.67160279624488 139.7452594748169 22.3 35.671713904385314 139.745463601504 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71704e03-745f-4964-a7fc-214a74b886ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71704e03-745f-4964-a7fc-214a74b886ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71704e03-745f-4964-a7fc-214a74b886ad">
											<gml:posList>35.67176590213624 139.74543554176182 22.3 35.67176734734579 139.7454273216178 22.3 35.67174997925199 139.74544153534754 22.3 35.67174865113921 139.74544964489667 22.3 35.67176590213624 139.74543554176182 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8db2a07d-0f77-4b1a-ad9f-f61517b96a3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8db2a07d-0f77-4b1a-ad9f-f61517b96a3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8db2a07d-0f77-4b1a-ad9f-f61517b96a3f">
											<gml:posList>35.67174318148656 139.7454395986249 22.3 35.67174865113921 139.74544964489667 22.3 35.67174997925199 139.74544153534754 22.3 35.67174450057688 139.7454314780396 22.3 35.67174318148656 139.7454395986249 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96558aed-6423-4d3c-a850-dd2aafaa1da8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96558aed-6423-4d3c-a850-dd2aafaa1da8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96558aed-6423-4d3c-a850-dd2aafaa1da8">
											<gml:posList>35.67176590213624 139.74543554176182 22.3 35.67178123850004 139.74546573699672 22.3 35.67178506676033 139.7454622089824 22.3 35.67176734734579 139.7454273216178 22.3 35.67176590213624 139.74543554176182 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60adbeef-4210-40dc-8e52-68eb9f5ed471">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60adbeef-4210-40dc-8e52-68eb9f5ed471">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60adbeef-4210-40dc-8e52-68eb9f5ed471">
											<gml:posList>35.67174318148656 139.7454395986249 22.3 35.67174450057688 139.7454314780396 22.3 35.671715223477264 139.74545548092206 22.3 35.671713904385314 139.745463601504 22.3 35.67174318148656 139.7454395986249 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d2cefe9-f193-4259-8191-2f002c993085">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d2cefe9-f193-4259-8191-2f002c993085">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d2cefe9-f193-4259-8191-2f002c993085">
											<gml:posList>35.67181862803159 139.74544183566937 22.3 35.67181201076645 139.745440208048 22.3 35.67178506676033 139.7454622089824 22.3 35.67178367559043 139.74547037383616 22.3 35.67181862803159 139.74544183566937 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63409d44-fea4-45a6-aa4a-dfae0b7f1351">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63409d44-fea4-45a6-aa4a-dfae0b7f1351">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63409d44-fea4-45a6-aa4a-dfae0b7f1351">
											<gml:posList>35.67178123850004 139.74546573699672 22.3 35.67178367559043 139.74547037383616 22.3 35.67178506676033 139.7454622089824 22.3 35.67178123850004 139.74546573699672 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58fd55a4-c1e5-4dd1-894e-9b3433a810e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58fd55a4-c1e5-4dd1-894e-9b3433a810e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58fd55a4-c1e5-4dd1-894e-9b3433a810e8">
											<gml:posList>35.671715223477264 139.74545548092206 22.3 35.671715223477264 139.74545548092206 21.324 35.67160942252641 139.74526110240922 21.324 35.67160942252641 139.74526110240922 22.3 35.671715223477264 139.74545548092206 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08d0f225-df12-4e7d-a25c-4c4259b42f97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08d0f225-df12-4e7d-a25c-4c4259b42f97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08d0f225-df12-4e7d-a25c-4c4259b42f97">
											<gml:posList>35.67174997925199 139.74544153534754 22.3 35.67174997925199 139.74544153534754 21.324 35.67174450057688 139.7454314780396 21.324 35.67174450057688 139.7454314780396 22.3 35.67174997925199 139.74544153534754 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59f84fa6-2b04-419e-a5aa-f37b2ec6e545">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59f84fa6-2b04-419e-a5aa-f37b2ec6e545">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59f84fa6-2b04-419e-a5aa-f37b2ec6e545">
											<gml:posList>35.67178506676033 139.7454622089824 22.3 35.67178506676033 139.7454622089824 21.324 35.67176734734579 139.7454273216178 21.324 35.67176734734579 139.7454273216178 22.3 35.67178506676033 139.7454622089824 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70b04728-667c-4484-8862-923fba34183f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70b04728-667c-4484-8862-923fba34183f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70b04728-667c-4484-8862-923fba34183f">
											<gml:posList>35.67168035201276 139.74518780869397 7.49 35.671571913702415 139.74518350934454 7.49 35.671571913702415 139.74518350934454 22.3 35.67168035201276 139.74518780869397 22.3 35.67168035201276 139.74518780869397 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-807481de-9e01-4cc5-bd77-5687cdb8ee85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-807481de-9e01-4cc5-bd77-5687cdb8ee85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-807481de-9e01-4cc5-bd77-5687cdb8ee85">
											<gml:posList>35.67158104916366 139.7451897294842 22.3 35.67158104916366 139.7451897294842 21.324 35.67167775126 139.74519356674787 21.324 35.67167775126 139.74519356674787 22.3 35.67158104916366 139.7451897294842 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3591b704-9be5-4c90-9b17-34bbf0e50ef9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3591b704-9be5-4c90-9b17-34bbf0e50ef9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3591b704-9be5-4c90-9b17-34bbf0e50ef9">
											<gml:posList>35.671571913702415 139.74518350934454 7.49 35.67161009299651 139.74525350172928 7.49 35.67161009299651 139.74525350172928 22.3 35.671571913702415 139.74518350934454 22.3 35.671571913702415 139.74518350934454 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-caf9f7e7-81ae-453c-8290-cbf7012eba20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-caf9f7e7-81ae-453c-8290-cbf7012eba20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-caf9f7e7-81ae-453c-8290-cbf7012eba20">
											<gml:posList>35.67161671927809 139.74525512932127 22.3 35.67161671927809 139.74525512932127 21.324 35.67158104916366 139.7451897294842 21.324 35.67158104916366 139.7451897294842 22.3 35.67161671927809 139.74525512932127 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-913404c4-3061-423e-a644-502e9eb9735e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-913404c4-3061-423e-a644-502e9eb9735e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-913404c4-3061-423e-a644-502e9eb9735e">
											<gml:posList>35.67161009299651 139.74525350172928 7.49 35.67160279624488 139.7452594748169 7.49 35.67160279624488 139.7452594748169 22.3 35.67161009299651 139.74525350172928 22.3 35.67161009299651 139.74525350172928 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fa8665e-ced5-4eeb-bab6-d72f928a6f83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fa8665e-ced5-4eeb-bab6-d72f928a6f83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fa8665e-ced5-4eeb-bab6-d72f928a6f83">
											<gml:posList>35.67160942252641 139.74526110240922 22.3 35.67160942252641 139.74526110240922 21.324 35.67161671927809 139.74525512932127 21.324 35.67161671927809 139.74525512932127 22.3 35.67160942252641 139.74526110240922 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb390c82-795b-460d-b7b3-58d2461a77e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb390c82-795b-460d-b7b3-58d2461a77e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb390c82-795b-460d-b7b3-58d2461a77e3">
											<gml:posList>35.67181862803159 139.74544183566937 7.49 35.67168035201276 139.74518780869397 7.49 35.67168035201276 139.74518780869397 22.3 35.67181862803159 139.74544183566937 22.3 35.67181862803159 139.74544183566937 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-074df4dd-8d33-4be0-878f-c85562b6dd0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-074df4dd-8d33-4be0-878f-c85562b6dd0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-074df4dd-8d33-4be0-878f-c85562b6dd0d">
											<gml:posList>35.67167775126 139.74519356674787 22.3 35.67167775126 139.74519356674787 21.324 35.67181201076645 139.745440208048 21.324 35.67181201076645 139.745440208048 22.3 35.67167775126 139.74519356674787 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcc01fe9-263f-4c88-ba64-f80cb87ed831">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcc01fe9-263f-4c88-ba64-f80cb87ed831">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcc01fe9-263f-4c88-ba64-f80cb87ed831">
											<gml:posList>35.67160279624488 139.7452594748169 7.49 35.671713904385314 139.745463601504 7.49 35.671713904385314 139.745463601504 22.3 35.67160279624488 139.7452594748169 22.3 35.67160279624488 139.7452594748169 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a98dcfc-e4b1-4b73-a25c-969a50ab11e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a98dcfc-e4b1-4b73-a25c-969a50ab11e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a98dcfc-e4b1-4b73-a25c-969a50ab11e1">
											<gml:posList>35.67176734734579 139.7454273216178 22.3 35.67176734734579 139.7454273216178 21.324 35.67174997925199 139.74544153534754 21.324 35.67174997925199 139.74544153534754 22.3 35.67176734734579 139.7454273216178 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4cbbe17-35fd-4e42-91c4-82704eedc593">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4cbbe17-35fd-4e42-91c4-82704eedc593">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4cbbe17-35fd-4e42-91c4-82704eedc593">
											<gml:posList>35.67174865113921 139.74544964489667 7.49 35.67176590213624 139.74543554176182 7.49 35.67176590213624 139.74543554176182 22.3 35.67174865113921 139.74544964489667 22.3 35.67174865113921 139.74544964489667 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f058b7af-7bbb-430b-a06a-89a4c455984f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f058b7af-7bbb-430b-a06a-89a4c455984f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f058b7af-7bbb-430b-a06a-89a4c455984f">
											<gml:posList>35.67174450057688 139.7454314780396 22.3 35.67174450057688 139.7454314780396 21.324 35.671715223477264 139.74545548092206 21.324 35.671715223477264 139.74545548092206 22.3 35.67174450057688 139.7454314780396 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d5926af-8f6e-428e-8a17-4a832eab0956">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d5926af-8f6e-428e-8a17-4a832eab0956">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d5926af-8f6e-428e-8a17-4a832eab0956">
											<gml:posList>35.67174318148656 139.7454395986249 7.49 35.67174865113921 139.74544964489667 7.49 35.67174865113921 139.74544964489667 22.3 35.67174318148656 139.7454395986249 22.3 35.67174318148656 139.7454395986249 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7c86354-cd54-4d12-87f3-48a56cf99ff6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7c86354-cd54-4d12-87f3-48a56cf99ff6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7c86354-cd54-4d12-87f3-48a56cf99ff6">
											<gml:posList>35.67178123850004 139.74546573699672 22.3 35.67176590213624 139.74543554176182 22.3 35.67176590213624 139.74543554176182 7.49 35.67178123850004 139.74546573699672 7.49 35.67178123850004 139.74546573699672 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3abfac9e-29c3-4b74-92b8-130db3d59360">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3abfac9e-29c3-4b74-92b8-130db3d59360">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3abfac9e-29c3-4b74-92b8-130db3d59360">
											<gml:posList>35.67181201076645 139.745440208048 22.3 35.67181201076645 139.745440208048 21.324 35.67178506676033 139.7454622089824 21.324 35.67178506676033 139.7454622089824 22.3 35.67181201076645 139.745440208048 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b00d77aa-7465-4e4f-9094-3fac1b9a057f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b00d77aa-7465-4e4f-9094-3fac1b9a057f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b00d77aa-7465-4e4f-9094-3fac1b9a057f">
											<gml:posList>35.671713904385314 139.745463601504 7.49 35.67174318148656 139.7454395986249 7.49 35.67174318148656 139.7454395986249 22.3 35.671713904385314 139.745463601504 22.3 35.671713904385314 139.745463601504 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b819e40a-e869-412f-9353-51065728004a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b819e40a-e869-412f-9353-51065728004a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b819e40a-e869-412f-9353-51065728004a">
											<gml:posList>35.67178367559043 139.74547037383616 7.49 35.67181862803159 139.74544183566937 7.49 35.67181862803159 139.74544183566937 22.3 35.67178367559043 139.74547037383616 22.3 35.67178367559043 139.74547037383616 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-905ee95a-f18b-4d18-bfe3-769c4b50f3de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-905ee95a-f18b-4d18-bfe3-769c4b50f3de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-905ee95a-f18b-4d18-bfe3-769c4b50f3de">
											<gml:posList>35.67178123850004 139.74546573699672 7.49 35.67178367559043 139.74547037383616 7.49 35.67178367559043 139.74547037383616 22.3 35.67178123850004 139.74546573699672 22.3 35.67178123850004 139.74546573699672 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区霞が関三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-2250</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">311.13345</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.1</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>