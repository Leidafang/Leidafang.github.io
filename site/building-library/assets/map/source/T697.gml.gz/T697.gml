<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c941ec6a-a832-4dc7-894a-87169c856299">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">37.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67416193922666 139.73845140457755 0 35.67412651800967 139.7383405368755 0 35.67410507303316 139.73835028344638 0 35.67408428822257 139.73828281231044 0 35.67403545262489 139.7383066207531 0 35.67408922177246 139.7384809855198 0 35.67416193922666 139.73845140457755 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67416193922666 139.73845140457755 7.96 35.67408922177246 139.7384809855198 7.96 35.67403545262489 139.7383066207531 7.96 35.67408428822257 139.73828281231044 7.96 35.67410507303316 139.73835028344638 7.96 35.67412651800967 139.7383405368755 7.96 35.67416193922666 139.73845140457755 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67416193922666 139.73845140457755 7.96 35.67412651800967 139.7383405368755 7.96 35.67412651800967 139.7383405368755 45.29 35.67416193922666 139.73845140457755 45.29 35.67416193922666 139.73845140457755 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67412651800967 139.7383405368755 7.96 35.67410507303316 139.73835028344638 7.96 35.67410507303316 139.73835028344638 45.29 35.67412651800967 139.7383405368755 45.29 35.67412651800967 139.7383405368755 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67410507303316 139.73835028344638 7.96 35.67408428822257 139.73828281231044 7.96 35.67408428822257 139.73828281231044 45.29 35.67410507303316 139.73835028344638 45.29 35.67410507303316 139.73835028344638 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67408428822257 139.73828281231044 7.96 35.67403545262489 139.7383066207531 7.96 35.67403545262489 139.7383066207531 45.29 35.67408428822257 139.73828281231044 45.29 35.67408428822257 139.73828281231044 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67403545262489 139.7383066207531 7.96 35.67408922177246 139.7384809855198 7.96 35.67408922177246 139.7384809855198 45.29 35.67403545262489 139.7383066207531 45.29 35.67403545262489 139.7383066207531 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67408922177246 139.7384809855198 7.96 35.67416193922666 139.73845140457755 7.96 35.67416193922666 139.73845140457755 45.29 35.67408922177246 139.7384809855198 45.29 35.67408922177246 139.7384809855198 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67416193922666 139.73845140457755 45.29 35.67412651800967 139.7383405368755 45.29 35.67410507303316 139.73835028344638 45.29 35.67408428822257 139.73828281231044 45.29 35.67403545262489 139.7383066207531 45.29 35.67408922177246 139.7384809855198 45.29 35.67416193922666 139.73845140457755 45.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5823580d-8d0f-4c77-8bdd-eadc7778cfde"/>
							<gml:surfaceMember xlink:href="#poly-00fecf43-2114-4bf8-89b2-0c5be396918c"/>
							<gml:surfaceMember xlink:href="#poly-dbcfbedb-bbbd-4f70-8a1e-af8d57690494"/>
							<gml:surfaceMember xlink:href="#poly-5434fd43-e142-4925-8b44-312fb7c958e4"/>
							<gml:surfaceMember xlink:href="#poly-c55db8ff-7b87-40b2-ab2e-837052a558cd"/>
							<gml:surfaceMember xlink:href="#poly-80dd37d7-1dc7-4907-b9d7-c43187410aa2"/>
							<gml:surfaceMember xlink:href="#poly-18c2f34b-166f-49c0-a224-c1aa01b1c9e6"/>
							<gml:surfaceMember xlink:href="#poly-ba8d5b34-2b3f-467b-b6c0-730b92ac18a1"/>
							<gml:surfaceMember xlink:href="#poly-510c9471-bee3-492d-97c7-52b74fd3174a"/>
							<gml:surfaceMember xlink:href="#poly-0546bed7-c104-4874-a2f7-4d681fd9a99a"/>
							<gml:surfaceMember xlink:href="#poly-1f934bd6-d364-4b6a-924f-34aafff166a8"/>
							<gml:surfaceMember xlink:href="#poly-dcda65a7-5eaf-4aaf-a24f-26a0cb6c0538"/>
							<gml:surfaceMember xlink:href="#poly-f480294d-66d7-4625-963f-3fb8b231296e"/>
							<gml:surfaceMember xlink:href="#poly-208c424e-b8a9-497b-8fcc-9f2f2f3c3300"/>
							<gml:surfaceMember xlink:href="#poly-b0ecd06c-3c32-4189-86ce-3531ef718ae7"/>
							<gml:surfaceMember xlink:href="#poly-de12121c-6217-4aa2-a35c-4cae0cd79385"/>
							<gml:surfaceMember xlink:href="#poly-30fde6b6-4f6d-4894-8955-731c485a2199"/>
							<gml:surfaceMember xlink:href="#poly-932e6e2e-ed93-40b6-b15d-eb74c7043e4d"/>
							<gml:surfaceMember xlink:href="#poly-19f93b9d-85d9-464f-a923-1b3912a043c7"/>
							<gml:surfaceMember xlink:href="#poly-87634239-4d0b-40ef-ae66-61c1f6bfd42c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5823580d-8d0f-4c77-8bdd-eadc7778cfde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5823580d-8d0f-4c77-8bdd-eadc7778cfde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5823580d-8d0f-4c77-8bdd-eadc7778cfde">
											<gml:posList>35.67408922177244 139.73848098551977 7.96 35.674035452624906 139.7383066207531 7.96 35.67408428822255 139.73828281231044 7.96 35.67410507303313 139.73835028344638 7.96 35.67412651800965 139.7383405368755 7.96 35.67416193922666 139.73845140457755 7.96 35.67408922177244 139.73848098551977 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00fecf43-2114-4bf8-89b2-0c5be396918c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00fecf43-2114-4bf8-89b2-0c5be396918c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00fecf43-2114-4bf8-89b2-0c5be396918c">
											<gml:posList>35.674035452624906 139.7383066207531 53.859 35.674040222921036 139.73830920004121 53.859 35.674082165668125 139.73828874694217 53.859 35.67408428822255 139.73828281231044 53.859 35.674035452624906 139.7383066207531 53.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbcfbedb-bbbd-4f70-8a1e-af8d57690494">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbcfbedb-bbbd-4f70-8a1e-af8d57690494">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbcfbedb-bbbd-4f70-8a1e-af8d57690494">
											<gml:posList>35.67408922177244 139.73848098551977 53.859 35.67409144367 139.73847528275724 53.859 35.674040222921036 139.73830920004121 53.859 35.674035452624906 139.7383066207531 53.859 35.67408922177244 139.73848098551977 53.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5434fd43-e142-4925-8b44-312fb7c958e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5434fd43-e142-4925-8b44-312fb7c958e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5434fd43-e142-4925-8b44-312fb7c958e4">
											<gml:posList>35.67410507303313 139.73835028344638 53.859 35.67408428822255 139.73828281231044 53.859 35.674082165668125 139.73828874694217 53.859 35.67410290532838 139.7383561187104 53.859 35.67410507303313 139.73835028344638 53.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c55db8ff-7b87-40b2-ab2e-837052a558cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c55db8ff-7b87-40b2-ab2e-837052a558cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c55db8ff-7b87-40b2-ab2e-837052a558cd">
											<gml:posList>35.67409144367 139.73847528275724 53.313 35.67415705157252 139.73844859343356 53.313 35.67412438635153 139.7383463610519 53.313 35.67410290532838 139.7383561187104 53.313 35.674082165668125 139.73828874694217 53.313 35.674040222921036 139.73830920004121 53.313 35.67409144367 139.73847528275724 53.313</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-80dd37d7-1dc7-4907-b9d7-c43187410aa2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80dd37d7-1dc7-4907-b9d7-c43187410aa2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80dd37d7-1dc7-4907-b9d7-c43187410aa2">
											<gml:posList>35.67410507303313 139.73835028344638 53.859 35.67410290532838 139.7383561187104 53.859 35.67412438635153 139.7383463610519 53.859 35.67412651800965 139.7383405368755 53.859 35.67410507303313 139.73835028344638 53.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18c2f34b-166f-49c0-a224-c1aa01b1c9e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18c2f34b-166f-49c0-a224-c1aa01b1c9e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18c2f34b-166f-49c0-a224-c1aa01b1c9e6">
											<gml:posList>35.67416193922666 139.73845140457755 53.859 35.67415705157252 139.73844859343356 53.859 35.67409144367 139.73847528275724 53.859 35.67408922177244 139.73848098551977 53.859 35.67416193922666 139.73845140457755 53.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba8d5b34-2b3f-467b-b6c0-730b92ac18a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba8d5b34-2b3f-467b-b6c0-730b92ac18a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba8d5b34-2b3f-467b-b6c0-730b92ac18a1">
											<gml:posList>35.67412651800965 139.7383405368755 53.859 35.67412438635153 139.7383463610519 53.859 35.67415705157252 139.73844859343356 53.859 35.67416193922666 139.73845140457755 53.859 35.67412651800965 139.7383405368755 53.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-510c9471-bee3-492d-97c7-52b74fd3174a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-510c9471-bee3-492d-97c7-52b74fd3174a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-510c9471-bee3-492d-97c7-52b74fd3174a">
											<gml:posList>35.674082165668125 139.73828874694217 53.859 35.674082165668125 139.73828874694217 53.313 35.67410290532838 139.7383561187104 53.313 35.67410290532838 139.7383561187104 53.859 35.674082165668125 139.73828874694217 53.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0546bed7-c104-4874-a2f7-4d681fd9a99a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0546bed7-c104-4874-a2f7-4d681fd9a99a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0546bed7-c104-4874-a2f7-4d681fd9a99a">
											<gml:posList>35.67408428822255 139.73828281231044 7.96 35.674035452624906 139.7383066207531 7.96 35.674035452624906 139.7383066207531 53.859 35.67408428822255 139.73828281231044 53.859 35.67408428822255 139.73828281231044 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f934bd6-d364-4b6a-924f-34aafff166a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f934bd6-d364-4b6a-924f-34aafff166a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f934bd6-d364-4b6a-924f-34aafff166a8">
											<gml:posList>35.674040222921036 139.73830920004121 53.859 35.674040222921036 139.73830920004121 53.313 35.674082165668125 139.73828874694217 53.313 35.674082165668125 139.73828874694217 53.859 35.674040222921036 139.73830920004121 53.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcda65a7-5eaf-4aaf-a24f-26a0cb6c0538">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcda65a7-5eaf-4aaf-a24f-26a0cb6c0538">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcda65a7-5eaf-4aaf-a24f-26a0cb6c0538">
											<gml:posList>35.67410507303313 139.73835028344638 7.96 35.67408428822255 139.73828281231044 7.96 35.67408428822255 139.73828281231044 53.859 35.67410507303313 139.73835028344638 53.859 35.67410507303313 139.73835028344638 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f480294d-66d7-4625-963f-3fb8b231296e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f480294d-66d7-4625-963f-3fb8b231296e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f480294d-66d7-4625-963f-3fb8b231296e">
											<gml:posList>35.67412651800965 139.7383405368755 7.96 35.67410507303313 139.73835028344638 7.96 35.67410507303313 139.73835028344638 53.859 35.67412651800965 139.7383405368755 53.859 35.67412651800965 139.7383405368755 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-208c424e-b8a9-497b-8fcc-9f2f2f3c3300">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-208c424e-b8a9-497b-8fcc-9f2f2f3c3300">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-208c424e-b8a9-497b-8fcc-9f2f2f3c3300">
											<gml:posList>35.67410290532838 139.7383561187104 53.859 35.67410290532838 139.7383561187104 53.313 35.67412438635153 139.7383463610519 53.313 35.67412438635153 139.7383463610519 53.859 35.67410290532838 139.7383561187104 53.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0ecd06c-3c32-4189-86ce-3531ef718ae7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0ecd06c-3c32-4189-86ce-3531ef718ae7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0ecd06c-3c32-4189-86ce-3531ef718ae7">
											<gml:posList>35.67409144367 139.73847528275724 53.859 35.67409144367 139.73847528275724 53.313 35.674040222921036 139.73830920004121 53.313 35.674040222921036 139.73830920004121 53.859 35.67409144367 139.73847528275724 53.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de12121c-6217-4aa2-a35c-4cae0cd79385">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de12121c-6217-4aa2-a35c-4cae0cd79385">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de12121c-6217-4aa2-a35c-4cae0cd79385">
											<gml:posList>35.674035452624906 139.7383066207531 7.96 35.67408922177244 139.73848098551977 7.96 35.67408922177244 139.73848098551977 53.859 35.674035452624906 139.7383066207531 53.859 35.674035452624906 139.7383066207531 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30fde6b6-4f6d-4894-8955-731c485a2199">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30fde6b6-4f6d-4894-8955-731c485a2199">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30fde6b6-4f6d-4894-8955-731c485a2199">
											<gml:posList>35.67416193922666 139.73845140457755 7.96 35.67412651800965 139.7383405368755 7.96 35.67412651800965 139.7383405368755 53.859 35.67416193922666 139.73845140457755 53.859 35.67416193922666 139.73845140457755 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-932e6e2e-ed93-40b6-b15d-eb74c7043e4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-932e6e2e-ed93-40b6-b15d-eb74c7043e4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-932e6e2e-ed93-40b6-b15d-eb74c7043e4d">
											<gml:posList>35.67412438635153 139.7383463610519 53.859 35.67412438635153 139.7383463610519 53.313 35.67415705157252 139.73844859343356 53.313 35.67415705157252 139.73844859343356 53.859 35.67412438635153 139.7383463610519 53.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19f93b9d-85d9-464f-a923-1b3912a043c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19f93b9d-85d9-464f-a923-1b3912a043c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19f93b9d-85d9-464f-a923-1b3912a043c7">
											<gml:posList>35.67415705157252 139.73844859343356 53.859 35.67415705157252 139.73844859343356 53.313 35.67409144367 139.73847528275724 53.313 35.67409144367 139.73847528275724 53.859 35.67415705157252 139.73844859343356 53.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87634239-4d0b-40ef-ae66-61c1f6bfd42c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87634239-4d0b-40ef-ae66-61c1f6bfd42c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87634239-4d0b-40ef-ae66-61c1f6bfd42c">
											<gml:posList>35.67408922177244 139.73848098551977 7.96 35.67416193922666 139.73845140457755 7.96 35.67416193922666 139.73845140457755 53.859 35.67408922177244 139.73848098551977 53.859 35.67408922177244 139.73848098551977 7.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2318</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">127.2425</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.36</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>