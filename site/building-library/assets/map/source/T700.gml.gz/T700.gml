<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c9ee6b9d-4bb7-4743-957c-233748067290">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">7</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671548692801586 139.7407847396938 0 35.67159596421651 139.74071884842138 0 35.67154977572133 139.7406691928841 0 35.67154122178178 139.74068102243942 0 35.67152669762018 139.74066535331139 0 35.67148383828476 139.7407251639359 0 35.671529395542144 139.74077448880092 0 35.671533627405594 139.74076851884942 0 35.671548692801586 139.7407847396938 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671548692801586 139.7407847396938 8.03 35.671533627405594 139.74076851884942 8.03 35.671529395542144 139.74077448880092 8.03 35.67148383828476 139.7407251639359 8.03 35.67152669762018 139.74066535331139 8.03 35.67154122178178 139.74068102243942 8.03 35.67154977572133 139.7406691928841 8.03 35.67159596421651 139.74071884842138 8.03 35.671548692801586 139.7407847396938 8.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671548692801586 139.7407847396938 8.03 35.67159596421651 139.74071884842138 8.03 35.67159596421651 139.74071884842138 14.99 35.671548692801586 139.7407847396938 14.99 35.671548692801586 139.7407847396938 8.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67159596421651 139.74071884842138 8.03 35.67154977572133 139.7406691928841 8.03 35.67154977572133 139.7406691928841 14.99 35.67159596421651 139.74071884842138 14.99 35.67159596421651 139.74071884842138 8.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67154977572133 139.7406691928841 8.03 35.67154122178178 139.74068102243942 8.03 35.67154122178178 139.74068102243942 14.99 35.67154977572133 139.7406691928841 14.99 35.67154977572133 139.7406691928841 8.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67154122178178 139.74068102243942 8.03 35.67152669762018 139.74066535331139 8.03 35.67152669762018 139.74066535331139 14.99 35.67154122178178 139.74068102243942 14.99 35.67154122178178 139.74068102243942 8.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152669762018 139.74066535331139 8.03 35.67148383828476 139.7407251639359 8.03 35.67148383828476 139.7407251639359 14.99 35.67152669762018 139.74066535331139 14.99 35.67152669762018 139.74066535331139 8.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148383828476 139.7407251639359 8.03 35.671529395542144 139.74077448880092 8.03 35.671529395542144 139.74077448880092 14.99 35.67148383828476 139.7407251639359 14.99 35.67148383828476 139.7407251639359 8.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671529395542144 139.74077448880092 8.03 35.671533627405594 139.74076851884942 8.03 35.671533627405594 139.74076851884942 14.99 35.671529395542144 139.74077448880092 14.99 35.671529395542144 139.74077448880092 8.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671533627405594 139.74076851884942 8.03 35.671548692801586 139.7407847396938 8.03 35.671548692801586 139.7407847396938 14.99 35.671533627405594 139.74076851884942 14.99 35.671533627405594 139.74076851884942 8.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671548692801586 139.7407847396938 14.99 35.67159596421651 139.74071884842138 14.99 35.67154977572133 139.7406691928841 14.99 35.67154122178178 139.74068102243942 14.99 35.67152669762018 139.74066535331139 14.99 35.67148383828476 139.7407251639359 14.99 35.671529395542144 139.74077448880092 14.99 35.671533627405594 139.74076851884942 14.99 35.671548692801586 139.7407847396938 14.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ede61681-dedc-402a-9fd9-589552abb26c"/>
							<gml:surfaceMember xlink:href="#poly-9aa49119-84ba-4c01-a03d-1a3447438b5c"/>
							<gml:surfaceMember xlink:href="#poly-8a81b89f-43d3-4c9a-bcc0-1e9f57eb8f44"/>
							<gml:surfaceMember xlink:href="#poly-f4065be3-85d9-45de-ba99-1f9100e73c0a"/>
							<gml:surfaceMember xlink:href="#poly-dd023e45-af16-4de6-b584-b8c7a67cd537"/>
							<gml:surfaceMember xlink:href="#poly-7b5aed8c-597d-4ea6-b8aa-4f3a1b967492"/>
							<gml:surfaceMember xlink:href="#poly-84a7d130-2d6e-45a4-992c-8a7acce8eb10"/>
							<gml:surfaceMember xlink:href="#poly-c9ab96d1-e500-4d75-b4d2-e632a9c73248"/>
							<gml:surfaceMember xlink:href="#poly-b55bd7ee-6f0c-490e-baad-bd8c6ed94542"/>
							<gml:surfaceMember xlink:href="#poly-96231664-b23b-4480-8248-764d7996807b"/>
							<gml:surfaceMember xlink:href="#poly-3e76c415-7992-44ca-afc0-a11fc01efef7"/>
							<gml:surfaceMember xlink:href="#poly-00772b55-19eb-4281-bed8-9c649bf8bace"/>
							<gml:surfaceMember xlink:href="#poly-d0f3b28f-d0f3-4b5e-840e-552de12eba7a"/>
							<gml:surfaceMember xlink:href="#poly-a6112989-d0b2-4afd-9fbd-36c50e1f6fbf"/>
							<gml:surfaceMember xlink:href="#poly-b665d7a6-ba09-44f2-ad00-8807ec1fc0db"/>
							<gml:surfaceMember xlink:href="#poly-176cae53-1108-4f4b-bad8-3fb2acc83fda"/>
							<gml:surfaceMember xlink:href="#poly-2523699c-2cf4-4b23-9710-d34847e40d01"/>
							<gml:surfaceMember xlink:href="#poly-a412591f-528f-407e-8292-498be874273b"/>
							<gml:surfaceMember xlink:href="#poly-a2a5fc18-e033-4560-9e2c-b162c145c17a"/>
							<gml:surfaceMember xlink:href="#poly-24e54795-7ca5-4b4d-b1e4-071cda8927b9"/>
							<gml:surfaceMember xlink:href="#poly-14738c69-2151-4cd3-9e8a-3c2ecc317d75"/>
							<gml:surfaceMember xlink:href="#poly-04f4b827-e34f-4f62-b1fd-1bc4b691dcb3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ede61681-dedc-402a-9fd9-589552abb26c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ede61681-dedc-402a-9fd9-589552abb26c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ede61681-dedc-402a-9fd9-589552abb26c">
											<gml:posList>35.671483838284765 139.74072516393593 8.03 35.67152669762017 139.74066535331139 8.03 35.67154122178176 139.74068102243942 8.03 35.67154977572133 139.7406691928841 8.03 35.6715959642165 139.74071884842135 8.03 35.67154869280156 139.7407847396938 8.03 35.6715336274056 139.74076851884942 8.03 35.67152939554212 139.74077448880092 8.03 35.671483838284765 139.74072516393593 8.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9aa49119-84ba-4c01-a03d-1a3447438b5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9aa49119-84ba-4c01-a03d-1a3447438b5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9aa49119-84ba-4c01-a03d-1a3447438b5c">
											<gml:posList>35.671525473919075 139.74071503046417 15.997 35.67152669762017 139.74066535331139 13.096 35.67148798016155 139.74071939292458 13.096 35.671525473919075 139.74071503046417 15.997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a81b89f-43d3-4c9a-bcc0-1e9f57eb8f44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a81b89f-43d3-4c9a-bcc0-1e9f57eb8f44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a81b89f-43d3-4c9a-bcc0-1e9f57eb8f44">
											<gml:posList>35.67148798016155 139.74071939292458 13.096 35.671483838284765 139.74072516393593 13.096 35.67152939554212 139.74077448880092 13.096 35.6715336274056 139.74076851884942 13.096 35.67148798016155 139.74071939292458 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4065be3-85d9-45de-ba99-1f9100e73c0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4065be3-85d9-45de-ba99-1f9100e73c0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4065be3-85d9-45de-ba99-1f9100e73c0a">
											<gml:posList>35.6715336274056 139.74076851884942 13.096 35.671525473919075 139.74071503046417 15.997 35.67148798016155 139.74071939292458 13.096 35.6715336274056 139.74076851884942 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd023e45-af16-4de6-b584-b8c7a67cd537">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd023e45-af16-4de6-b584-b8c7a67cd537">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd023e45-af16-4de6-b584-b8c7a67cd537">
											<gml:posList>35.67154122178176 139.74068102243942 13.096 35.67152669762017 139.74066535331139 13.096 35.671525473919075 139.74071503046417 15.997 35.67153852743596 139.74072887864048 15.997 35.67154122178176 139.74068102243942 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b5aed8c-597d-4ea6-b8aa-4f3a1b967492">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b5aed8c-597d-4ea6-b8aa-4f3a1b967492">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b5aed8c-597d-4ea6-b8aa-4f3a1b967492">
											<gml:posList>35.671544201942694 139.74073521273118 15.817 35.67153852743596 139.74072887864048 15.997 35.671525473919075 139.74071503046417 15.997 35.671544201942694 139.74073521273118 15.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84a7d130-2d6e-45a4-992c-8a7acce8eb10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84a7d130-2d6e-45a4-992c-8a7acce8eb10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84a7d130-2d6e-45a4-992c-8a7acce8eb10">
											<gml:posList>35.6715336274056 139.74076851884942 13.096 35.671544201942694 139.74073521273118 15.817 35.671525473919075 139.74071503046417 15.997 35.6715336274056 139.74076851884942 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9ab96d1-e500-4d75-b4d2-e632a9c73248">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9ab96d1-e500-4d75-b4d2-e632a9c73248">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9ab96d1-e500-4d75-b4d2-e632a9c73248">
											<gml:posList>35.6715336274056 139.74076851884942 13.096 35.67154869280156 139.7407847396938 13.096 35.671544201942694 139.74073521273118 15.817 35.6715336274056 139.74076851884942 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b55bd7ee-6f0c-490e-baad-bd8c6ed94542">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b55bd7ee-6f0c-490e-baad-bd8c6ed94542">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b55bd7ee-6f0c-490e-baad-bd8c6ed94542">
											<gml:posList>35.67154122178176 139.74068102243942 13.096 35.67153852743596 139.74072887864048 15.997 35.671567601590034 139.74068834887163 15.817 35.67154122178176 139.74068102243942 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96231664-b23b-4480-8248-764d7996807b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96231664-b23b-4480-8248-764d7996807b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96231664-b23b-4480-8248-764d7996807b">
											<gml:posList>35.671567601590034 139.74068834887163 15.817 35.67154977572133 139.7406691928841 13.096 35.67154122178176 139.74068102243942 13.096 35.671567601590034 139.74068834887163 15.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e76c415-7992-44ca-afc0-a11fc01efef7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e76c415-7992-44ca-afc0-a11fc01efef7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e76c415-7992-44ca-afc0-a11fc01efef7">
											<gml:posList>35.6715959642165 139.74071884842135 13.096 35.67153852743596 139.74072887864048 15.997 35.671544201942694 139.74073521273118 15.817 35.6715959642165 139.74071884842135 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00772b55-19eb-4281-bed8-9c649bf8bace">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00772b55-19eb-4281-bed8-9c649bf8bace">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00772b55-19eb-4281-bed8-9c649bf8bace">
											<gml:posList>35.671567601590034 139.74068834887163 15.817 35.67153852743596 139.74072887864048 15.997 35.6715959642165 139.74071884842135 13.096 35.671567601590034 139.74068834887163 15.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0f3b28f-d0f3-4b5e-840e-552de12eba7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0f3b28f-d0f3-4b5e-840e-552de12eba7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0f3b28f-d0f3-4b5e-840e-552de12eba7a">
											<gml:posList>35.671544201942694 139.74073521273118 15.817 35.67154869280156 139.7407847396938 13.096 35.6715959642165 139.74071884842135 13.096 35.671544201942694 139.74073521273118 15.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6112989-d0b2-4afd-9fbd-36c50e1f6fbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6112989-d0b2-4afd-9fbd-36c50e1f6fbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6112989-d0b2-4afd-9fbd-36c50e1f6fbf">
											<gml:posList>35.67152669762017 139.74066535331139 8.03 35.671483838284765 139.74072516393593 8.03 35.671483838284765 139.74072516393593 13.096 35.67148798016155 139.74071939292458 13.096 35.67152669762017 139.74066535331139 13.096 35.67152669762017 139.74066535331139 8.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b665d7a6-ba09-44f2-ad00-8807ec1fc0db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b665d7a6-ba09-44f2-ad00-8807ec1fc0db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b665d7a6-ba09-44f2-ad00-8807ec1fc0db">
											<gml:posList>35.67154122178176 139.74068102243942 13.096 35.67154122178176 139.74068102243942 8.03 35.67152669762017 139.74066535331139 8.03 35.67152669762017 139.74066535331139 13.096 35.67154122178176 139.74068102243942 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-176cae53-1108-4f4b-bad8-3fb2acc83fda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-176cae53-1108-4f4b-bad8-3fb2acc83fda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-176cae53-1108-4f4b-bad8-3fb2acc83fda">
											<gml:posList>35.67154977572133 139.7406691928841 13.096 35.67154977572133 139.7406691928841 8.03 35.67154122178176 139.74068102243942 8.03 35.67154122178176 139.74068102243942 13.096 35.67154977572133 139.7406691928841 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2523699c-2cf4-4b23-9710-d34847e40d01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2523699c-2cf4-4b23-9710-d34847e40d01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2523699c-2cf4-4b23-9710-d34847e40d01">
											<gml:posList>35.671567601590034 139.74068834887163 15.817 35.6715959642165 139.74071884842135 13.096 35.67154977572133 139.7406691928841 13.096 35.671567601590034 139.74068834887163 15.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a412591f-528f-407e-8292-498be874273b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a412591f-528f-407e-8292-498be874273b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a412591f-528f-407e-8292-498be874273b">
											<gml:posList>35.6715959642165 139.74071884842135 13.096 35.6715959642165 139.74071884842135 8.03 35.67154977572133 139.7406691928841 8.03 35.67154977572133 139.7406691928841 13.096 35.6715959642165 139.74071884842135 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2a5fc18-e033-4560-9e2c-b162c145c17a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2a5fc18-e033-4560-9e2c-b162c145c17a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2a5fc18-e033-4560-9e2c-b162c145c17a">
											<gml:posList>35.671483838284765 139.74072516393593 13.096 35.671483838284765 139.74072516393593 8.03 35.67152939554212 139.74077448880092 8.03 35.67152939554212 139.74077448880092 13.096 35.671483838284765 139.74072516393593 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24e54795-7ca5-4b4d-b1e4-071cda8927b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24e54795-7ca5-4b4d-b1e4-071cda8927b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24e54795-7ca5-4b4d-b1e4-071cda8927b9">
											<gml:posList>35.67154869280156 139.7407847396938 13.096 35.67154869280156 139.7407847396938 8.03 35.6715959642165 139.74071884842135 8.03 35.6715959642165 139.74071884842135 13.096 35.67154869280156 139.7407847396938 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14738c69-2151-4cd3-9e8a-3c2ecc317d75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14738c69-2151-4cd3-9e8a-3c2ecc317d75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14738c69-2151-4cd3-9e8a-3c2ecc317d75">
											<gml:posList>35.67152939554212 139.74077448880092 13.096 35.67152939554212 139.74077448880092 8.03 35.6715336274056 139.74076851884942 8.03 35.6715336274056 139.74076851884942 13.096 35.67152939554212 139.74077448880092 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04f4b827-e34f-4f62-b1fd-1bc4b691dcb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04f4b827-e34f-4f62-b1fd-1bc4b691dcb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04f4b827-e34f-4f62-b1fd-1bc4b691dcb3">
											<gml:posList>35.6715336274056 139.74076851884942 13.096 35.6715336274056 139.74076851884942 8.03 35.67154869280156 139.7407847396938 8.03 35.67154869280156 139.7407847396938 13.096 35.6715336274056 139.74076851884942 13.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10690</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">72.78529</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>