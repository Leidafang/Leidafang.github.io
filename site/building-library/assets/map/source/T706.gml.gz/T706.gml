<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cbd2efcf-4bd3-4966-b880-9e9e0f24c5f6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">15.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67202668715064 139.7381209905602 0 35.67208254106714 139.73830970880687 0 35.67216318569409 139.7382739330127 0 35.67210724158486 139.73808521470846 0 35.67202668715064 139.7381209905602 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67202668715064 139.7381209905602 9.77 35.67210724158486 139.73808521470846 9.77 35.67216318569409 139.7382739330127 9.77 35.67208254106714 139.73830970880687 9.77 35.67202668715064 139.7381209905602 9.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67202668715064 139.7381209905602 9.77 35.67208254106714 139.73830970880687 9.77 35.67208254106714 139.73830970880687 25.7 35.67202668715064 139.7381209905602 25.7 35.67202668715064 139.7381209905602 9.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67208254106714 139.73830970880687 9.77 35.67216318569409 139.7382739330127 9.77 35.67216318569409 139.7382739330127 25.7 35.67208254106714 139.73830970880687 25.7 35.67208254106714 139.73830970880687 9.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67216318569409 139.7382739330127 9.77 35.67210724158486 139.73808521470846 9.77 35.67210724158486 139.73808521470846 25.7 35.67216318569409 139.7382739330127 25.7 35.67216318569409 139.7382739330127 9.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67210724158486 139.73808521470846 9.77 35.67202668715064 139.7381209905602 9.77 35.67202668715064 139.7381209905602 25.7 35.67210724158486 139.73808521470846 25.7 35.67210724158486 139.73808521470846 9.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67202668715064 139.7381209905602 25.7 35.67208254106714 139.73830970880687 25.7 35.67216318569409 139.7382739330127 25.7 35.67210724158486 139.73808521470846 25.7 35.67202668715064 139.7381209905602 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ea67d9cc-a200-499d-975b-a0a260803c51"/>
							<gml:surfaceMember xlink:href="#poly-6210deae-214b-4810-9a61-44ed0f7c8aa2"/>
							<gml:surfaceMember xlink:href="#poly-bc1bee52-700f-4e45-a438-274f0d641a4e"/>
							<gml:surfaceMember xlink:href="#poly-41ed1102-1f7d-4fc8-95f2-4a4eb5ab377d"/>
							<gml:surfaceMember xlink:href="#poly-5380d67b-c9d6-436e-9013-7f801514d395"/>
							<gml:surfaceMember xlink:href="#poly-cf4c296f-fa7b-45b3-8fe8-2b5e87d916ad"/>
							<gml:surfaceMember xlink:href="#poly-79562f54-50c6-4f0a-9c5c-907ca78b4650"/>
							<gml:surfaceMember xlink:href="#poly-7bac8c73-b22e-447c-b7c5-d6c5e96dde87"/>
							<gml:surfaceMember xlink:href="#poly-45917e55-4fc8-495f-a2c1-5fe778f328cf"/>
							<gml:surfaceMember xlink:href="#poly-363eb02a-02b2-4b40-bfc7-538ad81a147a"/>
							<gml:surfaceMember xlink:href="#poly-6a739fa2-a343-4a47-a5f9-f1093c09f2e7"/>
							<gml:surfaceMember xlink:href="#poly-a2ef150d-963e-4bbc-9c6f-da9f6b89a962"/>
							<gml:surfaceMember xlink:href="#poly-97eb973e-1eba-4d1b-a5f8-1f4add109f80"/>
							<gml:surfaceMember xlink:href="#poly-0de7103b-d260-4c13-af81-a50cddd9aa2a"/>
							<gml:surfaceMember xlink:href="#poly-df5bdb34-5c71-4705-a8b2-0c850f830ece"/>
							<gml:surfaceMember xlink:href="#poly-8cf71f61-4ddc-4352-abe3-141f484e7a07"/>
							<gml:surfaceMember xlink:href="#poly-131483e3-fc69-4fd9-86b4-423355a7c7d7"/>
							<gml:surfaceMember xlink:href="#poly-fd3fd932-3900-412b-90e8-f325cb81703d"/>
							<gml:surfaceMember xlink:href="#poly-548509e9-1f7e-45a8-bfb3-49036c470365"/>
							<gml:surfaceMember xlink:href="#poly-46c7826c-ec60-49eb-9a1b-e09fcb520a1f"/>
							<gml:surfaceMember xlink:href="#poly-7a73411a-346c-46cf-a50b-2a29aa3227e3"/>
							<gml:surfaceMember xlink:href="#poly-e7954005-473f-4b2c-9327-d0e786f894cd"/>
							<gml:surfaceMember xlink:href="#poly-78e72cae-044e-40f4-88e8-db679e73a4c2"/>
							<gml:surfaceMember xlink:href="#poly-d22133c0-bb0f-4e39-b6e6-75abb703f86f"/>
							<gml:surfaceMember xlink:href="#poly-badd90a9-d81d-42aa-9167-8e317a725505"/>
							<gml:surfaceMember xlink:href="#poly-59330fa1-dcdf-4b6e-bc5b-33fa0eca3e33"/>
							<gml:surfaceMember xlink:href="#poly-7645451c-323d-491c-bd7a-44f2a87d974e"/>
							<gml:surfaceMember xlink:href="#poly-d75ccdf0-427e-42bf-adb8-1b59c5b5f705"/>
							<gml:surfaceMember xlink:href="#poly-410be005-eaf6-4fec-8474-0956064e11c1"/>
							<gml:surfaceMember xlink:href="#poly-73d9697d-d158-41a3-be4c-6abf1138d40b"/>
							<gml:surfaceMember xlink:href="#poly-a7a717e0-a596-484d-9a90-b00cbaac239b"/>
							<gml:surfaceMember xlink:href="#poly-823f5d24-0f67-47f3-8434-204ba2e50e44"/>
							<gml:surfaceMember xlink:href="#poly-d5bbb1df-5424-40e2-9d50-9cad2a19c85d"/>
							<gml:surfaceMember xlink:href="#poly-843da0aa-5b0e-4ac4-80a8-4acc08b4cfa7"/>
							<gml:surfaceMember xlink:href="#poly-a79f50d3-25c1-4659-9ed4-fd588e15a0f6"/>
							<gml:surfaceMember xlink:href="#poly-6df863f7-ed8d-4df2-9993-006b3d3cbcd2"/>
							<gml:surfaceMember xlink:href="#poly-9289daa9-9fb5-44a5-8425-c64411bed230"/>
							<gml:surfaceMember xlink:href="#poly-f35eaf95-9546-4e46-9a9e-3f24c3630720"/>
							<gml:surfaceMember xlink:href="#poly-da99f97b-8653-4888-9f10-43b498f6d004"/>
							<gml:surfaceMember xlink:href="#poly-fce7e4b9-f5b3-4602-a481-7cefe0f60988"/>
							<gml:surfaceMember xlink:href="#poly-958570ac-d6fd-4f48-ab59-e3f4e82697a3"/>
							<gml:surfaceMember xlink:href="#poly-7904adf0-a5df-4325-8567-ff5881220479"/>
							<gml:surfaceMember xlink:href="#poly-91b433a8-0285-4c75-8baa-1231f6c59cf2"/>
							<gml:surfaceMember xlink:href="#poly-2658b3c3-2ba7-4991-8a5e-33f28737ca84"/>
							<gml:surfaceMember xlink:href="#poly-1d22bbdd-e47d-4553-b36d-726417c49c2a"/>
							<gml:surfaceMember xlink:href="#poly-8ba84f5e-87ee-42a7-88e5-a474ea9a045d"/>
							<gml:surfaceMember xlink:href="#poly-fc736cb3-3b12-45d8-a56e-b834cbf844ef"/>
							<gml:surfaceMember xlink:href="#poly-377bee27-9352-4dee-bca1-33566feec61e"/>
							<gml:surfaceMember xlink:href="#poly-409b7a9a-0e19-476b-8a18-cf232b687836"/>
							<gml:surfaceMember xlink:href="#poly-1808e82f-cfd3-4519-91e7-94bea8717d3b"/>
							<gml:surfaceMember xlink:href="#poly-ef08e6ab-1744-468c-8358-3361adee0340"/>
							<gml:surfaceMember xlink:href="#poly-30826acf-b242-4a74-98d1-6856a3ba4a8e"/>
							<gml:surfaceMember xlink:href="#poly-c9884c70-2b1f-41e9-add0-1b4fb709dbf1"/>
							<gml:surfaceMember xlink:href="#poly-7755a5e1-11fe-40c3-bb83-68e9f3ec6ebb"/>
							<gml:surfaceMember xlink:href="#poly-614f9fa4-6466-42e4-90d5-be8966629246"/>
							<gml:surfaceMember xlink:href="#poly-f9ad4da7-8e98-4ea3-8055-1c53f005d152"/>
							<gml:surfaceMember xlink:href="#poly-18268e80-65f2-4ef1-b314-00de12285cec"/>
							<gml:surfaceMember xlink:href="#poly-fc353de6-26c7-4f60-9859-7b202cc2be8f"/>
							<gml:surfaceMember xlink:href="#poly-c6ded875-d8e4-421b-a413-cf6c3db693c5"/>
							<gml:surfaceMember xlink:href="#poly-3c45fa22-9e11-411f-8c3d-01c6a56bc94b"/>
							<gml:surfaceMember xlink:href="#poly-bddfda96-3ad2-480e-aa79-ef9369a09e97"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_cbd2efcf-4bd3-4966-b880-9e9e0f24c5f6_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63e8df3a-ce83-4f9f-8a7c-3738cd1fad11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6721077974732 139.73817266916663 29.982 35.672103215233236 139.7381571321848 29.982 35.6721179295029 139.73815061937563 29.982 35.67212251174371 139.73816615635994 29.982 35.6721077974732 139.73817266916663 29.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-709859bb-33e5-401c-8f7c-d53b926c9eaa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672091942087775 139.73821800070888 26.041 35.67210824221692 139.73821077905444 26.041 35.672115951607466 139.73823696115505 26.041 35.67209966048176 139.73824417174774 26.041 35.672091942087775 139.73821800070888 26.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-531f2a29-9397-4714-9c12-e18ced5589a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-531f2a29-9397-4714-9c12-e18ced5589a7_0">
											<gml:posList>35.672091942087775 139.73821800070888 26.041 35.67209966048176 139.73824417174774 26.041 35.67209966048176 139.73824417174774 27.998 35.672091942087775 139.73821800070888 27.998 35.672091942087775 139.73821800070888 26.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e31be53-0dde-49f6-a6d2-f2258957ed87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e31be53-0dde-49f6-a6d2-f2258957ed87_0">
											<gml:posList>35.67210824221692 139.73821077905444 26.041 35.672091942087775 139.73821800070888 26.041 35.672091942087775 139.73821800070888 27.998 35.67210824221692 139.73821077905444 27.998 35.67210824221692 139.73821077905444 26.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a5c876b-ef99-416b-83eb-267b4206b53c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a5c876b-ef99-416b-83eb-267b4206b53c_0">
											<gml:posList>35.672091942087775 139.73821800070888 27.998 35.67209966048176 139.73824417174774 27.998 35.672115951607466 139.73823696115505 27.998 35.67210824221692 139.73821077905444 27.998 35.672091942087775 139.73821800070888 27.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32d15427-1f10-4d2c-a207-395d4ddfa4d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32d15427-1f10-4d2c-a207-395d4ddfa4d8_0">
											<gml:posList>35.672103215233236 139.7381571321848 29.982 35.6721077974732 139.73817266916663 29.982 35.6721077974732 139.73817266916663 33.001 35.672103215233236 139.7381571321848 33.001 35.672103215233236 139.7381571321848 29.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43e79747-5fb9-4ffc-80f8-4d6cd5ab3d76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43e79747-5fb9-4ffc-80f8-4d6cd5ab3d76_0">
											<gml:posList>35.67209966048176 139.73824417174774 26.041 35.672115951607466 139.73823696115505 26.041 35.672115951607466 139.73823696115505 27.998 35.67209966048176 139.73824417174774 27.998 35.67209966048176 139.73824417174774 26.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-150cdba8-fd5a-4ea4-aab3-0b4e850de19d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-150cdba8-fd5a-4ea4-aab3-0b4e850de19d_0">
											<gml:posList>35.672103215233236 139.7381571321848 29.982 35.672103215233236 139.7381571321848 33.001 35.6721179295029 139.73815061937563 33.001 35.6721179295029 139.73815061937563 29.982 35.672103215233236 139.7381571321848 29.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c27b789-7cc6-4d2e-b814-d0e3d3133413">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c27b789-7cc6-4d2e-b814-d0e3d3133413_0">
											<gml:posList>35.672115951607466 139.73823696115505 26.041 35.67210824221692 139.73821077905444 26.041 35.67210824221692 139.73821077905444 27.998 35.672115951607466 139.73823696115505 27.998 35.672115951607466 139.73823696115505 26.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c79dc80a-81bf-4779-9a4c-a08564686164">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c79dc80a-81bf-4779-9a4c-a08564686164_0">
											<gml:posList>35.6721077974732 139.73817266916663 33.001 35.67212251174371 139.73816615635994 33.001 35.6721179295029 139.73815061937563 33.001 35.672103215233236 139.7381571321848 33.001 35.6721077974732 139.73817266916663 33.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-061e4973-2b80-49f1-9aff-3c8b5578fb6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-061e4973-2b80-49f1-9aff-3c8b5578fb6e_0">
											<gml:posList>35.6721077974732 139.73817266916663 29.982 35.67212251174371 139.73816615635994 29.982 35.67212251174371 139.73816615635994 33.001 35.6721077974732 139.73817266916663 33.001 35.6721077974732 139.73817266916663 29.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72638a57-d0b7-4cfe-9086-034f74486c44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72638a57-d0b7-4cfe-9086-034f74486c44_0">
											<gml:posList>35.67212251174371 139.73816615635994 29.982 35.6721179295029 139.73815061937563 29.982 35.6721179295029 139.73815061937563 33.001 35.67212251174371 139.73816615635994 33.001 35.67212251174371 139.73816615635994 29.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ea67d9cc-a200-499d-975b-a0a260803c51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea67d9cc-a200-499d-975b-a0a260803c51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea67d9cc-a200-499d-975b-a0a260803c51">
											<gml:posList>35.672026687150634 139.7381209905602 9.77 35.67210724158483 139.73808521470846 9.77 35.672163185694096 139.7382739330127 9.77 35.67208254106713 139.73830970880687 9.77 35.672026687150634 139.7381209905602 9.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6210deae-214b-4810-9a61-44ed0f7c8aa2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6210deae-214b-4810-9a61-44ed0f7c8aa2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6210deae-214b-4810-9a61-44ed0f7c8aa2">
											<gml:posList>35.67207220851932 139.73810077665084 24.546 35.672026687150634 139.7381209905602 24.546 35.672033239591066 139.73814310889196 25.727 35.67207887808065 139.738122817529 25.727 35.67207220851932 139.73810077665084 24.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc1bee52-700f-4e45-a438-274f0d641a4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc1bee52-700f-4e45-a438-274f0d641a4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc1bee52-700f-4e45-a438-274f0d641a4e">
											<gml:posList>35.67207647668864 139.73828922475022 26.516 35.6720780328359 139.73828513570294 26.516 35.672036567164355 139.73814501598338 26.516 35.672033239591066 139.73814310889196 26.516 35.67207647668864 139.73828922475022 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41ed1102-1f7d-4fc8-95f2-4a4eb5ab377d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41ed1102-1f7d-4fc8-95f2-4a4eb5ab377d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41ed1102-1f7d-4fc8-95f2-4a4eb5ab377d">
											<gml:posList>35.67207887808065 139.738122817529 26.516 35.672033239591066 139.73814310889196 26.516 35.672036567164355 139.73814501598338 26.516 35.6720822236904 139.73812473564573 26.516 35.67207887808065 139.738122817529 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5380d67b-c9d6-436e-9013-7f801514d395">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5380d67b-c9d6-436e-9013-7f801514d395">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5380d67b-c9d6-436e-9013-7f801514d395">
											<gml:posList>35.67207887808065 139.738122817529 26.516 35.6720822236904 139.73812473564573 26.516 35.672075554111956 139.73810267267356 26.516 35.67207220851932 139.73810077665084 26.516 35.67207887808065 139.738122817529 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf4c296f-fa7b-45b3-8fe8-2b5e87d916ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf4c296f-fa7b-45b3-8fe8-2b5e87d916ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf4c296f-fa7b-45b3-8fe8-2b5e87d916ad">
											<gml:posList>35.6720822236904 139.73812473564573 26.041 35.672036567164355 139.73814501598338 26.041 35.6720780328359 139.73828513570294 26.041 35.67212198059062 139.7382354406334 26.041 35.67208199666738 139.73809981502558 26.041 35.672075554111956 139.73810267267356 26.041 35.6720822236904 139.73812473564573 26.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79562f54-50c6-4f0a-9c5c-907ca78b4650">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79562f54-50c6-4f0a-9c5c-907ca78b4650">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79562f54-50c6-4f0a-9c5c-907ca78b4650">
											<gml:posList>35.67208407922252 139.738305663967 23.199 35.672078900533435 139.7382881503669 23.199 35.67207647668864 139.73828922475022 23.199 35.67208254106713 139.73830970880687 23.199 35.67208407922252 139.738305663967 23.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7bac8c73-b22e-447c-b7c5-d6c5e96dde87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bac8c73-b22e-447c-b7c5-d6c5e96dde87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bac8c73-b22e-447c-b7c5-d6c5e96dde87">
											<gml:posList>35.67210724158483 139.73808521470846 26.516 35.67207220851932 139.73810077665084 26.516 35.672075554111956 139.73810267267356 26.516 35.67208199666738 139.73809981502558 26.516 35.67208184302353 139.7380992960229 26.516 35.6721047569002 139.73808913916673 26.516 35.67210724158483 139.73808521470846 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45917e55-4fc8-495f-a2c1-5fe778f328cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45917e55-4fc8-495f-a2c1-5fe778f328cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45917e55-4fc8-495f-a2c1-5fe778f328cf">
											<gml:posList>35.67208184302353 139.7380992960229 28.538 35.6720975510112 139.73815257670628 28.538 35.67209961442822 139.7381516573974 28.538 35.67208465657957 139.7381009054689 28.538 35.67208184302353 139.7380992960229 28.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-363eb02a-02b2-4b40-bfc7-538ad81a147a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-363eb02a-02b2-4b40-bfc7-538ad81a147a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-363eb02a-02b2-4b40-bfc7-538ad81a147a">
											<gml:posList>35.67208465657957 139.7381009054689 28.538 35.67210344361453 139.73809257618734 28.538 35.6721047569002 139.73808913916673 28.538 35.67208184302353 139.7380992960229 28.538 35.67208465657957 139.7381009054689 28.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a739fa2-a343-4a47-a5f9-f1093c09f2e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a739fa2-a343-4a47-a5f9-f1093c09f2e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a739fa2-a343-4a47-a5f9-f1093c09f2e7">
											<gml:posList>35.67210344361453 139.73809257618734 28.204 35.67208465657957 139.7381009054689 28.204 35.67209961442822 139.7381516573974 28.204 35.6721184104891 139.73814333916195 28.204 35.67210344361453 139.73809257618734 28.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2ef150d-963e-4bbc-9c6f-da9f6b89a962">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2ef150d-963e-4bbc-9c6f-da9f6b89a962">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2ef150d-963e-4bbc-9c6f-da9f6b89a962">
											<gml:posList>35.67209967020452 139.73815380035143 30.126 35.6720975510112 139.73815257670628 30.126 35.67210645340284 139.73818277830676 30.126 35.67210745187433 139.7381801811949 30.126 35.67209967020452 139.73815380035143 30.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97eb973e-1eba-4d1b-a5f8-1f4add109f80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97eb973e-1eba-4d1b-a5f8-1f4add109f80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97eb973e-1eba-4d1b-a5f8-1f4add109f80">
											<gml:posList>35.67212047390604 139.7381424198526 30.126 35.6720975510112 139.73815257670628 30.126 35.67209967020452 139.73815380035143 30.126 35.672119484449084 139.73814501695466 30.126 35.67212047390604 139.7381424198526 30.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0de7103b-d260-4c13-af81-a50cddd9aa2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0de7103b-d260-4c13-af81-a50cddd9aa2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0de7103b-d260-4c13-af81-a50cddd9aa2a">
											<gml:posList>35.67210344361453 139.73809257618734 28.538 35.6721184104891 139.73814333916195 28.538 35.67212047390604 139.7381424198526 28.538 35.6721047569002 139.73808913916673 28.538 35.67210344361453 139.73809257618734 28.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df5bdb34-5c71-4705-a8b2-0c850f830ece">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df5bdb34-5c71-4705-a8b2-0c850f830ece">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df5bdb34-5c71-4705-a8b2-0c850f830ece">
											<gml:posList>35.672119484449084 139.73814501695466 29.982 35.67209967020452 139.73815380035143 29.982 35.67210745187433 139.7381801811949 29.982 35.67212726612082 139.7381713978038 29.982 35.672119484449084 139.73814501695466 29.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8cf71f61-4ddc-4352-abe3-141f484e7a07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cf71f61-4ddc-4352-abe3-141f484e7a07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cf71f61-4ddc-4352-abe3-141f484e7a07">
											<gml:posList>35.67212359073109 139.7382312410537 28.538 35.67210896734893 139.73818165962695 28.538 35.67210645340284 139.73818277830676 28.538 35.67212198059062 139.7382354406334 28.538 35.67212359073109 139.7382312410537 28.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-131483e3-fc69-4fd9-86b4-423355a7c7d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-131483e3-fc69-4fd9-86b4-423355a7c7d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-131483e3-fc69-4fd9-86b4-423355a7c7d7">
											<gml:posList>35.6720780328359 139.73828513570294 26.041 35.67215376664457 139.73825147559248 26.041 35.672144903501106 139.73822529484679 26.041 35.67212198059062 139.7382354406334 26.041 35.6720780328359 139.73828513570294 26.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fd3fd932-3900-412b-90e8-f325cb81703d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd3fd932-3900-412b-90e8-f325cb81703d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd3fd932-3900-412b-90e8-f325cb81703d">
											<gml:posList>35.67215710323852 139.73825339372706 26.516 35.67215376664457 139.73825147559248 26.516 35.6720780328359 139.73828513570294 26.516 35.67207647668864 139.73828922475022 26.516 35.67215710323852 139.73825339372706 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-548509e9-1f7e-45a8-bfb3-49036c470365">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-548509e9-1f7e-45a8-bfb3-49036c470365">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-548509e9-1f7e-45a8-bfb3-49036c470365">
											<gml:posList>35.67210745187433 139.7381801811949 30.126 35.67210645340284 139.73818277830676 30.126 35.67212937630021 139.73817262146062 30.126 35.67212726612082 139.7381713978038 30.126 35.67210745187433 139.7381801811949 30.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46c7826c-ec60-49eb-9a1b-e09fcb520a1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46c7826c-ec60-49eb-9a1b-e09fcb520a1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46c7826c-ec60-49eb-9a1b-e09fcb520a1f">
											<gml:posList>35.672078900533435 139.7382881503669 23.075 35.67208407922252 139.738305663967 23.075 35.672159894195225 139.7382720479631 23.075 35.67215468840781 139.73825446810181 23.075 35.672078900533435 139.7382881503669 23.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a73411a-346c-46cf-a50b-2a29aa3227e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a73411a-346c-46cf-a50b-2a29aa3227e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a73411a-346c-46cf-a50b-2a29aa3227e3">
											<gml:posList>35.67208254106713 139.73830970880687 23.199 35.672163185694096 139.7382739330127 23.199 35.672159894195225 139.7382720479631 23.199 35.67208407922252 139.738305663967 23.199 35.67208254106713 139.73830970880687 23.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e7954005-473f-4b2c-9327-d0e786f894cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7954005-473f-4b2c-9327-d0e786f894cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7954005-473f-4b2c-9327-d0e786f894cd">
											<gml:posList>35.672119484449084 139.73814501695466 30.126 35.67212726612082 139.7381713978038 30.126 35.67212937630021 139.73817262146062 30.126 35.67212047390604 139.7381424198526 30.126 35.672119484449084 139.73814501695466 30.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78e72cae-044e-40f4-88e8-db679e73a4c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78e72cae-044e-40f4-88e8-db679e73a4c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78e72cae-044e-40f4-88e8-db679e73a4c2">
											<gml:posList>35.67210896734893 139.73818165962695 28.349 35.67212359073109 139.7382312410537 28.349 35.672141476725876 139.73822332158812 28.349 35.67212686235421 139.73817374014104 28.349 35.67210896734893 139.73818165962695 28.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d22133c0-bb0f-4e39-b6e6-75abb703f86f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d22133c0-bb0f-4e39-b6e6-75abb703f86f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d22133c0-bb0f-4e39-b6e6-75abb703f86f">
											<gml:posList>35.672105676430654 139.73808930377177 26.041 35.67210491053537 139.73808964712308 26.041 35.672144903501106 139.73822529484679 26.041 35.67215376664457 139.73825147559248 26.041 35.672105676430654 139.73808930377177 26.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-badd90a9-d81d-42aa-9167-8e317a725505">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-badd90a9-d81d-42aa-9167-8e317a725505">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-badd90a9-d81d-42aa-9167-8e317a725505">
											<gml:posList>35.672105676430654 139.73808930377177 26.516 35.67215376664457 139.73825147559248 26.516 35.67215710323852 139.73825339372706 26.516 35.67210724158483 139.73808521470846 26.516 35.6721047569002 139.73808913916673 26.516 35.67210491053537 139.73808964712308 26.516 35.672105676430654 139.73808930377177 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-59330fa1-dcdf-4b6e-bc5b-33fa0eca3e33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59330fa1-dcdf-4b6e-bc5b-33fa0eca3e33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59330fa1-dcdf-4b6e-bc5b-33fa0eca3e33">
											<gml:posList>35.672141476725876 139.73822332158812 28.538 35.67212359073109 139.7382312410537 28.538 35.67212198059062 139.7382354406334 28.538 35.672144903501106 139.73822529484679 28.538 35.672141476725876 139.73822332158812 28.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7645451c-323d-491c-bd7a-44f2a87d974e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7645451c-323d-491c-bd7a-44f2a87d974e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7645451c-323d-491c-bd7a-44f2a87d974e">
											<gml:posList>35.672144903501106 139.73822529484679 28.538 35.67212937630021 139.73817262146062 28.538 35.67212686235421 139.73817374014104 28.538 35.672141476725876 139.73822332158812 28.538 35.672144903501106 139.73822529484679 28.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d75ccdf0-427e-42bf-adb8-1b59c5b5f705">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d75ccdf0-427e-42bf-adb8-1b59c5b5f705">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d75ccdf0-427e-42bf-adb8-1b59c5b5f705">
											<gml:posList>35.67215710323852 139.73825339372706 23.199 35.67215468840781 139.73825446810181 23.199 35.672159894195225 139.7382720479631 23.199 35.672163185694096 139.7382739330127 23.199 35.67215710323852 139.73825339372706 23.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-410be005-eaf6-4fec-8474-0956064e11c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-410be005-eaf6-4fec-8474-0956064e11c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-410be005-eaf6-4fec-8474-0956064e11c1">
											<gml:posList>35.67210344361453 139.73809257618734 28.204 35.6721184104891 139.73814333916195 28.204 35.6721184104891 139.73814333916195 28.538 35.67210344361453 139.73809257618734 28.538 35.67210344361453 139.73809257618734 28.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73d9697d-d158-41a3-be4c-6abf1138d40b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73d9697d-d158-41a3-be4c-6abf1138d40b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73d9697d-d158-41a3-be4c-6abf1138d40b">
											<gml:posList>35.672119484449084 139.73814501695466 29.982 35.67212726612082 139.7381713978038 29.982 35.67212726612082 139.7381713978038 30.126 35.672119484449084 139.73814501695466 30.126 35.672119484449084 139.73814501695466 29.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7a717e0-a596-484d-9a90-b00cbaac239b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7a717e0-a596-484d-9a90-b00cbaac239b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7a717e0-a596-484d-9a90-b00cbaac239b">
											<gml:posList>35.67210745187433 139.7381801811949 29.982 35.67209967020452 139.73815380035143 29.982 35.67209967020452 139.73815380035143 30.126 35.67210745187433 139.7381801811949 30.126 35.67210745187433 139.7381801811949 29.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-823f5d24-0f67-47f3-8434-204ba2e50e44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-823f5d24-0f67-47f3-8434-204ba2e50e44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-823f5d24-0f67-47f3-8434-204ba2e50e44">
											<gml:posList>35.67212359073109 139.7382312410537 28.349 35.67210896734893 139.73818165962695 28.349 35.67210896734893 139.73818165962695 28.538 35.67212359073109 139.7382312410537 28.538 35.67212359073109 139.7382312410537 28.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5bbb1df-5424-40e2-9d50-9cad2a19c85d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5bbb1df-5424-40e2-9d50-9cad2a19c85d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5bbb1df-5424-40e2-9d50-9cad2a19c85d">
											<gml:posList>35.672026687150634 139.7381209905602 9.77 35.67208254106713 139.73830970880687 9.77 35.67208254106713 139.73830970880687 23.199 35.67207647668864 139.73828922475022 23.199 35.67207647668864 139.73828922475022 26.516 35.672033239591066 139.73814310889196 26.516 35.672033239591066 139.73814310889196 25.727 35.672026687150634 139.7381209905602 24.546 35.672026687150634 139.7381209905602 9.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-843da0aa-5b0e-4ac4-80a8-4acc08b4cfa7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-843da0aa-5b0e-4ac4-80a8-4acc08b4cfa7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-843da0aa-5b0e-4ac4-80a8-4acc08b4cfa7">
											<gml:posList>35.672033239591066 139.73814310889196 25.727 35.672033239591066 139.73814310889196 26.516 35.67207887808065 139.738122817529 26.516 35.67207887808065 139.738122817529 25.727 35.672033239591066 139.73814310889196 25.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a79f50d3-25c1-4659-9ed4-fd588e15a0f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a79f50d3-25c1-4659-9ed4-fd588e15a0f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a79f50d3-25c1-4659-9ed4-fd588e15a0f6">
											<gml:posList>35.672036567164355 139.73814501598338 26.516 35.6720780328359 139.73828513570294 26.516 35.6720780328359 139.73828513570294 26.041 35.672036567164355 139.73814501598338 26.041 35.672036567164355 139.73814501598338 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6df863f7-ed8d-4df2-9993-006b3d3cbcd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6df863f7-ed8d-4df2-9993-006b3d3cbcd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6df863f7-ed8d-4df2-9993-006b3d3cbcd2">
											<gml:posList>35.6720822236904 139.73812473564573 26.516 35.672036567164355 139.73814501598338 26.516 35.672036567164355 139.73814501598338 26.041 35.6720822236904 139.73812473564573 26.041 35.6720822236904 139.73812473564573 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9289daa9-9fb5-44a5-8425-c64411bed230">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9289daa9-9fb5-44a5-8425-c64411bed230">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9289daa9-9fb5-44a5-8425-c64411bed230">
											<gml:posList>35.67210724158483 139.73808521470846 26.516 35.67210724158483 139.73808521470846 9.77 35.672026687150634 139.7381209905602 9.77 35.672026687150634 139.7381209905602 24.546 35.67207220851932 139.73810077665084 24.546 35.67207220851932 139.73810077665084 26.516 35.67210724158483 139.73808521470846 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f35eaf95-9546-4e46-9a9e-3f24c3630720">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f35eaf95-9546-4e46-9a9e-3f24c3630720">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f35eaf95-9546-4e46-9a9e-3f24c3630720">
											<gml:posList>35.67207887808065 139.738122817529 25.727 35.67207887808065 139.738122817529 26.516 35.67207220851932 139.73810077665084 26.516 35.67207220851932 139.73810077665084 24.546 35.67207887808065 139.738122817529 25.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da99f97b-8653-4888-9f10-43b498f6d004">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da99f97b-8653-4888-9f10-43b498f6d004">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da99f97b-8653-4888-9f10-43b498f6d004">
											<gml:posList>35.672075554111956 139.73810267267356 26.516 35.672075554111956 139.73810267267356 26.041 35.67208199666738 139.73809981502558 26.041 35.67208199666738 139.73809981502558 26.516 35.672075554111956 139.73810267267356 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fce7e4b9-f5b3-4602-a481-7cefe0f60988">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fce7e4b9-f5b3-4602-a481-7cefe0f60988">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fce7e4b9-f5b3-4602-a481-7cefe0f60988">
											<gml:posList>35.6720822236904 139.73812473564573 26.041 35.672075554111956 139.73810267267356 26.041 35.672075554111956 139.73810267267356 26.516 35.6720822236904 139.73812473564573 26.516 35.6720822236904 139.73812473564573 26.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-958570ac-d6fd-4f48-ab59-e3f4e82697a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-958570ac-d6fd-4f48-ab59-e3f4e82697a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-958570ac-d6fd-4f48-ab59-e3f4e82697a3">
											<gml:posList>35.67208407922252 139.738305663967 23.075 35.672078900533435 139.7382881503669 23.075 35.672078900533435 139.7382881503669 23.199 35.67208407922252 139.738305663967 23.199 35.67208407922252 139.738305663967 23.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7904adf0-a5df-4325-8567-ff5881220479">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7904adf0-a5df-4325-8567-ff5881220479">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7904adf0-a5df-4325-8567-ff5881220479">
											<gml:posList>35.67209961442822 139.7381516573974 28.204 35.67208465657957 139.7381009054689 28.204 35.67208465657957 139.7381009054689 28.538 35.67209961442822 139.7381516573974 28.538 35.67209961442822 139.7381516573974 28.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91b433a8-0285-4c75-8baa-1231f6c59cf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91b433a8-0285-4c75-8baa-1231f6c59cf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91b433a8-0285-4c75-8baa-1231f6c59cf2">
											<gml:posList>35.67208184302353 139.7380992960229 28.538 35.6721047569002 139.73808913916673 28.538 35.6721047569002 139.73808913916673 26.516 35.67208184302353 139.7380992960229 26.516 35.67208184302353 139.7380992960229 28.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2658b3c3-2ba7-4991-8a5e-33f28737ca84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2658b3c3-2ba7-4991-8a5e-33f28737ca84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2658b3c3-2ba7-4991-8a5e-33f28737ca84">
											<gml:posList>35.67208465657957 139.7381009054689 28.204 35.67210344361453 139.73809257618734 28.204 35.67210344361453 139.73809257618734 28.538 35.67208465657957 139.7381009054689 28.538 35.67208465657957 139.7381009054689 28.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d22bbdd-e47d-4553-b36d-726417c49c2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d22bbdd-e47d-4553-b36d-726417c49c2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d22bbdd-e47d-4553-b36d-726417c49c2a">
											<gml:posList>35.67208199666738 139.73809981502558 26.516 35.67208199666738 139.73809981502558 26.041 35.67212198059062 139.7382354406334 26.041 35.67212198059062 139.7382354406334 28.538 35.67210645340284 139.73818277830676 28.538 35.67210645340284 139.73818277830676 30.126 35.6720975510112 139.73815257670628 30.126 35.6720975510112 139.73815257670628 28.538 35.67208184302353 139.7380992960229 28.538 35.67208184302353 139.7380992960229 26.516 35.67208199666738 139.73809981502558 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ba84f5e-87ee-42a7-88e5-a474ea9a045d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ba84f5e-87ee-42a7-88e5-a474ea9a045d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ba84f5e-87ee-42a7-88e5-a474ea9a045d">
											<gml:posList>35.672105676430654 139.73808930377177 26.041 35.672105676430654 139.73808930377177 26.516 35.67210491053537 139.73808964712308 26.516 35.67210491053537 139.73808964712308 26.041 35.672105676430654 139.73808930377177 26.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc736cb3-3b12-45d8-a56e-b834cbf844ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc736cb3-3b12-45d8-a56e-b834cbf844ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc736cb3-3b12-45d8-a56e-b834cbf844ef">
											<gml:posList>35.6720975510112 139.73815257670628 30.126 35.67212047390604 139.7381424198526 30.126 35.67212047390604 139.7381424198526 28.538 35.6721184104891 139.73814333916195 28.538 35.6721184104891 139.73814333916195 28.204 35.67209961442822 139.7381516573974 28.204 35.67209961442822 139.7381516573974 28.538 35.6720975510112 139.73815257670628 28.538 35.6720975510112 139.73815257670628 30.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-377bee27-9352-4dee-bca1-33566feec61e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-377bee27-9352-4dee-bca1-33566feec61e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-377bee27-9352-4dee-bca1-33566feec61e">
											<gml:posList>35.67209967020452 139.73815380035143 29.982 35.672119484449084 139.73814501695466 29.982 35.672119484449084 139.73814501695466 30.126 35.67209967020452 139.73815380035143 30.126 35.67209967020452 139.73815380035143 29.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-409b7a9a-0e19-476b-8a18-cf232b687836">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-409b7a9a-0e19-476b-8a18-cf232b687836">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-409b7a9a-0e19-476b-8a18-cf232b687836">
											<gml:posList>35.6720780328359 139.73828513570294 26.516 35.67215376664457 139.73825147559248 26.516 35.67215376664457 139.73825147559248 26.041 35.6720780328359 139.73828513570294 26.041 35.6720780328359 139.73828513570294 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1808e82f-cfd3-4519-91e7-94bea8717d3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1808e82f-cfd3-4519-91e7-94bea8717d3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1808e82f-cfd3-4519-91e7-94bea8717d3b">
											<gml:posList>35.67215710323852 139.73825339372706 26.516 35.67207647668864 139.73828922475022 26.516 35.67207647668864 139.73828922475022 23.199 35.672078900533435 139.7382881503669 23.199 35.672078900533435 139.7382881503669 23.075 35.67215468840781 139.73825446810181 23.075 35.67215468840781 139.73825446810181 23.199 35.67215710323852 139.73825339372706 23.199 35.67215710323852 139.73825339372706 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef08e6ab-1744-468c-8358-3361adee0340">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef08e6ab-1744-468c-8358-3361adee0340">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef08e6ab-1744-468c-8358-3361adee0340">
											<gml:posList>35.67212726612082 139.7381713978038 29.982 35.67210745187433 139.7381801811949 29.982 35.67210745187433 139.7381801811949 30.126 35.67212726612082 139.7381713978038 30.126 35.67212726612082 139.7381713978038 29.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30826acf-b242-4a74-98d1-6856a3ba4a8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30826acf-b242-4a74-98d1-6856a3ba4a8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30826acf-b242-4a74-98d1-6856a3ba4a8e">
											<gml:posList>35.67212686235421 139.73817374014104 28.538 35.67212937630021 139.73817262146062 28.538 35.67212937630021 139.73817262146062 30.126 35.67210645340284 139.73818277830676 30.126 35.67210645340284 139.73818277830676 28.538 35.67210896734893 139.73818165962695 28.538 35.67210896734893 139.73818165962695 28.349 35.67212686235421 139.73817374014104 28.349 35.67212686235421 139.73817374014104 28.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9884c70-2b1f-41e9-add0-1b4fb709dbf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9884c70-2b1f-41e9-add0-1b4fb709dbf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9884c70-2b1f-41e9-add0-1b4fb709dbf1">
											<gml:posList>35.67208407922252 139.738305663967 23.199 35.672159894195225 139.7382720479631 23.199 35.672159894195225 139.7382720479631 23.075 35.67208407922252 139.738305663967 23.075 35.67208407922252 139.738305663967 23.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7755a5e1-11fe-40c3-bb83-68e9f3ec6ebb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7755a5e1-11fe-40c3-bb83-68e9f3ec6ebb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7755a5e1-11fe-40c3-bb83-68e9f3ec6ebb">
											<gml:posList>35.67208254106713 139.73830970880687 9.77 35.672163185694096 139.7382739330127 9.77 35.672163185694096 139.7382739330127 23.199 35.67208254106713 139.73830970880687 23.199 35.67208254106713 139.73830970880687 9.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-614f9fa4-6466-42e4-90d5-be8966629246">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-614f9fa4-6466-42e4-90d5-be8966629246">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-614f9fa4-6466-42e4-90d5-be8966629246">
											<gml:posList>35.67210491053537 139.73808964712308 26.516 35.6721047569002 139.73808913916673 26.516 35.6721047569002 139.73808913916673 28.538 35.67212047390604 139.7381424198526 28.538 35.67212047390604 139.7381424198526 30.126 35.67212937630021 139.73817262146062 30.126 35.67212937630021 139.73817262146062 28.538 35.672144903501106 139.73822529484679 28.538 35.672144903501106 139.73822529484679 26.041 35.67210491053537 139.73808964712308 26.041 35.67210491053537 139.73808964712308 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9ad4da7-8e98-4ea3-8055-1c53f005d152">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9ad4da7-8e98-4ea3-8055-1c53f005d152">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9ad4da7-8e98-4ea3-8055-1c53f005d152">
											<gml:posList>35.672105676430654 139.73808930377177 26.041 35.67215376664457 139.73825147559248 26.041 35.67215376664457 139.73825147559248 26.516 35.672105676430654 139.73808930377177 26.516 35.672105676430654 139.73808930377177 26.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18268e80-65f2-4ef1-b314-00de12285cec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18268e80-65f2-4ef1-b314-00de12285cec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18268e80-65f2-4ef1-b314-00de12285cec">
											<gml:posList>35.672141476725876 139.73822332158812 28.349 35.67212359073109 139.7382312410537 28.349 35.67212359073109 139.7382312410537 28.538 35.672141476725876 139.73822332158812 28.538 35.672141476725876 139.73822332158812 28.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc353de6-26c7-4f60-9859-7b202cc2be8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc353de6-26c7-4f60-9859-7b202cc2be8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc353de6-26c7-4f60-9859-7b202cc2be8f">
											<gml:posList>35.672144903501106 139.73822529484679 28.538 35.67212198059062 139.7382354406334 28.538 35.67212198059062 139.7382354406334 26.041 35.672144903501106 139.73822529484679 26.041 35.672144903501106 139.73822529484679 28.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6ded875-d8e4-421b-a413-cf6c3db693c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6ded875-d8e4-421b-a413-cf6c3db693c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6ded875-d8e4-421b-a413-cf6c3db693c5">
											<gml:posList>35.67212686235421 139.73817374014104 28.349 35.672141476725876 139.73822332158812 28.349 35.672141476725876 139.73822332158812 28.538 35.67212686235421 139.73817374014104 28.538 35.67212686235421 139.73817374014104 28.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c45fa22-9e11-411f-8c3d-01c6a56bc94b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c45fa22-9e11-411f-8c3d-01c6a56bc94b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c45fa22-9e11-411f-8c3d-01c6a56bc94b">
											<gml:posList>35.67210724158483 139.73808521470846 26.516 35.67215710323852 139.73825339372706 26.516 35.67215710323852 139.73825339372706 23.199 35.672163185694096 139.7382739330127 23.199 35.672163185694096 139.7382739330127 9.77 35.67210724158483 139.73808521470846 9.77 35.67210724158483 139.73808521470846 26.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bddfda96-3ad2-480e-aa79-ef9369a09e97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bddfda96-3ad2-480e-aa79-ef9369a09e97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bddfda96-3ad2-480e-aa79-ef9369a09e97">
											<gml:posList>35.67215468840781 139.73825446810181 23.075 35.672159894195225 139.7382720479631 23.075 35.672159894195225 139.7382720479631 23.199 35.67215468840781 139.73825446810181 23.199 35.67215468840781 139.73825446810181 23.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10672</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">172.8476</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>