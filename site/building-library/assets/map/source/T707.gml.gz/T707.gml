<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cbff0d63-b11d-4353-8cc1-58a8fba9fa34">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667821127342776 139.74339014343698 0 35.66783231561375 139.74335692688553 0 35.66781631018123 139.74334882610407 0 35.66780511289871 139.74338204266013 0 35.667821127342776 139.74339014343698 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667821127342776 139.74339014343698 27.4 35.66780511289871 139.74338204266013 27.4 35.66781631018123 139.74334882610407 27.4 35.66783231561375 139.74335692688553 27.4 35.667821127342776 139.74339014343698 27.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667821127342776 139.74339014343698 27.4 35.66783231561375 139.74335692688553 27.4 35.66783231561375 139.74335692688553 31.43 35.667821127342776 139.74339014343698 31.43 35.667821127342776 139.74339014343698 27.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66783231561375 139.74335692688553 27.4 35.66781631018123 139.74334882610407 27.4 35.66781631018123 139.74334882610407 31.43 35.66783231561375 139.74335692688553 31.43 35.66783231561375 139.74335692688553 27.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66781631018123 139.74334882610407 27.4 35.66780511289871 139.74338204266013 27.4 35.66780511289871 139.74338204266013 31.43 35.66781631018123 139.74334882610407 31.43 35.66781631018123 139.74334882610407 27.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66780511289871 139.74338204266013 27.4 35.667821127342776 139.74339014343698 27.4 35.667821127342776 139.74339014343698 31.43 35.66780511289871 139.74338204266013 31.43 35.66780511289871 139.74338204266013 27.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667821127342776 139.74339014343698 31.43 35.66783231561375 139.74335692688553 31.43 35.66781631018123 139.74334882610407 31.43 35.66780511289871 139.74338204266013 31.43 35.667821127342776 139.74339014343698 31.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fdf1fff1-6749-4b95-94c1-2de65ea49e8f"/>
							<gml:surfaceMember xlink:href="#poly-5f587c49-78a9-41f5-9402-8698a0ded34b"/>
							<gml:surfaceMember xlink:href="#poly-31d681b3-3f78-407f-8978-3b2082090f99"/>
							<gml:surfaceMember xlink:href="#poly-65132fc6-f015-489a-a252-6adaa9b3e9ff"/>
							<gml:surfaceMember xlink:href="#poly-cab96f15-5e88-4ad9-bc16-95f7b1ef5c3b"/>
							<gml:surfaceMember xlink:href="#poly-8be09fb9-bbca-46fc-9949-92881ebd6049"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_cbff0d63-b11d-4353-8cc1-58a8fba9fa34_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aaa81a72-ed31-42f0-b7ad-23c56c1fc998">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66781163095682 139.7433714865081 31.069 35.66781145008811 139.7433706914058 31.069 35.66781133230723 139.7433698851868 31.069 35.66781126860871 139.74336907890714 31.069 35.667811258976045 139.74336825047502 31.069 35.66781131244772 139.743367433018 31.069 35.66781142902373 139.74336662653604 31.069 35.66781159969035 139.74336583103934 31.069 35.66781181544211 139.74336505758387 31.069 35.66781209431472 139.74336431719527 31.069 35.66781242729443 139.7433636098837 31.069 35.66781280535929 139.74336292461334 31.069 35.667813237547776 139.7433622945117 31.069 35.66781370582418 139.74336170855327 31.069 35.667814210196745 139.74336117778387 31.069 35.66781475967923 139.74336070219334 31.069 35.66781533625241 139.74336029284785 31.069 35.66781593990804 139.7433599387015 31.069 35.66781656164062 139.7433596508103 31.069 35.667817210463916 139.74335942916414 31.069 35.66781786835872 139.74335928482913 31.069 35.66781853531676 139.7433592067594 31.069 35.66781920232433 139.74335919496505 31.069 35.66781986938967 139.743359260492 31.069 35.667820527499046 139.74335940335035 31.069 35.66782117663597 139.7433596014483 31.069 35.667821807803215 139.74335987688775 31.069 35.6678224119788 139.74336021863297 31.069 35.66782299817643 139.7433606266738 31.069 35.66782354836043 139.74336108998455 31.069 35.66782406253903 139.74336161961116 31.069 35.66782454069575 139.74336219346188 31.069 35.66782497381683 139.74336281154672 31.069 35.66782536191054 139.74336348491164 31.069 35.66782570496036 139.74336419146485 31.069 35.667825993952576 139.74336493121638 31.069 35.667826219865205 139.74336569313058 31.069 35.66782640073395 139.74336648823302 31.069 35.66782651851485 139.74336729445213 31.069 35.66782658222163 139.74336811177784 31.069 35.667826591846044 139.74336892916423 31.069 35.667826538374364 139.74336974662143 31.069 35.667826430812056 139.74337055309337 31.069 35.667826260145404 139.74337134859022 31.069 35.66782603537988 139.74337212205594 31.069 35.66782575650722 139.74337286244463 31.069 35.6678254235357 139.7433735808022 31.069 35.667825045462536 139.74337425502674 31.069 35.66782462228772 139.74337488511824 31.069 35.66782415401125 139.7433754710767 31.069 35.66782364062488 139.7433760018562 31.069 35.66782310015608 139.74337647743656 31.069 35.66782252359109 139.74337689782786 31.069 35.66782191993543 139.74337725197412 31.069 35.66782128918081 139.7433775288294 31.069 35.6678206493712 139.74337775046533 31.069 35.667819991476385 139.74337789480018 31.069 35.66781932452658 139.74337798391565 31.069 35.66781864849703 139.74337798467405 31.069 35.667817990445435 139.74337791913686 31.069 35.667817323322346 139.74337777628847 31.069 35.66781668319918 139.74337757818026 31.069 35.66781604301825 139.7433773027508 31.069 35.667815438842716 139.74337696100548 31.069 35.66781485264513 139.7433765529646 31.069 35.667814302461196 139.74337608965376 31.069 35.6678137882909 139.743375571073 31.069 35.66781331914798 139.74337499721221 31.069 35.667812877004984 139.7433743680916 31.069 35.66781248891959 139.74337370577263 31.069 35.667812154883556 139.7433729992094 31.069 35.66781186588313 139.74337224841202 31.069 35.66781163095682 139.7433714865081 31.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a34506f6-2f48-4196-9ed9-1a278c3000db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a34506f6-2f48-4196-9ed9-1a278c3000db_0">
											<gml:posList>35.66781920232433 139.74335919496505 32.836 35.66781920232433 139.74335919496505 31.069 35.66781853531676 139.7433592067594 31.069 35.66781853531676 139.7433592067594 32.836 35.66781920232433 139.74335919496505 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80a3a795-acae-457c-bac3-aed64763d7b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80a3a795-acae-457c-bac3-aed64763d7b2_0">
											<gml:posList>35.66781986938967 139.743359260492 32.836 35.66781986938967 139.743359260492 31.069 35.66781920232433 139.74335919496505 31.069 35.66781920232433 139.74335919496505 32.836 35.66781986938967 139.743359260492 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-566e9306-a631-422a-83c4-762348b284f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-566e9306-a631-422a-83c4-762348b284f1_0">
											<gml:posList>35.66781853531676 139.7433592067594 32.836 35.66781853531676 139.7433592067594 31.069 35.66781786835872 139.74335928482913 31.069 35.66781786835872 139.74335928482913 32.836 35.66781853531676 139.7433592067594 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-297f7366-dbd3-4f55-a2ca-424abce07853">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-297f7366-dbd3-4f55-a2ca-424abce07853_0">
											<gml:posList>35.667820527499046 139.74335940335035 32.836 35.667820527499046 139.74335940335035 31.069 35.66781986938967 139.743359260492 31.069 35.66781986938967 139.743359260492 32.836 35.667820527499046 139.74335940335035 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ded605c-3cd7-42ff-9294-fbd94877eec2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ded605c-3cd7-42ff-9294-fbd94877eec2_0">
											<gml:posList>35.66781786835872 139.74335928482913 32.836 35.66781786835872 139.74335928482913 31.069 35.667817210463916 139.74335942916414 31.069 35.667817210463916 139.74335942916414 32.836 35.66781786835872 139.74335928482913 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-995574aa-172a-4fea-a388-bb0aef2d00cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-995574aa-172a-4fea-a388-bb0aef2d00cd_0">
											<gml:posList>35.66782117663597 139.7433596014483 32.836 35.66782117663597 139.7433596014483 31.069 35.667820527499046 139.74335940335035 31.069 35.667820527499046 139.74335940335035 32.836 35.66782117663597 139.7433596014483 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab9e982e-d81f-4d9b-ac79-78ff6a157cf2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab9e982e-d81f-4d9b-ac79-78ff6a157cf2_0">
											<gml:posList>35.667817210463916 139.74335942916414 32.836 35.667817210463916 139.74335942916414 31.069 35.66781656164062 139.7433596508103 31.069 35.66781656164062 139.7433596508103 32.836 35.667817210463916 139.74335942916414 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09b5162e-b480-487c-9bc2-3863e58f6a27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09b5162e-b480-487c-9bc2-3863e58f6a27_0">
											<gml:posList>35.667821807803215 139.74335987688775 32.836 35.667821807803215 139.74335987688775 31.069 35.66782117663597 139.7433596014483 31.069 35.66782117663597 139.7433596014483 32.836 35.667821807803215 139.74335987688775 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f60a952a-d320-412c-9061-3d95850dcf2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f60a952a-d320-412c-9061-3d95850dcf2e_0">
											<gml:posList>35.66781656164062 139.7433596508103 32.836 35.66781656164062 139.7433596508103 31.069 35.66781593990804 139.7433599387015 31.069 35.66781593990804 139.7433599387015 32.836 35.66781656164062 139.7433596508103 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b1dcb6b-5886-42b8-b3e5-7e53b5219f0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b1dcb6b-5886-42b8-b3e5-7e53b5219f0b_0">
											<gml:posList>35.6678224119788 139.74336021863297 32.836 35.6678224119788 139.74336021863297 31.069 35.667821807803215 139.74335987688775 31.069 35.667821807803215 139.74335987688775 32.836 35.6678224119788 139.74336021863297 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd5e99d0-4346-47e8-9d1a-425de233868c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd5e99d0-4346-47e8-9d1a-425de233868c_0">
											<gml:posList>35.66781593990804 139.7433599387015 32.836 35.66781593990804 139.7433599387015 31.069 35.66781533625241 139.74336029284785 31.069 35.66781533625241 139.74336029284785 32.836 35.66781593990804 139.7433599387015 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4156292c-3133-40c7-96fa-e39e1e15ba64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4156292c-3133-40c7-96fa-e39e1e15ba64_0">
											<gml:posList>35.66782299817643 139.7433606266738 32.836 35.66782299817643 139.7433606266738 31.069 35.6678224119788 139.74336021863297 31.069 35.6678224119788 139.74336021863297 32.836 35.66782299817643 139.7433606266738 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03bb8a6e-3819-4f4d-81f1-2f03809409e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03bb8a6e-3819-4f4d-81f1-2f03809409e4_0">
											<gml:posList>35.66781533625241 139.74336029284785 32.836 35.66781533625241 139.74336029284785 31.069 35.66781475967923 139.74336070219334 31.069 35.66781475967923 139.74336070219334 32.836 35.66781533625241 139.74336029284785 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84b12836-3217-498a-8a5f-ddd6819551e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84b12836-3217-498a-8a5f-ddd6819551e0_0">
											<gml:posList>35.66782354836043 139.74336108998455 32.836 35.66782354836043 139.74336108998455 31.069 35.66782299817643 139.7433606266738 31.069 35.66782299817643 139.7433606266738 32.836 35.66782354836043 139.74336108998455 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1afdfea5-17dc-4d85-b419-15c52d49838e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1afdfea5-17dc-4d85-b419-15c52d49838e_0">
											<gml:posList>35.66781475967923 139.74336070219334 32.836 35.66781475967923 139.74336070219334 31.069 35.667814210196745 139.74336117778387 31.069 35.667814210196745 139.74336117778387 32.836 35.66781475967923 139.74336070219334 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce529863-dc1a-4e40-8181-83a7d8e9472f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce529863-dc1a-4e40-8181-83a7d8e9472f_0">
											<gml:posList>35.66782406253903 139.74336161961116 32.836 35.66782406253903 139.74336161961116 31.069 35.66782354836043 139.74336108998455 31.069 35.66782354836043 139.74336108998455 32.836 35.66782406253903 139.74336161961116 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57db3f6b-e7b9-497c-9547-b84d5166a23d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57db3f6b-e7b9-497c-9547-b84d5166a23d_0">
											<gml:posList>35.667814210196745 139.74336117778387 32.836 35.667814210196745 139.74336117778387 31.069 35.66781370582418 139.74336170855327 31.069 35.66781370582418 139.74336170855327 32.836 35.667814210196745 139.74336117778387 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b20e1b81-64aa-4e91-902d-cd952cd390f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b20e1b81-64aa-4e91-902d-cd952cd390f4_0">
											<gml:posList>35.66782454069575 139.74336219346188 32.836 35.66782454069575 139.74336219346188 31.069 35.66782406253903 139.74336161961116 31.069 35.66782406253903 139.74336161961116 32.836 35.66782454069575 139.74336219346188 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4525e443-2ddd-42d7-8054-41948b1915cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4525e443-2ddd-42d7-8054-41948b1915cf_0">
											<gml:posList>35.66781370582418 139.74336170855327 32.836 35.66781370582418 139.74336170855327 31.069 35.667813237547776 139.7433622945117 31.069 35.667813237547776 139.7433622945117 32.836 35.66781370582418 139.74336170855327 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-409c41e7-252a-4ae2-b8f8-b796c2541849">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-409c41e7-252a-4ae2-b8f8-b796c2541849_0">
											<gml:posList>35.66782497381683 139.74336281154672 32.836 35.66782497381683 139.74336281154672 31.069 35.66782454069575 139.74336219346188 31.069 35.66782454069575 139.74336219346188 32.836 35.66782497381683 139.74336281154672 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a14ff8b9-3ecc-4207-9709-3efd519c8ae7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a14ff8b9-3ecc-4207-9709-3efd519c8ae7_0">
											<gml:posList>35.667813237547776 139.7433622945117 32.836 35.667813237547776 139.7433622945117 31.069 35.66781280535929 139.74336292461334 31.069 35.66781280535929 139.74336292461334 32.836 35.667813237547776 139.7433622945117 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32a55dbc-c8d3-40cd-87f5-a096af593266">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32a55dbc-c8d3-40cd-87f5-a096af593266_0">
											<gml:posList>35.66782536191054 139.74336348491164 32.836 35.66782536191054 139.74336348491164 31.069 35.66782497381683 139.74336281154672 31.069 35.66782497381683 139.74336281154672 32.836 35.66782536191054 139.74336348491164 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-628b6b27-b16b-4f5b-b819-244b8d97b3cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-628b6b27-b16b-4f5b-b819-244b8d97b3cd_0">
											<gml:posList>35.66781280535929 139.74336292461334 32.836 35.66781280535929 139.74336292461334 31.069 35.66781242729443 139.7433636098837 31.069 35.66781242729443 139.7433636098837 32.836 35.66781280535929 139.74336292461334 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e78ae0d-247f-425c-b43d-1ef28c0f96ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e78ae0d-247f-425c-b43d-1ef28c0f96ff_0">
											<gml:posList>35.66782570496036 139.74336419146485 32.836 35.66782570496036 139.74336419146485 31.069 35.66782536191054 139.74336348491164 31.069 35.66782536191054 139.74336348491164 32.836 35.66782570496036 139.74336419146485 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4027279-2d61-43d5-8d6d-c52f7c97d47f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4027279-2d61-43d5-8d6d-c52f7c97d47f_0">
											<gml:posList>35.66781242729443 139.7433636098837 32.836 35.66781242729443 139.7433636098837 31.069 35.66781209431472 139.74336431719527 31.069 35.66781209431472 139.74336431719527 32.836 35.66781242729443 139.7433636098837 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd7f4ad5-15de-43c4-bf0c-9aaab5ce393b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd7f4ad5-15de-43c4-bf0c-9aaab5ce393b_0">
											<gml:posList>35.667825993952576 139.74336493121638 32.836 35.667825993952576 139.74336493121638 31.069 35.66782570496036 139.74336419146485 31.069 35.66782570496036 139.74336419146485 32.836 35.667825993952576 139.74336493121638 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92138676-1f58-49da-922f-30eece366a3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92138676-1f58-49da-922f-30eece366a3a_0">
											<gml:posList>35.66781209431472 139.74336431719527 32.836 35.66781209431472 139.74336431719527 31.069 35.66781181544211 139.74336505758387 31.069 35.66781181544211 139.74336505758387 32.836 35.66781209431472 139.74336431719527 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2da73298-c9e9-4e5b-af47-c5ee745629dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2da73298-c9e9-4e5b-af47-c5ee745629dc_0">
											<gml:posList>35.667826219865205 139.74336569313058 32.836 35.667826219865205 139.74336569313058 31.069 35.667825993952576 139.74336493121638 31.069 35.667825993952576 139.74336493121638 32.836 35.667826219865205 139.74336569313058 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1962fa93-0fa1-4259-a6f1-2998534c618a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1962fa93-0fa1-4259-a6f1-2998534c618a_0">
											<gml:posList>35.66781181544211 139.74336505758387 32.836 35.66781181544211 139.74336505758387 31.069 35.66781159969035 139.74336583103934 31.069 35.66781159969035 139.74336583103934 32.836 35.66781181544211 139.74336505758387 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49a9f501-e4e9-4584-9ec7-364b64bdfe5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49a9f501-e4e9-4584-9ec7-364b64bdfe5a_0">
											<gml:posList>35.66782640073395 139.74336648823302 32.836 35.66782640073395 139.74336648823302 31.069 35.667826219865205 139.74336569313058 31.069 35.667826219865205 139.74336569313058 32.836 35.66782640073395 139.74336648823302 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cedb72c0-5f08-4066-95d4-40c602cef311">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cedb72c0-5f08-4066-95d4-40c602cef311_0">
											<gml:posList>35.66781159969035 139.74336583103934 32.836 35.66781159969035 139.74336583103934 31.069 35.66781142902373 139.74336662653604 31.069 35.66781142902373 139.74336662653604 32.836 35.66781159969035 139.74336583103934 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4ffdb95-0755-4ff0-acc0-b80a8813346a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4ffdb95-0755-4ff0-acc0-b80a8813346a_0">
											<gml:posList>35.66782651851485 139.74336729445213 32.836 35.66782651851485 139.74336729445213 31.069 35.66782640073395 139.74336648823302 31.069 35.66782640073395 139.74336648823302 32.836 35.66782651851485 139.74336729445213 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4c9e1a1-8b6c-4a8f-82ea-216e51739bf8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4c9e1a1-8b6c-4a8f-82ea-216e51739bf8_0">
											<gml:posList>35.66781142902373 139.74336662653604 32.836 35.66781142902373 139.74336662653604 31.069 35.66781131244772 139.743367433018 31.069 35.66781131244772 139.743367433018 32.836 35.66781142902373 139.74336662653604 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6caaf95d-1b0b-417e-878a-4419b166925c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6caaf95d-1b0b-417e-878a-4419b166925c_0">
											<gml:posList>35.66782658222163 139.74336811177784 32.836 35.66782658222163 139.74336811177784 31.069 35.66782651851485 139.74336729445213 31.069 35.66782651851485 139.74336729445213 32.836 35.66782658222163 139.74336811177784 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b322095-4c77-4a33-9c5c-90fdc78176da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b322095-4c77-4a33-9c5c-90fdc78176da_0">
											<gml:posList>35.66781131244772 139.743367433018 32.836 35.66781131244772 139.743367433018 31.069 35.667811258976045 139.74336825047502 31.069 35.667811258976045 139.74336825047502 32.836 35.66781131244772 139.743367433018 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca0dc6e1-fdbd-4867-93e6-2ff3d01b7eeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca0dc6e1-fdbd-4867-93e6-2ff3d01b7eeb_0">
											<gml:posList>35.667826591846044 139.74336892916423 32.836 35.667826591846044 139.74336892916423 31.069 35.66782658222163 139.74336811177784 31.069 35.66782658222163 139.74336811177784 32.836 35.667826591846044 139.74336892916423 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24833044-281f-4300-8548-9e325d80815d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24833044-281f-4300-8548-9e325d80815d_0">
											<gml:posList>35.66781163095682 139.7433714865081 32.836 35.66781186588313 139.74337224841202 32.836 35.667812154883556 139.7433729992094 32.836 35.66781248891959 139.74337370577263 32.836 35.667812877004984 139.7433743680916 32.836 35.66781331914798 139.74337499721221 32.836 35.6678137882909 139.743375571073 32.836 35.667814302461196 139.74337608965376 32.836 35.66781485264513 139.7433765529646 32.836 35.667815438842716 139.74337696100548 32.836 35.66781604301825 139.7433773027508 32.836 35.66781668319918 139.74337757818026 32.836 35.667817323322346 139.74337777628847 32.836 35.667817990445435 139.74337791913686 32.836 35.66781864849703 139.74337798467405 32.836 35.66781932452658 139.74337798391565 32.836 35.667819991476385 139.74337789480018 32.836 35.6678206493712 139.74337775046533 32.836 35.66782128918081 139.7433775288294 32.836 35.66782191993543 139.74337725197412 32.836 35.66782252359109 139.74337689782786 32.836 35.66782310015608 139.74337647743656 32.836 35.66782364062488 139.7433760018562 32.836 35.66782415401125 139.7433754710767 32.836 35.66782462228772 139.74337488511824 32.836 35.667825045462536 139.74337425502674 32.836 35.6678254235357 139.7433735808022 32.836 35.66782575650722 139.74337286244463 32.836 35.66782603537988 139.74337212205594 32.836 35.667826260145404 139.74337134859022 32.836 35.667826430812056 139.74337055309337 32.836 35.667826538374364 139.74336974662143 32.836 35.667826591846044 139.74336892916423 32.836 35.66782658222163 139.74336811177784 32.836 35.66782651851485 139.74336729445213 32.836 35.66782640073395 139.74336648823302 32.836 35.667826219865205 139.74336569313058 32.836 35.667825993952576 139.74336493121638 32.836 35.66782570496036 139.74336419146485 32.836 35.66782536191054 139.74336348491164 32.836 35.66782497381683 139.74336281154672 32.836 35.66782454069575 139.74336219346188 32.836 35.66782406253903 139.74336161961116 32.836 35.66782354836043 139.74336108998455 32.836 35.66782299817643 139.7433606266738 32.836 35.6678224119788 139.74336021863297 32.836 35.667821807803215 139.74335987688775 32.836 35.66782117663597 139.7433596014483 32.836 35.667820527499046 139.74335940335035 32.836 35.66781986938967 139.743359260492 32.836 35.66781920232433 139.74335919496505 32.836 35.66781853531676 139.7433592067594 32.836 35.66781786835872 139.74335928482913 32.836 35.667817210463916 139.74335942916414 32.836 35.66781656164062 139.7433596508103 32.836 35.66781593990804 139.7433599387015 32.836 35.66781533625241 139.74336029284785 32.836 35.66781475967923 139.74336070219334 32.836 35.667814210196745 139.74336117778387 32.836 35.66781370582418 139.74336170855327 32.836 35.667813237547776 139.7433622945117 32.836 35.66781280535929 139.74336292461334 32.836 35.66781242729443 139.7433636098837 32.836 35.66781209431472 139.74336431719527 32.836 35.66781181544211 139.74336505758387 32.836 35.66781159969035 139.74336583103934 32.836 35.66781142902373 139.74336662653604 32.836 35.66781131244772 139.743367433018 32.836 35.667811258976045 139.74336825047502 32.836 35.66781126860871 139.74336907890714 32.836 35.66781133230723 139.7433698851868 32.836 35.66781145008811 139.7433706914058 32.836 35.66781163095682 139.7433714865081 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea6f35f4-c03b-4f97-86cd-ac1d4d4f728a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea6f35f4-c03b-4f97-86cd-ac1d4d4f728a_0">
											<gml:posList>35.667811258976045 139.74336825047502 32.836 35.667811258976045 139.74336825047502 31.069 35.66781126860871 139.74336907890714 31.069 35.66781126860871 139.74336907890714 32.836 35.667811258976045 139.74336825047502 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f910e855-6bf2-47fa-b4ae-5b76bf920384">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f910e855-6bf2-47fa-b4ae-5b76bf920384_0">
											<gml:posList>35.667826538374364 139.74336974662143 32.836 35.667826538374364 139.74336974662143 31.069 35.667826591846044 139.74336892916423 31.069 35.667826591846044 139.74336892916423 32.836 35.667826538374364 139.74336974662143 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7c0190f-d907-4f50-8845-98655e48c0e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7c0190f-d907-4f50-8845-98655e48c0e8_0">
											<gml:posList>35.66781126860871 139.74336907890714 32.836 35.66781126860871 139.74336907890714 31.069 35.66781133230723 139.7433698851868 31.069 35.66781133230723 139.7433698851868 32.836 35.66781126860871 139.74336907890714 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81f3dad4-0dde-4129-aa3b-040494929dc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81f3dad4-0dde-4129-aa3b-040494929dc1_0">
											<gml:posList>35.667826430812056 139.74337055309337 32.836 35.667826430812056 139.74337055309337 31.069 35.667826538374364 139.74336974662143 31.069 35.667826538374364 139.74336974662143 32.836 35.667826430812056 139.74337055309337 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16750234-90b0-4072-8644-45c95388b8fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16750234-90b0-4072-8644-45c95388b8fb_0">
											<gml:posList>35.66781133230723 139.7433698851868 32.836 35.66781133230723 139.7433698851868 31.069 35.66781145008811 139.7433706914058 31.069 35.66781145008811 139.7433706914058 32.836 35.66781133230723 139.7433698851868 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29d0254f-c8b9-46f6-98db-6b1417a202d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29d0254f-c8b9-46f6-98db-6b1417a202d6_0">
											<gml:posList>35.667826260145404 139.74337134859022 32.836 35.667826260145404 139.74337134859022 31.069 35.667826430812056 139.74337055309337 31.069 35.667826430812056 139.74337055309337 32.836 35.667826260145404 139.74337134859022 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ac1c7bc-04ac-4453-997e-5cec8c87b1c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ac1c7bc-04ac-4453-997e-5cec8c87b1c7_0">
											<gml:posList>35.66781145008811 139.7433706914058 32.836 35.66781145008811 139.7433706914058 31.069 35.66781163095682 139.7433714865081 31.069 35.66781163095682 139.7433714865081 32.836 35.66781145008811 139.7433706914058 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d794820a-b191-4116-9ab7-d9cbb245b420">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d794820a-b191-4116-9ab7-d9cbb245b420_0">
											<gml:posList>35.66782603537988 139.74337212205594 32.836 35.66782603537988 139.74337212205594 31.069 35.667826260145404 139.74337134859022 31.069 35.667826260145404 139.74337134859022 32.836 35.66782603537988 139.74337212205594 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-410952f4-4458-46ae-9380-101b4e8ca30d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-410952f4-4458-46ae-9380-101b4e8ca30d_0">
											<gml:posList>35.66781163095682 139.7433714865081 32.836 35.66781163095682 139.7433714865081 31.069 35.66781186588313 139.74337224841202 31.069 35.66781186588313 139.74337224841202 32.836 35.66781163095682 139.7433714865081 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3ec6933-9a50-4a96-9351-8e3bc8ea3c04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3ec6933-9a50-4a96-9351-8e3bc8ea3c04_0">
											<gml:posList>35.66782575650722 139.74337286244463 32.836 35.66782575650722 139.74337286244463 31.069 35.66782603537988 139.74337212205594 31.069 35.66782603537988 139.74337212205594 32.836 35.66782575650722 139.74337286244463 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-899151b4-4920-48e7-b549-7fd5df551071">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-899151b4-4920-48e7-b549-7fd5df551071_0">
											<gml:posList>35.66781186588313 139.74337224841202 32.836 35.66781186588313 139.74337224841202 31.069 35.667812154883556 139.7433729992094 31.069 35.667812154883556 139.7433729992094 32.836 35.66781186588313 139.74337224841202 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11c85898-a91c-4a6b-8737-ab499d6f2f24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11c85898-a91c-4a6b-8737-ab499d6f2f24_0">
											<gml:posList>35.6678254235357 139.7433735808022 32.836 35.6678254235357 139.7433735808022 31.069 35.66782575650722 139.74337286244463 31.069 35.66782575650722 139.74337286244463 32.836 35.6678254235357 139.7433735808022 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98340874-0e85-498c-b474-4c95e9eb868e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98340874-0e85-498c-b474-4c95e9eb868e_0">
											<gml:posList>35.667812154883556 139.7433729992094 32.836 35.667812154883556 139.7433729992094 31.069 35.66781248891959 139.74337370577263 31.069 35.66781248891959 139.74337370577263 32.836 35.667812154883556 139.7433729992094 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef479205-1f52-4f3e-b8fa-618fa4eeb36a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef479205-1f52-4f3e-b8fa-618fa4eeb36a_0">
											<gml:posList>35.667825045462536 139.74337425502674 32.836 35.667825045462536 139.74337425502674 31.069 35.6678254235357 139.7433735808022 31.069 35.6678254235357 139.7433735808022 32.836 35.667825045462536 139.74337425502674 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85121e6d-8e01-4ae0-9e82-cdbc9a0e699b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85121e6d-8e01-4ae0-9e82-cdbc9a0e699b_0">
											<gml:posList>35.66781248891959 139.74337370577263 32.836 35.66781248891959 139.74337370577263 31.069 35.667812877004984 139.7433743680916 31.069 35.667812877004984 139.7433743680916 32.836 35.66781248891959 139.74337370577263 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ab3c235-5fac-4774-bac3-30501978c0b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ab3c235-5fac-4774-bac3-30501978c0b9_0">
											<gml:posList>35.66782462228772 139.74337488511824 32.836 35.66782462228772 139.74337488511824 31.069 35.667825045462536 139.74337425502674 31.069 35.667825045462536 139.74337425502674 32.836 35.66782462228772 139.74337488511824 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c11d0ec-2494-46ce-b79d-ca71e8e78e51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c11d0ec-2494-46ce-b79d-ca71e8e78e51_0">
											<gml:posList>35.667812877004984 139.7433743680916 32.836 35.667812877004984 139.7433743680916 31.069 35.66781331914798 139.74337499721221 31.069 35.66781331914798 139.74337499721221 32.836 35.667812877004984 139.7433743680916 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9804f040-a62d-4ddd-aec1-1f845faa8bce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9804f040-a62d-4ddd-aec1-1f845faa8bce_0">
											<gml:posList>35.66782415401125 139.7433754710767 32.836 35.66782415401125 139.7433754710767 31.069 35.66782462228772 139.74337488511824 31.069 35.66782462228772 139.74337488511824 32.836 35.66782415401125 139.7433754710767 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f690424-b5cd-48aa-90de-4ea92e0b5373">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f690424-b5cd-48aa-90de-4ea92e0b5373_0">
											<gml:posList>35.66781331914798 139.74337499721221 32.836 35.66781331914798 139.74337499721221 31.069 35.6678137882909 139.743375571073 31.069 35.6678137882909 139.743375571073 32.836 35.66781331914798 139.74337499721221 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b041cec8-b16d-4333-a1c4-b4cbe0ae3e65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b041cec8-b16d-4333-a1c4-b4cbe0ae3e65_0">
											<gml:posList>35.66782364062488 139.7433760018562 32.836 35.66782364062488 139.7433760018562 31.069 35.66782415401125 139.7433754710767 31.069 35.66782415401125 139.7433754710767 32.836 35.66782364062488 139.7433760018562 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9660a6e5-6237-4674-8248-d4c6a04d92b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9660a6e5-6237-4674-8248-d4c6a04d92b1_0">
											<gml:posList>35.6678137882909 139.743375571073 32.836 35.6678137882909 139.743375571073 31.069 35.667814302461196 139.74337608965376 31.069 35.667814302461196 139.74337608965376 32.836 35.6678137882909 139.743375571073 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0008212b-26ca-458a-8014-fd8a695d9eea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0008212b-26ca-458a-8014-fd8a695d9eea_0">
											<gml:posList>35.66782310015608 139.74337647743656 32.836 35.66782310015608 139.74337647743656 31.069 35.66782364062488 139.7433760018562 31.069 35.66782364062488 139.7433760018562 32.836 35.66782310015608 139.74337647743656 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ff8aec0-ad40-4c4c-8207-7ab27bfaaea8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ff8aec0-ad40-4c4c-8207-7ab27bfaaea8_0">
											<gml:posList>35.667814302461196 139.74337608965376 32.836 35.667814302461196 139.74337608965376 31.069 35.66781485264513 139.7433765529646 31.069 35.66781485264513 139.7433765529646 32.836 35.667814302461196 139.74337608965376 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-977010f4-fec8-4414-b549-595d07423351">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-977010f4-fec8-4414-b549-595d07423351_0">
											<gml:posList>35.66782252359109 139.74337689782786 32.836 35.66782252359109 139.74337689782786 31.069 35.66782310015608 139.74337647743656 31.069 35.66782310015608 139.74337647743656 32.836 35.66782252359109 139.74337689782786 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d0eebc7-27f6-428a-b26c-e76d3dac0a2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d0eebc7-27f6-428a-b26c-e76d3dac0a2f_0">
											<gml:posList>35.66781485264513 139.7433765529646 32.836 35.66781485264513 139.7433765529646 31.069 35.667815438842716 139.74337696100548 31.069 35.667815438842716 139.74337696100548 32.836 35.66781485264513 139.7433765529646 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8698f34e-d5ee-4cb1-ac7e-277dc0e5be44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8698f34e-d5ee-4cb1-ac7e-277dc0e5be44_0">
											<gml:posList>35.66782191993543 139.74337725197412 32.836 35.66782191993543 139.74337725197412 31.069 35.66782252359109 139.74337689782786 31.069 35.66782252359109 139.74337689782786 32.836 35.66782191993543 139.74337725197412 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02788f17-b198-4942-94f7-7921a5ebdafa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02788f17-b198-4942-94f7-7921a5ebdafa_0">
											<gml:posList>35.667815438842716 139.74337696100548 32.836 35.667815438842716 139.74337696100548 31.069 35.66781604301825 139.7433773027508 31.069 35.66781604301825 139.7433773027508 32.836 35.667815438842716 139.74337696100548 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d934dbe-d92e-40cd-a6e5-ae53ec533dca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d934dbe-d92e-40cd-a6e5-ae53ec533dca_0">
											<gml:posList>35.66782128918081 139.7433775288294 32.836 35.66782128918081 139.7433775288294 31.069 35.66782191993543 139.74337725197412 31.069 35.66782191993543 139.74337725197412 32.836 35.66782128918081 139.7433775288294 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-510c54e1-0a66-4ee0-b582-eb640a6c378c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-510c54e1-0a66-4ee0-b582-eb640a6c378c_0">
											<gml:posList>35.66781604301825 139.7433773027508 32.836 35.66781604301825 139.7433773027508 31.069 35.66781668319918 139.74337757818026 31.069 35.66781668319918 139.74337757818026 32.836 35.66781604301825 139.7433773027508 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3850eb3-6f4b-4428-aac7-780bc8bc6ab9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3850eb3-6f4b-4428-aac7-780bc8bc6ab9_0">
											<gml:posList>35.6678206493712 139.74337775046533 32.836 35.6678206493712 139.74337775046533 31.069 35.66782128918081 139.7433775288294 31.069 35.66782128918081 139.7433775288294 32.836 35.6678206493712 139.74337775046533 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13bda3b9-54fe-466a-b63d-28170d8dc686">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13bda3b9-54fe-466a-b63d-28170d8dc686_0">
											<gml:posList>35.66781668319918 139.74337757818026 32.836 35.66781668319918 139.74337757818026 31.069 35.667817323322346 139.74337777628847 31.069 35.667817323322346 139.74337777628847 32.836 35.66781668319918 139.74337757818026 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cafbe351-d5f5-4e05-b12a-584494a88fbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cafbe351-d5f5-4e05-b12a-584494a88fbe_0">
											<gml:posList>35.667819991476385 139.74337789480018 32.836 35.667819991476385 139.74337789480018 31.069 35.6678206493712 139.74337775046533 31.069 35.6678206493712 139.74337775046533 32.836 35.667819991476385 139.74337789480018 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11209abe-a77a-4515-84cd-3d1e7d41faf1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11209abe-a77a-4515-84cd-3d1e7d41faf1_0">
											<gml:posList>35.667817323322346 139.74337777628847 32.836 35.667817323322346 139.74337777628847 31.069 35.667817990445435 139.74337791913686 31.069 35.667817990445435 139.74337791913686 32.836 35.667817323322346 139.74337777628847 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0882c45a-e96c-48e8-8486-c27d8a4d24c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0882c45a-e96c-48e8-8486-c27d8a4d24c4_0">
											<gml:posList>35.66781932452658 139.74337798391565 32.836 35.66781932452658 139.74337798391565 31.069 35.667819991476385 139.74337789480018 31.069 35.667819991476385 139.74337789480018 32.836 35.66781932452658 139.74337798391565 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5887bb2-78f3-4119-bc99-8b6d94798868">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5887bb2-78f3-4119-bc99-8b6d94798868_0">
											<gml:posList>35.667817990445435 139.74337791913686 32.836 35.667817990445435 139.74337791913686 31.069 35.66781864849703 139.74337798467405 31.069 35.66781864849703 139.74337798467405 32.836 35.667817990445435 139.74337791913686 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4effbbf-6780-40bb-bad9-de7b1137e067">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4effbbf-6780-40bb-bad9-de7b1137e067_0">
											<gml:posList>35.66781864849703 139.74337798467405 32.836 35.66781864849703 139.74337798467405 31.069 35.66781932452658 139.74337798391565 31.069 35.66781932452658 139.74337798391565 32.836 35.66781864849703 139.74337798467405 32.836</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fdf1fff1-6749-4b95-94c1-2de65ea49e8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdf1fff1-6749-4b95-94c1-2de65ea49e8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdf1fff1-6749-4b95-94c1-2de65ea49e8f">
											<gml:posList>35.66782112734277 139.74339014343698 27.4 35.66780511289869 139.74338204266013 27.4 35.66781631018123 139.74334882610407 27.4 35.66783231561377 139.74335692688553 27.4 35.66782112734277 139.74339014343698 27.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f587c49-78a9-41f5-9402-8698a0ded34b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f587c49-78a9-41f5-9402-8698a0ded34b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f587c49-78a9-41f5-9402-8698a0ded34b">
											<gml:posList>35.66780511289869 139.74338204266013 31.069 35.66782112734277 139.74339014343698 31.069 35.66783231561377 139.74335692688553 31.069 35.66781631018123 139.74334882610407 31.069 35.66780511289869 139.74338204266013 31.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31d681b3-3f78-407f-8978-3b2082090f99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31d681b3-3f78-407f-8978-3b2082090f99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31d681b3-3f78-407f-8978-3b2082090f99">
											<gml:posList>35.66783231561377 139.74335692688553 27.4 35.66781631018123 139.74334882610407 27.4 35.66781631018123 139.74334882610407 31.069 35.66783231561377 139.74335692688553 31.069 35.66783231561377 139.74335692688553 27.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65132fc6-f015-489a-a252-6adaa9b3e9ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65132fc6-f015-489a-a252-6adaa9b3e9ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65132fc6-f015-489a-a252-6adaa9b3e9ff">
											<gml:posList>35.66781631018123 139.74334882610407 27.4 35.66780511289869 139.74338204266013 27.4 35.66780511289869 139.74338204266013 31.069 35.66781631018123 139.74334882610407 31.069 35.66781631018123 139.74334882610407 27.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cab96f15-5e88-4ad9-bc16-95f7b1ef5c3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cab96f15-5e88-4ad9-bc16-95f7b1ef5c3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cab96f15-5e88-4ad9-bc16-95f7b1ef5c3b">
											<gml:posList>35.66782112734277 139.74339014343698 27.4 35.66783231561377 139.74335692688553 27.4 35.66783231561377 139.74335692688553 31.069 35.66782112734277 139.74339014343698 31.069 35.66782112734277 139.74339014343698 27.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8be09fb9-bbca-46fc-9949-92881ebd6049">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8be09fb9-bbca-46fc-9949-92881ebd6049">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8be09fb9-bbca-46fc-9949-92881ebd6049">
											<gml:posList>35.66780511289869 139.74338204266013 27.4 35.66782112734277 139.74339014343698 27.4 35.66782112734277 139.74339014343698 31.069 35.66780511289869 139.74338204266013 31.069 35.66780511289869 139.74338204266013 27.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1524</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>