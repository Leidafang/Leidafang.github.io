<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cc11e633-a77d-486c-b690-42e85c569984">
			<core:creationDate>2023-08-22</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>環状第二号線新橋・虎ノ門地区</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">15.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66855905701279 139.7478441921307 0 35.66854130300913 139.7478573801089 0 35.668548354884926 139.74787068744934 0 35.66858670522002 139.74788917736532 0 35.66861434424302 139.74780313699765 0 35.66855905701279 139.7478441921307 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855905701279 139.7478441921307 5.467 35.66861434424302 139.74780313699765 5.467 35.66858670522002 139.74788917736532 5.467 35.668548354884926 139.74787068744934 5.467 35.66854130300913 139.7478573801089 5.467 35.66855905701279 139.7478441921307 5.467</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855905701279 139.7478441921307 5.467 35.66854130300913 139.7478573801089 5.467 35.66854130300913 139.7478573801089 20.78 35.66855905701279 139.7478441921307 20.78 35.66855905701279 139.7478441921307 5.467</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854130300913 139.7478573801089 5.467 35.668548354884926 139.74787068744934 5.467 35.668548354884926 139.74787068744934 20.78 35.66854130300913 139.7478573801089 20.78 35.66854130300913 139.7478573801089 5.467</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668548354884926 139.74787068744934 5.467 35.66858670522002 139.74788917736532 5.467 35.66858670522002 139.74788917736532 20.78 35.668548354884926 139.74787068744934 20.78 35.668548354884926 139.74787068744934 5.467</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858670522002 139.74788917736532 5.467 35.66861434424302 139.74780313699765 5.467 35.66861434424302 139.74780313699765 20.78 35.66858670522002 139.74788917736532 20.78 35.66858670522002 139.74788917736532 5.467</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66861434424302 139.74780313699765 5.467 35.66855905701279 139.7478441921307 5.467 35.66855905701279 139.7478441921307 20.78 35.66861434424302 139.74780313699765 20.78 35.66861434424302 139.74780313699765 5.467</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855905701279 139.7478441921307 20.78 35.66854130300913 139.7478573801089 20.78 35.668548354884926 139.74787068744934 20.78 35.66858670522002 139.74788917736532 20.78 35.66861434424302 139.74780313699765 20.78 35.66855905701279 139.7478441921307 20.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly_TMmnt0165_p990_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0165_p990_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0165_p990_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0165_p936_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0165_p936_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0165_p936_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0165_p936_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0165_b_0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_ab110c1e-3f5a-47e3-ba99-0ca1a726be7d">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_46c2df80-8057-4633-9ce6-0915f7eaf71a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_49e6d058-8544-4ab3-9c3a-b611f6ab8de3">
											<gml:posList>35.66860318573339 139.7478169764286 19.29400401957983 35.66858811725245 139.7478638291733 19.29400401957983 35.66858811725245 139.7478638291733 19.829503592333737 35.66860318573339 139.7478169764286 19.829503592333737 35.66860318573339 139.7478169764286 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fa21bc4a-58d3-4101-952e-44b8086afbfc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9d7b3950-212f-464a-b116-d7781567bc86">
											<gml:posList>35.66858853757453 139.74786402845558 19.29400401957983 35.66858853757453 139.74786402845558 19.829503592333737 35.66858811725245 139.7478638291733 19.829503592333737 35.66858811725245 139.7478638291733 19.29400401957983 35.66858853757453 139.74786402845558 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b4360f1-c194-4aca-9efc-0e6a60641934">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c3e117aa-40d6-4669-a945-81ac5dae7aa3">
											<gml:posList>35.66860411286696 139.74781560024996 19.829503592333737 35.66858853757453 139.74786402845558 19.829503592333737 35.66858853757453 139.74786402845558 19.29400401957983 35.66860411286696 139.74781560024996 19.29400401957983 35.66860411286696 139.74781560024996 19.829503592333737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3371fe70-aff2-448f-af60-9ff6d349bc56">
									<gml:exterior>
										<gml:LinearRing gml:id="line_54059b4c-f5c7-4c8c-8448-d8a6aabc49dd">
											<gml:posList>35.66855956410258 139.7478502868857 19.829503592333737 35.6685600863752 139.74785053460118 19.829503592333737 35.66860318573339 139.7478169764286 19.829503592333737 35.66858811725245 139.7478638291733 19.829503592333737 35.66858853757453 139.74786402845558 19.829503592333737 35.66860411286696 139.74781560024996 19.829503592333737 35.66855956410258 139.7478502868857 19.829503592333737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f8f0a48b-198e-4fc6-822d-619955272898">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7cda511e-d8c6-494d-82b7-71cc9c9fd49b">
											<gml:posList>35.66860411286696 139.74781560024996 19.29400401957983 35.66858853757453 139.74786402845558 19.29400401957983 35.66858811725245 139.7478638291733 19.29400401957983 35.66860318573339 139.7478169764286 19.29400401957983 35.6685600863752 139.74785053460118 19.29400401957983 35.66855956410258 139.7478502868857 19.29400401957983 35.66860411286696 139.74781560024996 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_28baf83b-9442-4989-866e-043836e6ea79">
									<gml:exterior>
										<gml:LinearRing gml:id="line_58c37600-3799-49fb-b635-dfda5519d673">
											<gml:posList>35.66855956410258 139.7478502868857 19.29400401957983 35.66855956410258 139.7478502868857 19.829503592333737 35.66860411286696 139.74781560024996 19.829503592333737 35.66860411286696 139.74781560024996 19.29400401957983 35.66855956410258 139.7478502868857 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_805827c7-ac07-4a08-a264-e21d0e32d290">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cc8443ff-e834-4b60-9d02-9bb60a45c1ec">
											<gml:posList>35.66860318573339 139.7478169764286 19.29400401957983 35.66860318573339 139.7478169764286 19.829503592333737 35.6685600863752 139.74785053460118 19.829503592333737 35.6685600863752 139.74785053460118 19.29400401957983 35.66860318573339 139.7478169764286 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_67edf938-3228-47ec-84c9-27e971adcdfa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_08aaa4ce-414b-402d-ac4c-c75298c04b8e">
											<gml:posList>35.6685600863752 139.74785053460118 19.29400401957983 35.6685600863752 139.74785053460118 19.829503592333737 35.66855956410258 139.7478502868857 19.829503592333737 35.66855956410258 139.7478502868857 19.29400401957983 35.6685600863752 139.74785053460118 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_59ff1196-5159-4c2c-9a3f-dfb4d4be6ccb">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b851c905-3b90-4233-8e69-9a4808a19945">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a39006d1-cb5b-477a-9f3a-f5c8e93ee6f4">
											<gml:posList>35.66858757613061 139.74786357237608 21.33099895366186 35.66858757613061 139.74786357237608 21.409749564013424 35.66856929562642 139.74785490233128 21.409749564013424 35.66856929562642 139.74785490233128 21.33099895366186 35.66858757613061 139.74786357237608 21.33099895366186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c6259600-b313-49a6-9cd8-0402823ae33d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_56dd6deb-8ce1-4afc-8a25-2bb203fa693d">
											<gml:posList>35.668573193512664 139.74784255990144 21.409749564013424 35.66856929562642 139.74785490233128 21.409749564013424 35.66858757613061 139.74786357237608 21.409749564013424 35.668591474155384 139.74785123011225 21.409749564013424 35.668573193512664 139.74784255990144 21.409749564013424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_42f352f4-4750-4c30-b0f8-ec501b5425ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_55931ae1-576a-42cc-9873-a9973dade9cc">
											<gml:posList>35.668573193512664 139.74784255990144 21.409749564013424 35.668573193512664 139.74784255990144 19.29400401957983 35.66857286813987 139.74784359008123 19.29400401957983 35.66857286813987 139.74784359008123 21.33099895366186 35.66856929562642 139.74785490233128 21.33099895366186 35.66856929562642 139.74785490233128 21.409749564013424 35.668573193512664 139.74784255990144 21.409749564013424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3b6a621b-12e6-4bd7-9a60-442d9ccefaf9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cd76dd6e-9414-4988-b833-8f8a02af7c73">
											<gml:posList>35.6685737087842 139.74784398881405 21.33099895366186 35.66857286813987 139.74784359008123 21.33099895366186 35.66857286813987 139.74784359008123 19.29400401957983 35.6685737087842 139.74784398881405 19.29400401957983 35.6685737087842 139.74784398881405 21.33099895366186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4fe8d841-ef2b-4050-b586-132cae8bfa7a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9e2a1ec7-6c03-446b-8ffd-c51c779c5515">
											<gml:posList>35.668574034157 139.74784295863424 21.33099895366186 35.6685737087842 139.74784398881405 21.33099895366186 35.6685737087842 139.74784398881405 19.29400401957983 35.668574034157 139.74784295863424 19.29400401957983 35.668574034157 139.74784295863424 21.33099895366186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d9bf1117-29cc-43e3-9a04-824de49718a3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6520483c-0fb7-4ed5-bfcf-44bd4ab6cb09">
											<gml:posList>35.668573193512664 139.74784255990144 19.29400401957983 35.668574034157 139.74784295863424 19.29400401957983 35.6685737087842 139.74784398881405 19.29400401957983 35.66857286813987 139.74784359008123 19.29400401957983 35.668573193512664 139.74784255990144 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_daa2e598-2aab-419e-8e75-5949ce87bc54">
									<gml:exterior>
										<gml:LinearRing gml:id="line_14869fd4-2b38-4514-9ce3-c5a477764499">
											<gml:posList>35.668574034157 139.74784295863424 21.33099895366186 35.668574034157 139.74784295863424 19.29400401957983 35.668573193512664 139.74784255990144 19.29400401957983 35.668573193512664 139.74784255990144 21.409749564013424 35.668591474155384 139.74785123011225 21.409749564013424 35.668591474155384 139.74785123011225 19.29400401957983 35.66859063351108 139.74785083137925 19.29400401957983 35.66859063351108 139.74785083137925 21.33099895366186 35.668574034157 139.74784295863424 21.33099895366186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_918f3b0e-82c9-425f-90bc-58a798aa97ae">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7b937b38-a803-458e-aedc-dcd05db7004c">
											<gml:posList>35.6685737087842 139.74784398881405 21.33099895366186 35.668574034157 139.74784295863424 21.33099895366186 35.66859063351108 139.74785083137925 21.33099895366186 35.66859030813822 139.74785186155927 21.33099895366186 35.6685911487824 139.74785226012372 21.33099895366186 35.66858757613061 139.74786357237608 21.33099895366186 35.66856929562642 139.74785490233128 21.33099895366186 35.66857286813987 139.74784359008123 21.33099895366186 35.6685737087842 139.74784398881405 21.33099895366186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fe17dd86-7ff0-4a69-9125-bfd848e12dbf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_efb17f8e-b1db-4842-ac58-c39a9c322fbd">
											<gml:posList>35.6685911487824 139.74785226012372 21.33099895366186 35.6685911487824 139.74785226012372 19.29400401957983 35.668591474155384 139.74785123011225 19.29400401957983 35.668591474155384 139.74785123011225 21.409749564013424 35.66858757613061 139.74786357237608 21.409749564013424 35.66858757613061 139.74786357237608 21.33099895366186 35.6685911487824 139.74785226012372 21.33099895366186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2db42d29-cc16-48c1-a7ac-b49a03fdd101">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a454582e-6255-4a0d-87ad-121f883932f9">
											<gml:posList>35.66859030813822 139.74785186155927 21.33099895366186 35.66859063351108 139.74785083137925 21.33099895366186 35.66859063351108 139.74785083137925 19.29400401957983 35.66859030813822 139.74785186155927 19.29400401957983 35.66859030813822 139.74785186155927 21.33099895366186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_54c692d3-f087-4579-a00a-8dc43136ba35">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b05793f4-8da4-40e5-b3d2-b73731919a65">
											<gml:posList>35.6685911487824 139.74785226012372 21.33099895366186 35.66859030813822 139.74785186155927 21.33099895366186 35.66859030813822 139.74785186155927 19.29400401957983 35.6685911487824 139.74785226012372 19.29400401957983 35.6685911487824 139.74785226012372 21.33099895366186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2ffeb677-5170-4fa1-9f98-32769a135e20">
									<gml:exterior>
										<gml:LinearRing gml:id="line_95dd1ee6-02a0-4768-bf0d-2ff68c2aaf6e">
											<gml:posList>35.66859063351108 139.74785083137925 19.29400401957983 35.668591474155384 139.74785123011225 19.29400401957983 35.6685911487824 139.74785226012372 19.29400401957983 35.66859030813822 139.74785186155927 19.29400401957983 35.66859063351108 139.74785083137925 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gnd_TMmnt0165_b_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0165_b_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0165_b_0">
											<gml:posList>35.66861436872504 139.7478031425735 5.59242583 35.66858673484601 139.7478891839714 5.59176113 35.66854841400698 139.74787070101277 5.58987892 35.66854136239907 139.7478573934104 5.58946355 35.66861436872504 139.7478031425735 5.59242583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gml_38fb8d9f-ed76-4d7a-ae47-4cfd56cf3652">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_829594fa-59f9-43d8-b46c-0f7d22ebaf4c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_94abacd4-5c9f-40c5-a667-aa32f325df43">
											<gml:posList>35.66858801047075 139.74783740707372 6.547750052294674 35.668593419477425 139.74782058873228 6.547750052294674 35.6685915919358 139.74781972198085 6.547750052294674 35.66860878397718 139.74780633586957 6.547750052294674 35.668610310609985 139.7478089816377 6.547750052294674 35.668583614963765 139.7478919868432 6.547750052294674 35.66854619336461 139.7478742384264 6.547750052294674 35.668539329176184 139.74786041480579 6.547750052294674 35.66857612078802 139.7478317681427 6.547750052294674 35.66858801047075 139.74783740707372 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_bd914475-f77f-4870-8d9d-aafd2ae4a718">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4df94235-270b-40dd-9c95-1f1906a7a6b5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cc8551f6-5d41-41e7-9abf-0cd7d98d350e">
											<gml:posList>35.6685915919358 139.74781972198085 9.055745657763424 35.668593419477425 139.74782058873228 9.055745657763424 35.66858801047075 139.74783740707372 9.055745657763424 35.66857612078802 139.7478317681427 9.055745657763424 35.6685915919358 139.74781972198085 9.055745657763424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_c0fd84cf-ffb2-4666-845f-5c52144be258">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_26b639e2-1f32-4ad2-bd2c-44350c72e0cb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a400abbf-2937-4823-b359-2e4568eba1c4">
											<gml:posList>35.66858511638629 139.74786240577512 19.29400401957983 35.66859206828028 139.74786570293242 19.29400401957983 35.668610310609985 139.7478089816377 19.29400401957983 35.66860878397718 139.74780633586957 19.29400401957983 35.66855507264054 139.74784815666743 19.29400401957983 35.66857816738158 139.74785911013225 19.29400401957983 35.66858511638629 139.74786240577512 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_3e886fc9-cc69-4673-829b-3a7a76a83ae4">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c47a20a3-bba8-46fe-ae13-b4bcc22da58a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f9fb402d-fd42-4e6b-929c-92b5bd630cca">
											<gml:posList>35.66859206828028 139.74786570293242 22.49725108989233 35.66855507264054 139.74784815666743 22.49725108989233 35.668539329176184 139.74786041480579 22.49725108989233 35.66854619336461 139.7478742384264 22.49725108989233 35.668583614963765 139.7478919868432 22.49725108989233 35.66859206828028 139.74786570293242 22.49725108989233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0165_p936_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0165_p936_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0165_p936_0">
											<gml:posList>35.66855905185459 139.7478441908478 21.53684853 35.66854130322957 139.7478573798005 21.53612967 35.668548354819876 139.74787068736967 21.53654503 35.66858667556279 139.74788917028206 21.53842724 35.668595478812385 139.74786176033507 21.5386378 35.66855905185459 139.7478441908478 21.53684853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0165_p990_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0165_p990_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0165_p990_0">
											<gml:posList>35.66859548928129 139.74786176273957 18.72363805 35.66861431984973 139.74780313147767 18.72409219 35.66855906230735 139.74784419324445 18.72184878 35.66859548928129 139.74786176273957 18.72363805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_05066482-1a0b-45a6-b793-4dac03e963da">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_02015388-eb12-42f9-b023-226bbcd638aa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e195f9ef-ac19-4378-af1b-8668aba87de1">
											<gml:posList>35.668583614963765 139.7478919868432 22.49725108989233 35.668583614963765 139.7478919868432 6.547750052294674 35.668610310609985 139.7478089816377 6.547750052294674 35.668610310609985 139.7478089816377 19.29400401957983 35.66859206828028 139.74786570293242 19.29400401957983 35.66859206828028 139.74786570293242 22.49725108989233 35.668583614963765 139.7478919868432 22.49725108989233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_8dfef7f8-b7c1-4b4d-9b0c-a54d18daefb8">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d34da2c2-bc69-4099-a4f6-5acc2dd56b73">
									<gml:exterior>
										<gml:LinearRing gml:id="line_354c2603-10a1-426b-90c8-e1a43b572b35">
											<gml:posList>35.66854619336461 139.7478742384264 6.547750052294674 35.668544029815074 139.74786988155742 9.346639212450924 35.668539329176184 139.74786041480579 6.547750052294674 35.66854619336461 139.7478742384264 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b55c65a4-20ef-4777-9f3f-9c4724220926">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dea13dac-be49-471e-a39c-735942d6bfd8">
											<gml:posList>35.668544029815074 139.74786988155742 9.346639212450924 35.66854619336461 139.7478742384264 6.547750052294674 35.668544029815074 139.74786988155742 9.972936209521237 35.668544029815074 139.74786988155742 9.346639212450924</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_adeb50a4-1580-46b4-8e99-995cd31d164a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_29802c32-cb3b-452e-8d8b-b20b3478aaf7">
											<gml:posList>35.668539329176184 139.74786041480579 6.547750052294674 35.668544029815074 139.74786988155742 9.346639212450924 35.668541379232174 139.7478645434117 9.346639212450924 35.668539329176184 139.74786041480579 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_67d635a8-b12f-4b37-a14b-ea2b4690eec5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a70821d3-3ba9-4f50-a24b-2886b83bbac1">
											<gml:posList>35.668539329176184 139.74786041480579 6.547750052294674 35.668541379232174 139.7478645434117 9.346639212450924 35.668541379232174 139.7478645434117 9.972936209521237 35.668539329176184 139.74786041480579 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ea404a1b-67c5-4bad-a6e1-37f1d86567e9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d779ba6f-55c3-4134-b346-732587904b12">
											<gml:posList>35.668539329176184 139.74786041480579 6.547750052294674 35.668541379232174 139.7478645434117 12.364598807177487 35.668541379232174 139.7478645434117 12.990895804247799 35.668539329176184 139.74786041480579 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_95a34ae8-034f-4c10-b8da-66a140e12c78">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b7e486d8-a4c3-4863-9ebf-3d57ce6c8498">
											<gml:posList>35.668541379232174 139.7478645434117 12.364598807177487 35.668539329176184 139.74786041480579 6.547750052294674 35.668541379232174 139.7478645434117 9.972936209521237 35.668541379232174 139.7478645434117 12.364598807177487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3bb29457-4dd1-48c4-9252-33600df92f0e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_43bca597-3b2a-48f6-b01b-741986cd8a24">
											<gml:posList>35.668539329176184 139.74786041480579 6.547750052294674 35.668541379232174 139.7478645434117 12.990895804247799 35.668541379232174 139.7478645434117 15.329351004443112 35.668539329176184 139.74786041480579 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_19f8dff1-66f6-48a4-a294-5c85dca63eee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ad8a55c5-c323-4dc6-a094-8cbd762eeaeb">
											<gml:posList>35.668541379232174 139.7478645434117 9.972936209521237 35.668544029815074 139.74786988155742 12.364598807177487 35.668541379232174 139.7478645434117 12.364598807177487 35.668541379232174 139.7478645434117 9.972936209521237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9f1e79a0-2663-4bfa-94fa-9d5aad53f38a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dc1b70c2-0862-41f0-b1fb-16ee3da32f09">
											<gml:posList>35.668544029815074 139.74786988155742 12.364598807177487 35.668541379232174 139.7478645434117 9.972936209521237 35.668544029815074 139.74786988155742 9.972936209521237 35.668544029815074 139.74786988155742 12.364598807177487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9b6f8053-faf3-4d60-98ab-6f1328db5a1b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_35fe51cc-3fa4-469f-a8ca-9f4a105be75d">
											<gml:posList>35.668544029815074 139.74786988155742 12.364598807177487 35.66854619336461 139.7478742384264 6.547750052294674 35.668544029815074 139.74786988155742 12.990895804247799 35.668544029815074 139.74786988155742 12.364598807177487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9fd4a142-2891-4717-8eec-1d53ca064476">
									<gml:exterior>
										<gml:LinearRing gml:id="line_16597051-1422-498f-b381-f53296298d5c">
											<gml:posList>35.66854619336461 139.7478742384264 6.547750052294674 35.668544029815074 139.74786988155742 12.364598807177487 35.668544029815074 139.74786988155742 9.972936209521237 35.66854619336461 139.7478742384264 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a168e7b9-93e6-4a43-82b0-1d14950cfa87">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c0c5d951-38ba-4903-92d1-5160c421598c">
											<gml:posList>35.668544029815074 139.74786988155742 12.990895804247799 35.66854619336461 139.7478742384264 6.547750052294674 35.668544029815074 139.74786988155742 15.329351004443112 35.668544029815074 139.74786988155742 12.990895804247799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3df94054-ab15-42a4-951c-dd6fda85887a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9c00edea-8657-4a9c-9d16-2586efb79d91">
											<gml:posList>35.668544029815074 139.74786988155742 15.329351004443112 35.66854619336461 139.7478742384264 6.547750052294674 35.66854619336461 139.7478742384264 22.49725108989233 35.668544029815074 139.74786988155742 15.329351004443112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6305f62d-e4ff-48dc-96ce-e5296d1344f7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_41e1428a-fe82-446e-9e71-60d404931937">
											<gml:posList>35.668544029815074 139.74786988155742 18.418599661669674 35.66854619336461 139.7478742384264 22.49725108989233 35.668544029815074 139.74786988155742 19.044896658739987 35.668544029815074 139.74786988155742 18.418599661669674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_520d8c71-8320-4957-8ca5-0cb4d644a5bb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8ab46ac8-73d1-48cb-bba0-f59cd639dfb5">
											<gml:posList>35.66854619336461 139.7478742384264 22.49725108989233 35.668544029815074 139.74786988155742 18.418599661669674 35.668544029815074 139.74786988155742 15.955648001513424 35.66854619336461 139.7478742384264 22.49725108989233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_87cdf6c1-5511-4b0c-82d5-69663e5a609d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cbf5cb15-a1ca-4296-9dd3-96f92564cb52">
											<gml:posList>35.668544029815074 139.74786988155742 19.044896658739987 35.66854619336461 139.7478742384264 22.49725108989233 35.668539329176184 139.74786041480579 22.49725108989233 35.668544029815074 139.74786988155742 19.044896658739987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a1b9585a-c97a-4887-8b84-2f49ce6337e2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9c7a2545-4784-46d2-a5db-c8dfde562d99">
											<gml:posList>35.668544029815074 139.74786988155742 19.044896658739987 35.668539329176184 139.74786041480579 22.49725108989233 35.668541379232174 139.7478645434117 19.044896658739987 35.668544029815074 139.74786988155742 19.044896658739987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e42a3b04-f23b-4e9a-95d8-0cee3c804bea">
									<gml:exterior>
										<gml:LinearRing gml:id="line_816e98db-afc8-4439-b1d3-6f90e77c25f7">
											<gml:posList>35.668541379232174 139.7478645434117 19.044896658739987 35.668539329176184 139.74786041480579 22.49725108989233 35.668541379232174 139.7478645434117 18.418599661669674 35.668541379232174 139.7478645434117 19.044896658739987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4d837ec6-94dd-4148-a494-fae1f0654bb1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_afe9fae8-265a-4e07-b54f-d868dbee497d">
											<gml:posList>35.668541379232174 139.7478645434117 15.955648001513424 35.668539329176184 139.74786041480579 22.49725108989233 35.668541379232174 139.7478645434117 15.329351004443112 35.668541379232174 139.7478645434117 15.955648001513424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d8f06769-a74d-4356-91df-73bc18f650c0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_86a16be2-ca64-4010-b6cb-152dfaa1d9d4">
											<gml:posList>35.668539329176184 139.74786041480579 22.49725108989233 35.668541379232174 139.7478645434117 15.955648001513424 35.668541379232174 139.7478645434117 18.418599661669674 35.668539329176184 139.74786041480579 22.49725108989233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_487fdd2c-7fe3-40f2-93d3-93b5494c6790">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4d883c0f-b9ce-42e5-9edc-dfb26466f1cf">
											<gml:posList>35.668544029815074 139.74786988155742 15.955648001513424 35.668541379232174 139.7478645434117 18.418599661669674 35.668541379232174 139.7478645434117 15.955648001513424 35.668544029815074 139.74786988155742 15.955648001513424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b31c7a18-4dbe-4849-b396-1f32351c704c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_22771e08-d9f3-4c69-b9e4-0972b66ff892">
											<gml:posList>35.668541379232174 139.7478645434117 18.418599661669674 35.668544029815074 139.74786988155742 15.955648001513424 35.668544029815074 139.74786988155742 18.418599661669674 35.668541379232174 139.7478645434117 18.418599661669674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c22ef1ea-ab3c-4900-bcab-e4359ea4e002">
									<gml:exterior>
										<gml:LinearRing gml:id="line_61a710ef-5fcd-4104-8e75-bf5eb9cba2e2">
											<gml:posList>35.668544029815074 139.74786988155742 15.329351004443112 35.66854619336461 139.7478742384264 22.49725108989233 35.668544029815074 139.74786988155742 15.955648001513424 35.668544029815074 139.74786988155742 15.329351004443112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fca2f3fc-24f2-4325-aa15-a3df836e0fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9acec9de-df0b-47f0-9de4-d858c8150c2e">
											<gml:posList>35.668544029815074 139.74786988155742 12.990895804247799 35.668544029815074 139.74786988155742 15.329351004443112 35.668541379232174 139.7478645434117 12.990895804247799 35.668544029815074 139.74786988155742 12.990895804247799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fa7e8351-ba78-4aaf-8a1d-25c0ce6273b9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9c8fa109-969a-4838-9d97-c8c745a20e7b">
											<gml:posList>35.668541379232174 139.7478645434117 12.990895804247799 35.668544029815074 139.74786988155742 15.329351004443112 35.668541379232174 139.7478645434117 15.329351004443112 35.668541379232174 139.7478645434117 12.990895804247799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_66fbf9a0-9dd3-4b0a-a575-a312ec553f0d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0e6ad8b2-c0fe-4b20-ac01-9800952c4bfb">
											<gml:posList>35.668539329176184 139.74786041480579 6.547750052294674 35.668541379232174 139.7478645434117 15.329351004443112 35.668539329176184 139.74786041480579 22.49725108989233 35.668539329176184 139.74786041480579 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_1898a867-4d60-4246-a124-3b9f524b26df">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_6695ff02-eb60-4f66-a70d-7069be136a06">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ede3b349-aa81-46af-87df-fece72aba166">
													<gml:posList>35.668544029815074 139.74786988155742 18.418599661669674 35.668544029815074 139.74786988155742 19.044896658739987 35.668541379232174 139.7478645434117 19.044896658739987 35.668541379232174 139.7478645434117 18.418599661669674 35.668544029815074 139.74786988155742 18.418599661669674</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_8f901331-4ef6-4a68-b348-418fdc38ed20">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_fc7ad2d6-6d29-4342-9050-77ffe66a26b5">
											<gml:exterior>
												<gml:LinearRing gml:id="line_b7321fe3-3b0a-4d83-a764-19d974afad33">
													<gml:posList>35.668544029815074 139.74786988155742 15.329351004443112 35.668544029815074 139.74786988155742 15.955648001513424 35.668541379232174 139.7478645434117 15.955648001513424 35.668541379232174 139.7478645434117 15.329351004443112 35.668544029815074 139.74786988155742 15.329351004443112</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_5e8c7b9e-c5a5-44e5-9cbb-ac7a0065c166">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0da0f8d5-95b1-49ce-ad57-2914edae7388">
											<gml:exterior>
												<gml:LinearRing gml:id="line_21884274-ff5a-4c5c-b74a-a4180d9af472">
													<gml:posList>35.668544029815074 139.74786988155742 12.364598807177487 35.668544029815074 139.74786988155742 12.990895804247799 35.668541379232174 139.7478645434117 12.990895804247799 35.668541379232174 139.7478645434117 12.364598807177487 35.668544029815074 139.74786988155742 12.364598807177487</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_bbf55c3a-81c7-47b6-9d15-fad4e12a8bdd">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_4935ebe5-cbdf-4f07-8967-a0f642a0c473">
											<gml:exterior>
												<gml:LinearRing gml:id="line_392be170-12fc-4944-946b-cd9bbbad7181">
													<gml:posList>35.668544029815074 139.74786988155742 9.346639212450924 35.668544029815074 139.74786988155742 9.972936209521237 35.668541379232174 139.7478645434117 9.972936209521237 35.668541379232174 139.7478645434117 9.346639212450924 35.668544029815074 139.74786988155742 9.346639212450924</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_900521ab-54a2-4ed7-864f-db5bba20d4d6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_81af48fb-45b7-4887-9c74-ce82c4023deb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_de5facfe-bd63-4b12-806d-63197070db23">
											<gml:posList>35.66854619336461 139.7478742384264 22.49725108989233 35.66854619336461 139.7478742384264 6.547750052294674 35.668583614963765 139.7478919868432 6.547750052294674 35.668583614963765 139.7478919868432 22.49725108989233 35.66854619336461 139.7478742384264 22.49725108989233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_95a70c04-32f6-45ef-b008-c6cda61795de">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9a67fc81-d691-4581-be39-0c0872c101c8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f474ea1f-5f69-4599-89e9-37237658c0a0">
											<gml:posList>35.66858801047075 139.74783740707372 6.547750052294674 35.66857612078802 139.7478317681427 6.547750052294674 35.66857612078802 139.7478317681427 9.055745657763424 35.66858801047075 139.74783740707372 9.055745657763424 35.66858801047075 139.74783740707372 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_e2d45d61-a51d-4d60-9b31-86d123639587">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_235be5f0-9302-4f01-b3e7-13ab0e90c311">
											<gml:exterior>
												<gml:LinearRing gml:id="line_94bb128c-442c-4ac5-b8dd-22bb9a27fa44">
													<gml:posList>35.668593419477425 139.74782058873228 6.547750052294674 35.66858801047075 139.74783740707372 6.547750052294674 35.66858801047075 139.74783740707372 9.055745657763424 35.668593419477425 139.74782058873228 9.055745657763424 35.668593419477425 139.74782058873228 6.547750052294674</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0165_p936_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0165_p936_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0165_p936_3">
											<gml:posList>35.668595478812385 139.74786176033507 21.5386378 35.66859548928129 139.74786176273957 18.72363805 35.66855906230735 139.74784419324445 18.72184878 35.66855905185459 139.7478441908478 21.53684853 35.668595478812385 139.74786176033507 21.5386378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0165_p990_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0165_p990_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0165_p990_1">
											<gml:posList>35.66861436872504 139.7478031425735 5.59242583 35.66854136239907 139.7478573934104 5.58946355 35.66854130322957 139.7478573798005 21.53612967 35.66855905185459 139.7478441908478 21.53684853 35.66855906230735 139.74784419324445 18.72184878 35.66861431984973 139.74780313147767 18.72409219 35.66861436872504 139.7478031425735 5.59242583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7baabf6c-aef1-4330-9661-f08c90167004">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f2686ee3-438e-4c00-bac4-493aeb39ea8f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1f82e4f7-e581-4858-810d-ee3b3d22be97">
											<gml:posList>35.6685915919358 139.74781972198085 6.547750052294674 35.668593419477425 139.74782058873228 6.547750052294674 35.668593419477425 139.74782058873228 9.055745657763424 35.6685915919358 139.74781972198085 9.055745657763424 35.6685915919358 139.74781972198085 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_27eb1c51-66c2-4723-89ad-5d96681160f2">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e5054ac6-a1bb-4ba2-9730-57e1161b2f36">
									<gml:exterior>
										<gml:LinearRing gml:id="line_162f1398-47b9-421c-a96e-5cc05b6cca5c">
											<gml:posList>35.668597096352805 139.7478154359821 13.151494559130612 35.66858308505905 139.74782634558142 11.920033987841549 35.66858308505905 139.74782634558142 13.151494559130612 35.668597096352805 139.7478154359821 13.151494559130612</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fc61723b-75a0-41f4-acad-b5bfa35f008d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b70c558e-4a5d-4a89-acca-a431f6f138bc">
											<gml:posList>35.66858308505905 139.74782634558142 11.920033987841549 35.668597096352805 139.7478154359821 13.151494559130612 35.668597096352805 139.7478154359821 11.920033987841549 35.66858308505905 139.74782634558142 11.920033987841549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b35178aa-cba2-4173-820f-7a3e12d158bc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a9b5bbf4-7744-4faa-941a-5ab8223990a6">
											<gml:posList>35.668597096352805 139.7478154359821 16.108960684618893 35.66858308505905 139.74782634558142 14.969213064989987 35.66858308505905 139.74782634558142 16.108960684618893 35.668597096352805 139.7478154359821 16.108960684618893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b39b3f47-baaf-4d5b-8f02-fefea12906a2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4ae0f6fa-19d1-4a98-aec2-a0d3efc6bc0b">
											<gml:posList>35.66858308505905 139.74782634558142 14.969213064989987 35.668597096352805 139.7478154359821 16.108960684618893 35.668597096352805 139.7478154359821 14.969213064989987 35.66858308505905 139.74782634558142 14.969213064989987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ff167d29-3855-4f67-b1f4-39d211e482ca">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6ad03ab3-2272-4624-9634-cc78aec7e263">
											<gml:posList>35.668597096352805 139.7478154359821 10.102307852587643 35.66860878397718 139.74780633586957 6.547750052294674 35.6685915919358 139.74781972198085 9.055745657763424 35.668597096352805 139.7478154359821 10.102307852587643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8e1e9d3b-942e-4b0e-b41c-edfb4073060f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_75e0d36c-c917-48dc-aceb-dbf95355c1a1">
											<gml:posList>35.66860878397718 139.74780633586957 6.547750052294674 35.668597096352805 139.7478154359821 10.102307852587643 35.668597096352805 139.7478154359821 11.920033987841549 35.66860878397718 139.74780633586957 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9d97dc9a-1f6d-490e-8aec-5a1a21ed7892">
									<gml:exterior>
										<gml:LinearRing gml:id="line_06814682-b037-4f6e-8e74-0b95b7bde99e">
											<gml:posList>35.6685915919358 139.74781972198085 9.055745657763424 35.66860878397718 139.74780633586957 6.547750052294674 35.6685915919358 139.74781972198085 6.547750052294674 35.6685915919358 139.74781972198085 9.055745657763424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_93f32ba3-5a66-4aed-8e29-71ee0c9583ba">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4b57864a-9406-4c53-a6c4-7596d975d4db">
											<gml:posList>35.66858308505905 139.74782634558142 10.102307852587643 35.6685915919358 139.74781972198085 9.055745657763424 35.66857612078802 139.7478317681427 9.055745657763424 35.66858308505905 139.74782634558142 10.102307852587643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_22101fad-fe5f-45ff-a96d-bf14e129fa6f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e0805277-776f-4925-8fa8-e90ce07a6127">
											<gml:posList>35.6685915919358 139.74781972198085 9.055745657763424 35.66858308505905 139.74782634558142 10.102307852587643 35.668597096352805 139.7478154359821 10.102307852587643 35.6685915919358 139.74781972198085 9.055745657763424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bfcbce1b-076e-40b0-90c9-2a5c955a8c07">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1b25e9c7-2042-4ad1-9bee-e8b2ad6127a0">
											<gml:posList>35.66858308505905 139.74782634558142 10.102307852587643 35.66857612078802 139.7478317681427 9.055745657763424 35.668569770424945 139.74783671254988 10.102307852587643 35.66858308505905 139.74782634558142 10.102307852587643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_367323db-7b98-47a5-b727-9fb19ad508b3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e3b51975-ddfb-4ca9-be81-3f6f9c4aa7ff">
											<gml:posList>35.66858308505905 139.74782634558142 10.102307852587643 35.668569770424945 139.74783671254988 10.102307852587643 35.66858308505905 139.74782634558142 11.920033987841549 35.66858308505905 139.74782634558142 10.102307852587643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d0052f03-defa-43ba-96b8-1d6e289ab732">
									<gml:exterior>
										<gml:LinearRing gml:id="line_24dee6f7-89f6-4b79-ac4b-27065c8f67d0">
											<gml:posList>35.66858308505905 139.74782634558142 11.920033987841549 35.668569770424945 139.74783671254988 10.102307852587643 35.668569770424945 139.74783671254988 11.920033987841549 35.66858308505905 139.74782634558142 11.920033987841549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a59aa632-a4b2-43d7-87f8-92fca71753c4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4d867090-c215-4e72-968a-226cfc020d81">
											<gml:posList>35.668569770424945 139.74783671254988 11.920033987841549 35.66858308505905 139.74782634558142 13.151494559130612 35.66858308505905 139.74782634558142 11.920033987841549 35.668569770424945 139.74783671254988 11.920033987841549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_56419b5a-2c0d-4a23-915c-a6027246851f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e73e3546-e65c-4fc1-b674-e23eb715269f">
											<gml:posList>35.66858308505905 139.74782634558142 13.151494559130612 35.668569770424945 139.74783671254988 11.920033987841549 35.668569770424945 139.74783671254988 13.151494559130612 35.66858308505905 139.74782634558142 13.151494559130612</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b35267f9-01b0-491c-94d6-a16a11d63c9d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b93d0da8-8b59-4ec7-b6ea-3527b684c9a3">
											<gml:posList>35.66858308505905 139.74782634558142 13.151494559130612 35.668569770424945 139.74783671254988 13.151494559130612 35.66858308505905 139.74782634558142 14.969213064989987 35.66858308505905 139.74782634558142 13.151494559130612</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_636addbd-caa2-4a36-87d2-c130a7c0b662">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ed8178a9-0173-44b3-8151-7f2c6ed03ece">
											<gml:posList>35.668569770424945 139.74783671254988 13.151494559130612 35.66855575912917 139.74784762214176 11.920033987841549 35.66855575912917 139.74784762214176 13.151494559130612 35.668569770424945 139.74783671254988 13.151494559130612</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1d9cbb01-221d-407f-9266-97f9926b87f2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e6ca4411-94cf-4c2a-9e0d-152dd38da2a5">
											<gml:posList>35.66855575912917 139.74784762214176 11.920033987841549 35.668569770424945 139.74783671254988 13.151494559130612 35.668569770424945 139.74783671254988 11.920033987841549 35.66855575912917 139.74784762214176 11.920033987841549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_505a681f-f4ec-4641-9606-3fbdf2dae3b3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_adf8d1a1-416f-4d1c-89a8-0ed0034be485">
											<gml:posList>35.668569770424945 139.74783671254988 16.108960684618893 35.66855575912917 139.74784762214176 14.969213064989987 35.66855575912917 139.74784762214176 16.108960684618893 35.668569770424945 139.74783671254988 16.108960684618893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_38704e2b-e219-41a8-a7e4-c0df14e7b7d7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_23895803-022f-427a-9253-da0d2ef423ea">
											<gml:posList>35.66855575912917 139.74784762214176 14.969213064989987 35.668569770424945 139.74783671254988 16.108960684618893 35.668569770424945 139.74783671254988 14.969213064989987 35.66855575912917 139.74784762214176 14.969213064989987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_65321551-a08e-4342-be39-b95279c6b331">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8fef39ee-5487-4706-9778-6538dc1e05be">
											<gml:posList>35.668597096352805 139.7478154359821 13.151494559130612 35.66860878397718 139.74780633586957 6.547750052294674 35.668597096352805 139.7478154359821 11.920033987841549 35.668597096352805 139.7478154359821 13.151494559130612</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a4566292-7bc0-470d-9297-2dbd6f8bde86">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6fd6f1b4-7df1-412f-9d15-bd5277fed674">
											<gml:posList>35.66860878397718 139.74780633586957 6.547750052294674 35.668597096352805 139.7478154359821 13.151494559130612 35.66860878397718 139.74780633586957 19.29400401957983 35.66860878397718 139.74780633586957 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_568a66f6-b7c4-4be2-8ecb-8cbc5b2b40c0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6b4a5b48-3359-4c2d-b0ba-6f7abc9ceac3">
											<gml:posList>35.66860878397718 139.74780633586957 19.29400401957983 35.668597096352805 139.7478154359821 14.969213064989987 35.668597096352805 139.7478154359821 16.108960684618893 35.66860878397718 139.74780633586957 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ec2ab8d9-ac84-44a3-8bd0-09c2f7b84a92">
									<gml:exterior>
										<gml:LinearRing gml:id="line_66f33a08-9e61-432c-a9f9-c12cce02c369">
											<gml:posList>35.668597096352805 139.7478154359821 14.969213064989987 35.66860878397718 139.74780633586957 19.29400401957983 35.668597096352805 139.7478154359821 13.151494559130612 35.668597096352805 139.7478154359821 14.969213064989987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2441057b-e9b5-47cb-9564-fd415bf9b78c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_64e4360b-338b-4f62-ad17-f99f34931123">
											<gml:posList>35.66860878397718 139.74780633586957 19.29400401957983 35.668597096352805 139.7478154359821 17.926679190478268 35.66858308505905 139.74782634558142 17.926679190478268 35.66860878397718 139.74780633586957 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f42b39a0-7784-4829-8415-7d14af2ae989">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e1138adb-2d9b-4345-838f-48a63d3f26cf">
											<gml:posList>35.668597096352805 139.7478154359821 17.926679190478268 35.66860878397718 139.74780633586957 19.29400401957983 35.668597096352805 139.7478154359821 16.108960684618893 35.668597096352805 139.7478154359821 17.926679190478268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_29331b50-1498-443d-b4b7-0680f4054ab6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_310f8d5d-9ffb-4c5a-a3ea-e05041ba6d48">
											<gml:posList>35.66860878397718 139.74780633586957 19.29400401957983 35.66858308505905 139.74782634558142 17.926679190478268 35.66855507264054 139.74784815666743 19.29400401957983 35.66860878397718 139.74780633586957 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2a4bd4ed-8936-44f4-a332-1e9660ffe9d1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c8805965-5497-440b-941a-750164188658">
											<gml:posList>35.66855507264054 139.74784815666743 19.29400401957983 35.66858308505905 139.74782634558142 17.926679190478268 35.668569770424945 139.74783671254988 17.926679190478268 35.66855507264054 139.74784815666743 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7e930747-3181-4a76-ba11-a58631fd500e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_82078ffd-d67a-4a28-98e5-c1d301ec7c3e">
											<gml:posList>35.668569770424945 139.74783671254988 17.926679190478268 35.66858308505905 139.74782634558142 17.926679190478268 35.66858308505905 139.74782634558142 16.108960684618893 35.668569770424945 139.74783671254988 17.926679190478268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eeb05360-84b2-43d6-8ebf-def9efcbeff0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2924be99-cc22-42e3-b23e-5fe1f0d7db24">
											<gml:posList>35.668569770424945 139.74783671254988 16.108960684618893 35.66858308505905 139.74782634558142 16.108960684618893 35.668569770424945 139.74783671254988 14.969213064989987 35.668569770424945 139.74783671254988 16.108960684618893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f79a1d6d-e8fd-4dcb-95ae-c9c7c714614a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ca9bd88-b9eb-432d-853d-1dc9e96b2218">
											<gml:posList>35.66858308505905 139.74782634558142 16.108960684618893 35.668569770424945 139.74783671254988 16.108960684618893 35.668569770424945 139.74783671254988 17.926679190478268 35.66858308505905 139.74782634558142 16.108960684618893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_45475009-5406-46f7-a8c8-c2c670e6af8c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3f4bd481-4835-4a7b-8ab0-1ee1f2d0a53c">
											<gml:posList>35.668569770424945 139.74783671254988 14.969213064989987 35.66858308505905 139.74782634558142 16.108960684618893 35.66858308505905 139.74782634558142 14.969213064989987 35.668569770424945 139.74783671254988 14.969213064989987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e0636a5e-f0cd-4644-a6ed-b074166a9d9e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4604ef96-8710-4c94-944a-fb1b46d99c90">
											<gml:posList>35.668569770424945 139.74783671254988 10.102307852587643 35.66857612078802 139.7478317681427 9.055745657763424 35.66856238744216 139.74784246119196 8.877019461474362 35.668569770424945 139.74783671254988 10.102307852587643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_299a8e9f-56de-443f-816f-a293d7677b8b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ec4a3e0e-683c-4937-bfe8-43219fe0c92f">
											<gml:posList>35.66858308505905 139.74782634558142 14.969213064989987 35.668569770424945 139.74783671254988 13.151494559130612 35.668569770424945 139.74783671254988 14.969213064989987 35.66858308505905 139.74782634558142 14.969213064989987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e407967f-e794-4e7d-aa77-563038c47c0a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5d9e4cc0-46bb-4768-8172-21d72b1096d0">
											<gml:posList>35.66855507264054 139.74784815666743 19.29400401957983 35.668569770424945 139.74783671254988 17.926679190478268 35.66855575912917 139.74784762214176 17.926679190478268 35.66855507264054 139.74784815666743 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0b11ca9f-1714-4744-ac4e-feb3fd4798de">
									<gml:exterior>
										<gml:LinearRing gml:id="line_85f2c7ea-7c0d-4f02-a4df-8d4e1673a72a">
											<gml:posList>35.66856238744216 139.74784246119196 8.069081839404049 35.66857612078802 139.7478317681427 6.547750052294674 35.66855624079842 139.747847247113 8.069081839404049 35.66856238744216 139.74784246119196 8.069081839404049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fb06f7ed-39cd-4e50-b262-5449e5ce4e94">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ae010735-7d34-4cb1-bca0-de93beb49dc5">
											<gml:posList>35.66857612078802 139.7478317681427 6.547750052294674 35.66856238744216 139.74784246119196 8.069081839404049 35.66857612078802 139.7478317681427 9.055745657763424 35.66857612078802 139.7478317681427 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c078c79f-6a39-4787-b6b2-2531ba8ca038">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b5ff351b-c9a2-4ba5-8906-4b981046fe7b">
											<gml:posList>35.66855624079842 139.747847247113 8.069081839404049 35.66857612078802 139.7478317681427 6.547750052294674 35.668539329176184 139.74786041480579 6.547750052294674 35.66855624079842 139.747847247113 8.069081839404049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_16cf74e4-1cef-4067-95f4-d14842f68a8e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_711a721e-8148-405a-b396-f59ec7f25f4b">
											<gml:posList>35.66855624079842 139.747847247113 8.069081839404049 35.668539329176184 139.74786041480579 6.547750052294674 35.66855624079842 139.747847247113 8.877019461474362 35.66855624079842 139.747847247113 8.069081839404049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3f6a37d8-7a97-4285-8563-ca69a97721a9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d2f75242-8449-4cd5-9e93-7ae957491126">
											<gml:posList>35.66855624079842 139.747847247113 8.877019461474362 35.668539329176184 139.74786041480579 6.547750052294674 35.66855575912917 139.74784762214176 10.102307852587643 35.66855624079842 139.747847247113 8.877019461474362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_64cefaa0-54b1-43a8-a743-a9336a7d2f68">
									<gml:exterior>
										<gml:LinearRing gml:id="line_44f5b868-63a7-4e1e-96f3-fc1866ca6688">
											<gml:posList>35.66855575912917 139.74784762214176 10.102307852587643 35.668539329176184 139.74786041480579 6.547750052294674 35.66855575912917 139.74784762214176 11.920033987841549 35.66855575912917 139.74784762214176 10.102307852587643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3a9e6a78-fb53-4270-bc5e-86a1882c8b6c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_01972a13-2f7c-44aa-9ceb-a16f7c328cfb">
											<gml:posList>35.66855575912917 139.74784762214176 11.920033987841549 35.668539329176184 139.74786041480579 6.547750052294674 35.66855575912917 139.74784762214176 13.151494559130612 35.66855575912917 139.74784762214176 11.920033987841549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_02118006-c3ce-44cf-aa26-f5105a36b8b2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fb3f3107-a646-46f8-adfc-dacc199659c2">
											<gml:posList>35.66855575912917 139.74784762214176 13.151494559130612 35.668539329176184 139.74786041480579 6.547750052294674 35.66855575912917 139.74784762214176 14.969213064989987 35.66855575912917 139.74784762214176 13.151494559130612</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bb998be6-4a02-4191-845c-9e738e852355">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c99f1b0e-8f6e-486b-a431-6afbc347d4fb">
											<gml:posList>35.66855575912917 139.74784762214176 14.969213064989987 35.668539329176184 139.74786041480579 6.547750052294674 35.668539329176184 139.74786041480579 22.49725108989233 35.66855575912917 139.74784762214176 14.969213064989987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7d5d923f-7985-405b-801e-d7e4f441c480">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f35a538c-7640-4668-a3b2-d9d94052ff6a">
											<gml:posList>35.66855575912917 139.74784762214176 14.969213064989987 35.668539329176184 139.74786041480579 22.49725108989233 35.66855575912917 139.74784762214176 16.108960684618893 35.66855575912917 139.74784762214176 14.969213064989987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2bf279d3-6976-410f-ab11-cd163c3cf4c9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a36ada08-932f-451b-8d9e-238dee83817c">
											<gml:posList>35.66855575912917 139.74784762214176 16.108960684618893 35.668539329176184 139.74786041480579 22.49725108989233 35.66855575912917 139.74784762214176 17.926679190478268 35.66855575912917 139.74784762214176 16.108960684618893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_324efb25-d6ec-40ee-8ba8-6e0e7015c322">
									<gml:exterior>
										<gml:LinearRing gml:id="line_95fbecf7-8de6-43b9-8448-aedb0fabfaa6">
											<gml:posList>35.66855575912917 139.74784762214176 17.926679190478268 35.668539329176184 139.74786041480579 22.49725108989233 35.66855507264054 139.74784815666743 19.29400401957983 35.66855575912917 139.74784762214176 17.926679190478268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a00d3866-16d1-4e2f-81cf-7a6f8f045431">
									<gml:exterior>
										<gml:LinearRing gml:id="line_52a8b5bf-2db1-48f3-a0db-3a1cfaae1f7e">
											<gml:posList>35.66855507264054 139.74784815666743 19.29400401957983 35.668539329176184 139.74786041480579 22.49725108989233 35.66855507264054 139.74784815666743 22.49725108989233 35.66855507264054 139.74784815666743 19.29400401957983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5f0106b9-4d40-4187-ac82-0e9ee2255efd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cb2a1d29-4934-44f0-bc55-ecdcf9cb3c76">
											<gml:posList>35.668569770424945 139.74783671254988 10.102307852587643 35.66856238744216 139.74784246119196 8.877019461474362 35.66855575912917 139.74784762214176 10.102307852587643 35.668569770424945 139.74783671254988 10.102307852587643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_53adb501-0762-4d00-8edd-0745859e1575">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8b09af64-9d72-46e0-9db1-4f712a7d195d">
											<gml:posList>35.66855575912917 139.74784762214176 10.102307852587643 35.66856238744216 139.74784246119196 8.877019461474362 35.66855624079842 139.747847247113 8.877019461474362 35.66855575912917 139.74784762214176 10.102307852587643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_46e00aca-c467-41a0-ac9f-5f3519eba7ab">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f9acffbb-edf3-4bc0-8414-a6ca4ea3e86f">
											<gml:posList>35.66857612078802 139.7478317681427 9.055745657763424 35.66856238744216 139.74784246119196 8.069081839404049 35.66856238744216 139.74784246119196 8.877019461474362 35.66857612078802 139.7478317681427 9.055745657763424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_e7d85a96-9c45-40be-b032-51943ff28cb4">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_97879ed0-0a9e-4423-b2ba-698d960c9ae0">
											<gml:exterior>
												<gml:LinearRing gml:id="line_95ed03db-406c-4359-9a5b-0304d8ec7e7f">
													<gml:posList>35.66858308505905 139.74782634558142 17.926679190478268 35.668597096352805 139.7478154359821 17.926679190478268 35.668597096352805 139.7478154359821 16.108960684618893 35.66858308505905 139.74782634558142 16.108960684618893 35.66858308505905 139.74782634558142 17.926679190478268</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_8a3042b8-83e8-49ad-8610-7b27ffbdb8c6">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d5f0ecbb-36df-48f7-b418-dae77fc407c7">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e9c1a7e1-b747-491e-a9c6-d1eca9b34b8f">
													<gml:posList>35.66855575912917 139.74784762214176 11.920033987841549 35.668569770424945 139.74783671254988 11.920033987841549 35.668569770424945 139.74783671254988 10.102307852587643 35.66855575912917 139.74784762214176 10.102307852587643 35.66855575912917 139.74784762214176 11.920033987841549</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_017b986f-3628-4247-aa51-cf06aafcb0c8">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e706b390-aaae-4e85-85a3-5c1cf96916f6">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ca6c237c-d76d-4c89-ba23-626b26b5c989">
													<gml:posList>35.66855575912917 139.74784762214176 14.969213064989987 35.668569770424945 139.74783671254988 14.969213064989987 35.668569770424945 139.74783671254988 13.151494559130612 35.66855575912917 139.74784762214176 13.151494559130612 35.66855575912917 139.74784762214176 14.969213064989987</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_de63a876-f63a-4ce5-94a7-159de7e58a35">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_43e9a85f-880e-4a1e-8c72-7ec26c0c6114">
											<gml:exterior>
												<gml:LinearRing gml:id="line_465598bd-c58c-4ee0-949f-45b06987d055">
													<gml:posList>35.66855575912917 139.74784762214176 17.926679190478268 35.668569770424945 139.74783671254988 17.926679190478268 35.668569770424945 139.74783671254988 16.108960684618893 35.66855575912917 139.74784762214176 16.108960684618893 35.66855575912917 139.74784762214176 17.926679190478268</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_b3812f0b-2442-44b1-97fe-2e95d48da14e">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_b56840b9-0cce-40b4-9511-8d0f5d4c6857">
											<gml:exterior>
												<gml:LinearRing gml:id="line_cf4ce881-38af-4649-b9f2-05c7c9d269dc">
													<gml:posList>35.66858308505905 139.74782634558142 14.969213064989987 35.668597096352805 139.7478154359821 14.969213064989987 35.668597096352805 139.7478154359821 13.151494559130612 35.66858308505905 139.74782634558142 13.151494559130612 35.66858308505905 139.74782634558142 14.969213064989987</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_428024e6-6c2b-4a93-aa76-e8e4ff5d3cca">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_6e4b2f22-508a-4857-9e28-2e5be833806a">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e5c09cd0-3e4d-4ee1-ae61-fca618e7889d">
													<gml:posList>35.66856238744216 139.74784246119196 8.877019461474362 35.66856238744216 139.74784246119196 8.069081839404049 35.66855624079842 139.747847247113 8.069081839404049 35.66855624079842 139.747847247113 8.877019461474362 35.66856238744216 139.74784246119196 8.877019461474362</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_27a0eb80-6d68-4604-98c2-5bd23a9618ed">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_41694124-fc17-4c17-ac7f-7868b3955861">
											<gml:exterior>
												<gml:LinearRing gml:id="line_5c4d3b5d-fd2c-47dc-b432-c80d2958d677">
													<gml:posList>35.66858308505905 139.74782634558142 11.920033987841549 35.668597096352805 139.7478154359821 11.920033987841549 35.668597096352805 139.7478154359821 10.102307852587643 35.66858308505905 139.74782634558142 10.102307852587643 35.66858308505905 139.74782634558142 11.920033987841549</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_0ccb31b0-c722-4da7-8e44-461f2ea6c735">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_95881719-cc8d-44b2-8540-34e9000b627c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_799abac6-31f3-4f7a-847c-9079c9bb3689">
											<gml:posList>35.66860878397718 139.74780633586957 6.547750052294674 35.66860878397718 139.74780633586957 19.29400401957983 35.668610310609985 139.7478089816377 19.29400401957983 35.668610310609985 139.7478089816377 6.547750052294674 35.66860878397718 139.74780633586957 6.547750052294674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0165_p936_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0165_p936_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0165_p936_1">
											<gml:posList>35.66858667556279 139.74788917028206 21.53842724 35.668548354819876 139.74787068736967 21.53654503 35.66854841400698 139.74787070101277 5.58987892 35.66858673484601 139.7478891839714 5.59176113 35.66858667556279 139.74788917028206 21.53842724</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0165_p990_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0165_p990_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0165_p990_2">
											<gml:posList>35.66861431984973 139.74780313147767 18.72409219 35.66859548928129 139.74786176273957 18.72363805 35.668595478812385 139.74786176033507 21.5386378 35.66858667556279 139.74788917028206 21.53842724 35.66858673484601 139.7478891839714 5.59176113 35.66861436872504 139.7478031425735 5.59242583 35.66861431984973 139.74780313147767 18.72409219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0165_p936_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0165_p936_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0165_p936_2">
											<gml:posList>35.668548354819876 139.74787068736967 21.53654503 35.66854130322957 139.7478573798005 21.53612967 35.66854136239907 139.7478573934104 5.58946355 35.66854841400698 139.74787070101277 5.58987892 35.668548354819876 139.74787068736967 21.53654503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_25846c9f-1a48-406a-a0f4-0e527cddca0a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b43bf495-34b5-4a2f-bb7a-fdb3c6e02c58">
									<gml:exterior>
										<gml:LinearRing gml:id="line_de129e72-e91e-4b98-b620-9c6f14b5a0e8">
											<gml:posList>35.66857816738158 139.74785911013225 21.20660930522436 35.66857816738158 139.74785911013225 19.29400401957983 35.66855507264054 139.74784815666743 19.29400401957983 35.66855507264054 139.74784815666743 22.49725108989233 35.66859206828028 139.74786570293242 22.49725108989233 35.66859206828028 139.74786570293242 19.29400401957983 35.66858511638629 139.74786240577512 19.29400401957983 35.66858511638629 139.74786240577512 21.20660930522436 35.66857816738158 139.74785911013225 21.20660930522436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_323ec17e-00cf-4ffb-ab58-89dc93ce7903">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_8f366202-63cf-4661-bf5f-7ac0364354c6">
											<gml:exterior>
												<gml:LinearRing gml:id="line_9080f343-ee69-424c-8504-64d42bc83bca">
													<gml:posList>35.66858511638629 139.74786240577512 19.29400401957983 35.66857816738158 139.74785911013225 19.29400401957983 35.66857816738158 139.74785911013225 21.20660930522436 35.66858511638629 139.74786240577512 21.20660930522436 35.66858511638629 139.74786240577512 19.29400401957983</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:lod3Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#Poly_8f366202-63cf-4661-bf5f-7ac0364354c6"/>
							<gml:surfaceMember xlink:href="#Poly_d34da2c2-bc69-4099-a4f6-5acc2dd56b73"/>
							<gml:surfaceMember xlink:href="#Poly_b55c65a4-20ef-4777-9f3f-9c4724220926"/>
							<gml:surfaceMember xlink:href="#Poly_adeb50a4-1580-46b4-8e99-995cd31d164a"/>
							<gml:surfaceMember xlink:href="#Poly_67d635a8-b12f-4b37-a14b-ea2b4690eec5"/>
							<gml:surfaceMember xlink:href="#Poly_ea404a1b-67c5-4bad-a6e1-37f1d86567e9"/>
							<gml:surfaceMember xlink:href="#Poly_95a34ae8-034f-4c10-b8da-66a140e12c78"/>
							<gml:surfaceMember xlink:href="#Poly_3bb29457-4dd1-48c4-9252-33600df92f0e"/>
							<gml:surfaceMember xlink:href="#Poly_19f8dff1-66f6-48a4-a294-5c85dca63eee"/>
							<gml:surfaceMember xlink:href="#Poly_9f1e79a0-2663-4bfa-94fa-9d5aad53f38a"/>
							<gml:surfaceMember xlink:href="#Poly_9b6f8053-faf3-4d60-98ab-6f1328db5a1b"/>
							<gml:surfaceMember xlink:href="#Poly_9fd4a142-2891-4717-8eec-1d53ca064476"/>
							<gml:surfaceMember xlink:href="#Poly_a168e7b9-93e6-4a43-82b0-1d14950cfa87"/>
							<gml:surfaceMember xlink:href="#Poly_3df94054-ab15-42a4-951c-dd6fda85887a"/>
							<gml:surfaceMember xlink:href="#Poly_6305f62d-e4ff-48dc-96ce-e5296d1344f7"/>
							<gml:surfaceMember xlink:href="#Poly_520d8c71-8320-4957-8ca5-0cb4d644a5bb"/>
							<gml:surfaceMember xlink:href="#Poly_87cdf6c1-5511-4b0c-82d5-69663e5a609d"/>
							<gml:surfaceMember xlink:href="#Poly_a1b9585a-c97a-4887-8b84-2f49ce6337e2"/>
							<gml:surfaceMember xlink:href="#Poly_e42a3b04-f23b-4e9a-95d8-0cee3c804bea"/>
							<gml:surfaceMember xlink:href="#Poly_4d837ec6-94dd-4148-a494-fae1f0654bb1"/>
							<gml:surfaceMember xlink:href="#Poly_d8f06769-a74d-4356-91df-73bc18f650c0"/>
							<gml:surfaceMember xlink:href="#Poly_487fdd2c-7fe3-40f2-93d3-93b5494c6790"/>
							<gml:surfaceMember xlink:href="#Poly_b31c7a18-4dbe-4849-b396-1f32351c704c"/>
							<gml:surfaceMember xlink:href="#Poly_c22ef1ea-ab3c-4900-bcab-e4359ea4e002"/>
							<gml:surfaceMember xlink:href="#Poly_fca2f3fc-24f2-4325-aa15-a3df836e0fd5"/>
							<gml:surfaceMember xlink:href="#Poly_fa7e8351-ba78-4aaf-8a1d-25c0ce6273b9"/>
							<gml:surfaceMember xlink:href="#Poly_66fbf9a0-9dd3-4b0a-a575-a312ec553f0d"/>
							<gml:surfaceMember xlink:href="#Poly_4935ebe5-cbdf-4f07-8967-a0f642a0c473"/>
							<gml:surfaceMember xlink:href="#Poly_0da0f8d5-95b1-49ce-ad57-2914edae7388"/>
							<gml:surfaceMember xlink:href="#Poly_fc7ad2d6-6d29-4342-9050-77ffe66a26b5"/>
							<gml:surfaceMember xlink:href="#Poly_6e4b2f22-508a-4857-9e28-2e5be833806a"/>
							<gml:surfaceMember xlink:href="#Poly_43e9a85f-880e-4a1e-8c72-7ec26c0c6114"/>
							<gml:surfaceMember xlink:href="#Poly_e706b390-aaae-4e85-85a3-5c1cf96916f6"/>
							<gml:surfaceMember xlink:href="#Poly_d5f0ecbb-36df-48f7-b418-dae77fc407c7"/>
							<gml:surfaceMember xlink:href="#Poly_41694124-fc17-4c17-ac7f-7868b3955861"/>
							<gml:surfaceMember xlink:href="#Poly_b56840b9-0cce-40b4-9511-8d0f5d4c6857"/>
							<gml:surfaceMember xlink:href="#Poly_97879ed0-0a9e-4423-b2ba-698d960c9ae0"/>
							<gml:surfaceMember xlink:href="#Poly_e5054ac6-a1bb-4ba2-9730-57e1161b2f36"/>
							<gml:surfaceMember xlink:href="#Poly_fc61723b-75a0-41f4-acad-b5bfa35f008d"/>
							<gml:surfaceMember xlink:href="#Poly_b35178aa-cba2-4173-820f-7a3e12d158bc"/>
							<gml:surfaceMember xlink:href="#Poly_b39b3f47-baaf-4d5b-8f02-fefea12906a2"/>
							<gml:surfaceMember xlink:href="#Poly_ff167d29-3855-4f67-b1f4-39d211e482ca"/>
							<gml:surfaceMember xlink:href="#Poly_8e1e9d3b-942e-4b0e-b41c-edfb4073060f"/>
							<gml:surfaceMember xlink:href="#Poly_9d97dc9a-1f6d-490e-8aec-5a1a21ed7892"/>
							<gml:surfaceMember xlink:href="#Poly_93f32ba3-5a66-4aed-8e29-71ee0c9583ba"/>
							<gml:surfaceMember xlink:href="#Poly_22101fad-fe5f-45ff-a96d-bf14e129fa6f"/>
							<gml:surfaceMember xlink:href="#Poly_bfcbce1b-076e-40b0-90c9-2a5c955a8c07"/>
							<gml:surfaceMember xlink:href="#Poly_367323db-7b98-47a5-b727-9fb19ad508b3"/>
							<gml:surfaceMember xlink:href="#Poly_d0052f03-defa-43ba-96b8-1d6e289ab732"/>
							<gml:surfaceMember xlink:href="#Poly_a59aa632-a4b2-43d7-87f8-92fca71753c4"/>
							<gml:surfaceMember xlink:href="#Poly_56419b5a-2c0d-4a23-915c-a6027246851f"/>
							<gml:surfaceMember xlink:href="#Poly_b35267f9-01b0-491c-94d6-a16a11d63c9d"/>
							<gml:surfaceMember xlink:href="#Poly_636addbd-caa2-4a36-87d2-c130a7c0b662"/>
							<gml:surfaceMember xlink:href="#Poly_1d9cbb01-221d-407f-9266-97f9926b87f2"/>
							<gml:surfaceMember xlink:href="#Poly_505a681f-f4ec-4641-9606-3fbdf2dae3b3"/>
							<gml:surfaceMember xlink:href="#Poly_38704e2b-e219-41a8-a7e4-c0df14e7b7d7"/>
							<gml:surfaceMember xlink:href="#Poly_65321551-a08e-4342-be39-b95279c6b331"/>
							<gml:surfaceMember xlink:href="#Poly_a4566292-7bc0-470d-9297-2dbd6f8bde86"/>
							<gml:surfaceMember xlink:href="#Poly_568a66f6-b7c4-4be2-8ecb-8cbc5b2b40c0"/>
							<gml:surfaceMember xlink:href="#Poly_ec2ab8d9-ac84-44a3-8bd0-09c2f7b84a92"/>
							<gml:surfaceMember xlink:href="#Poly_2441057b-e9b5-47cb-9564-fd415bf9b78c"/>
							<gml:surfaceMember xlink:href="#Poly_f42b39a0-7784-4829-8415-7d14af2ae989"/>
							<gml:surfaceMember xlink:href="#Poly_29331b50-1498-443d-b4b7-0680f4054ab6"/>
							<gml:surfaceMember xlink:href="#Poly_2a4bd4ed-8936-44f4-a332-1e9660ffe9d1"/>
							<gml:surfaceMember xlink:href="#Poly_7e930747-3181-4a76-ba11-a58631fd500e"/>
							<gml:surfaceMember xlink:href="#Poly_eeb05360-84b2-43d6-8ebf-def9efcbeff0"/>
							<gml:surfaceMember xlink:href="#Poly_f79a1d6d-e8fd-4dcb-95ae-c9c7c714614a"/>
							<gml:surfaceMember xlink:href="#Poly_45475009-5406-46f7-a8c8-c2c670e6af8c"/>
							<gml:surfaceMember xlink:href="#Poly_e0636a5e-f0cd-4644-a6ed-b074166a9d9e"/>
							<gml:surfaceMember xlink:href="#Poly_299a8e9f-56de-443f-816f-a293d7677b8b"/>
							<gml:surfaceMember xlink:href="#Poly_e407967f-e794-4e7d-aa77-563038c47c0a"/>
							<gml:surfaceMember xlink:href="#Poly_0b11ca9f-1714-4744-ac4e-feb3fd4798de"/>
							<gml:surfaceMember xlink:href="#Poly_fb06f7ed-39cd-4e50-b262-5449e5ce4e94"/>
							<gml:surfaceMember xlink:href="#Poly_c078c79f-6a39-4787-b6b2-2531ba8ca038"/>
							<gml:surfaceMember xlink:href="#Poly_16cf74e4-1cef-4067-95f4-d14842f68a8e"/>
							<gml:surfaceMember xlink:href="#Poly_3f6a37d8-7a97-4285-8563-ca69a97721a9"/>
							<gml:surfaceMember xlink:href="#Poly_64cefaa0-54b1-43a8-a743-a9336a7d2f68"/>
							<gml:surfaceMember xlink:href="#Poly_3a9e6a78-fb53-4270-bc5e-86a1882c8b6c"/>
							<gml:surfaceMember xlink:href="#Poly_02118006-c3ce-44cf-aa26-f5105a36b8b2"/>
							<gml:surfaceMember xlink:href="#Poly_bb998be6-4a02-4191-845c-9e738e852355"/>
							<gml:surfaceMember xlink:href="#Poly_7d5d923f-7985-405b-801e-d7e4f441c480"/>
							<gml:surfaceMember xlink:href="#Poly_2bf279d3-6976-410f-ab11-cd163c3cf4c9"/>
							<gml:surfaceMember xlink:href="#Poly_324efb25-d6ec-40ee-8ba8-6e0e7015c322"/>
							<gml:surfaceMember xlink:href="#Poly_a00d3866-16d1-4e2f-81cf-7a6f8f045431"/>
							<gml:surfaceMember xlink:href="#Poly_5f0106b9-4d40-4187-ac82-0e9ee2255efd"/>
							<gml:surfaceMember xlink:href="#Poly_53adb501-0762-4d00-8edd-0745859e1575"/>
							<gml:surfaceMember xlink:href="#Poly_46e00aca-c467-41a0-ac9f-5f3519eba7ab"/>
							<gml:surfaceMember xlink:href="#Poly_829594fa-59f9-43d8-b46c-0f7d22ebaf4c"/>
							<gml:surfaceMember xlink:href="#Poly_b43bf495-34b5-4a2f-bb7a-fdb3c6e02c58"/>
							<gml:surfaceMember xlink:href="#Poly_6695ff02-eb60-4f66-a70d-7069be136a06"/>
							<gml:surfaceMember xlink:href="#Poly_81af48fb-45b7-4887-9c74-ce82c4023deb"/>
							<gml:surfaceMember xlink:href="#Poly_02015388-eb12-42f9-b023-226bbcd638aa"/>
							<gml:surfaceMember xlink:href="#Poly_c47a20a3-bba8-46fe-ae13-b4bcc22da58a"/>
							<gml:surfaceMember xlink:href="#Poly_26b639e2-1f32-4ad2-bd2c-44350c72e0cb"/>
							<gml:surfaceMember xlink:href="#Poly_95881719-cc8d-44b2-8540-34e9000b627c"/>
							<gml:surfaceMember xlink:href="#Poly_f2686ee3-438e-4c00-bac4-493aeb39ea8f"/>
							<gml:surfaceMember xlink:href="#Poly_9a67fc81-d691-4581-be39-0c0872c101c8"/>
							<gml:surfaceMember xlink:href="#Poly_235be5f0-9302-4f01-b3e7-13ab0e90c311"/>
							<gml:surfaceMember xlink:href="#Poly_4df94235-270b-40dd-9c95-1f1906a7a6b5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod3Solid>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">3</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">2</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">2</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
					<uro:lodType>3.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">19.49585</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">9</uro:districtsAndZonesType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.43</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2400400000</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>