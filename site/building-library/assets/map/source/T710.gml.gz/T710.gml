<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cc869ea9-86c6-437a-9689-743854db3705">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">50.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.666850933893144 139.73843404325737 0 35.66684247811002 139.73845578029776 0 35.6668484080928 139.738477323584 0 35.66685883100663 139.73849262069746 0 35.66687342217842 139.7384785532128 0 35.666900557686425 139.7385181754638 0 35.66688791376219 139.7385326051546 0 35.66696657690882 139.73863605538227 0 35.66696849618197 139.7386123046688 0 35.667072048020515 139.73847748982067 0 35.667012052699356 139.73840898849386 0 35.66701804833563 139.73839945992015 0 35.66698413903967 139.73836564471466 0 35.666975442676154 139.73837947329747 0 35.66696666555295 139.7383823335044 0 35.66693889644193 139.73836227410288 0 35.66692570596538 139.73838084664115 0 35.666850933893144 139.73843404325737 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666850933893144 139.73843404325737 11.91 35.66692570596538 139.73838084664115 11.91 35.66693889644193 139.73836227410288 11.91 35.66696666555295 139.7383823335044 11.91 35.666975442676154 139.73837947329747 11.91 35.66698413903967 139.73836564471466 11.91 35.66701804833563 139.73839945992015 11.91 35.667012052699356 139.73840898849386 11.91 35.667072048020515 139.73847748982067 11.91 35.66696849618197 139.7386123046688 11.91 35.66696657690882 139.73863605538227 11.91 35.66688791376219 139.7385326051546 11.91 35.666900557686425 139.7385181754638 11.91 35.66687342217842 139.7384785532128 11.91 35.66685883100663 139.73849262069746 11.91 35.6668484080928 139.738477323584 11.91 35.66684247811002 139.73845578029776 11.91 35.666850933893144 139.73843404325737 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666850933893144 139.73843404325737 11.91 35.66684247811002 139.73845578029776 11.91 35.66684247811002 139.73845578029776 62.17 35.666850933893144 139.73843404325737 62.17 35.666850933893144 139.73843404325737 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66684247811002 139.73845578029776 11.91 35.6668484080928 139.738477323584 11.91 35.6668484080928 139.738477323584 62.17 35.66684247811002 139.73845578029776 62.17 35.66684247811002 139.73845578029776 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6668484080928 139.738477323584 11.91 35.66685883100663 139.73849262069746 11.91 35.66685883100663 139.73849262069746 62.17 35.6668484080928 139.738477323584 62.17 35.6668484080928 139.738477323584 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66685883100663 139.73849262069746 11.91 35.66687342217842 139.7384785532128 11.91 35.66687342217842 139.7384785532128 62.17 35.66685883100663 139.73849262069746 62.17 35.66685883100663 139.73849262069746 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687342217842 139.7384785532128 11.91 35.666900557686425 139.7385181754638 11.91 35.666900557686425 139.7385181754638 62.17 35.66687342217842 139.7384785532128 62.17 35.66687342217842 139.7384785532128 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666900557686425 139.7385181754638 11.91 35.66688791376219 139.7385326051546 11.91 35.66688791376219 139.7385326051546 62.17 35.666900557686425 139.7385181754638 62.17 35.666900557686425 139.7385181754638 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66688791376219 139.7385326051546 11.91 35.66696657690882 139.73863605538227 11.91 35.66696657690882 139.73863605538227 62.17 35.66688791376219 139.7385326051546 62.17 35.66688791376219 139.7385326051546 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66696657690882 139.73863605538227 11.91 35.66696849618197 139.7386123046688 11.91 35.66696849618197 139.7386123046688 62.17 35.66696657690882 139.73863605538227 62.17 35.66696657690882 139.73863605538227 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66696849618197 139.7386123046688 11.91 35.667072048020515 139.73847748982067 11.91 35.667072048020515 139.73847748982067 62.17 35.66696849618197 139.7386123046688 62.17 35.66696849618197 139.7386123046688 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667072048020515 139.73847748982067 11.91 35.667012052699356 139.73840898849386 11.91 35.667012052699356 139.73840898849386 62.17 35.667072048020515 139.73847748982067 62.17 35.667072048020515 139.73847748982067 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667012052699356 139.73840898849386 11.91 35.66701804833563 139.73839945992015 11.91 35.66701804833563 139.73839945992015 62.17 35.667012052699356 139.73840898849386 62.17 35.667012052699356 139.73840898849386 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66701804833563 139.73839945992015 11.91 35.66698413903967 139.73836564471466 11.91 35.66698413903967 139.73836564471466 62.17 35.66701804833563 139.73839945992015 62.17 35.66701804833563 139.73839945992015 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66698413903967 139.73836564471466 11.91 35.666975442676154 139.73837947329747 11.91 35.666975442676154 139.73837947329747 62.17 35.66698413903967 139.73836564471466 62.17 35.66698413903967 139.73836564471466 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666975442676154 139.73837947329747 11.91 35.66696666555295 139.7383823335044 11.91 35.66696666555295 139.7383823335044 62.17 35.666975442676154 139.73837947329747 62.17 35.666975442676154 139.73837947329747 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66696666555295 139.7383823335044 11.91 35.66693889644193 139.73836227410288 11.91 35.66693889644193 139.73836227410288 62.17 35.66696666555295 139.7383823335044 62.17 35.66696666555295 139.7383823335044 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693889644193 139.73836227410288 11.91 35.66692570596538 139.73838084664115 11.91 35.66692570596538 139.73838084664115 62.17 35.66693889644193 139.73836227410288 62.17 35.66693889644193 139.73836227410288 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66692570596538 139.73838084664115 11.91 35.666850933893144 139.73843404325737 11.91 35.666850933893144 139.73843404325737 62.17 35.66692570596538 139.73838084664115 62.17 35.66692570596538 139.73838084664115 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666850933893144 139.73843404325737 62.17 35.66684247811002 139.73845578029776 62.17 35.6668484080928 139.738477323584 62.17 35.66685883100663 139.73849262069746 62.17 35.66687342217842 139.7384785532128 62.17 35.666900557686425 139.7385181754638 62.17 35.66688791376219 139.7385326051546 62.17 35.66696657690882 139.73863605538227 62.17 35.66696849618197 139.7386123046688 62.17 35.667072048020515 139.73847748982067 62.17 35.667012052699356 139.73840898849386 62.17 35.66701804833563 139.73839945992015 62.17 35.66698413903967 139.73836564471466 62.17 35.666975442676154 139.73837947329747 62.17 35.66696666555295 139.7383823335044 62.17 35.66693889644193 139.73836227410288 62.17 35.66692570596538 139.73838084664115 62.17 35.666850933893144 139.73843404325737 62.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-47a30dd1-fe53-44cf-85ff-87351ddc508b"/>
							<gml:surfaceMember xlink:href="#poly-81784a57-dbde-402a-a0c9-cd3a2fb5c9e5"/>
							<gml:surfaceMember xlink:href="#poly-5bc2573c-17ea-40c1-b3b8-30608aa20780"/>
							<gml:surfaceMember xlink:href="#poly-f3bccf1f-6d18-4927-8d7f-cae2bcf4a256"/>
							<gml:surfaceMember xlink:href="#poly-9ecdcd73-b905-487d-bad6-102273e967df"/>
							<gml:surfaceMember xlink:href="#poly-10bec0ce-0887-4520-b9f6-64c10016cad0"/>
							<gml:surfaceMember xlink:href="#poly-ecbddcc0-c7f0-448c-829d-7913e698241d"/>
							<gml:surfaceMember xlink:href="#poly-e338792a-0bbd-4d66-adac-7f851f82e667"/>
							<gml:surfaceMember xlink:href="#poly-fa00cc5d-7e15-4163-9ea0-d782dcdc4ae5"/>
							<gml:surfaceMember xlink:href="#poly-0200061a-3311-467b-b4c9-b6b3d341dcb5"/>
							<gml:surfaceMember xlink:href="#poly-f0082a06-8b25-4031-ada3-9e7fadb59403"/>
							<gml:surfaceMember xlink:href="#poly-ddfb998a-c224-4705-9bcf-a8c61ba31336"/>
							<gml:surfaceMember xlink:href="#poly-8e32cd93-dce9-416f-85b9-cd03d2500485"/>
							<gml:surfaceMember xlink:href="#poly-df4b090a-93bf-420d-bf6d-c749c2c23d39"/>
							<gml:surfaceMember xlink:href="#poly-13624d89-33bf-42c0-82f0-cf524e392621"/>
							<gml:surfaceMember xlink:href="#poly-4cea908a-e9b9-45d9-b74a-d2dd6f1b6257"/>
							<gml:surfaceMember xlink:href="#poly-0339b0cf-8f82-43a5-9b41-3c0e069980e8"/>
							<gml:surfaceMember xlink:href="#poly-d70b9dcf-ff95-4f20-ba63-23deebfd3c6e"/>
							<gml:surfaceMember xlink:href="#poly-7b7d6430-b267-4ba1-9208-988e7a345c90"/>
							<gml:surfaceMember xlink:href="#poly-b9796cdd-07c1-4eeb-893a-8bed137a7717"/>
							<gml:surfaceMember xlink:href="#poly-02556c3b-9d40-49cb-9126-59de1e63e8a5"/>
							<gml:surfaceMember xlink:href="#poly-d259837d-cff5-4d90-bc6a-05af7e0576b9"/>
							<gml:surfaceMember xlink:href="#poly-f4f3141f-31de-442e-9a6d-28d536304976"/>
							<gml:surfaceMember xlink:href="#poly-d43c7624-273a-4248-b1e6-ac6447f47245"/>
							<gml:surfaceMember xlink:href="#poly-1b3f147e-c304-4d91-9ca6-8efcad16c753"/>
							<gml:surfaceMember xlink:href="#poly-0cb52908-2e21-42fc-bfbf-ddb8192c4796"/>
							<gml:surfaceMember xlink:href="#poly-a012bf48-6244-4792-a506-fa398bc92724"/>
							<gml:surfaceMember xlink:href="#poly-e730cad9-7c54-471a-8dbc-8bc993a8dec2"/>
							<gml:surfaceMember xlink:href="#poly-6521d844-52fe-41a2-b23c-ef35dd5dbd52"/>
							<gml:surfaceMember xlink:href="#poly-c37d0f0e-7ff2-4a69-add6-7ac40fbbf5df"/>
							<gml:surfaceMember xlink:href="#poly-1a918bd3-9135-4e80-9845-c3be27f74fdc"/>
							<gml:surfaceMember xlink:href="#poly-a5b80ba2-b699-4510-8ed4-3ae3bacab85b"/>
							<gml:surfaceMember xlink:href="#poly-e7be80a8-b620-4c4a-b51b-dd1c487b4a10"/>
							<gml:surfaceMember xlink:href="#poly-90910842-6138-4fc3-85af-996df4163cdb"/>
							<gml:surfaceMember xlink:href="#poly-ce7874f4-8af3-49cd-a1e3-3a462c8aa862"/>
							<gml:surfaceMember xlink:href="#poly-134f3f9f-1c77-4b61-aff4-4b4ff827c9e0"/>
							<gml:surfaceMember xlink:href="#poly-8b8e3fff-f945-4ba3-b188-08f340da268e"/>
							<gml:surfaceMember xlink:href="#poly-beb1bfc6-e289-4242-90cd-e7fbfac43810"/>
							<gml:surfaceMember xlink:href="#poly-877ffba9-523c-4b7b-8606-4dc5fe24f0ce"/>
							<gml:surfaceMember xlink:href="#poly-39be350e-5351-43df-96f3-fc9592eb7be6"/>
							<gml:surfaceMember xlink:href="#poly-492995cf-e12b-47ab-b6ad-13b3d81f5a9c"/>
							<gml:surfaceMember xlink:href="#poly-6cc849c9-fdcb-4e79-8f7a-c43ca8b038a3"/>
							<gml:surfaceMember xlink:href="#poly-14f49e1b-18c1-4ff2-bf1a-3f59281e4f89"/>
							<gml:surfaceMember xlink:href="#poly-d0cd35f6-de0a-46c0-b2e7-892f324dbc93"/>
							<gml:surfaceMember xlink:href="#poly-618fccd9-1e62-437a-8c6c-5aef00cc0c75"/>
							<gml:surfaceMember xlink:href="#poly-e679c857-77d1-4f65-8560-ad091f6f114e"/>
							<gml:surfaceMember xlink:href="#poly-749d42db-25eb-4a01-841a-6d892ec43cf5"/>
							<gml:surfaceMember xlink:href="#poly-62560e98-a309-4c23-baa7-d03c05a8b74d"/>
							<gml:surfaceMember xlink:href="#poly-18f0341f-1da2-4a12-83a8-2df82f0c323f"/>
							<gml:surfaceMember xlink:href="#poly-d13825cd-534b-4738-a42b-70a18dcae17c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-47a30dd1-fe53-44cf-85ff-87351ddc508b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47a30dd1-fe53-44cf-85ff-87351ddc508b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47a30dd1-fe53-44cf-85ff-87351ddc508b">
											<gml:posList>35.66692570596536 139.73838084664112 11.91 35.666938896441906 139.73836227410288 11.91 35.66696666555292 139.7383823335044 11.91 35.66697544267615 139.73837947329747 11.91 35.66698413903967 139.73836564471466 11.91 35.6670180483356 139.73839945992012 11.91 35.66701205269934 139.73840898849386 11.91 35.66707204802051 139.73847748982064 11.91 35.66696849618196 139.7386123046688 11.91 35.6669665769088 139.73863605538227 11.91 35.66688791376218 139.7385326051546 11.91 35.66690055768643 139.7385181754638 11.91 35.666873422178405 139.7384785532128 11.91 35.66685883100662 139.73849262069746 11.91 35.66684840809278 139.738477323584 11.91 35.66684247811 139.73845578029776 11.91 35.66685093389313 139.73843404325737 11.91 35.66692570596536 139.73838084664112 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81784a57-dbde-402a-a0c9-cd3a2fb5c9e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81784a57-dbde-402a-a0c9-cd3a2fb5c9e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81784a57-dbde-402a-a0c9-cd3a2fb5c9e5">
											<gml:posList>35.66697544267615 139.73837947329747 67.807 35.66697674255162 139.7383818797405 67.807 35.66698450266378 139.7383695434484 67.807 35.66698413903967 139.73836564471466 67.807 35.66697544267615 139.73837947329747 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5bc2573c-17ea-40c1-b3b8-30608aa20780">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bc2573c-17ea-40c1-b3b8-30608aa20780">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bc2573c-17ea-40c1-b3b8-30608aa20780">
											<gml:posList>35.66697544267615 139.73837947329747 67.807 35.66696666555292 139.7383823335044 67.807 35.666967100328264 139.73838501711634 67.807 35.66697674255162 139.7383818797405 67.807 35.66697544267615 139.73837947329747 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3bccf1f-6d18-4927-8d7f-cae2bcf4a256">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3bccf1f-6d18-4927-8d7f-cae2bcf4a256">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3bccf1f-6d18-4927-8d7f-cae2bcf4a256">
											<gml:posList>35.66698413903967 139.73836564471466 67.807 35.66698450266378 139.7383695434484 67.807 35.667014938948036 139.73839990543314 67.807 35.6670180483356 139.73839945992012 67.807 35.66698413903967 139.73836564471466 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ecdcd73-b905-487d-bad6-102273e967df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ecdcd73-b905-487d-bad6-102273e967df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ecdcd73-b905-487d-bad6-102273e967df">
											<gml:posList>35.66696666555292 139.7383823335044 67.807 35.66695689601382 139.7383840461239 67.807 35.66695785351564 139.73838664075026 67.807 35.666967100328264 139.73838501711634 67.807 35.66696666555292 139.7383823335044 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-10bec0ce-0887-4520-b9f6-64c10016cad0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10bec0ce-0887-4520-b9f6-64c10016cad0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10bec0ce-0887-4520-b9f6-64c10016cad0">
											<gml:posList>35.66693707301547 139.73840463684758 67.807 35.66693838176486 139.73840686654682 67.807 35.66695785351564 139.73838664075026 67.807 35.66695689601382 139.7383840461239 67.807 35.66693707301547 139.73840463684758 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ecbddcc0-c7f0-448c-829d-7913e698241d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecbddcc0-c7f0-448c-829d-7913e698241d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecbddcc0-c7f0-448c-829d-7913e698241d">
											<gml:posList>35.66701205269934 139.73840898849386 67.807 35.6670180483356 139.73839945992012 67.807 35.667014938948036 139.73839990543314 67.807 35.667009033335816 139.73840929030456 67.807 35.66701205269934 139.73840898849386 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e338792a-0bbd-4d66-adac-7f851f82e667">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e338792a-0bbd-4d66-adac-7f851f82e667">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e338792a-0bbd-4d66-adac-7f851f82e667">
											<gml:posList>35.66685883100662 139.73849262069746 25.772 35.666873422178405 139.7384785532128 25.772 35.66686434762336 139.73845856004877 25.772 35.66693707301547 139.73840463684758 25.772 35.66695689601382 139.7383840461239 25.772 35.66696666555292 139.7383823335044 25.772 35.666938896441906 139.73836227410288 25.772 35.66692570596536 139.73838084664112 25.772 35.66685093389313 139.73843404325737 25.772 35.66684247811 139.73845578029776 25.772 35.66684840809278 139.738477323584 25.772 35.66685883100662 139.73849262069746 25.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa00cc5d-7e15-4163-9ea0-d782dcdc4ae5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa00cc5d-7e15-4163-9ea0-d782dcdc4ae5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa00cc5d-7e15-4163-9ea0-d782dcdc4ae5">
											<gml:posList>35.66693707301547 139.73840463684758 67.807 35.66686434762336 139.73845856004877 67.807 35.66686734995174 139.73845951747901 67.807 35.66693838176486 139.73840686654682 67.807 35.66693707301547 139.73840463684758 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0200061a-3311-467b-b4c9-b6b3d341dcb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0200061a-3311-467b-b4c9-b6b3d341dcb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0200061a-3311-467b-b4c9-b6b3d341dcb5">
											<gml:posList>35.66701205269934 139.73840898849386 67.807 35.667009033335816 139.73840929030456 67.807 35.66706887527556 139.7384776040318 67.807 35.66707204802051 139.73847748982064 67.807 35.66701205269934 139.73840898849386 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0082a06-8b25-4031-ada3-9e7fadb59403">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0082a06-8b25-4031-ada3-9e7fadb59403">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0082a06-8b25-4031-ada3-9e7fadb59403">
											<gml:posList>35.666873422178405 139.7384785532128 67.807 35.666875277779425 139.73847699356332 67.807 35.66686734995174 139.73845951747901 67.807 35.66686434762336 139.73845856004877 67.807 35.666873422178405 139.7384785532128 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ddfb998a-c224-4705-9bcf-a8c61ba31336">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddfb998a-c224-4705-9bcf-a8c61ba31336">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddfb998a-c224-4705-9bcf-a8c61ba31336">
											<gml:posList>35.666875277779425 139.73847699356332 63.405 35.666902232804674 139.7385163509294 63.405 35.666968538044415 139.73860822872314 63.405 35.66706887527556 139.7384776040318 63.405 35.667009033335816 139.73840929030456 63.405 35.667014938948036 139.73839990543314 63.405 35.66698450266378 139.7383695434484 63.405 35.66697674255162 139.7383818797405 63.405 35.666967100328264 139.73838501711634 63.405 35.66695785351564 139.73838664075026 63.405 35.66693838176486 139.73840686654682 63.405 35.66686734995174 139.73845951747901 63.405 35.666875277779425 139.73847699356332 63.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e32cd93-dce9-416f-85b9-cd03d2500485">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e32cd93-dce9-416f-85b9-cd03d2500485">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e32cd93-dce9-416f-85b9-cd03d2500485">
											<gml:posList>35.66690055768643 139.7385181754638 67.807 35.666902232804674 139.7385163509294 67.807 35.666875277779425 139.73847699356332 67.807 35.666873422178405 139.7384785532128 67.807 35.66690055768643 139.7385181754638 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df4b090a-93bf-420d-bf6d-c749c2c23d39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df4b090a-93bf-420d-bf6d-c749c2c23d39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df4b090a-93bf-420d-bf6d-c749c2c23d39">
											<gml:posList>35.66707204802051 139.73847748982064 67.807 35.66706887527556 139.7384776040318 67.807 35.666968538044415 139.73860822872314 67.807 35.66696849618196 139.7386123046688 67.807 35.66707204802051 139.73847748982064 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-13624d89-33bf-42c0-82f0-cf524e392621">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13624d89-33bf-42c0-82f0-cf524e392621">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13624d89-33bf-42c0-82f0-cf524e392621">
											<gml:posList>35.66690055768643 139.7385181754638 67.807 35.66696849618196 139.7386123046688 67.807 35.666968538044415 139.73860822872314 67.807 35.666902232804674 139.7385163509294 67.807 35.66690055768643 139.7385181754638 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4cea908a-e9b9-45d9-b74a-d2dd6f1b6257">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cea908a-e9b9-45d9-b74a-d2dd6f1b6257">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cea908a-e9b9-45d9-b74a-d2dd6f1b6257">
											<gml:posList>35.66696849618196 139.7386123046688 25.772 35.66690055768643 139.7385181754638 25.772 35.66688791376218 139.7385326051546 25.772 35.6669665769088 139.73863605538227 25.772 35.66696849618196 139.7386123046688 25.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0339b0cf-8f82-43a5-9b41-3c0e069980e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0339b0cf-8f82-43a5-9b41-3c0e069980e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0339b0cf-8f82-43a5-9b41-3c0e069980e8">
											<gml:posList>35.66685093389313 139.73843404325737 11.91 35.66684247811 139.73845578029776 11.91 35.66684247811 139.73845578029776 25.772 35.66685093389313 139.73843404325737 25.772 35.66685093389313 139.73843404325737 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d70b9dcf-ff95-4f20-ba63-23deebfd3c6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d70b9dcf-ff95-4f20-ba63-23deebfd3c6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d70b9dcf-ff95-4f20-ba63-23deebfd3c6e">
											<gml:posList>35.66684247811 139.73845578029776 11.91 35.66684840809278 139.738477323584 11.91 35.66684840809278 139.738477323584 25.772 35.66684247811 139.73845578029776 25.772 35.66684247811 139.73845578029776 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b7d6430-b267-4ba1-9208-988e7a345c90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b7d6430-b267-4ba1-9208-988e7a345c90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b7d6430-b267-4ba1-9208-988e7a345c90">
											<gml:posList>35.666875277779425 139.73847699356332 67.807 35.666875277779425 139.73847699356332 63.405 35.66686734995174 139.73845951747901 63.405 35.66686734995174 139.73845951747901 67.807 35.666875277779425 139.73847699356332 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9796cdd-07c1-4eeb-893a-8bed137a7717">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9796cdd-07c1-4eeb-893a-8bed137a7717">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9796cdd-07c1-4eeb-893a-8bed137a7717">
											<gml:posList>35.666873422178405 139.7384785532128 25.772 35.666873422178405 139.7384785532128 67.807 35.66686434762336 139.73845856004877 67.807 35.66686434762336 139.73845856004877 25.772 35.666873422178405 139.7384785532128 25.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02556c3b-9d40-49cb-9126-59de1e63e8a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02556c3b-9d40-49cb-9126-59de1e63e8a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02556c3b-9d40-49cb-9126-59de1e63e8a5">
											<gml:posList>35.66684840809278 139.738477323584 11.91 35.66685883100662 139.73849262069746 11.91 35.66685883100662 139.73849262069746 25.772 35.66684840809278 139.738477323584 25.772 35.66684840809278 139.738477323584 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d259837d-cff5-4d90-bc6a-05af7e0576b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d259837d-cff5-4d90-bc6a-05af7e0576b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d259837d-cff5-4d90-bc6a-05af7e0576b9">
											<gml:posList>35.66685883100662 139.73849262069746 11.91 35.666873422178405 139.7384785532128 11.91 35.666873422178405 139.7384785532128 25.772 35.66685883100662 139.73849262069746 25.772 35.66685883100662 139.73849262069746 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4f3141f-31de-442e-9a6d-28d536304976">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4f3141f-31de-442e-9a6d-28d536304976">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4f3141f-31de-442e-9a6d-28d536304976">
											<gml:posList>35.666938896441906 139.73836227410288 11.91 35.66692570596536 139.73838084664112 11.91 35.66692570596536 139.73838084664112 25.772 35.666938896441906 139.73836227410288 25.772 35.666938896441906 139.73836227410288 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d43c7624-273a-4248-b1e6-ac6447f47245">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d43c7624-273a-4248-b1e6-ac6447f47245">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d43c7624-273a-4248-b1e6-ac6447f47245">
											<gml:posList>35.66696666555292 139.7383823335044 11.91 35.666938896441906 139.73836227410288 11.91 35.666938896441906 139.73836227410288 25.772 35.66696666555292 139.7383823335044 25.772 35.66696666555292 139.7383823335044 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b3f147e-c304-4d91-9ca6-8efcad16c753">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b3f147e-c304-4d91-9ca6-8efcad16c753">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b3f147e-c304-4d91-9ca6-8efcad16c753">
											<gml:posList>35.66698413903967 139.73836564471466 11.91 35.66697544267615 139.73837947329747 11.91 35.66697544267615 139.73837947329747 67.807 35.66698413903967 139.73836564471466 67.807 35.66698413903967 139.73836564471466 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0cb52908-2e21-42fc-bfbf-ddb8192c4796">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cb52908-2e21-42fc-bfbf-ddb8192c4796">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cb52908-2e21-42fc-bfbf-ddb8192c4796">
											<gml:posList>35.66697674255162 139.7383818797405 67.807 35.66697674255162 139.7383818797405 63.405 35.66698450266378 139.7383695434484 63.405 35.66698450266378 139.7383695434484 67.807 35.66697674255162 139.7383818797405 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a012bf48-6244-4792-a506-fa398bc92724">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a012bf48-6244-4792-a506-fa398bc92724">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a012bf48-6244-4792-a506-fa398bc92724">
											<gml:posList>35.66697544267615 139.73837947329747 11.91 35.66696666555292 139.7383823335044 11.91 35.66696666555292 139.7383823335044 25.772 35.66696666555292 139.7383823335044 67.807 35.66697544267615 139.73837947329747 67.807 35.66697544267615 139.73837947329747 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e730cad9-7c54-471a-8dbc-8bc993a8dec2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e730cad9-7c54-471a-8dbc-8bc993a8dec2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e730cad9-7c54-471a-8dbc-8bc993a8dec2">
											<gml:posList>35.6670180483356 139.73839945992012 11.91 35.66698413903967 139.73836564471466 11.91 35.66698413903967 139.73836564471466 67.807 35.6670180483356 139.73839945992012 67.807 35.6670180483356 139.73839945992012 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6521d844-52fe-41a2-b23c-ef35dd5dbd52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6521d844-52fe-41a2-b23c-ef35dd5dbd52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6521d844-52fe-41a2-b23c-ef35dd5dbd52">
											<gml:posList>35.66695689601382 139.7383840461239 25.772 35.66695689601382 139.7383840461239 67.807 35.66696666555292 139.7383823335044 67.807 35.66696666555292 139.7383823335044 25.772 35.66695689601382 139.7383840461239 25.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c37d0f0e-7ff2-4a69-add6-7ac40fbbf5df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c37d0f0e-7ff2-4a69-add6-7ac40fbbf5df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c37d0f0e-7ff2-4a69-add6-7ac40fbbf5df">
											<gml:posList>35.666967100328264 139.73838501711634 67.807 35.666967100328264 139.73838501711634 63.405 35.66697674255162 139.7383818797405 63.405 35.66697674255162 139.7383818797405 67.807 35.666967100328264 139.73838501711634 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a918bd3-9135-4e80-9845-c3be27f74fdc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a918bd3-9135-4e80-9845-c3be27f74fdc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a918bd3-9135-4e80-9845-c3be27f74fdc">
											<gml:posList>35.66698450266378 139.7383695434484 67.807 35.66698450266378 139.7383695434484 63.405 35.667014938948036 139.73839990543314 63.405 35.667014938948036 139.73839990543314 67.807 35.66698450266378 139.7383695434484 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5b80ba2-b699-4510-8ed4-3ae3bacab85b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5b80ba2-b699-4510-8ed4-3ae3bacab85b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5b80ba2-b699-4510-8ed4-3ae3bacab85b">
											<gml:posList>35.66695785351564 139.73838664075026 67.807 35.66695785351564 139.73838664075026 63.405 35.666967100328264 139.73838501711634 63.405 35.666967100328264 139.73838501711634 67.807 35.66695785351564 139.73838664075026 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7be80a8-b620-4c4a-b51b-dd1c487b4a10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7be80a8-b620-4c4a-b51b-dd1c487b4a10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7be80a8-b620-4c4a-b51b-dd1c487b4a10">
											<gml:posList>35.66693707301547 139.73840463684758 25.772 35.66693707301547 139.73840463684758 67.807 35.66695689601382 139.7383840461239 67.807 35.66695689601382 139.7383840461239 25.772 35.66693707301547 139.73840463684758 25.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90910842-6138-4fc3-85af-996df4163cdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90910842-6138-4fc3-85af-996df4163cdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90910842-6138-4fc3-85af-996df4163cdb">
											<gml:posList>35.66693838176486 139.73840686654682 67.807 35.66693838176486 139.73840686654682 63.405 35.66695785351564 139.73838664075026 63.405 35.66695785351564 139.73838664075026 67.807 35.66693838176486 139.73840686654682 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce7874f4-8af3-49cd-a1e3-3a462c8aa862">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce7874f4-8af3-49cd-a1e3-3a462c8aa862">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce7874f4-8af3-49cd-a1e3-3a462c8aa862">
											<gml:posList>35.66701205269934 139.73840898849386 11.91 35.6670180483356 139.73839945992012 11.91 35.6670180483356 139.73839945992012 67.807 35.66701205269934 139.73840898849386 67.807 35.66701205269934 139.73840898849386 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-134f3f9f-1c77-4b61-aff4-4b4ff827c9e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-134f3f9f-1c77-4b61-aff4-4b4ff827c9e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-134f3f9f-1c77-4b61-aff4-4b4ff827c9e0">
											<gml:posList>35.667014938948036 139.73839990543314 67.807 35.667014938948036 139.73839990543314 63.405 35.667009033335816 139.73840929030456 63.405 35.667009033335816 139.73840929030456 67.807 35.667014938948036 139.73839990543314 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b8e3fff-f945-4ba3-b188-08f340da268e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b8e3fff-f945-4ba3-b188-08f340da268e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b8e3fff-f945-4ba3-b188-08f340da268e">
											<gml:posList>35.66692570596536 139.73838084664112 11.91 35.66685093389313 139.73843404325737 11.91 35.66685093389313 139.73843404325737 25.772 35.66692570596536 139.73838084664112 25.772 35.66692570596536 139.73838084664112 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-beb1bfc6-e289-4242-90cd-e7fbfac43810">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-beb1bfc6-e289-4242-90cd-e7fbfac43810">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-beb1bfc6-e289-4242-90cd-e7fbfac43810">
											<gml:posList>35.66686434762336 139.73845856004877 25.772 35.66686434762336 139.73845856004877 67.807 35.66693707301547 139.73840463684758 67.807 35.66693707301547 139.73840463684758 25.772 35.66686434762336 139.73845856004877 25.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-877ffba9-523c-4b7b-8606-4dc5fe24f0ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-877ffba9-523c-4b7b-8606-4dc5fe24f0ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-877ffba9-523c-4b7b-8606-4dc5fe24f0ce">
											<gml:posList>35.66686734995174 139.73845951747901 67.807 35.66686734995174 139.73845951747901 63.405 35.66693838176486 139.73840686654682 63.405 35.66693838176486 139.73840686654682 67.807 35.66686734995174 139.73845951747901 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39be350e-5351-43df-96f3-fc9592eb7be6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39be350e-5351-43df-96f3-fc9592eb7be6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39be350e-5351-43df-96f3-fc9592eb7be6">
											<gml:posList>35.66707204802051 139.73847748982064 11.91 35.66701205269934 139.73840898849386 11.91 35.66701205269934 139.73840898849386 67.807 35.66707204802051 139.73847748982064 67.807 35.66707204802051 139.73847748982064 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-492995cf-e12b-47ab-b6ad-13b3d81f5a9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-492995cf-e12b-47ab-b6ad-13b3d81f5a9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-492995cf-e12b-47ab-b6ad-13b3d81f5a9c">
											<gml:posList>35.667009033335816 139.73840929030456 67.807 35.667009033335816 139.73840929030456 63.405 35.66706887527556 139.7384776040318 63.405 35.66706887527556 139.7384776040318 67.807 35.667009033335816 139.73840929030456 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6cc849c9-fdcb-4e79-8f7a-c43ca8b038a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cc849c9-fdcb-4e79-8f7a-c43ca8b038a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cc849c9-fdcb-4e79-8f7a-c43ca8b038a3">
											<gml:posList>35.666902232804674 139.7385163509294 67.807 35.666902232804674 139.7385163509294 63.405 35.666875277779425 139.73847699356332 63.405 35.666875277779425 139.73847699356332 67.807 35.666902232804674 139.7385163509294 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14f49e1b-18c1-4ff2-bf1a-3f59281e4f89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14f49e1b-18c1-4ff2-bf1a-3f59281e4f89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14f49e1b-18c1-4ff2-bf1a-3f59281e4f89">
											<gml:posList>35.666873422178405 139.7384785532128 25.772 35.666873422178405 139.7384785532128 11.91 35.66690055768643 139.7385181754638 11.91 35.66690055768643 139.7385181754638 25.772 35.66690055768643 139.7385181754638 67.807 35.666873422178405 139.7384785532128 67.807 35.666873422178405 139.7384785532128 25.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0cd35f6-de0a-46c0-b2e7-892f324dbc93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0cd35f6-de0a-46c0-b2e7-892f324dbc93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0cd35f6-de0a-46c0-b2e7-892f324dbc93">
											<gml:posList>35.66690055768643 139.7385181754638 11.91 35.66688791376218 139.7385326051546 11.91 35.66688791376218 139.7385326051546 25.772 35.66690055768643 139.7385181754638 25.772 35.66690055768643 139.7385181754638 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-618fccd9-1e62-437a-8c6c-5aef00cc0c75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-618fccd9-1e62-437a-8c6c-5aef00cc0c75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-618fccd9-1e62-437a-8c6c-5aef00cc0c75">
											<gml:posList>35.66706887527556 139.7384776040318 67.807 35.66706887527556 139.7384776040318 63.405 35.666968538044415 139.73860822872314 63.405 35.666968538044415 139.73860822872314 67.807 35.66706887527556 139.7384776040318 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e679c857-77d1-4f65-8560-ad091f6f114e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e679c857-77d1-4f65-8560-ad091f6f114e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e679c857-77d1-4f65-8560-ad091f6f114e">
											<gml:posList>35.66707204802051 139.73847748982064 11.91 35.66707204802051 139.73847748982064 67.807 35.66696849618196 139.7386123046688 67.807 35.66696849618196 139.7386123046688 25.772 35.66696849618196 139.7386123046688 11.91 35.66707204802051 139.73847748982064 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-749d42db-25eb-4a01-841a-6d892ec43cf5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-749d42db-25eb-4a01-841a-6d892ec43cf5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-749d42db-25eb-4a01-841a-6d892ec43cf5">
											<gml:posList>35.666968538044415 139.73860822872314 67.807 35.666968538044415 139.73860822872314 63.405 35.666902232804674 139.7385163509294 63.405 35.666902232804674 139.7385163509294 67.807 35.666968538044415 139.73860822872314 67.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62560e98-a309-4c23-baa7-d03c05a8b74d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62560e98-a309-4c23-baa7-d03c05a8b74d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62560e98-a309-4c23-baa7-d03c05a8b74d">
											<gml:posList>35.66696849618196 139.7386123046688 25.772 35.66696849618196 139.7386123046688 67.807 35.66690055768643 139.7385181754638 67.807 35.66690055768643 139.7385181754638 25.772 35.66696849618196 139.7386123046688 25.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18f0341f-1da2-4a12-83a8-2df82f0c323f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18f0341f-1da2-4a12-83a8-2df82f0c323f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18f0341f-1da2-4a12-83a8-2df82f0c323f">
											<gml:posList>35.66688791376218 139.7385326051546 11.91 35.6669665769088 139.73863605538227 11.91 35.6669665769088 139.73863605538227 25.772 35.66688791376218 139.7385326051546 25.772 35.66688791376218 139.7385326051546 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d13825cd-534b-4738-a42b-70a18dcae17c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d13825cd-534b-4738-a42b-70a18dcae17c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d13825cd-534b-4738-a42b-70a18dcae17c">
											<gml:posList>35.6669665769088 139.73863605538227 11.91 35.66696849618196 139.7386123046688 11.91 35.66696849618196 139.7386123046688 25.772 35.6669665769088 139.73863605538227 25.772 35.6669665769088 139.73863605538227 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1823</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">222</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>