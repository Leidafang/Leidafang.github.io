<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cca2c071-81da-41fe-afc8-42ca36f12668">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67047514315151 139.74088329656968 0 35.67046467773381 139.74087093681334 0 35.67041338218687 139.74086127525618 0 35.670430819730754 139.74103225134965 0 35.67049769393221 139.7410222327151 0 35.67047514315151 139.74088329656968 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047514315151 139.74088329656968 8.9 35.67049769393221 139.7410222327151 8.9 35.670430819730754 139.74103225134965 8.9 35.67041338218687 139.74086127525618 8.9 35.67046467773381 139.74087093681334 8.9 35.67047514315151 139.74088329656968 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047514315151 139.74088329656968 8.9 35.67046467773381 139.74087093681334 8.9 35.67046467773381 139.74087093681334 23.83 35.67047514315151 139.74088329656968 23.83 35.67047514315151 139.74088329656968 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67046467773381 139.74087093681334 8.9 35.67041338218687 139.74086127525618 8.9 35.67041338218687 139.74086127525618 23.83 35.67046467773381 139.74087093681334 23.83 35.67046467773381 139.74087093681334 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041338218687 139.74086127525618 8.9 35.670430819730754 139.74103225134965 8.9 35.670430819730754 139.74103225134965 23.83 35.67041338218687 139.74086127525618 23.83 35.67041338218687 139.74086127525618 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670430819730754 139.74103225134965 8.9 35.67049769393221 139.7410222327151 8.9 35.67049769393221 139.7410222327151 23.83 35.670430819730754 139.74103225134965 23.83 35.670430819730754 139.74103225134965 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049769393221 139.7410222327151 8.9 35.67047514315151 139.74088329656968 8.9 35.67047514315151 139.74088329656968 23.83 35.67049769393221 139.7410222327151 23.83 35.67049769393221 139.7410222327151 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047514315151 139.74088329656968 23.83 35.67046467773381 139.74087093681334 23.83 35.67041338218687 139.74086127525618 23.83 35.670430819730754 139.74103225134965 23.83 35.67049769393221 139.7410222327151 23.83 35.67047514315151 139.74088329656968 23.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-510e457e-d874-43af-a591-af787fbae15c"/>
							<gml:surfaceMember xlink:href="#poly-3ba2a89a-82cb-4d7f-b777-77cb4a01698c"/>
							<gml:surfaceMember xlink:href="#poly-f030c220-556e-4e00-bd65-9de9c6a63b0e"/>
							<gml:surfaceMember xlink:href="#poly-67a3b4aa-4cc7-425b-8bca-049119bd080c"/>
							<gml:surfaceMember xlink:href="#poly-7b00a4c6-7349-4e67-81df-79ee965d8faa"/>
							<gml:surfaceMember xlink:href="#poly-1b5029fe-249a-43fc-95be-693db28a910e"/>
							<gml:surfaceMember xlink:href="#poly-c073d03d-68a2-4570-b238-27d390a0250b"/>
							<gml:surfaceMember xlink:href="#poly-156f2051-0be9-4eb9-b990-fa7127b260b7"/>
							<gml:surfaceMember xlink:href="#poly-35625b2d-bcc2-499a-a297-c0e1da084c11"/>
							<gml:surfaceMember xlink:href="#poly-52186006-2261-48fc-987d-8ae05028dcc0"/>
							<gml:surfaceMember xlink:href="#poly-eef63660-a587-4309-b231-6081d252a911"/>
							<gml:surfaceMember xlink:href="#poly-3cd942b8-f324-414a-8b08-0068210e25d3"/>
							<gml:surfaceMember xlink:href="#poly-1b45b97f-170b-48ac-8679-2bfc51485525"/>
							<gml:surfaceMember xlink:href="#poly-156f07cb-ec06-493d-a4c3-6ba79fb10586"/>
							<gml:surfaceMember xlink:href="#poly-93c69831-9cf5-44ba-b0bb-5e5870b4ec99"/>
							<gml:surfaceMember xlink:href="#poly-6ec11f2e-493d-4f25-b46f-449e584ae880"/>
							<gml:surfaceMember xlink:href="#poly-43a5b152-8a59-4859-b1eb-2008a136b4dd"/>
							<gml:surfaceMember xlink:href="#poly-c9f3c568-8dff-4c1a-a1ad-1f85958c3de1"/>
							<gml:surfaceMember xlink:href="#poly-80cc2edb-197b-4e82-90b2-5d052f6b37ba"/>
							<gml:surfaceMember xlink:href="#poly-abac6a6b-c60c-4f93-8309-b7f9368f4689"/>
							<gml:surfaceMember xlink:href="#poly-7db5ae0e-9f7e-49a8-9142-80e62a2fcff7"/>
							<gml:surfaceMember xlink:href="#poly-e65f0370-f748-4124-8f9d-5fd3d321e69c"/>
							<gml:surfaceMember xlink:href="#poly-c36231f2-3fa8-45cd-9d70-4b8ef5d97f9f"/>
							<gml:surfaceMember xlink:href="#poly-48154a12-412d-49fe-8564-60c8bf8dc223"/>
							<gml:surfaceMember xlink:href="#poly-64e185b1-b207-466b-bce6-ef319f1e1774"/>
							<gml:surfaceMember xlink:href="#poly-8842b316-8af6-4c21-bd4a-973040a30ca2"/>
							<gml:surfaceMember xlink:href="#poly-de2330e9-40ad-4bc7-a0de-66faa662c041"/>
							<gml:surfaceMember xlink:href="#poly-3ace032e-d6c5-4e8b-a1d1-584329499ac7"/>
							<gml:surfaceMember xlink:href="#poly-7fbf3b86-2d3e-41d7-a9b7-5ffad61bed33"/>
							<gml:surfaceMember xlink:href="#poly-fc6b8cd0-5e25-4d3d-a4fc-c24a993f9df5"/>
							<gml:surfaceMember xlink:href="#poly-f60315b2-0ffa-42bf-8328-c25bc21e085d"/>
							<gml:surfaceMember xlink:href="#poly-8d0ffbc0-9f3f-4e87-b4b4-fee547e759be"/>
							<gml:surfaceMember xlink:href="#poly-d3078c18-064c-4338-a099-0b0331f68e8d"/>
							<gml:surfaceMember xlink:href="#poly-6b1faed5-f6cb-4faf-b140-eb9d0b80d929"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_cca2c071-81da-41fe-afc8-42ca36f12668_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03e817fe-d40e-4775-8e5d-0678a4835cc0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670428985147105 139.74101423700142 25.389 35.670431589808096 139.74101383633672 25.389 35.670432734192005 139.74102512430366 25.389 35.67043012953098 139.74102552496797 25.389 35.670428985147105 139.74101423700142 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b6bcc66-8d15-4a32-acb8-535abf318353">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670431589808096 139.74101383633672 25.001 35.67046027714222 139.74100944002808 25.001 35.670461430540264 139.74102072798857 25.001 35.670432734192005 139.74102512430366 25.001 35.670431589808096 139.74101383633672 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d199fe0-efed-4bca-b0d8-1da637f8533a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670469739498905 139.74101850916767 25.001 35.6704643282874 139.74099112064573 25.001 35.67047525044569 139.7409878825548 25.001 35.67048155381321 139.7410150049424 25.001 35.670469739498905 139.74101850916767 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b3fe7fe-829c-4b4e-adcf-26e4056493d7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047710684899 139.74098732810302 25.389 35.67048251806135 139.74101471662905 25.389 35.67048155381321 139.7410150049424 25.389 35.67047525044569 139.7409878825548 25.389 35.67047710684899 139.74098732810302 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d728ddd-3a2f-42b3-af53-c71a2b44685a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d728ddd-3a2f-42b3-af53-c71a2b44685a_0">
											<gml:posList>35.67047525044569 139.7409878825548 25.389 35.67047525044569 139.7409878825548 25.001 35.6704643282874 139.74099112064573 25.001 35.6704643282874 139.74099112064573 26.3 35.67047710684899 139.74098732810302 26.3 35.67047710684899 139.74098732810302 25.389 35.67047525044569 139.7409878825548 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55309673-50e6-4170-b1d5-50dd9b6cd40f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55309673-50e6-4170-b1d5-50dd9b6cd40f_0">
											<gml:posList>35.67048251806135 139.74101471662905 25.389 35.67047710684899 139.74098732810302 25.389 35.67047710684899 139.74098732810302 26.3 35.67048251806135 139.74101471662905 26.3 35.67048251806135 139.74101471662905 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f838f4da-e5e2-4936-a0eb-3948eeef1691">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f838f4da-e5e2-4936-a0eb-3948eeef1691_0">
											<gml:posList>35.67047525044569 139.7409878825548 25.389 35.67048155381321 139.7410150049424 25.389 35.67048155381321 139.7410150049424 25.001 35.67047525044569 139.7409878825548 25.001 35.67047525044569 139.7409878825548 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e61fc38-a4d4-4814-a23b-c093590a1225">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e61fc38-a4d4-4814-a23b-c093590a1225_0">
											<gml:posList>35.6704643282874 139.74099112064573 26.3 35.670469739498905 139.74101850916767 26.3 35.67048251806135 139.74101471662905 26.3 35.67047710684899 139.74098732810302 26.3 35.6704643282874 139.74099112064573 26.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2becc4fc-22d4-4fa3-9b0c-51e390d4f6cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2becc4fc-22d4-4fa3-9b0c-51e390d4f6cf_0">
											<gml:posList>35.6704643282874 139.74099112064573 25.001 35.670469739498905 139.74101850916767 25.001 35.670469739498905 139.74101850916767 26.3 35.6704643282874 139.74099112064573 26.3 35.6704643282874 139.74099112064573 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-017b5109-d92d-4bd3-a2ee-5045754e855c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-017b5109-d92d-4bd3-a2ee-5045754e855c_0">
											<gml:posList>35.670428985147105 139.74101423700142 27.398 35.67046027714222 139.74100944002808 27.398 35.67046027714222 139.74100944002808 25.001 35.670431589808096 139.74101383633672 25.001 35.670431589808096 139.74101383633672 25.389 35.670428985147105 139.74101423700142 25.389 35.670428985147105 139.74101423700142 27.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd495ac9-31cf-49dc-879c-59e36d87bc41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd495ac9-31cf-49dc-879c-59e36d87bc41_0">
											<gml:posList>35.670461430540264 139.74102072798857 25.001 35.67046027714222 139.74100944002808 25.001 35.67046027714222 139.74100944002808 27.398 35.670461430540264 139.74102072798857 27.398 35.670461430540264 139.74102072798857 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05467e8c-987d-4338-a0ab-b7361f8bc42e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05467e8c-987d-4338-a0ab-b7361f8bc42e_0">
											<gml:posList>35.67048155381321 139.7410150049424 25.389 35.67048251806135 139.74101471662905 25.389 35.67048251806135 139.74101471662905 26.3 35.670469739498905 139.74101850916767 26.3 35.670469739498905 139.74101850916767 25.001 35.67048155381321 139.7410150049424 25.001 35.67048155381321 139.7410150049424 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b72d9158-b5df-4c06-ae71-ffaee15393eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b72d9158-b5df-4c06-ae71-ffaee15393eb_0">
											<gml:posList>35.67046027714222 139.74100944002808 27.398 35.670428985147105 139.74101423700142 27.398 35.67043012953098 139.74102552496797 27.398 35.670461430540264 139.74102072798857 27.398 35.67046027714222 139.74100944002808 27.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c02d9464-42db-4a2a-b5b8-eae615522253">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c02d9464-42db-4a2a-b5b8-eae615522253_0">
											<gml:posList>35.670432734192005 139.74102512430366 25.389 35.670431589808096 139.74101383633672 25.389 35.670431589808096 139.74101383633672 25.001 35.670432734192005 139.74102512430366 25.001 35.670432734192005 139.74102512430366 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb8287bd-8b8b-48c9-b64a-8e7b58ccb147">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb8287bd-8b8b-48c9-b64a-8e7b58ccb147_0">
											<gml:posList>35.670428985147105 139.74101423700142 25.389 35.67043012953098 139.74102552496797 25.389 35.67043012953098 139.74102552496797 27.398 35.670428985147105 139.74101423700142 27.398 35.670428985147105 139.74101423700142 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49f42717-9e83-43b9-9b43-8348c8f9c3ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49f42717-9e83-43b9-9b43-8348c8f9c3ea_0">
											<gml:posList>35.670432734192005 139.74102512430366 25.389 35.670432734192005 139.74102512430366 25.001 35.670461430540264 139.74102072798857 25.001 35.670461430540264 139.74102072798857 27.398 35.67043012953098 139.74102552496797 27.398 35.67043012953098 139.74102552496797 25.389 35.670432734192005 139.74102512430366 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-510e457e-d874-43af-a591-af787fbae15c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-510e457e-d874-43af-a591-af787fbae15c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-510e457e-d874-43af-a591-af787fbae15c">
											<gml:posList>35.670475143151485 139.74088329656965 8.9 35.67049769393221 139.7410222327151 8.9 35.670430819730726 139.74103225134965 8.9 35.67041338218687 139.74086127525618 8.9 35.6704646777338 139.74087093681334 8.9 35.670475143151485 139.74088329656965 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ba2a89a-82cb-4d7f-b777-77cb4a01698c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ba2a89a-82cb-4d7f-b777-77cb4a01698c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ba2a89a-82cb-4d7f-b777-77cb4a01698c">
											<gml:posList>35.6704646777338 139.74087093681334 19.906 35.67041338218687 139.74086127525618 19.906 35.67041607051191 139.74088766168134 25.389 35.6704646777338 139.74087093681334 19.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f030c220-556e-4e00-bd65-9de9c6a63b0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f030c220-556e-4e00-bd65-9de9c6a63b0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f030c220-556e-4e00-bd65-9de9c6a63b0e">
											<gml:posList>35.6704646777338 139.74087093681334 19.906 35.67045605993138 139.74089353637362 25.389 35.670475143151485 139.74088329656965 19.906 35.6704646777338 139.74087093681334 19.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67a3b4aa-4cc7-425b-8bca-049119bd080c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67a3b4aa-4cc7-425b-8bca-049119bd080c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67a3b4aa-4cc7-425b-8bca-049119bd080c">
											<gml:posList>35.67041607051191 139.74088766168134 25.389 35.67045605993138 139.74089353637362 25.389 35.6704646777338 139.74087093681334 19.906 35.67041607051191 139.74088766168134 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b00a4c6-7349-4e67-81df-79ee965d8faa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b00a4c6-7349-4e67-81df-79ee965d8faa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b00a4c6-7349-4e67-81df-79ee965d8faa">
											<gml:posList>35.67045605993138 139.74089353637362 25.389 35.67041607051191 139.74088766168134 25.389 35.6704190929415 139.7408913476489 25.389 35.67045402508571 139.7408964770274 25.389 35.67045605993138 139.74089353637362 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b5029fe-249a-43fc-95be-693db28a910e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b5029fe-249a-43fc-95be-693db28a910e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b5029fe-249a-43fc-95be-693db28a910e">
											<gml:posList>35.670423626786004 139.7409617402714 25.389 35.67042622243309 139.7409613396154 25.389 35.6704190929415 139.7408913476489 25.389 35.67041607051191 139.74088766168134 25.389 35.670423626786004 139.7409617402714 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c073d03d-68a2-4570-b238-27d390a0250b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c073d03d-68a2-4570-b238-27d390a0250b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c073d03d-68a2-4570-b238-27d390a0250b">
											<gml:posList>35.67049769393221 139.7410222327151 19.906 35.670475143151485 139.74088329656965 19.906 35.67045605993138 139.74089353637362 25.389 35.67049769393221 139.7410222327151 19.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-156f2051-0be9-4eb9-b990-fa7127b260b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-156f2051-0be9-4eb9-b990-fa7127b260b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-156f2051-0be9-4eb9-b990-fa7127b260b7">
											<gml:posList>35.67045605993138 139.74089353637362 25.389 35.67048634695101 139.7410239358592 25.389 35.67049769393221 139.7410222327151 19.906 35.67045605993138 139.74089353637362 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35625b2d-bcc2-499a-a297-c0e1da084c11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35625b2d-bcc2-499a-a297-c0e1da084c11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35625b2d-bcc2-499a-a297-c0e1da084c11">
											<gml:posList>35.67045605993138 139.74089353637362 25.389 35.67045402508571 139.7408964770274 25.389 35.67048299175452 139.74102121129252 25.389 35.67048634695101 139.7410239358592 25.389 35.67045605993138 139.74089353637362 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52186006-2261-48fc-987d-8ae05028dcc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52186006-2261-48fc-987d-8ae05028dcc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52186006-2261-48fc-987d-8ae05028dcc0">
											<gml:posList>35.67045198521354 139.74099860213968 25.001 35.67043037283056 139.74100191881655 25.001 35.67043309746757 139.7410286807833 25.001 35.67048299175452 139.74102121129252 25.001 35.67045402508571 139.7408964770274 25.001 35.6704190929415 139.7408913476489 25.001 35.67042622243309 139.7409613396154 25.001 35.67044785285089 139.74095803395323 25.001 35.67045198521354 139.74099860213968 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eef63660-a587-4309-b231-6081d252a911">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eef63660-a587-4309-b231-6081d252a911">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eef63660-a587-4309-b231-6081d252a911">
											<gml:posList>35.670423626786004 139.7409617402714 27.99 35.67042527750054 139.74096330693936 27.99 35.670446574444554 139.74096004584706 27.99 35.67044785285089 139.74095803395323 27.99 35.670423626786004 139.7409617402714 27.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3cd942b8-f324-414a-8b08-0068210e25d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cd942b8-f324-414a-8b08-0068210e25d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cd942b8-f324-414a-8b08-0068210e25d3">
											<gml:posList>35.67044785285089 139.74095803395323 27.99 35.670446574444554 139.74096004584706 27.99 35.67045034350471 139.74099702441382 27.99 35.67045198521354 139.74099860213968 27.99 35.67044785285089 139.74095803395323 27.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b45b97f-170b-48ac-8679-2bfc51485525">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b45b97f-170b-48ac-8679-2bfc51485525">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b45b97f-170b-48ac-8679-2bfc51485525">
											<gml:posList>35.67045034350471 139.74099702441382 27.574 35.670446574444554 139.74096004584706 27.574 35.67042527750054 139.74096330693936 27.574 35.670429055581906 139.74100029653235 27.574 35.67045034350471 139.74099702441382 27.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-156f07cb-ec06-493d-a4c3-6ba79fb10586">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-156f07cb-ec06-493d-a4c3-6ba79fb10586">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-156f07cb-ec06-493d-a4c3-6ba79fb10586">
											<gml:posList>35.6704277681696 139.7410023194816 27.99 35.670429055581906 139.74100029653235 27.99 35.67042527750054 139.74096330693936 27.99 35.670423626786004 139.7409617402714 27.99 35.6704277681696 139.7410023194816 27.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93c69831-9cf5-44ba-b0bb-5e5870b4ec99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93c69831-9cf5-44ba-b0bb-5e5870b4ec99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93c69831-9cf5-44ba-b0bb-5e5870b4ec99">
											<gml:posList>35.67045198521354 139.74099860213968 27.99 35.67045034350471 139.74099702441382 27.99 35.670429055581906 139.74100029653235 27.99 35.6704277681696 139.7410023194816 27.99 35.67045198521354 139.74099860213968 27.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ec11f2e-493d-4f25-b46f-449e584ae880">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ec11f2e-493d-4f25-b46f-449e584ae880">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ec11f2e-493d-4f25-b46f-449e584ae880">
											<gml:posList>35.6704277681696 139.7410023194816 25.389 35.670430819730726 139.74103225134965 25.389 35.67043309746757 139.7410286807833 25.389 35.67043037283056 139.74100191881655 25.389 35.6704277681696 139.7410023194816 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43a5b152-8a59-4859-b1eb-2008a136b4dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43a5b152-8a59-4859-b1eb-2008a136b4dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43a5b152-8a59-4859-b1eb-2008a136b4dd">
											<gml:posList>35.670430819730726 139.74103225134965 25.389 35.67048634695101 139.7410239358592 25.389 35.67048299175452 139.74102121129252 25.389 35.67043309746757 139.7410286807833 25.389 35.670430819730726 139.74103225134965 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9f3c568-8dff-4c1a-a1ad-1f85958c3de1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9f3c568-8dff-4c1a-a1ad-1f85958c3de1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9f3c568-8dff-4c1a-a1ad-1f85958c3de1">
											<gml:posList>35.67041338218687 139.74086127525618 19.906 35.67041338218687 139.74086127525618 8.9 35.670430819730726 139.74103225134965 8.9 35.670430819730726 139.74103225134965 25.389 35.6704277681696 139.7410023194816 25.389 35.6704277681696 139.7410023194816 27.99 35.670423626786004 139.7409617402714 27.99 35.670423626786004 139.7409617402714 25.389 35.67041607051191 139.74088766168134 25.389 35.67041338218687 139.74086127525618 19.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80cc2edb-197b-4e82-90b2-5d052f6b37ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80cc2edb-197b-4e82-90b2-5d052f6b37ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80cc2edb-197b-4e82-90b2-5d052f6b37ba">
											<gml:posList>35.67042622243309 139.7409613396154 25.389 35.67042622243309 139.7409613396154 25.001 35.6704190929415 139.7408913476489 25.001 35.6704190929415 139.7408913476489 25.389 35.67042622243309 139.7409613396154 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abac6a6b-c60c-4f93-8309-b7f9368f4689">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abac6a6b-c60c-4f93-8309-b7f9368f4689">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abac6a6b-c60c-4f93-8309-b7f9368f4689">
											<gml:posList>35.670429055581906 139.74100029653235 27.99 35.670429055581906 139.74100029653235 27.574 35.67042527750054 139.74096330693936 27.574 35.67042527750054 139.74096330693936 27.99 35.670429055581906 139.74100029653235 27.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7db5ae0e-9f7e-49a8-9142-80e62a2fcff7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7db5ae0e-9f7e-49a8-9142-80e62a2fcff7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7db5ae0e-9f7e-49a8-9142-80e62a2fcff7">
											<gml:posList>35.67043309746757 139.7410286807833 25.389 35.67043309746757 139.7410286807833 25.001 35.67043037283056 139.74100191881655 25.001 35.67043037283056 139.74100191881655 25.389 35.67043309746757 139.7410286807833 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e65f0370-f748-4124-8f9d-5fd3d321e69c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e65f0370-f748-4124-8f9d-5fd3d321e69c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e65f0370-f748-4124-8f9d-5fd3d321e69c">
											<gml:posList>35.67042622243309 139.7409613396154 25.389 35.670423626786004 139.7409617402714 25.389 35.670423626786004 139.7409617402714 27.99 35.67044785285089 139.74095803395323 27.99 35.67044785285089 139.74095803395323 25.001 35.67042622243309 139.7409613396154 25.001 35.67042622243309 139.7409613396154 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c36231f2-3fa8-45cd-9d70-4b8ef5d97f9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c36231f2-3fa8-45cd-9d70-4b8ef5d97f9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c36231f2-3fa8-45cd-9d70-4b8ef5d97f9f">
											<gml:posList>35.67042527750054 139.74096330693936 27.99 35.67042527750054 139.74096330693936 27.574 35.670446574444554 139.74096004584706 27.574 35.670446574444554 139.74096004584706 27.99 35.67042527750054 139.74096330693936 27.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48154a12-412d-49fe-8564-60c8bf8dc223">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48154a12-412d-49fe-8564-60c8bf8dc223">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48154a12-412d-49fe-8564-60c8bf8dc223">
											<gml:posList>35.6704190929415 139.7408913476489 25.389 35.6704190929415 139.7408913476489 25.001 35.67045402508571 139.7408964770274 25.001 35.67045402508571 139.7408964770274 25.389 35.6704190929415 139.7408913476489 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64e185b1-b207-466b-bce6-ef319f1e1774">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64e185b1-b207-466b-bce6-ef319f1e1774">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64e185b1-b207-466b-bce6-ef319f1e1774">
											<gml:posList>35.6704646777338 139.74087093681334 8.9 35.67041338218687 139.74086127525618 8.9 35.67041338218687 139.74086127525618 19.906 35.6704646777338 139.74087093681334 19.906 35.6704646777338 139.74087093681334 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8842b316-8af6-4c21-bd4a-973040a30ca2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8842b316-8af6-4c21-bd4a-973040a30ca2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8842b316-8af6-4c21-bd4a-973040a30ca2">
											<gml:posList>35.67045034350471 139.74099702441382 27.99 35.67045034350471 139.74099702441382 27.574 35.670429055581906 139.74100029653235 27.574 35.670429055581906 139.74100029653235 27.99 35.67045034350471 139.74099702441382 27.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de2330e9-40ad-4bc7-a0de-66faa662c041">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de2330e9-40ad-4bc7-a0de-66faa662c041">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de2330e9-40ad-4bc7-a0de-66faa662c041">
											<gml:posList>35.6704277681696 139.7410023194816 27.99 35.6704277681696 139.7410023194816 25.389 35.67043037283056 139.74100191881655 25.389 35.67043037283056 139.74100191881655 25.001 35.67045198521354 139.74099860213968 25.001 35.67045198521354 139.74099860213968 27.99 35.6704277681696 139.7410023194816 27.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ace032e-d6c5-4e8b-a1d1-584329499ac7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ace032e-d6c5-4e8b-a1d1-584329499ac7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ace032e-d6c5-4e8b-a1d1-584329499ac7">
											<gml:posList>35.670446574444554 139.74096004584706 27.99 35.670446574444554 139.74096004584706 27.574 35.67045034350471 139.74099702441382 27.574 35.67045034350471 139.74099702441382 27.99 35.670446574444554 139.74096004584706 27.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fbf3b86-2d3e-41d7-a9b7-5ffad61bed33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fbf3b86-2d3e-41d7-a9b7-5ffad61bed33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fbf3b86-2d3e-41d7-a9b7-5ffad61bed33">
											<gml:posList>35.67044785285089 139.74095803395323 27.99 35.67045198521354 139.74099860213968 27.99 35.67045198521354 139.74099860213968 25.001 35.67044785285089 139.74095803395323 25.001 35.67044785285089 139.74095803395323 27.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc6b8cd0-5e25-4d3d-a4fc-c24a993f9df5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc6b8cd0-5e25-4d3d-a4fc-c24a993f9df5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc6b8cd0-5e25-4d3d-a4fc-c24a993f9df5">
											<gml:posList>35.67048299175452 139.74102121129252 25.389 35.67048299175452 139.74102121129252 25.001 35.67043309746757 139.7410286807833 25.001 35.67043309746757 139.7410286807833 25.389 35.67048299175452 139.74102121129252 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f60315b2-0ffa-42bf-8328-c25bc21e085d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f60315b2-0ffa-42bf-8328-c25bc21e085d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f60315b2-0ffa-42bf-8328-c25bc21e085d">
											<gml:posList>35.67048634695101 139.7410239358592 25.389 35.670430819730726 139.74103225134965 25.389 35.670430819730726 139.74103225134965 8.9 35.67049769393221 139.7410222327151 8.9 35.67049769393221 139.7410222327151 19.906 35.67048634695101 139.7410239358592 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d0ffbc0-9f3f-4e87-b4b4-fee547e759be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d0ffbc0-9f3f-4e87-b4b4-fee547e759be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d0ffbc0-9f3f-4e87-b4b4-fee547e759be">
											<gml:posList>35.67045402508571 139.7408964770274 25.389 35.67045402508571 139.7408964770274 25.001 35.67048299175452 139.74102121129252 25.001 35.67048299175452 139.74102121129252 25.389 35.67045402508571 139.7408964770274 25.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3078c18-064c-4338-a099-0b0331f68e8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3078c18-064c-4338-a099-0b0331f68e8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3078c18-064c-4338-a099-0b0331f68e8d">
											<gml:posList>35.670475143151485 139.74088329656965 8.9 35.6704646777338 139.74087093681334 8.9 35.6704646777338 139.74087093681334 19.906 35.670475143151485 139.74088329656965 19.906 35.670475143151485 139.74088329656965 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b1faed5-f6cb-4faf-b140-eb9d0b80d929">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b1faed5-f6cb-4faf-b140-eb9d0b80d929">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b1faed5-f6cb-4faf-b140-eb9d0b80d929">
											<gml:posList>35.67049769393221 139.7410222327151 8.9 35.670475143151485 139.74088329656965 8.9 35.670475143151485 139.74088329656965 19.906 35.67049769393221 139.7410222327151 19.906 35.67049769393221 139.7410222327151 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1187</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">69.73594</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>