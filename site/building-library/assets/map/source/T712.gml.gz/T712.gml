<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cca78598-6e60-410a-accf-b78087cd2b9b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">30.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67052108658551 139.74395201037663 0 35.670558996626056 139.74377986700335 0 35.670447018572986 139.7437428766128 0 35.67040595886664 139.74392187195892 0 35.67052108658551 139.74395201037663 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052108658551 139.74395201037663 7.41 35.67040595886664 139.74392187195892 7.41 35.670447018572986 139.7437428766128 7.41 35.670558996626056 139.74377986700335 7.41 35.67052108658551 139.74395201037663 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052108658551 139.74395201037663 7.41 35.670558996626056 139.74377986700335 7.41 35.670558996626056 139.74377986700335 37.79 35.67052108658551 139.74395201037663 37.79 35.67052108658551 139.74395201037663 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670558996626056 139.74377986700335 7.41 35.670447018572986 139.7437428766128 7.41 35.670447018572986 139.7437428766128 37.79 35.670558996626056 139.74377986700335 37.79 35.670558996626056 139.74377986700335 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670447018572986 139.7437428766128 7.41 35.67040595886664 139.74392187195892 7.41 35.67040595886664 139.74392187195892 37.79 35.670447018572986 139.7437428766128 37.79 35.670447018572986 139.7437428766128 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040595886664 139.74392187195892 7.41 35.67052108658551 139.74395201037663 7.41 35.67052108658551 139.74395201037663 37.79 35.67040595886664 139.74392187195892 37.79 35.67040595886664 139.74392187195892 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052108658551 139.74395201037663 37.79 35.670558996626056 139.74377986700335 37.79 35.670447018572986 139.7437428766128 37.79 35.67040595886664 139.74392187195892 37.79 35.67052108658551 139.74395201037663 37.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7db460b9-94d2-468e-bd92-dae230d4077d"/>
							<gml:surfaceMember xlink:href="#poly-54965630-a599-444b-90f6-49566f12ddff"/>
							<gml:surfaceMember xlink:href="#poly-67ae06f2-fd4e-4615-afe8-da6ce6bf25a0"/>
							<gml:surfaceMember xlink:href="#poly-c8461e46-6aa6-40dc-85dc-28adcdf4469b"/>
							<gml:surfaceMember xlink:href="#poly-36bbc60a-4df8-4c89-8989-8569aad9378e"/>
							<gml:surfaceMember xlink:href="#poly-e5864f2d-ca6c-4608-8c42-412f3774fa12"/>
							<gml:surfaceMember xlink:href="#poly-ebee0d63-a2a3-46e2-bd61-b8e2bc517b76"/>
							<gml:surfaceMember xlink:href="#poly-21a6cbef-a7b8-437b-9acd-608c7a808178"/>
							<gml:surfaceMember xlink:href="#poly-843a5259-4686-46b0-9f3a-527016f66fed"/>
							<gml:surfaceMember xlink:href="#poly-9aa0c03b-4d54-4570-b0be-09c0a96c7953"/>
							<gml:surfaceMember xlink:href="#poly-8a909e84-bbd5-4c2b-8964-119546dfbcba"/>
							<gml:surfaceMember xlink:href="#poly-57d6bdf9-c88e-4cf9-bc78-d0f7ed9d7250"/>
							<gml:surfaceMember xlink:href="#poly-c881043d-ac65-4aac-825b-9eaa054b6bfd"/>
							<gml:surfaceMember xlink:href="#poly-16aab0cc-c706-4275-b169-ee809d425bcf"/>
							<gml:surfaceMember xlink:href="#poly-c678940c-2713-4cb7-a722-ad580e02bbc8"/>
							<gml:surfaceMember xlink:href="#poly-cfe5e37a-3e2f-45df-85ec-06f2606e24bf"/>
							<gml:surfaceMember xlink:href="#poly-c1d87242-f209-489a-b82a-6f0c0fa99043"/>
							<gml:surfaceMember xlink:href="#poly-5df6a6ba-3f14-4e1f-8221-e85ff04f4a3d"/>
							<gml:surfaceMember xlink:href="#poly-8fc39a3f-80b5-427e-988c-d3695c612034"/>
							<gml:surfaceMember xlink:href="#poly-d0a52761-1aff-483b-8541-8f59e02962f4"/>
							<gml:surfaceMember xlink:href="#poly-8e295bed-5f45-4ff6-ad83-4f95d63cf991"/>
							<gml:surfaceMember xlink:href="#poly-60052bfc-a7eb-41dc-a892-8358d5118266"/>
							<gml:surfaceMember xlink:href="#poly-b3417e6a-ef7e-484b-8361-f263440050d0"/>
							<gml:surfaceMember xlink:href="#poly-84f2db4b-b573-4df4-b3eb-8bf3a7583e38"/>
							<gml:surfaceMember xlink:href="#poly-2625bb4f-b691-4fc0-9731-748c89748d3d"/>
							<gml:surfaceMember xlink:href="#poly-7f1f1f45-7f69-45d8-8f40-917722bc1c07"/>
							<gml:surfaceMember xlink:href="#poly-f62f9426-4e48-4695-819a-bc443acbc1b2"/>
							<gml:surfaceMember xlink:href="#poly-acc52f3e-58fa-42ca-9783-e8dbaf85d4de"/>
							<gml:surfaceMember xlink:href="#poly-29f8fee0-98ff-4da2-af0d-dd40f5b09670"/>
							<gml:surfaceMember xlink:href="#poly-5b26e665-60cb-494a-b21e-c93fa230952c"/>
							<gml:surfaceMember xlink:href="#poly-88ec37e8-d09b-4d97-a080-ebd1ad155df3"/>
							<gml:surfaceMember xlink:href="#poly-f2428409-4e27-49dd-bd5f-bb962613c3b1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_cca78598-6e60-410a-accf-b78087cd2b9b_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70e74602-6c41-4b1a-b6d6-ec14c8f03da3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67053232194195 139.74383637643092 36.599 35.67052639632859 139.7438679312208 36.599 35.670490216640005 139.74385772064863 36.599 35.67049614225894 139.74382617691853 36.599 35.67053232194195 139.74383637643092 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0504951-b878-489c-9afc-01c35d5c3072">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6704201023081 139.74386240518683 37.5 35.67042136449203 139.74386275725882 37.5 35.67041491354028 139.74389089929335 37.5 35.6704201023081 139.74386240518683 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87cb054c-85ca-431c-8140-1d9bf113fcd0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052557807409 139.74387061637984 36.599 35.67051983481823 139.7439049877623 36.599 35.67048289867735 139.74389571695133 36.599 35.670488641930625 139.74386134558407 36.599 35.67052557807409 139.74387061637984 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fb262fe-4560-47c1-b62e-01c7802af07d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047768375207 139.7438768667802 36.599 35.67047053374644 139.74391042228646 36.599 35.670450076734994 139.74390388361843 36.599 35.67045722673883 139.74387032812015 36.599 35.67047768375207 139.7438768667802 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23aec37b-e5bc-44c8-87dd-443a8af7bc7e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041000302639 139.74391782451642 36.599 35.67041491354028 139.74389089929335 36.599 35.67042136449203 139.74386275725882 36.599 35.67044961927114 139.74387049125647 36.599 35.67043951997759 139.74392589955917 36.599 35.67041000302639 139.74391782451642 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-caa86235-f6d7-4948-b187-8fa5304c1bca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67048219024419 139.74390063333345 36.599 35.6705179546909 139.74391002696248 36.599 35.670511573015624 139.74394650888968 36.599 35.67047580857171 139.7439371152451 36.599 35.67048219024419 139.74390063333345 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8715993c-1372-4bec-b86f-5e44df6550a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8715993c-1372-4bec-b86f-5e44df6550a5_0">
											<gml:posList>35.67052639632859 139.7438679312208 39.707 35.670490216640005 139.74385772064863 39.707 35.670490216640005 139.74385772064863 36.599 35.67052639632859 139.7438679312208 36.599 35.67052639632859 139.7438679312208 39.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21fc7210-0600-4e5a-a002-8cec6ab9fe9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21fc7210-0600-4e5a-a002-8cec6ab9fe9a_0">
											<gml:posList>35.67048219024419 139.74390063333345 36.599 35.67048219024419 139.74390063333345 39.707 35.6705179546909 139.74391002696248 39.707 35.6705179546909 139.74391002696248 36.599 35.67048219024419 139.74390063333345 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-452d5fa9-a01b-4844-b99c-64302516cd0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-452d5fa9-a01b-4844-b99c-64302516cd0d_0">
											<gml:posList>35.67049614225894 139.74382617691853 36.599 35.67049614225894 139.74382617691853 39.707 35.67053232194195 139.74383637643092 39.707 35.67053232194195 139.74383637643092 36.599 35.67049614225894 139.74382617691853 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f161dfc-f226-4670-9bf8-53c51e1a81f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f161dfc-f226-4670-9bf8-53c51e1a81f7_0">
											<gml:posList>35.670490216640005 139.74385772064863 36.599 35.670490216640005 139.74385772064863 39.707 35.67049614225894 139.74382617691853 39.707 35.67049614225894 139.74382617691853 36.599 35.670490216640005 139.74385772064863 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f010aaa-6513-4201-8963-b07a6ff5f664">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f010aaa-6513-4201-8963-b07a6ff5f664_0">
											<gml:posList>35.67053232194195 139.74383637643092 39.707 35.67049614225894 139.74382617691853 39.707 35.670490216640005 139.74385772064863 39.707 35.67052639632859 139.7438679312208 39.707 35.67053232194195 139.74383637643092 39.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51062f54-fbf0-49be-850c-97bc8c925801">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51062f54-fbf0-49be-850c-97bc8c925801_0">
											<gml:posList>35.67041000302639 139.74391782451642 36.599 35.67041000302639 139.74391782451642 39.824 35.6704201023081 139.74386240518683 39.824 35.6704201023081 139.74386240518683 37.5 35.67041491354028 139.74389089929335 37.5 35.67041491354028 139.74389089929335 36.599 35.67041000302639 139.74391782451642 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f84f10d-aeae-44f6-a5c2-d1668bac0253">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f84f10d-aeae-44f6-a5c2-d1668bac0253_0">
											<gml:posList>35.67041491354028 139.74389089929335 36.599 35.67041491354028 139.74389089929335 37.5 35.67042136449203 139.74386275725882 37.5 35.67042136449203 139.74386275725882 36.599 35.67041491354028 139.74389089929335 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68ab82c2-7ea7-4503-bd58-5a16ff9eba63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68ab82c2-7ea7-4503-bd58-5a16ff9eba63_0">
											<gml:posList>35.67043951997759 139.74392589955917 36.599 35.67043951997759 139.74392589955917 39.824 35.67041000302639 139.74391782451642 39.824 35.67041000302639 139.74391782451642 36.599 35.67043951997759 139.74392589955917 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b43b065-e6ea-4978-a6bb-bf752de799bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b43b065-e6ea-4978-a6bb-bf752de799bc_0">
											<gml:posList>35.67044961927114 139.74387049125647 39.824 35.6704201023081 139.74386240518683 39.824 35.67041000302639 139.74391782451642 39.824 35.67043951997759 139.74392589955917 39.824 35.67044961927114 139.74387049125647 39.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc848211-2767-4257-9122-bc73b797bd80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc848211-2767-4257-9122-bc73b797bd80_0">
											<gml:posList>35.6704201023081 139.74386240518683 39.824 35.67044961927114 139.74387049125647 39.824 35.67044961927114 139.74387049125647 36.599 35.67042136449203 139.74386275725882 36.599 35.67042136449203 139.74386275725882 37.5 35.6704201023081 139.74386240518683 37.5 35.6704201023081 139.74386240518683 39.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b616fb2-df91-44d1-8c48-e4f01fc79ded">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b616fb2-df91-44d1-8c48-e4f01fc79ded_0">
											<gml:posList>35.67043951997759 139.74392589955917 36.599 35.67044961927114 139.74387049125647 36.599 35.67044961927114 139.74387049125647 39.824 35.67043951997759 139.74392589955917 39.824 35.67043951997759 139.74392589955917 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-829c7925-021c-4578-818e-54b38a38324e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-829c7925-021c-4578-818e-54b38a38324e_0">
											<gml:posList>35.670450076734994 139.74390388361843 36.599 35.670450076734994 139.74390388361843 39.453 35.67045722673883 139.74387032812015 39.453 35.67045722673883 139.74387032812015 36.599 35.670450076734994 139.74390388361843 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fe83d9f-11c5-4cfd-b384-7df52de0816a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fe83d9f-11c5-4cfd-b384-7df52de0816a_0">
											<gml:posList>35.670450076734994 139.74390388361843 36.599 35.67047053374644 139.74391042228646 36.599 35.67047053374644 139.74391042228646 39.453 35.670450076734994 139.74390388361843 39.453 35.670450076734994 139.74390388361843 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-395a28b2-ab3b-4660-8dfc-ccc5e21edad3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-395a28b2-ab3b-4660-8dfc-ccc5e21edad3_0">
											<gml:posList>35.67047768375207 139.7438768667802 39.453 35.67045722673883 139.74387032812015 39.453 35.670450076734994 139.74390388361843 39.453 35.67047053374644 139.74391042228646 39.453 35.67047768375207 139.7438768667802 39.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4172b82-eb17-43df-a715-ea248028e578">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4172b82-eb17-43df-a715-ea248028e578_0">
											<gml:posList>35.67045722673883 139.74387032812015 36.599 35.67045722673883 139.74387032812015 39.453 35.67047768375207 139.7438768667802 39.453 35.67047768375207 139.7438768667802 36.599 35.67045722673883 139.74387032812015 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d33ab64-a5ec-4e8e-9968-c1c740c8f0b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d33ab64-a5ec-4e8e-9968-c1c740c8f0b3_0">
											<gml:posList>35.67047053374644 139.74391042228646 36.599 35.67047768375207 139.7438768667802 36.599 35.67047768375207 139.7438768667802 39.453 35.67047053374644 139.74391042228646 39.453 35.67047053374644 139.74391042228646 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be4041ad-ef51-42cc-a0ce-1f829edbe981">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be4041ad-ef51-42cc-a0ce-1f829edbe981_0">
											<gml:posList>35.67048219024419 139.74390063333345 36.599 35.67047580857171 139.7439371152451 36.599 35.67047580857171 139.7439371152451 39.707 35.67048219024419 139.74390063333345 39.707 35.67048219024419 139.74390063333345 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9028010-0405-40d3-a626-655a0401b1ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9028010-0405-40d3-a626-655a0401b1ce_0">
											<gml:posList>35.670488641930625 139.74386134558407 36.599 35.67048289867735 139.74389571695133 36.599 35.67048289867735 139.74389571695133 39.707 35.670488641930625 139.74386134558407 39.707 35.670488641930625 139.74386134558407 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b63f9006-fe8e-4213-b7a9-053663c0c175">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b63f9006-fe8e-4213-b7a9-053663c0c175_0">
											<gml:posList>35.67047580857171 139.7439371152451 36.599 35.670511573015624 139.74394650888968 36.599 35.670511573015624 139.74394650888968 39.707 35.67047580857171 139.7439371152451 39.707 35.67047580857171 139.7439371152451 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb13ef65-fdf9-4ccb-b545-803876cd082a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb13ef65-fdf9-4ccb-b545-803876cd082a_0">
											<gml:posList>35.670511573015624 139.74394650888968 39.707 35.6705179546909 139.74391002696248 39.707 35.67048219024419 139.74390063333345 39.707 35.67047580857171 139.7439371152451 39.707 35.670511573015624 139.74394650888968 39.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a977204b-d3bf-44e9-ab4d-01cc52b3bc6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a977204b-d3bf-44e9-ab4d-01cc52b3bc6e_0">
											<gml:posList>35.67048289867735 139.74389571695133 36.599 35.67051983481823 139.7439049877623 36.599 35.67051983481823 139.7439049877623 39.707 35.67048289867735 139.74389571695133 39.707 35.67048289867735 139.74389571695133 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d721b6e-273c-43f2-988e-b8cc33ae1e4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d721b6e-273c-43f2-988e-b8cc33ae1e4b_0">
											<gml:posList>35.67052557807409 139.74387061637984 39.707 35.670488641930625 139.74386134558407 39.707 35.67048289867735 139.74389571695133 39.707 35.67051983481823 139.7439049877623 39.707 35.67052557807409 139.74387061637984 39.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9db5f19-c8e8-4b58-92de-ce882ccc07f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9db5f19-c8e8-4b58-92de-ce882ccc07f7_0">
											<gml:posList>35.67052557807409 139.74387061637984 36.599 35.670488641930625 139.74386134558407 36.599 35.670488641930625 139.74386134558407 39.707 35.67052557807409 139.74387061637984 39.707 35.67052557807409 139.74387061637984 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5c5f4c1-ee83-44bf-bba9-b3017de153a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5c5f4c1-ee83-44bf-bba9-b3017de153a7_0">
											<gml:posList>35.670511573015624 139.74394650888968 36.599 35.6705179546909 139.74391002696248 36.599 35.6705179546909 139.74391002696248 39.707 35.670511573015624 139.74394650888968 39.707 35.670511573015624 139.74394650888968 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af385655-879d-44bd-9ba5-47706e56f116">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af385655-879d-44bd-9ba5-47706e56f116_0">
											<gml:posList>35.67052557807409 139.74387061637984 36.599 35.67052557807409 139.74387061637984 39.707 35.67051983481823 139.7439049877623 39.707 35.67051983481823 139.7439049877623 36.599 35.67052557807409 139.74387061637984 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab33254f-cdec-49f0-9581-4070ee8d7a14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab33254f-cdec-49f0-9581-4070ee8d7a14_0">
											<gml:posList>35.67052639632859 139.7438679312208 36.599 35.67053232194195 139.74383637643092 36.599 35.67053232194195 139.74383637643092 39.707 35.67052639632859 139.7438679312208 39.707 35.67052639632859 139.7438679312208 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_cca78598-6e60-410a-accf-b78087cd2b9b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdd666c4-f8a4-4f6a-8211-dcf70c0d11b2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051433398653 139.74395023945362 37.5 35.67054481453952 139.74377517712767 37.5 35.67055899662605 139.74377986700335 37.5 35.670521086585474 139.74395201037663 37.5 35.67051433398653 139.74395023945362 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9485a3fd-3b56-4472-b93d-3e7a8010a5c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9485a3fd-3b56-4472-b93d-3e7a8010a5c0_0">
											<gml:posList>35.67055899662605 139.74377986700335 38.839 35.67055899662605 139.74377986700335 37.5 35.67054481453952 139.74377517712767 37.5 35.67054481453952 139.74377517712767 38.839 35.67055899662605 139.74377986700335 38.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a056b93-5e08-46b2-bf4a-71bab2b54f84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a056b93-5e08-46b2-bf4a-71bab2b54f84_0">
											<gml:posList>35.67054481453952 139.74377517712767 38.839 35.67054481453952 139.74377517712767 37.5 35.67051433398653 139.74395023945362 37.5 35.67051433398653 139.74395023945362 38.839 35.67054481453952 139.74377517712767 38.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c1e3c6d-622d-4b29-8fa8-83a370bf6916">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c1e3c6d-622d-4b29-8fa8-83a370bf6916_0">
											<gml:posList>35.670521086585474 139.74395201037663 38.839 35.67055899662605 139.74377986700335 38.839 35.67054481453952 139.74377517712767 38.839 35.67051433398653 139.74395023945362 38.839 35.670521086585474 139.74395201037663 38.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b9deba3-49f3-4028-9561-4982b6272ba6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b9deba3-49f3-4028-9561-4982b6272ba6_0">
											<gml:posList>35.670521086585474 139.74395201037663 38.839 35.670521086585474 139.74395201037663 37.5 35.67055899662605 139.74377986700335 37.5 35.67055899662605 139.74377986700335 38.839 35.670521086585474 139.74395201037663 38.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-293b0b9e-c765-45a3-8281-2aac92b308bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-293b0b9e-c765-45a3-8281-2aac92b308bf_0">
											<gml:posList>35.67051433398653 139.74395023945362 38.839 35.67051433398653 139.74395023945362 37.5 35.670521086585474 139.74395201037663 37.5 35.670521086585474 139.74395201037663 38.839 35.67051433398653 139.74395023945362 38.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7db460b9-94d2-468e-bd92-dae230d4077d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7db460b9-94d2-468e-bd92-dae230d4077d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7db460b9-94d2-468e-bd92-dae230d4077d">
											<gml:posList>35.670521086585474 139.74395201037663 7.41 35.670405958866624 139.74392187195892 7.41 35.670447018572965 139.74374287661277 7.41 35.67055899662605 139.74377986700335 7.41 35.670521086585474 139.74395201037663 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54965630-a599-444b-90f6-49566f12ddff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54965630-a599-444b-90f6-49566f12ddff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54965630-a599-444b-90f6-49566f12ddff">
											<gml:posList>35.670447018572965 139.74374287661277 37.5 35.67044824642003 139.74374553739165 37.5 35.670464186611326 139.74375079969823 37.5 35.670466249587015 139.74374922882268 37.5 35.670447018572965 139.74374287661277 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67ae06f2-fd4e-4615-afe8-da6ce6bf25a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67ae06f2-fd4e-4615-afe8-da6ce6bf25a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67ae06f2-fd4e-4615-afe8-da6ce6bf25a0">
											<gml:posList>35.67046591756672 139.7437512285688 37.5 35.670466249587015 139.74374922882268 37.5 35.670464186611326 139.74375079969823 37.5 35.67046591756672 139.7437512285688 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8461e46-6aa6-40dc-85dc-28adcdf4469b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8461e46-6aa6-40dc-85dc-28adcdf4469b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8461e46-6aa6-40dc-85dc-28adcdf4469b">
											<gml:posList>35.670466249587015 139.74374922882268 40.564 35.670466998819066 139.7437506971397 40.564 35.6705306423867 139.74377172442595 40.564 35.67053176846947 139.74377087260444 40.564 35.670466249587015 139.74374922882268 40.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36bbc60a-4df8-4c89-8989-8569aad9378e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36bbc60a-4df8-4c89-8989-8569aad9378e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36bbc60a-4df8-4c89-8989-8569aad9378e">
											<gml:posList>35.670533122540895 139.74377357743066 37.5 35.67053176846947 139.74377087260444 37.5 35.670531391585605 139.74377314855926 37.5 35.670533122540895 139.74377357743066 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5864f2d-ca6c-4608-8c42-412f3774fa12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5864f2d-ca6c-4608-8c42-412f3774fa12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5864f2d-ca6c-4608-8c42-412f3774fa12">
											<gml:posList>35.67053176846947 139.74377087260444 37.5 35.670533122540895 139.74377357743066 37.5 35.67055681644693 139.74378140487198 37.5 35.67055899662605 139.74377986700335 37.5 35.67053176846947 139.74377087260444 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ebee0d63-a2a3-46e2-bd61-b8e2bc517b76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebee0d63-a2a3-46e2-bd61-b8e2bc517b76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebee0d63-a2a3-46e2-bd61-b8e2bc517b76">
											<gml:posList>35.67045549952534 139.74381429231892 40.564 35.67045664357017 139.7438133521086 40.564 35.670466998819066 139.7437506971397 40.564 35.670466249587015 139.74374922882268 40.564 35.67045549952534 139.74381429231892 40.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21a6cbef-a7b8-437b-9acd-608c7a808178">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21a6cbef-a7b8-437b-9acd-608c7a808178">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21a6cbef-a7b8-437b-9acd-608c7a808178">
											<gml:posList>35.6705306423867 139.74377172442595 39.858 35.670466998819066 139.7437506971397 39.858 35.67045664357017 139.7438133521086 39.858 35.67052112166751 139.74382935245328 39.858 35.6705306423867 139.74377172442595 39.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-843a5259-4686-46b0-9f3a-527016f66fed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-843a5259-4686-46b0-9f3a-527016f66fed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-843a5259-4686-46b0-9f3a-527016f66fed">
											<gml:posList>35.67053176846947 139.74377087260444 40.564 35.6705306423867 139.74377172442595 40.564 35.67052112166751 139.74382935245328 40.564 35.67052187986304 139.74383075448438 40.564 35.67053176846947 139.74377087260444 40.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9aa0c03b-4d54-4570-b0be-09c0a96c7953">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9aa0c03b-4d54-4570-b0be-09c0a96c7953">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9aa0c03b-4d54-4570-b0be-09c0a96c7953">
											<gml:posList>35.67052187986304 139.74383075448438 40.564 35.67052112166751 139.74382935245328 40.564 35.67045664357017 139.7438133521086 40.564 35.67045549952534 139.74381429231892 40.564 35.67052187986304 139.74383075448438 40.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a909e84-bbd5-4c2b-8964-119546dfbcba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a909e84-bbd5-4c2b-8964-119546dfbcba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a909e84-bbd5-4c2b-8964-119546dfbcba">
											<gml:posList>35.670405958866624 139.74392187195892 37.5 35.67040818403419 139.7439202235842 37.5 35.67044824642003 139.74374553739165 37.5 35.670447018572965 139.74374287661277 37.5 35.670405958866624 139.74392187195892 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-57d6bdf9-c88e-4cf9-bc78-d0f7ed9d7250">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57d6bdf9-c88e-4cf9-bc78-d0f7ed9d7250">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57d6bdf9-c88e-4cf9-bc78-d0f7ed9d7250">
											<gml:posList>35.670533122540895 139.74377357743066 36.599 35.670531391585605 139.74377314855926 36.599 35.67052187986304 139.74383075448438 36.599 35.67045549952534 139.74381429231892 36.599 35.67046591756672 139.7437512285688 36.599 35.670464186611326 139.74375079969823 36.599 35.67044824642003 139.74374553739165 36.599 35.67040818403419 139.7439202235842 36.599 35.67051980473444 139.7439494490689 36.599 35.67055681644693 139.74378140487198 36.599 35.670533122540895 139.74377357743066 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c881043d-ac65-4aac-825b-9eaa054b6bfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c881043d-ac65-4aac-825b-9eaa054b6bfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c881043d-ac65-4aac-825b-9eaa054b6bfd">
											<gml:posList>35.67055899662605 139.74377986700335 37.5 35.67055681644693 139.74378140487198 37.5 35.67051980473444 139.7439494490689 37.5 35.670521086585474 139.74395201037663 37.5 35.67055899662605 139.74377986700335 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16aab0cc-c706-4275-b169-ee809d425bcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16aab0cc-c706-4275-b169-ee809d425bcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16aab0cc-c706-4275-b169-ee809d425bcf">
											<gml:posList>35.670521086585474 139.74395201037663 37.5 35.67051980473444 139.7439494490689 37.5 35.67040818403419 139.7439202235842 37.5 35.670405958866624 139.74392187195892 37.5 35.670521086585474 139.74395201037663 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c678940c-2713-4cb7-a722-ad580e02bbc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c678940c-2713-4cb7-a722-ad580e02bbc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c678940c-2713-4cb7-a722-ad580e02bbc8">
											<gml:posList>35.67044824642003 139.74374553739165 37.5 35.67044824642003 139.74374553739165 36.599 35.670464186611326 139.74375079969823 36.599 35.670464186611326 139.74375079969823 37.5 35.67044824642003 139.74374553739165 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfe5e37a-3e2f-45df-85ec-06f2606e24bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfe5e37a-3e2f-45df-85ec-06f2606e24bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfe5e37a-3e2f-45df-85ec-06f2606e24bf">
											<gml:posList>35.670464186611326 139.74375079969823 37.5 35.670464186611326 139.74375079969823 36.599 35.67046591756672 139.7437512285688 36.599 35.67046591756672 139.7437512285688 37.5 35.670464186611326 139.74375079969823 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1d87242-f209-489a-b82a-6f0c0fa99043">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1d87242-f209-489a-b82a-6f0c0fa99043">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1d87242-f209-489a-b82a-6f0c0fa99043">
											<gml:posList>35.6705306423867 139.74377172442595 39.858 35.6705306423867 139.74377172442595 40.564 35.670466998819066 139.7437506971397 40.564 35.670466998819066 139.7437506971397 39.858 35.6705306423867 139.74377172442595 39.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5df6a6ba-3f14-4e1f-8221-e85ff04f4a3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5df6a6ba-3f14-4e1f-8221-e85ff04f4a3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5df6a6ba-3f14-4e1f-8221-e85ff04f4a3d">
											<gml:posList>35.670466249587015 139.74374922882268 37.5 35.670466249587015 139.74374922882268 40.564 35.67053176846947 139.74377087260444 40.564 35.67053176846947 139.74377087260444 37.5 35.67055899662605 139.74377986700335 37.5 35.67055899662605 139.74377986700335 7.41 35.670447018572965 139.74374287661277 7.41 35.670447018572965 139.74374287661277 37.5 35.670466249587015 139.74374922882268 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fc39a3f-80b5-427e-988c-d3695c612034">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fc39a3f-80b5-427e-988c-d3695c612034">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fc39a3f-80b5-427e-988c-d3695c612034">
											<gml:posList>35.670531391585605 139.74377314855926 37.5 35.670531391585605 139.74377314855926 36.599 35.670533122540895 139.74377357743066 36.599 35.670533122540895 139.74377357743066 37.5 35.670531391585605 139.74377314855926 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0a52761-1aff-483b-8541-8f59e02962f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0a52761-1aff-483b-8541-8f59e02962f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0a52761-1aff-483b-8541-8f59e02962f4">
											<gml:posList>35.670533122540895 139.74377357743066 37.5 35.670533122540895 139.74377357743066 36.599 35.67055681644693 139.74378140487198 36.599 35.67055681644693 139.74378140487198 37.5 35.670533122540895 139.74377357743066 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e295bed-5f45-4ff6-ad83-4f95d63cf991">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e295bed-5f45-4ff6-ad83-4f95d63cf991">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e295bed-5f45-4ff6-ad83-4f95d63cf991">
											<gml:posList>35.67046591756672 139.7437512285688 37.5 35.67046591756672 139.7437512285688 36.599 35.67045549952534 139.74381429231892 36.599 35.67045549952534 139.74381429231892 40.564 35.670466249587015 139.74374922882268 40.564 35.670466249587015 139.74374922882268 37.5 35.67046591756672 139.7437512285688 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60052bfc-a7eb-41dc-a892-8358d5118266">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60052bfc-a7eb-41dc-a892-8358d5118266">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60052bfc-a7eb-41dc-a892-8358d5118266">
											<gml:posList>35.670466998819066 139.7437506971397 39.858 35.670466998819066 139.7437506971397 40.564 35.67045664357017 139.7438133521086 40.564 35.67045664357017 139.7438133521086 39.858 35.670466998819066 139.7437506971397 39.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3417e6a-ef7e-484b-8361-f263440050d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3417e6a-ef7e-484b-8361-f263440050d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3417e6a-ef7e-484b-8361-f263440050d0">
											<gml:posList>35.6705306423867 139.74377172442595 40.564 35.6705306423867 139.74377172442595 39.858 35.67052112166751 139.74382935245328 39.858 35.67052112166751 139.74382935245328 40.564 35.6705306423867 139.74377172442595 40.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84f2db4b-b573-4df4-b3eb-8bf3a7583e38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84f2db4b-b573-4df4-b3eb-8bf3a7583e38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84f2db4b-b573-4df4-b3eb-8bf3a7583e38">
											<gml:posList>35.670531391585605 139.74377314855926 37.5 35.67053176846947 139.74377087260444 37.5 35.67053176846947 139.74377087260444 40.564 35.67052187986304 139.74383075448438 40.564 35.67052187986304 139.74383075448438 36.599 35.670531391585605 139.74377314855926 36.599 35.670531391585605 139.74377314855926 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2625bb4f-b691-4fc0-9731-748c89748d3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2625bb4f-b691-4fc0-9731-748c89748d3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2625bb4f-b691-4fc0-9731-748c89748d3d">
											<gml:posList>35.67052112166751 139.74382935245328 40.564 35.67052112166751 139.74382935245328 39.858 35.67045664357017 139.7438133521086 39.858 35.67045664357017 139.7438133521086 40.564 35.67052112166751 139.74382935245328 40.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f1f1f45-7f69-45d8-8f40-917722bc1c07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f1f1f45-7f69-45d8-8f40-917722bc1c07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f1f1f45-7f69-45d8-8f40-917722bc1c07">
											<gml:posList>35.67045549952534 139.74381429231892 36.599 35.67052187986304 139.74383075448438 36.599 35.67052187986304 139.74383075448438 40.564 35.67045549952534 139.74381429231892 40.564 35.67045549952534 139.74381429231892 36.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f62f9426-4e48-4695-819a-bc443acbc1b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f62f9426-4e48-4695-819a-bc443acbc1b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f62f9426-4e48-4695-819a-bc443acbc1b2">
											<gml:posList>35.670447018572965 139.74374287661277 7.41 35.670405958866624 139.74392187195892 7.41 35.670405958866624 139.74392187195892 37.5 35.670447018572965 139.74374287661277 37.5 35.670447018572965 139.74374287661277 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-acc52f3e-58fa-42ca-9783-e8dbaf85d4de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acc52f3e-58fa-42ca-9783-e8dbaf85d4de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acc52f3e-58fa-42ca-9783-e8dbaf85d4de">
											<gml:posList>35.67040818403419 139.7439202235842 37.5 35.67040818403419 139.7439202235842 36.599 35.67044824642003 139.74374553739165 36.599 35.67044824642003 139.74374553739165 37.5 35.67040818403419 139.7439202235842 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29f8fee0-98ff-4da2-af0d-dd40f5b09670">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29f8fee0-98ff-4da2-af0d-dd40f5b09670">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29f8fee0-98ff-4da2-af0d-dd40f5b09670">
											<gml:posList>35.67055681644693 139.74378140487198 37.5 35.67055681644693 139.74378140487198 36.599 35.67051980473444 139.7439494490689 36.599 35.67051980473444 139.7439494490689 37.5 35.67055681644693 139.74378140487198 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b26e665-60cb-494a-b21e-c93fa230952c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b26e665-60cb-494a-b21e-c93fa230952c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b26e665-60cb-494a-b21e-c93fa230952c">
											<gml:posList>35.670521086585474 139.74395201037663 7.41 35.67055899662605 139.74377986700335 7.41 35.67055899662605 139.74377986700335 37.5 35.670521086585474 139.74395201037663 37.5 35.670521086585474 139.74395201037663 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88ec37e8-d09b-4d97-a080-ebd1ad155df3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88ec37e8-d09b-4d97-a080-ebd1ad155df3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88ec37e8-d09b-4d97-a080-ebd1ad155df3">
											<gml:posList>35.67051980473444 139.7439494490689 37.5 35.67051980473444 139.7439494490689 36.599 35.67040818403419 139.7439202235842 36.599 35.67040818403419 139.7439202235842 37.5 35.67051980473444 139.7439494490689 37.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2428409-4e27-49dd-bd5f-bb962613c3b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2428409-4e27-49dd-bd5f-bb962613c3b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2428409-4e27-49dd-bd5f-bb962613c3b1">
											<gml:posList>35.670405958866624 139.74392187195892 7.41 35.670521086585474 139.74395201037663 7.41 35.670521086585474 139.74395201037663 37.5 35.670405958866624 139.74392187195892 37.5 35.670405958866624 139.74392187195892 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-300</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">213.5393</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>