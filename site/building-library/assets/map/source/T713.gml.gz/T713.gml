<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ccc5d161-3238-433a-aeab-410d860f6db9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">17.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66922582668437 139.7392831850749 0 35.66920624758726 139.73927001900012 0 35.669148075195395 139.739399900889 0 35.66920913015616 139.73944092084668 0 35.66930274771769 139.73928042168953 0 35.66925167814013 139.73923712563703 0 35.66922982304895 139.7392758457763 0 35.66922582668437 139.7392831850749 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922582668437 139.7392831850749 11.74 35.66922982304895 139.7392758457763 11.74 35.66925167814013 139.73923712563703 11.74 35.66930274771769 139.73928042168953 11.74 35.66920913015616 139.73944092084668 11.74 35.669148075195395 139.739399900889 11.74 35.66920624758726 139.73927001900012 11.74 35.66922582668437 139.7392831850749 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922582668437 139.7392831850749 11.74 35.66920624758726 139.73927001900012 11.74 35.66920624758726 139.73927001900012 29.17 35.66922582668437 139.7392831850749 29.17 35.66922582668437 139.7392831850749 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920624758726 139.73927001900012 11.74 35.669148075195395 139.739399900889 11.74 35.669148075195395 139.739399900889 29.17 35.66920624758726 139.73927001900012 29.17 35.66920624758726 139.73927001900012 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669148075195395 139.739399900889 11.74 35.66920913015616 139.73944092084668 11.74 35.66920913015616 139.73944092084668 29.17 35.669148075195395 139.739399900889 29.17 35.669148075195395 139.739399900889 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920913015616 139.73944092084668 11.74 35.66930274771769 139.73928042168953 11.74 35.66930274771769 139.73928042168953 29.17 35.66920913015616 139.73944092084668 29.17 35.66920913015616 139.73944092084668 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66930274771769 139.73928042168953 11.74 35.66925167814013 139.73923712563703 11.74 35.66925167814013 139.73923712563703 29.17 35.66930274771769 139.73928042168953 29.17 35.66930274771769 139.73928042168953 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925167814013 139.73923712563703 11.74 35.66922982304895 139.7392758457763 11.74 35.66922982304895 139.7392758457763 29.17 35.66925167814013 139.73923712563703 29.17 35.66925167814013 139.73923712563703 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922982304895 139.7392758457763 11.74 35.66922582668437 139.7392831850749 11.74 35.66922582668437 139.7392831850749 29.17 35.66922982304895 139.7392758457763 29.17 35.66922982304895 139.7392758457763 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922582668437 139.7392831850749 29.17 35.66920624758726 139.73927001900012 29.17 35.669148075195395 139.739399900889 29.17 35.66920913015616 139.73944092084668 29.17 35.66930274771769 139.73928042168953 29.17 35.66925167814013 139.73923712563703 29.17 35.66922982304895 139.7392758457763 29.17 35.66922582668437 139.7392831850749 29.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-204c845e-a13d-430b-abfe-ef9403d86f9b"/>
							<gml:surfaceMember xlink:href="#poly-6f1962d9-c7e2-48fe-baac-7acb076b9d28"/>
							<gml:surfaceMember xlink:href="#poly-7173a733-5610-4998-aca9-0d5042f58779"/>
							<gml:surfaceMember xlink:href="#poly-5deb775a-5f9f-48ea-a948-f118ec769d40"/>
							<gml:surfaceMember xlink:href="#poly-76fcc805-1fe5-4441-8352-01b5d0ae356f"/>
							<gml:surfaceMember xlink:href="#poly-d77862e3-c6ed-46f9-b574-62a61ded02df"/>
							<gml:surfaceMember xlink:href="#poly-bcabe8e4-c565-410a-899e-1e041de781f4"/>
							<gml:surfaceMember xlink:href="#poly-34830661-11ea-4c33-8d1a-da69d8e7350c"/>
							<gml:surfaceMember xlink:href="#poly-d6ba3e50-d778-4697-a60e-2d365c95820f"/>
							<gml:surfaceMember xlink:href="#poly-9f0e74aa-d2fa-4c74-bd2e-22e5bd58affb"/>
							<gml:surfaceMember xlink:href="#poly-1fbbb3c2-eea8-4753-a207-fc96eab3d27c"/>
							<gml:surfaceMember xlink:href="#poly-ed4b9bfb-b2ee-40df-a9d9-e94f7200c23c"/>
							<gml:surfaceMember xlink:href="#poly-3c2ac4fd-9d81-4787-979b-7c839a335cfb"/>
							<gml:surfaceMember xlink:href="#poly-552178bf-b8db-446f-8baf-244a539b6932"/>
							<gml:surfaceMember xlink:href="#poly-f1a45fbb-1846-4893-bd44-79d037eb1441"/>
							<gml:surfaceMember xlink:href="#poly-10249ddd-1d85-4d56-8092-c25e24e31a43"/>
							<gml:surfaceMember xlink:href="#poly-9aeff573-0976-4f10-93e4-014361b3ebe5"/>
							<gml:surfaceMember xlink:href="#poly-09f0d37b-b2e4-4882-bee1-a44dbbaa0a6f"/>
							<gml:surfaceMember xlink:href="#poly-37073fef-b35a-4790-b89b-7b9cf7bc1c82"/>
							<gml:surfaceMember xlink:href="#poly-7702d939-dc68-4461-8a8e-c1c888b80979"/>
							<gml:surfaceMember xlink:href="#poly-001a7ca8-ac39-477f-a7b6-98e58ac2718e"/>
							<gml:surfaceMember xlink:href="#poly-a7e4e906-cd4a-4472-82b0-9b82c42e5767"/>
							<gml:surfaceMember xlink:href="#poly-83806e04-035d-421b-b634-658beaf35294"/>
							<gml:surfaceMember xlink:href="#poly-ba58aedc-3290-4c21-966d-2d9bd0807968"/>
							<gml:surfaceMember xlink:href="#poly-8f127931-bc0b-467a-bac7-6fe8f11daa76"/>
							<gml:surfaceMember xlink:href="#poly-1faa1a55-ea86-4066-a059-e6e238fa4115"/>
							<gml:surfaceMember xlink:href="#poly-63891f21-6205-46b1-ae9d-a0dc097b694d"/>
							<gml:surfaceMember xlink:href="#poly-dc636af1-b667-4d9d-b6e7-9e16bd28df14"/>
							<gml:surfaceMember xlink:href="#poly-0b6ef23d-9b59-4175-9c96-1a6cfbf825c7"/>
							<gml:surfaceMember xlink:href="#poly-13a8115a-cff4-441a-9301-ab909505a625"/>
							<gml:surfaceMember xlink:href="#poly-8f671608-acfa-449b-95d6-7e08e6695aca"/>
							<gml:surfaceMember xlink:href="#poly-80bb6797-fcf5-43f4-9c2a-f6da38824f07"/>
							<gml:surfaceMember xlink:href="#poly-034100ea-f73e-4af0-adf1-1a5c57d908a1"/>
							<gml:surfaceMember xlink:href="#poly-9807f224-3d8c-4b5b-8039-459042924ecc"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ccc5d161-3238-433a-aeab-410d860f6db9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54c63299-d4c2-4d22-8030-c4660f74e25c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924049783193 139.73926753763124 32.89 35.66924901303537 139.73925244971022 32.89 35.66925764489968 139.73925977419543 32.89 35.66924912969531 139.73927486211733 32.89 35.66924049783193 139.73926753763124 32.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53c8c99b-21a0-4a21-a8c4-47817ee8bfd9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919015511728 139.73932394282423 30.779 35.66919892097849 139.7393066343593 30.779 35.669217265812385 139.73932059720815 30.779 35.66920849994058 139.73933789462941 30.779 35.66919015511728 139.73932394282423 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f8199e9-b666-4578-ba2b-c2ea1625b4c1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669182953330335 139.73933572640468 30.779 35.66919322559263 139.73934292746287 30.779 35.669186707898554 139.7393534951698 30.779 35.669177788833586 139.73934775060903 30.779 35.669182953330335 139.73933572640468 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93ec31b2-735b-4332-836f-15f7f40830f3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669183005424905 139.73936782629391 30.779 35.669189021130215 139.73937237023523 30.779 35.66918367526079 139.73938299179665 30.779 35.66917765955587 139.73937844785485 30.779 35.669183005424905 139.73936782629391 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-841427fc-80c7-49f3-8593-244ff8c1e65c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669182379292565 139.73938556705517 30.779 35.66917772641019 139.7393948180873 30.779 35.6691716836473 139.73939025208446 30.779 35.669176336520714 139.73938099000665 30.779 35.669182379292565 139.73938556705517 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd9f9914-4236-4893-8eca-fd3ecfe543b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd9f9914-4236-4893-8eca-fd3ecfe543b1_0">
											<gml:posList>35.66917765955587 139.73937844785485 30.779 35.66918367526079 139.73938299179665 30.779 35.66918367526079 139.73938299179665 32.278 35.66917765955587 139.73937844785485 32.278 35.66917765955587 139.73937844785485 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f28b127a-c0e2-4275-91f3-9884c3f6e415">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f28b127a-c0e2-4275-91f3-9884c3f6e415_0">
											<gml:posList>35.669176336520714 139.73938099000665 30.779 35.6691716836473 139.73939025208446 30.779 35.6691716836473 139.73939025208446 32.278 35.669176336520714 139.73938099000665 32.278 35.669176336520714 139.73938099000665 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dff8d75b-c140-4e3e-b800-ad94524f5962">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dff8d75b-c140-4e3e-b800-ad94524f5962_0">
											<gml:posList>35.6691716836473 139.73939025208446 30.779 35.66917772641019 139.7393948180873 30.779 35.66917772641019 139.7393948180873 32.278 35.6691716836473 139.73939025208446 32.278 35.6691716836473 139.73939025208446 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5abb6ab5-e872-4b57-8ebb-22ad67fcbe2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5abb6ab5-e872-4b57-8ebb-22ad67fcbe2a_0">
											<gml:posList>35.6691716836473 139.73939025208446 32.278 35.66917772641019 139.7393948180873 32.278 35.669182379292565 139.73938556705517 32.278 35.669176336520714 139.73938099000665 32.278 35.6691716836473 139.73939025208446 32.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c641f558-caa3-457e-bead-041153cb3b00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c641f558-caa3-457e-bead-041153cb3b00_0">
											<gml:posList>35.669182379292565 139.73938556705517 30.779 35.669176336520714 139.73938099000665 30.779 35.669176336520714 139.73938099000665 32.278 35.669182379292565 139.73938556705517 32.278 35.669182379292565 139.73938556705517 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c369e65c-2dc9-47db-84c1-ef823df22aea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c369e65c-2dc9-47db-84c1-ef823df22aea_0">
											<gml:posList>35.66917772641019 139.7393948180873 30.779 35.669182379292565 139.73938556705517 30.779 35.669182379292565 139.73938556705517 32.278 35.66917772641019 139.7393948180873 32.278 35.66917772641019 139.7393948180873 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a901d9d-fcdf-4409-b1b0-b014f870e4e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a901d9d-fcdf-4409-b1b0-b014f870e4e6_0">
											<gml:posList>35.669183005424905 139.73936782629391 30.779 35.66917765955587 139.73937844785485 30.779 35.66917765955587 139.73937844785485 32.278 35.669183005424905 139.73936782629391 32.278 35.669183005424905 139.73936782629391 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abe410dc-bbaa-41c8-8347-e3e4f8d9643c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abe410dc-bbaa-41c8-8347-e3e4f8d9643c_0">
											<gml:posList>35.669182953330335 139.73933572640468 30.779 35.669177788833586 139.73934775060903 30.779 35.669177788833586 139.73934775060903 32.05 35.669182953330335 139.73933572640468 32.05 35.669182953330335 139.73933572640468 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-303f88ac-882b-47cf-b960-b4883f319332">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-303f88ac-882b-47cf-b960-b4883f319332_0">
											<gml:posList>35.669177788833586 139.73934775060903 30.779 35.669186707898554 139.7393534951698 30.779 35.669186707898554 139.7393534951698 32.05 35.669177788833586 139.73934775060903 32.05 35.669177788833586 139.73934775060903 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bb20379-400e-4097-a4cd-7d280b83de0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bb20379-400e-4097-a4cd-7d280b83de0b_0">
											<gml:posList>35.669183005424905 139.73936782629391 32.278 35.66917765955587 139.73937844785485 32.278 35.66918367526079 139.73938299179665 32.278 35.669189021130215 139.73937237023523 32.278 35.669183005424905 139.73936782629391 32.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16f24f88-2fdd-46dc-a0b4-20bdaa3e73ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16f24f88-2fdd-46dc-a0b4-20bdaa3e73ca_0">
											<gml:posList>35.669186707898554 139.7393534951698 32.05 35.66919322559263 139.73934292746287 32.05 35.669182953330335 139.73933572640468 32.05 35.669177788833586 139.73934775060903 32.05 35.669186707898554 139.7393534951698 32.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd0f4087-e911-46f5-8e7e-ec236fc93808">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd0f4087-e911-46f5-8e7e-ec236fc93808_0">
											<gml:posList>35.669189021130215 139.73937237023523 30.779 35.669183005424905 139.73936782629391 30.779 35.669183005424905 139.73936782629391 32.278 35.669189021130215 139.73937237023523 32.278 35.669189021130215 139.73937237023523 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d13c2711-34af-41dc-82ef-b8d8902f3618">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d13c2711-34af-41dc-82ef-b8d8902f3618_0">
											<gml:posList>35.66918367526079 139.73938299179665 30.779 35.669189021130215 139.73937237023523 30.779 35.669189021130215 139.73937237023523 32.278 35.66918367526079 139.73938299179665 32.278 35.66918367526079 139.73938299179665 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a4bf7b5-00c9-47d4-8788-9588f437e9ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a4bf7b5-00c9-47d4-8788-9588f437e9ae_0">
											<gml:posList>35.669182953330335 139.73933572640468 30.779 35.669182953330335 139.73933572640468 32.05 35.66919322559263 139.73934292746287 32.05 35.66919322559263 139.73934292746287 30.779 35.669182953330335 139.73933572640468 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6b26b05-b431-4870-b6ee-529ba0990123">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6b26b05-b431-4870-b6ee-529ba0990123_0">
											<gml:posList>35.669186707898554 139.7393534951698 30.779 35.66919322559263 139.73934292746287 30.779 35.66919322559263 139.73934292746287 32.05 35.669186707898554 139.7393534951698 32.05 35.669186707898554 139.7393534951698 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90c0a386-c498-4783-863c-d2a69a925cc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90c0a386-c498-4783-863c-d2a69a925cc1_0">
											<gml:posList>35.66919015511728 139.73932394282423 30.779 35.66919015511728 139.73932394282423 33.121 35.66919892097849 139.7393066343593 33.121 35.66919892097849 139.7393066343593 30.779 35.66919015511728 139.73932394282423 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76850ff8-a685-4ea3-94e1-e89a19d1e569">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76850ff8-a685-4ea3-94e1-e89a19d1e569_0">
											<gml:posList>35.66919015511728 139.73932394282423 30.779 35.66920849994058 139.73933789462941 30.779 35.66920849994058 139.73933789462941 33.121 35.66919015511728 139.73932394282423 33.121 35.66919015511728 139.73932394282423 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-830f1722-e040-4898-8e5d-18d76b214956">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-830f1722-e040-4898-8e5d-18d76b214956_0">
											<gml:posList>35.66919015511728 139.73932394282423 33.121 35.66920849994058 139.73933789462941 33.121 35.669217265812385 139.73932059720815 33.121 35.66919892097849 139.7393066343593 33.121 35.66919015511728 139.73932394282423 33.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcf42823-78c3-470b-8c0c-e28d1de9fad5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcf42823-78c3-470b-8c0c-e28d1de9fad5_0">
											<gml:posList>35.66919892097849 139.7393066343593 30.779 35.66919892097849 139.7393066343593 33.121 35.669217265812385 139.73932059720815 33.121 35.669217265812385 139.73932059720815 30.779 35.66919892097849 139.7393066343593 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9678af1-b2a0-4afd-8367-1792448d4a41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9678af1-b2a0-4afd-8367-1792448d4a41_0">
											<gml:posList>35.66920849994058 139.73933789462941 30.779 35.669217265812385 139.73932059720815 30.779 35.669217265812385 139.73932059720815 33.121 35.66920849994058 139.73933789462941 33.121 35.66920849994058 139.73933789462941 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43982afd-d677-47d5-b264-a362db29c504">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43982afd-d677-47d5-b264-a362db29c504_0">
											<gml:posList>35.66924901303537 139.73925244971022 32.89 35.66924049783193 139.73926753763124 32.89 35.66924049783193 139.73926753763124 35.085 35.66924901303537 139.73925244971022 35.085 35.66924901303537 139.73925244971022 32.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba663401-f29a-428e-a6b4-27cae6f70060">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba663401-f29a-428e-a6b4-27cae6f70060_0">
											<gml:posList>35.66924912969531 139.73927486211733 32.89 35.66924912969531 139.73927486211733 35.085 35.66924049783193 139.73926753763124 35.085 35.66924049783193 139.73926753763124 32.89 35.66924912969531 139.73927486211733 32.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5330d45a-b5d1-475e-aa13-dc034e5d78e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5330d45a-b5d1-475e-aa13-dc034e5d78e3_0">
											<gml:posList>35.66924049783193 139.73926753763124 35.085 35.66924912969531 139.73927486211733 35.085 35.66925764489968 139.73925977419543 35.085 35.66924901303537 139.73925244971022 35.085 35.66924049783193 139.73926753763124 35.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f658814b-7502-4211-bf3a-6b9666e7f9bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f658814b-7502-4211-bf3a-6b9666e7f9bb_0">
											<gml:posList>35.66925764489968 139.73925977419543 32.89 35.66924901303537 139.73925244971022 32.89 35.66924901303537 139.73925244971022 35.085 35.66925764489968 139.73925977419543 35.085 35.66925764489968 139.73925977419543 32.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27b0e9b8-7a45-4b11-97bb-ca3fe914df48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27b0e9b8-7a45-4b11-97bb-ca3fe914df48_0">
											<gml:posList>35.66924912969531 139.73927486211733 32.89 35.66925764489968 139.73925977419543 32.89 35.66925764489968 139.73925977419543 35.085 35.66924912969531 139.73927486211733 35.085 35.66924912969531 139.73927486211733 32.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ccc5d161-3238-433a-aeab-410d860f6db9_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12e688dc-6add-4836-9be3-2e8e5942ceb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12e688dc-6add-4836-9be3-2e8e5942ceb6_0">
											<gml:posList>35.6692360018856 139.73922383348136 29.794 35.6692516781401 139.73923712563703 11.74 35.6692360018856 139.73922383348136 11.74 35.6692360018856 139.73922383348136 29.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53fdd36e-c6da-4ed6-8815-16f3ef9f163c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53fdd36e-c6da-4ed6-8815-16f3ef9f163c_0">
											<gml:posList>35.6692360018856 139.73922383348136 29.794 35.6692516781401 139.73923712563703 29.794 35.6692516781401 139.73923712563703 11.74 35.6692360018856 139.73922383348136 29.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cbadd8c-3749-4974-8d49-082359d0a9d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cbadd8c-3749-4974-8d49-082359d0a9d3_0">
											<gml:posList>35.66921247421992 139.73925610465747 11.74 35.66921247421992 139.73925610465747 31.583 35.6692360018856 139.73922383348136 29.794 35.66921247421992 139.73925610465747 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d4c121a-028c-4471-b602-7cbf4e1e227f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d4c121a-028c-4471-b602-7cbf4e1e227f_0">
											<gml:posList>35.6692360018856 139.73922383348136 11.74 35.66921247421992 139.73925610465747 11.74 35.6692360018856 139.73922383348136 29.794 35.6692360018856 139.73922383348136 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f2aeb92-5082-4d94-99e8-b7102bed0b64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f2aeb92-5082-4d94-99e8-b7102bed0b64_0">
											<gml:posList>35.6692516781401 139.73923712563703 29.794 35.6692360018856 139.73922383348136 29.794 35.66921247421992 139.73925610465747 31.583 35.6692516781401 139.73923712563703 29.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b31ce71d-2f7c-4569-af5e-fa6bded9386e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b31ce71d-2f7c-4569-af5e-fa6bded9386e_0">
											<gml:posList>35.66922982304895 139.7392758457763 31.583 35.6692516781401 139.73923712563703 29.794 35.66921247421992 139.73925610465747 31.583 35.66922982304895 139.7392758457763 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea783bec-c2e0-485f-94c6-5205930a8145">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea783bec-c2e0-485f-94c6-5205930a8145_0">
											<gml:posList>35.66922982304895 139.7392758457763 11.74 35.6692516781401 139.73923712563703 11.74 35.6692516781401 139.73923712563703 29.794 35.66922982304895 139.7392758457763 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35482746-b27c-436c-a032-399d38c12ccd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35482746-b27c-436c-a032-399d38c12ccd_0">
											<gml:posList>35.66922982304895 139.7392758457763 31.583 35.66922982304895 139.7392758457763 11.74 35.6692516781401 139.73923712563703 29.794 35.66922982304895 139.7392758457763 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bf8e071-5f08-4b78-a4fc-f241c1cd5632">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0bf8e071-5f08-4b78-a4fc-f241c1cd5632_0">
											<gml:posList>35.66920624758723 139.73927001900012 11.74 35.66921247421992 139.73925610465747 31.583 35.66921247421992 139.73925610465747 11.74 35.66920624758723 139.73927001900012 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-847e9064-7f37-44c0-9ded-ba4da1ff6246">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-847e9064-7f37-44c0-9ded-ba4da1ff6246_0">
											<gml:posList>35.66920624758723 139.73927001900012 11.74 35.66920624758723 139.73927001900012 31.583 35.66921247421992 139.73925610465747 31.583 35.66920624758723 139.73927001900012 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f481304-6cb3-4a47-8b20-ee1c070ac542">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f481304-6cb3-4a47-8b20-ee1c070ac542_0">
											<gml:posList>35.66922982304895 139.7392758457763 31.583 35.66921247421992 139.73925610465747 31.583 35.66920624758723 139.73927001900012 31.583 35.66922982304895 139.7392758457763 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc8bf331-1332-4bc0-864f-a370e265cd1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc8bf331-1332-4bc0-864f-a370e265cd1a_0">
											<gml:posList>35.66922582668437 139.73928318507487 31.583 35.66922982304895 139.7392758457763 31.583 35.66920624758723 139.73927001900012 31.583 35.66922582668437 139.73928318507487 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43abd230-2702-48df-b206-e4e3a55daa2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43abd230-2702-48df-b206-e4e3a55daa2e_0">
											<gml:posList>35.66920624758723 139.73927001900012 11.74 35.66922582668437 139.73928318507487 31.583 35.66920624758723 139.73927001900012 31.583 35.66920624758723 139.73927001900012 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7881e18-ebff-4ff4-8a38-5e723cf8086b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7881e18-ebff-4ff4-8a38-5e723cf8086b_0">
											<gml:posList>35.66920624758723 139.73927001900012 11.74 35.66922582668437 139.73928318507487 11.74 35.66922582668437 139.73928318507487 31.583 35.66920624758723 139.73927001900012 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-964e2831-3c5b-4e75-82ed-9e25d6b10df2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-964e2831-3c5b-4e75-82ed-9e25d6b10df2_0">
											<gml:posList>35.66922582668437 139.73928318507487 31.583 35.66922982304895 139.7392758457763 11.74 35.66922982304895 139.7392758457763 31.583 35.66922582668437 139.73928318507487 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eb42fa3-b360-49e6-af2f-8801195d6e69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eb42fa3-b360-49e6-af2f-8801195d6e69_0">
											<gml:posList>35.66922582668437 139.73928318507487 31.583 35.66922582668437 139.73928318507487 11.74 35.66922982304895 139.7392758457763 11.74 35.66922582668437 139.73928318507487 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdfe6064-d878-45f0-a2fb-55d0db236a27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922582668437 139.73928318507487 11.74 35.66920624758723 139.73927001900012 11.74 35.66922982304895 139.7392758457763 11.74 35.66922582668437 139.73928318507487 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48eeec5a-2c61-4fc7-8a81-1d6b03218476">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920624758723 139.73927001900012 11.74 35.66921247421992 139.73925610465747 11.74 35.66922982304895 139.7392758457763 11.74 35.66920624758723 139.73927001900012 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a61f861-26dd-41c0-ab60-b2e431920d85">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922982304895 139.7392758457763 11.74 35.66921247421992 139.73925610465747 11.74 35.6692516781401 139.73923712563703 11.74 35.66922982304895 139.7392758457763 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1278c05d-cb09-4ead-b5b8-a7b27fb47747">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66921247421992 139.73925610465747 11.74 35.6692360018856 139.73922383348136 11.74 35.6692516781401 139.73923712563703 11.74 35.66921247421992 139.73925610465747 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-204c845e-a13d-430b-abfe-ef9403d86f9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-204c845e-a13d-430b-abfe-ef9403d86f9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-204c845e-a13d-430b-abfe-ef9403d86f9b">
											<gml:posList>35.66914807519541 139.739399900889 11.74 35.66920624758723 139.73927001900012 11.74 35.66922582668437 139.73928318507487 11.74 35.66922982304895 139.7392758457763 11.74 35.6692516781401 139.73923712563703 11.74 35.66930274771765 139.73928042168953 11.74 35.66920913015614 139.73944092084668 11.74 35.66914807519541 139.739399900889 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f1962d9-c7e2-48fe-baac-7acb076b9d28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f1962d9-c7e2-48fe-baac-7acb076b9d28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f1962d9-c7e2-48fe-baac-7acb076b9d28">
											<gml:posList>35.6692516781401 139.73923712563703 34.056 35.66925222178609 139.73924073707502 34.056 35.669271713372595 139.73925726126924 34.056 35.66927466035119 139.73925660609126 34.056 35.6692516781401 139.73923712563703 34.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7173a733-5610-4998-aca9-0d5042f58779">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7173a733-5610-4998-aca9-0d5042f58779">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7173a733-5610-4998-aca9-0d5042f58779">
											<gml:posList>35.66922982304895 139.7392758457763 34.056 35.669232770019036 139.73927517955323 34.056 35.66925222178609 139.73924073707502 34.056 35.6692516781401 139.73923712563703 34.056 35.66922982304895 139.7392758457763 34.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5deb775a-5f9f-48ea-a948-f118ec769d40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5deb775a-5f9f-48ea-a948-f118ec769d40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5deb775a-5f9f-48ea-a948-f118ec769d40">
											<gml:posList>35.669271713372595 139.73925726126924 32.89 35.66925222178609 139.73924073707502 32.89 35.669232770019036 139.73927517955323 32.89 35.6692522706146 139.73929170374126 32.89 35.669271713372595 139.73925726126924 32.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-76fcc805-1fe5-4441-8352-01b5d0ae356f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76fcc805-1fe5-4441-8352-01b5d0ae356f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76fcc805-1fe5-4441-8352-01b5d0ae356f">
											<gml:posList>35.66927466035119 139.73925660609126 34.056 35.669271713372595 139.73925726126924 34.056 35.6692522706146 139.73929170374126 34.056 35.669252805253855 139.73929532623634 34.056 35.66927466035119 139.73925660609126 34.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d77862e3-c6ed-46f9-b574-62a61ded02df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d77862e3-c6ed-46f9-b574-62a61ded02df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d77862e3-c6ed-46f9-b574-62a61ded02df">
											<gml:posList>35.66930274771765 139.73928042168953 26.156 35.66927466035119 139.73925660609126 30.613 35.66925284131738 139.73929533724015 30.608 35.66930274771765 139.73928042168953 26.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bcabe8e4-c565-410a-899e-1e041de781f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcabe8e4-c565-410a-899e-1e041de781f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcabe8e4-c565-410a-899e-1e041de781f4">
											<gml:posList>35.66922582668437 139.73928318507487 31.653 35.66920624758723 139.73927001900012 31.653 35.66920683542938 139.73927251472855 31.653 35.66922631532351 139.7392856146438 31.653 35.66922582668437 139.73928318507487 31.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-34830661-11ea-4c33-8d1a-da69d8e7350c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34830661-11ea-4c33-8d1a-da69d8e7350c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34830661-11ea-4c33-8d1a-da69d8e7350c">
											<gml:posList>35.66923107679354 139.73927691577737 31.653 35.66922982304895 139.7392758457763 31.653 35.66922582668437 139.73928318507487 31.653 35.66922631532351 139.7392856146438 31.653 35.66923107679354 139.73927691577737 31.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d6ba3e50-d778-4697-a60e-2d365c95820f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6ba3e50-d778-4697-a60e-2d365c95820f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6ba3e50-d778-4697-a60e-2d365c95820f">
											<gml:posList>35.669252805253855 139.73929532623634 34.056 35.6692522706146 139.73929170374126 34.056 35.669232770019036 139.73927517955323 34.056 35.66922982304895 139.7392758457763 34.056 35.669252805253855 139.73929532623634 34.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f0e74aa-d2fa-4c74-bd2e-22e5bd58affb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f0e74aa-d2fa-4c74-bd2e-22e5bd58affb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f0e74aa-d2fa-4c74-bd2e-22e5bd58affb">
											<gml:posList>35.66914807519541 139.739399900889 31.653 35.66915012073349 139.7393991584046 31.653 35.66920683542938 139.73927251472855 31.653 35.66920624758723 139.73927001900012 31.653 35.66914807519541 139.739399900889 31.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1fbbb3c2-eea8-4753-a207-fc96eab3d27c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fbbb3c2-eea8-4753-a207-fc96eab3d27c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fbbb3c2-eea8-4753-a207-fc96eab3d27c">
											<gml:posList>35.66915012073349 139.7393991584046 30.779 35.66917499364706 139.73941587514278 30.779 35.6692452196825 139.73928889525484 30.779 35.66923107679354 139.73927691577737 30.779 35.66922631532351 139.7392856146438 30.779 35.66920683542938 139.73927251472855 30.779 35.66915012073349 139.7393991584046 30.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed4b9bfb-b2ee-40df-a9d9-e94f7200c23c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed4b9bfb-b2ee-40df-a9d9-e94f7200c23c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed4b9bfb-b2ee-40df-a9d9-e94f7200c23c">
											<gml:posList>35.66930274771765 139.73928042168953 26.156 35.66925284131738 139.73929533724015 30.608 35.66917546425608 139.73941830473208 31.653 35.66930274771765 139.73928042168953 26.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c2ac4fd-9d81-4787-979b-7c839a335cfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c2ac4fd-9d81-4787-979b-7c839a335cfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c2ac4fd-9d81-4787-979b-7c839a335cfb">
											<gml:posList>35.66917499364706 139.73941587514278 31.653 35.66917546425608 139.73941830473208 31.653 35.66924645538227 139.73928994318527 31.653 35.6692452196825 139.73928889525484 31.653 35.66917499364706 139.73941587514278 31.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-552178bf-b8db-446f-8baf-244a539b6932">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-552178bf-b8db-446f-8baf-244a539b6932">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-552178bf-b8db-446f-8baf-244a539b6932">
											<gml:posList>35.66925284131738 139.73929533724015 30.608 35.66924645538227 139.73928994318527 31.653 35.66917546425608 139.73941830473208 31.653 35.66925284131738 139.73929533724015 30.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1a45fbb-1846-4893-bd44-79d037eb1441">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1a45fbb-1846-4893-bd44-79d037eb1441">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1a45fbb-1846-4893-bd44-79d037eb1441">
											<gml:posList>35.66930274771765 139.73928042168953 26.156 35.66917546425608 139.73941830473208 31.653 35.66920913015614 139.73944092084668 26.156 35.66930274771765 139.73928042168953 26.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-10249ddd-1d85-4d56-8092-c25e24e31a43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10249ddd-1d85-4d56-8092-c25e24e31a43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10249ddd-1d85-4d56-8092-c25e24e31a43">
											<gml:posList>35.66917546425608 139.73941830473208 31.653 35.66917499364706 139.73941587514278 31.653 35.66915012073349 139.7393991584046 31.653 35.66914807519541 139.739399900889 31.653 35.66917546425608 139.73941830473208 31.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9aeff573-0976-4f10-93e4-014361b3ebe5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9aeff573-0976-4f10-93e4-014361b3ebe5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9aeff573-0976-4f10-93e4-014361b3ebe5">
											<gml:posList>35.669232770019036 139.73927517955323 34.056 35.669232770019036 139.73927517955323 32.89 35.66925222178609 139.73924073707502 32.89 35.66925222178609 139.73924073707502 34.056 35.669232770019036 139.73927517955323 34.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09f0d37b-b2e4-4882-bee1-a44dbbaa0a6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09f0d37b-b2e4-4882-bee1-a44dbbaa0a6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09f0d37b-b2e4-4882-bee1-a44dbbaa0a6f">
											<gml:posList>35.669271713372595 139.73925726126924 34.056 35.669271713372595 139.73925726126924 32.89 35.6692522706146 139.73929170374126 32.89 35.6692522706146 139.73929170374126 34.056 35.669271713372595 139.73925726126924 34.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37073fef-b35a-4790-b89b-7b9cf7bc1c82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37073fef-b35a-4790-b89b-7b9cf7bc1c82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37073fef-b35a-4790-b89b-7b9cf7bc1c82">
											<gml:posList>35.6692522706146 139.73929170374126 34.056 35.6692522706146 139.73929170374126 32.89 35.669232770019036 139.73927517955323 32.89 35.669232770019036 139.73927517955323 34.056 35.6692522706146 139.73929170374126 34.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7702d939-dc68-4461-8a8e-c1c888b80979">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7702d939-dc68-4461-8a8e-c1c888b80979">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7702d939-dc68-4461-8a8e-c1c888b80979">
											<gml:posList>35.66925222178609 139.73924073707502 34.056 35.66925222178609 139.73924073707502 32.89 35.669271713372595 139.73925726126924 32.89 35.669271713372595 139.73925726126924 34.056 35.66925222178609 139.73924073707502 34.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-001a7ca8-ac39-477f-a7b6-98e58ac2718e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-001a7ca8-ac39-477f-a7b6-98e58ac2718e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-001a7ca8-ac39-477f-a7b6-98e58ac2718e">
											<gml:posList>35.6692516781401 139.73923712563703 34.056 35.6692516781401 139.73923712563703 11.74 35.66922982304895 139.7392758457763 11.74 35.66922982304895 139.7392758457763 31.653 35.66922982304895 139.7392758457763 34.056 35.6692516781401 139.73923712563703 34.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7e4e906-cd4a-4472-82b0-9b82c42e5767">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7e4e906-cd4a-4472-82b0-9b82c42e5767">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7e4e906-cd4a-4472-82b0-9b82c42e5767">
											<gml:posList>35.6692516781401 139.73923712563703 11.74 35.6692516781401 139.73923712563703 34.056 35.66927466035119 139.73925660609126 34.056 35.66927466035119 139.73925660609126 30.613 35.66930274771765 139.73928042168953 26.156 35.66930274771765 139.73928042168953 11.74 35.6692516781401 139.73923712563703 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83806e04-035d-421b-b634-658beaf35294">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83806e04-035d-421b-b634-658beaf35294">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83806e04-035d-421b-b634-658beaf35294">
											<gml:posList>35.66927466035119 139.73925660609126 34.056 35.669252805253855 139.73929532623634 34.056 35.66925284131738 139.73929533724015 30.608 35.66927466035119 139.73925660609126 30.613 35.66927466035119 139.73925660609126 34.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba58aedc-3290-4c21-966d-2d9bd0807968">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba58aedc-3290-4c21-966d-2d9bd0807968">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba58aedc-3290-4c21-966d-2d9bd0807968">
											<gml:posList>35.66922582668437 139.73928318507487 11.74 35.66920624758723 139.73927001900012 11.74 35.66920624758723 139.73927001900012 31.653 35.66922582668437 139.73928318507487 31.653 35.66922582668437 139.73928318507487 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f127931-bc0b-467a-bac7-6fe8f11daa76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f127931-bc0b-467a-bac7-6fe8f11daa76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f127931-bc0b-467a-bac7-6fe8f11daa76">
											<gml:posList>35.66920683542938 139.73927251472855 31.653 35.66920683542938 139.73927251472855 30.779 35.66922631532351 139.7392856146438 30.779 35.66922631532351 139.7392856146438 31.653 35.66920683542938 139.73927251472855 31.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1faa1a55-ea86-4066-a059-e6e238fa4115">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1faa1a55-ea86-4066-a059-e6e238fa4115">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1faa1a55-ea86-4066-a059-e6e238fa4115">
											<gml:posList>35.66922982304895 139.7392758457763 11.74 35.66922582668437 139.73928318507487 11.74 35.66922582668437 139.73928318507487 31.653 35.66922982304895 139.7392758457763 31.653 35.66922982304895 139.7392758457763 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63891f21-6205-46b1-ae9d-a0dc097b694d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63891f21-6205-46b1-ae9d-a0dc097b694d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63891f21-6205-46b1-ae9d-a0dc097b694d">
											<gml:posList>35.66922631532351 139.7392856146438 31.653 35.66922631532351 139.7392856146438 30.779 35.66923107679354 139.73927691577737 30.779 35.66923107679354 139.73927691577737 31.653 35.66922631532351 139.7392856146438 31.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc636af1-b667-4d9d-b6e7-9e16bd28df14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc636af1-b667-4d9d-b6e7-9e16bd28df14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc636af1-b667-4d9d-b6e7-9e16bd28df14">
											<gml:posList>35.66923107679354 139.73927691577737 31.653 35.66923107679354 139.73927691577737 30.779 35.6692452196825 139.73928889525484 30.779 35.6692452196825 139.73928889525484 31.653 35.66924645538227 139.73928994318527 31.653 35.66925284131738 139.73929533724015 30.608 35.669252805253855 139.73929532623634 34.056 35.66922982304895 139.7392758457763 34.056 35.66922982304895 139.7392758457763 31.653 35.66923107679354 139.73927691577737 31.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b6ef23d-9b59-4175-9c96-1a6cfbf825c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b6ef23d-9b59-4175-9c96-1a6cfbf825c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b6ef23d-9b59-4175-9c96-1a6cfbf825c7">
											<gml:posList>35.66920624758723 139.73927001900012 11.74 35.66914807519541 139.739399900889 11.74 35.66914807519541 139.739399900889 31.653 35.66920624758723 139.73927001900012 31.653 35.66920624758723 139.73927001900012 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13a8115a-cff4-441a-9301-ab909505a625">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13a8115a-cff4-441a-9301-ab909505a625">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13a8115a-cff4-441a-9301-ab909505a625">
											<gml:posList>35.66915012073349 139.7393991584046 31.653 35.66915012073349 139.7393991584046 30.779 35.66920683542938 139.73927251472855 30.779 35.66920683542938 139.73927251472855 31.653 35.66915012073349 139.7393991584046 31.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f671608-acfa-449b-95d6-7e08e6695aca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f671608-acfa-449b-95d6-7e08e6695aca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f671608-acfa-449b-95d6-7e08e6695aca">
											<gml:posList>35.6692452196825 139.73928889525484 31.653 35.6692452196825 139.73928889525484 30.779 35.66917499364706 139.73941587514278 30.779 35.66917499364706 139.73941587514278 31.653 35.6692452196825 139.73928889525484 31.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80bb6797-fcf5-43f4-9c2a-f6da38824f07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80bb6797-fcf5-43f4-9c2a-f6da38824f07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80bb6797-fcf5-43f4-9c2a-f6da38824f07">
											<gml:posList>35.66920913015614 139.73944092084668 11.74 35.66930274771765 139.73928042168953 11.74 35.66930274771765 139.73928042168953 26.156 35.66920913015614 139.73944092084668 26.156 35.66920913015614 139.73944092084668 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-034100ea-f73e-4af0-adf1-1a5c57d908a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-034100ea-f73e-4af0-adf1-1a5c57d908a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-034100ea-f73e-4af0-adf1-1a5c57d908a1">
											<gml:posList>35.66917499364706 139.73941587514278 31.653 35.66917499364706 139.73941587514278 30.779 35.66915012073349 139.7393991584046 30.779 35.66915012073349 139.7393991584046 31.653 35.66917499364706 139.73941587514278 31.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9807f224-3d8c-4b5b-8039-459042924ecc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9807f224-3d8c-4b5b-8039-459042924ecc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9807f224-3d8c-4b5b-8039-459042924ecc">
											<gml:posList>35.66920913015614 139.73944092084668 26.156 35.66917546425608 139.73941830473208 31.653 35.66914807519541 139.739399900889 31.653 35.66914807519541 139.739399900889 11.74 35.66920913015614 139.73944092084668 11.74 35.66920913015614 139.73944092084668 26.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4129</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">159.11525</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>