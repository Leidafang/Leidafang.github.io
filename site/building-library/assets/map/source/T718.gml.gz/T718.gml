<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ce0d74c6-1b28-4e73-b3f1-bc752c054de9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">17.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67410656807995 139.73818888832642 0 35.674054241928715 139.73801606854985 0 35.67399477273348 139.73804309334562 0 35.67404709884622 139.7382159130118 0 35.67410656807995 139.73818888832642 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67410656807995 139.73818888832642 8.396 35.67404709884622 139.7382159130118 8.396 35.67399477273348 139.73804309334562 8.396 35.674054241928715 139.73801606854985 8.396 35.67410656807995 139.73818888832642 8.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67410656807995 139.73818888832642 8.396 35.674054241928715 139.73801606854985 8.396 35.674054241928715 139.73801606854985 26.03 35.67410656807995 139.73818888832642 26.03 35.67410656807995 139.73818888832642 8.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674054241928715 139.73801606854985 8.396 35.67399477273348 139.73804309334562 8.396 35.67399477273348 139.73804309334562 26.03 35.674054241928715 139.73801606854985 26.03 35.674054241928715 139.73801606854985 8.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67399477273348 139.73804309334562 8.396 35.67404709884622 139.7382159130118 8.396 35.67404709884622 139.7382159130118 26.03 35.67399477273348 139.73804309334562 26.03 35.67399477273348 139.73804309334562 8.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67404709884622 139.7382159130118 8.396 35.67410656807995 139.73818888832642 8.396 35.67410656807995 139.73818888832642 26.03 35.67404709884622 139.7382159130118 26.03 35.67404709884622 139.7382159130118 8.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67410656807995 139.73818888832642 26.03 35.674054241928715 139.73801606854985 26.03 35.67399477273348 139.73804309334562 26.03 35.67404709884622 139.7382159130118 26.03 35.67410656807995 139.73818888832642 26.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-91cf54f9-b1e6-438e-8dc7-d46da10e6f26"/>
							<gml:surfaceMember xlink:href="#poly-65a1b73d-2e45-4374-9a74-3dae6c8d7dce"/>
							<gml:surfaceMember xlink:href="#poly-da226edb-b01d-42c0-baa4-5fec21851ee2"/>
							<gml:surfaceMember xlink:href="#poly-fe0574ab-3485-44ef-a177-0b2545598a50"/>
							<gml:surfaceMember xlink:href="#poly-04a026d4-ba60-43c6-8908-1c899b8605b5"/>
							<gml:surfaceMember xlink:href="#poly-04175e78-4ac3-453e-91bc-47d716c9271b"/>
							<gml:surfaceMember xlink:href="#poly-392d2951-85f2-46c9-b7ac-1e0f6705ab81"/>
							<gml:surfaceMember xlink:href="#poly-aaa2bcc8-008e-4c26-be03-67987afce7dd"/>
							<gml:surfaceMember xlink:href="#poly-72ad6c6b-016a-4273-b97a-8a5433f7d315"/>
							<gml:surfaceMember xlink:href="#poly-aefbcf47-97cc-4875-83a0-1f7d288d2ee0"/>
							<gml:surfaceMember xlink:href="#poly-d441494e-5f23-49f2-97af-b3aba6e46701"/>
							<gml:surfaceMember xlink:href="#poly-7d6a7ef5-bfb0-42e5-967f-6609481d096c"/>
							<gml:surfaceMember xlink:href="#poly-cdadfa31-4eea-431e-a88a-5336c7685174"/>
							<gml:surfaceMember xlink:href="#poly-b671cf9c-e580-4918-b809-5a08a1eed05f"/>
							<gml:surfaceMember xlink:href="#poly-9fb62649-799f-4bf2-bb4f-502135c4ded2"/>
							<gml:surfaceMember xlink:href="#poly-0a90591f-5fe5-4543-9857-b17003abd00a"/>
							<gml:surfaceMember xlink:href="#poly-1ce409aa-e778-4e39-8812-caea6acbbb2a"/>
							<gml:surfaceMember xlink:href="#poly-74e63cc0-f86d-4bb1-bba2-6867292617cd"/>
							<gml:surfaceMember xlink:href="#poly-66e5501c-c6e0-4b74-9874-9e1cf1ebb0b7"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ce0d74c6-1b28-4e73-b3f1-bc752c054de9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5414835b-0a78-43a2-8387-ce31076c94ac">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67402624874302 139.73813435741607 29.255 35.67402998114572 139.7381466701235 29.255 35.6740269896572 139.73814802138043 29.255 35.6740232572459 139.7381356976266 29.255 35.67402624874302 139.73813435741607 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b328e6c-9712-43b3-8f4d-bb45409f28b6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67404120618468 139.7381276011281 28.343 35.674044929574364 139.73813991384822 28.343 35.67402998114572 139.7381466701235 28.343 35.67402624874302 139.73813435741607 28.343 35.67404120618468 139.7381276011281 28.343</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9ad370a-f32c-4cfb-b089-7feb2b462a6b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67405661142092 139.7381399883508 28.343 35.67405032170682 139.73811954825769 28.343 35.67406689188652 139.7381118842144 28.343 35.67407318161064 139.7381323353579 28.343 35.67405661142092 139.7381399883508 28.343</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10fd000f-f20e-4865-8352-645fd002b062">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10fd000f-f20e-4865-8352-645fd002b062_0">
											<gml:posList>35.6740232572459 139.7381356976266 30.632 35.6740232572459 139.7381356976266 29.255 35.6740269896572 139.73814802138043 29.255 35.6740269896572 139.73814802138043 30.632 35.6740232572459 139.7381356976266 30.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d9257a3-767c-475a-867f-7af5bad3f0b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d9257a3-767c-475a-867f-7af5bad3f0b7_0">
											<gml:posList>35.67402624874302 139.73813435741607 28.343 35.67402998114572 139.7381466701235 28.343 35.67402998114572 139.7381466701235 29.255 35.67402624874302 139.73813435741607 29.255 35.67402624874302 139.73813435741607 28.343</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc489f0c-d05e-4234-9dac-df4cb09a0afa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc489f0c-d05e-4234-9dac-df4cb09a0afa_0">
											<gml:posList>35.67402624874302 139.73813435741607 29.255 35.6740232572459 139.7381356976266 29.255 35.6740232572459 139.7381356976266 30.632 35.67404120618468 139.7381276011281 30.632 35.67404120618468 139.7381276011281 28.343 35.67402624874302 139.73813435741607 28.343 35.67402624874302 139.73813435741607 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef86c581-5225-4d88-8fe1-456a0f8d9058">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef86c581-5225-4d88-8fe1-456a0f8d9058_0">
											<gml:posList>35.6740269896572 139.73814802138043 30.632 35.674044929574364 139.73813991384822 30.632 35.67404120618468 139.7381276011281 30.632 35.6740232572459 139.7381356976266 30.632 35.6740269896572 139.73814802138043 30.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67f3fe8c-3f31-4985-9d3c-9c026b3cc1b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67f3fe8c-3f31-4985-9d3c-9c026b3cc1b7_0">
											<gml:posList>35.6740269896572 139.73814802138043 30.632 35.6740269896572 139.73814802138043 29.255 35.67402998114572 139.7381466701235 29.255 35.67402998114572 139.7381466701235 28.343 35.674044929574364 139.73813991384822 28.343 35.674044929574364 139.73813991384822 30.632 35.6740269896572 139.73814802138043 30.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11ae14ad-3eae-4059-8f72-7e826072af6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11ae14ad-3eae-4059-8f72-7e826072af6f_0">
											<gml:posList>35.67404120618468 139.7381276011281 30.632 35.674044929574364 139.73813991384822 30.632 35.674044929574364 139.73813991384822 28.343 35.67404120618468 139.7381276011281 28.343 35.67404120618468 139.7381276011281 30.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dfdc1fc-6e34-4ea2-a3b0-eae8e9270c61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dfdc1fc-6e34-4ea2-a3b0-eae8e9270c61_0">
											<gml:posList>35.67405661142092 139.7381399883508 30.632 35.67405032170682 139.73811954825769 30.632 35.67405032170682 139.73811954825769 28.343 35.67405661142092 139.7381399883508 28.343 35.67405661142092 139.7381399883508 30.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c761a400-41cb-4512-aefa-ecb40ae1e7c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c761a400-41cb-4512-aefa-ecb40ae1e7c1_0">
											<gml:posList>35.67406689188652 139.7381118842144 30.632 35.67406689188652 139.7381118842144 28.343 35.67405032170682 139.73811954825769 28.343 35.67405032170682 139.73811954825769 30.632 35.67406689188652 139.7381118842144 30.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-041c0b0a-9a40-48a2-a390-0a3b24c6fc93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-041c0b0a-9a40-48a2-a390-0a3b24c6fc93_0">
											<gml:posList>35.67406689188652 139.7381118842144 30.632 35.67405032170682 139.73811954825769 30.632 35.67405661142092 139.7381399883508 30.632 35.67407318161064 139.7381323353579 30.632 35.67406689188652 139.7381118842144 30.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c25acfbd-87d4-491a-8061-7a294bb3d16c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c25acfbd-87d4-491a-8061-7a294bb3d16c_0">
											<gml:posList>35.67407318161064 139.7381323353579 30.632 35.67405661142092 139.7381399883508 30.632 35.67405661142092 139.7381399883508 28.343 35.67407318161064 139.7381323353579 28.343 35.67407318161064 139.7381323353579 30.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93417a3b-7b2e-4fe0-aea1-d95a6758b261">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93417a3b-7b2e-4fe0-aea1-d95a6758b261_0">
											<gml:posList>35.67406689188652 139.7381118842144 30.632 35.67407318161064 139.7381323353579 30.632 35.67407318161064 139.7381323353579 28.343 35.67406689188652 139.7381118842144 28.343 35.67406689188652 139.7381118842144 30.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-91cf54f9-b1e6-438e-8dc7-d46da10e6f26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91cf54f9-b1e6-438e-8dc7-d46da10e6f26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91cf54f9-b1e6-438e-8dc7-d46da10e6f26">
											<gml:posList>35.67410656807992 139.73818888832642 8.396 35.67404709884625 139.7382159130118 8.396 35.67399477273348 139.73804309334562 8.396 35.674054241928715 139.73801606854983 8.396 35.67410656807992 139.73818888832642 8.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65a1b73d-2e45-4374-9a74-3dae6c8d7dce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65a1b73d-2e45-4374-9a74-3dae6c8d7dce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65a1b73d-2e45-4374-9a74-3dae6c8d7dce">
											<gml:posList>35.67401137433288 139.7380979318199 29.255 35.674054241928715 139.73801606854983 21.999 35.67399477273348 139.73804309334562 21.999 35.67401137433288 139.7380979318199 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da226edb-b01d-42c0-baa4-5fec21851ee2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da226edb-b01d-42c0-baa4-5fec21851ee2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da226edb-b01d-42c0-baa4-5fec21851ee2">
											<gml:posList>35.67401137433288 139.7380979318199 29.255 35.67407050915007 139.73806979173298 29.255 35.674054241928715 139.73801606854983 21.999 35.67401137433288 139.7380979318199 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fe0574ab-3485-44ef-a177-0b2545598a50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe0574ab-3485-44ef-a177-0b2545598a50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe0574ab-3485-44ef-a177-0b2545598a50">
											<gml:posList>35.67401137433288 139.7380979318199 29.255 35.674015973329176 139.73810045606456 29.255 35.67406841347251 139.73807550540207 29.255 35.67407050915007 139.73806979173298 29.255 35.67401137433288 139.7380979318199 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04a026d4-ba60-43c6-8908-1c899b8605b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04a026d4-ba60-43c6-8908-1c899b8605b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04a026d4-ba60-43c6-8908-1c899b8605b5">
											<gml:posList>35.67407050915007 139.73806979173298 29.255 35.67406841347251 139.73807550540207 29.255 35.67408478008025 139.73812955989186 29.255 35.67408937006213 139.73813208415132 29.255 35.67407050915007 139.73806979173298 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04175e78-4ac3-453e-91bc-47d716c9271b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04175e78-4ac3-453e-91bc-47d716c9271b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04175e78-4ac3-453e-91bc-47d716c9271b">
											<gml:posList>35.67408478008025 139.73812955989186 28.343 35.67406841347251 139.73807550540207 28.343 35.674015973329176 139.73810045606456 28.343 35.67403241220147 139.7381547203268 28.343 35.67408478008025 139.73812955989186 28.343</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-392d2951-85f2-46c9-b7ac-1e0f6705ab81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-392d2951-85f2-46c9-b7ac-1e0f6705ab81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-392d2951-85f2-46c9-b7ac-1e0f6705ab81">
											<gml:posList>35.674030307523594 139.73816045609513 29.255 35.67403241220147 139.7381547203268 29.255 35.674015973329176 139.73810045606456 29.255 35.67401137433288 139.7380979318199 29.255 35.674030307523594 139.73816045609513 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aaa2bcc8-008e-4c26-be03-67987afce7dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aaa2bcc8-008e-4c26-be03-67987afce7dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aaa2bcc8-008e-4c26-be03-67987afce7dd">
											<gml:posList>35.67408937006213 139.73813208415132 29.255 35.67408478008025 139.73812955989186 29.255 35.67403241220147 139.7381547203268 29.255 35.674030307523594 139.73816045609513 29.255 35.67408937006213 139.73813208415132 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72ad6c6b-016a-4273-b97a-8a5433f7d315">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72ad6c6b-016a-4273-b97a-8a5433f7d315">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72ad6c6b-016a-4273-b97a-8a5433f7d315">
											<gml:posList>35.674035919683035 139.7381789748539 21.999 35.67409537987731 139.73815192806208 21.999 35.67408937006213 139.73813208415132 29.255 35.674035919683035 139.7381789748539 21.999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aefbcf47-97cc-4875-83a0-1f7d288d2ee0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aefbcf47-97cc-4875-83a0-1f7d288d2ee0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aefbcf47-97cc-4875-83a0-1f7d288d2ee0">
											<gml:posList>35.67408937006213 139.73813208415132 29.255 35.674030307523594 139.73816045609513 29.255 35.674035919683035 139.7381789748539 21.999 35.67408937006213 139.73813208415132 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d441494e-5f23-49f2-97af-b3aba6e46701">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d441494e-5f23-49f2-97af-b3aba6e46701">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d441494e-5f23-49f2-97af-b3aba6e46701">
											<gml:posList>35.67404709884625 139.7382159130118 21.999 35.67410656807992 139.73818888832642 21.999 35.67409537987731 139.73815192806208 21.999 35.674035919683035 139.7381789748539 21.999 35.67404709884625 139.7382159130118 21.999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d6a7ef5-bfb0-42e5-967f-6609481d096c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d6a7ef5-bfb0-42e5-967f-6609481d096c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d6a7ef5-bfb0-42e5-967f-6609481d096c">
											<gml:posList>35.674054241928715 139.73801606854983 8.396 35.67399477273348 139.73804309334562 8.396 35.67399477273348 139.73804309334562 21.999 35.674054241928715 139.73801606854983 21.999 35.674054241928715 139.73801606854983 8.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdadfa31-4eea-431e-a88a-5336c7685174">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdadfa31-4eea-431e-a88a-5336c7685174">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdadfa31-4eea-431e-a88a-5336c7685174">
											<gml:posList>35.674015973329176 139.73810045606456 29.255 35.674015973329176 139.73810045606456 28.343 35.67406841347251 139.73807550540207 28.343 35.67406841347251 139.73807550540207 29.255 35.674015973329176 139.73810045606456 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b671cf9c-e580-4918-b809-5a08a1eed05f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b671cf9c-e580-4918-b809-5a08a1eed05f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b671cf9c-e580-4918-b809-5a08a1eed05f">
											<gml:posList>35.67407050915007 139.73806979173298 29.255 35.67408937006213 139.73813208415132 29.255 35.67409537987731 139.73815192806208 21.999 35.67410656807992 139.73818888832642 21.999 35.67410656807992 139.73818888832642 8.396 35.674054241928715 139.73801606854983 8.396 35.674054241928715 139.73801606854983 21.999 35.67407050915007 139.73806979173298 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fb62649-799f-4bf2-bb4f-502135c4ded2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fb62649-799f-4bf2-bb4f-502135c4ded2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fb62649-799f-4bf2-bb4f-502135c4ded2">
											<gml:posList>35.67406841347251 139.73807550540207 29.255 35.67406841347251 139.73807550540207 28.343 35.67408478008025 139.73812955989186 28.343 35.67408478008025 139.73812955989186 29.255 35.67406841347251 139.73807550540207 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a90591f-5fe5-4543-9857-b17003abd00a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a90591f-5fe5-4543-9857-b17003abd00a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a90591f-5fe5-4543-9857-b17003abd00a">
											<gml:posList>35.67403241220147 139.7381547203268 29.255 35.67403241220147 139.7381547203268 28.343 35.674015973329176 139.73810045606456 28.343 35.674015973329176 139.73810045606456 29.255 35.67403241220147 139.7381547203268 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ce409aa-e778-4e39-8812-caea6acbbb2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ce409aa-e778-4e39-8812-caea6acbbb2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ce409aa-e778-4e39-8812-caea6acbbb2a">
											<gml:posList>35.674030307523594 139.73816045609513 29.255 35.67401137433288 139.7380979318199 29.255 35.67399477273348 139.73804309334562 21.999 35.67399477273348 139.73804309334562 8.396 35.67404709884625 139.7382159130118 8.396 35.67404709884625 139.7382159130118 21.999 35.674035919683035 139.7381789748539 21.999 35.674030307523594 139.73816045609513 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74e63cc0-f86d-4bb1-bba2-6867292617cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74e63cc0-f86d-4bb1-bba2-6867292617cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74e63cc0-f86d-4bb1-bba2-6867292617cd">
											<gml:posList>35.67408478008025 139.73812955989186 29.255 35.67408478008025 139.73812955989186 28.343 35.67403241220147 139.7381547203268 28.343 35.67403241220147 139.7381547203268 29.255 35.67408478008025 139.73812955989186 29.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66e5501c-c6e0-4b74-9874-9e1cf1ebb0b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66e5501c-c6e0-4b74-9874-9e1cf1ebb0b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66e5501c-c6e0-4b74-9874-9e1cf1ebb0b7">
											<gml:posList>35.67404709884625 139.7382159130118 8.396 35.67410656807992 139.73818888832642 8.396 35.67410656807992 139.73818888832642 21.999 35.67404709884625 139.7382159130118 21.999 35.67404709884625 139.7382159130118 8.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8611</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">117.4176</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>