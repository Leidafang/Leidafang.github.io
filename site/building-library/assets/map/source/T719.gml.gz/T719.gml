<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ce28ccaf-1103-42a3-850e-89d0f361794d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">11.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66831305153006 139.74903330071686 0 35.66823199104424 139.74899472506345 0 35.668199163383456 139.74909826023534 0 35.66828022383663 139.74913683597782 0 35.66831305153006 139.74903330071686 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66831305153006 139.74903330071686 5.4 35.66828022383663 139.74913683597782 5.4 35.668199163383456 139.74909826023534 5.4 35.66823199104424 139.74899472506345 5.4 35.66831305153006 139.74903330071686 5.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66831305153006 139.74903330071686 5.4 35.66823199104424 139.74899472506345 5.4 35.66823199104424 139.74899472506345 16.46 35.66831305153006 139.74903330071686 16.46 35.66831305153006 139.74903330071686 5.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66823199104424 139.74899472506345 5.4 35.668199163383456 139.74909826023534 5.4 35.668199163383456 139.74909826023534 16.46 35.66823199104424 139.74899472506345 16.46 35.66823199104424 139.74899472506345 5.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668199163383456 139.74909826023534 5.4 35.66828022383663 139.74913683597782 5.4 35.66828022383663 139.74913683597782 16.46 35.668199163383456 139.74909826023534 16.46 35.668199163383456 139.74909826023534 5.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66828022383663 139.74913683597782 5.4 35.66831305153006 139.74903330071686 5.4 35.66831305153006 139.74903330071686 16.46 35.66828022383663 139.74913683597782 16.46 35.66828022383663 139.74913683597782 5.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66831305153006 139.74903330071686 16.46 35.66823199104424 139.74899472506345 16.46 35.668199163383456 139.74909826023534 16.46 35.66828022383663 139.74913683597782 16.46 35.66831305153006 139.74903330071686 16.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f38e730c-c04b-4252-a973-e2016aa09413"/>
							<gml:surfaceMember xlink:href="#poly-656f47ba-9c95-43f3-a217-d4477e243d63"/>
							<gml:surfaceMember xlink:href="#poly-dee070cd-10f7-46ac-b958-3b6bc2dc755a"/>
							<gml:surfaceMember xlink:href="#poly-83ed318f-6f3e-4794-9b68-ee10f94874a6"/>
							<gml:surfaceMember xlink:href="#poly-9b2860e1-1990-4f74-a41e-690451182d96"/>
							<gml:surfaceMember xlink:href="#poly-237091e5-4cc3-41e3-a1cc-c2ce0b1de2eb"/>
							<gml:surfaceMember xlink:href="#poly-281622da-d0b1-4a7d-a9e9-ab96a1f5dfc5"/>
							<gml:surfaceMember xlink:href="#poly-82489eb9-fa32-46c0-9332-2103d4cef7aa"/>
							<gml:surfaceMember xlink:href="#poly-8b342ede-fc04-4c34-93a5-f28247884075"/>
							<gml:surfaceMember xlink:href="#poly-db157fea-3baf-4264-b4dc-48b24c84b786"/>
							<gml:surfaceMember xlink:href="#poly-ad8cc875-6300-4a65-9046-d3d8eb63e48b"/>
							<gml:surfaceMember xlink:href="#poly-5adaf8f7-d1ba-4138-98e5-7ce46c55e570"/>
							<gml:surfaceMember xlink:href="#poly-211b8c2d-9b91-4ede-bd01-3e23995cf56b"/>
							<gml:surfaceMember xlink:href="#poly-e9fbb858-63f6-49b0-aae3-4b4e8f3cc7cd"/>
							<gml:surfaceMember xlink:href="#poly-da31221d-6817-4324-852f-1b55f0f2bc1f"/>
							<gml:surfaceMember xlink:href="#poly-ba7c3368-f110-45a6-9318-a99a3e1273f4"/>
							<gml:surfaceMember xlink:href="#poly-88980a59-c472-469d-ad1e-7ee174266ec5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f38e730c-c04b-4252-a973-e2016aa09413">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f38e730c-c04b-4252-a973-e2016aa09413">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f38e730c-c04b-4252-a973-e2016aa09413">
											<gml:posList>35.668313051530056 139.74903330071686 5.4 35.66828022383665 139.7491368359778 5.4 35.668199163383434 139.74909826023534 5.4 35.66823199104424 139.74899472506345 5.4 35.668313051530056 139.74903330071686 5.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-656f47ba-9c95-43f3-a217-d4477e243d63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-656f47ba-9c95-43f3-a217-d4477e243d63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-656f47ba-9c95-43f3-a217-d4477e243d63">
											<gml:posList>35.66824779265231 139.74904697795654 17.3 35.66823199104424 139.74899472506345 12.1 35.668199163383434 139.74909826023534 12.1 35.66824779265231 139.74904697795654 17.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dee070cd-10f7-46ac-b958-3b6bc2dc755a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dee070cd-10f7-46ac-b958-3b6bc2dc755a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dee070cd-10f7-46ac-b958-3b6bc2dc755a">
											<gml:posList>35.66824779265231 139.74904697795654 17.3 35.668199163383434 139.74909826023534 12.1 35.66822670950933 139.74911136494825 17.3 35.66824779265231 139.74904697795654 17.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83ed318f-6f3e-4794-9b68-ee10f94874a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83ed318f-6f3e-4794-9b68-ee10f94874a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83ed318f-6f3e-4794-9b68-ee10f94874a6">
											<gml:posList>35.66822670950933 139.74911136494825 17.3 35.668228808935375 139.7491102581467 17.3 35.668248695811116 139.74904952862545 17.3 35.66824779265231 139.74904697795654 17.3 35.66822670950933 139.74911136494825 17.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b2860e1-1990-4f74-a41e-690451182d96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b2860e1-1990-4f74-a41e-690451182d96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b2860e1-1990-4f74-a41e-690451182d96">
											<gml:posList>35.66828022383665 139.7491368359778 17.3 35.668279302652245 139.74913428532582 17.3 35.668228808935375 139.7491102581467 17.3 35.66822670950933 139.74911136494825 17.3 35.66828022383665 139.7491368359778 17.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-237091e5-4cc3-41e3-a1cc-c2ce0b1de2eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-237091e5-4cc3-41e3-a1cc-c2ce0b1de2eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-237091e5-4cc3-41e3-a1cc-c2ce0b1de2eb">
											<gml:posList>35.668279302652245 139.74913428532582 16.901 35.66829863051098 139.7490733023023 16.901 35.668248695811116 139.74904952862545 16.901 35.668228808935375 139.7491102581467 16.901 35.668279302652245 139.74913428532582 16.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-281622da-d0b1-4a7d-a9e9-ab96a1f5dfc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-281622da-d0b1-4a7d-a9e9-ab96a1f5dfc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-281622da-d0b1-4a7d-a9e9-ab96a1f5dfc5">
											<gml:posList>35.66824779265231 139.74904697795654 17.3 35.66830072090747 139.7490721734163 17.3 35.668313051530056 139.74903330071686 12.1 35.66823199104424 139.74899472506345 12.1 35.66824779265231 139.74904697795654 17.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-82489eb9-fa32-46c0-9332-2103d4cef7aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82489eb9-fa32-46c0-9332-2103d4cef7aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82489eb9-fa32-46c0-9332-2103d4cef7aa">
											<gml:posList>35.66824779265231 139.74904697795654 17.3 35.668248695811116 139.74904952862545 17.3 35.66829863051098 139.7490733023023 17.3 35.66830072090747 139.7490721734163 17.3 35.66824779265231 139.74904697795654 17.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b342ede-fc04-4c34-93a5-f28247884075">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b342ede-fc04-4c34-93a5-f28247884075">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b342ede-fc04-4c34-93a5-f28247884075">
											<gml:posList>35.66830072090747 139.7490721734163 17.3 35.66829863051098 139.7490733023023 17.3 35.668279302652245 139.74913428532582 17.3 35.66828022383665 139.7491368359778 17.3 35.66830072090747 139.7490721734163 17.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db157fea-3baf-4264-b4dc-48b24c84b786">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db157fea-3baf-4264-b4dc-48b24c84b786">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db157fea-3baf-4264-b4dc-48b24c84b786">
											<gml:posList>35.668313051530056 139.74903330071686 5.4 35.66823199104424 139.74899472506345 5.4 35.66823199104424 139.74899472506345 12.1 35.668313051530056 139.74903330071686 12.1 35.668313051530056 139.74903330071686 5.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad8cc875-6300-4a65-9046-d3d8eb63e48b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad8cc875-6300-4a65-9046-d3d8eb63e48b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad8cc875-6300-4a65-9046-d3d8eb63e48b">
											<gml:posList>35.66823199104424 139.74899472506345 5.4 35.668199163383434 139.74909826023534 5.4 35.668199163383434 139.74909826023534 12.1 35.66823199104424 139.74899472506345 12.1 35.66823199104424 139.74899472506345 5.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5adaf8f7-d1ba-4138-98e5-7ce46c55e570">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5adaf8f7-d1ba-4138-98e5-7ce46c55e570">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5adaf8f7-d1ba-4138-98e5-7ce46c55e570">
											<gml:posList>35.668248695811116 139.74904952862545 17.3 35.668248695811116 139.74904952862545 16.901 35.66829863051098 139.7490733023023 16.901 35.66829863051098 139.7490733023023 17.3 35.668248695811116 139.74904952862545 17.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-211b8c2d-9b91-4ede-bd01-3e23995cf56b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-211b8c2d-9b91-4ede-bd01-3e23995cf56b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-211b8c2d-9b91-4ede-bd01-3e23995cf56b">
											<gml:posList>35.668228808935375 139.7491102581467 17.3 35.668228808935375 139.7491102581467 16.901 35.668248695811116 139.74904952862545 16.901 35.668248695811116 139.74904952862545 17.3 35.668228808935375 139.7491102581467 17.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9fbb858-63f6-49b0-aae3-4b4e8f3cc7cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9fbb858-63f6-49b0-aae3-4b4e8f3cc7cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9fbb858-63f6-49b0-aae3-4b4e8f3cc7cd">
											<gml:posList>35.66828022383665 139.7491368359778 17.3 35.66828022383665 139.7491368359778 5.4 35.668313051530056 139.74903330071686 5.4 35.668313051530056 139.74903330071686 12.1 35.66830072090747 139.7490721734163 17.3 35.66828022383665 139.7491368359778 17.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da31221d-6817-4324-852f-1b55f0f2bc1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da31221d-6817-4324-852f-1b55f0f2bc1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da31221d-6817-4324-852f-1b55f0f2bc1f">
											<gml:posList>35.66829863051098 139.7490733023023 17.3 35.66829863051098 139.7490733023023 16.901 35.668279302652245 139.74913428532582 16.901 35.668279302652245 139.74913428532582 17.3 35.66829863051098 139.7490733023023 17.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba7c3368-f110-45a6-9318-a99a3e1273f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba7c3368-f110-45a6-9318-a99a3e1273f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba7c3368-f110-45a6-9318-a99a3e1273f4">
											<gml:posList>35.668199163383434 139.74909826023534 12.1 35.668199163383434 139.74909826023534 5.4 35.66828022383665 139.7491368359778 5.4 35.66828022383665 139.7491368359778 17.3 35.66822670950933 139.74911136494825 17.3 35.668199163383434 139.74909826023534 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88980a59-c472-469d-ad1e-7ee174266ec5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88980a59-c472-469d-ad1e-7ee174266ec5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88980a59-c472-469d-ad1e-7ee174266ec5">
											<gml:posList>35.668279302652245 139.74913428532582 17.3 35.668279302652245 139.74913428532582 16.901 35.668228808935375 139.7491102581467 16.901 35.668228808935375 139.7491102581467 17.3 35.668279302652245 139.74913428532582 17.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10562</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">97.0113</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>