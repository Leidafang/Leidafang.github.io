<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ce4e5aa0-e625-46dd-ba14-c538f1e3e81a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">8.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66992136133967 139.7488124090404 0 35.66991235459205 139.7488223601111 0 35.66990000121394 139.74881585587738 0 35.6698800257001 139.74886569525674 0 35.669968306402225 139.74891740894833 0 35.66998576181317 139.74887287436061 0 35.670044754354514 139.74880531984988 0 35.66998629475813 139.74873324975562 0 35.66992045919177 139.74881130537167 0 35.66992136133967 139.7488124090404 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66992136133967 139.7488124090404 6.41 35.66992045919177 139.74881130537167 6.41 35.66998629475813 139.74873324975562 6.41 35.670044754354514 139.74880531984988 6.41 35.66998576181317 139.74887287436061 6.41 35.669968306402225 139.74891740894833 6.41 35.6698800257001 139.74886569525674 6.41 35.66990000121394 139.74881585587738 6.41 35.66991235459205 139.7488223601111 6.41 35.66992136133967 139.7488124090404 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66992136133967 139.7488124090404 6.41 35.66991235459205 139.7488223601111 6.41 35.66991235459205 139.7488223601111 14.84 35.66992136133967 139.7488124090404 14.84 35.66992136133967 139.7488124090404 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66991235459205 139.7488223601111 6.41 35.66990000121394 139.74881585587738 6.41 35.66990000121394 139.74881585587738 14.84 35.66991235459205 139.7488223601111 14.84 35.66991235459205 139.7488223601111 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66990000121394 139.74881585587738 6.41 35.6698800257001 139.74886569525674 6.41 35.6698800257001 139.74886569525674 14.84 35.66990000121394 139.74881585587738 14.84 35.66990000121394 139.74881585587738 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698800257001 139.74886569525674 6.41 35.669968306402225 139.74891740894833 6.41 35.669968306402225 139.74891740894833 14.84 35.6698800257001 139.74886569525674 14.84 35.6698800257001 139.74886569525674 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669968306402225 139.74891740894833 6.41 35.66998576181317 139.74887287436061 6.41 35.66998576181317 139.74887287436061 14.84 35.669968306402225 139.74891740894833 14.84 35.669968306402225 139.74891740894833 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66998576181317 139.74887287436061 6.41 35.670044754354514 139.74880531984988 6.41 35.670044754354514 139.74880531984988 14.84 35.66998576181317 139.74887287436061 14.84 35.66998576181317 139.74887287436061 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670044754354514 139.74880531984988 6.41 35.66998629475813 139.74873324975562 6.41 35.66998629475813 139.74873324975562 14.84 35.670044754354514 139.74880531984988 14.84 35.670044754354514 139.74880531984988 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66998629475813 139.74873324975562 6.41 35.66992045919177 139.74881130537167 6.41 35.66992045919177 139.74881130537167 14.84 35.66998629475813 139.74873324975562 14.84 35.66998629475813 139.74873324975562 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66992045919177 139.74881130537167 6.41 35.66992136133967 139.7488124090404 6.41 35.66992136133967 139.7488124090404 14.84 35.66992045919177 139.74881130537167 14.84 35.66992045919177 139.74881130537167 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66992136133967 139.7488124090404 14.84 35.66991235459205 139.7488223601111 14.84 35.66990000121394 139.74881585587738 14.84 35.6698800257001 139.74886569525674 14.84 35.669968306402225 139.74891740894833 14.84 35.66998576181317 139.74887287436061 14.84 35.670044754354514 139.74880531984988 14.84 35.66998629475813 139.74873324975562 14.84 35.66992045919177 139.74881130537167 14.84 35.66992136133967 139.7488124090404 14.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f8f8c1f1-d15c-4091-96d1-ee44cece392c"/>
							<gml:surfaceMember xlink:href="#poly-d1b9ed68-2533-4c57-9540-c7184e3faccb"/>
							<gml:surfaceMember xlink:href="#poly-98c0e9b2-aa1e-406b-b8c1-d3372e647c81"/>
							<gml:surfaceMember xlink:href="#poly-8dd60949-3936-4b10-b36f-77efc9ed589a"/>
							<gml:surfaceMember xlink:href="#poly-4c1ab154-0e9a-4345-b3e2-ff2a181ffecc"/>
							<gml:surfaceMember xlink:href="#poly-52120498-7acb-41ec-968b-3df02716674a"/>
							<gml:surfaceMember xlink:href="#poly-974920ec-4734-4eb7-968f-2dbb144690f9"/>
							<gml:surfaceMember xlink:href="#poly-0f07b2f7-0a8d-4e01-9069-2fe4f4aad1c3"/>
							<gml:surfaceMember xlink:href="#poly-b3a32d44-434e-4860-a838-a01c7e53d29b"/>
							<gml:surfaceMember xlink:href="#poly-1eb97715-2ac7-4790-9d1c-af8d443ec010"/>
							<gml:surfaceMember xlink:href="#poly-8f1cfaf2-251b-431e-8ff9-c2beb43bd72f"/>
							<gml:surfaceMember xlink:href="#poly-4f81ae93-4392-40fa-a3e1-078fc175112a"/>
							<gml:surfaceMember xlink:href="#poly-c785c301-2d82-44b8-9042-bce5a6e96dc6"/>
							<gml:surfaceMember xlink:href="#poly-a1acf8fd-b3ae-4ef2-8e6e-4a7d53557236"/>
							<gml:surfaceMember xlink:href="#poly-345caf0e-6271-45d0-9f9f-51a5a9f973cd"/>
							<gml:surfaceMember xlink:href="#poly-e0dd2703-f7c4-4911-a263-092c8b16350e"/>
							<gml:surfaceMember xlink:href="#poly-2068d2ba-72d7-4963-a529-212a81446270"/>
							<gml:surfaceMember xlink:href="#poly-698588b9-3513-4e05-bd3d-57262338be15"/>
							<gml:surfaceMember xlink:href="#poly-d59a0cc4-eb5f-4e66-9a49-9064de8872d8"/>
							<gml:surfaceMember xlink:href="#poly-c0c121c8-2769-4b7c-8396-92aac36a0a9a"/>
							<gml:surfaceMember xlink:href="#poly-20d6158f-c0be-48f7-8682-72d542e3a388"/>
							<gml:surfaceMember xlink:href="#poly-a48396da-eccd-488c-b997-dfd6c9a961ca"/>
							<gml:surfaceMember xlink:href="#poly-527b190e-832c-4798-bce0-b616d6318153"/>
							<gml:surfaceMember xlink:href="#poly-184800aa-680b-48f8-9f51-60be3742a051"/>
							<gml:surfaceMember xlink:href="#poly-360f6842-6c51-48f2-b045-8a4104fff6d2"/>
							<gml:surfaceMember xlink:href="#poly-ffed25da-9111-46f4-8d38-30a41941d369"/>
							<gml:surfaceMember xlink:href="#poly-6b8788b2-1005-45aa-86c7-8d833117cf7e"/>
							<gml:surfaceMember xlink:href="#poly-1a04655c-f43f-4a78-9a18-4e072ef8383a"/>
							<gml:surfaceMember xlink:href="#poly-48915424-c236-4432-9350-ec49aa5bdf45"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ce4e5aa0-e625-46dd-ba14-c538f1e3e81a_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c92696b8-f136-4f27-bdbb-1c579680d8c5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66999290274585 139.74874739297425 15 35.6699862448432 139.7487391816209 15 35.66992565992525 139.7488110347805 15 35.66992510070209 139.74881050515253 15 35.669987639836506 139.7487361424424 15 35.66999501026595 139.74874498267772 15 35.66999290274585 139.74874739297425 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cef1f6a2-a6d6-4f32-8b6a-8f918c662660">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66993834047241 139.74882134960941 14.664 35.66993397394508 139.74881582006634 14.664 35.66993159629861 139.74881863935326 14.664 35.66992565992525 139.7488110347805 14.664 35.6699862448432 139.7487391816209 14.664 35.66999290274585 139.74874739297425 14.664 35.66996653182312 139.74877769843783 14.664 35.66997218846282 139.74878486145883 14.664 35.66995723811043 139.74880258428573 14.664 35.669951942346486 139.74879588482477 14.664 35.66994385473661 139.74880545936134 14.664 35.66994767093868 139.74881029357402 14.664 35.66993834047241 139.74882134960941 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f40e99f3-683f-4ec1-8326-6a54b7f895e1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670009689182116 139.74878998049397 14.664 35.66999989873866 139.74880063936178 14.664 35.669994584505154 139.74879331028305 14.664 35.670004374947965 139.74878265141507 14.664 35.670009689182116 139.74878998049397 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e272af08-5426-4312-b4b3-9233ad93d0cc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66995902745537 139.74884770613536 14.664 35.66995433555152 139.74884091766532 14.664 35.669967567078906 139.7488271732911 14.664 35.66997225898349 139.74883396176145 14.664 35.66995902745537 139.74884770613536 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-120b7eed-39aa-4d35-84cd-d184209f9615">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-120b7eed-39aa-4d35-84cd-d184209f9615_0">
											<gml:posList>35.66999501026595 139.74874498267772 15 35.669987639836506 139.7487361424424 15 35.669987639836506 139.7487361424424 16.53 35.66999501026595 139.74874498267772 16.53 35.66999501026595 139.74874498267772 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d67790dd-947b-4903-a939-be5259018466">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d67790dd-947b-4903-a939-be5259018466_0">
											<gml:posList>35.6699862448432 139.7487391816209 15 35.66999290274585 139.74874739297425 15 35.66999290274585 139.74874739297425 14.664 35.6699862448432 139.7487391816209 14.664 35.6699862448432 139.7487391816209 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c99039ca-466f-4a0d-b762-23b2a3a11d76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c99039ca-466f-4a0d-b762-23b2a3a11d76_0">
											<gml:posList>35.66999501026595 139.74874498267772 16.53 35.66996653182312 139.74877769843783 16.53 35.66996653182312 139.74877769843783 14.664 35.66999290274585 139.74874739297425 14.664 35.66999290274585 139.74874739297425 15 35.66999501026595 139.74874498267772 15 35.66999501026595 139.74874498267772 16.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-534809d1-2665-4d84-b382-492b7ec16e22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-534809d1-2665-4d84-b382-492b7ec16e22_0">
											<gml:posList>35.66992510070209 139.74881050515253 15 35.66992510070209 139.74881050515253 16.53 35.669987639836506 139.7487361424424 16.53 35.669987639836506 139.7487361424424 15 35.66992510070209 139.74881050515253 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f1ed4b7-0200-4bae-8763-4201f0b7db67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f1ed4b7-0200-4bae-8763-4201f0b7db67_0">
											<gml:posList>35.6699862448432 139.7487391816209 14.664 35.66992565992525 139.7488110347805 14.664 35.66992565992525 139.7488110347805 15 35.6699862448432 139.7487391816209 15 35.6699862448432 139.7487391816209 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fc75111-cdf6-4086-af2c-379fa8dc9f5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fc75111-cdf6-4086-af2c-379fa8dc9f5d_0">
											<gml:posList>35.66994385473661 139.74880545936134 16.53 35.669951942346486 139.74879588482477 16.53 35.66995723811043 139.74880258428573 16.53 35.66997218846282 139.74878486145883 16.53 35.66996653182312 139.74877769843783 16.53 35.66999501026595 139.74874498267772 16.53 35.669987639836506 139.7487361424424 16.53 35.66992510070209 139.74881050515253 16.53 35.66993159629861 139.74881863935326 16.53 35.66993397394508 139.74881582006634 16.53 35.66993834047241 139.74882134960941 16.53 35.66994767093868 139.74881029357402 16.53 35.66994385473661 139.74880545936134 16.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5736482-4f1d-4fe4-8db3-0f2d225fba2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5736482-4f1d-4fe4-8db3-0f2d225fba2c_0">
											<gml:posList>35.66997218846282 139.74878486145883 14.664 35.66996653182312 139.74877769843783 14.664 35.66996653182312 139.74877769843783 16.53 35.66997218846282 139.74878486145883 16.53 35.66997218846282 139.74878486145883 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ad64b1d-4aea-47d4-8ba5-f32ccff0f0db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ad64b1d-4aea-47d4-8ba5-f32ccff0f0db_0">
											<gml:posList>35.670009689182116 139.74878998049397 14.664 35.670004374947965 139.74878265141507 14.664 35.670004374947965 139.74878265141507 16.936 35.670009689182116 139.74878998049397 16.936 35.670009689182116 139.74878998049397 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9722da7a-9f45-44b0-8622-852492e16043">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9722da7a-9f45-44b0-8622-852492e16043_0">
											<gml:posList>35.670004374947965 139.74878265141507 14.664 35.669994584505154 139.74879331028305 14.664 35.669994584505154 139.74879331028305 16.936 35.670004374947965 139.74878265141507 16.936 35.670004374947965 139.74878265141507 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24369d04-16de-49f7-8315-320148522c04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24369d04-16de-49f7-8315-320148522c04_0">
											<gml:posList>35.670009689182116 139.74878998049397 16.936 35.670004374947965 139.74878265141507 16.936 35.669994584505154 139.74879331028305 16.936 35.66999989873866 139.74880063936178 16.936 35.670009689182116 139.74878998049397 16.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de1494b1-0dbd-4129-b4d9-9010a562b6a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de1494b1-0dbd-4129-b4d9-9010a562b6a1_0">
											<gml:posList>35.66995723811043 139.74880258428573 14.664 35.66997218846282 139.74878486145883 14.664 35.66997218846282 139.74878486145883 16.53 35.66995723811043 139.74880258428573 16.53 35.66995723811043 139.74880258428573 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5709cb51-b3ee-4339-8635-fe18d2dc50c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5709cb51-b3ee-4339-8635-fe18d2dc50c5_0">
											<gml:posList>35.66999989873866 139.74880063936178 14.664 35.670009689182116 139.74878998049397 14.664 35.670009689182116 139.74878998049397 16.936 35.66999989873866 139.74880063936178 16.936 35.66999989873866 139.74880063936178 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dacbc278-a6c2-4a51-a1ce-d6ad4efebb0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dacbc278-a6c2-4a51-a1ce-d6ad4efebb0c_0">
											<gml:posList>35.669994584505154 139.74879331028305 14.664 35.66999989873866 139.74880063936178 14.664 35.66999989873866 139.74880063936178 16.936 35.669994584505154 139.74879331028305 16.936 35.669994584505154 139.74879331028305 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef7552d5-25c2-4255-9040-7fec35d74fc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef7552d5-25c2-4255-9040-7fec35d74fc8_0">
											<gml:posList>35.66995723811043 139.74880258428573 14.664 35.66995723811043 139.74880258428573 16.53 35.669951942346486 139.74879588482477 16.53 35.669951942346486 139.74879588482477 14.664 35.66995723811043 139.74880258428573 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6fea8ed-9b8d-4889-8e0b-5ef2abe23485">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6fea8ed-9b8d-4889-8e0b-5ef2abe23485_0">
											<gml:posList>35.66994385473661 139.74880545936134 14.664 35.669951942346486 139.74879588482477 14.664 35.669951942346486 139.74879588482477 16.53 35.66994385473661 139.74880545936134 16.53 35.66994385473661 139.74880545936134 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c1d78f2-03a4-411e-8281-547c0002c345">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c1d78f2-03a4-411e-8281-547c0002c345_0">
											<gml:posList>35.66994767093868 139.74881029357402 14.664 35.66994385473661 139.74880545936134 14.664 35.66994385473661 139.74880545936134 16.53 35.66994767093868 139.74881029357402 16.53 35.66994767093868 139.74881029357402 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75bbbee4-7678-40f3-ad2c-c27ab6fca0f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75bbbee4-7678-40f3-ad2c-c27ab6fca0f2_0">
											<gml:posList>35.66993159629861 139.74881863935326 14.664 35.66993159629861 139.74881863935326 16.53 35.66992510070209 139.74881050515253 16.53 35.66992510070209 139.74881050515253 15 35.66992565992525 139.7488110347805 15 35.66992565992525 139.7488110347805 14.664 35.66993159629861 139.74881863935326 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ebc0a46-82bb-4729-95ba-4dba44dc66bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ebc0a46-82bb-4729-95ba-4dba44dc66bf_0">
											<gml:posList>35.66993834047241 139.74882134960941 14.664 35.66994767093868 139.74881029357402 14.664 35.66994767093868 139.74881029357402 16.53 35.66993834047241 139.74882134960941 16.53 35.66993834047241 139.74882134960941 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bd1fe04-6121-4b4e-bdb9-cbc0bb6c0d3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bd1fe04-6121-4b4e-bdb9-cbc0bb6c0d3d_0">
											<gml:posList>35.66993159629861 139.74881863935326 14.664 35.66993397394508 139.74881582006634 14.664 35.66993397394508 139.74881582006634 16.53 35.66993159629861 139.74881863935326 16.53 35.66993159629861 139.74881863935326 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cc396a1-702a-428e-ac92-dc9cfc843d0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cc396a1-702a-428e-ac92-dc9cfc843d0d_0">
											<gml:posList>35.66993397394508 139.74881582006634 14.664 35.66993834047241 139.74882134960941 14.664 35.66993834047241 139.74882134960941 16.53 35.66993397394508 139.74881582006634 16.53 35.66993397394508 139.74881582006634 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba3244b1-5cc7-48d1-9cf7-e157a33209b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba3244b1-5cc7-48d1-9cf7-e157a33209b6_0">
											<gml:posList>35.669967567078906 139.7488271732911 14.664 35.669967567078906 139.7488271732911 16.733 35.66997225898349 139.74883396176145 16.733 35.66997225898349 139.74883396176145 14.664 35.669967567078906 139.7488271732911 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb58e8db-a96e-4897-8094-2a2f942dd062">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb58e8db-a96e-4897-8094-2a2f942dd062_0">
											<gml:posList>35.66995433555152 139.74884091766532 14.664 35.66995433555152 139.74884091766532 16.733 35.669967567078906 139.7488271732911 16.733 35.669967567078906 139.7488271732911 14.664 35.66995433555152 139.74884091766532 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be33b1c7-f380-4d61-bd5c-305d20c10c2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be33b1c7-f380-4d61-bd5c-305d20c10c2d_0">
											<gml:posList>35.66995902745537 139.74884770613536 16.733 35.66997225898349 139.74883396176145 16.733 35.669967567078906 139.7488271732911 16.733 35.66995433555152 139.74884091766532 16.733 35.66995902745537 139.74884770613536 16.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a38066b-e220-4aea-aaab-c6b7c622f414">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a38066b-e220-4aea-aaab-c6b7c622f414_0">
											<gml:posList>35.66995902745537 139.74884770613536 14.664 35.66997225898349 139.74883396176145 14.664 35.66997225898349 139.74883396176145 16.733 35.66995902745537 139.74884770613536 16.733 35.66995902745537 139.74884770613536 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb1b9d0f-7965-4d1f-8a9e-014367e63131">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb1b9d0f-7965-4d1f-8a9e-014367e63131_0">
											<gml:posList>35.66995433555152 139.74884091766532 14.664 35.66995902745537 139.74884770613536 14.664 35.66995902745537 139.74884770613536 16.733 35.66995433555152 139.74884091766532 16.733 35.66995433555152 139.74884091766532 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f8f8c1f1-d15c-4091-96d1-ee44cece392c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8f8c1f1-d15c-4091-96d1-ee44cece392c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8f8c1f1-d15c-4091-96d1-ee44cece392c">
											<gml:posList>35.66988002570009 139.74886569525674 6.41 35.669900001213925 139.74881585587738 6.41 35.66991235459201 139.7488223601111 6.41 35.66992136133967 139.74881240904037 6.41 35.669920459191765 139.74881130537165 6.41 35.66998629475813 139.74873324975562 6.41 35.67004475435451 139.74880531984985 6.41 35.66998576181316 139.74887287436061 6.41 35.66996830640221 139.74891740894833 6.41 35.66988002570009 139.74886569525674 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1b9ed68-2533-4c57-9540-c7184e3faccb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1b9ed68-2533-4c57-9540-c7184e3faccb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1b9ed68-2533-4c57-9540-c7184e3faccb">
											<gml:posList>35.66988002570009 139.74886569525674 15 35.66988465738346 139.74886373520133 15 35.66990166358488 139.74882133303743 15 35.669900001213925 139.74881585587738 15 35.66988002570009 139.74886569525674 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98c0e9b2-aa1e-406b-b8c1-d3372e647c81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98c0e9b2-aa1e-406b-b8c1-d3372e647c81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98c0e9b2-aa1e-406b-b8c1-d3372e647c81">
											<gml:posList>35.66991235459201 139.7488223601111 15 35.669900001213925 139.74881585587738 15 35.66990166358488 139.74882133303743 15 35.6699130340945 139.74882730809063 15 35.66991235459201 139.7488223601111 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8dd60949-3936-4b10-b36f-77efc9ed589a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dd60949-3936-4b10-b36f-77efc9ed589a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dd60949-3936-4b10-b36f-77efc9ed589a">
											<gml:posList>35.66992136133967 139.74881240904037 15 35.66991235459201 139.7488223601111 15 35.6699130340945 139.74882730809063 15 35.66992637309506 139.74881258049635 15 35.66992136133967 139.74881240904037 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c1ab154-0e9a-4345-b3e2-ff2a181ffecc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c1ab154-0e9a-4345-b3e2-ff2a181ffecc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c1ab154-0e9a-4345-b3e2-ff2a181ffecc">
											<gml:posList>35.66992136133967 139.74881240904037 15 35.66992637309506 139.74881258049635 15 35.66992538073237 139.74881136646073 15 35.669920459191765 139.74881130537165 15 35.66992136133967 139.74881240904037 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52120498-7acb-41ec-968b-3df02716674a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52120498-7acb-41ec-968b-3df02716674a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52120498-7acb-41ec-968b-3df02716674a">
											<gml:posList>35.66996830640221 139.74891740894833 15 35.66996668900358 139.7489117881337 15 35.66988465738346 139.74886373520133 15 35.66988002570009 139.74886569525674 15 35.66996830640221 139.74891740894833 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-974920ec-4734-4eb7-968f-2dbb144690f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-974920ec-4734-4eb7-968f-2dbb144690f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-974920ec-4734-4eb7-968f-2dbb144690f9">
											<gml:posList>35.669920459191765 139.74881130537165 15 35.66992538073237 139.74881136646073 15 35.6699862448432 139.7487391816209 15 35.66998629475813 139.74873324975562 15 35.669920459191765 139.74881130537165 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0f07b2f7-0a8d-4e01-9069-2fe4f4aad1c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f07b2f7-0a8d-4e01-9069-2fe4f4aad1c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f07b2f7-0a8d-4e01-9069-2fe4f4aad1c3">
											<gml:posList>35.6699862448432 139.7487391816209 14.664 35.66992538073237 139.74881136646073 14.664 35.66992637309506 139.74881258049635 14.664 35.6699130340945 139.74882730809063 14.664 35.66990166358488 139.74882133303743 14.664 35.66988465738346 139.74886373520133 14.664 35.66996668900358 139.7489117881337 14.664 35.66998293873506 139.74887033670717 14.664 35.67003981476328 139.7488052256415 14.664 35.6699862448432 139.7487391816209 14.664</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b3a32d44-434e-4860-a838-a01c7e53d29b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3a32d44-434e-4860-a838-a01c7e53d29b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3a32d44-434e-4860-a838-a01c7e53d29b">
											<gml:posList>35.66998576181316 139.74887287436061 15 35.66998293873506 139.74887033670717 15 35.66996668900358 139.7489117881337 15 35.66996830640221 139.74891740894833 15 35.66998576181316 139.74887287436061 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1eb97715-2ac7-4790-9d1c-af8d443ec010">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1eb97715-2ac7-4790-9d1c-af8d443ec010">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1eb97715-2ac7-4790-9d1c-af8d443ec010">
											<gml:posList>35.66998576181316 139.74887287436061 15 35.67004475435451 139.74880531984985 15 35.67003981476328 139.7488052256415 15 35.66998293873506 139.74887033670717 15 35.66998576181316 139.74887287436061 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8f1cfaf2-251b-431e-8ff9-c2beb43bd72f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f1cfaf2-251b-431e-8ff9-c2beb43bd72f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f1cfaf2-251b-431e-8ff9-c2beb43bd72f">
											<gml:posList>35.66998629475813 139.74873324975562 15 35.6699862448432 139.7487391816209 15 35.67003981476328 139.7488052256415 15 35.67004475435451 139.74880531984985 15 35.66998629475813 139.74873324975562 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f81ae93-4392-40fa-a3e1-078fc175112a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f81ae93-4392-40fa-a3e1-078fc175112a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f81ae93-4392-40fa-a3e1-078fc175112a">
											<gml:posList>35.67003981476328 139.7488052256415 15 35.67003981476328 139.7488052256415 14.664 35.66998293873506 139.74887033670717 14.664 35.66998293873506 139.74887033670717 15 35.67003981476328 139.7488052256415 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c785c301-2d82-44b8-9042-bce5a6e96dc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c785c301-2d82-44b8-9042-bce5a6e96dc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c785c301-2d82-44b8-9042-bce5a6e96dc6">
											<gml:posList>35.669920459191765 139.74881130537165 15 35.66998629475813 139.74873324975562 15 35.66998629475813 139.74873324975562 6.41 35.669920459191765 139.74881130537165 6.41 35.669920459191765 139.74881130537165 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1acf8fd-b3ae-4ef2-8e6e-4a7d53557236">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1acf8fd-b3ae-4ef2-8e6e-4a7d53557236">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1acf8fd-b3ae-4ef2-8e6e-4a7d53557236">
											<gml:posList>35.66992538073237 139.74881136646073 15 35.66992538073237 139.74881136646073 14.664 35.6699862448432 139.7487391816209 14.664 35.6699862448432 139.7487391816209 15 35.66992538073237 139.74881136646073 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-345caf0e-6271-45d0-9f9f-51a5a9f973cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-345caf0e-6271-45d0-9f9f-51a5a9f973cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-345caf0e-6271-45d0-9f9f-51a5a9f973cd">
											<gml:posList>35.669920459191765 139.74881130537165 6.41 35.66992136133967 139.74881240904037 6.41 35.66992136133967 139.74881240904037 15 35.669920459191765 139.74881130537165 15 35.669920459191765 139.74881130537165 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0dd2703-f7c4-4911-a263-092c8b16350e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0dd2703-f7c4-4911-a263-092c8b16350e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0dd2703-f7c4-4911-a263-092c8b16350e">
											<gml:posList>35.66992637309506 139.74881258049635 15 35.66992637309506 139.74881258049635 14.664 35.66992538073237 139.74881136646073 14.664 35.66992538073237 139.74881136646073 15 35.66992637309506 139.74881258049635 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2068d2ba-72d7-4963-a529-212a81446270">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2068d2ba-72d7-4963-a529-212a81446270">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2068d2ba-72d7-4963-a529-212a81446270">
											<gml:posList>35.66992136133967 139.74881240904037 6.41 35.66991235459201 139.7488223601111 6.41 35.66991235459201 139.7488223601111 15 35.66992136133967 139.74881240904037 15 35.66992136133967 139.74881240904037 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-698588b9-3513-4e05-bd3d-57262338be15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-698588b9-3513-4e05-bd3d-57262338be15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-698588b9-3513-4e05-bd3d-57262338be15">
											<gml:posList>35.66991235459201 139.7488223601111 6.41 35.669900001213925 139.74881585587738 6.41 35.669900001213925 139.74881585587738 15 35.66991235459201 139.7488223601111 15 35.66991235459201 139.7488223601111 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d59a0cc4-eb5f-4e66-9a49-9064de8872d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d59a0cc4-eb5f-4e66-9a49-9064de8872d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d59a0cc4-eb5f-4e66-9a49-9064de8872d8">
											<gml:posList>35.6699130340945 139.74882730809063 15 35.6699130340945 139.74882730809063 14.664 35.66992637309506 139.74881258049635 14.664 35.66992637309506 139.74881258049635 15 35.6699130340945 139.74882730809063 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0c121c8-2769-4b7c-8396-92aac36a0a9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0c121c8-2769-4b7c-8396-92aac36a0a9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0c121c8-2769-4b7c-8396-92aac36a0a9a">
											<gml:posList>35.66990166358488 139.74882133303743 15 35.66990166358488 139.74882133303743 14.664 35.6699130340945 139.74882730809063 14.664 35.6699130340945 139.74882730809063 15 35.66990166358488 139.74882133303743 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20d6158f-c0be-48f7-8682-72d542e3a388">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20d6158f-c0be-48f7-8682-72d542e3a388">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20d6158f-c0be-48f7-8682-72d542e3a388">
											<gml:posList>35.669900001213925 139.74881585587738 6.41 35.66988002570009 139.74886569525674 6.41 35.66988002570009 139.74886569525674 15 35.669900001213925 139.74881585587738 15 35.669900001213925 139.74881585587738 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a48396da-eccd-488c-b997-dfd6c9a961ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a48396da-eccd-488c-b997-dfd6c9a961ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a48396da-eccd-488c-b997-dfd6c9a961ca">
											<gml:posList>35.66988465738346 139.74886373520133 15 35.66988465738346 139.74886373520133 14.664 35.66990166358488 139.74882133303743 14.664 35.66990166358488 139.74882133303743 15 35.66988465738346 139.74886373520133 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-527b190e-832c-4798-bce0-b616d6318153">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-527b190e-832c-4798-bce0-b616d6318153">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-527b190e-832c-4798-bce0-b616d6318153">
											<gml:posList>35.66996668900358 139.7489117881337 15 35.66996668900358 139.7489117881337 14.664 35.66988465738346 139.74886373520133 14.664 35.66988465738346 139.74886373520133 15 35.66996668900358 139.7489117881337 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-184800aa-680b-48f8-9f51-60be3742a051">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-184800aa-680b-48f8-9f51-60be3742a051">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-184800aa-680b-48f8-9f51-60be3742a051">
											<gml:posList>35.66998293873506 139.74887033670717 15 35.66998293873506 139.74887033670717 14.664 35.66996668900358 139.7489117881337 14.664 35.66996668900358 139.7489117881337 15 35.66998293873506 139.74887033670717 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-360f6842-6c51-48f2-b045-8a4104fff6d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-360f6842-6c51-48f2-b045-8a4104fff6d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-360f6842-6c51-48f2-b045-8a4104fff6d2">
											<gml:posList>35.66988002570009 139.74886569525674 6.41 35.66996830640221 139.74891740894833 6.41 35.66996830640221 139.74891740894833 15 35.66988002570009 139.74886569525674 15 35.66988002570009 139.74886569525674 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffed25da-9111-46f4-8d38-30a41941d369">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffed25da-9111-46f4-8d38-30a41941d369">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffed25da-9111-46f4-8d38-30a41941d369">
											<gml:posList>35.66996830640221 139.74891740894833 6.41 35.66998576181316 139.74887287436061 6.41 35.66998576181316 139.74887287436061 15 35.66996830640221 139.74891740894833 15 35.66996830640221 139.74891740894833 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b8788b2-1005-45aa-86c7-8d833117cf7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b8788b2-1005-45aa-86c7-8d833117cf7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b8788b2-1005-45aa-86c7-8d833117cf7e">
											<gml:posList>35.6699862448432 139.7487391816209 15 35.6699862448432 139.7487391816209 14.664 35.67003981476328 139.7488052256415 14.664 35.67003981476328 139.7488052256415 15 35.6699862448432 139.7487391816209 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a04655c-f43f-4a78-9a18-4e072ef8383a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a04655c-f43f-4a78-9a18-4e072ef8383a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a04655c-f43f-4a78-9a18-4e072ef8383a">
											<gml:posList>35.66998576181316 139.74887287436061 6.41 35.67004475435451 139.74880531984985 6.41 35.67004475435451 139.74880531984985 15 35.66998576181316 139.74887287436061 15 35.66998576181316 139.74887287436061 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48915424-c236-4432-9350-ec49aa5bdf45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48915424-c236-4432-9350-ec49aa5bdf45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48915424-c236-4432-9350-ec49aa5bdf45">
											<gml:posList>35.67004475435451 139.74880531984985 6.41 35.66998629475813 139.74873324975562 6.41 35.66998629475813 139.74873324975562 15 35.67004475435451 139.74880531984985 15 35.67004475435451 139.74880531984985 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1462</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">89.04566</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>