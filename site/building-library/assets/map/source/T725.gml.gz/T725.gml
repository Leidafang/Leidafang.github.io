<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cf60f938-48a1-4d1b-929c-762e20af6a42">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66948294381989 139.7388347196642 0 35.66952321318572 139.7390365956651 0 35.66966712895242 139.73899378822895 0 35.6696267692046 139.73879169107087 0 35.66948294381989 139.7388347196642 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66948294381989 139.7388347196642 16.92 35.6696267692046 139.73879169107087 16.92 35.66966712895242 139.73899378822895 16.92 35.66952321318572 139.7390365956651 16.92 35.66948294381989 139.7388347196642 16.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66948294381989 139.7388347196642 16.92 35.66952321318572 139.7390365956651 16.92 35.66952321318572 139.7390365956651 31.44 35.66948294381989 139.7388347196642 31.44 35.66948294381989 139.7388347196642 16.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66952321318572 139.7390365956651 16.92 35.66966712895242 139.73899378822895 16.92 35.66966712895242 139.73899378822895 31.44 35.66952321318572 139.7390365956651 31.44 35.66952321318572 139.7390365956651 16.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66966712895242 139.73899378822895 16.92 35.6696267692046 139.73879169107087 16.92 35.6696267692046 139.73879169107087 31.44 35.66966712895242 139.73899378822895 31.44 35.66966712895242 139.73899378822895 16.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6696267692046 139.73879169107087 16.92 35.66948294381989 139.7388347196642 16.92 35.66948294381989 139.7388347196642 31.44 35.6696267692046 139.73879169107087 31.44 35.6696267692046 139.73879169107087 16.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66948294381989 139.7388347196642 31.44 35.66952321318572 139.7390365956651 31.44 35.66966712895242 139.73899378822895 31.44 35.6696267692046 139.73879169107087 31.44 35.66948294381989 139.7388347196642 31.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0e80952d-c473-41e0-bcf5-71da9c7f92b0"/>
							<gml:surfaceMember xlink:href="#poly-4ea24655-825a-41b4-bd48-b11147354924"/>
							<gml:surfaceMember xlink:href="#poly-374e3ff5-abee-4757-a63f-001fd9122256"/>
							<gml:surfaceMember xlink:href="#poly-6e11881a-5dbf-4a33-bf96-52304253feba"/>
							<gml:surfaceMember xlink:href="#poly-320f2ef1-aac6-444f-b353-fa58c5dbe9c7"/>
							<gml:surfaceMember xlink:href="#poly-f965e6f5-05dc-4507-ae92-640f55fe9cc3"/>
							<gml:surfaceMember xlink:href="#poly-6964b18a-16b8-45de-b763-76bbd9721314"/>
							<gml:surfaceMember xlink:href="#poly-ee026615-613c-4400-b66b-08e538e91363"/>
							<gml:surfaceMember xlink:href="#poly-3f107b8f-c2aa-48f1-873c-da98abbe30cf"/>
							<gml:surfaceMember xlink:href="#poly-3bea3997-8a33-485d-bed4-3619a3a6e36d"/>
							<gml:surfaceMember xlink:href="#poly-4a0cf095-166c-4f69-a37d-2ec4768204c2"/>
							<gml:surfaceMember xlink:href="#poly-fca1a36d-098b-4315-924e-8e86e591b058"/>
							<gml:surfaceMember xlink:href="#poly-1eb8f067-4c7c-43f2-939d-280f5c7f48c4"/>
							<gml:surfaceMember xlink:href="#poly-122b0e76-0e2d-48ff-a270-bb96441a6c31"/>
							<gml:surfaceMember xlink:href="#poly-62375832-ba0d-4ec3-9e41-9756b7c794b3"/>
							<gml:surfaceMember xlink:href="#poly-50df29ef-296e-4a12-8cd0-f3885f11337d"/>
							<gml:surfaceMember xlink:href="#poly-314c2559-0c01-40f5-bdc1-94f9c11291d0"/>
							<gml:surfaceMember xlink:href="#poly-65be8915-f61f-4652-ace0-509859e9367a"/>
							<gml:surfaceMember xlink:href="#poly-28bbb267-fa55-4501-8e2d-5071b161b969"/>
							<gml:surfaceMember xlink:href="#poly-73589215-e2d3-4bed-ba1f-a0242056d04e"/>
							<gml:surfaceMember xlink:href="#poly-a1ea9034-3424-4c4d-b1b0-eeb1410bd0d6"/>
							<gml:surfaceMember xlink:href="#poly-dc227785-6d6b-4efd-a0ad-8e6453200349"/>
							<gml:surfaceMember xlink:href="#poly-d05e7b24-96c5-45e2-9eb6-28923f25ace7"/>
							<gml:surfaceMember xlink:href="#poly-78a78989-61e4-4289-8d5a-d26bed581f4f"/>
							<gml:surfaceMember xlink:href="#poly-9dc65340-1108-4e0b-9138-85906e03e5ac"/>
							<gml:surfaceMember xlink:href="#poly-4fb69fd7-6630-4e88-b279-3116a2ef3a5e"/>
							<gml:surfaceMember xlink:href="#poly-debb398f-1beb-4c8d-8f48-966700070dd6"/>
							<gml:surfaceMember xlink:href="#poly-41295120-dbee-4d5a-85d3-08f124256cd5"/>
							<gml:surfaceMember xlink:href="#poly-4969e8ed-3bbd-4a1e-8cd4-a3e748629e45"/>
							<gml:surfaceMember xlink:href="#poly-9521abc8-ac09-4825-a093-aee4a87d9cc4"/>
							<gml:surfaceMember xlink:href="#poly-f029293c-fe76-4ffe-bc45-b650738b4b7c"/>
							<gml:surfaceMember xlink:href="#poly-53e60cfa-0a22-4265-910e-2e339d446d88"/>
							<gml:surfaceMember xlink:href="#poly-16a3400b-f2d8-4280-9f57-6a9f380b1ba3"/>
							<gml:surfaceMember xlink:href="#poly-96a884ea-d107-4d17-b191-fa9ddefb8fd5"/>
							<gml:surfaceMember xlink:href="#poly-37f889f4-a05d-41b9-9e19-0e3534061059"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_cf60f938-48a1-4d1b-929c-762e20af6a42_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27ab7e63-3f5a-479a-824a-18d143ca97ab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66954959070125 139.73887984194022 31.286 35.66955234209306 139.7388941434571 31.286 35.6695443397085 139.7388964504806 31.286 35.66954159733069 139.73888214895445 31.286 35.66954959070125 139.73887984194022 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cba80b5-f149-44a5-8f3c-ef1d66c6db13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66957215564696 139.7388843995097 31.286 35.669574454515484 139.73889635978028 31.286 35.669566479172076 139.73889866677237 31.286 35.669564180295126 139.73888669545676 31.286 35.66957215564696 139.7388843995097 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d3487d6-2667-46a8-a8bf-a21ac1305273">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66964706262812 139.73896853822885 35.678 35.66964938826979 139.73898016709677 35.678 35.669630562998385 139.73898580069704 35.678 35.669628246379645 139.73897418286722 35.678 35.66964706262812 139.73896853822885 35.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b965693-a34d-4986-8825-f65c9bb2bbf3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b965693-a34d-4986-8825-f65c9bb2bbf3_0">
											<gml:posList>35.66954959070125 139.73887984194022 31.286 35.66954159733069 139.73888214895445 31.286 35.66954159733069 139.73888214895445 33.591 35.66954959070125 139.73887984194022 33.591 35.66954959070125 139.73887984194022 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9574741f-d6f6-441b-b8d5-47b58bcad95a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9574741f-d6f6-441b-b8d5-47b58bcad95a_0">
											<gml:posList>35.66957215564696 139.7388843995097 31.286 35.669564180295126 139.73888669545676 31.286 35.669564180295126 139.73888669545676 33.591 35.66957215564696 139.7388843995097 33.591 35.66957215564696 139.7388843995097 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-000bed55-871a-4f77-9785-b2fb2d3f3b03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-000bed55-871a-4f77-9785-b2fb2d3f3b03_0">
											<gml:posList>35.66955234209306 139.7388941434571 31.286 35.66954959070125 139.73887984194022 31.286 35.66954959070125 139.73887984194022 33.591 35.66955234209306 139.7388941434571 33.591 35.66955234209306 139.7388941434571 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f0f237f-f583-4617-9a1b-61830d71fc42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f0f237f-f583-4617-9a1b-61830d71fc42_0">
											<gml:posList>35.66954959070125 139.73887984194022 33.591 35.66954159733069 139.73888214895445 33.591 35.6695443397085 139.7388964504806 33.591 35.66955234209306 139.7388941434571 33.591 35.66954959070125 139.73887984194022 33.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38d751f7-c907-49e4-b33b-2b7dfe815dab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38d751f7-c907-49e4-b33b-2b7dfe815dab_0">
											<gml:posList>35.66954159733069 139.73888214895445 31.286 35.6695443397085 139.7388964504806 31.286 35.6695443397085 139.7388964504806 33.591 35.66954159733069 139.73888214895445 33.591 35.66954159733069 139.73888214895445 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efa63bb2-32ab-4825-8c6a-9d945c305b9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efa63bb2-32ab-4825-8c6a-9d945c305b9e_0">
											<gml:posList>35.669574454515484 139.73889635978028 31.286 35.66957215564696 139.7388843995097 31.286 35.66957215564696 139.7388843995097 33.591 35.669574454515484 139.73889635978028 33.591 35.669574454515484 139.73889635978028 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da9bd577-9200-4d0a-818c-1184ba389e3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da9bd577-9200-4d0a-818c-1184ba389e3a_0">
											<gml:posList>35.669566479172076 139.73889866677237 33.591 35.669574454515484 139.73889635978028 33.591 35.66957215564696 139.7388843995097 33.591 35.669564180295126 139.73888669545676 33.591 35.669566479172076 139.73889866677237 33.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa71ed93-eac6-4484-9730-56cf6f3f573a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa71ed93-eac6-4484-9730-56cf6f3f573a_0">
											<gml:posList>35.669564180295126 139.73888669545676 31.286 35.669566479172076 139.73889866677237 31.286 35.669566479172076 139.73889866677237 33.591 35.669564180295126 139.73888669545676 33.591 35.669564180295126 139.73888669545676 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99066985-3fac-48ff-b94c-22e9cc2399fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99066985-3fac-48ff-b94c-22e9cc2399fd_0">
											<gml:posList>35.6695443397085 139.7388964504806 31.286 35.66955234209306 139.7388941434571 31.286 35.66955234209306 139.7388941434571 33.591 35.6695443397085 139.7388964504806 33.591 35.6695443397085 139.7388964504806 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61f1b1e9-c7ea-48cf-ae8d-47b3a746eb93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61f1b1e9-c7ea-48cf-ae8d-47b3a746eb93_0">
											<gml:posList>35.669566479172076 139.73889866677237 31.286 35.669574454515484 139.73889635978028 31.286 35.669574454515484 139.73889635978028 33.591 35.669566479172076 139.73889866677237 33.591 35.669566479172076 139.73889866677237 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f06a904-419c-4cb6-9a64-a362ef0f8d34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f06a904-419c-4cb6-9a64-a362ef0f8d34_0">
											<gml:posList>35.669628246379645 139.73897418286722 35.678 35.669628246379645 139.73897418286722 36.532 35.66964706262812 139.73896853822885 36.532 35.66964706262812 139.73896853822885 35.678 35.669628246379645 139.73897418286722 35.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66b57452-dc45-45e9-8afa-f92b9e51e677">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66b57452-dc45-45e9-8afa-f92b9e51e677_0">
											<gml:posList>35.66964938826979 139.73898016709677 35.678 35.66964706262812 139.73896853822885 35.678 35.66964706262812 139.73896853822885 36.532 35.66964938826979 139.73898016709677 36.532 35.66964938826979 139.73898016709677 35.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24222d50-3a1f-49fb-b9ee-6b395b2195ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24222d50-3a1f-49fb-b9ee-6b395b2195ed_0">
											<gml:posList>35.669630562998385 139.73898580069704 36.532 35.66964938826979 139.73898016709677 36.532 35.66964706262812 139.73896853822885 36.532 35.669628246379645 139.73897418286722 36.532 35.669630562998385 139.73898580069704 36.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05ae8571-ed40-4e55-af40-3a2fe5418af9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05ae8571-ed40-4e55-af40-3a2fe5418af9_0">
											<gml:posList>35.669628246379645 139.73897418286722 35.678 35.669630562998385 139.73898580069704 35.678 35.669630562998385 139.73898580069704 36.532 35.669628246379645 139.73897418286722 36.532 35.669628246379645 139.73897418286722 35.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85c34fd3-de16-4fbe-9354-dc0306f61dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85c34fd3-de16-4fbe-9354-dc0306f61dd4_0">
											<gml:posList>35.669630562998385 139.73898580069704 35.678 35.66964938826979 139.73898016709677 35.678 35.66964938826979 139.73898016709677 36.532 35.669630562998385 139.73898580069704 36.532 35.669630562998385 139.73898580069704 35.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_cf60f938-48a1-4d1b-929c-762e20af6a42_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-278cea05-a9f2-4c69-b2c8-733476fab77d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66960528879576 139.73890569060057 31.286 35.669599768756925 139.73887807067595 31.286 35.66962275737571 139.738871172886 31.286 35.66962827741611 139.73889879281808 31.286 35.66960528879576 139.73890569060057 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7342433b-e10f-4db8-aa01-f9470c5678ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7342433b-e10f-4db8-aa01-f9470c5678ff_0">
											<gml:posList>35.669599768756925 139.73887807067595 31.286 35.669599768756925 139.73887807067595 34.595 35.66962275737571 139.738871172886 34.595 35.66962275737571 139.738871172886 31.286 35.669599768756925 139.73887807067595 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c477122-2872-4e1f-a864-5e53d2543415">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c477122-2872-4e1f-a864-5e53d2543415_0">
											<gml:posList>35.66962275737571 139.738871172886 31.286 35.66962275737571 139.738871172886 34.595 35.66962827741611 139.73889879281808 34.595 35.66962827741611 139.73889879281808 31.286 35.66962275737571 139.738871172886 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d81bb355-0088-4055-a099-7390cea059e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d81bb355-0088-4055-a099-7390cea059e7_0">
											<gml:posList>35.66960528879576 139.73890569060057 34.595 35.66962827741611 139.73889879281808 34.595 35.66962275737571 139.738871172886 34.595 35.669599768756925 139.73887807067595 34.595 35.66960528879576 139.73890569060057 34.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-731904e5-2481-48cf-b56c-fdf6c1eb43fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-731904e5-2481-48cf-b56c-fdf6c1eb43fe_0">
											<gml:posList>35.66960528879576 139.73890569060057 31.286 35.66960528879576 139.73890569060057 34.595 35.669599768756925 139.73887807067595 34.595 35.669599768756925 139.73887807067595 31.286 35.66960528879576 139.73890569060057 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1f1045c-dd77-4aec-a95c-a60154afb7d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1f1045c-dd77-4aec-a95c-a60154afb7d4_0">
											<gml:posList>35.66962827741611 139.73889879281808 31.286 35.66962827741611 139.73889879281808 34.595 35.66960528879576 139.73890569060057 34.595 35.66960528879576 139.73890569060057 31.286 35.66962827741611 139.73889879281808 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0e80952d-c473-41e0-bcf5-71da9c7f92b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e80952d-c473-41e0-bcf5-71da9c7f92b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e80952d-c473-41e0-bcf5-71da9c7f92b0">
											<gml:posList>35.669482943819894 139.7388347196642 16.92 35.6696267692046 139.73879169107087 16.92 35.669667128952426 139.73899378822892 16.92 35.6695232131857 139.7390365956651 16.92 35.669482943819894 139.7388347196642 16.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ea24655-825a-41b4-bd48-b11147354924">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ea24655-825a-41b4-bd48-b11147354924">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ea24655-825a-41b4-bd48-b11147354924">
											<gml:posList>35.669504742919884 139.7388281988427 32.019 35.66951061429559 139.73883257723972 32.019 35.66962320541586 139.7387988863199 32.019 35.6696267692046 139.73879169107087 32.019 35.669504742919884 139.7388281988427 32.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-374e3ff5-abee-4757-a63f-001fd9122256">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-374e3ff5-abee-4757-a63f-001fd9122256">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-374e3ff5-abee-4757-a63f-001fd9122256">
											<gml:posList>35.669504742919884 139.7388281988427 25.168 35.669482943819894 139.7388347196642 25.168 35.66948878812821 139.73883906495396 25.168 35.66950589218805 139.73883396357255 25.168 35.669504742919884 139.7388281988427 25.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e11881a-5dbf-4a33-bf96-52304253feba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e11881a-5dbf-4a33-bf96-52304253feba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e11881a-5dbf-4a33-bf96-52304253feba">
											<gml:posList>35.66965310262861 139.7389235622065 32.019 35.6696267692046 139.73879169107087 32.019 35.66962320541586 139.7387988863199 32.019 35.669648389559825 139.73892498166433 32.019 35.66965310262861 139.7389235622065 32.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-320f2ef1-aac6-444f-b353-fa58c5dbe9c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-320f2ef1-aac6-444f-b353-fa58c5dbe9c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-320f2ef1-aac6-444f-b353-fa58c5dbe9c7">
											<gml:posList>35.66954854010485 139.73902295702877 31.286 35.66962239027265 139.73900078889992 31.286 35.66960957653734 139.73893661477965 31.286 35.669648389559825 139.73892498166433 31.286 35.66962320541586 139.7387988863199 31.286 35.66951061429559 139.73883257723972 31.286 35.66954854010485 139.73902295702877 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f965e6f5-05dc-4507-ae92-640f55fe9cc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f965e6f5-05dc-4507-ae92-640f55fe9cc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f965e6f5-05dc-4507-ae92-640f55fe9cc3">
											<gml:posList>35.6695449672712 139.73903013017886 32.019 35.66954854010485 139.73902295702877 32.019 35.66951061429559 139.73883257723972 32.019 35.669504742919884 139.7388281988427 32.019 35.6695449672712 139.73903013017886 32.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6964b18a-16b8-45de-b763-76bbd9721314">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6964b18a-16b8-45de-b763-76bbd9721314">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6964b18a-16b8-45de-b763-76bbd9721314">
											<gml:posList>35.66954381800378 139.7390243543972 24.471 35.66950589218805 139.73883396357255 24.471 35.66948878812821 139.73883906495396 24.471 35.66952675898724 139.7390294335952 24.471 35.66954381800378 139.7390243543972 24.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee026615-613c-4400-b66b-08e538e91363">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee026615-613c-4400-b66b-08e538e91363">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee026615-613c-4400-b66b-08e538e91363">
											<gml:posList>35.66960957653734 139.73893661477965 36.181 35.669615745535076 139.738941213763 36.181 35.66964934983826 139.73893113324394 36.181 35.66965310262861 139.7389235622065 36.181 35.66960957653734 139.73893661477965 36.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f107b8f-c2aa-48f1-873c-da98abbe30cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f107b8f-c2aa-48f1-873c-da98abbe30cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f107b8f-c2aa-48f1-873c-da98abbe30cf">
											<gml:posList>35.6695232131857 139.7390365956651 25.168 35.66952675898724 139.7390294335952 25.168 35.66948878812821 139.73883906495396 25.168 35.669482943819894 139.7388347196642 25.168 35.6695232131857 139.7390365956651 25.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3bea3997-8a33-485d-bed4-3619a3a6e36d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bea3997-8a33-485d-bed4-3619a3a6e36d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bea3997-8a33-485d-bed4-3619a3a6e36d">
											<gml:posList>35.66965310262861 139.7389235622065 36.181 35.66964934983826 139.73893113324394 36.181 35.669659747374915 139.73898313736967 36.181 35.66966592538456 139.7389877363489 36.181 35.66965310262861 139.7389235622065 36.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a0cf095-166c-4f69-a37d-2ec4768204c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a0cf095-166c-4f69-a37d-2ec4768204c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a0cf095-166c-4f69-a37d-2ec4768204c2">
											<gml:posList>35.669659747374915 139.73898313736967 35.678 35.66964934983826 139.73893113324394 35.678 35.669615745535076 139.738941213763 35.678 35.66962613405368 139.73899321787889 35.678 35.669659747374915 139.73898313736967 35.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fca1a36d-098b-4315-924e-8e86e591b058">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fca1a36d-098b-4315-924e-8e86e591b058">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fca1a36d-098b-4315-924e-8e86e591b058">
											<gml:posList>35.66962239027265 139.73900078889992 36.181 35.66962613405368 139.73899321787889 36.181 35.669615745535076 139.738941213763 36.181 35.66960957653734 139.73893661477965 36.181 35.66962239027265 139.73900078889992 36.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1eb8f067-4c7c-43f2-939d-280f5c7f48c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1eb8f067-4c7c-43f2-939d-280f5c7f48c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1eb8f067-4c7c-43f2-939d-280f5c7f48c4">
											<gml:posList>35.66966592538456 139.7389877363489 36.181 35.669659747374915 139.73898313736967 36.181 35.66962613405368 139.73899321787889 36.181 35.66962239027265 139.73900078889992 36.181 35.66966592538456 139.7389877363489 36.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-122b0e76-0e2d-48ff-a270-bb96441a6c31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-122b0e76-0e2d-48ff-a270-bb96441a6c31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-122b0e76-0e2d-48ff-a270-bb96441a6c31">
											<gml:posList>35.669667128952426 139.73899378822892 32.019 35.66966592538456 139.7389877363489 32.019 35.66962239027265 139.73900078889992 32.019 35.669667128952426 139.73899378822892 32.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62375832-ba0d-4ec3-9e41-9756b7c794b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62375832-ba0d-4ec3-9e41-9756b7c794b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62375832-ba0d-4ec3-9e41-9756b7c794b3">
											<gml:posList>35.6695449672712 139.73903013017886 32.019 35.669667128952426 139.73899378822892 32.019 35.66962239027265 139.73900078889992 32.019 35.66954854010485 139.73902295702877 32.019 35.6695449672712 139.73903013017886 32.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50df29ef-296e-4a12-8cd0-f3885f11337d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50df29ef-296e-4a12-8cd0-f3885f11337d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50df29ef-296e-4a12-8cd0-f3885f11337d">
											<gml:posList>35.6695449672712 139.73903013017886 25.168 35.66954381800378 139.7390243543972 25.168 35.66952675898724 139.7390294335952 25.168 35.6695232131857 139.7390365956651 25.168 35.6695449672712 139.73903013017886 25.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-314c2559-0c01-40f5-bdc1-94f9c11291d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-314c2559-0c01-40f5-bdc1-94f9c11291d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-314c2559-0c01-40f5-bdc1-94f9c11291d0">
											<gml:posList>35.66962613405368 139.73899321787889 36.181 35.66962613405368 139.73899321787889 35.678 35.669615745535076 139.738941213763 35.678 35.669615745535076 139.738941213763 36.181 35.66962613405368 139.73899321787889 36.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65be8915-f61f-4652-ace0-509859e9367a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65be8915-f61f-4652-ace0-509859e9367a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65be8915-f61f-4652-ace0-509859e9367a">
											<gml:posList>35.669659747374915 139.73898313736967 36.181 35.669659747374915 139.73898313736967 35.678 35.66962613405368 139.73899321787889 35.678 35.66962613405368 139.73899321787889 36.181 35.669659747374915 139.73898313736967 36.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28bbb267-fa55-4501-8e2d-5071b161b969">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28bbb267-fa55-4501-8e2d-5071b161b969">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28bbb267-fa55-4501-8e2d-5071b161b969">
											<gml:posList>35.66966592538456 139.7389877363489 32.019 35.66966592538456 139.7389877363489 36.181 35.66962239027265 139.73900078889992 36.181 35.66962239027265 139.73900078889992 32.019 35.66966592538456 139.7389877363489 32.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73589215-e2d3-4bed-ba1f-a0242056d04e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73589215-e2d3-4bed-ba1f-a0242056d04e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73589215-e2d3-4bed-ba1f-a0242056d04e">
											<gml:posList>35.66965310262861 139.7389235622065 32.019 35.66965310262861 139.7389235622065 36.181 35.66966592538456 139.7389877363489 36.181 35.66966592538456 139.7389877363489 32.019 35.669667128952426 139.73899378822892 32.019 35.669667128952426 139.73899378822892 16.92 35.6696267692046 139.73879169107087 16.92 35.6696267692046 139.73879169107087 32.019 35.66965310262861 139.7389235622065 32.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1ea9034-3424-4c4d-b1b0-eeb1410bd0d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1ea9034-3424-4c4d-b1b0-eeb1410bd0d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1ea9034-3424-4c4d-b1b0-eeb1410bd0d6">
											<gml:posList>35.66964934983826 139.73893113324394 36.181 35.66964934983826 139.73893113324394 35.678 35.669659747374915 139.73898313736967 35.678 35.669659747374915 139.73898313736967 36.181 35.66964934983826 139.73893113324394 36.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc227785-6d6b-4efd-a0ad-8e6453200349">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc227785-6d6b-4efd-a0ad-8e6453200349">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc227785-6d6b-4efd-a0ad-8e6453200349">
											<gml:posList>35.669482943819894 139.7388347196642 16.92 35.669482943819894 139.7388347196642 25.168 35.669504742919884 139.7388281988427 25.168 35.669504742919884 139.7388281988427 32.019 35.6696267692046 139.73879169107087 32.019 35.6696267692046 139.73879169107087 16.92 35.669482943819894 139.7388347196642 16.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d05e7b24-96c5-45e2-9eb6-28923f25ace7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d05e7b24-96c5-45e2-9eb6-28923f25ace7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d05e7b24-96c5-45e2-9eb6-28923f25ace7">
											<gml:posList>35.66951061429559 139.73883257723972 32.019 35.66951061429559 139.73883257723972 31.286 35.66962320541586 139.7387988863199 31.286 35.66962320541586 139.7387988863199 32.019 35.66951061429559 139.73883257723972 32.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78a78989-61e4-4289-8d5a-d26bed581f4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78a78989-61e4-4289-8d5a-d26bed581f4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78a78989-61e4-4289-8d5a-d26bed581f4f">
											<gml:posList>35.66948878812821 139.73883906495396 25.168 35.66948878812821 139.73883906495396 24.471 35.66950589218805 139.73883396357255 24.471 35.66950589218805 139.73883396357255 25.168 35.66948878812821 139.73883906495396 25.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9dc65340-1108-4e0b-9138-85906e03e5ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dc65340-1108-4e0b-9138-85906e03e5ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dc65340-1108-4e0b-9138-85906e03e5ac">
											<gml:posList>35.66962320541586 139.7387988863199 32.019 35.66962320541586 139.7387988863199 31.286 35.669648389559825 139.73892498166433 31.286 35.669648389559825 139.73892498166433 32.019 35.66962320541586 139.7387988863199 32.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fb69fd7-6630-4e88-b279-3116a2ef3a5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fb69fd7-6630-4e88-b279-3116a2ef3a5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fb69fd7-6630-4e88-b279-3116a2ef3a5e">
											<gml:posList>35.66954854010485 139.73902295702877 32.019 35.66954854010485 139.73902295702877 31.286 35.66951061429559 139.73883257723972 31.286 35.66951061429559 139.73883257723972 32.019 35.66954854010485 139.73902295702877 32.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-debb398f-1beb-4c8d-8f48-966700070dd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-debb398f-1beb-4c8d-8f48-966700070dd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-debb398f-1beb-4c8d-8f48-966700070dd6">
											<gml:posList>35.66950589218805 139.73883396357255 25.168 35.66950589218805 139.73883396357255 24.471 35.66954381800378 139.7390243543972 24.471 35.66954381800378 139.7390243543972 25.168 35.6695449672712 139.73903013017886 25.168 35.6695449672712 139.73903013017886 32.019 35.669504742919884 139.7388281988427 32.019 35.669504742919884 139.7388281988427 25.168 35.66950589218805 139.73883396357255 25.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41295120-dbee-4d5a-85d3-08f124256cd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41295120-dbee-4d5a-85d3-08f124256cd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41295120-dbee-4d5a-85d3-08f124256cd5">
											<gml:posList>35.66960957653734 139.73893661477965 31.286 35.66960957653734 139.73893661477965 36.181 35.66965310262861 139.7389235622065 36.181 35.66965310262861 139.7389235622065 32.019 35.669648389559825 139.73892498166433 32.019 35.669648389559825 139.73892498166433 31.286 35.66960957653734 139.73893661477965 31.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4969e8ed-3bbd-4a1e-8cd4-a3e748629e45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4969e8ed-3bbd-4a1e-8cd4-a3e748629e45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4969e8ed-3bbd-4a1e-8cd4-a3e748629e45">
											<gml:posList>35.66952675898724 139.7390294335952 25.168 35.66952675898724 139.7390294335952 24.471 35.66948878812821 139.73883906495396 24.471 35.66948878812821 139.73883906495396 25.168 35.66952675898724 139.7390294335952 25.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9521abc8-ac09-4825-a093-aee4a87d9cc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9521abc8-ac09-4825-a093-aee4a87d9cc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9521abc8-ac09-4825-a093-aee4a87d9cc4">
											<gml:posList>35.669482943819894 139.7388347196642 16.92 35.6695232131857 139.7390365956651 16.92 35.6695232131857 139.7390365956651 25.168 35.669482943819894 139.7388347196642 25.168 35.669482943819894 139.7388347196642 16.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f029293c-fe76-4ffe-bc45-b650738b4b7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f029293c-fe76-4ffe-bc45-b650738b4b7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f029293c-fe76-4ffe-bc45-b650738b4b7c">
											<gml:posList>35.669615745535076 139.738941213763 36.181 35.669615745535076 139.738941213763 35.678 35.66964934983826 139.73893113324394 35.678 35.66964934983826 139.73893113324394 36.181 35.669615745535076 139.738941213763 36.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53e60cfa-0a22-4265-910e-2e339d446d88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53e60cfa-0a22-4265-910e-2e339d446d88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53e60cfa-0a22-4265-910e-2e339d446d88">
											<gml:posList>35.66960957653734 139.73893661477965 36.181 35.66960957653734 139.73893661477965 31.286 35.66962239027265 139.73900078889992 31.286 35.66962239027265 139.73900078889992 32.019 35.66962239027265 139.73900078889992 36.181 35.66960957653734 139.73893661477965 36.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16a3400b-f2d8-4280-9f57-6a9f380b1ba3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16a3400b-f2d8-4280-9f57-6a9f380b1ba3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16a3400b-f2d8-4280-9f57-6a9f380b1ba3">
											<gml:posList>35.66962239027265 139.73900078889992 32.019 35.66962239027265 139.73900078889992 31.286 35.66954854010485 139.73902295702877 31.286 35.66954854010485 139.73902295702877 32.019 35.66962239027265 139.73900078889992 32.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96a884ea-d107-4d17-b191-fa9ddefb8fd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96a884ea-d107-4d17-b191-fa9ddefb8fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96a884ea-d107-4d17-b191-fa9ddefb8fd5">
											<gml:posList>35.669667128952426 139.73899378822892 16.92 35.669667128952426 139.73899378822892 32.019 35.6695449672712 139.73903013017886 32.019 35.6695449672712 139.73903013017886 25.168 35.6695232131857 139.7390365956651 25.168 35.6695232131857 139.7390365956651 16.92 35.669667128952426 139.73899378822892 16.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37f889f4-a05d-41b9-9e19-0e3534061059">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37f889f4-a05d-41b9-9e19-0e3534061059">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37f889f4-a05d-41b9-9e19-0e3534061059">
											<gml:posList>35.66954381800378 139.7390243543972 25.168 35.66954381800378 139.7390243543972 24.471 35.66952675898724 139.7390294335952 24.471 35.66952675898724 139.7390294335952 25.168 35.66954381800378 139.7390243543972 25.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6005</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">309.24275</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.07</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>