<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d2a4270b-ac73-4764-8a5c-b6b0aadeefae">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">34</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.674987831431004 139.741427233661 0 35.675003350323585 139.74109359959334 0 35.674775587057624 139.74099366659865 0 35.67476775347983 139.7411575116628 0 35.6747635128323 139.74124626704014 0 35.674755980603464 139.7414038591856 0 35.674987831431004 139.741427233661 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674987831431004 139.741427233661 9.36 35.674755980603464 139.7414038591856 9.36 35.6747635128323 139.74124626704014 9.36 35.67476775347983 139.7411575116628 9.36 35.674775587057624 139.74099366659865 9.36 35.675003350323585 139.74109359959334 9.36 35.674987831431004 139.741427233661 9.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674987831431004 139.741427233661 9.36 35.675003350323585 139.74109359959334 9.36 35.675003350323585 139.74109359959334 40.63 35.674987831431004 139.741427233661 40.63 35.674987831431004 139.741427233661 9.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.675003350323585 139.74109359959334 9.36 35.674775587057624 139.74099366659865 9.36 35.674775587057624 139.74099366659865 40.63 35.675003350323585 139.74109359959334 40.63 35.675003350323585 139.74109359959334 9.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674775587057624 139.74099366659865 9.36 35.67476775347983 139.7411575116628 9.36 35.67476775347983 139.7411575116628 40.63 35.674775587057624 139.74099366659865 40.63 35.674775587057624 139.74099366659865 9.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67476775347983 139.7411575116628 9.36 35.6747635128323 139.74124626704014 9.36 35.6747635128323 139.74124626704014 40.63 35.67476775347983 139.7411575116628 40.63 35.67476775347983 139.7411575116628 9.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6747635128323 139.74124626704014 9.36 35.674755980603464 139.7414038591856 9.36 35.674755980603464 139.7414038591856 40.63 35.6747635128323 139.74124626704014 40.63 35.6747635128323 139.74124626704014 9.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674755980603464 139.7414038591856 9.36 35.674987831431004 139.741427233661 9.36 35.674987831431004 139.741427233661 40.63 35.674755980603464 139.7414038591856 40.63 35.674755980603464 139.7414038591856 9.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674987831431004 139.741427233661 40.63 35.675003350323585 139.74109359959334 40.63 35.674775587057624 139.74099366659865 40.63 35.67476775347983 139.7411575116628 40.63 35.6747635128323 139.74124626704014 40.63 35.674755980603464 139.7414038591856 40.63 35.674987831431004 139.741427233661 40.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-961b1e81-5786-4398-ac47-9fff0a90cc79"/>
							<gml:surfaceMember xlink:href="#poly-95f03f63-44b9-4cc9-b923-257af34b9bd3"/>
							<gml:surfaceMember xlink:href="#poly-a6cbf42e-fff5-4b4e-adfa-b591be527022"/>
							<gml:surfaceMember xlink:href="#poly-8d9eb032-ff29-437a-adc1-dfce0ed4f665"/>
							<gml:surfaceMember xlink:href="#poly-a33aa033-7c53-4a91-a7d6-559e26591cfb"/>
							<gml:surfaceMember xlink:href="#poly-18c5da5e-a841-4112-b5d1-1d217f01a130"/>
							<gml:surfaceMember xlink:href="#poly-668856b7-c31e-4aeb-8f48-3cd1acadff4c"/>
							<gml:surfaceMember xlink:href="#poly-af45d52b-4b5f-491d-9c4b-f1e1dcc42468"/>
							<gml:surfaceMember xlink:href="#poly-18cbfc92-9dd7-4786-8409-39af1a379c4f"/>
							<gml:surfaceMember xlink:href="#poly-99153452-6074-4f7d-9e8a-2f7c48d9fe01"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-961b1e81-5786-4398-ac47-9fff0a90cc79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-961b1e81-5786-4398-ac47-9fff0a90cc79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-961b1e81-5786-4398-ac47-9fff0a90cc79">
											<gml:posList>35.675003350323585 139.7410935995933 9.36 35.67498783143099 139.741427233661 9.36 35.67475598060346 139.7414038591856 9.36 35.67477558705761 139.74099366659865 9.36 35.675003350323585 139.7410935995933 9.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-95f03f63-44b9-4cc9-b923-257af34b9bd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95f03f63-44b9-4cc9-b923-257af34b9bd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95f03f63-44b9-4cc9-b923-257af34b9bd3">
											<gml:posList>35.6747635128323 139.7412462670401 43.386 35.674859595390025 139.7412531603872 43.386 35.674863836050854 139.74116441595072 43.386 35.67476775347981 139.7411575116628 43.386 35.6747635128323 139.7412462670401 43.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6cbf42e-fff5-4b4e-adfa-b591be527022">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6cbf42e-fff5-4b4e-adfa-b591be527022">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6cbf42e-fff5-4b4e-adfa-b591be527022">
											<gml:posList>35.6747635128323 139.7412462670401 38 35.67475598060346 139.7414038591856 38 35.67498783143099 139.741427233661 38 35.675003350323585 139.7410935995933 38 35.67477558705761 139.74099366659865 38 35.67476775347981 139.7411575116628 38 35.674863836050854 139.74116441595072 38 35.674859595390025 139.7412531603872 38 35.6747635128323 139.7412462670401 38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d9eb032-ff29-437a-adc1-dfce0ed4f665">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d9eb032-ff29-437a-adc1-dfce0ed4f665">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d9eb032-ff29-437a-adc1-dfce0ed4f665">
											<gml:posList>35.675003350323585 139.7410935995933 9.36 35.67477558705761 139.74099366659865 9.36 35.67477558705761 139.74099366659865 38 35.675003350323585 139.7410935995933 38 35.675003350323585 139.7410935995933 9.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a33aa033-7c53-4a91-a7d6-559e26591cfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a33aa033-7c53-4a91-a7d6-559e26591cfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a33aa033-7c53-4a91-a7d6-559e26591cfb">
											<gml:posList>35.67476775347981 139.7411575116628 38 35.67476775347981 139.7411575116628 43.386 35.674863836050854 139.74116441595072 43.386 35.674863836050854 139.74116441595072 38 35.67476775347981 139.7411575116628 38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18c5da5e-a841-4112-b5d1-1d217f01a130">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18c5da5e-a841-4112-b5d1-1d217f01a130">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18c5da5e-a841-4112-b5d1-1d217f01a130">
											<gml:posList>35.67475598060346 139.7414038591856 9.36 35.67475598060346 139.7414038591856 38 35.6747635128323 139.7412462670401 38 35.6747635128323 139.7412462670401 43.386 35.67476775347981 139.7411575116628 43.386 35.67476775347981 139.7411575116628 38 35.67477558705761 139.74099366659865 38 35.67477558705761 139.74099366659865 9.36 35.67475598060346 139.7414038591856 9.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-668856b7-c31e-4aeb-8f48-3cd1acadff4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-668856b7-c31e-4aeb-8f48-3cd1acadff4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-668856b7-c31e-4aeb-8f48-3cd1acadff4c">
											<gml:posList>35.674863836050854 139.74116441595072 38 35.674863836050854 139.74116441595072 43.386 35.674859595390025 139.7412531603872 43.386 35.674859595390025 139.7412531603872 38 35.674863836050854 139.74116441595072 38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af45d52b-4b5f-491d-9c4b-f1e1dcc42468">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af45d52b-4b5f-491d-9c4b-f1e1dcc42468">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af45d52b-4b5f-491d-9c4b-f1e1dcc42468">
											<gml:posList>35.674859595390025 139.7412531603872 38 35.674859595390025 139.7412531603872 43.386 35.6747635128323 139.7412462670401 43.386 35.6747635128323 139.7412462670401 38 35.674859595390025 139.7412531603872 38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18cbfc92-9dd7-4786-8409-39af1a379c4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18cbfc92-9dd7-4786-8409-39af1a379c4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18cbfc92-9dd7-4786-8409-39af1a379c4f">
											<gml:posList>35.67498783143099 139.741427233661 9.36 35.675003350323585 139.7410935995933 9.36 35.675003350323585 139.7410935995933 38 35.67498783143099 139.741427233661 38 35.67498783143099 139.741427233661 9.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99153452-6074-4f7d-9e8a-2f7c48d9fe01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99153452-6074-4f7d-9e8a-2f7c48d9fe01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99153452-6074-4f7d-9e8a-2f7c48d9fe01">
											<gml:posList>35.67475598060346 139.7414038591856 9.36 35.67498783143099 139.741427233661 9.36 35.67498783143099 139.741427233661 38 35.67475598060346 139.7414038591856 38 35.67475598060346 139.7414038591856 9.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4620</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">691.64305</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>