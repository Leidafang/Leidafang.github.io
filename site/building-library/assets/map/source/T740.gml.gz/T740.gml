<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d3ecb408-139a-4c11-9550-676eafbca40f">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">7.6</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67448605169265 139.74821519952147 0 35.674493961466254 139.74819640047022 0 35.674500607552616 139.74820060225343 0 35.67452790930888 139.7481357283579 0 35.67450262351538 139.74811974837692 0 35.67446742100957 139.74820342129578 0 35.67448605169265 139.74821519952147 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67448605169265 139.74821519952147 19.247 35.67446742100957 139.74820342129578 19.247 35.67450262351538 139.74811974837692 19.247 35.67452790930888 139.7481357283579 19.247 35.674500607552616 139.74820060225343 19.247 35.674493961466254 139.74819640047022 19.247 35.67448605169265 139.74821519952147 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67448605169265 139.74821519952147 19.247 35.674493961466254 139.74819640047022 19.247 35.674493961466254 139.74819640047022 26.02 35.67448605169265 139.74821519952147 26.02 35.67448605169265 139.74821519952147 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674493961466254 139.74819640047022 19.247 35.674500607552616 139.74820060225343 19.247 35.674500607552616 139.74820060225343 26.02 35.674493961466254 139.74819640047022 26.02 35.674493961466254 139.74819640047022 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674500607552616 139.74820060225343 19.247 35.67452790930888 139.7481357283579 19.247 35.67452790930888 139.7481357283579 26.02 35.674500607552616 139.74820060225343 26.02 35.674500607552616 139.74820060225343 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67452790930888 139.7481357283579 19.247 35.67450262351538 139.74811974837692 19.247 35.67450262351538 139.74811974837692 26.02 35.67452790930888 139.7481357283579 26.02 35.67452790930888 139.7481357283579 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67450262351538 139.74811974837692 19.247 35.67446742100957 139.74820342129578 19.247 35.67446742100957 139.74820342129578 26.02 35.67450262351538 139.74811974837692 26.02 35.67450262351538 139.74811974837692 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67446742100957 139.74820342129578 19.247 35.67448605169265 139.74821519952147 19.247 35.67448605169265 139.74821519952147 26.02 35.67446742100957 139.74820342129578 26.02 35.67446742100957 139.74820342129578 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67448605169265 139.74821519952147 26.02 35.674493961466254 139.74819640047022 26.02 35.674500607552616 139.74820060225343 26.02 35.67452790930888 139.7481357283579 26.02 35.67450262351538 139.74811974837692 26.02 35.67446742100957 139.74820342129578 26.02 35.67448605169265 139.74821519952147 26.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-cc68242c-faf5-492c-9374-e1ff4e30182f"/>
							<gml:surfaceMember xlink:href="#poly-e3d9d62a-b8a1-4ef5-91ca-0b195655e429"/>
							<gml:surfaceMember xlink:href="#poly-def44dbc-22e6-49f7-977f-ed149f258b15"/>
							<gml:surfaceMember xlink:href="#poly-668d846d-d351-415d-ac05-fe09b254e08e"/>
							<gml:surfaceMember xlink:href="#poly-012d924f-49d5-402b-a08f-c337aeb32ed7"/>
							<gml:surfaceMember xlink:href="#poly-edf4a36b-ba0c-45d1-a595-9b3a8cf34d10"/>
							<gml:surfaceMember xlink:href="#poly-220b531c-0ba7-4c78-aa3e-dafc237a746a"/>
							<gml:surfaceMember xlink:href="#poly-119519c5-428a-4fed-a5bc-f96302a9f98e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-cc68242c-faf5-492c-9374-e1ff4e30182f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc68242c-faf5-492c-9374-e1ff4e30182f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc68242c-faf5-492c-9374-e1ff4e30182f">
											<gml:posList>35.67452790930887 139.74813572835788 19.247 35.67450060755261 139.7482006022534 19.247 35.67449396146625 139.74819640047022 19.247 35.67448605169265 139.74821519952144 19.247 35.674467421009545 139.7482034212958 19.247 35.67450263252911 139.74811974836732 19.247 35.67452790930887 139.74813572835788 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e3d9d62a-b8a1-4ef5-91ca-0b195655e429">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3d9d62a-b8a1-4ef5-91ca-0b195655e429">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3d9d62a-b8a1-4ef5-91ca-0b195655e429">
											<gml:posList>35.674467421009545 139.7482034212958 26.8 35.67448605169265 139.74821519952144 26.8 35.67449396146625 139.74819640047022 26.8 35.67450060755261 139.7482006022534 26.8 35.67452790930887 139.74813572835788 26.8 35.67450263252911 139.74811974836732 26.8 35.674467421009545 139.7482034212958 26.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-def44dbc-22e6-49f7-977f-ed149f258b15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-def44dbc-22e6-49f7-977f-ed149f258b15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-def44dbc-22e6-49f7-977f-ed149f258b15">
											<gml:posList>35.67452790930887 139.74813572835788 19.247 35.67450263252911 139.74811974836732 19.247 35.67450263252911 139.74811974836732 26.8 35.67452790930887 139.74813572835788 26.8 35.67452790930887 139.74813572835788 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-668d846d-d351-415d-ac05-fe09b254e08e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-668d846d-d351-415d-ac05-fe09b254e08e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-668d846d-d351-415d-ac05-fe09b254e08e">
											<gml:posList>35.67450263252911 139.74811974836732 19.247 35.674467421009545 139.7482034212958 19.247 35.674467421009545 139.7482034212958 26.8 35.67450263252911 139.74811974836732 26.8 35.67450263252911 139.74811974836732 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-012d924f-49d5-402b-a08f-c337aeb32ed7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-012d924f-49d5-402b-a08f-c337aeb32ed7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-012d924f-49d5-402b-a08f-c337aeb32ed7">
											<gml:posList>35.67450060755261 139.7482006022534 19.247 35.67452790930887 139.74813572835788 19.247 35.67452790930887 139.74813572835788 26.8 35.67450060755261 139.7482006022534 26.8 35.67450060755261 139.7482006022534 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edf4a36b-ba0c-45d1-a595-9b3a8cf34d10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edf4a36b-ba0c-45d1-a595-9b3a8cf34d10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edf4a36b-ba0c-45d1-a595-9b3a8cf34d10">
											<gml:posList>35.67449396146625 139.74819640047022 19.247 35.67450060755261 139.7482006022534 19.247 35.67450060755261 139.7482006022534 26.8 35.67449396146625 139.74819640047022 26.8 35.67449396146625 139.74819640047022 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-220b531c-0ba7-4c78-aa3e-dafc237a746a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-220b531c-0ba7-4c78-aa3e-dafc237a746a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-220b531c-0ba7-4c78-aa3e-dafc237a746a">
											<gml:posList>35.67448605169265 139.74821519952144 19.247 35.67449396146625 139.74819640047022 19.247 35.67449396146625 139.74819640047022 26.8 35.67448605169265 139.74821519952144 26.8 35.67448605169265 139.74821519952144 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-119519c5-428a-4fed-a5bc-f96302a9f98e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-119519c5-428a-4fed-a5bc-f96302a9f98e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-119519c5-428a-4fed-a5bc-f96302a9f98e">
											<gml:posList>35.674467421009545 139.7482034212958 19.247 35.67448605169265 139.74821519952144 19.247 35.67448605169265 139.74821519952144 26.8 35.674467421009545 139.7482034212958 26.8 35.674467421009545 139.7482034212958 19.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4592</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>