<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d42d880d-c997-4b1d-9243-7d09a9409a72">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">3.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667803976171555 139.73794606711107 0 35.66781787401992 139.7379671482592 0 35.66784302371482 139.73796888569353 0 35.667859505622694 139.73795218676455 0 35.667860563905336 139.73792269292045 0 35.66784513336572 139.73790117175656 0 35.66782250646263 139.73789810583204 0 35.66780566506343 139.7379161307008 0 35.667803976171555 139.73794606711107 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667803976171555 139.73794606711107 29.35 35.66780566506343 139.7379161307008 29.35 35.66782250646263 139.73789810583204 29.35 35.66784513336572 139.73790117175656 29.35 35.667860563905336 139.73792269292045 29.35 35.667859505622694 139.73795218676455 29.35 35.66784302371482 139.73796888569353 29.35 35.66781787401992 139.7379671482592 29.35 35.667803976171555 139.73794606711107 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667803976171555 139.73794606711107 29.35 35.66781787401992 139.7379671482592 29.35 35.66781787401992 139.7379671482592 32.4 35.667803976171555 139.73794606711107 32.4 35.667803976171555 139.73794606711107 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66781787401992 139.7379671482592 29.35 35.66784302371482 139.73796888569353 29.35 35.66784302371482 139.73796888569353 32.4 35.66781787401992 139.7379671482592 32.4 35.66781787401992 139.7379671482592 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66784302371482 139.73796888569353 29.35 35.667859505622694 139.73795218676455 29.35 35.667859505622694 139.73795218676455 32.4 35.66784302371482 139.73796888569353 32.4 35.66784302371482 139.73796888569353 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667859505622694 139.73795218676455 29.35 35.667860563905336 139.73792269292045 29.35 35.667860563905336 139.73792269292045 32.4 35.667859505622694 139.73795218676455 32.4 35.667859505622694 139.73795218676455 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667860563905336 139.73792269292045 29.35 35.66784513336572 139.73790117175656 29.35 35.66784513336572 139.73790117175656 32.4 35.667860563905336 139.73792269292045 32.4 35.667860563905336 139.73792269292045 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66784513336572 139.73790117175656 29.35 35.66782250646263 139.73789810583204 29.35 35.66782250646263 139.73789810583204 32.4 35.66784513336572 139.73790117175656 32.4 35.66784513336572 139.73790117175656 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66782250646263 139.73789810583204 29.35 35.66780566506343 139.7379161307008 29.35 35.66780566506343 139.7379161307008 32.4 35.66782250646263 139.73789810583204 32.4 35.66782250646263 139.73789810583204 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66780566506343 139.7379161307008 29.35 35.667803976171555 139.73794606711107 29.35 35.667803976171555 139.73794606711107 32.4 35.66780566506343 139.7379161307008 32.4 35.66780566506343 139.7379161307008 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667803976171555 139.73794606711107 32.4 35.66781787401992 139.7379671482592 32.4 35.66784302371482 139.73796888569353 32.4 35.667859505622694 139.73795218676455 32.4 35.667860563905336 139.73792269292045 32.4 35.66784513336572 139.73790117175656 32.4 35.66782250646263 139.73789810583204 32.4 35.66780566506343 139.7379161307008 32.4 35.667803976171555 139.73794606711107 32.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-23c8fedf-bb49-4a8b-9a6c-da5f40d1946c"/>
							<gml:surfaceMember xlink:href="#poly-086160b4-56a1-4166-b734-417943cb4cb9"/>
							<gml:surfaceMember xlink:href="#poly-a6fe94b2-3678-4fa2-8d7d-82c18cd2d01a"/>
							<gml:surfaceMember xlink:href="#poly-323d097b-ad83-4707-947d-66659439b4d8"/>
							<gml:surfaceMember xlink:href="#poly-019749e7-5849-45c2-a991-b47ce92a73a7"/>
							<gml:surfaceMember xlink:href="#poly-30016427-e0f1-4c22-a325-5cec72c2b7d8"/>
							<gml:surfaceMember xlink:href="#poly-6eb9186c-cb99-4f95-a339-4ce2ec679074"/>
							<gml:surfaceMember xlink:href="#poly-e030ef90-30f0-4158-a0f2-403a63569cf0"/>
							<gml:surfaceMember xlink:href="#poly-432d80ba-ca9a-478f-85c0-9e5d174b4d67"/>
							<gml:surfaceMember xlink:href="#poly-6eeb76f3-d4c9-4f47-972f-e02a40625033"/>
							<gml:surfaceMember xlink:href="#poly-13c6d887-1a01-42d8-a4d4-48b6252a4754"/>
							<gml:surfaceMember xlink:href="#poly-5de41c9b-e6ed-4d44-97f3-78e8ffa2f655"/>
							<gml:surfaceMember xlink:href="#poly-df88274d-2585-4d0a-8850-212f61b5e959"/>
							<gml:surfaceMember xlink:href="#poly-23f06afd-5168-4b4d-8b7f-ca0da5451fa0"/>
							<gml:surfaceMember xlink:href="#poly-b63c630e-8161-4de6-80d3-28555d22b08e"/>
							<gml:surfaceMember xlink:href="#poly-df413c7a-b012-415e-8f4c-a8329558c320"/>
							<gml:surfaceMember xlink:href="#poly-783bf11d-d5af-43d7-b0a7-1d8d08831360"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-23c8fedf-bb49-4a8b-9a6c-da5f40d1946c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23c8fedf-bb49-4a8b-9a6c-da5f40d1946c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23c8fedf-bb49-4a8b-9a6c-da5f40d1946c">
											<gml:posList>35.667803976171534 139.73794606711107 29.35 35.66780566506344 139.73791613070077 29.35 35.667822506462635 139.73789810583204 29.35 35.66784513336571 139.73790117175656 29.35 35.66786056390534 139.73792269292045 29.35 35.66785950562269 139.73795218676452 29.35 35.66784302371479 139.73796888569353 29.35 35.66781787401993 139.73796714825917 29.35 35.667803976171534 139.73794606711107 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-086160b4-56a1-4166-b734-417943cb4cb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-086160b4-56a1-4166-b734-417943cb4cb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-086160b4-56a1-4166-b734-417943cb4cb9">
											<gml:posList>35.667822506462635 139.73789810583204 31.939 35.66780566506344 139.73791613070077 31.939 35.667832269339 139.73793349634806 33.497 35.667822506462635 139.73789810583204 31.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6fe94b2-3678-4fa2-8d7d-82c18cd2d01a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6fe94b2-3678-4fa2-8d7d-82c18cd2d01a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6fe94b2-3678-4fa2-8d7d-82c18cd2d01a">
											<gml:posList>35.66784513336571 139.73790117175656 31.939 35.667822506462635 139.73789810583204 31.939 35.667832269339 139.73793349634806 33.497 35.66784513336571 139.73790117175656 31.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-323d097b-ad83-4707-947d-66659439b4d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-323d097b-ad83-4707-947d-66659439b4d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-323d097b-ad83-4707-947d-66659439b4d8">
											<gml:posList>35.66786056390534 139.73792269292045 31.939 35.66784513336571 139.73790117175656 31.939 35.667832269339 139.73793349634806 33.497 35.66786056390534 139.73792269292045 31.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-019749e7-5849-45c2-a991-b47ce92a73a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-019749e7-5849-45c2-a991-b47ce92a73a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-019749e7-5849-45c2-a991-b47ce92a73a7">
											<gml:posList>35.66780566506344 139.73791613070077 31.939 35.667803976171534 139.73794606711107 31.939 35.667832269339 139.73793349634806 33.497 35.66780566506344 139.73791613070077 31.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-30016427-e0f1-4c22-a325-5cec72c2b7d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30016427-e0f1-4c22-a325-5cec72c2b7d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30016427-e0f1-4c22-a325-5cec72c2b7d8">
											<gml:posList>35.66785950562269 139.73795218676452 31.939 35.66786056390534 139.73792269292045 31.939 35.667832269339 139.73793349634806 33.497 35.66785950562269 139.73795218676452 31.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6eb9186c-cb99-4f95-a339-4ce2ec679074">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6eb9186c-cb99-4f95-a339-4ce2ec679074">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6eb9186c-cb99-4f95-a339-4ce2ec679074">
											<gml:posList>35.667803976171534 139.73794606711107 31.939 35.66781787401993 139.73796714825917 31.939 35.667832269339 139.73793349634806 33.497 35.667803976171534 139.73794606711107 31.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e030ef90-30f0-4158-a0f2-403a63569cf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e030ef90-30f0-4158-a0f2-403a63569cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e030ef90-30f0-4158-a0f2-403a63569cf0">
											<gml:posList>35.66781787401993 139.73796714825917 31.939 35.66784302371479 139.73796888569353 31.939 35.667832269339 139.73793349634806 33.497 35.66781787401993 139.73796714825917 31.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-432d80ba-ca9a-478f-85c0-9e5d174b4d67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-432d80ba-ca9a-478f-85c0-9e5d174b4d67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-432d80ba-ca9a-478f-85c0-9e5d174b4d67">
											<gml:posList>35.66784302371479 139.73796888569353 31.939 35.66785950562269 139.73795218676452 31.939 35.667832269339 139.73793349634806 33.497 35.66784302371479 139.73796888569353 31.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6eeb76f3-d4c9-4f47-972f-e02a40625033">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6eeb76f3-d4c9-4f47-972f-e02a40625033">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6eeb76f3-d4c9-4f47-972f-e02a40625033">
											<gml:posList>35.66784513336571 139.73790117175656 29.35 35.667822506462635 139.73789810583204 29.35 35.667822506462635 139.73789810583204 31.939 35.66784513336571 139.73790117175656 31.939 35.66784513336571 139.73790117175656 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13c6d887-1a01-42d8-a4d4-48b6252a4754">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13c6d887-1a01-42d8-a4d4-48b6252a4754">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13c6d887-1a01-42d8-a4d4-48b6252a4754">
											<gml:posList>35.667822506462635 139.73789810583204 29.35 35.66780566506344 139.73791613070077 29.35 35.66780566506344 139.73791613070077 31.939 35.667822506462635 139.73789810583204 31.939 35.667822506462635 139.73789810583204 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5de41c9b-e6ed-4d44-97f3-78e8ffa2f655">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5de41c9b-e6ed-4d44-97f3-78e8ffa2f655">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5de41c9b-e6ed-4d44-97f3-78e8ffa2f655">
											<gml:posList>35.66786056390534 139.73792269292045 29.35 35.66784513336571 139.73790117175656 29.35 35.66784513336571 139.73790117175656 31.939 35.66786056390534 139.73792269292045 31.939 35.66786056390534 139.73792269292045 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df88274d-2585-4d0a-8850-212f61b5e959">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df88274d-2585-4d0a-8850-212f61b5e959">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df88274d-2585-4d0a-8850-212f61b5e959">
											<gml:posList>35.66780566506344 139.73791613070077 29.35 35.667803976171534 139.73794606711107 29.35 35.667803976171534 139.73794606711107 31.939 35.66780566506344 139.73791613070077 31.939 35.66780566506344 139.73791613070077 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23f06afd-5168-4b4d-8b7f-ca0da5451fa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23f06afd-5168-4b4d-8b7f-ca0da5451fa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23f06afd-5168-4b4d-8b7f-ca0da5451fa0">
											<gml:posList>35.66785950562269 139.73795218676452 29.35 35.66786056390534 139.73792269292045 29.35 35.66786056390534 139.73792269292045 31.939 35.66785950562269 139.73795218676452 31.939 35.66785950562269 139.73795218676452 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b63c630e-8161-4de6-80d3-28555d22b08e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b63c630e-8161-4de6-80d3-28555d22b08e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b63c630e-8161-4de6-80d3-28555d22b08e">
											<gml:posList>35.667803976171534 139.73794606711107 29.35 35.66781787401993 139.73796714825917 29.35 35.66781787401993 139.73796714825917 31.939 35.667803976171534 139.73794606711107 31.939 35.667803976171534 139.73794606711107 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df413c7a-b012-415e-8f4c-a8329558c320">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df413c7a-b012-415e-8f4c-a8329558c320">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df413c7a-b012-415e-8f4c-a8329558c320">
											<gml:posList>35.66784302371479 139.73796888569353 29.35 35.66785950562269 139.73795218676452 29.35 35.66785950562269 139.73795218676452 31.939 35.66784302371479 139.73796888569353 31.939 35.66784302371479 139.73796888569353 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-783bf11d-d5af-43d7-b0a7-1d8d08831360">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-783bf11d-d5af-43d7-b0a7-1d8d08831360">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-783bf11d-d5af-43d7-b0a7-1d8d08831360">
											<gml:posList>35.66781787401993 139.73796714825917 29.35 35.66784302371479 139.73796888569353 29.35 35.66784302371479 139.73796888569353 31.939 35.66781787401993 139.73796714825917 31.939 35.66781787401993 139.73796714825917 29.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-912</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">3</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>