<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d66ceaff-0bd3-4a73-9679-b1d1655d4e72">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">6.5</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67181891758099 139.74123433893553 0 35.67183012280257 139.741247637047 0 35.672005702225114 139.74102527954926 0 35.67199449697926 139.74101198143987 0 35.67181891758099 139.74123433893553 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181891758099 139.74123433893553 7.17 35.67199449697926 139.74101198143987 7.17 35.672005702225114 139.74102527954926 7.17 35.67183012280257 139.741247637047 7.17 35.67181891758099 139.74123433893553 7.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181891758099 139.74123433893553 7.17 35.67183012280257 139.741247637047 7.17 35.67183012280257 139.741247637047 13.67 35.67181891758099 139.74123433893553 13.67 35.67181891758099 139.74123433893553 7.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67183012280257 139.741247637047 7.17 35.672005702225114 139.74102527954926 7.17 35.672005702225114 139.74102527954926 13.67 35.67183012280257 139.741247637047 13.67 35.67183012280257 139.741247637047 7.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672005702225114 139.74102527954926 7.17 35.67199449697926 139.74101198143987 7.17 35.67199449697926 139.74101198143987 13.67 35.672005702225114 139.74102527954926 13.67 35.672005702225114 139.74102527954926 7.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67199449697926 139.74101198143987 7.17 35.67181891758099 139.74123433893553 7.17 35.67181891758099 139.74123433893553 13.67 35.67199449697926 139.74101198143987 13.67 35.67199449697926 139.74101198143987 7.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181891758099 139.74123433893553 13.67 35.67183012280257 139.741247637047 13.67 35.672005702225114 139.74102527954926 13.67 35.67199449697926 139.74101198143987 13.67 35.67181891758099 139.74123433893553 13.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-94b4917b-44ba-49b2-8432-6fe38ce5c5bb"/>
							<gml:surfaceMember xlink:href="#poly-788c7b72-c785-4438-89e6-95d5c9927cce"/>
							<gml:surfaceMember xlink:href="#poly-f82ac939-21da-4ea1-b52c-821225d2784d"/>
							<gml:surfaceMember xlink:href="#poly-fd5d4c07-5c5d-4653-9aa0-5e56a28e1c20"/>
							<gml:surfaceMember xlink:href="#poly-7449da57-82af-4127-86fa-cbd21cc6a830"/>
							<gml:surfaceMember xlink:href="#poly-e68c5c6a-e7ed-4017-be99-bc07c0c80ce5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-94b4917b-44ba-49b2-8432-6fe38ce5c5bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94b4917b-44ba-49b2-8432-6fe38ce5c5bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94b4917b-44ba-49b2-8432-6fe38ce5c5bb">
											<gml:posList>35.67181891758098 139.7412343389355 7.17 35.67199449697926 139.74101198143987 7.17 35.67200570222508 139.74102527954923 7.17 35.67183012280256 139.74124763704697 7.17 35.67181891758098 139.7412343389355 7.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-788c7b72-c785-4438-89e6-95d5c9927cce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-788c7b72-c785-4438-89e6-95d5c9927cce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-788c7b72-c785-4438-89e6-95d5c9927cce">
											<gml:posList>35.67183012280256 139.74124763704697 14.717 35.67200570222508 139.74102527954923 14.717 35.67199449697926 139.74101198143987 14.717 35.67181891758098 139.7412343389355 14.717 35.67183012280256 139.74124763704697 14.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f82ac939-21da-4ea1-b52c-821225d2784d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f82ac939-21da-4ea1-b52c-821225d2784d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f82ac939-21da-4ea1-b52c-821225d2784d">
											<gml:posList>35.67200570222508 139.74102527954923 14.717 35.67200570222508 139.74102527954923 7.17 35.67199449697926 139.74101198143987 7.17 35.67199449697926 139.74101198143987 14.717 35.67200570222508 139.74102527954923 14.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd5d4c07-5c5d-4653-9aa0-5e56a28e1c20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd5d4c07-5c5d-4653-9aa0-5e56a28e1c20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd5d4c07-5c5d-4653-9aa0-5e56a28e1c20">
											<gml:posList>35.67181891758098 139.7412343389355 14.717 35.67181891758098 139.7412343389355 7.17 35.67183012280256 139.74124763704697 7.17 35.67183012280256 139.74124763704697 14.717 35.67181891758098 139.7412343389355 14.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7449da57-82af-4127-86fa-cbd21cc6a830">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7449da57-82af-4127-86fa-cbd21cc6a830">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7449da57-82af-4127-86fa-cbd21cc6a830">
											<gml:posList>35.67199449697926 139.74101198143987 14.717 35.67199449697926 139.74101198143987 7.17 35.67181891758098 139.7412343389355 7.17 35.67181891758098 139.7412343389355 14.717 35.67199449697926 139.74101198143987 14.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e68c5c6a-e7ed-4017-be99-bc07c0c80ce5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e68c5c6a-e7ed-4017-be99-bc07c0c80ce5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e68c5c6a-e7ed-4017-be99-bc07c0c80ce5">
											<gml:posList>35.67183012280256 139.74124763704697 14.717 35.67183012280256 139.74124763704697 7.17 35.67200570222508 139.74102527954923 7.17 35.67200570222508 139.74102527954923 14.717 35.67183012280256 139.74124763704697 14.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5329</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.57</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>