<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d6a0d2f1-d4fa-471b-8124-09257bbc281c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.85</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">13.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6746519516656 139.74186341689628 0 35.674699200384744 139.74186180537782 0 35.67474253725126 139.7418603308835 0 35.67474216294985 139.7417236816449 0 35.67474213209737 139.74168313970182 0 35.67469710858346 139.741683191176 0 35.6746516343834 139.74168324316537 0 35.6746519516656 139.74186341689628 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6746519516656 139.74186341689628 9.5 35.6746516343834 139.74168324316537 9.5 35.67469710858346 139.741683191176 9.5 35.67474213209737 139.74168313970182 9.5 35.67474216294985 139.7417236816449 9.5 35.67474253725126 139.7418603308835 9.5 35.674699200384744 139.74186180537782 9.5 35.6746519516656 139.74186341689628 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6746519516656 139.74186341689628 9.5 35.674699200384744 139.74186180537782 9.5 35.674699200384744 139.74186180537782 22.7 35.6746519516656 139.74186341689628 22.7 35.6746519516656 139.74186341689628 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674699200384744 139.74186180537782 9.5 35.67474253725126 139.7418603308835 9.5 35.67474253725126 139.7418603308835 22.7 35.674699200384744 139.74186180537782 22.7 35.674699200384744 139.74186180537782 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67474253725126 139.7418603308835 9.5 35.67474216294985 139.7417236816449 9.5 35.67474216294985 139.7417236816449 22.7 35.67474253725126 139.7418603308835 22.7 35.67474253725126 139.7418603308835 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67474216294985 139.7417236816449 9.5 35.67474213209737 139.74168313970182 9.5 35.67474213209737 139.74168313970182 22.7 35.67474216294985 139.7417236816449 22.7 35.67474216294985 139.7417236816449 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67474213209737 139.74168313970182 9.5 35.67469710858346 139.741683191176 9.5 35.67469710858346 139.741683191176 22.7 35.67474213209737 139.74168313970182 22.7 35.67474213209737 139.74168313970182 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67469710858346 139.741683191176 9.5 35.6746516343834 139.74168324316537 9.5 35.6746516343834 139.74168324316537 22.7 35.67469710858346 139.741683191176 22.7 35.67469710858346 139.741683191176 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6746516343834 139.74168324316537 9.5 35.6746519516656 139.74186341689628 9.5 35.6746519516656 139.74186341689628 22.7 35.6746516343834 139.74168324316537 22.7 35.6746516343834 139.74168324316537 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6746519516656 139.74186341689628 22.7 35.674699200384744 139.74186180537782 22.7 35.67474253725126 139.7418603308835 22.7 35.67474216294985 139.7417236816449 22.7 35.67474213209737 139.74168313970182 22.7 35.67469710858346 139.741683191176 22.7 35.6746516343834 139.74168324316537 22.7 35.6746519516656 139.74186341689628 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3a9db11b-daba-469e-b2bd-1e279a4e8717"/>
							<gml:surfaceMember xlink:href="#poly-d1baee57-c404-4303-ac5c-3c52db8f82ee"/>
							<gml:surfaceMember xlink:href="#poly-201370bd-4611-47fb-96f3-2b38f4f2e6d1"/>
							<gml:surfaceMember xlink:href="#poly-6b20d8d7-e62f-4a4f-bf78-a5349ac09cca"/>
							<gml:surfaceMember xlink:href="#poly-c0cd0099-87df-4bd8-84ad-04fe9020e550"/>
							<gml:surfaceMember xlink:href="#poly-bf3ff4ea-e379-44f5-bea1-3d998aeb8f20"/>
							<gml:surfaceMember xlink:href="#poly-19f24cf0-94cc-4125-ad5e-5aa21dc5d7d9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3a9db11b-daba-469e-b2bd-1e279a4e8717">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a9db11b-daba-469e-b2bd-1e279a4e8717">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a9db11b-daba-469e-b2bd-1e279a4e8717">
											<gml:posList>35.67465163438338 139.74168324316534 9.5 35.67474213209736 139.74168313970182 9.5 35.67474216294983 139.7417236816449 9.5 35.67474253725127 139.74186033088347 9.5 35.67465195166556 139.74186341689628 9.5 35.67465163438338 139.74168324316534 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1baee57-c404-4303-ac5c-3c52db8f82ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1baee57-c404-4303-ac5c-3c52db8f82ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1baee57-c404-4303-ac5c-3c52db8f82ee">
											<gml:posList>35.67474216294983 139.7417236816449 22.3 35.67474213209736 139.74168313970182 22.3 35.67469710858345 139.741683191176 23.347 35.67469920038474 139.74186180537785 23.347 35.67474253725127 139.74186033088347 22.3 35.67474216294983 139.7417236816449 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-201370bd-4611-47fb-96f3-2b38f4f2e6d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-201370bd-4611-47fb-96f3-2b38f4f2e6d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-201370bd-4611-47fb-96f3-2b38f4f2e6d1">
											<gml:posList>35.67465163438338 139.74168324316534 22.3 35.67465195166556 139.74186341689628 22.3 35.67469920038474 139.74186180537785 23.347 35.67469710858345 139.741683191176 23.347 35.67465163438338 139.74168324316534 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b20d8d7-e62f-4a4f-bf78-a5349ac09cca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b20d8d7-e62f-4a4f-bf78-a5349ac09cca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b20d8d7-e62f-4a4f-bf78-a5349ac09cca">
											<gml:posList>35.67465163438338 139.74168324316534 9.5 35.67465163438338 139.74168324316534 22.3 35.67469710858345 139.741683191176 23.347 35.67474213209736 139.74168313970182 22.3 35.67474213209736 139.74168313970182 9.5 35.67465163438338 139.74168324316534 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0cd0099-87df-4bd8-84ad-04fe9020e550">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0cd0099-87df-4bd8-84ad-04fe9020e550">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0cd0099-87df-4bd8-84ad-04fe9020e550">
											<gml:posList>35.67474216294983 139.7417236816449 9.5 35.67474213209736 139.74168313970182 9.5 35.67474213209736 139.74168313970182 22.3 35.67474216294983 139.7417236816449 22.3 35.67474253725127 139.74186033088347 22.3 35.67474253725127 139.74186033088347 9.5 35.67474216294983 139.7417236816449 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf3ff4ea-e379-44f5-bea1-3d998aeb8f20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf3ff4ea-e379-44f5-bea1-3d998aeb8f20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf3ff4ea-e379-44f5-bea1-3d998aeb8f20">
											<gml:posList>35.67465163438338 139.74168324316534 22.3 35.67465163438338 139.74168324316534 9.5 35.67465195166556 139.74186341689628 9.5 35.67465195166556 139.74186341689628 22.3 35.67465163438338 139.74168324316534 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19f24cf0-94cc-4125-ad5e-5aa21dc5d7d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19f24cf0-94cc-4125-ad5e-5aa21dc5d7d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19f24cf0-94cc-4125-ad5e-5aa21dc5d7d9">
											<gml:posList>35.67474253725127 139.74186033088347 9.5 35.67474253725127 139.74186033088347 22.3 35.67469920038474 139.74186180537785 23.347 35.67465195166556 139.74186341689628 22.3 35.67465195166556 139.74186341689628 9.5 35.67474253725127 139.74186033088347 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4611</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">259.07944</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.27</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>