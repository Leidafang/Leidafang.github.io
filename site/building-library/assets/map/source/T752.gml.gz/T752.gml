<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d713710b-5b13-4977-95a0-192ee9067d74">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">6.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67297106119101 139.74695030235227 0 35.67301618780397 139.7468803727895 0 35.67299464803976 139.74685950685844 0 35.67294952143086 139.74692942536748 0 35.67297106119101 139.74695030235227 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67297106119101 139.74695030235227 11.02 35.67294952143086 139.74692942536748 11.02 35.67299464803976 139.74685950685844 11.02 35.67301618780397 139.7468803727895 11.02 35.67297106119101 139.74695030235227 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67297106119101 139.74695030235227 11.02 35.67301618780397 139.7468803727895 11.02 35.67301618780397 139.7468803727895 17.42 35.67297106119101 139.74695030235227 17.42 35.67297106119101 139.74695030235227 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67301618780397 139.7468803727895 11.02 35.67299464803976 139.74685950685844 11.02 35.67299464803976 139.74685950685844 17.42 35.67301618780397 139.7468803727895 17.42 35.67301618780397 139.7468803727895 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67299464803976 139.74685950685844 11.02 35.67294952143086 139.74692942536748 11.02 35.67294952143086 139.74692942536748 17.42 35.67299464803976 139.74685950685844 17.42 35.67299464803976 139.74685950685844 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67294952143086 139.74692942536748 11.02 35.67297106119101 139.74695030235227 11.02 35.67297106119101 139.74695030235227 17.42 35.67294952143086 139.74692942536748 17.42 35.67294952143086 139.74692942536748 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67297106119101 139.74695030235227 17.42 35.67301618780397 139.7468803727895 17.42 35.67299464803976 139.74685950685844 17.42 35.67294952143086 139.74692942536748 17.42 35.67297106119101 139.74695030235227 17.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5a8d6984-6480-4311-b6bb-283a42c90c75"/>
							<gml:surfaceMember xlink:href="#poly-72f29ae9-a587-49ca-892b-ab4ac8d5aae0"/>
							<gml:surfaceMember xlink:href="#poly-5a05c4d0-e854-4709-85b3-eb8ed4df7aff"/>
							<gml:surfaceMember xlink:href="#poly-ac6cf231-c815-4f17-91af-8b0245ceefa6"/>
							<gml:surfaceMember xlink:href="#poly-f8c0d091-b844-4079-b721-1e041a8882b8"/>
							<gml:surfaceMember xlink:href="#poly-937aa664-b626-4da8-865c-0fa517b54c67"/>
							<gml:surfaceMember xlink:href="#poly-8a2ea974-8e71-4e7c-b7cb-da49b03e58ba"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5a8d6984-6480-4311-b6bb-283a42c90c75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a8d6984-6480-4311-b6bb-283a42c90c75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a8d6984-6480-4311-b6bb-283a42c90c75">
											<gml:posList>35.672971061191 139.74695030235225 11.02 35.67294952143082 139.74692942536748 11.02 35.67299464803974 139.74685950685844 11.02 35.673016187803945 139.7468803727895 11.02 35.672971061191 139.74695030235225 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72f29ae9-a587-49ca-892b-ab4ac8d5aae0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72f29ae9-a587-49ca-892b-ab4ac8d5aae0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72f29ae9-a587-49ca-892b-ab4ac8d5aae0">
											<gml:posList>35.673016187803945 139.7468803727895 16.95 35.67299464803974 139.74685950685844 16.95 35.67294952143082 139.74692942536748 16.95 35.673016187803945 139.7468803727895 16.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a05c4d0-e854-4709-85b3-eb8ed4df7aff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a05c4d0-e854-4709-85b3-eb8ed4df7aff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a05c4d0-e854-4709-85b3-eb8ed4df7aff">
											<gml:posList>35.67294952143082 139.74692942536748 16.95 35.672971061191 139.74695030235225 17.43 35.673016187803945 139.7468803727895 16.95 35.67294952143082 139.74692942536748 16.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac6cf231-c815-4f17-91af-8b0245ceefa6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac6cf231-c815-4f17-91af-8b0245ceefa6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac6cf231-c815-4f17-91af-8b0245ceefa6">
											<gml:posList>35.673016187803945 139.7468803727895 11.02 35.67299464803974 139.74685950685844 11.02 35.67299464803974 139.74685950685844 16.95 35.673016187803945 139.7468803727895 16.95 35.673016187803945 139.7468803727895 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8c0d091-b844-4079-b721-1e041a8882b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8c0d091-b844-4079-b721-1e041a8882b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8c0d091-b844-4079-b721-1e041a8882b8">
											<gml:posList>35.67299464803974 139.74685950685844 11.02 35.67294952143082 139.74692942536748 11.02 35.67294952143082 139.74692942536748 16.95 35.67299464803974 139.74685950685844 16.95 35.67299464803974 139.74685950685844 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-937aa664-b626-4da8-865c-0fa517b54c67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-937aa664-b626-4da8-865c-0fa517b54c67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-937aa664-b626-4da8-865c-0fa517b54c67">
											<gml:posList>35.672971061191 139.74695030235225 11.02 35.673016187803945 139.7468803727895 11.02 35.673016187803945 139.7468803727895 16.95 35.672971061191 139.74695030235225 17.43 35.672971061191 139.74695030235225 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a2ea974-8e71-4e7c-b7cb-da49b03e58ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a2ea974-8e71-4e7c-b7cb-da49b03e58ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a2ea974-8e71-4e7c-b7cb-da49b03e58ba">
											<gml:posList>35.67294952143082 139.74692942536748 11.02 35.672971061191 139.74695030235225 11.02 35.672971061191 139.74695030235225 17.43 35.67294952143082 139.74692942536748 16.95 35.67294952143082 139.74692942536748 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4526</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>