<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d7606f1f-3c47-48d8-9712-fdea8d3cd412">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6723146671646 139.7387964750019 0 35.67233665274706 139.7387863967357 0 35.67233312837525 139.73877491250252 0 35.67237457664853 139.73875597404313 0 35.67237685397095 139.73876343881383 0 35.672412535631196 139.73874726877662 0 35.672381158594334 139.73864373348331 0 35.67228204285551 139.73868858895855 0 35.6723146671646 139.7387964750019 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6723146671646 139.7387964750019 9.54 35.67228204285551 139.73868858895855 9.54 35.672381158594334 139.73864373348331 9.54 35.672412535631196 139.73874726877662 9.54 35.67237685397095 139.73876343881383 9.54 35.67237457664853 139.73875597404313 9.54 35.67233312837525 139.73877491250252 9.54 35.67233665274706 139.7387863967357 9.54 35.6723146671646 139.7387964750019 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6723146671646 139.7387964750019 9.54 35.67233665274706 139.7387863967357 9.54 35.67233665274706 139.7387863967357 26.2 35.6723146671646 139.7387964750019 26.2 35.6723146671646 139.7387964750019 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67233665274706 139.7387863967357 9.54 35.67233312837525 139.73877491250252 9.54 35.67233312837525 139.73877491250252 26.2 35.67233665274706 139.7387863967357 26.2 35.67233665274706 139.7387863967357 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67233312837525 139.73877491250252 9.54 35.67237457664853 139.73875597404313 9.54 35.67237457664853 139.73875597404313 26.2 35.67233312837525 139.73877491250252 26.2 35.67233312837525 139.73877491250252 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67237457664853 139.73875597404313 9.54 35.67237685397095 139.73876343881383 9.54 35.67237685397095 139.73876343881383 26.2 35.67237457664853 139.73875597404313 26.2 35.67237457664853 139.73875597404313 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67237685397095 139.73876343881383 9.54 35.672412535631196 139.73874726877662 9.54 35.672412535631196 139.73874726877662 26.2 35.67237685397095 139.73876343881383 26.2 35.67237685397095 139.73876343881383 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672412535631196 139.73874726877662 9.54 35.672381158594334 139.73864373348331 9.54 35.672381158594334 139.73864373348331 26.2 35.672412535631196 139.73874726877662 26.2 35.672412535631196 139.73874726877662 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672381158594334 139.73864373348331 9.54 35.67228204285551 139.73868858895855 9.54 35.67228204285551 139.73868858895855 26.2 35.672381158594334 139.73864373348331 26.2 35.672381158594334 139.73864373348331 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67228204285551 139.73868858895855 9.54 35.6723146671646 139.7387964750019 9.54 35.6723146671646 139.7387964750019 26.2 35.67228204285551 139.73868858895855 26.2 35.67228204285551 139.73868858895855 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6723146671646 139.7387964750019 26.2 35.67233665274706 139.7387863967357 26.2 35.67233312837525 139.73877491250252 26.2 35.67237457664853 139.73875597404313 26.2 35.67237685397095 139.73876343881383 26.2 35.672412535631196 139.73874726877662 26.2 35.672381158594334 139.73864373348331 26.2 35.67228204285551 139.73868858895855 26.2 35.6723146671646 139.7387964750019 26.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-71d19054-e270-4e4b-89f4-d9d85a162309"/>
							<gml:surfaceMember xlink:href="#poly-31bc22df-40f3-4618-81e2-b02a75e710f1"/>
							<gml:surfaceMember xlink:href="#poly-095fc4af-c440-4504-9220-edce78578488"/>
							<gml:surfaceMember xlink:href="#poly-8f8637ec-f587-45f9-88d2-698f9633a37b"/>
							<gml:surfaceMember xlink:href="#poly-f0c3376c-5974-44c4-9c97-f57b7014ccc4"/>
							<gml:surfaceMember xlink:href="#poly-d40b181e-653f-4199-a421-5a50d1e9d659"/>
							<gml:surfaceMember xlink:href="#poly-d15579fd-82ec-4475-b6fc-6a5379be3041"/>
							<gml:surfaceMember xlink:href="#poly-fef60dbd-0bf8-4e7b-b5e3-fcc124315c75"/>
							<gml:surfaceMember xlink:href="#poly-5527d6fb-369d-40d7-873f-02f0ea05397c"/>
							<gml:surfaceMember xlink:href="#poly-32c14ad2-7294-4953-ae2d-c1a5837fc035"/>
							<gml:surfaceMember xlink:href="#poly-5f65810d-fb39-460e-a17a-ab4b77eaf127"/>
							<gml:surfaceMember xlink:href="#poly-f9d309b3-dc53-4366-a0ee-f1dbe66ec7cf"/>
							<gml:surfaceMember xlink:href="#poly-db24f6e0-4dd1-4c1a-bf13-27f51341bae1"/>
							<gml:surfaceMember xlink:href="#poly-1d22f64c-1a10-4fbb-9eef-fa9572fd0353"/>
							<gml:surfaceMember xlink:href="#poly-ec1befe0-262b-4f8c-aba0-07f1d509e70c"/>
							<gml:surfaceMember xlink:href="#poly-c8f9b70f-f7c4-43d2-8b18-48ffe36ad118"/>
							<gml:surfaceMember xlink:href="#poly-e1c02558-6f70-4b7b-8694-1995a67df21b"/>
							<gml:surfaceMember xlink:href="#poly-ffa9a3e3-dce2-48b3-b7e6-3882a08808f9"/>
							<gml:surfaceMember xlink:href="#poly-9f0230b6-d47b-480e-a824-245ee6954ae0"/>
							<gml:surfaceMember xlink:href="#poly-83b90ae4-73f9-46b8-a0d0-4028a1e80dbd"/>
							<gml:surfaceMember xlink:href="#poly-e7025061-fb7e-4621-ab2c-352650381cf3"/>
							<gml:surfaceMember xlink:href="#poly-aac960d9-579d-4597-8538-9fb287f659c7"/>
							<gml:surfaceMember xlink:href="#poly-5702bf83-2118-4a09-996d-331493323cd7"/>
							<gml:surfaceMember xlink:href="#poly-e64eb2c4-b33a-4463-b978-541c1c25380b"/>
							<gml:surfaceMember xlink:href="#poly-a0bb306f-24d7-4c34-95ce-0bdf3a3bbc0d"/>
							<gml:surfaceMember xlink:href="#poly-d79dde15-c63b-4287-a7fb-395f8ceb1704"/>
							<gml:surfaceMember xlink:href="#poly-ef92b5a7-89fb-4963-9425-e884c2a9d943"/>
							<gml:surfaceMember xlink:href="#poly-134d101e-52ca-4347-a6ad-cff94a226f51"/>
							<gml:surfaceMember xlink:href="#poly-d078a3d4-e94d-46ea-81db-0343d095fee4"/>
							<gml:surfaceMember xlink:href="#poly-69844c3e-54e2-4b4c-8127-ae93493f66df"/>
							<gml:surfaceMember xlink:href="#poly-8196ae3c-b0e0-4cdb-a974-d03512ddff51"/>
							<gml:surfaceMember xlink:href="#poly-1129d5be-84ae-459d-8b0a-969944c21587"/>
							<gml:surfaceMember xlink:href="#poly-9eb30273-4e68-4dbd-9f7f-507236e98a95"/>
							<gml:surfaceMember xlink:href="#poly-0dc63224-34ea-4592-9936-f133e3fcdedd"/>
							<gml:surfaceMember xlink:href="#poly-5dac6eef-3176-412a-9f16-a96bf5b52393"/>
							<gml:surfaceMember xlink:href="#poly-8b885801-9e6c-42cd-9892-b6486ed92ea3"/>
							<gml:surfaceMember xlink:href="#poly-9d5be03a-47c2-4b2a-a5c5-af0508974524"/>
							<gml:surfaceMember xlink:href="#poly-5b0cb90a-6161-4123-a83f-a2b59c5a2c87"/>
							<gml:surfaceMember xlink:href="#poly-01f86b43-ed4f-408e-9cb3-b79b35baecf0"/>
							<gml:surfaceMember xlink:href="#poly-a5e0507e-3738-4a9c-b1ba-796b413d0166"/>
							<gml:surfaceMember xlink:href="#poly-f022e5ee-40c9-473b-a3d6-51c6ea4b74f2"/>
							<gml:surfaceMember xlink:href="#poly-66454d69-3122-4c21-915e-7787cde0e3a1"/>
							<gml:surfaceMember xlink:href="#poly-0bb28236-bacf-4eff-9317-d081a8fc658e"/>
							<gml:surfaceMember xlink:href="#poly-ca846afd-dba8-4f42-bcf6-3fb6e6e78509"/>
							<gml:surfaceMember xlink:href="#poly-b086b374-db58-4e9c-98fb-66119b3f3643"/>
							<gml:surfaceMember xlink:href="#poly-5e532310-5a00-49c8-821a-36d8e4f95381"/>
							<gml:surfaceMember xlink:href="#poly-098b28ef-c0f6-4e84-a76a-069b681c3068"/>
							<gml:surfaceMember xlink:href="#poly-b8d49b02-5bed-4ba6-96be-bea5d6e61255"/>
							<gml:surfaceMember xlink:href="#poly-c978b81e-2dc8-443a-94f5-0aacaae8bf25"/>
							<gml:surfaceMember xlink:href="#poly-d57551d4-4991-4279-ad25-f5141d15c211"/>
							<gml:surfaceMember xlink:href="#poly-1b1d9335-071d-4274-acdc-981058ca669b"/>
							<gml:surfaceMember xlink:href="#poly-58f3bb32-ff54-46f5-b0a3-b3e2d400000b"/>
							<gml:surfaceMember xlink:href="#poly-b9b66b0f-e493-4cf6-b7dc-6d6938064d22"/>
							<gml:surfaceMember xlink:href="#poly-799cb213-e11f-4592-8b57-7a3a69bceb65"/>
							<gml:surfaceMember xlink:href="#poly-e7240d8d-609c-4381-b4de-77f0b75a3ab5"/>
							<gml:surfaceMember xlink:href="#poly-723a92a8-9e2b-4e3a-ad6a-f01312ccf054"/>
							<gml:surfaceMember xlink:href="#poly-f57b33cd-d2f8-4201-a5cf-484f3194f259"/>
							<gml:surfaceMember xlink:href="#poly-1d1d9fb6-b2d9-4743-a203-3a4cc6abd85f"/>
							<gml:surfaceMember xlink:href="#poly-dcd68187-383d-4b1e-863d-242e228f5ebf"/>
							<gml:surfaceMember xlink:href="#poly-3aaa504f-7131-4b56-9980-0848694d0865"/>
							<gml:surfaceMember xlink:href="#poly-6e5decbb-ba75-4e5c-a164-fe72c6379df2"/>
							<gml:surfaceMember xlink:href="#poly-5a3165a9-131e-40ab-aafc-475a5f3c03bc"/>
							<gml:surfaceMember xlink:href="#poly-563a8c67-a6f5-4865-bb4e-68510baedea0"/>
							<gml:surfaceMember xlink:href="#poly-02d6f305-8101-495c-858b-741daa9e7f24"/>
							<gml:surfaceMember xlink:href="#poly-8f06acf5-151f-4d3c-807b-ad0d48a71e53"/>
							<gml:surfaceMember xlink:href="#poly-41e1ab9d-e655-470b-9fa1-3ca94bdcab45"/>
							<gml:surfaceMember xlink:href="#poly-f2791773-497a-4d23-8790-35471c544ca9"/>
							<gml:surfaceMember xlink:href="#poly-3d5ac52e-bd7a-4562-94bd-6af0efb5f828"/>
							<gml:surfaceMember xlink:href="#poly-c24686c1-0f45-4017-95db-9ab08dbbccb9"/>
							<gml:surfaceMember xlink:href="#poly-417b0906-9f78-45f4-94f4-60f82fbef0ab"/>
							<gml:surfaceMember xlink:href="#poly-6894324f-28fa-4142-833d-07ac635d5f14"/>
							<gml:surfaceMember xlink:href="#poly-0c6d6360-69ad-4008-9d0d-cdd971c3ac6a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d7606f1f-3c47-48d8-9712-fdea8d3cd412_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb2aa775-5d84-4642-a7d9-d8239e2016ed">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672382512861105 139.73865800400722 29.688 35.67238597414802 139.73866948831682 29.688 35.67237689154093 139.73867359730548 29.688 35.672373430254396 139.73866211299702 29.688 35.672382512861105 139.73865800400722 29.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02e098e7-269e-4fbd-8115-86190f8af88f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67236918812609 139.73870075877988 27.511 35.6723828390315 139.7386945345139 27.511 35.672388053473185 139.73871173886147 27.511 35.67237441157193 139.73871795206773 27.511 35.67236918812609 139.73870075877988 27.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2f84afb-b646-4465-b3d5-278e2a6d4a02">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67233231430301 139.73878277859075 23.423 35.672329232730846 139.73877272988472 23.423 35.672329881484416 139.73877243086326 23.423 35.67233294503784 139.73878249063716 23.423 35.67233231430301 139.73878277859075 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f428aa9c-ad99-4ee0-ad9e-e2a67e528146">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672329232730846 139.73877272988472 23.18 35.67233231430301 139.73878277859075 23.18 35.67232597092585 139.73878569130855 23.18 35.67232213019761 139.73877309175083 23.18 35.672329104309256 139.73876989107853 23.18 35.672329881484416 139.73877243086326 23.18 35.672329232730846 139.73877272988472 23.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82a183cc-9d73-470c-a1e6-669c2fb918fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82a183cc-9d73-470c-a1e6-669c2fb918fd_0">
											<gml:posList>35.672329232730846 139.73877272988472 23.18 35.672329881484416 139.73877243086326 23.18 35.672329881484416 139.73877243086326 23.423 35.672329232730846 139.73877272988472 23.423 35.672329232730846 139.73877272988472 23.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2087d39-bf96-4670-9034-195aa953001c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2087d39-bf96-4670-9034-195aa953001c_0">
											<gml:posList>35.67237441157193 139.73871795206773 27.511 35.67237441157193 139.73871795206773 29.362 35.67236918812609 139.73870075877988 29.362 35.67236918812609 139.73870075877988 27.511 35.67237441157193 139.73871795206773 27.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4a0d0da-9962-4888-b3be-110278617b15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4a0d0da-9962-4888-b3be-110278617b15_0">
											<gml:posList>35.672373430254396 139.73866211299702 29.688 35.67237689154093 139.73867359730548 29.688 35.67237689154093 139.73867359730548 31.168 35.672373430254396 139.73866211299702 31.168 35.672373430254396 139.73866211299702 29.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50c4c6fb-2514-4399-87ea-e304dc3bc3b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50c4c6fb-2514-4399-87ea-e304dc3bc3b3_0">
											<gml:posList>35.6723828390315 139.7386945345139 27.511 35.67236918812609 139.73870075877988 27.511 35.67236918812609 139.73870075877988 29.362 35.6723828390315 139.7386945345139 29.362 35.6723828390315 139.7386945345139 27.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4529b4c3-faf6-46c2-8001-3a289558c081">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4529b4c3-faf6-46c2-8001-3a289558c081_0">
											<gml:posList>35.672382512861105 139.73865800400722 29.688 35.672373430254396 139.73866211299702 29.688 35.672373430254396 139.73866211299702 31.168 35.672382512861105 139.73865800400722 31.168 35.672382512861105 139.73865800400722 29.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8991a8a-0eb7-48e1-88aa-e31cab34a003">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8991a8a-0eb7-48e1-88aa-e31cab34a003_0">
											<gml:posList>35.67236918812609 139.73870075877988 29.362 35.67237441157193 139.73871795206773 29.362 35.672388053473185 139.73871173886147 29.362 35.6723828390315 139.7386945345139 29.362 35.67236918812609 139.73870075877988 29.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8b3e653-df9c-45db-8608-b072b72052fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8b3e653-df9c-45db-8608-b072b72052fc_0">
											<gml:posList>35.672382512861105 139.73865800400722 31.168 35.672373430254396 139.73866211299702 31.168 35.67237689154093 139.73867359730548 31.168 35.67238597414802 139.73866948831682 31.168 35.672382512861105 139.73865800400722 31.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f08f0333-6295-44bf-b439-35298c155e8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f08f0333-6295-44bf-b439-35298c155e8e_0">
											<gml:posList>35.67237441157193 139.73871795206773 27.511 35.672388053473185 139.73871173886147 27.511 35.672388053473185 139.73871173886147 29.362 35.67237441157193 139.73871795206773 29.362 35.67237441157193 139.73871795206773 27.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5af86ad2-491d-460d-82aa-69585a190b4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5af86ad2-491d-460d-82aa-69585a190b4c_0">
											<gml:posList>35.67237689154093 139.73867359730548 29.688 35.67238597414802 139.73866948831682 29.688 35.67238597414802 139.73866948831682 31.168 35.67237689154093 139.73867359730548 31.168 35.67237689154093 139.73867359730548 29.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19b94dc5-70aa-4a43-bd91-56445f4d68ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19b94dc5-70aa-4a43-bd91-56445f4d68ed_0">
											<gml:posList>35.67238597414802 139.73866948831682 29.688 35.672382512861105 139.73865800400722 29.688 35.672382512861105 139.73865800400722 31.168 35.67238597414802 139.73866948831682 31.168 35.67238597414802 139.73866948831682 29.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74f1d697-8685-414c-a427-a797ad1cfaee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74f1d697-8685-414c-a427-a797ad1cfaee_0">
											<gml:posList>35.672388053473185 139.73871173886147 27.511 35.6723828390315 139.7386945345139 27.511 35.6723828390315 139.7386945345139 29.362 35.672388053473185 139.73871173886147 29.362 35.672388053473185 139.73871173886147 27.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ab44d5a-4458-4e1a-a9c4-118334f9960c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ab44d5a-4458-4e1a-a9c4-118334f9960c_0">
											<gml:posList>35.67232213019761 139.73877309175083 23.18 35.67232597092585 139.73878569130855 23.18 35.67232597092585 139.73878569130855 24.462 35.67232213019761 139.73877309175083 24.462 35.67232213019761 139.73877309175083 23.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-879ebd18-c269-4cfa-9868-3f0c921c2abe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-879ebd18-c269-4cfa-9868-3f0c921c2abe_0">
											<gml:posList>35.67232213019761 139.73877309175083 23.18 35.67232213019761 139.73877309175083 24.462 35.672329104309256 139.73876989107853 24.462 35.672329104309256 139.73876989107853 23.18 35.67232213019761 139.73877309175083 23.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-039ce031-5380-426a-852e-5edc38ba9f04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-039ce031-5380-426a-852e-5edc38ba9f04_0">
											<gml:posList>35.67233294503784 139.73878249063716 24.462 35.672329104309256 139.73876989107853 24.462 35.67232213019761 139.73877309175083 24.462 35.67232597092585 139.73878569130855 24.462 35.67233294503784 139.73878249063716 24.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-160f15f3-e416-48bc-8a6f-fcd0df77b0ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-160f15f3-e416-48bc-8a6f-fcd0df77b0ce_0">
											<gml:posList>35.67233231430301 139.73878277859075 23.423 35.67233294503784 139.73878249063716 23.423 35.67233294503784 139.73878249063716 24.462 35.67232597092585 139.73878569130855 24.462 35.67232597092585 139.73878569130855 23.18 35.67233231430301 139.73878277859075 23.18 35.67233231430301 139.73878277859075 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-896e1a8d-c5a6-4454-898a-c108fddee565">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-896e1a8d-c5a6-4454-898a-c108fddee565_0">
											<gml:posList>35.67233231430301 139.73878277859075 23.423 35.67233231430301 139.73878277859075 23.18 35.672329232730846 139.73877272988472 23.18 35.672329232730846 139.73877272988472 23.423 35.67233231430301 139.73878277859075 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81e692be-61bc-4ab8-ac63-48e55a3bd3b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81e692be-61bc-4ab8-ac63-48e55a3bd3b1_0">
											<gml:posList>35.672329104309256 139.73876989107853 23.18 35.672329104309256 139.73876989107853 24.462 35.67233294503784 139.73878249063716 24.462 35.67233294503784 139.73878249063716 23.423 35.672329881484416 139.73877243086326 23.423 35.672329881484416 139.73877243086326 23.18 35.672329104309256 139.73876989107853 23.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-71d19054-e270-4e4b-89f4-d9d85a162309">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71d19054-e270-4e4b-89f4-d9d85a162309">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71d19054-e270-4e4b-89f4-d9d85a162309">
											<gml:posList>35.672333128375236 139.73877491250252 9.54 35.672336652747056 139.7387863967357 9.54 35.672314667164585 139.73879647500186 9.54 35.672282042855485 139.73868858895855 9.54 35.672381158594334 139.73864373348331 9.54 35.672412535631196 139.7387472687766 9.54 35.67237685397093 139.73876343881383 9.54 35.67237457664854 139.7387559740431 9.54 35.672333128375236 139.73877491250252 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31bc22df-40f3-4618-81e2-b02a75e710f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31bc22df-40f3-4618-81e2-b02a75e710f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31bc22df-40f3-4618-81e2-b02a75e710f1">
											<gml:posList>35.672345567128474 139.7386599586864 29.849 35.67234767725074 139.73866111608027 29.849 35.672380205146744 139.73864628635897 29.849 35.672381158594334 139.73864373348331 29.849 35.672345567128474 139.7386599586864 29.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-095fc4af-c440-4504-9220-edce78578488">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-095fc4af-c440-4504-9220-edce78578488">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-095fc4af-c440-4504-9220-edce78578488">
											<gml:posList>35.672381158594334 139.73864373348331 29.849 35.672380205146744 139.73864628635897 29.849 35.67238749810922 139.738670303961 29.849 35.67238957218518 139.73867147244485 29.849 35.672381158594334 139.73864373348331 29.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8f8637ec-f587-45f9-88d2-698f9633a37b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f8637ec-f587-45f9-88d2-698f9633a37b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f8637ec-f587-45f9-88d2-698f9633a37b">
											<gml:posList>35.67229020950231 139.7386888554807 23.423 35.67229303880299 139.73868757074402 23.423 35.67229199049377 139.73868411441998 23.423 35.672282042855485 139.73868858895855 23.423 35.672285920482665 139.73869078263877 23.423 35.67229020950231 139.7386888554807 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0c3376c-5974-44c4-9c97-f57b7014ccc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0c3376c-5974-44c4-9c97-f57b7014ccc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0c3376c-5974-44c4-9c97-f57b7014ccc4">
											<gml:posList>35.672314667164585 139.73879647500186 23.423 35.67231643912053 139.73879170081315 23.423 35.672285920482665 139.73869078263877 23.423 35.672282042855485 139.73868858895855 23.423 35.672314667164585 139.73879647500186 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d40b181e-653f-4199-a421-5a50d1e9d659">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d40b181e-653f-4199-a421-5a50d1e9d659">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d40b181e-653f-4199-a421-5a50d1e9d659">
											<gml:posList>35.67231101353822 139.73874665948102 26.227 35.67231360403109 139.73873970816013 26.227 35.67229766264132 139.7386873112154 26.227 35.67229199049377 139.73868411441998 26.227 35.67231101353822 139.73874665948102 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d15579fd-82ec-4475-b6fc-6a5379be3041">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d15579fd-82ec-4475-b6fc-6a5379be3041">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d15579fd-82ec-4475-b6fc-6a5379be3041">
											<gml:posList>35.67231101353822 139.73874665948102 23.18 35.67229303880299 139.73868757074402 23.18 35.67229020950231 139.7386888554807 23.18 35.672285920482665 139.73869078263877 23.18 35.67231643912053 139.73879170081315 23.18 35.67233275710288 139.73878421411723 23.18 35.672329232730846 139.73877272988472 23.18 35.672347217677455 139.73876451214645 23.18 35.672350055983955 139.73876321635433 23.18 35.672340865299 139.73873301493768 23.18 35.67231101353822 139.73874665948102 23.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fef60dbd-0bf8-4e7b-b5e3-fcc124315c75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fef60dbd-0bf8-4e7b-b5e3-fcc124315c75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fef60dbd-0bf8-4e7b-b5e3-fcc124315c75">
											<gml:posList>35.67229766264132 139.7386873112154 26.227 35.67234709442483 139.7386650161937 26.227 35.672345567128474 139.7386599586864 26.227 35.67229199049377 139.73868411441998 26.227 35.67229766264132 139.7386873112154 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5527d6fb-369d-40d7-873f-02f0ea05397c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5527d6fb-369d-40d7-873f-02f0ea05397c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5527d6fb-369d-40d7-873f-02f0ea05397c">
											<gml:posList>35.672336652747056 139.7387863967357 23.423 35.67233275710288 139.73878421411723 23.423 35.67231643912053 139.73879170081315 23.423 35.672314667164585 139.73879647500186 23.423 35.672336652747056 139.7387863967357 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32c14ad2-7294-4953-ae2d-c1a5837fc035">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32c14ad2-7294-4953-ae2d-c1a5837fc035">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32c14ad2-7294-4953-ae2d-c1a5837fc035">
											<gml:posList>35.672340865299 139.73873301493768 26.227 35.672343446768664 139.73872605257787 26.227 35.67231360403109 139.73873970816013 26.227 35.67231101353822 139.73874665948102 26.227 35.672340865299 139.73873301493768 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f65810d-fb39-460e-a17a-ab4b77eaf127">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f65810d-fb39-460e-a17a-ab4b77eaf127">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f65810d-fb39-460e-a17a-ab4b77eaf127">
											<gml:posList>35.672333128375236 139.73877491250252 23.423 35.672329232730846 139.73877272988472 23.423 35.67233275710288 139.73878421411723 23.423 35.672336652747056 139.7387863967357 23.423 35.672333128375236 139.73877491250252 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9d309b3-dc53-4366-a0ee-f1dbe66ec7cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9d309b3-dc53-4366-a0ee-f1dbe66ec7cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9d309b3-dc53-4366-a0ee-f1dbe66ec7cf">
											<gml:posList>35.672343446768664 139.73872605257787 25.658 35.672353703815986 139.73875974344057 25.658 35.67236892253898 139.73875278826506 25.658 35.67236343693654 139.7387346231906 25.658 35.67236756375328 139.73873275145704 25.658 35.67234709442483 139.7386650161937 25.658 35.67229766264132 139.7386873112154 25.658 35.67231360403109 139.73873970816013 25.658 35.672343446768664 139.73872605257787 25.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db24f6e0-4dd1-4c1a-bf13-27f51341bae1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db24f6e0-4dd1-4c1a-bf13-27f51341bae1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db24f6e0-4dd1-4c1a-bf13-27f51341bae1">
											<gml:posList>35.672347217677455 139.73876451214645 23.423 35.672329232730846 139.73877272988472 23.423 35.672333128375236 139.73877491250252 23.423 35.67235111332198 139.73876669476434 23.423 35.672350055983955 139.73876321635433 23.423 35.672347217677455 139.73876451214645 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d22f64c-1a10-4fbb-9eef-fa9572fd0353">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d22f64c-1a10-4fbb-9eef-fa9572fd0353">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d22f64c-1a10-4fbb-9eef-fa9572fd0353">
											<gml:posList>35.672340865299 139.73873301493768 26.227 35.67235111332198 139.73876669476434 26.227 35.672353703815986 139.73875974344057 26.227 35.672343446768664 139.73872605257787 26.227 35.672340865299 139.73873301493768 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec1befe0-262b-4f8c-aba0-07f1d509e70c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec1befe0-262b-4f8c-aba0-07f1d509e70c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec1befe0-262b-4f8c-aba0-07f1d509e70c">
											<gml:posList>35.672354413139715 139.73868739887052 27.654 35.672345567128474 139.7386599586864 27.654 35.67235393559494 139.73868763141144 27.654 35.672354413139715 139.73868739887052 27.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8f9b70f-f7c4-43d2-8b18-48ffe36ad118">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8f9b70f-f7c4-43d2-8b18-48ffe36ad118">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8f9b70f-f7c4-43d2-8b18-48ffe36ad118">
											<gml:posList>35.672354413139715 139.73868739887052 29.849 35.67235533957309 139.73868487916766 29.849 35.67234767725074 139.73866111608027 29.849 35.672345567128474 139.7386599586864 29.849 35.672354413139715 139.73868739887052 29.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1c02558-6f70-4b7b-8694-1995a67df21b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1c02558-6f70-4b7b-8694-1995a67df21b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1c02558-6f70-4b7b-8694-1995a67df21b">
											<gml:posList>35.672355836803746 139.738686756491 27.654 35.672354413139715 139.73868739887052 27.654 35.67235393559494 139.73868763141144 27.654 35.672367798708805 139.7387335133906 27.654 35.67236900402166 139.73873029742717 27.654 35.672355836803746 139.738686756491 27.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ffa9a3e3-dce2-48b3-b7e6-3882a08808f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffa9a3e3-dce2-48b3-b7e6-3882a08808f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffa9a3e3-dce2-48b3-b7e6-3882a08808f9">
											<gml:posList>35.67237457664854 139.7387559740431 26.227 35.67236892253898 139.73875278826506 26.227 35.672353703815986 139.73875974344057 26.227 35.67235111332198 139.73876669476434 26.227 35.67237457664854 139.7387559740431 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f0230b6-d47b-480e-a824-245ee6954ae0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f0230b6-d47b-480e-a824-245ee6954ae0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f0230b6-d47b-480e-a824-245ee6954ae0">
											<gml:posList>35.67235533957309 139.73868487916766 29.688 35.67238749810922 139.738670303961 29.688 35.672380205146744 139.73864628635897 29.688 35.67234767725074 139.73866111608027 29.688 35.67235533957309 139.73868487916766 29.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83b90ae4-73f9-46b8-a0d0-4028a1e80dbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83b90ae4-73f9-46b8-a0d0-4028a1e80dbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83b90ae4-73f9-46b8-a0d0-4028a1e80dbd">
											<gml:posList>35.67236343693654 139.7387346231906 26.227 35.67236892253898 139.73875278826506 26.227 35.67237457664854 139.7387559740431 26.227 35.672367798708805 139.7387335133906 26.227 35.67236756375328 139.73873275145704 26.227 35.67236343693654 139.7387346231906 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e7025061-fb7e-4621-ab2c-352650381cf3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7025061-fb7e-4621-ab2c-352650381cf3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7025061-fb7e-4621-ab2c-352650381cf3">
											<gml:posList>35.67238957218518 139.73867147244485 29.849 35.67238749810922 139.738670303961 29.849 35.67235533957309 139.73868487916766 29.849 35.672354413139715 139.73868739887052 29.849 35.67238957218518 139.73867147244485 29.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aac960d9-579d-4597-8538-9fb287f659c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aac960d9-579d-4597-8538-9fb287f659c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aac960d9-579d-4597-8538-9fb287f659c7">
											<gml:posList>35.67237457664854 139.7387559740431 25.42 35.672377405932544 139.73875466721438 25.42 35.67237716191136 139.73875383901216 25.42 35.6723743235963 139.73875512375852 25.42 35.67237457664854 139.7387559740431 25.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5702bf83-2118-4a09-996d-331493323cd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5702bf83-2118-4a09-996d-331493323cd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5702bf83-2118-4a09-996d-331493323cd7">
											<gml:posList>35.67237457664854 139.7387559740431 25.42 35.67237685397093 139.73876343881383 25.42 35.67237862593422 139.7387586756672 25.42 35.672377405932544 139.73875466721438 25.42 35.67237457664854 139.7387559740431 25.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e64eb2c4-b33a-4463-b978-541c1c25380b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e64eb2c4-b33a-4463-b978-541c1c25380b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e64eb2c4-b33a-4463-b978-541c1c25380b">
											<gml:posList>35.67238765294038 139.73867233634078 27.511 35.672355836803746 139.738686756491 27.511 35.67236900402166 139.73873029742717 27.511 35.67240083813013 139.73871579994488 27.511 35.67238765294038 139.73867233634078 27.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a0bb306f-24d7-4c34-95ce-0bdf3a3bbc0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0bb306f-24d7-4c34-95ce-0bdf3a3bbc0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0bb306f-24d7-4c34-95ce-0bdf3a3bbc0d">
											<gml:posList>35.67240346227689 139.73871726603747 27.654 35.67240083813013 139.73871579994488 27.654 35.67236900402166 139.73873029742717 27.654 35.672367798708805 139.7387335133906 27.654 35.67240346227689 139.73871726603747 27.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d79dde15-c63b-4287-a7fb-395f8ceb1704">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d79dde15-c63b-4287-a7fb-395f8ceb1704">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d79dde15-c63b-4287-a7fb-395f8ceb1704">
											<gml:posList>35.67237716191136 139.73875383901216 25.151 35.672377405932544 139.73875466721438 25.151 35.67237862593422 139.7387586756672 25.151 35.672408648991386 139.7387450751008 25.151 35.672401672279136 139.7387220181612 25.151 35.67240062397091 139.73871856183206 25.151 35.672367798708805 139.7387335133906 25.151 35.6723743235963 139.73875512375852 25.151 35.67237716191136 139.73875383901216 25.151</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef92b5a7-89fb-4963-9425-e884c2a9d943">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef92b5a7-89fb-4963-9425-e884c2a9d943">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef92b5a7-89fb-4963-9425-e884c2a9d943">
											<gml:posList>35.672412535631196 139.7387472687766 25.42 35.672408648991386 139.7387450751008 25.42 35.67237862593422 139.7387586756672 25.42 35.67237685397093 139.73876343881383 25.42 35.672412535631196 139.7387472687766 25.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-134d101e-52ca-4347-a6ad-cff94a226f51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-134d101e-52ca-4347-a6ad-cff94a226f51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-134d101e-52ca-4347-a6ad-cff94a226f51">
											<gml:posList>35.67240083813013 139.73871579994488 27.654 35.67240346227689 139.73871726603747 27.654 35.67238957218518 139.73867147244485 27.654 35.67238765294038 139.73867233634078 27.654 35.67240083813013 139.73871579994488 27.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d078a3d4-e94d-46ea-81db-0343d095fee4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d078a3d4-e94d-46ea-81db-0343d095fee4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d078a3d4-e94d-46ea-81db-0343d095fee4">
											<gml:posList>35.672412535631196 139.7387472687766 25.42 35.67240346227689 139.73871726603747 25.42 35.67240062397091 139.73871856183206 25.42 35.672401672279136 139.7387220181612 25.42 35.672408648991386 139.7387450751008 25.42 35.672412535631196 139.7387472687766 25.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69844c3e-54e2-4b4c-8127-ae93493f66df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69844c3e-54e2-4b4c-8127-ae93493f66df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69844c3e-54e2-4b4c-8127-ae93493f66df">
											<gml:posList>35.67238749810922 139.738670303961 29.849 35.67238749810922 139.738670303961 29.688 35.67235533957309 139.73868487916766 29.688 35.67235533957309 139.73868487916766 29.849 35.67238749810922 139.738670303961 29.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8196ae3c-b0e0-4cdb-a974-d03512ddff51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8196ae3c-b0e0-4cdb-a974-d03512ddff51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8196ae3c-b0e0-4cdb-a974-d03512ddff51">
											<gml:posList>35.672285920482665 139.73869078263877 23.423 35.672285920482665 139.73869078263877 23.18 35.67229020950231 139.7386888554807 23.18 35.67229020950231 139.7386888554807 23.423 35.672285920482665 139.73869078263877 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1129d5be-84ae-459d-8b0a-969944c21587">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1129d5be-84ae-459d-8b0a-969944c21587">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1129d5be-84ae-459d-8b0a-969944c21587">
											<gml:posList>35.67229020950231 139.7386888554807 23.423 35.67229020950231 139.7386888554807 23.18 35.67229303880299 139.73868757074402 23.18 35.67229303880299 139.73868757074402 23.423 35.67229020950231 139.7386888554807 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9eb30273-4e68-4dbd-9f7f-507236e98a95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9eb30273-4e68-4dbd-9f7f-507236e98a95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9eb30273-4e68-4dbd-9f7f-507236e98a95">
											<gml:posList>35.67229199049377 139.73868411441998 26.227 35.67229199049377 139.73868411441998 23.423 35.67229303880299 139.73868757074402 23.423 35.67229303880299 139.73868757074402 23.18 35.67231101353822 139.73874665948102 23.18 35.67231101353822 139.73874665948102 26.227 35.67229199049377 139.73868411441998 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0dc63224-34ea-4592-9936-f133e3fcdedd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dc63224-34ea-4592-9936-f133e3fcdedd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dc63224-34ea-4592-9936-f133e3fcdedd">
											<gml:posList>35.67231360403109 139.73873970816013 26.227 35.67231360403109 139.73873970816013 25.658 35.67229766264132 139.7386873112154 25.658 35.67229766264132 139.7386873112154 26.227 35.67231360403109 139.73873970816013 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5dac6eef-3176-412a-9f16-a96bf5b52393">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dac6eef-3176-412a-9f16-a96bf5b52393">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dac6eef-3176-412a-9f16-a96bf5b52393">
											<gml:posList>35.67229766264132 139.7386873112154 26.227 35.67229766264132 139.7386873112154 25.658 35.67234709442483 139.7386650161937 25.658 35.67234709442483 139.7386650161937 26.227 35.67229766264132 139.7386873112154 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b885801-9e6c-42cd-9892-b6486ed92ea3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b885801-9e6c-42cd-9892-b6486ed92ea3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b885801-9e6c-42cd-9892-b6486ed92ea3">
											<gml:posList>35.672343446768664 139.73872605257787 26.227 35.672343446768664 139.73872605257787 25.658 35.67231360403109 139.73873970816013 25.658 35.67231360403109 139.73873970816013 26.227 35.672343446768664 139.73872605257787 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d5be03a-47c2-4b2a-a5c5-af0508974524">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d5be03a-47c2-4b2a-a5c5-af0508974524">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d5be03a-47c2-4b2a-a5c5-af0508974524">
											<gml:posList>35.67229199049377 139.73868411441998 23.423 35.67229199049377 139.73868411441998 26.227 35.672345567128474 139.7386599586864 26.227 35.672345567128474 139.7386599586864 27.654 35.672345567128474 139.7386599586864 29.849 35.672381158594334 139.73864373348331 29.849 35.672381158594334 139.73864373348331 9.54 35.672282042855485 139.73868858895855 9.54 35.672282042855485 139.73868858895855 23.423 35.67229199049377 139.73868411441998 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b0cb90a-6161-4123-a83f-a2b59c5a2c87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b0cb90a-6161-4123-a83f-a2b59c5a2c87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b0cb90a-6161-4123-a83f-a2b59c5a2c87">
											<gml:posList>35.672354413139715 139.73868739887052 29.849 35.672345567128474 139.7386599586864 29.849 35.672345567128474 139.7386599586864 27.654 35.672354413139715 139.73868739887052 27.654 35.672354413139715 139.73868739887052 29.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01f86b43-ed4f-408e-9cb3-b79b35baecf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01f86b43-ed4f-408e-9cb3-b79b35baecf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01f86b43-ed4f-408e-9cb3-b79b35baecf0">
											<gml:posList>35.67235533957309 139.73868487916766 29.849 35.67235533957309 139.73868487916766 29.688 35.67234767725074 139.73866111608027 29.688 35.67234767725074 139.73866111608027 29.849 35.67235533957309 139.73868487916766 29.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5e0507e-3738-4a9c-b1ba-796b413d0166">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5e0507e-3738-4a9c-b1ba-796b413d0166">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5e0507e-3738-4a9c-b1ba-796b413d0166">
											<gml:posList>35.67236756375328 139.73873275145704 26.227 35.672367798708805 139.7387335133906 26.227 35.672367798708805 139.7387335133906 27.654 35.67235393559494 139.73868763141144 27.654 35.672345567128474 139.7386599586864 27.654 35.672345567128474 139.7386599586864 26.227 35.67234709442483 139.7386650161937 26.227 35.67234709442483 139.7386650161937 25.658 35.67236756375328 139.73873275145704 25.658 35.67236756375328 139.73873275145704 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f022e5ee-40c9-473b-a3d6-51c6ea4b74f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f022e5ee-40c9-473b-a3d6-51c6ea4b74f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f022e5ee-40c9-473b-a3d6-51c6ea4b74f2">
											<gml:posList>35.67236900402166 139.73873029742717 27.654 35.67236900402166 139.73873029742717 27.511 35.672355836803746 139.738686756491 27.511 35.672355836803746 139.738686756491 27.654 35.67236900402166 139.73873029742717 27.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66454d69-3122-4c21-915e-7787cde0e3a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66454d69-3122-4c21-915e-7787cde0e3a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66454d69-3122-4c21-915e-7787cde0e3a1">
											<gml:posList>35.67234767725074 139.73866111608027 29.849 35.67234767725074 139.73866111608027 29.688 35.672380205146744 139.73864628635897 29.688 35.672380205146744 139.73864628635897 29.849 35.67234767725074 139.73866111608027 29.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bb28236-bacf-4eff-9317-d081a8fc658e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bb28236-bacf-4eff-9317-d081a8fc658e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bb28236-bacf-4eff-9317-d081a8fc658e">
											<gml:posList>35.67236756375328 139.73873275145704 26.227 35.67236756375328 139.73873275145704 25.658 35.67236343693654 139.7387346231906 25.658 35.67236343693654 139.7387346231906 26.227 35.67236756375328 139.73873275145704 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca846afd-dba8-4f42-bcf6-3fb6e6e78509">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca846afd-dba8-4f42-bcf6-3fb6e6e78509">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca846afd-dba8-4f42-bcf6-3fb6e6e78509">
											<gml:posList>35.672355836803746 139.738686756491 27.654 35.672355836803746 139.738686756491 27.511 35.67238765294038 139.73867233634078 27.511 35.67238765294038 139.73867233634078 27.654 35.67238957218518 139.73867147244485 27.654 35.67238957218518 139.73867147244485 29.849 35.672354413139715 139.73868739887052 29.849 35.672354413139715 139.73868739887052 27.654 35.672355836803746 139.738686756491 27.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b086b374-db58-4e9c-98fb-66119b3f3643">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b086b374-db58-4e9c-98fb-66119b3f3643">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b086b374-db58-4e9c-98fb-66119b3f3643">
											<gml:posList>35.672380205146744 139.73864628635897 29.849 35.672380205146744 139.73864628635897 29.688 35.67238749810922 139.738670303961 29.688 35.67238749810922 139.738670303961 29.849 35.672380205146744 139.73864628635897 29.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e532310-5a00-49c8-821a-36d8e4f95381">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e532310-5a00-49c8-821a-36d8e4f95381">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e532310-5a00-49c8-821a-36d8e4f95381">
											<gml:posList>35.67240083813013 139.73871579994488 27.654 35.67240083813013 139.73871579994488 27.511 35.67236900402166 139.73873029742717 27.511 35.67236900402166 139.73873029742717 27.654 35.67240083813013 139.73871579994488 27.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-098b28ef-c0f6-4e84-a76a-069b681c3068">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-098b28ef-c0f6-4e84-a76a-069b681c3068">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-098b28ef-c0f6-4e84-a76a-069b681c3068">
											<gml:posList>35.672367798708805 139.7387335133906 26.227 35.672367798708805 139.7387335133906 25.151 35.67240062397091 139.73871856183206 25.151 35.67240062397091 139.73871856183206 25.42 35.67240346227689 139.73871726603747 25.42 35.67240346227689 139.73871726603747 27.654 35.672367798708805 139.7387335133906 27.654 35.672367798708805 139.7387335133906 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8d49b02-5bed-4ba6-96be-bea5d6e61255">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8d49b02-5bed-4ba6-96be-bea5d6e61255">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8d49b02-5bed-4ba6-96be-bea5d6e61255">
											<gml:posList>35.67238765294038 139.73867233634078 27.654 35.67238765294038 139.73867233634078 27.511 35.67240083813013 139.73871579994488 27.511 35.67240083813013 139.73871579994488 27.654 35.67238765294038 139.73867233634078 27.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c978b81e-2dc8-443a-94f5-0aacaae8bf25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c978b81e-2dc8-443a-94f5-0aacaae8bf25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c978b81e-2dc8-443a-94f5-0aacaae8bf25">
											<gml:posList>35.67240346227689 139.73871726603747 25.42 35.672412535631196 139.7387472687766 25.42 35.672412535631196 139.7387472687766 9.54 35.672381158594334 139.73864373348331 9.54 35.672381158594334 139.73864373348331 29.849 35.67238957218518 139.73867147244485 29.849 35.67238957218518 139.73867147244485 27.654 35.67240346227689 139.73871726603747 27.654 35.67240346227689 139.73871726603747 25.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d57551d4-4991-4279-ad25-f5141d15c211">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d57551d4-4991-4279-ad25-f5141d15c211">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d57551d4-4991-4279-ad25-f5141d15c211">
											<gml:posList>35.67240062397091 139.73871856183206 25.42 35.67240062397091 139.73871856183206 25.151 35.672401672279136 139.7387220181612 25.151 35.672401672279136 139.7387220181612 25.42 35.67240062397091 139.73871856183206 25.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b1d9335-071d-4274-acdc-981058ca669b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b1d9335-071d-4274-acdc-981058ca669b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b1d9335-071d-4274-acdc-981058ca669b">
											<gml:posList>35.672401672279136 139.7387220181612 25.42 35.672401672279136 139.7387220181612 25.151 35.672408648991386 139.7387450751008 25.151 35.672408648991386 139.7387450751008 25.42 35.672401672279136 139.7387220181612 25.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58f3bb32-ff54-46f5-b0a3-b3e2d400000b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58f3bb32-ff54-46f5-b0a3-b3e2d400000b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58f3bb32-ff54-46f5-b0a3-b3e2d400000b">
											<gml:posList>35.67231101353822 139.73874665948102 23.18 35.672340865299 139.73873301493768 23.18 35.672340865299 139.73873301493768 26.227 35.67231101353822 139.73874665948102 26.227 35.67231101353822 139.73874665948102 23.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9b66b0f-e493-4cf6-b7dc-6d6938064d22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9b66b0f-e493-4cf6-b7dc-6d6938064d22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9b66b0f-e493-4cf6-b7dc-6d6938064d22">
											<gml:posList>35.67231643912053 139.73879170081315 23.423 35.67231643912053 139.73879170081315 23.18 35.672285920482665 139.73869078263877 23.18 35.672285920482665 139.73869078263877 23.423 35.67231643912053 139.73879170081315 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-799cb213-e11f-4592-8b57-7a3a69bceb65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-799cb213-e11f-4592-8b57-7a3a69bceb65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-799cb213-e11f-4592-8b57-7a3a69bceb65">
											<gml:posList>35.672282042855485 139.73868858895855 9.54 35.672314667164585 139.73879647500186 9.54 35.672314667164585 139.73879647500186 23.423 35.672282042855485 139.73868858895855 23.423 35.672282042855485 139.73868858895855 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7240d8d-609c-4381-b4de-77f0b75a3ab5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7240d8d-609c-4381-b4de-77f0b75a3ab5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7240d8d-609c-4381-b4de-77f0b75a3ab5">
											<gml:posList>35.672353703815986 139.73875974344057 26.227 35.672353703815986 139.73875974344057 25.658 35.672343446768664 139.73872605257787 25.658 35.672343446768664 139.73872605257787 26.227 35.672353703815986 139.73875974344057 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-723a92a8-9e2b-4e3a-ad6a-f01312ccf054">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-723a92a8-9e2b-4e3a-ad6a-f01312ccf054">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-723a92a8-9e2b-4e3a-ad6a-f01312ccf054">
											<gml:posList>35.67236343693654 139.7387346231906 26.227 35.67236343693654 139.7387346231906 25.658 35.67236892253898 139.73875278826506 25.658 35.67236892253898 139.73875278826506 26.227 35.67236343693654 139.7387346231906 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f57b33cd-d2f8-4201-a5cf-484f3194f259">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f57b33cd-d2f8-4201-a5cf-484f3194f259">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f57b33cd-d2f8-4201-a5cf-484f3194f259">
											<gml:posList>35.672367798708805 139.7387335133906 25.151 35.672367798708805 139.7387335133906 26.227 35.67237457664854 139.7387559740431 26.227 35.67237457664854 139.7387559740431 25.42 35.6723743235963 139.73875512375852 25.42 35.6723743235963 139.73875512375852 25.151 35.672367798708805 139.7387335133906 25.151</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d1d9fb6-b2d9-4743-a203-3a4cc6abd85f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d1d9fb6-b2d9-4743-a203-3a4cc6abd85f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d1d9fb6-b2d9-4743-a203-3a4cc6abd85f">
											<gml:posList>35.67235111332198 139.73876669476434 26.227 35.672340865299 139.73873301493768 26.227 35.672340865299 139.73873301493768 23.18 35.672350055983955 139.73876321635433 23.18 35.672350055983955 139.73876321635433 23.423 35.67235111332198 139.73876669476434 23.423 35.67235111332198 139.73876669476434 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcd68187-383d-4b1e-863d-242e228f5ebf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcd68187-383d-4b1e-863d-242e228f5ebf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcd68187-383d-4b1e-863d-242e228f5ebf">
											<gml:posList>35.672408648991386 139.7387450751008 25.42 35.672408648991386 139.7387450751008 25.151 35.67237862593422 139.7387586756672 25.151 35.67237862593422 139.7387586756672 25.42 35.672408648991386 139.7387450751008 25.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3aaa504f-7131-4b56-9980-0848694d0865">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3aaa504f-7131-4b56-9980-0848694d0865">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3aaa504f-7131-4b56-9980-0848694d0865">
											<gml:posList>35.672377405932544 139.73875466721438 25.42 35.672377405932544 139.73875466721438 25.151 35.67237716191136 139.73875383901216 25.151 35.67237716191136 139.73875383901216 25.42 35.672377405932544 139.73875466721438 25.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e5decbb-ba75-4e5c-a164-fe72c6379df2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e5decbb-ba75-4e5c-a164-fe72c6379df2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e5decbb-ba75-4e5c-a164-fe72c6379df2">
											<gml:posList>35.67237716191136 139.73875383901216 25.42 35.67237716191136 139.73875383901216 25.151 35.6723743235963 139.73875512375852 25.151 35.6723743235963 139.73875512375852 25.42 35.67237716191136 139.73875383901216 25.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a3165a9-131e-40ab-aafc-475a5f3c03bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a3165a9-131e-40ab-aafc-475a5f3c03bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a3165a9-131e-40ab-aafc-475a5f3c03bc">
											<gml:posList>35.67237685397093 139.73876343881383 9.54 35.672412535631196 139.7387472687766 9.54 35.672412535631196 139.7387472687766 25.42 35.67237685397093 139.73876343881383 25.42 35.67237685397093 139.73876343881383 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-563a8c67-a6f5-4865-bb4e-68510baedea0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-563a8c67-a6f5-4865-bb4e-68510baedea0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-563a8c67-a6f5-4865-bb4e-68510baedea0">
											<gml:posList>35.67236892253898 139.73875278826506 26.227 35.67236892253898 139.73875278826506 25.658 35.672353703815986 139.73875974344057 25.658 35.672353703815986 139.73875974344057 26.227 35.67236892253898 139.73875278826506 26.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02d6f305-8101-495c-858b-741daa9e7f24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02d6f305-8101-495c-858b-741daa9e7f24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02d6f305-8101-495c-858b-741daa9e7f24">
											<gml:posList>35.67237862593422 139.7387586756672 25.42 35.67237862593422 139.7387586756672 25.151 35.672377405932544 139.73875466721438 25.151 35.672377405932544 139.73875466721438 25.42 35.67237862593422 139.7387586756672 25.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f06acf5-151f-4d3c-807b-ad0d48a71e53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f06acf5-151f-4d3c-807b-ad0d48a71e53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f06acf5-151f-4d3c-807b-ad0d48a71e53">
											<gml:posList>35.67237457664854 139.7387559740431 9.54 35.67237685397093 139.73876343881383 9.54 35.67237685397093 139.73876343881383 25.42 35.67237457664854 139.7387559740431 25.42 35.67237457664854 139.7387559740431 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41e1ab9d-e655-470b-9fa1-3ca94bdcab45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41e1ab9d-e655-470b-9fa1-3ca94bdcab45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41e1ab9d-e655-470b-9fa1-3ca94bdcab45">
											<gml:posList>35.672350055983955 139.73876321635433 23.423 35.672350055983955 139.73876321635433 23.18 35.672347217677455 139.73876451214645 23.18 35.672347217677455 139.73876451214645 23.423 35.672350055983955 139.73876321635433 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2791773-497a-4d23-8790-35471c544ca9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2791773-497a-4d23-8790-35471c544ca9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2791773-497a-4d23-8790-35471c544ca9">
											<gml:posList>35.67237457664854 139.7387559740431 25.42 35.67237457664854 139.7387559740431 26.227 35.67235111332198 139.73876669476434 26.227 35.67235111332198 139.73876669476434 23.423 35.672333128375236 139.73877491250252 23.423 35.672333128375236 139.73877491250252 9.54 35.67237457664854 139.7387559740431 9.54 35.67237457664854 139.7387559740431 25.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d5ac52e-bd7a-4562-94bd-6af0efb5f828">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d5ac52e-bd7a-4562-94bd-6af0efb5f828">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d5ac52e-bd7a-4562-94bd-6af0efb5f828">
											<gml:posList>35.672347217677455 139.73876451214645 23.423 35.672347217677455 139.73876451214645 23.18 35.672329232730846 139.73877272988472 23.18 35.672329232730846 139.73877272988472 23.423 35.672347217677455 139.73876451214645 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c24686c1-0f45-4017-95db-9ab08dbbccb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c24686c1-0f45-4017-95db-9ab08dbbccb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c24686c1-0f45-4017-95db-9ab08dbbccb9">
											<gml:posList>35.672329232730846 139.73877272988472 23.423 35.672329232730846 139.73877272988472 23.18 35.67233275710288 139.73878421411723 23.18 35.67233275710288 139.73878421411723 23.423 35.672329232730846 139.73877272988472 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-417b0906-9f78-45f4-94f4-60f82fbef0ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-417b0906-9f78-45f4-94f4-60f82fbef0ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-417b0906-9f78-45f4-94f4-60f82fbef0ab">
											<gml:posList>35.672336652747056 139.7387863967357 9.54 35.672333128375236 139.73877491250252 9.54 35.672333128375236 139.73877491250252 23.423 35.672336652747056 139.7387863967357 23.423 35.672336652747056 139.7387863967357 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6894324f-28fa-4142-833d-07ac635d5f14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6894324f-28fa-4142-833d-07ac635d5f14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6894324f-28fa-4142-833d-07ac635d5f14">
											<gml:posList>35.67233275710288 139.73878421411723 23.423 35.67233275710288 139.73878421411723 23.18 35.67231643912053 139.73879170081315 23.18 35.67231643912053 139.73879170081315 23.423 35.67233275710288 139.73878421411723 23.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c6d6360-69ad-4008-9d0d-cdd971c3ac6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c6d6360-69ad-4008-9d0d-cdd971c3ac6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c6d6360-69ad-4008-9d0d-cdd971c3ac6a">
											<gml:posList>35.672314667164585 139.73879647500186 9.54 35.672336652747056 139.7387863967357 9.54 35.672336652747056 139.7387863967357 23.423 35.672314667164585 139.73879647500186 23.423 35.672314667164585 139.73879647500186 9.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2871</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">72.45217</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>