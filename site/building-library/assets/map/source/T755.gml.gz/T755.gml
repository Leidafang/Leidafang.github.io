<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d8462866-0f2b-4349-9062-1516845a51e7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">18.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67130455120036 139.73756269110748 0 35.67129283905599 139.73758119674622 0 35.67145085190004 139.7377314048588 0 35.67149730443919 139.73765800128479 0 35.67131373897417 139.73748689086602 0 35.67128080817839 139.73753894765235 0 35.67130455120036 139.73756269110748 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130455120036 139.73756269110748 10.93 35.67128080817839 139.73753894765235 10.93 35.67131373897417 139.73748689086602 10.93 35.67149730443919 139.73765800128479 10.93 35.67145085190004 139.7377314048588 10.93 35.67129283905599 139.73758119674622 10.93 35.67130455120036 139.73756269110748 10.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130455120036 139.73756269110748 10.93 35.67129283905599 139.73758119674622 10.93 35.67129283905599 139.73758119674622 29.59 35.67130455120036 139.73756269110748 29.59 35.67130455120036 139.73756269110748 10.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67129283905599 139.73758119674622 10.93 35.67145085190004 139.7377314048588 10.93 35.67145085190004 139.7377314048588 29.59 35.67129283905599 139.73758119674622 29.59 35.67129283905599 139.73758119674622 10.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145085190004 139.7377314048588 10.93 35.67149730443919 139.73765800128479 10.93 35.67149730443919 139.73765800128479 29.59 35.67145085190004 139.7377314048588 29.59 35.67145085190004 139.7377314048588 10.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67149730443919 139.73765800128479 10.93 35.67131373897417 139.73748689086602 10.93 35.67131373897417 139.73748689086602 29.59 35.67149730443919 139.73765800128479 29.59 35.67149730443919 139.73765800128479 10.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131373897417 139.73748689086602 10.93 35.67128080817839 139.73753894765235 10.93 35.67128080817839 139.73753894765235 29.59 35.67131373897417 139.73748689086602 29.59 35.67131373897417 139.73748689086602 10.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128080817839 139.73753894765235 10.93 35.67130455120036 139.73756269110748 10.93 35.67130455120036 139.73756269110748 29.59 35.67128080817839 139.73753894765235 29.59 35.67128080817839 139.73753894765235 10.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130455120036 139.73756269110748 29.59 35.67129283905599 139.73758119674622 29.59 35.67145085190004 139.7377314048588 29.59 35.67149730443919 139.73765800128479 29.59 35.67131373897417 139.73748689086602 29.59 35.67128080817839 139.73753894765235 29.59 35.67130455120036 139.73756269110748 29.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-31f78a48-f40e-4109-b998-e196c3642250"/>
							<gml:surfaceMember xlink:href="#poly-2f94645d-4e4f-4787-917a-e395a686d9ea"/>
							<gml:surfaceMember xlink:href="#poly-ee81a20b-6612-45c1-ad37-72ff6c7f886d"/>
							<gml:surfaceMember xlink:href="#poly-2534cb47-f357-4937-9f23-1bfb8bb47157"/>
							<gml:surfaceMember xlink:href="#poly-2ada8f9c-09f7-4091-a39c-fb959c2e2296"/>
							<gml:surfaceMember xlink:href="#poly-7ee6c03d-a645-483f-9c20-7cec91842573"/>
							<gml:surfaceMember xlink:href="#poly-4e6b0309-9668-45d2-980e-e10b7e6b1f57"/>
							<gml:surfaceMember xlink:href="#poly-59245f71-7902-4e71-ad24-682c06c7d9aa"/>
							<gml:surfaceMember xlink:href="#poly-00a061c3-a76e-4ff9-906d-154ec2e5e7f2"/>
							<gml:surfaceMember xlink:href="#poly-a9c40f12-d1c5-44cf-bdf7-817e3f761f7f"/>
							<gml:surfaceMember xlink:href="#poly-b3638f6e-0de8-45a5-a5dc-69b6156649a3"/>
							<gml:surfaceMember xlink:href="#poly-7bd96803-21a3-4e82-9fa0-29dab652973f"/>
							<gml:surfaceMember xlink:href="#poly-4476f779-7b22-4c8a-a180-94468f69078c"/>
							<gml:surfaceMember xlink:href="#poly-3f96f722-b481-4b62-8cdb-6380bd9c5808"/>
							<gml:surfaceMember xlink:href="#poly-37e7068d-3bd4-4ca7-b647-0b3d7ea3dd75"/>
							<gml:surfaceMember xlink:href="#poly-a4f1d402-2b76-4418-9a5f-04dcb1cff123"/>
							<gml:surfaceMember xlink:href="#poly-4c0b8109-36d3-411f-8036-ac1e11724917"/>
							<gml:surfaceMember xlink:href="#poly-15125252-18b3-4405-bfa5-94cb1b3f9776"/>
							<gml:surfaceMember xlink:href="#poly-c9acba31-012e-4f71-9eaf-cc43488a9232"/>
							<gml:surfaceMember xlink:href="#poly-5b9dfe94-9921-4848-9638-ff172e1e41d2"/>
							<gml:surfaceMember xlink:href="#poly-a28f5b46-fa12-4f55-8719-b64edfa80c34"/>
							<gml:surfaceMember xlink:href="#poly-82f752c9-bba3-4322-b769-75756c570032"/>
							<gml:surfaceMember xlink:href="#poly-90f7e986-9172-4bd1-b91e-0055d93c0876"/>
							<gml:surfaceMember xlink:href="#poly-d37b0b71-8554-453d-a63f-739e91be5f60"/>
							<gml:surfaceMember xlink:href="#poly-0a8488c4-01f2-4493-b420-0fb84451c536"/>
							<gml:surfaceMember xlink:href="#poly-081c3b82-fcec-48ed-94d8-ef0e35f6c2c3"/>
							<gml:surfaceMember xlink:href="#poly-7ee6370c-2489-4683-bbe6-2e76db21dfb4"/>
							<gml:surfaceMember xlink:href="#poly-a4173f62-65b1-4bcd-b44b-410bc7b4434e"/>
							<gml:surfaceMember xlink:href="#poly-e521b615-c9f1-44db-85ae-ae0598a2611a"/>
							<gml:surfaceMember xlink:href="#poly-028bc834-53ca-4cf7-a095-7612735a1592"/>
							<gml:surfaceMember xlink:href="#poly-6a0c355d-269e-43ca-a81f-445b680d0040"/>
							<gml:surfaceMember xlink:href="#poly-9ee400cf-e261-413a-9b3e-076cdddf81ed"/>
							<gml:surfaceMember xlink:href="#poly-8d1bb505-a0e8-4854-8ed7-fab22f1bbead"/>
							<gml:surfaceMember xlink:href="#poly-501a52b8-c9f8-45d3-aa31-9ebd696cbbdd"/>
							<gml:surfaceMember xlink:href="#poly-b6bacd6f-0260-48d3-bf6e-ca1499fd7506"/>
							<gml:surfaceMember xlink:href="#poly-53c2e1e3-a8b6-40ee-aac1-3d584a22f23f"/>
							<gml:surfaceMember xlink:href="#poly-ccf8e5eb-7639-4ddc-925f-53122e5190a9"/>
							<gml:surfaceMember xlink:href="#poly-eb5c64b7-1c26-4ab6-a160-6df7b4b54de1"/>
							<gml:surfaceMember xlink:href="#poly-1b06c3c5-6d99-4ce2-8db6-7892fe09afb8"/>
							<gml:surfaceMember xlink:href="#poly-3f2cdb83-e4f3-4955-8a9f-3b7ee4b0e53f"/>
							<gml:surfaceMember xlink:href="#poly-87da6ab3-fe96-4a36-b355-50ce30e02761"/>
							<gml:surfaceMember xlink:href="#poly-c79a8ea8-ecf7-4c3b-9b1a-331066c106e7"/>
							<gml:surfaceMember xlink:href="#poly-658a92b6-9c13-41ed-b963-0ee50384894b"/>
							<gml:surfaceMember xlink:href="#poly-62c7ee1a-e656-4cb3-b03d-4c04c08fc5ec"/>
							<gml:surfaceMember xlink:href="#poly-565bae71-5797-4eb3-b377-dacad9dabda6"/>
							<gml:surfaceMember xlink:href="#poly-dd81f6e8-a53c-4a66-adab-a706c45a2638"/>
							<gml:surfaceMember xlink:href="#poly-540981f4-a616-4f0b-8e59-6b3eb0560cd1"/>
							<gml:surfaceMember xlink:href="#poly-f73b910f-22e7-48a3-a283-d0b57835a0ac"/>
							<gml:surfaceMember xlink:href="#poly-205c169f-e4e3-425a-b994-15f57628f7cf"/>
							<gml:surfaceMember xlink:href="#poly-207b9756-4e7b-4408-8f93-8d34a0a7b4b0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d8462866-0f2b-4349-9062-1516845a51e7_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-224fe59e-3fdd-477c-8ded-0e00c8292ad3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671380084195704 139.73762812810787 34.387 35.671368507071655 139.7376464126655 34.387 35.67135265797283 139.73763134220803 34.387 35.67136423509463 139.7376130576519 34.387 35.671380084195704 139.73762812810787 34.387</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30a0aa54-262a-4594-940a-60364003edb4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148164969556 139.73767199367603 30.095 35.67146898338773 139.737692146393 30.095 35.67140247524306 139.73762931648344 30.095 35.67141514154932 139.73760917481974 30.095 35.67148164969556 139.73767199367603 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee10ab1d-f8ed-4952-a421-29d4162c6c08">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67144275005022 139.73767653597685 30.095 35.67143151559824 139.73769501896828 30.095 35.67140472539479 139.7376705610562 30.095 35.67141030660828 139.7376613748375 30.095 35.67139942816191 139.7376514460591 30.095 35.67140299294287 139.73764558721277 30.095 35.671414250238065 139.73765585797716 30.095 35.671416338691415 139.73765242005388 30.095 35.67144275005022 139.73767653597685 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8c3fad7-4c04-4b1f-9342-7eb0ede3c0eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8c3fad7-4c04-4b1f-9342-7eb0ede3c0eb_0">
											<gml:posList>35.671414250238065 139.73765585797716 30.095 35.67140299294287 139.73764558721277 30.095 35.67140299294287 139.73764558721277 32.432 35.671414250238065 139.73765585797716 32.432 35.671414250238065 139.73765585797716 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a86c34f-e63b-411d-b0ab-2f7035caa6f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a86c34f-e63b-411d-b0ab-2f7035caa6f9_0">
											<gml:posList>35.67144275005022 139.73767653597685 30.095 35.671416338691415 139.73765242005388 30.095 35.671416338691415 139.73765242005388 32.432 35.67144275005022 139.73767653597685 32.432 35.67144275005022 139.73767653597685 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-077e8b77-ebe3-4ca9-abef-129ce8783f47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-077e8b77-ebe3-4ca9-abef-129ce8783f47_0">
											<gml:posList>35.67141514154932 139.73760917481974 30.095 35.67140247524306 139.73762931648344 30.095 35.67140247524306 139.73762931648344 32.736 35.67141514154932 139.73760917481974 32.736 35.67141514154932 139.73760917481974 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4102a7b2-69c2-488d-bb65-5fa6760c1609">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4102a7b2-69c2-488d-bb65-5fa6760c1609_0">
											<gml:posList>35.67136423509463 139.7376130576519 34.387 35.67136423509463 139.7376130576519 36.295 35.671380084195704 139.73762812810787 36.295 35.671380084195704 139.73762812810787 34.387 35.67136423509463 139.7376130576519 34.387</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17f8a6ce-502f-4311-a4d8-246dc63e04de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17f8a6ce-502f-4311-a4d8-246dc63e04de_0">
											<gml:posList>35.67136423509463 139.7376130576519 34.387 35.67135265797283 139.73763134220803 34.387 35.67135265797283 139.73763134220803 36.295 35.67136423509463 139.7376130576519 36.295 35.67136423509463 139.7376130576519 34.387</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5eb589b-b7f6-4472-b3a3-13df92e414a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5eb589b-b7f6-4472-b3a3-13df92e414a8_0">
											<gml:posList>35.67135265797283 139.73763134220803 36.295 35.671368507071655 139.7376464126655 36.295 35.671380084195704 139.73762812810787 36.295 35.67136423509463 139.7376130576519 36.295 35.67135265797283 139.73763134220803 36.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d15bf2f-9594-45a1-81ff-b6ed413d3454">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d15bf2f-9594-45a1-81ff-b6ed413d3454_0">
											<gml:posList>35.671368507071655 139.7376464126655 34.387 35.671380084195704 139.73762812810787 34.387 35.671380084195704 139.73762812810787 36.295 35.671368507071655 139.7376464126655 36.295 35.671368507071655 139.7376464126655 34.387</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cab3f19-be95-469a-9f6f-9d3f025ea9c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cab3f19-be95-469a-9f6f-9d3f025ea9c0_0">
											<gml:posList>35.67135265797283 139.73763134220803 34.387 35.671368507071655 139.7376464126655 34.387 35.671368507071655 139.7376464126655 36.295 35.67135265797283 139.73763134220803 36.295 35.67135265797283 139.73763134220803 34.387</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4732a9f-cca7-4881-855a-dfcdbf338079">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4732a9f-cca7-4881-855a-dfcdbf338079_0">
											<gml:posList>35.67141514154932 139.73760917481974 30.095 35.67141514154932 139.73760917481974 32.736 35.67148164969556 139.73767199367603 32.736 35.67148164969556 139.73767199367603 30.095 35.67141514154932 139.73760917481974 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce35d09e-527a-4513-8d50-4aa6fb03803e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce35d09e-527a-4513-8d50-4aa6fb03803e_0">
											<gml:posList>35.67140299294287 139.73764558721277 30.095 35.67139942816191 139.7376514460591 30.095 35.67139942816191 139.7376514460591 32.432 35.67140299294287 139.73764558721277 32.432 35.67140299294287 139.73764558721277 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac3ced17-08fd-4358-99aa-117936d64cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac3ced17-08fd-4358-99aa-117936d64cf0_0">
											<gml:posList>35.67140247524306 139.73762931648344 32.736 35.67146898338773 139.737692146393 32.736 35.67148164969556 139.73767199367603 32.736 35.67141514154932 139.73760917481974 32.736 35.67140247524306 139.73762931648344 32.736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29238d11-873f-4d22-9540-c6c25fdd9efa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29238d11-873f-4d22-9540-c6c25fdd9efa_0">
											<gml:posList>35.671416338691415 139.73765242005388 30.095 35.671414250238065 139.73765585797716 30.095 35.671414250238065 139.73765585797716 32.432 35.671416338691415 139.73765242005388 32.432 35.671416338691415 139.73765242005388 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1acb284-0ffc-4b11-95f1-4b4e728a7bbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1acb284-0ffc-4b11-95f1-4b4e728a7bbb_0">
											<gml:posList>35.67141030660828 139.7376613748375 30.095 35.67141030660828 139.7376613748375 32.432 35.67139942816191 139.7376514460591 32.432 35.67139942816191 139.7376514460591 30.095 35.67141030660828 139.7376613748375 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40074a32-d24c-4aaa-883f-e57dd84134c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40074a32-d24c-4aaa-883f-e57dd84134c6_0">
											<gml:posList>35.67140247524306 139.73762931648344 30.095 35.67146898338773 139.737692146393 30.095 35.67146898338773 139.737692146393 32.736 35.67140247524306 139.73762931648344 32.736 35.67140247524306 139.73762931648344 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de336861-087a-42a5-90e5-80d5c347bf80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de336861-087a-42a5-90e5-80d5c347bf80_0">
											<gml:posList>35.67141030660828 139.7376613748375 30.095 35.67140472539479 139.7376705610562 30.095 35.67140472539479 139.7376705610562 32.432 35.67141030660828 139.7376613748375 32.432 35.67141030660828 139.7376613748375 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f08aa134-94e2-4f6e-9558-747c3cae9372">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f08aa134-94e2-4f6e-9558-747c3cae9372_0">
											<gml:posList>35.671414250238065 139.73765585797716 32.432 35.67140299294287 139.73764558721277 32.432 35.67139942816191 139.7376514460591 32.432 35.67141030660828 139.7376613748375 32.432 35.67140472539479 139.7376705610562 32.432 35.67143151559824 139.73769501896828 32.432 35.67144275005022 139.73767653597685 32.432 35.671416338691415 139.73765242005388 32.432 35.671414250238065 139.73765585797716 32.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17f8fa8b-1659-4a08-99ab-d37c4642dda2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17f8fa8b-1659-4a08-99ab-d37c4642dda2_0">
											<gml:posList>35.67146898338773 139.737692146393 30.095 35.67148164969556 139.73767199367603 30.095 35.67148164969556 139.73767199367603 32.736 35.67146898338773 139.737692146393 32.736 35.67146898338773 139.737692146393 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd32b836-9bb9-4bdd-9550-902e8bb2e5ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd32b836-9bb9-4bdd-9550-902e8bb2e5ed_0">
											<gml:posList>35.67143151559824 139.73769501896828 30.095 35.67143151559824 139.73769501896828 32.432 35.67140472539479 139.7376705610562 32.432 35.67140472539479 139.7376705610562 30.095 35.67143151559824 139.73769501896828 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9358b9c1-0502-43d0-93bd-7be79804dc21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9358b9c1-0502-43d0-93bd-7be79804dc21_0">
											<gml:posList>35.67144275005022 139.73767653597685 30.095 35.67144275005022 139.73767653597685 32.432 35.67143151559824 139.73769501896828 32.432 35.67143151559824 139.73769501896828 30.095 35.67144275005022 139.73767653597685 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d8462866-0f2b-4349-9062-1516845a51e7_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc84927a-ca35-49e7-90dc-5b4c78daef5e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130455120036 139.73756269110748 30.428 35.67128080817838 139.73753894765235 30.428 35.671268636926506 139.73755819394506 30.428 35.67129283905597 139.73758119674622 30.428 35.67130455120036 139.73756269110748 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1543d94c-da6d-43a6-8a23-3c23d1413abd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128080817838 139.73753894765235 10.97 35.67130455120036 139.73756269110748 10.97 35.67129283905597 139.73758119674622 10.97 35.671268636926506 139.73755819394506 10.97 35.67128080817838 139.73753894765235 10.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5706d1fb-7e32-4efd-a54f-0d7df0bdbf88">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671268636926506 139.73755819394506 30.428 35.67128080817838 139.73753894765235 30.428 35.67130455120036 139.73756269110748 30.428 35.67129283905597 139.73758119674622 30.428 35.671268636926506 139.73755819394506 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f57927a5-f503-4404-95da-e737fcee3948">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f57927a5-f503-4404-95da-e737fcee3948_0">
											<gml:posList>35.67128080817838 139.73753894765235 10.97 35.671268636926506 139.73755819394506 10.97 35.671268636926506 139.73755819394506 30.428 35.67128080817838 139.73753894765235 30.428 35.67128080817838 139.73753894765235 10.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75ca6195-d0ac-4519-8ed8-b10e9e3e10f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75ca6195-d0ac-4519-8ed8-b10e9e3e10f4_0">
											<gml:posList>35.67130455120036 139.73756269110748 10.97 35.67128080817838 139.73753894765235 10.97 35.67128080817838 139.73753894765235 30.428 35.67130455120036 139.73756269110748 30.428 35.67130455120036 139.73756269110748 10.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44a26d84-e8b4-431a-81e0-bc0ef113f1b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44a26d84-e8b4-431a-81e0-bc0ef113f1b6_0">
											<gml:posList>35.671268636926506 139.73755819394506 10.97 35.67129283905597 139.73758119674622 10.97 35.67129283905597 139.73758119674622 30.428 35.671268636926506 139.73755819394506 30.428 35.671268636926506 139.73755819394506 10.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7e886f6-2cb3-45d9-b3c8-06399a5820cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7e886f6-2cb3-45d9-b3c8-06399a5820cb_0">
											<gml:posList>35.67129283905597 139.73758119674622 10.97 35.67130455120036 139.73756269110748 10.97 35.67130455120036 139.73756269110748 30.428 35.67129283905597 139.73758119674622 30.428 35.67129283905597 139.73758119674622 10.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d8462866-0f2b-4349-9062-1516845a51e7_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-748d67df-7285-481b-bc5b-fff1671b3fd4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131260263143 139.73757675458768 30.095 35.67131849305337 139.7375823591178 30.095 35.67131375777413 139.73758983213116 30.095 35.67130786735254 139.73758422760082 30.095 35.67131260263143 139.73757675458768 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95137818-dc16-45e8-a46b-aa0e1381e037">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95137818-dc16-45e8-a46b-aa0e1381e037_0">
											<gml:posList>35.67131260263143 139.73757675458768 30.095 35.67131260263143 139.73757675458768 32.145 35.67131849305337 139.7375823591178 32.145 35.67131849305337 139.7375823591178 30.095 35.67131260263143 139.73757675458768 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38fc1b46-019f-4063-9e77-f1d430fea9c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38fc1b46-019f-4063-9e77-f1d430fea9c1_0">
											<gml:posList>35.67130786735254 139.73758422760082 30.095 35.67130786735254 139.73758422760082 32.145 35.67131260263143 139.73757675458768 32.145 35.67131260263143 139.73757675458768 30.095 35.67130786735254 139.73758422760082 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd6fb51b-a066-44fe-a7c2-790bdf336e5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd6fb51b-a066-44fe-a7c2-790bdf336e5a_0">
											<gml:posList>35.67131375777413 139.73758983213116 32.145 35.67131849305337 139.7375823591178 32.145 35.67131260263143 139.73757675458768 32.145 35.67130786735254 139.73758422760082 32.145 35.67131375777413 139.73758983213116 32.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b802c32-21f2-4d28-8fd9-1736df950bbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b802c32-21f2-4d28-8fd9-1736df950bbf_0">
											<gml:posList>35.67131849305337 139.7375823591178 30.095 35.67131849305337 139.7375823591178 32.145 35.67131375777413 139.73758983213116 32.145 35.67131375777413 139.73758983213116 30.095 35.67131849305337 139.7375823591178 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9b94cb6-e344-4968-8b5a-e4439883e56b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9b94cb6-e344-4968-8b5a-e4439883e56b_0">
											<gml:posList>35.67131375777413 139.73758983213116 30.095 35.67131375777413 139.73758983213116 32.145 35.67130786735254 139.73758422760082 32.145 35.67130786735254 139.73758422760082 30.095 35.67131375777413 139.73758983213116 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-31f78a48-f40e-4109-b998-e196c3642250">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31f78a48-f40e-4109-b998-e196c3642250">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31f78a48-f40e-4109-b998-e196c3642250">
											<gml:posList>35.67130455120036 139.73756269110748 10.93 35.67128080817838 139.73753894765235 10.93 35.67131373897418 139.73748689086602 10.93 35.6714973044392 139.73765800128479 10.93 35.67145085190002 139.73773140485883 10.93 35.67129283905597 139.73758119674622 10.93 35.67130455120036 139.73756269110748 10.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2f94645d-4e4f-4787-917a-e395a686d9ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f94645d-4e4f-4787-917a-e395a686d9ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f94645d-4e4f-4787-917a-e395a686d9ea">
											<gml:posList>35.67128080817838 139.73753894765235 30.428 35.67128440426621 139.7375384573148 30.428 35.67130773849851 139.73750156764126 30.428 35.671307275255735 139.73749711650106 30.428 35.67128080817838 139.73753894765235 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee81a20b-6612-45c1-ad37-72ff6c7f886d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee81a20b-6612-45c1-ad37-72ff6c7f886d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee81a20b-6612-45c1-ad37-72ff6c7f886d">
											<gml:posList>35.67130455120036 139.73756269110748 30.428 35.67130814728829 139.73756220077084 30.428 35.67128440426621 139.7375384573148 30.428 35.67128080817838 139.73753894765235 30.428 35.67130455120036 139.73756269110748 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2534cb47-f357-4937-9f23-1bfb8bb47157">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2534cb47-f357-4937-9f23-1bfb8bb47157">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2534cb47-f357-4937-9f23-1bfb8bb47157">
											<gml:posList>35.67130455120036 139.73756269110748 30.428 35.67129283905597 139.73758119674622 30.428 35.67129647115493 139.73758065113554 30.428 35.67130814728829 139.73756220077084 30.428 35.67130455120036 139.73756269110748 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ada8f9c-09f7-4091-a39c-fb959c2e2296">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ada8f9c-09f7-4091-a39c-fb959c2e2296">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ada8f9c-09f7-4091-a39c-fb959c2e2296">
											<gml:posList>35.67148954435429 139.73767027206253 30.428 35.6714973044392 139.73765800128479 27.38 35.67131373897418 139.73748689086602 27.38 35.67148954435429 139.73767027206253 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7ee6c03d-a645-483f-9c20-7cec91842573">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ee6c03d-a645-483f-9c20-7cec91842573">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ee6c03d-a645-483f-9c20-7cec91842573">
											<gml:posList>35.67131373897418 139.73748689086602 27.38 35.671307275255735 139.73749711650106 30.428 35.67148954435429 139.73767027206253 30.428 35.67131373897418 139.73748689086602 27.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e6b0309-9668-45d2-980e-e10b7e6b1f57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e6b0309-9668-45d2-980e-e10b7e6b1f57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e6b0309-9668-45d2-980e-e10b7e6b1f57">
											<gml:posList>35.671307275255735 139.73749711650106 30.428 35.67130773849851 139.73750156764126 30.428 35.67148592127752 139.73767082870611 30.428 35.67148954435429 139.73767027206253 30.428 35.671307275255735 139.73749711650106 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-59245f71-7902-4e71-ad24-682c06c7d9aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59245f71-7902-4e71-ad24-682c06c7d9aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59245f71-7902-4e71-ad24-682c06c7d9aa">
											<gml:posList>35.6713484507251 139.7376340646427 30.428 35.67135003514698 139.7376315552203 30.428 35.67129647115493 139.73758065113554 30.428 35.67129283905597 139.73758119674622 30.428 35.6713484507251 139.7376340646427 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00a061c3-a76e-4ff9-906d-154ec2e5e7f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00a061c3-a76e-4ff9-906d-154ec2e5e7f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00a061c3-a76e-4ff9-906d-154ec2e5e7f2">
											<gml:posList>35.67137812600184 139.7376140021041 34.564 35.671367499795174 139.7376038962926 34.564 35.671367744992274 139.73760619365 34.564 35.67137730678066 139.73761529551055 34.564 35.67137812600184 139.7376140021041 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9c40f12-d1c5-44cf-bdf7-817e3f761f7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9c40f12-d1c5-44cf-bdf7-817e3f761f7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9c40f12-d1c5-44cf-bdf7-817e3f761f7f">
											<gml:posList>35.67139240400724 139.73761432749615 33.417 35.67138335640484 139.73760573315434 33.417 35.67137812600184 139.7376140021041 34.564 35.67138716458993 139.737622596457 34.564 35.67139240400724 139.73761432749615 33.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b3638f6e-0de8-45a5-a5dc-69b6156649a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3638f6e-0de8-45a5-a5dc-69b6156649a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3638f6e-0de8-45a5-a5dc-69b6156649a3">
											<gml:posList>35.67130814728829 139.73756220077084 30.095 35.67129647115493 139.73758065113554 30.095 35.67135003514698 139.7376315552203 30.095 35.671367499795174 139.7376038962926 30.095 35.67137812600184 139.7376140021041 30.095 35.67138335640484 139.73760573315434 30.095 35.67139240400724 139.73761432749615 30.095 35.67137920646121 139.7376351878032 30.095 35.67140375135153 139.73765851059582 30.095 35.671394262887475 139.73767362234597 30.095 35.67145039768821 139.73772696474498 30.095 35.67148592127752 139.73767082870611 30.095 35.67130773849851 139.73750156764126 30.095 35.67128440426621 139.7375384573148 30.095 35.67130814728829 139.73756220077084 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7bd96803-21a3-4e82-9fa0-29dab652973f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bd96803-21a3-4e82-9fa0-29dab652973f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bd96803-21a3-4e82-9fa0-29dab652973f">
											<gml:posList>35.67137812600184 139.7376140021041 34.564 35.67137730678066 139.73761529551055 34.564 35.67138528996437 139.7376228859012 34.564 35.67138716458993 139.737622596457 34.564 35.67137812600184 139.7376140021041 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4476f779-7b22-4c8a-a180-94468f69078c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4476f779-7b22-4c8a-a180-94468f69078c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4476f779-7b22-4c8a-a180-94468f69078c">
											<gml:posList>35.6713484507251 139.7376340646427 34.564 35.671350334355644 139.73763376414172 34.564 35.671367744992274 139.73760619365 34.564 35.671367499795174 139.7376038962926 34.564 35.6713484507251 139.7376340646427 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f96f722-b481-4b62-8cdb-6380bd9c5808">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f96f722-b481-4b62-8cdb-6380bd9c5808">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f96f722-b481-4b62-8cdb-6380bd9c5808">
											<gml:posList>35.671367861270184 139.7376504232777 34.387 35.67138528996437 139.7376228859012 34.387 35.67137730678066 139.73761529551055 34.387 35.671367744992274 139.73760619365 34.387 35.671350334355644 139.73763376414172 34.387 35.671367861270184 139.7376504232777 34.387</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37e7068d-3bd4-4ca7-b647-0b3d7ea3dd75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37e7068d-3bd4-4ca7-b647-0b3d7ea3dd75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37e7068d-3bd4-4ca7-b647-0b3d7ea3dd75">
											<gml:posList>35.67138716458993 139.737622596457 34.564 35.67138528996437 139.7376228859012 34.564 35.671367861270184 139.7376504232777 34.564 35.671368088447736 139.73765273170318 34.564 35.67138716458993 139.737622596457 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4f1d402-2b76-4418-9a5f-04dcb1cff123">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4f1d402-2b76-4418-9a5f-04dcb1cff123">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4f1d402-2b76-4418-9a5f-04dcb1cff123">
											<gml:posList>35.671368088447736 139.73765273170318 34.564 35.671367861270184 139.7376504232777 34.564 35.671350334355644 139.73763376414172 34.564 35.6713484507251 139.7376340646427 34.564 35.671368088447736 139.73765273170318 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c0b8109-36d3-411f-8036-ac1e11724917">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c0b8109-36d3-411f-8036-ac1e11724917">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c0b8109-36d3-411f-8036-ac1e11724917">
											<gml:posList>35.67137920646121 139.7376351878032 33.318 35.67137832422278 139.73763658070223 33.318 35.67140174153763 139.73765882229338 33.318 35.67140375135153 139.73765851059582 33.318 35.67137920646121 139.7376351878032 33.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15125252-18b3-4405-bfa5-94cb1b3f9776">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15125252-18b3-4405-bfa5-94cb1b3f9776">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15125252-18b3-4405-bfa5-94cb1b3f9776">
											<gml:posList>35.67140174153763 139.73765882229338 33.154 35.67137832422278 139.73763658070223 33.154 35.67136897068636 139.7376513388045 33.154 35.6713924421335 139.7376736466112 33.154 35.67140174153763 139.73765882229338 33.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9acba31-012e-4f71-9eaf-cc43488a9232">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9acba31-012e-4f71-9eaf-cc43488a9232">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9acba31-012e-4f71-9eaf-cc43488a9232">
											<gml:posList>35.671368088447736 139.73765273170318 33.318 35.671392696483395 139.73767612070102 33.318 35.6713924421335 139.7376736466112 33.318 35.67136897068636 139.7376513388045 33.318 35.671368088447736 139.73765273170318 33.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b9dfe94-9921-4848-9638-ff172e1e41d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b9dfe94-9921-4848-9638-ff172e1e41d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b9dfe94-9921-4848-9638-ff172e1e41d2">
											<gml:posList>35.67140375135153 139.73765851059582 33.318 35.67140174153763 139.73765882229338 33.318 35.6713924421335 139.7376736466112 33.318 35.671392696483395 139.73767612070102 33.318 35.67140375135153 139.73765851059582 33.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a28f5b46-fa12-4f55-8719-b64edfa80c34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a28f5b46-fa12-4f55-8719-b64edfa80c34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a28f5b46-fa12-4f55-8719-b64edfa80c34">
											<gml:posList>35.67148954435429 139.73767027206253 30.428 35.67148592127752 139.73767082870611 30.428 35.67145039768821 139.73772696474498 30.428 35.67145085190002 139.73773140485883 30.428 35.67148954435429 139.73767027206253 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-82f752c9-bba3-4322-b769-75756c570032">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82f752c9-bba3-4322-b769-75756c570032">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82f752c9-bba3-4322-b769-75756c570032">
											<gml:posList>35.671392696483395 139.73767612070102 30.428 35.67145085190002 139.73773140485883 30.428 35.67145039768821 139.73772696474498 30.428 35.671394262887475 139.73767362234597 30.428 35.671392696483395 139.73767612070102 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90f7e986-9172-4bd1-b91e-0055d93c0876">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90f7e986-9172-4bd1-b91e-0055d93c0876">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90f7e986-9172-4bd1-b91e-0055d93c0876">
											<gml:posList>35.671367744992274 139.73760619365 34.564 35.671367744992274 139.73760619365 34.387 35.67137730678066 139.73761529551055 34.387 35.67137730678066 139.73761529551055 34.564 35.671367744992274 139.73760619365 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d37b0b71-8554-453d-a63f-739e91be5f60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d37b0b71-8554-453d-a63f-739e91be5f60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d37b0b71-8554-453d-a63f-739e91be5f60">
											<gml:posList>35.67137730678066 139.73761529551055 34.564 35.67137730678066 139.73761529551055 34.387 35.67138528996437 139.7376228859012 34.387 35.67138528996437 139.7376228859012 34.564 35.67137730678066 139.73761529551055 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a8488c4-01f2-4493-b420-0fb84451c536">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a8488c4-01f2-4493-b420-0fb84451c536">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a8488c4-01f2-4493-b420-0fb84451c536">
											<gml:posList>35.671350334355644 139.73763376414172 34.564 35.671350334355644 139.73763376414172 34.387 35.671367744992274 139.73760619365 34.387 35.671367744992274 139.73760619365 34.564 35.671350334355644 139.73763376414172 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-081c3b82-fcec-48ed-94d8-ef0e35f6c2c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-081c3b82-fcec-48ed-94d8-ef0e35f6c2c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-081c3b82-fcec-48ed-94d8-ef0e35f6c2c3">
											<gml:posList>35.67138528996437 139.7376228859012 34.564 35.67138528996437 139.7376228859012 34.387 35.671367861270184 139.7376504232777 34.387 35.671367861270184 139.7376504232777 34.564 35.67138528996437 139.7376228859012 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ee6370c-2489-4683-bbe6-2e76db21dfb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ee6370c-2489-4683-bbe6-2e76db21dfb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ee6370c-2489-4683-bbe6-2e76db21dfb4">
											<gml:posList>35.67137832422278 139.73763658070223 33.318 35.67137832422278 139.73763658070223 33.154 35.67140174153763 139.73765882229338 33.154 35.67140174153763 139.73765882229338 33.318 35.67137832422278 139.73763658070223 33.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4173f62-65b1-4bcd-b44b-410bc7b4434e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4173f62-65b1-4bcd-b44b-410bc7b4434e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4173f62-65b1-4bcd-b44b-410bc7b4434e">
											<gml:posList>35.6713924421335 139.7376736466112 33.318 35.6713924421335 139.7376736466112 33.154 35.67136897068636 139.7376513388045 33.154 35.67136897068636 139.7376513388045 33.318 35.6713924421335 139.7376736466112 33.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e521b615-c9f1-44db-85ae-ae0598a2611a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e521b615-c9f1-44db-85ae-ae0598a2611a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e521b615-c9f1-44db-85ae-ae0598a2611a">
											<gml:posList>35.67148954435429 139.73767027206253 30.428 35.67145085190002 139.73773140485883 30.428 35.67145085190002 139.73773140485883 10.93 35.6714973044392 139.73765800128479 10.93 35.6714973044392 139.73765800128479 27.38 35.67148954435429 139.73767027206253 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-028bc834-53ca-4cf7-a095-7612735a1592">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-028bc834-53ca-4cf7-a095-7612735a1592">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-028bc834-53ca-4cf7-a095-7612735a1592">
											<gml:posList>35.67128080817838 139.73753894765235 10.93 35.67130455120036 139.73756269110748 10.93 35.67130455120036 139.73756269110748 30.428 35.67128080817838 139.73753894765235 30.428 35.67128080817838 139.73753894765235 10.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a0c355d-269e-43ca-a81f-445b680d0040">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a0c355d-269e-43ca-a81f-445b680d0040">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a0c355d-269e-43ca-a81f-445b680d0040">
											<gml:posList>35.67128440426621 139.7375384573148 30.428 35.67128440426621 139.7375384573148 30.095 35.67130773849851 139.73750156764126 30.095 35.67130773849851 139.73750156764126 30.428 35.67128440426621 139.7375384573148 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ee400cf-e261-413a-9b3e-076cdddf81ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ee400cf-e261-413a-9b3e-076cdddf81ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ee400cf-e261-413a-9b3e-076cdddf81ed">
											<gml:posList>35.67130814728829 139.73756220077084 30.428 35.67130814728829 139.73756220077084 30.095 35.67128440426621 139.7375384573148 30.095 35.67128440426621 139.7375384573148 30.428 35.67130814728829 139.73756220077084 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d1bb505-a0e8-4854-8ed7-fab22f1bbead">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d1bb505-a0e8-4854-8ed7-fab22f1bbead">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d1bb505-a0e8-4854-8ed7-fab22f1bbead">
											<gml:posList>35.67128080817838 139.73753894765235 30.428 35.671307275255735 139.73749711650106 30.428 35.67131373897418 139.73748689086602 27.38 35.67131373897418 139.73748689086602 10.93 35.67128080817838 139.73753894765235 10.93 35.67128080817838 139.73753894765235 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-501a52b8-c9f8-45d3-aa31-9ebd696cbbdd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-501a52b8-c9f8-45d3-aa31-9ebd696cbbdd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-501a52b8-c9f8-45d3-aa31-9ebd696cbbdd">
											<gml:posList>35.67130455120036 139.73756269110748 10.93 35.67129283905597 139.73758119674622 10.93 35.67129283905597 139.73758119674622 30.428 35.67130455120036 139.73756269110748 30.428 35.67130455120036 139.73756269110748 10.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6bacd6f-0260-48d3-bf6e-ca1499fd7506">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6bacd6f-0260-48d3-bf6e-ca1499fd7506">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6bacd6f-0260-48d3-bf6e-ca1499fd7506">
											<gml:posList>35.67129647115493 139.73758065113554 30.428 35.67129647115493 139.73758065113554 30.095 35.67130814728829 139.73756220077084 30.095 35.67130814728829 139.73756220077084 30.428 35.67129647115493 139.73758065113554 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53c2e1e3-a8b6-40ee-aac1-3d584a22f23f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53c2e1e3-a8b6-40ee-aac1-3d584a22f23f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53c2e1e3-a8b6-40ee-aac1-3d584a22f23f">
											<gml:posList>35.67135003514698 139.7376315552203 30.428 35.67135003514698 139.7376315552203 30.095 35.67129647115493 139.73758065113554 30.095 35.67129647115493 139.73758065113554 30.428 35.67135003514698 139.7376315552203 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccf8e5eb-7639-4ddc-925f-53122e5190a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccf8e5eb-7639-4ddc-925f-53122e5190a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccf8e5eb-7639-4ddc-925f-53122e5190a9">
											<gml:posList>35.67135003514698 139.7376315552203 30.428 35.6713484507251 139.7376340646427 30.428 35.6713484507251 139.7376340646427 34.564 35.671367499795174 139.7376038962926 34.564 35.671367499795174 139.7376038962926 30.095 35.67135003514698 139.7376315552203 30.095 35.67135003514698 139.7376315552203 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb5c64b7-1c26-4ab6-a160-6df7b4b54de1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb5c64b7-1c26-4ab6-a160-6df7b4b54de1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb5c64b7-1c26-4ab6-a160-6df7b4b54de1">
											<gml:posList>35.671367861270184 139.7376504232777 34.564 35.671367861270184 139.7376504232777 34.387 35.671350334355644 139.73763376414172 34.387 35.671350334355644 139.73763376414172 34.564 35.671367861270184 139.7376504232777 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b06c3c5-6d99-4ce2-8db6-7892fe09afb8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b06c3c5-6d99-4ce2-8db6-7892fe09afb8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b06c3c5-6d99-4ce2-8db6-7892fe09afb8">
											<gml:posList>35.671368088447736 139.73765273170318 33.318 35.671368088447736 139.73765273170318 34.564 35.6713484507251 139.7376340646427 34.564 35.6713484507251 139.7376340646427 30.428 35.67129283905597 139.73758119674622 30.428 35.67129283905597 139.73758119674622 10.93 35.67145085190002 139.73773140485883 10.93 35.67145085190002 139.73773140485883 30.428 35.671392696483395 139.73767612070102 30.428 35.671392696483395 139.73767612070102 33.318 35.671368088447736 139.73765273170318 33.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f2cdb83-e4f3-4955-8a9f-3b7ee4b0e53f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f2cdb83-e4f3-4955-8a9f-3b7ee4b0e53f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f2cdb83-e4f3-4955-8a9f-3b7ee4b0e53f">
											<gml:posList>35.671367499795174 139.7376038962926 34.564 35.67137812600184 139.7376140021041 34.564 35.67137812600184 139.7376140021041 30.095 35.671367499795174 139.7376038962926 30.095 35.671367499795174 139.7376038962926 34.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87da6ab3-fe96-4a36-b355-50ce30e02761">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87da6ab3-fe96-4a36-b355-50ce30e02761">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87da6ab3-fe96-4a36-b355-50ce30e02761">
											<gml:posList>35.67137920646121 139.7376351878032 33.318 35.67137920646121 139.7376351878032 30.095 35.67139240400724 139.73761432749615 30.095 35.67139240400724 139.73761432749615 33.417 35.67138716458993 139.737622596457 34.564 35.671368088447736 139.73765273170318 34.564 35.671368088447736 139.73765273170318 33.318 35.67136897068636 139.7376513388045 33.318 35.67136897068636 139.7376513388045 33.154 35.67137832422278 139.73763658070223 33.154 35.67137832422278 139.73763658070223 33.318 35.67137920646121 139.7376351878032 33.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c79a8ea8-ecf7-4c3b-9b1a-331066c106e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c79a8ea8-ecf7-4c3b-9b1a-331066c106e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c79a8ea8-ecf7-4c3b-9b1a-331066c106e7">
											<gml:posList>35.67137812600184 139.7376140021041 30.095 35.67137812600184 139.7376140021041 34.564 35.67138335640484 139.73760573315434 33.417 35.67138335640484 139.73760573315434 30.095 35.67137812600184 139.7376140021041 30.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-658a92b6-9c13-41ed-b963-0ee50384894b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-658a92b6-9c13-41ed-b963-0ee50384894b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-658a92b6-9c13-41ed-b963-0ee50384894b">
											<gml:posList>35.67138335640484 139.73760573315434 33.417 35.67139240400724 139.73761432749615 33.417 35.67139240400724 139.73761432749615 30.095 35.67138335640484 139.73760573315434 30.095 35.67138335640484 139.73760573315434 33.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62c7ee1a-e656-4cb3-b03d-4c04c08fc5ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62c7ee1a-e656-4cb3-b03d-4c04c08fc5ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62c7ee1a-e656-4cb3-b03d-4c04c08fc5ec">
											<gml:posList>35.67137920646121 139.7376351878032 33.318 35.67140375135153 139.73765851059582 33.318 35.67140375135153 139.73765851059582 30.095 35.67137920646121 139.7376351878032 30.095 35.67137920646121 139.7376351878032 33.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-565bae71-5797-4eb3-b377-dacad9dabda6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-565bae71-5797-4eb3-b377-dacad9dabda6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-565bae71-5797-4eb3-b377-dacad9dabda6">
											<gml:posList>35.67130773849851 139.73750156764126 30.428 35.67130773849851 139.73750156764126 30.095 35.67148592127752 139.73767082870611 30.095 35.67148592127752 139.73767082870611 30.428 35.67130773849851 139.73750156764126 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd81f6e8-a53c-4a66-adab-a706c45a2638">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd81f6e8-a53c-4a66-adab-a706c45a2638">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd81f6e8-a53c-4a66-adab-a706c45a2638">
											<gml:posList>35.67140174153763 139.73765882229338 33.318 35.67140174153763 139.73765882229338 33.154 35.6713924421335 139.7376736466112 33.154 35.6713924421335 139.7376736466112 33.318 35.67140174153763 139.73765882229338 33.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-540981f4-a616-4f0b-8e59-6b3eb0560cd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-540981f4-a616-4f0b-8e59-6b3eb0560cd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-540981f4-a616-4f0b-8e59-6b3eb0560cd1">
											<gml:posList>35.671392696483395 139.73767612070102 33.318 35.671392696483395 139.73767612070102 30.428 35.671394262887475 139.73767362234597 30.428 35.671394262887475 139.73767362234597 30.095 35.67140375135153 139.73765851059582 30.095 35.67140375135153 139.73765851059582 33.318 35.671392696483395 139.73767612070102 33.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f73b910f-22e7-48a3-a283-d0b57835a0ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f73b910f-22e7-48a3-a283-d0b57835a0ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f73b910f-22e7-48a3-a283-d0b57835a0ac">
											<gml:posList>35.6714973044392 139.73765800128479 10.93 35.67131373897418 139.73748689086602 10.93 35.67131373897418 139.73748689086602 27.38 35.6714973044392 139.73765800128479 27.38 35.6714973044392 139.73765800128479 10.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-205c169f-e4e3-425a-b994-15f57628f7cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-205c169f-e4e3-425a-b994-15f57628f7cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-205c169f-e4e3-425a-b994-15f57628f7cf">
											<gml:posList>35.67145039768821 139.73772696474498 30.428 35.67145039768821 139.73772696474498 30.095 35.671394262887475 139.73767362234597 30.095 35.671394262887475 139.73767362234597 30.428 35.67145039768821 139.73772696474498 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-207b9756-4e7b-4408-8f93-8d34a0a7b4b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-207b9756-4e7b-4408-8f93-8d34a0a7b4b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-207b9756-4e7b-4408-8f93-8d34a0a7b4b0">
											<gml:posList>35.67148592127752 139.73767082870611 30.428 35.67148592127752 139.73767082870611 30.095 35.67145039768821 139.73772696474498 30.095 35.67145039768821 139.73772696474498 30.428 35.67148592127752 139.73767082870611 30.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7951</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">211.6124</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>