<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d95566f7-e6a9-4742-b60a-b7a7aa6e6c1f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">6.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66894399313832 139.73950121143545 0 35.66899233819852 139.73942593113594 0 35.66895833233267 139.73939504198532 0 35.66891088900836 139.7394707630582 0 35.66894399313832 139.73950121143545 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894399313832 139.73950121143545 11.704 35.66891088900836 139.7394707630582 11.704 35.66895833233267 139.73939504198532 11.704 35.66899233819852 139.73942593113594 11.704 35.66894399313832 139.73950121143545 11.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894399313832 139.73950121143545 11.704 35.66899233819852 139.73942593113594 11.704 35.66899233819852 139.73942593113594 18.39 35.66894399313832 139.73950121143545 18.39 35.66894399313832 139.73950121143545 11.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66899233819852 139.73942593113594 11.704 35.66895833233267 139.73939504198532 11.704 35.66895833233267 139.73939504198532 18.39 35.66899233819852 139.73942593113594 18.39 35.66899233819852 139.73942593113594 11.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895833233267 139.73939504198532 11.704 35.66891088900836 139.7394707630582 11.704 35.66891088900836 139.7394707630582 18.39 35.66895833233267 139.73939504198532 18.39 35.66895833233267 139.73939504198532 11.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891088900836 139.7394707630582 11.704 35.66894399313832 139.73950121143545 11.704 35.66894399313832 139.73950121143545 18.39 35.66891088900836 139.7394707630582 18.39 35.66891088900836 139.7394707630582 11.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894399313832 139.73950121143545 18.39 35.66899233819852 139.73942593113594 18.39 35.66895833233267 139.73939504198532 18.39 35.66891088900836 139.7394707630582 18.39 35.66894399313832 139.73950121143545 18.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e9807044-ae8a-4a19-963b-b309714c9f31"/>
							<gml:surfaceMember xlink:href="#poly-63fdaeec-48b8-4bc7-89cb-b4ac32ed8346"/>
							<gml:surfaceMember xlink:href="#poly-c79fdddf-b557-4b92-afea-a7a135d79857"/>
							<gml:surfaceMember xlink:href="#poly-1ca38265-c91f-4247-9cf0-1e9eb926953a"/>
							<gml:surfaceMember xlink:href="#poly-0ff6ad29-3f32-4385-ae71-bceee2824923"/>
							<gml:surfaceMember xlink:href="#poly-5bd8c340-6dad-41b7-8973-66080a49f9d6"/>
							<gml:surfaceMember xlink:href="#poly-a86c244a-d2dc-4c97-90e7-385356f4296b"/>
							<gml:surfaceMember xlink:href="#poly-79cd0596-db62-4c84-be9c-157b2a6151c8"/>
							<gml:surfaceMember xlink:href="#poly-aa13b793-22ea-4306-9865-7efcb4482d19"/>
							<gml:surfaceMember xlink:href="#poly-ea196bb5-ab35-4d84-8b3c-d8425df76818"/>
							<gml:surfaceMember xlink:href="#poly-d0cc9eb3-fb4c-46a3-bdc7-c3e58fb73e05"/>
							<gml:surfaceMember xlink:href="#poly-41aa1158-1aa3-4574-beb8-45e78b01034f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e9807044-ae8a-4a19-963b-b309714c9f31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9807044-ae8a-4a19-963b-b309714c9f31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9807044-ae8a-4a19-963b-b309714c9f31">
											<gml:posList>35.66894399313829 139.73950121143545 11.704 35.66891088900836 139.73947076305816 11.704 35.668958332332686 139.73939504198532 11.704 35.6689923381985 139.7394259311359 11.704 35.66894399313829 139.73950121143545 11.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63fdaeec-48b8-4bc7-89cb-b4ac32ed8346">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63fdaeec-48b8-4bc7-89cb-b4ac32ed8346">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63fdaeec-48b8-4bc7-89cb-b4ac32ed8346">
											<gml:posList>35.6689923381985 139.7394259311359 19.161 35.6689753352666 139.73941048655732 21.142 35.66895936548235 139.73943687221777 21.142 35.6689923381985 139.7394259311359 19.161</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c79fdddf-b557-4b92-afea-a7a135d79857">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c79fdddf-b557-4b92-afea-a7a135d79857">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c79fdddf-b557-4b92-afea-a7a135d79857">
											<gml:posList>35.66895936548235 139.73943687221777 21.142 35.6689753352666 139.73941048655732 21.142 35.668958332332686 139.73939504198532 19.161 35.668931279741535 139.7394382195885 19.161 35.66894842742353 139.73945434885087 21.142 35.66895936548235 139.73943687221777 21.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ca38265-c91f-4247-9cf0-1e9eb926953a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ca38265-c91f-4247-9cf0-1e9eb926953a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ca38265-c91f-4247-9cf0-1e9eb926953a">
											<gml:posList>35.66895936548235 139.73943687221777 21.142 35.66897538592356 139.73945232899527 19.161 35.6689923381985 139.7394259311359 19.161 35.66895936548235 139.73943687221777 21.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ff6ad29-3f32-4385-ae71-bceee2824923">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ff6ad29-3f32-4385-ae71-bceee2824923">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ff6ad29-3f32-4385-ae71-bceee2824923">
											<gml:posList>35.66894399313829 139.73950121143545 18.666 35.66897538592356 139.73945232899527 18.666 35.66895936548235 139.73943687221777 18.666 35.668948265365955 139.739454592054 18.666 35.668931279741535 139.7394382195885 18.666 35.66891088900836 139.73947076305816 18.666 35.66894399313829 139.73950121143545 18.666</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5bd8c340-6dad-41b7-8973-66080a49f9d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bd8c340-6dad-41b7-8973-66080a49f9d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bd8c340-6dad-41b7-8973-66080a49f9d6">
											<gml:posList>35.668958332332686 139.73939504198532 19.161 35.6689753352666 139.73941048655732 21.142 35.6689923381985 139.7394259311359 19.161 35.6689923381985 139.7394259311359 11.704 35.668958332332686 139.73939504198532 11.704 35.668958332332686 139.73939504198532 19.161</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a86c244a-d2dc-4c97-90e7-385356f4296b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a86c244a-d2dc-4c97-90e7-385356f4296b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a86c244a-d2dc-4c97-90e7-385356f4296b">
											<gml:posList>35.66891088900836 139.73947076305816 11.704 35.66891088900836 139.73947076305816 18.666 35.668931279741535 139.7394382195885 18.666 35.668931279741535 139.7394382195885 19.161 35.668958332332686 139.73939504198532 19.161 35.668958332332686 139.73939504198532 11.704 35.66891088900836 139.73947076305816 11.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79cd0596-db62-4c84-be9c-157b2a6151c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79cd0596-db62-4c84-be9c-157b2a6151c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79cd0596-db62-4c84-be9c-157b2a6151c8">
											<gml:posList>35.66895936548235 139.73943687221777 18.666 35.66897538592356 139.73945232899527 18.666 35.66897538592356 139.73945232899527 19.161 35.66895936548235 139.73943687221777 21.142 35.66895936548235 139.73943687221777 18.666</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa13b793-22ea-4306-9865-7efcb4482d19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa13b793-22ea-4306-9865-7efcb4482d19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa13b793-22ea-4306-9865-7efcb4482d19">
											<gml:posList>35.66894842742353 139.73945434885087 21.142 35.668948265365955 139.739454592054 18.666 35.66895936548235 139.73943687221777 18.666 35.66895936548235 139.73943687221777 21.142 35.66894842742353 139.73945434885087 21.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea196bb5-ab35-4d84-8b3c-d8425df76818">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea196bb5-ab35-4d84-8b3c-d8425df76818">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea196bb5-ab35-4d84-8b3c-d8425df76818">
											<gml:posList>35.668948265365955 139.739454592054 18.666 35.66894842742353 139.73945434885087 21.142 35.668931279741535 139.7394382195885 19.161 35.668931279741535 139.7394382195885 18.666 35.668948265365955 139.739454592054 18.666</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0cc9eb3-fb4c-46a3-bdc7-c3e58fb73e05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0cc9eb3-fb4c-46a3-bdc7-c3e58fb73e05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0cc9eb3-fb4c-46a3-bdc7-c3e58fb73e05">
											<gml:posList>35.66894399313829 139.73950121143545 11.704 35.6689923381985 139.7394259311359 11.704 35.6689923381985 139.7394259311359 19.161 35.66897538592356 139.73945232899527 19.161 35.66897538592356 139.73945232899527 18.666 35.66894399313829 139.73950121143545 18.666 35.66894399313829 139.73950121143545 11.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41aa1158-1aa3-4574-beb8-45e78b01034f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41aa1158-1aa3-4574-beb8-45e78b01034f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41aa1158-1aa3-4574-beb8-45e78b01034f">
											<gml:posList>35.66891088900836 139.73947076305816 11.704 35.66894399313829 139.73950121143545 11.704 35.66894399313829 139.73950121143545 18.666 35.66891088900836 139.73947076305816 18.666 35.66891088900836 139.73947076305816 11.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6189</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">40.1972</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>