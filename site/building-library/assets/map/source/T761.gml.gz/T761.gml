<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d99fdbec-db07-4a29-8e4c-d8d4954f488a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">17.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67181350976235 139.74030855263683 0 35.671833677109156 139.74027826193716 0 35.67173381809422 139.7401786284341 0 35.671720403287885 139.7401988590136 0 35.67169604735726 139.74017447467293 0 35.67165022074276 139.74024334720804 0 35.67180745122996 139.74040024525198 0 35.67184652549157 139.74034154324852 0 35.67181350976235 139.74030855263683 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181350976235 139.74030855263683 8.126 35.67184652549157 139.74034154324852 8.126 35.67180745122996 139.74040024525198 8.126 35.67165022074276 139.74024334720804 8.126 35.67169604735726 139.74017447467293 8.126 35.671720403287885 139.7401988590136 8.126 35.67173381809422 139.7401786284341 8.126 35.671833677109156 139.74027826193716 8.126 35.67181350976235 139.74030855263683 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181350976235 139.74030855263683 8.126 35.671833677109156 139.74027826193716 8.126 35.671833677109156 139.74027826193716 25.29 35.67181350976235 139.74030855263683 25.29 35.67181350976235 139.74030855263683 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671833677109156 139.74027826193716 8.126 35.67173381809422 139.7401786284341 8.126 35.67173381809422 139.7401786284341 25.29 35.671833677109156 139.74027826193716 25.29 35.671833677109156 139.74027826193716 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67173381809422 139.7401786284341 8.126 35.671720403287885 139.7401988590136 8.126 35.671720403287885 139.7401988590136 25.29 35.67173381809422 139.7401786284341 25.29 35.67173381809422 139.7401786284341 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671720403287885 139.7401988590136 8.126 35.67169604735726 139.74017447467293 8.126 35.67169604735726 139.74017447467293 25.29 35.671720403287885 139.7401988590136 25.29 35.671720403287885 139.7401988590136 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67169604735726 139.74017447467293 8.126 35.67165022074276 139.74024334720804 8.126 35.67165022074276 139.74024334720804 25.29 35.67169604735726 139.74017447467293 25.29 35.67169604735726 139.74017447467293 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67165022074276 139.74024334720804 8.126 35.67180745122996 139.74040024525198 8.126 35.67180745122996 139.74040024525198 25.29 35.67165022074276 139.74024334720804 25.29 35.67165022074276 139.74024334720804 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180745122996 139.74040024525198 8.126 35.67184652549157 139.74034154324852 8.126 35.67184652549157 139.74034154324852 25.29 35.67180745122996 139.74040024525198 25.29 35.67180745122996 139.74040024525198 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67184652549157 139.74034154324852 8.126 35.67181350976235 139.74030855263683 8.126 35.67181350976235 139.74030855263683 25.29 35.67184652549157 139.74034154324852 25.29 35.67184652549157 139.74034154324852 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181350976235 139.74030855263683 25.29 35.671833677109156 139.74027826193716 25.29 35.67173381809422 139.7401786284341 25.29 35.671720403287885 139.7401988590136 25.29 35.67169604735726 139.74017447467293 25.29 35.67165022074276 139.74024334720804 25.29 35.67180745122996 139.74040024525198 25.29 35.67184652549157 139.74034154324852 25.29 35.67181350976235 139.74030855263683 25.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-baf48733-83c7-48bf-8d63-af9a7c367dbb"/>
							<gml:surfaceMember xlink:href="#poly-8b6b05e4-bbe0-4f6a-ba06-d55a5ca480e7"/>
							<gml:surfaceMember xlink:href="#poly-ef0edf31-dd11-45ef-81c2-23cdb55523dd"/>
							<gml:surfaceMember xlink:href="#poly-09c9c759-6420-43ce-a892-83a43fe5c54a"/>
							<gml:surfaceMember xlink:href="#poly-2f972ceb-0378-425b-aca1-05137126949f"/>
							<gml:surfaceMember xlink:href="#poly-643cf052-5cb0-4541-b260-a5a752194e4c"/>
							<gml:surfaceMember xlink:href="#poly-303e66fe-0265-47ab-a608-889214c0c00a"/>
							<gml:surfaceMember xlink:href="#poly-74709bf5-b297-49e0-a77f-03c376ea7bf1"/>
							<gml:surfaceMember xlink:href="#poly-df3e668d-7f1b-42a4-b6bb-02366c60b281"/>
							<gml:surfaceMember xlink:href="#poly-c2a5bf2b-b22d-43a9-81ba-7c46e2eaa743"/>
							<gml:surfaceMember xlink:href="#poly-71091ee4-61de-4387-bc78-836b11fef39b"/>
							<gml:surfaceMember xlink:href="#poly-1eb0796b-9ec3-4b54-99db-67ae7e8aeb2f"/>
							<gml:surfaceMember xlink:href="#poly-a54397cc-21be-4ad9-8e76-d85248e9af19"/>
							<gml:surfaceMember xlink:href="#poly-6ea7cb89-97fc-46a9-9272-6ec9b0d7fb04"/>
							<gml:surfaceMember xlink:href="#poly-11cfece4-eace-4be4-9b8f-fa102cc7905e"/>
							<gml:surfaceMember xlink:href="#poly-56ffcbff-43e0-41d6-af45-2240fca1616c"/>
							<gml:surfaceMember xlink:href="#poly-c7bc3e86-0da2-4f79-9b01-6ed42aafe658"/>
							<gml:surfaceMember xlink:href="#poly-2fbc1fb6-bc0b-47d5-8af6-d5fd98cf401f"/>
							<gml:surfaceMember xlink:href="#poly-f4616b42-ecae-40c8-9874-99e310ea9a4e"/>
							<gml:surfaceMember xlink:href="#poly-e79c63d6-7905-4f31-b961-a3735dda77b9"/>
							<gml:surfaceMember xlink:href="#poly-bf121397-7dfc-4384-9e4f-465df2203c21"/>
							<gml:surfaceMember xlink:href="#poly-450863f4-11ec-4aca-8154-79f6586db8e0"/>
							<gml:surfaceMember xlink:href="#poly-74fc8cb0-a272-485d-9274-c30d74082e14"/>
							<gml:surfaceMember xlink:href="#poly-7cce5741-825e-4ee5-af1b-66a478adb5b2"/>
							<gml:surfaceMember xlink:href="#poly-78154a64-bf2c-48d0-8766-034f6dcceaa3"/>
							<gml:surfaceMember xlink:href="#poly-b716866e-df8d-4bc3-bd35-dc1eb6512076"/>
							<gml:surfaceMember xlink:href="#poly-aab02864-bb8f-4b5e-a221-5bcf0f317373"/>
							<gml:surfaceMember xlink:href="#poly-ef45f9fb-55a2-408a-8149-b9b450cba0fd"/>
							<gml:surfaceMember xlink:href="#poly-3a9fe700-0ae8-4268-9795-ca50465735c2"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d99fdbec-db07-4a29-8e4c-d8d4954f488a_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65561c1e-a0a2-4dce-a0cd-94b06d000661">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671778311548906 139.7402624082611 25.145 35.67178677295025 139.74027084897523 25.145 35.671795117087264 139.74027917936266 25.145 35.67178849969385 139.7402891398978 25.145 35.6717716941654 139.74027237984197 25.145 35.671778311548906 139.7402624082611 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4cb0df7-86be-49ed-8225-181e94e2c685">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4cb0df7-86be-49ed-8225-181e94e2c685_0">
											<gml:posList>35.671778311548906 139.7402624082611 25.772 35.67178677295025 139.74027084897523 25.772 35.67178677295025 139.74027084897523 25.145 35.671778311548906 139.7402624082611 25.145 35.671778311548906 139.7402624082611 25.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ef17c9f-c6fa-48fd-94ce-ad795ebfb7a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ef17c9f-c6fa-48fd-94ce-ad795ebfb7a7_0">
											<gml:posList>35.6717716941654 139.74027237984197 25.145 35.6717716941654 139.74027237984197 25.772 35.671778311548906 139.7402624082611 25.772 35.671778311548906 139.7402624082611 25.145 35.6717716941654 139.74027237984197 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-030c2d67-fee5-4479-bdfc-18b0e1a1d5d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-030c2d67-fee5-4479-bdfc-18b0e1a1d5d7_0">
											<gml:posList>35.671795117087264 139.74027917936266 25.145 35.67178677295025 139.74027084897523 25.145 35.67178677295025 139.74027084897523 25.772 35.671795117087264 139.74027917936266 25.772 35.671795117087264 139.74027917936266 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63395e71-a866-402d-9e72-9d2aab3629df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63395e71-a866-402d-9e72-9d2aab3629df_0">
											<gml:posList>35.67178849969385 139.7402891398978 25.772 35.671795117087264 139.74027917936266 25.772 35.67178677295025 139.74027084897523 25.772 35.671778311548906 139.7402624082611 25.772 35.6717716941654 139.74027237984197 25.772 35.67178849969385 139.7402891398978 25.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26989cf9-5f2d-41b2-b82c-0a8998dd5391">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26989cf9-5f2d-41b2-b82c-0a8998dd5391_0">
											<gml:posList>35.67178849969385 139.7402891398978 25.145 35.67178849969385 139.7402891398978 25.772 35.6717716941654 139.74027237984197 25.772 35.6717716941654 139.74027237984197 25.145 35.67178849969385 139.7402891398978 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfa4658a-d332-4e36-b6d8-2f8af86179c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfa4658a-d332-4e36-b6d8-2f8af86179c7_0">
											<gml:posList>35.671795117087264 139.74027917936266 25.772 35.67178849969385 139.7402891398978 25.772 35.67178849969385 139.7402891398978 25.145 35.671795117087264 139.74027917936266 25.145 35.671795117087264 139.74027917936266 25.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d99fdbec-db07-4a29-8e4c-d8d4954f488a_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f1b8940-443d-473d-84d7-493076521ea4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67169219093103 139.74018799999672 25.567 35.671691974439376 139.7401877903659 25.567 35.67168202624018 139.74020326693798 25.567 35.67165722224313 139.74024054433042 25.567 35.67165632019638 139.74023967270944 25.567 35.67169196262282 139.74018416714725 25.567 35.671693658467014 139.7401858000501 25.567 35.67169219093103 139.74018799999672 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e6ed42a-6a84-4a7f-92bd-ba91a4341d73">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671693658467014 139.7401858000501 25.145 35.67171943894763 139.74021067982883 25.145 35.67173359148821 139.74018864782383 25.145 35.6717633319386 139.74021733404163 25.145 35.67176188248076 139.7402196002473 25.145 35.67173348607501 139.74019220490186 25.145 35.671719360549304 139.74021420373552 25.145 35.67169219093103 139.74018799999672 25.145 35.671693658467014 139.7401858000501 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5acc8ba5-f9f1-4cc4-96c9-74288e812580">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67165849269095 139.74023991320843 25.145 35.67177500986824 139.74035230811708 25.145 35.67182250017259 139.74027837432806 25.145 35.671816582758275 139.74027267017783 25.145 35.67181764509669 139.7402710119761 25.145 35.67182460888804 139.74027773118598 25.145 35.6717753270118 139.74035446180733 25.145 35.67165722224313 139.74024054433042 25.145 35.67168202624018 139.74020326693798 25.145 35.67165849269095 139.74023991320843 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76a6dd2c-bf37-4d2a-9b68-69329d3f7394">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76a6dd2c-bf37-4d2a-9b68-69329d3f7394_0">
											<gml:posList>35.67169219093103 139.74018799999672 25.567 35.671693658467014 139.7401858000501 25.567 35.671693658467014 139.7401858000501 25.145 35.67169219093103 139.74018799999672 25.145 35.67169219093103 139.74018799999672 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed80f3c0-07a2-4b61-a850-43120adbdd02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed80f3c0-07a2-4b61-a850-43120adbdd02_0">
											<gml:posList>35.671693658467014 139.7401858000501 25.567 35.67169196262282 139.74018416714725 25.567 35.67169196262282 139.74018416714725 27.217 35.67171943894763 139.74021067982883 27.217 35.67171943894763 139.74021067982883 25.145 35.671693658467014 139.7401858000501 25.145 35.671693658467014 139.7401858000501 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26c60bc7-8657-49a7-a2fb-ff158efe406a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26c60bc7-8657-49a7-a2fb-ff158efe406a_0">
											<gml:posList>35.67171943894763 139.74021067982883 25.145 35.67171943894763 139.74021067982883 27.217 35.67173359148821 139.74018864782383 27.217 35.67173359148821 139.74018864782383 25.145 35.67171943894763 139.74021067982883 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c933f22-0ba1-4aaa-9e56-9dd3b3c40a36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c933f22-0ba1-4aaa-9e56-9dd3b3c40a36_0">
											<gml:posList>35.67169219093103 139.74018799999672 25.567 35.67169219093103 139.74018799999672 25.145 35.671719360549304 139.74021420373552 25.145 35.671719360549304 139.74021420373552 27.217 35.671691974439376 139.7401877903659 27.217 35.671691974439376 139.7401877903659 25.567 35.67169219093103 139.74018799999672 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61bf896c-160d-43c6-b2d5-c84b59985245">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61bf896c-160d-43c6-b2d5-c84b59985245_0">
											<gml:posList>35.67173359148821 139.74018864782383 27.217 35.6717633319386 139.74021733404163 27.217 35.6717633319386 139.74021733404163 25.145 35.67173359148821 139.74018864782383 25.145 35.67173359148821 139.74018864782383 27.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06c9043f-70ee-4b47-ae74-1dcbe3415c14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06c9043f-70ee-4b47-ae74-1dcbe3415c14_0">
											<gml:posList>35.67173348607501 139.74019220490186 25.145 35.67173348607501 139.74019220490186 27.217 35.671719360549304 139.74021420373552 27.217 35.671719360549304 139.74021420373552 25.145 35.67173348607501 139.74019220490186 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-456ccd48-ea8b-4761-931f-c926e48f5fbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-456ccd48-ea8b-4761-931f-c926e48f5fbe_0">
											<gml:posList>35.67176188248076 139.7402196002473 25.145 35.67176188248076 139.7402196002473 27.217 35.67173348607501 139.74019220490186 27.217 35.67173348607501 139.74019220490186 25.145 35.67176188248076 139.7402196002473 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f56fff1c-87c4-4d60-96b8-39e6247c644f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f56fff1c-87c4-4d60-96b8-39e6247c644f_0">
											<gml:posList>35.67165632019638 139.74023967270944 25.567 35.67165632019638 139.74023967270944 27.217 35.67169196262282 139.74018416714725 27.217 35.67169196262282 139.74018416714725 25.567 35.67165632019638 139.74023967270944 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5580416-4ad8-4a87-b5d2-849e60c24a7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5580416-4ad8-4a87-b5d2-849e60c24a7b_0">
											<gml:posList>35.67168202624018 139.74020326693798 25.567 35.671691974439376 139.7401877903659 25.567 35.671691974439376 139.7401877903659 27.217 35.67165849269095 139.74023991320843 27.217 35.67165849269095 139.74023991320843 25.145 35.67168202624018 139.74020326693798 25.145 35.67168202624018 139.74020326693798 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe248385-fc45-4398-89fe-48dc5ae089dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe248385-fc45-4398-89fe-48dc5ae089dc_0">
											<gml:posList>35.6717633319386 139.74021733404163 27.217 35.67176188248076 139.7402196002473 27.217 35.67176188248076 139.7402196002473 25.145 35.6717633319386 139.74021733404163 25.145 35.6717633319386 139.74021733404163 27.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f34ba95-6b81-4d98-a6c7-95a5bd140172">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f34ba95-6b81-4d98-a6c7-95a5bd140172_0">
											<gml:posList>35.67165722224313 139.74024054433042 25.145 35.67165722224313 139.74024054433042 25.567 35.67168202624018 139.74020326693798 25.567 35.67168202624018 139.74020326693798 25.145 35.67165722224313 139.74024054433042 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d6b28ab-c0a9-4195-839b-7dd6c81d778c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d6b28ab-c0a9-4195-839b-7dd6c81d778c_0">
											<gml:posList>35.6717633319386 139.74021733404163 27.217 35.67173359148821 139.74018864782383 27.217 35.67171943894763 139.74021067982883 27.217 35.67169196262282 139.74018416714725 27.217 35.67165632019638 139.74023967270944 27.217 35.6717753270118 139.74035446180733 27.217 35.67182460888804 139.74027773118598 27.217 35.67181764509669 139.7402710119761 27.217 35.671816582758275 139.74027267017783 27.217 35.67182250017259 139.74027837432806 27.217 35.67177500986824 139.74035230811708 27.217 35.67165849269095 139.74023991320843 27.217 35.671691974439376 139.7401877903659 27.217 35.671719360549304 139.74021420373552 27.217 35.67173348607501 139.74019220490186 27.217 35.67176188248076 139.7402196002473 27.217 35.6717633319386 139.74021733404163 27.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c358ddf-f09f-4393-ad68-48ce0d545804">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c358ddf-f09f-4393-ad68-48ce0d545804_0">
											<gml:posList>35.671816582758275 139.74027267017783 27.217 35.67181764509669 139.7402710119761 27.217 35.67181764509669 139.7402710119761 25.145 35.671816582758275 139.74027267017783 25.145 35.671816582758275 139.74027267017783 27.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1ce71ae-5d08-438f-89c6-29167b2868df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1ce71ae-5d08-438f-89c6-29167b2868df_0">
											<gml:posList>35.67181764509669 139.7402710119761 25.145 35.67181764509669 139.7402710119761 27.217 35.67182460888804 139.74027773118598 27.217 35.67182460888804 139.74027773118598 25.145 35.67181764509669 139.7402710119761 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b327837-6dfc-48f5-9b28-8d6eac28b8aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b327837-6dfc-48f5-9b28-8d6eac28b8aa_0">
											<gml:posList>35.67182250017259 139.74027837432806 25.145 35.67182250017259 139.74027837432806 27.217 35.671816582758275 139.74027267017783 27.217 35.671816582758275 139.74027267017783 25.145 35.67182250017259 139.74027837432806 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5732f64b-869a-4d1e-898a-25cd87d8cde6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5732f64b-869a-4d1e-898a-25cd87d8cde6_0">
											<gml:posList>35.67165849269095 139.74023991320843 25.145 35.67165849269095 139.74023991320843 27.217 35.67177500986824 139.74035230811708 27.217 35.67177500986824 139.74035230811708 25.145 35.67165849269095 139.74023991320843 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d50c0f1-8b2b-44a1-9ccd-397812d754b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d50c0f1-8b2b-44a1-9ccd-397812d754b2_0">
											<gml:posList>35.67165722224313 139.74024054433042 25.567 35.67165722224313 139.74024054433042 25.145 35.6717753270118 139.74035446180733 25.145 35.6717753270118 139.74035446180733 27.217 35.67165632019638 139.74023967270944 27.217 35.67165632019638 139.74023967270944 25.567 35.67165722224313 139.74024054433042 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72a11f52-8d3b-4dd3-863b-3c587ab890ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72a11f52-8d3b-4dd3-863b-3c587ab890ef_0">
											<gml:posList>35.67177500986824 139.74035230811708 25.145 35.67177500986824 139.74035230811708 27.217 35.67182250017259 139.74027837432806 27.217 35.67182250017259 139.74027837432806 25.145 35.67177500986824 139.74035230811708 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-942ed19d-346e-4788-b55d-e4dac7bdd1b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-942ed19d-346e-4788-b55d-e4dac7bdd1b1_0">
											<gml:posList>35.67182460888804 139.74027773118598 25.145 35.67182460888804 139.74027773118598 27.217 35.6717753270118 139.74035446180733 27.217 35.6717753270118 139.74035446180733 25.145 35.67182460888804 139.74027773118598 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d99fdbec-db07-4a29-8e4c-d8d4954f488a_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01b5c0dc-d7f2-41e3-b499-c74941489bfc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178377499178 139.74024054098865 29.529 35.671798298302875 139.74025503916658 29.529 35.67179174393067 139.74026490021288 29.529 35.67177722062928 139.74025041308076 29.529 35.67178377499178 139.74024054098865 29.529</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2911dbc7-b23a-47c3-8f16-34a0e30cdb16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2911dbc7-b23a-47c3-8f16-34a0e30cdb16_0">
											<gml:posList>35.67177722062928 139.74025041308076 32.566 35.67178377499178 139.74024054098865 32.566 35.67178377499178 139.74024054098865 29.529 35.67177722062928 139.74025041308076 29.529 35.67177722062928 139.74025041308076 32.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f64a9a32-bb5a-40bb-9bea-fc8c4d54e39e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f64a9a32-bb5a-40bb-9bea-fc8c4d54e39e_0">
											<gml:posList>35.67178377499178 139.74024054098865 29.529 35.67178377499178 139.74024054098865 32.566 35.671798298302875 139.74025503916658 32.566 35.671798298302875 139.74025503916658 29.529 35.67178377499178 139.74024054098865 29.529</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af616f35-2aef-4b47-afbc-14bfb632a1dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af616f35-2aef-4b47-afbc-14bfb632a1dd_0">
											<gml:posList>35.67178377499178 139.74024054098865 32.566 35.67177722062928 139.74025041308076 32.566 35.67179174393067 139.74026490021288 32.566 35.671798298302875 139.74025503916658 32.566 35.67178377499178 139.74024054098865 32.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-082b63f0-20a3-49d5-a009-8af00d7e66d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-082b63f0-20a3-49d5-a009-8af00d7e66d2_0">
											<gml:posList>35.67179174393067 139.74026490021288 29.529 35.67179174393067 139.74026490021288 32.566 35.67177722062928 139.74025041308076 32.566 35.67177722062928 139.74025041308076 29.529 35.67179174393067 139.74026490021288 29.529</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec153881-9d4e-4501-b2f6-d35091cdd055">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec153881-9d4e-4501-b2f6-d35091cdd055_0">
											<gml:posList>35.671798298302875 139.74025503916658 32.566 35.67179174393067 139.74026490021288 32.566 35.67179174393067 139.74026490021288 29.529 35.671798298302875 139.74025503916658 29.529 35.671798298302875 139.74025503916658 32.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d99fdbec-db07-4a29-8e4c-d8d4954f488a_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e9ca8a0-c1e8-42b8-96ff-ba4cf10afa83">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67169989995754 139.7402725625946 25.145 35.67166190638875 139.7402366726389 25.145 35.67167518530385 139.74021554747685 25.145 35.671713187892564 139.74025143741804 25.145 35.67169989995754 139.7402725625946 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef750b42-9539-4c7a-8426-71ae9fe74f8f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67173490703871 139.74028132597795 25.145 35.67172495019792 139.74029729964678 25.145 35.67171215948091 139.74028532909895 25.145 35.67172211632016 139.7402693554312 25.145 35.67173490703871 139.74028132597795 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be9cb01a-bf5f-40d3-a739-e3ed9f344a9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be9cb01a-bf5f-40d3-a739-e3ed9f344a9c_0">
											<gml:posList>35.67167518530385 139.74021554747685 25.145 35.67166190638875 139.7402366726389 25.145 35.67166190638875 139.7402366726389 26.946 35.67167518530385 139.74021554747685 26.946 35.67167518530385 139.74021554747685 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f5f5f74-9c34-48c4-b2b4-736ed57d6b11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f5f5f74-9c34-48c4-b2b4-736ed57d6b11_0">
											<gml:posList>35.671713187892564 139.74025143741804 25.145 35.67167518530385 139.74021554747685 25.145 35.67167518530385 139.74021554747685 26.946 35.671713187892564 139.74025143741804 26.946 35.671713187892564 139.74025143741804 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a283ac3-2261-4cdf-80ec-3f04abe6ef7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a283ac3-2261-4cdf-80ec-3f04abe6ef7a_0">
											<gml:posList>35.67167518530385 139.74021554747685 26.946 35.67166190638875 139.7402366726389 26.946 35.67169989995754 139.7402725625946 26.946 35.671713187892564 139.74025143741804 26.946 35.67167518530385 139.74021554747685 26.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75031359-57aa-4019-94f5-553e65bedbc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75031359-57aa-4019-94f5-553e65bedbc7_0">
											<gml:posList>35.67169989995754 139.7402725625946 26.946 35.67166190638875 139.7402366726389 26.946 35.67166190638875 139.7402366726389 25.145 35.67169989995754 139.7402725625946 25.145 35.67169989995754 139.7402725625946 26.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2124a8a7-9b81-42f8-b4eb-f27ba4963789">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2124a8a7-9b81-42f8-b4eb-f27ba4963789_0">
											<gml:posList>35.67169989995754 139.7402725625946 25.145 35.671713187892564 139.74025143741804 25.145 35.671713187892564 139.74025143741804 26.946 35.67169989995754 139.7402725625946 26.946 35.67169989995754 139.7402725625946 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5937d0b9-b05b-4dab-9912-df5d838e6076">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5937d0b9-b05b-4dab-9912-df5d838e6076_0">
											<gml:posList>35.67173490703871 139.74028132597795 25.145 35.67172211632016 139.7402693554312 25.145 35.67172211632016 139.7402693554312 26.991 35.67173490703871 139.74028132597795 26.991 35.67173490703871 139.74028132597795 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70370f0e-8b1e-4d2d-9c92-7fec7c225a88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70370f0e-8b1e-4d2d-9c92-7fec7c225a88_0">
											<gml:posList>35.67172211632016 139.7402693554312 25.145 35.67171215948091 139.74028532909895 25.145 35.67171215948091 139.74028532909895 26.991 35.67172211632016 139.7402693554312 26.991 35.67172211632016 139.7402693554312 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57f22df0-30a5-4fb3-b52f-1ebb57f8bbfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57f22df0-30a5-4fb3-b52f-1ebb57f8bbfe_0">
											<gml:posList>35.67171215948091 139.74028532909895 26.991 35.67172495019792 139.74029729964678 26.991 35.67173490703871 139.74028132597795 26.991 35.67172211632016 139.7402693554312 26.991 35.67171215948091 139.74028532909895 26.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77301489-8375-41d6-a2f7-1cc45b0c2eff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77301489-8375-41d6-a2f7-1cc45b0c2eff_0">
											<gml:posList>35.67172495019792 139.74029729964678 25.145 35.67173490703871 139.74028132597795 25.145 35.67173490703871 139.74028132597795 26.991 35.67172495019792 139.74029729964678 26.991 35.67172495019792 139.74029729964678 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f2518fd-396f-4419-a596-c29d77ae795c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f2518fd-396f-4419-a596-c29d77ae795c_0">
											<gml:posList>35.67171215948091 139.74028532909895 25.145 35.67172495019792 139.74029729964678 25.145 35.67172495019792 139.74029729964678 26.991 35.67171215948091 139.74028532909895 26.991 35.67171215948091 139.74028532909895 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-baf48733-83c7-48bf-8d63-af9a7c367dbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-baf48733-83c7-48bf-8d63-af9a7c367dbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-baf48733-83c7-48bf-8d63-af9a7c367dbb">
											<gml:posList>35.67181350976233 139.74030855263683 8.126 35.67184652549156 139.74034154324852 8.126 35.671807451229974 139.74040024525195 8.126 35.67165022074276 139.74024334720806 8.126 35.67169604735727 139.74017447467293 8.126 35.671720403287864 139.7401988590136 8.126 35.67173381809419 139.7401786284341 8.126 35.67183367710914 139.74027826193716 8.126 35.67181350976233 139.74030855263683 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b6b05e4-bbe0-4f6a-ba06-d55a5ca480e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b6b05e4-bbe0-4f6a-ba06-d55a5ca480e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b6b05e4-bbe0-4f6a-ba06-d55a5ca480e7">
											<gml:posList>35.67165022074276 139.74024334720806 25.567 35.67165581773386 139.74024265583037 25.567 35.67169662053728 139.74018134489307 25.567 35.67169604735727 139.74017447467293 25.567 35.67165022074276 139.74024334720806 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef0edf31-dd11-45ef-81c2-23cdb55523dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef0edf31-dd11-45ef-81c2-23cdb55523dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef0edf31-dd11-45ef-81c2-23cdb55523dd">
											<gml:posList>35.671720403287864 139.7401988590136 25.567 35.67169604735727 139.74017447467293 25.567 35.67169662053728 139.74018134489307 25.567 35.67172097646648 139.740205729236 25.567 35.671720403287864 139.7401988590136 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09c9c759-6420-43ce-a892-83a43fe5c54a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09c9c759-6420-43ce-a892-83a43fe5c54a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09c9c759-6420-43ce-a892-83a43fe5c54a">
											<gml:posList>35.671720403287864 139.7401988590136 25.567 35.67172097646648 139.740205729236 25.567 35.67173439127397 139.74018549865752 25.567 35.67173381809419 139.7401786284341 25.567 35.671720403287864 139.7401988590136 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2f972ceb-0378-425b-aca1-05137126949f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f972ceb-0378-425b-aca1-05137126949f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f972ceb-0378-425b-aca1-05137126949f">
											<gml:posList>35.67173439127397 139.74018549865752 25.567 35.67176772273101 139.7402187649806 25.567 35.67177024364272 139.74021497312012 25.567 35.67173381809419 139.7401786284341 25.567 35.67173439127397 139.74018549865752 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-643cf052-5cb0-4541-b260-a5a752194e4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-643cf052-5cb0-4541-b260-a5a752194e4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-643cf052-5cb0-4541-b260-a5a752194e4c">
											<gml:posList>35.67175451497738 139.74023866392804 29.529 35.671803497304175 139.74028754284936 29.529 35.67181923499271 139.74026385202603 29.529 35.67177024364272 139.74021497312012 29.529 35.67175451497738 139.74023866392804 29.529</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-303e66fe-0265-47ab-a608-889214c0c00a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-303e66fe-0265-47ab-a608-889214c0c00a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-303e66fe-0265-47ab-a608-889214c0c00a">
											<gml:posList>35.671773880434316 139.7403604617081 25.145 35.67182807111283 139.74027896437082 25.145 35.671816723084675 139.74026763283038 25.145 35.671803497304175 139.74028754284936 25.145 35.67175451497738 139.74023866392804 25.145 35.67176772273101 139.7402187649806 25.145 35.67173439127397 139.74018549865752 25.145 35.67172097646648 139.740205729236 25.145 35.67169662053728 139.74018134489307 25.145 35.67165581773386 139.74024265583037 25.145 35.671773880434316 139.7403604617081 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74709bf5-b297-49e0-a77f-03c376ea7bf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74709bf5-b297-49e0-a77f-03c376ea7bf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74709bf5-b297-49e0-a77f-03c376ea7bf1">
											<gml:posList>35.67182807111283 139.74027896437082 25.567 35.67183367710914 139.74027826193716 25.567 35.67181923499271 139.74026385202603 25.567 35.671816723084675 139.74026763283038 25.567 35.67182807111283 139.74027896437082 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df3e668d-7f1b-42a4-b6bb-02366c60b281">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df3e668d-7f1b-42a4-b6bb-02366c60b281">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df3e668d-7f1b-42a4-b6bb-02366c60b281">
											<gml:posList>35.67177446260892 139.7403673208794 25.567 35.671773880434316 139.7403604617081 25.567 35.67165581773386 139.74024265583037 25.567 35.67165022074276 139.74024334720806 25.567 35.67177446260892 139.7403673208794 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2a5bf2b-b22d-43a9-81ba-7c46e2eaa743">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2a5bf2b-b22d-43a9-81ba-7c46e2eaa743">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2a5bf2b-b22d-43a9-81ba-7c46e2eaa743">
											<gml:posList>35.67183367710914 139.74027826193716 25.567 35.67182807111283 139.74027896437082 25.567 35.671773880434316 139.7403604617081 25.567 35.67177446260892 139.7403673208794 25.567 35.67183367710914 139.74027826193716 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71091ee4-61de-4387-bc78-836b11fef39b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71091ee4-61de-4387-bc78-836b11fef39b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71091ee4-61de-4387-bc78-836b11fef39b">
											<gml:posList>35.67177446260892 139.7403673208794 12.088 35.671807451229974 139.74040024525195 12.088 35.67184652549156 139.74034154324852 12.088 35.67181350976233 139.74030855263683 12.088 35.67177446260892 139.7403673208794 12.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1eb0796b-9ec3-4b54-99db-67ae7e8aeb2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1eb0796b-9ec3-4b54-99db-67ae7e8aeb2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1eb0796b-9ec3-4b54-99db-67ae7e8aeb2f">
											<gml:posList>35.671720403287864 139.7401988590136 8.126 35.67169604735727 139.74017447467293 8.126 35.67169604735727 139.74017447467293 25.567 35.671720403287864 139.7401988590136 25.567 35.671720403287864 139.7401988590136 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a54397cc-21be-4ad9-8e76-d85248e9af19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a54397cc-21be-4ad9-8e76-d85248e9af19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a54397cc-21be-4ad9-8e76-d85248e9af19">
											<gml:posList>35.67173381809419 139.7401786284341 8.126 35.671720403287864 139.7401988590136 8.126 35.671720403287864 139.7401988590136 25.567 35.67173381809419 139.7401786284341 25.567 35.67173381809419 139.7401786284341 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ea7cb89-97fc-46a9-9272-6ec9b0d7fb04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ea7cb89-97fc-46a9-9272-6ec9b0d7fb04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ea7cb89-97fc-46a9-9272-6ec9b0d7fb04">
											<gml:posList>35.67169662053728 139.74018134489307 25.567 35.67169662053728 139.74018134489307 25.145 35.67172097646648 139.740205729236 25.145 35.67172097646648 139.740205729236 25.567 35.67169662053728 139.74018134489307 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11cfece4-eace-4be4-9b8f-fa102cc7905e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11cfece4-eace-4be4-9b8f-fa102cc7905e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11cfece4-eace-4be4-9b8f-fa102cc7905e">
											<gml:posList>35.67172097646648 139.740205729236 25.567 35.67172097646648 139.740205729236 25.145 35.67173439127397 139.74018549865752 25.145 35.67173439127397 139.74018549865752 25.567 35.67172097646648 139.740205729236 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56ffcbff-43e0-41d6-af45-2240fca1616c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56ffcbff-43e0-41d6-af45-2240fca1616c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56ffcbff-43e0-41d6-af45-2240fca1616c">
											<gml:posList>35.67173439127397 139.74018549865752 25.567 35.67173439127397 139.74018549865752 25.145 35.67176772273101 139.7402187649806 25.145 35.67176772273101 139.7402187649806 25.567 35.67173439127397 139.74018549865752 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7bc3e86-0da2-4f79-9b01-6ed42aafe658">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7bc3e86-0da2-4f79-9b01-6ed42aafe658">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7bc3e86-0da2-4f79-9b01-6ed42aafe658">
											<gml:posList>35.67169604735727 139.74017447467293 8.126 35.67165022074276 139.74024334720806 8.126 35.67165022074276 139.74024334720806 25.567 35.67169604735727 139.74017447467293 25.567 35.67169604735727 139.74017447467293 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2fbc1fb6-bc0b-47d5-8af6-d5fd98cf401f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fbc1fb6-bc0b-47d5-8af6-d5fd98cf401f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fbc1fb6-bc0b-47d5-8af6-d5fd98cf401f">
											<gml:posList>35.67165581773386 139.74024265583037 25.567 35.67165581773386 139.74024265583037 25.145 35.67169662053728 139.74018134489307 25.145 35.67169662053728 139.74018134489307 25.567 35.67165581773386 139.74024265583037 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4616b42-ecae-40c8-9874-99e310ea9a4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4616b42-ecae-40c8-9874-99e310ea9a4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4616b42-ecae-40c8-9874-99e310ea9a4e">
											<gml:posList>35.67175451497738 139.74023866392804 25.145 35.67175451497738 139.74023866392804 29.529 35.67177024364272 139.74021497312012 29.529 35.67177024364272 139.74021497312012 25.567 35.67176772273101 139.7402187649806 25.567 35.67176772273101 139.7402187649806 25.145 35.67175451497738 139.74023866392804 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e79c63d6-7905-4f31-b961-a3735dda77b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e79c63d6-7905-4f31-b961-a3735dda77b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e79c63d6-7905-4f31-b961-a3735dda77b9">
											<gml:posList>35.67177024364272 139.74021497312012 25.567 35.67177024364272 139.74021497312012 29.529 35.67181923499271 139.74026385202603 29.529 35.67181923499271 139.74026385202603 25.567 35.67183367710914 139.74027826193716 25.567 35.67183367710914 139.74027826193716 8.126 35.67173381809419 139.7401786284341 8.126 35.67173381809419 139.7401786284341 25.567 35.67177024364272 139.74021497312012 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf121397-7dfc-4384-9e4f-465df2203c21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf121397-7dfc-4384-9e4f-465df2203c21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf121397-7dfc-4384-9e4f-465df2203c21">
											<gml:posList>35.67175451497738 139.74023866392804 25.145 35.671803497304175 139.74028754284936 25.145 35.671803497304175 139.74028754284936 29.529 35.67175451497738 139.74023866392804 29.529 35.67175451497738 139.74023866392804 25.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-450863f4-11ec-4aca-8154-79f6586db8e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-450863f4-11ec-4aca-8154-79f6586db8e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-450863f4-11ec-4aca-8154-79f6586db8e0">
											<gml:posList>35.671816723084675 139.74026763283038 25.567 35.671816723084675 139.74026763283038 25.145 35.67182807111283 139.74027896437082 25.145 35.67182807111283 139.74027896437082 25.567 35.671816723084675 139.74026763283038 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74fc8cb0-a272-485d-9274-c30d74082e14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74fc8cb0-a272-485d-9274-c30d74082e14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74fc8cb0-a272-485d-9274-c30d74082e14">
											<gml:posList>35.67181923499271 139.74026385202603 29.529 35.671803497304175 139.74028754284936 29.529 35.671803497304175 139.74028754284936 25.145 35.671816723084675 139.74026763283038 25.145 35.671816723084675 139.74026763283038 25.567 35.67181923499271 139.74026385202603 25.567 35.67181923499271 139.74026385202603 29.529</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cce5741-825e-4ee5-af1b-66a478adb5b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cce5741-825e-4ee5-af1b-66a478adb5b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cce5741-825e-4ee5-af1b-66a478adb5b2">
											<gml:posList>35.671773880434316 139.7403604617081 25.567 35.671773880434316 139.7403604617081 25.145 35.67165581773386 139.74024265583037 25.145 35.67165581773386 139.74024265583037 25.567 35.671773880434316 139.7403604617081 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78154a64-bf2c-48d0-8766-034f6dcceaa3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78154a64-bf2c-48d0-8766-034f6dcceaa3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78154a64-bf2c-48d0-8766-034f6dcceaa3">
											<gml:posList>35.67182807111283 139.74027896437082 25.567 35.67182807111283 139.74027896437082 25.145 35.671773880434316 139.7403604617081 25.145 35.671773880434316 139.7403604617081 25.567 35.67182807111283 139.74027896437082 25.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b716866e-df8d-4bc3-bd35-dc1eb6512076">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b716866e-df8d-4bc3-bd35-dc1eb6512076">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b716866e-df8d-4bc3-bd35-dc1eb6512076">
											<gml:posList>35.67177446260892 139.7403673208794 12.088 35.67177446260892 139.7403673208794 25.567 35.67165022074276 139.74024334720806 25.567 35.67165022074276 139.74024334720806 8.126 35.671807451229974 139.74040024525195 8.126 35.671807451229974 139.74040024525195 12.088 35.67177446260892 139.7403673208794 12.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aab02864-bb8f-4b5e-a221-5bcf0f317373">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aab02864-bb8f-4b5e-a221-5bcf0f317373">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aab02864-bb8f-4b5e-a221-5bcf0f317373">
											<gml:posList>35.67183367710914 139.74027826193716 8.126 35.67183367710914 139.74027826193716 25.567 35.67177446260892 139.7403673208794 25.567 35.67177446260892 139.7403673208794 12.088 35.67181350976233 139.74030855263683 12.088 35.67181350976233 139.74030855263683 8.126 35.67183367710914 139.74027826193716 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef45f9fb-55a2-408a-8149-b9b450cba0fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef45f9fb-55a2-408a-8149-b9b450cba0fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef45f9fb-55a2-408a-8149-b9b450cba0fd">
											<gml:posList>35.67184652549156 139.74034154324852 8.126 35.67181350976233 139.74030855263683 8.126 35.67181350976233 139.74030855263683 12.088 35.67184652549156 139.74034154324852 12.088 35.67184652549156 139.74034154324852 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a9fe700-0ae8-4268-9795-ca50465735c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a9fe700-0ae8-4268-9795-ca50465735c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a9fe700-0ae8-4268-9795-ca50465735c2">
											<gml:posList>35.671807451229974 139.74040024525195 8.126 35.67184652549156 139.74034154324852 8.126 35.67184652549156 139.74034154324852 12.088 35.671807451229974 139.74040024525195 12.088 35.671807451229974 139.74040024525195 8.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9168</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">208.99695</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>