<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d9b2dc4d-6b60-4c6b-b847-f53489e77d61">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67078420308945 139.7407505390657 0 35.67081464728983 139.74070994182597 0 35.67083903843733 139.740674786342 0 35.67084656192494 139.74068263158335 0 35.67085506146048 139.7406703824334 0 35.6707389706429 139.74054944905868 0 35.67063765158577 139.7406954989118 0 35.67075370617837 139.74081639924853 0 35.670763826398094 139.74080180643833 0 35.67075501292867 139.74079262607913 0 35.67078420308945 139.7407505390657 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078420308945 139.7407505390657 10.99 35.67075501292867 139.74079262607913 10.99 35.670763826398094 139.74080180643833 10.99 35.67075370617837 139.74081639924853 10.99 35.67063765158577 139.7406954989118 10.99 35.6707389706429 139.74054944905868 10.99 35.67085506146048 139.7406703824334 10.99 35.67084656192494 139.74068263158335 10.99 35.67083903843733 139.740674786342 10.99 35.67081464728983 139.74070994182597 10.99 35.67078420308945 139.7407505390657 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078420308945 139.7407505390657 10.99 35.67081464728983 139.74070994182597 10.99 35.67081464728983 139.74070994182597 27.03 35.67078420308945 139.7407505390657 27.03 35.67078420308945 139.7407505390657 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67081464728983 139.74070994182597 10.99 35.67083903843733 139.740674786342 10.99 35.67083903843733 139.740674786342 27.03 35.67081464728983 139.74070994182597 27.03 35.67081464728983 139.74070994182597 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67083903843733 139.740674786342 10.99 35.67084656192494 139.74068263158335 10.99 35.67084656192494 139.74068263158335 27.03 35.67083903843733 139.740674786342 27.03 35.67083903843733 139.740674786342 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67084656192494 139.74068263158335 10.99 35.67085506146048 139.7406703824334 10.99 35.67085506146048 139.7406703824334 27.03 35.67084656192494 139.74068263158335 27.03 35.67084656192494 139.74068263158335 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67085506146048 139.7406703824334 10.99 35.6707389706429 139.74054944905868 10.99 35.6707389706429 139.74054944905868 27.03 35.67085506146048 139.7406703824334 27.03 35.67085506146048 139.7406703824334 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6707389706429 139.74054944905868 10.99 35.67063765158577 139.7406954989118 10.99 35.67063765158577 139.7406954989118 27.03 35.6707389706429 139.74054944905868 27.03 35.6707389706429 139.74054944905868 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063765158577 139.7406954989118 10.99 35.67075370617837 139.74081639924853 10.99 35.67075370617837 139.74081639924853 27.03 35.67063765158577 139.7406954989118 27.03 35.67063765158577 139.7406954989118 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67075370617837 139.74081639924853 10.99 35.670763826398094 139.74080180643833 10.99 35.670763826398094 139.74080180643833 27.03 35.67075370617837 139.74081639924853 27.03 35.67075370617837 139.74081639924853 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670763826398094 139.74080180643833 10.99 35.67075501292867 139.74079262607913 10.99 35.67075501292867 139.74079262607913 27.03 35.670763826398094 139.74080180643833 27.03 35.670763826398094 139.74080180643833 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67075501292867 139.74079262607913 10.99 35.67078420308945 139.7407505390657 10.99 35.67078420308945 139.7407505390657 27.03 35.67075501292867 139.74079262607913 27.03 35.67075501292867 139.74079262607913 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078420308945 139.7407505390657 27.03 35.67081464728983 139.74070994182597 27.03 35.67083903843733 139.740674786342 27.03 35.67084656192494 139.74068263158335 27.03 35.67085506146048 139.7406703824334 27.03 35.6707389706429 139.74054944905868 27.03 35.67063765158577 139.7406954989118 27.03 35.67075370617837 139.74081639924853 27.03 35.670763826398094 139.74080180643833 27.03 35.67075501292867 139.74079262607913 27.03 35.67078420308945 139.7407505390657 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5785e308-f54e-478b-9ed0-329ba1a17812"/>
							<gml:surfaceMember xlink:href="#poly-bcb75a15-2f64-4ead-bf85-56dd06479d0b"/>
							<gml:surfaceMember xlink:href="#poly-5afa2a43-9dd4-4d76-a809-eed62e2aa99c"/>
							<gml:surfaceMember xlink:href="#poly-45282aa1-306c-4db7-b0b4-ab2f8d448806"/>
							<gml:surfaceMember xlink:href="#poly-e14404aa-77e5-43a3-9de3-2a703dfaad08"/>
							<gml:surfaceMember xlink:href="#poly-1dce37e5-a65c-4cee-af88-e9c0d7ab5da6"/>
							<gml:surfaceMember xlink:href="#poly-ec0a48fe-f485-4fd7-9633-213e61f7f5a9"/>
							<gml:surfaceMember xlink:href="#poly-5b4c68f9-33de-4580-a86e-fd29e987e467"/>
							<gml:surfaceMember xlink:href="#poly-d7119f4e-cd5e-40e5-8a5e-abc6c3a2dbbc"/>
							<gml:surfaceMember xlink:href="#poly-e11fc524-6553-4a79-9696-dc6b99bd0348"/>
							<gml:surfaceMember xlink:href="#poly-59217bae-fa0f-48bd-a577-c29c39a27c6c"/>
							<gml:surfaceMember xlink:href="#poly-c70f1970-2145-4acc-ab9b-382f5655ea78"/>
							<gml:surfaceMember xlink:href="#poly-e40da80b-b323-4289-bab9-93ac542e87d5"/>
							<gml:surfaceMember xlink:href="#poly-31c90cc9-5134-4bc5-98f4-debd4dd3c494"/>
							<gml:surfaceMember xlink:href="#poly-b9e1818d-5825-478f-bd7a-15662ed9c934"/>
							<gml:surfaceMember xlink:href="#poly-8fa52ffa-b1fc-4d3e-8f77-d55c051a781b"/>
							<gml:surfaceMember xlink:href="#poly-efb83191-9d2f-4a67-9910-3adacd9e7a4b"/>
							<gml:surfaceMember xlink:href="#poly-a3f8b558-7770-47c2-9752-427914172642"/>
							<gml:surfaceMember xlink:href="#poly-0ef7c505-51ee-4e2e-9336-fbf0c6f1e3fd"/>
							<gml:surfaceMember xlink:href="#poly-ef682291-9943-4370-9238-79b05b538e5f"/>
							<gml:surfaceMember xlink:href="#poly-8e8d2fbd-588e-4b55-8093-990c894e3713"/>
							<gml:surfaceMember xlink:href="#poly-0786bfbc-70ce-415f-9e27-0cac7c90f247"/>
							<gml:surfaceMember xlink:href="#poly-4af00d18-7746-41c7-b318-0cc6cf7be740"/>
							<gml:surfaceMember xlink:href="#poly-973d9f46-c1b7-4fa7-b227-68100ec0ed5a"/>
							<gml:surfaceMember xlink:href="#poly-a19ef7b3-fc72-4ff2-bbce-c3b800253063"/>
							<gml:surfaceMember xlink:href="#poly-de753e36-3bf7-4c40-acf4-edf893347cc9"/>
							<gml:surfaceMember xlink:href="#poly-419431e7-a937-4a54-ba58-850f0b1ec74a"/>
							<gml:surfaceMember xlink:href="#poly-7898d849-7d25-4763-9ee2-aabfe7400968"/>
							<gml:surfaceMember xlink:href="#poly-bfc7adef-87e2-4a91-8cb3-58990593bbf8"/>
							<gml:surfaceMember xlink:href="#poly-4f361101-6e80-47e7-a7de-7dd23b46ea76"/>
							<gml:surfaceMember xlink:href="#poly-99b457d8-6f4d-4d96-ad98-62217c57e5d7"/>
							<gml:surfaceMember xlink:href="#poly-eee31ec2-5400-46ec-a98e-2fbb4449e428"/>
							<gml:surfaceMember xlink:href="#poly-b5344123-a091-46b7-896a-581d38622808"/>
							<gml:surfaceMember xlink:href="#poly-4b69c713-aed0-478f-95cc-dd5d4c13b081"/>
							<gml:surfaceMember xlink:href="#poly-334dff29-61cc-44c7-a844-3091cf98a6a8"/>
							<gml:surfaceMember xlink:href="#poly-f559cb9a-a88a-408c-8f6f-a9fc49771c4f"/>
							<gml:surfaceMember xlink:href="#poly-cc071b11-4093-47ac-8788-876809927492"/>
							<gml:surfaceMember xlink:href="#poly-62791e75-d59e-48a9-aa38-1b7bb8aecf16"/>
							<gml:surfaceMember xlink:href="#poly-8d0465fb-3dcf-4305-8a83-d46023b7a487"/>
							<gml:surfaceMember xlink:href="#poly-a3e68932-0d5b-45ce-87d2-a8a28cc739b7"/>
							<gml:surfaceMember xlink:href="#poly-b22c2a54-766b-4300-ab3a-20150ab96d67"/>
							<gml:surfaceMember xlink:href="#poly-d2a5a9bd-54bd-41fe-9d1b-7cbcbd514abd"/>
							<gml:surfaceMember xlink:href="#poly-4e5ab843-de62-4629-961b-d290a1609d48"/>
							<gml:surfaceMember xlink:href="#poly-edfef4da-38b5-43ea-a413-df1024186e02"/>
							<gml:surfaceMember xlink:href="#poly-abf2766a-270e-45bd-80ab-ad2a4f04ade9"/>
							<gml:surfaceMember xlink:href="#poly-fd3d8e26-caa8-4d75-8d47-7d6e174d81dd"/>
							<gml:surfaceMember xlink:href="#poly-e817035e-fca4-4d02-b1c0-2abd00b4d121"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d9b2dc4d-6b60-4c6b-b847-f53489e77d61_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e42ac83-ea29-421d-83d0-e30366bc19f1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670814647298315 139.74070995287227 10.99 35.670827529216595 139.7407233592706 10.99 35.67080863034441 139.74075059922907 10.99 35.670802423917856 139.74074412220742 10.99 35.67079219565942 139.7407588698051 10.99 35.670784203097945 139.74075055011195 10.99 35.670814647298315 139.74070995287227 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e998d3d8-d95a-4608-9c0e-46c597b497f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e998d3d8-d95a-4608-9c0e-46c597b497f3_0">
											<gml:posList>35.670827529216595 139.7407233592706 27.557 35.670827529216595 139.7407233592706 10.99 35.670814647298315 139.74070995287227 10.99 35.670814647298315 139.74070995287227 27.557 35.670827529216595 139.7407233592706 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4eda7561-0dd9-441f-8788-eee233e119e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4eda7561-0dd9-441f-8788-eee233e119e6_0">
											<gml:posList>35.670814647298315 139.74070995287227 27.557 35.670814647298315 139.74070995287227 10.99 35.670784203097945 139.74075055011195 10.99 35.670784203097945 139.74075055011195 27.557 35.670814647298315 139.74070995287227 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5131aa34-ef4b-4983-8e54-5a3b52ee5e59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5131aa34-ef4b-4983-8e54-5a3b52ee5e59_0">
											<gml:posList>35.670814647298315 139.74070995287227 27.557 35.670784203097945 139.74075055011195 27.557 35.67079219565942 139.7407588698051 27.557 35.670802423917856 139.74074412220742 27.557 35.67080863034441 139.74075059922907 27.557 35.670827529216595 139.7407233592706 27.557 35.670814647298315 139.74070995287227 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84d185b5-3cf8-4b6e-900c-005c2a620b33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84d185b5-3cf8-4b6e-900c-005c2a620b33_0">
											<gml:posList>35.67080863034441 139.74075059922907 27.557 35.67080863034441 139.74075059922907 10.99 35.670827529216595 139.7407233592706 10.99 35.670827529216595 139.7407233592706 27.557 35.67080863034441 139.74075059922907 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-647b3273-45f4-478b-acc8-eba0465cce06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-647b3273-45f4-478b-acc8-eba0465cce06_0">
											<gml:posList>35.670802423917856 139.74074412220742 27.557 35.670802423917856 139.74074412220742 10.99 35.67080863034441 139.74075059922907 10.99 35.67080863034441 139.74075059922907 27.557 35.670802423917856 139.74074412220742 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-951d4e73-f042-4eb9-891b-5009f8f73cd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-951d4e73-f042-4eb9-891b-5009f8f73cd6_0">
											<gml:posList>35.67079219565942 139.7407588698051 27.557 35.67079219565942 139.7407588698051 10.99 35.670802423917856 139.74074412220742 10.99 35.670802423917856 139.74074412220742 27.557 35.67079219565942 139.7407588698051 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-261d4ad6-53e3-4c32-b206-1c0f1e58bee6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-261d4ad6-53e3-4c32-b206-1c0f1e58bee6_0">
											<gml:posList>35.670784203097945 139.74075055011195 27.557 35.670784203097945 139.74075055011195 10.99 35.67079219565942 139.7407588698051 10.99 35.67079219565942 139.7407588698051 27.557 35.670784203097945 139.74075055011195 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5785e308-f54e-478b-9ed0-329ba1a17812">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5785e308-f54e-478b-9ed0-329ba1a17812">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5785e308-f54e-478b-9ed0-329ba1a17812">
											<gml:posList>35.67073897064288 139.74054944905868 10.99 35.67085506146045 139.7406703824334 10.99 35.67084656192494 139.74068263158333 10.99 35.67083903843733 139.74067478634197 10.99 35.670814647289816 139.74070994182594 10.99 35.67078420308945 139.74075053906566 10.99 35.67075501292866 139.7407926260791 10.99 35.6707638263981 139.74080180643833 10.99 35.67075370617835 139.74081639924853 10.99 35.67063765158577 139.74069549891178 10.99 35.67073897064288 139.74054944905868 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bcb75a15-2f64-4ead-bf85-56dd06479d0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcb75a15-2f64-4ead-bf85-56dd06479d0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcb75a15-2f64-4ead-bf85-56dd06479d0b">
											<gml:posList>35.670770895855334 139.74058270570154 27.557 35.67077127894963 139.74058857085075 27.557 35.670850284553296 139.7406708629462 27.557 35.67085506146045 139.7406703824334 27.557 35.670770895855334 139.74058270570154 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5afa2a43-9dd4-4d76-a809-eed62e2aa99c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5afa2a43-9dd4-4d76-a809-eed62e2aa99c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5afa2a43-9dd4-4d76-a809-eed62e2aa99c">
											<gml:posList>35.67063765158577 139.74069549891178 21.735 35.670669576758456 139.74072875557098 27.557 35.670770895855334 139.74058270570154 27.557 35.67073897064288 139.74054944905868 21.735 35.67063765158577 139.74069549891178 21.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45282aa1-306c-4db7-b0b4-ab2f8d448806">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45282aa1-306c-4db7-b0b4-ab2f8d448806">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45282aa1-306c-4db7-b0b4-ab2f8d448806">
											<gml:posList>35.670669576758456 139.74072875557098 27.557 35.6706743626882 139.7407282860986 27.557 35.67077127894963 139.74058857085075 27.557 35.670770895855334 139.74058270570154 27.557 35.670669576758456 139.74072875557098 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e14404aa-77e5-43a3-9de3-2a703dfaad08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e14404aa-77e5-43a3-9de3-2a703dfaad08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e14404aa-77e5-43a3-9de3-2a703dfaad08">
											<gml:posList>35.67077127894963 139.74058857085075 27.153 35.6706743626882 139.7407282860986 27.153 35.67075516136703 139.74069261260675 27.153 35.670771494851834 139.74066997088426 27.153 35.67077127894963 139.74058857085075 27.153</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1dce37e5-a65c-4cee-af88-e9c0d7ab5da6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1dce37e5-a65c-4cee-af88-e9c0d7ab5da6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1dce37e5-a65c-4cee-af88-e9c0d7ab5da6">
											<gml:posList>35.67083903843733 139.74067478634197 27.557 35.67084656192494 139.74068263158333 27.557 35.670846169838505 139.74067678853123 27.557 35.670839557467495 139.74066989222118 27.557 35.67083903843733 139.74067478634197 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec0a48fe-f485-4fd7-9633-213e61f7f5a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec0a48fe-f485-4fd7-9633-213e61f7f5a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec0a48fe-f485-4fd7-9633-213e61f7f5a9">
											<gml:posList>35.67085506146045 139.7406703824334 27.557 35.670850284553296 139.7406708629462 27.557 35.670846169838505 139.74067678853123 27.557 35.67084656192494 139.74068263158333 27.557 35.67085506146045 139.7406703824334 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b4c68f9-33de-4580-a86e-fd29e987e467">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b4c68f9-33de-4580-a86e-fd29e987e467">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b4c68f9-33de-4580-a86e-fd29e987e467">
											<gml:posList>35.67075516136703 139.74069261260675 31.398 35.67075827092273 139.74069237704126 31.398 35.67077168708117 139.74067379268655 31.398 35.670771494851834 139.74066997088426 31.398 35.67075516136703 139.74069261260675 31.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d7119f4e-cd5e-40e5-8a5e-abc6c3a2dbbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7119f4e-cd5e-40e5-8a5e-abc6c3a2dbbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7119f4e-cd5e-40e5-8a5e-abc6c3a2dbbc">
											<gml:posList>35.670771494851834 139.74066997088426 31.398 35.67077168708117 139.74067379268655 31.398 35.67079485365526 139.74069889628325 31.398 35.670797972224655 139.74069866070744 31.398 35.670771494851834 139.74066997088426 31.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e11fc524-6553-4a79-9696-dc6b99bd0348">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e11fc524-6553-4a79-9696-dc6b99bd0348">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e11fc524-6553-4a79-9696-dc6b99bd0348">
											<gml:posList>35.67083903843733 139.74067478634197 27.557 35.670839557467495 139.74066989222118 27.557 35.6708121393168 139.74070713895827 27.557 35.670814647289816 139.74070994182594 27.557 35.67083903843733 139.74067478634197 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-59217bae-fa0f-48bd-a577-c29c39a27c6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59217bae-fa0f-48bd-a577-c29c39a27c6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59217bae-fa0f-48bd-a577-c29c39a27c6c">
											<gml:posList>35.67079485365526 139.74069889628325 31.064 35.67077168708117 139.74067379268655 31.064 35.67075827092273 139.74069237704126 31.064 35.67078142847927 139.74071748064958 31.064 35.67079485365526 139.74069889628325 31.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c70f1970-2145-4acc-ab9b-382f5655ea78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c70f1970-2145-4acc-ab9b-382f5655ea78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c70f1970-2145-4acc-ab9b-382f5655ea78">
											<gml:posList>35.670839557467495 139.74066989222118 27.153 35.670846169838505 139.74067678853123 27.153 35.670850284553296 139.7406708629462 27.153 35.67077127894963 139.74058857085075 27.153 35.670771494851834 139.74066997088426 27.153 35.670797972224655 139.74069866070744 27.153 35.670781629720814 139.740721302442 27.153 35.67075516136703 139.74069261260675 27.153 35.6706743626882 139.7407282860986 27.153 35.670753323103646 139.7408105451458 27.153 35.67075904948185 139.74080227589644 27.153 35.67075023601243 139.74079309553773 27.153 35.67078165910495 139.7407477914709 27.153 35.6708121393168 139.74070713895827 27.153 35.670839557467495 139.74066989222118 27.153</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e40da80b-b323-4289-bab9-93ac542e87d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e40da80b-b323-4289-bab9-93ac542e87d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e40da80b-b323-4289-bab9-93ac542e87d5">
											<gml:posList>35.670781629720814 139.740721302442 31.398 35.67078142847927 139.74071748064958 31.398 35.67075827092273 139.74069237704126 31.398 35.67075516136703 139.74069261260675 31.398 35.670781629720814 139.740721302442 31.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31c90cc9-5134-4bc5-98f4-debd4dd3c494">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31c90cc9-5134-4bc5-98f4-debd4dd3c494">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31c90cc9-5134-4bc5-98f4-debd4dd3c494">
											<gml:posList>35.670797972224655 139.74069866070744 31.398 35.67079485365526 139.74069889628325 31.398 35.67078142847927 139.74071748064958 31.398 35.670781629720814 139.740721302442 31.398 35.670797972224655 139.74069866070744 31.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9e1818d-5825-478f-bd7a-15662ed9c934">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9e1818d-5825-478f-bd7a-15662ed9c934">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9e1818d-5825-478f-bd7a-15662ed9c934">
											<gml:posList>35.670814647289816 139.74070994182594 27.557 35.6708121393168 139.74070713895827 27.557 35.67078165910495 139.7407477914709 27.557 35.67078420308945 139.74075053906566 27.557 35.670814647289816 139.74070994182594 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fa52ffa-b1fc-4d3e-8f77-d55c051a781b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fa52ffa-b1fc-4d3e-8f77-d55c051a781b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fa52ffa-b1fc-4d3e-8f77-d55c051a781b">
											<gml:posList>35.67075501292866 139.7407926260791 27.557 35.67078420308945 139.74075053906566 27.557 35.67078165910495 139.7407477914709 27.557 35.67075023601243 139.74079309553773 27.557 35.67075501292866 139.7407926260791 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-efb83191-9d2f-4a67-9910-3adacd9e7a4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efb83191-9d2f-4a67-9910-3adacd9e7a4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efb83191-9d2f-4a67-9910-3adacd9e7a4b">
											<gml:posList>35.67075370617835 139.74081639924853 27.557 35.670753323103646 139.7408105451458 27.557 35.6706743626882 139.7407282860986 27.557 35.670669576758456 139.74072875557098 27.557 35.67075370617835 139.74081639924853 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3f8b558-7770-47c2-9752-427914172642">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3f8b558-7770-47c2-9752-427914172642">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3f8b558-7770-47c2-9752-427914172642">
											<gml:posList>35.67075501292866 139.7407926260791 27.557 35.67075023601243 139.74079309553773 27.557 35.67075904948185 139.74080227589644 27.557 35.6707638263981 139.74080180643833 27.557 35.67075501292866 139.7407926260791 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ef7c505-51ee-4e2e-9336-fbf0c6f1e3fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ef7c505-51ee-4e2e-9336-fbf0c6f1e3fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ef7c505-51ee-4e2e-9336-fbf0c6f1e3fd">
											<gml:posList>35.6707638263981 139.74080180643833 27.557 35.67075904948185 139.74080227589644 27.557 35.670753323103646 139.7408105451458 27.557 35.67075370617835 139.74081639924853 27.557 35.6707638263981 139.74080180643833 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef682291-9943-4370-9238-79b05b538e5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef682291-9943-4370-9238-79b05b538e5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef682291-9943-4370-9238-79b05b538e5f">
											<gml:posList>35.670846169838505 139.74067678853123 27.557 35.670846169838505 139.74067678853123 27.153 35.670839557467495 139.74066989222118 27.153 35.670839557467495 139.74066989222118 27.557 35.670846169838505 139.74067678853123 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e8d2fbd-588e-4b55-8093-990c894e3713">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e8d2fbd-588e-4b55-8093-990c894e3713">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e8d2fbd-588e-4b55-8093-990c894e3713">
											<gml:posList>35.67077168708117 139.74067379268655 31.398 35.67077168708117 139.74067379268655 31.064 35.67079485365526 139.74069889628325 31.064 35.67079485365526 139.74069889628325 31.398 35.67077168708117 139.74067379268655 31.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0786bfbc-70ce-415f-9e27-0cac7c90f247">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0786bfbc-70ce-415f-9e27-0cac7c90f247">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0786bfbc-70ce-415f-9e27-0cac7c90f247">
											<gml:posList>35.67078142847927 139.74071748064958 31.398 35.67078142847927 139.74071748064958 31.064 35.67075827092273 139.74069237704126 31.064 35.67075827092273 139.74069237704126 31.398 35.67078142847927 139.74071748064958 31.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4af00d18-7746-41c7-b318-0cc6cf7be740">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4af00d18-7746-41c7-b318-0cc6cf7be740">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4af00d18-7746-41c7-b318-0cc6cf7be740">
											<gml:posList>35.67075023601243 139.74079309553773 27.557 35.67075023601243 139.74079309553773 27.153 35.67075904948185 139.74080227589644 27.153 35.67075904948185 139.74080227589644 27.557 35.67075023601243 139.74079309553773 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-973d9f46-c1b7-4fa7-b227-68100ec0ed5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-973d9f46-c1b7-4fa7-b227-68100ec0ed5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-973d9f46-c1b7-4fa7-b227-68100ec0ed5a">
											<gml:posList>35.67073897064288 139.74054944905868 10.99 35.67063765158577 139.74069549891178 10.99 35.67063765158577 139.74069549891178 21.735 35.67073897064288 139.74054944905868 21.735 35.67073897064288 139.74054944905868 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a19ef7b3-fc72-4ff2-bbce-c3b800253063">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a19ef7b3-fc72-4ff2-bbce-c3b800253063">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a19ef7b3-fc72-4ff2-bbce-c3b800253063">
											<gml:posList>35.6706743626882 139.7407282860986 27.557 35.6706743626882 139.7407282860986 27.153 35.67077127894963 139.74058857085075 27.153 35.67077127894963 139.74058857085075 27.557 35.6706743626882 139.7407282860986 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de753e36-3bf7-4c40-acf4-edf893347cc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de753e36-3bf7-4c40-acf4-edf893347cc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de753e36-3bf7-4c40-acf4-edf893347cc9">
											<gml:posList>35.67075516136703 139.74069261260675 31.398 35.670771494851834 139.74066997088426 31.398 35.670771494851834 139.74066997088426 27.153 35.67075516136703 139.74069261260675 27.153 35.67075516136703 139.74069261260675 31.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-419431e7-a937-4a54-ba58-850f0b1ec74a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-419431e7-a937-4a54-ba58-850f0b1ec74a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-419431e7-a937-4a54-ba58-850f0b1ec74a">
											<gml:posList>35.67075827092273 139.74069237704126 31.398 35.67075827092273 139.74069237704126 31.064 35.67077168708117 139.74067379268655 31.064 35.67077168708117 139.74067379268655 31.398 35.67075827092273 139.74069237704126 31.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7898d849-7d25-4763-9ee2-aabfe7400968">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7898d849-7d25-4763-9ee2-aabfe7400968">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7898d849-7d25-4763-9ee2-aabfe7400968">
											<gml:posList>35.67075516136703 139.74069261260675 27.153 35.670781629720814 139.740721302442 27.153 35.670781629720814 139.740721302442 31.398 35.67075516136703 139.74069261260675 31.398 35.67075516136703 139.74069261260675 27.153</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfc7adef-87e2-4a91-8cb3-58990593bbf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfc7adef-87e2-4a91-8cb3-58990593bbf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfc7adef-87e2-4a91-8cb3-58990593bbf8">
											<gml:posList>35.670771494851834 139.74066997088426 31.398 35.670797972224655 139.74069866070744 31.398 35.670797972224655 139.74069866070744 27.153 35.670771494851834 139.74066997088426 27.153 35.670771494851834 139.74066997088426 31.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f361101-6e80-47e7-a7de-7dd23b46ea76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f361101-6e80-47e7-a7de-7dd23b46ea76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f361101-6e80-47e7-a7de-7dd23b46ea76">
											<gml:posList>35.67079485365526 139.74069889628325 31.398 35.67079485365526 139.74069889628325 31.064 35.67078142847927 139.74071748064958 31.064 35.67078142847927 139.74071748064958 31.398 35.67079485365526 139.74069889628325 31.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99b457d8-6f4d-4d96-ad98-62217c57e5d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99b457d8-6f4d-4d96-ad98-62217c57e5d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99b457d8-6f4d-4d96-ad98-62217c57e5d7">
											<gml:posList>35.670781629720814 139.740721302442 27.153 35.670797972224655 139.74069866070744 27.153 35.670797972224655 139.74069866070744 31.398 35.670781629720814 139.740721302442 31.398 35.670781629720814 139.740721302442 27.153</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eee31ec2-5400-46ec-a98e-2fbb4449e428">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eee31ec2-5400-46ec-a98e-2fbb4449e428">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eee31ec2-5400-46ec-a98e-2fbb4449e428">
											<gml:posList>35.6708121393168 139.74070713895827 27.557 35.6708121393168 139.74070713895827 27.153 35.67078165910495 139.7407477914709 27.153 35.67078165910495 139.7407477914709 27.557 35.6708121393168 139.74070713895827 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5344123-a091-46b7-896a-581d38622808">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5344123-a091-46b7-896a-581d38622808">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5344123-a091-46b7-896a-581d38622808">
											<gml:posList>35.670770895855334 139.74058270570154 27.557 35.67085506146045 139.7406703824334 27.557 35.67085506146045 139.7406703824334 10.99 35.67073897064288 139.74054944905868 10.99 35.67073897064288 139.74054944905868 21.735 35.670770895855334 139.74058270570154 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b69c713-aed0-478f-95cc-dd5d4c13b081">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b69c713-aed0-478f-95cc-dd5d4c13b081">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b69c713-aed0-478f-95cc-dd5d4c13b081">
											<gml:posList>35.67078420308945 139.74075053906566 10.99 35.670814647289816 139.74070994182594 10.99 35.670814647289816 139.74070994182594 27.557 35.67078420308945 139.74075053906566 27.557 35.67078420308945 139.74075053906566 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-334dff29-61cc-44c7-a844-3091cf98a6a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-334dff29-61cc-44c7-a844-3091cf98a6a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-334dff29-61cc-44c7-a844-3091cf98a6a8">
											<gml:posList>35.67077127894963 139.74058857085075 27.557 35.67077127894963 139.74058857085075 27.153 35.670850284553296 139.7406708629462 27.153 35.670850284553296 139.7406708629462 27.557 35.67077127894963 139.74058857085075 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f559cb9a-a88a-408c-8f6f-a9fc49771c4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f559cb9a-a88a-408c-8f6f-a9fc49771c4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f559cb9a-a88a-408c-8f6f-a9fc49771c4f">
											<gml:posList>35.670839557467495 139.74066989222118 27.557 35.670839557467495 139.74066989222118 27.153 35.6708121393168 139.74070713895827 27.153 35.6708121393168 139.74070713895827 27.557 35.670839557467495 139.74066989222118 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc071b11-4093-47ac-8788-876809927492">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc071b11-4093-47ac-8788-876809927492">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc071b11-4093-47ac-8788-876809927492">
											<gml:posList>35.670814647289816 139.74070994182594 10.99 35.67083903843733 139.74067478634197 10.99 35.67083903843733 139.74067478634197 27.557 35.670814647289816 139.74070994182594 27.557 35.670814647289816 139.74070994182594 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62791e75-d59e-48a9-aa38-1b7bb8aecf16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62791e75-d59e-48a9-aa38-1b7bb8aecf16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62791e75-d59e-48a9-aa38-1b7bb8aecf16">
											<gml:posList>35.67083903843733 139.74067478634197 10.99 35.67084656192494 139.74068263158333 10.99 35.67084656192494 139.74068263158333 27.557 35.67083903843733 139.74067478634197 27.557 35.67083903843733 139.74067478634197 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d0465fb-3dcf-4305-8a83-d46023b7a487">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d0465fb-3dcf-4305-8a83-d46023b7a487">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d0465fb-3dcf-4305-8a83-d46023b7a487">
											<gml:posList>35.670850284553296 139.7406708629462 27.557 35.670850284553296 139.7406708629462 27.153 35.670846169838505 139.74067678853123 27.153 35.670846169838505 139.74067678853123 27.557 35.670850284553296 139.7406708629462 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3e68932-0d5b-45ce-87d2-a8a28cc739b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3e68932-0d5b-45ce-87d2-a8a28cc739b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3e68932-0d5b-45ce-87d2-a8a28cc739b7">
											<gml:posList>35.67084656192494 139.74068263158333 10.99 35.67085506146045 139.7406703824334 10.99 35.67085506146045 139.7406703824334 27.557 35.67084656192494 139.74068263158333 27.557 35.67084656192494 139.74068263158333 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b22c2a54-766b-4300-ab3a-20150ab96d67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b22c2a54-766b-4300-ab3a-20150ab96d67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b22c2a54-766b-4300-ab3a-20150ab96d67">
											<gml:posList>35.67063765158577 139.74069549891178 10.99 35.67075370617835 139.74081639924853 10.99 35.67075370617835 139.74081639924853 27.557 35.670669576758456 139.74072875557098 27.557 35.67063765158577 139.74069549891178 21.735 35.67063765158577 139.74069549891178 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2a5a9bd-54bd-41fe-9d1b-7cbcbd514abd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2a5a9bd-54bd-41fe-9d1b-7cbcbd514abd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2a5a9bd-54bd-41fe-9d1b-7cbcbd514abd">
											<gml:posList>35.670753323103646 139.7408105451458 27.557 35.670753323103646 139.7408105451458 27.153 35.6706743626882 139.7407282860986 27.153 35.6706743626882 139.7407282860986 27.557 35.670753323103646 139.7408105451458 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e5ab843-de62-4629-961b-d290a1609d48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e5ab843-de62-4629-961b-d290a1609d48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e5ab843-de62-4629-961b-d290a1609d48">
											<gml:posList>35.67075904948185 139.74080227589644 27.557 35.67075904948185 139.74080227589644 27.153 35.670753323103646 139.7408105451458 27.153 35.670753323103646 139.7408105451458 27.557 35.67075904948185 139.74080227589644 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edfef4da-38b5-43ea-a413-df1024186e02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edfef4da-38b5-43ea-a413-df1024186e02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edfef4da-38b5-43ea-a413-df1024186e02">
											<gml:posList>35.67075370617835 139.74081639924853 10.99 35.6707638263981 139.74080180643833 10.99 35.6707638263981 139.74080180643833 27.557 35.67075370617835 139.74081639924853 27.557 35.67075370617835 139.74081639924853 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abf2766a-270e-45bd-80ab-ad2a4f04ade9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abf2766a-270e-45bd-80ab-ad2a4f04ade9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abf2766a-270e-45bd-80ab-ad2a4f04ade9">
											<gml:posList>35.6707638263981 139.74080180643833 10.99 35.67075501292866 139.7407926260791 10.99 35.67075501292866 139.7407926260791 27.557 35.6707638263981 139.74080180643833 27.557 35.6707638263981 139.74080180643833 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd3d8e26-caa8-4d75-8d47-7d6e174d81dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd3d8e26-caa8-4d75-8d47-7d6e174d81dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd3d8e26-caa8-4d75-8d47-7d6e174d81dd">
											<gml:posList>35.67078165910495 139.7407477914709 27.557 35.67078165910495 139.7407477914709 27.153 35.67075023601243 139.74079309553773 27.153 35.67075023601243 139.74079309553773 27.557 35.67078165910495 139.7407477914709 27.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e817035e-fca4-4d02-b1c0-2abd00b4d121">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e817035e-fca4-4d02-b1c0-2abd00b4d121">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e817035e-fca4-4d02-b1c0-2abd00b4d121">
											<gml:posList>35.67075501292866 139.7407926260791 10.99 35.67078420308945 139.74075053906566 10.99 35.67078420308945 139.74075053906566 27.557 35.67075501292866 139.7407926260791 27.557 35.67075501292866 139.7407926260791 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5393</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">273.303</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>