<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_db3fd85f-35f4-4ab1-8f01-97c7b40e39e1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">18.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.674146799782235 139.7376585952258 0 35.674067778011484 139.73769459152794 0 35.67412191279705 139.73787425796982 0 35.674200574247614 139.7378384831853 0 35.674146799782235 139.7376585952258 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674146799782235 139.7376585952258 9.127 35.674200574247614 139.7378384831853 9.127 35.67412191279705 139.73787425796982 9.127 35.674067778011484 139.73769459152794 9.127 35.674146799782235 139.7376585952258 9.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674146799782235 139.7376585952258 9.127 35.674067778011484 139.73769459152794 9.127 35.674067778011484 139.73769459152794 27.86 35.674146799782235 139.7376585952258 27.86 35.674146799782235 139.7376585952258 9.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674067778011484 139.73769459152794 9.127 35.67412191279705 139.73787425796982 9.127 35.67412191279705 139.73787425796982 27.86 35.674067778011484 139.73769459152794 27.86 35.674067778011484 139.73769459152794 9.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67412191279705 139.73787425796982 9.127 35.674200574247614 139.7378384831853 9.127 35.674200574247614 139.7378384831853 27.86 35.67412191279705 139.73787425796982 27.86 35.67412191279705 139.73787425796982 9.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674200574247614 139.7378384831853 9.127 35.674146799782235 139.7376585952258 9.127 35.674146799782235 139.7376585952258 27.86 35.674200574247614 139.7378384831853 27.86 35.674200574247614 139.7378384831853 9.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674146799782235 139.7376585952258 27.86 35.674067778011484 139.73769459152794 27.86 35.67412191279705 139.73787425796982 27.86 35.674200574247614 139.7378384831853 27.86 35.674146799782235 139.7376585952258 27.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1a225892-5476-4da2-9c26-4c5b42db24fe"/>
							<gml:surfaceMember xlink:href="#poly-d5700ffb-9052-4f6b-9128-6995be008f52"/>
							<gml:surfaceMember xlink:href="#poly-ef3b89ec-977a-4170-8ae0-04463d888aa8"/>
							<gml:surfaceMember xlink:href="#poly-c93a4856-26d8-4946-a31f-844e444c740b"/>
							<gml:surfaceMember xlink:href="#poly-5892262e-d00b-4c23-8c41-6348b3eaeed8"/>
							<gml:surfaceMember xlink:href="#poly-e7368a44-569d-426e-afb5-2b66a8b09f18"/>
							<gml:surfaceMember xlink:href="#poly-4d6c7862-99eb-4269-8543-4b21e23d7f82"/>
							<gml:surfaceMember xlink:href="#poly-667fa10f-e421-43c6-ab4e-5d145d2a784d"/>
							<gml:surfaceMember xlink:href="#poly-86af26e7-3143-4c04-b634-12a08b04906f"/>
							<gml:surfaceMember xlink:href="#poly-343eb878-affe-40f0-be3a-fe89d73199c1"/>
							<gml:surfaceMember xlink:href="#poly-dca6a270-2707-452f-ac03-23293f978568"/>
							<gml:surfaceMember xlink:href="#poly-92c10c8f-2c39-401f-b917-c49e17d24c82"/>
							<gml:surfaceMember xlink:href="#poly-31464fa4-e491-498a-9670-cb66f1142dc1"/>
							<gml:surfaceMember xlink:href="#poly-001610b1-611c-4dc8-a0ab-fb1ad5de6a80"/>
							<gml:surfaceMember xlink:href="#poly-20f868df-71a8-4238-b95d-bc33f1872b7d"/>
							<gml:surfaceMember xlink:href="#poly-fbcd0a79-9196-49fe-94ef-41a6f63ecbf0"/>
							<gml:surfaceMember xlink:href="#poly-3656d665-d886-4c2d-a186-b5feed8cc830"/>
							<gml:surfaceMember xlink:href="#poly-cba9e880-4f55-42c5-8695-7f24924dd741"/>
							<gml:surfaceMember xlink:href="#poly-94b65a2b-dacb-47ca-a47c-64a0fab35ba5"/>
							<gml:surfaceMember xlink:href="#poly-f17e7a1b-ba17-4609-a6b8-64f556ebc49b"/>
							<gml:surfaceMember xlink:href="#poly-d9d4fe44-27a7-489c-afef-8b450cd74e19"/>
							<gml:surfaceMember xlink:href="#poly-c3a3e170-4312-453a-a60c-1d216edcd56d"/>
							<gml:surfaceMember xlink:href="#poly-612eadb2-e5ad-4f7b-ab3e-8afd1d3cb47f"/>
							<gml:surfaceMember xlink:href="#poly-4b665c33-f2c6-46e4-a69a-751d45e21e47"/>
							<gml:surfaceMember xlink:href="#poly-d6671624-8f8f-4bff-9adf-7a84dc09124f"/>
							<gml:surfaceMember xlink:href="#poly-77e5493a-d865-410d-9f53-926a9646f82c"/>
							<gml:surfaceMember xlink:href="#poly-9fdc3efc-1dba-4754-ab0f-8ad84b285e6f"/>
							<gml:surfaceMember xlink:href="#poly-3a5419c3-fa60-44d9-bc1e-702290dfa3cc"/>
							<gml:surfaceMember xlink:href="#poly-2efdfd48-d205-4b91-907a-26d74b6a5f65"/>
							<gml:surfaceMember xlink:href="#poly-8e4382bb-ebe9-4a76-8831-901b7b4d6739"/>
							<gml:surfaceMember xlink:href="#poly-5f02da8d-d56b-481d-908f-6cca28b5825a"/>
							<gml:surfaceMember xlink:href="#poly-9cefa671-f248-4921-a9c6-079be48fb9f2"/>
							<gml:surfaceMember xlink:href="#poly-b44d3adc-60d9-4f7e-8089-1df570d4c863"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_db3fd85f-35f4-4ab1-8f01-97c7b40e39e1_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-780878ee-6aef-42b5-870b-2fe79d181224">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67413185035046 139.73769809424496 31.837 35.67412165050853 139.73770274605832 31.837 35.67411475497599 139.7376800089769 31.837 35.674124963839546 139.73767536819707 31.837 35.67413185035046 139.73769809424496 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-678a8901-4e43-4cba-b712-a67efa85a29e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-678a8901-4e43-4cba-b712-a67efa85a29e_0">
											<gml:posList>35.674124963839546 139.73767536819707 33.145 35.674124963839546 139.73767536819707 31.837 35.67411475497599 139.7376800089769 31.837 35.67411475497599 139.7376800089769 33.145 35.674124963839546 139.73767536819707 33.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9afdf21e-b1e1-4e78-9499-36a91de73c7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9afdf21e-b1e1-4e78-9499-36a91de73c7a_0">
											<gml:posList>35.67413185035046 139.73769809424496 33.145 35.67413185035046 139.73769809424496 31.837 35.674124963839546 139.73767536819707 31.837 35.674124963839546 139.73767536819707 33.145 35.67413185035046 139.73769809424496 33.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82c6bc04-7ef1-4ff8-9879-17b1448966c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82c6bc04-7ef1-4ff8-9879-17b1448966c7_0">
											<gml:posList>35.67413185035046 139.73769809424496 33.145 35.674124963839546 139.73767536819707 33.145 35.67411475497599 139.7376800089769 33.145 35.67412165050853 139.73770274605832 33.145 35.67413185035046 139.73769809424496 33.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16eeddc9-0c16-4041-9114-223f4b59fc33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16eeddc9-0c16-4041-9114-223f4b59fc33_0">
											<gml:posList>35.67411475497599 139.7376800089769 31.837 35.67412165050853 139.73770274605832 31.837 35.67412165050853 139.73770274605832 33.145 35.67411475497599 139.7376800089769 33.145 35.67411475497599 139.7376800089769 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09e3b98e-cc4b-4ff5-861c-188a89aa021e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09e3b98e-cc4b-4ff5-861c-188a89aa021e_0">
											<gml:posList>35.67412165050853 139.73770274605832 33.145 35.67412165050853 139.73770274605832 31.837 35.67413185035046 139.73769809424496 31.837 35.67413185035046 139.73769809424496 33.145 35.67412165050853 139.73770274605832 33.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_db3fd85f-35f4-4ab1-8f01-97c7b40e39e1_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc96d7da-c084-45e9-9aad-0548c0923d00">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67415857807609 139.73773470452835 27.692 35.67416491328349 139.73775559748262 27.692 35.6741394136641 139.73776721595354 27.692 35.67413306944498 139.73774632301578 27.692 35.67415857807609 139.73773470452835 27.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8c69c90-3396-4e91-8e0f-d75f6deeb7fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8c69c90-3396-4e91-8e0f-d75f6deeb7fd_0">
											<gml:posList>35.67413306944498 139.73774632301578 30.444 35.67413306944498 139.73774632301578 27.692 35.6741394136641 139.73776721595354 27.692 35.6741394136641 139.73776721595354 30.444 35.67413306944498 139.73774632301578 30.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a08c2ad-9c34-4536-a8f5-557dfbd7e3f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a08c2ad-9c34-4536-a8f5-557dfbd7e3f0_0">
											<gml:posList>35.67415857807609 139.73773470452835 30.444 35.67415857807609 139.73773470452835 27.692 35.67413306944498 139.73774632301578 27.692 35.67413306944498 139.73774632301578 30.444 35.67415857807609 139.73773470452835 30.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bb73a98-3529-4178-a5c6-0406dc1020aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bb73a98-3529-4178-a5c6-0406dc1020aa_0">
											<gml:posList>35.67415857807609 139.73773470452835 30.444 35.67413306944498 139.73774632301578 30.444 35.6741394136641 139.73776721595354 30.444 35.67416491328349 139.73775559748262 30.444 35.67415857807609 139.73773470452835 30.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2466623b-092c-40a0-927e-31be72d4d165">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2466623b-092c-40a0-927e-31be72d4d165_0">
											<gml:posList>35.6741394136641 139.73776721595354 30.444 35.6741394136641 139.73776721595354 27.692 35.67416491328349 139.73775559748262 27.692 35.67416491328349 139.73775559748262 30.444 35.6741394136641 139.73776721595354 30.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0609b560-5d44-479f-9ddf-c787efa2ae97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0609b560-5d44-479f-9ddf-c787efa2ae97_0">
											<gml:posList>35.67416491328349 139.73775559748262 30.444 35.67416491328349 139.73775559748262 27.692 35.67415857807609 139.73773470452835 27.692 35.67415857807609 139.73773470452835 30.444 35.67416491328349 139.73775559748262 30.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1a225892-5476-4da2-9c26-4c5b42db24fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a225892-5476-4da2-9c26-4c5b42db24fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a225892-5476-4da2-9c26-4c5b42db24fe">
											<gml:posList>35.67414679978222 139.7376585952258 9.127 35.67420057424759 139.73783848318527 9.127 35.674121912797034 139.73787425796982 9.127 35.67406777801148 139.73769459152794 9.127 35.67414679978222 139.7376585952258 9.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5700ffb-9052-4f6b-9128-6995be008f52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5700ffb-9052-4f6b-9128-6995be008f52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5700ffb-9052-4f6b-9128-6995be008f52">
											<gml:posList>35.67409881005396 139.7376804588262 32.269 35.674103048396184 139.73768283987187 32.269 35.67414484793993 139.73766380058763 32.269 35.67414679978222 139.7376585952258 32.269 35.67409881005396 139.7376804588262 32.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef3b89ec-977a-4170-8ae0-04463d888aa8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef3b89ec-977a-4170-8ae0-04463d888aa8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef3b89ec-977a-4170-8ae0-04463d888aa8">
											<gml:posList>35.67414679978222 139.7376585952258 32.269 35.67414484793993 139.73766380058763 32.269 35.67415999516988 139.737714443044 32.269 35.67416420647024 139.73771682412558 32.269 35.67414679978222 139.7376585952258 32.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c93a4856-26d8-4946-a31f-844e444c740b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c93a4856-26d8-4946-a31f-844e444c740b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c93a4856-26d8-4946-a31f-844e444c740b">
											<gml:posList>35.674103717348395 139.73769662544544 32.269 35.67410566020472 139.73769145323814 32.269 35.674103048396184 139.73768283987187 32.269 35.67409881005396 139.7376804588262 32.269 35.674103717348395 139.73769662544544 32.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5892262e-d00b-4c23-8c41-6348b3eaeed8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5892262e-d00b-4c23-8c41-6348b3eaeed8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5892262e-d00b-4c23-8c41-6348b3eaeed8">
											<gml:posList>35.67407423472792 139.73769822925854 28.631 35.67410056331323 139.73768624524266 28.631 35.67409881005396 139.7376804588262 28.631 35.67406777801148 139.73769459152794 28.631 35.67407423472792 139.73769822925854 28.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e7368a44-569d-426e-afb5-2b66a8b09f18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7368a44-569d-426e-afb5-2b66a8b09f18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7368a44-569d-426e-afb5-2b66a8b09f18">
											<gml:posList>35.67410818653726 139.7376945875076 32.269 35.674110129393505 139.73768941529997 32.269 35.67410566020472 139.73769145323814 32.269 35.674103717348395 139.73769662544544 32.269 35.67410818653726 139.7376945875076 32.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d6c7862-99eb-4269-8543-4b21e23d7f82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d6c7862-99eb-4269-8543-4b21e23d7f82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d6c7862-99eb-4269-8543-4b21e23d7f82">
											<gml:posList>35.674110129393505 139.73768941529997 31.837 35.67412285403433 139.73773136681626 31.837 35.67415999516988 139.737714443044 31.837 35.67414484793993 139.73766380058763 31.837 35.674103048396184 139.73768283987187 31.837 35.67410566020472 139.73769145323814 31.837 35.674110129393505 139.73768941529997 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-667fa10f-e421-43c6-ab4e-5d145d2a784d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-667fa10f-e421-43c6-ab4e-5d145d2a784d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-667fa10f-e421-43c6-ab4e-5d145d2a784d">
											<gml:posList>35.67410818653726 139.7376945875076 32.269 35.67412091118506 139.73773655007048 32.269 35.67412285403433 139.73773136681626 32.269 35.674110129393505 139.73768941529997 32.269 35.67410818653726 139.7376945875076 32.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-86af26e7-3143-4c04-b634-12a08b04906f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86af26e7-3143-4c04-b634-12a08b04906f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86af26e7-3143-4c04-b634-12a08b04906f">
											<gml:posList>35.67416420647024 139.73771682412558 32.269 35.67415999516988 139.737714443044 32.269 35.67412285403433 139.73773136681626 32.269 35.67412091118506 139.73773655007048 32.269 35.67416420647024 139.73771682412558 32.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-343eb878-affe-40f0-be3a-fe89d73199c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-343eb878-affe-40f0-be3a-fe89d73199c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-343eb878-affe-40f0-be3a-fe89d73199c1">
											<gml:posList>35.67418000963349 139.7377876041072 27.692 35.67415945795232 139.73771898391132 27.692 35.67412091118506 139.73773655007048 27.692 35.67410818653726 139.7376945875076 27.692 35.674103717348395 139.73769662544544 27.692 35.67410056331323 139.73768624524266 27.692 35.67407423472792 139.73769822925854 27.692 35.67411094515951 139.73782003137316 27.692 35.67418000963349 139.7377876041072 27.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dca6a270-2707-452f-ac03-23293f978568">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dca6a270-2707-452f-ac03-23293f978568">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dca6a270-2707-452f-ac03-23293f978568">
											<gml:posList>35.67418000963349 139.7377876041072 28.631 35.674186439262044 139.73779118664876 28.631 35.67416420647024 139.73771682412558 28.631 35.67415945795232 139.73771898391132 28.631 35.67418000963349 139.7377876041072 28.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92c10c8f-2c39-401f-b917-c49e17d24c82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92c10c8f-2c39-401f-b917-c49e17d24c82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92c10c8f-2c39-401f-b917-c49e17d24c82">
											<gml:posList>35.67410798598206 139.7378280217156 28.631 35.67411094515951 139.73782003137316 28.631 35.67407423472792 139.73769822925854 28.631 35.67406777801148 139.73769459152794 28.631 35.67410798598206 139.7378280217156 28.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31464fa4-e491-498a-9670-cb66f1142dc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31464fa4-e491-498a-9670-cb66f1142dc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31464fa4-e491-498a-9670-cb66f1142dc1">
											<gml:posList>35.674186439262044 139.73779118664876 28.631 35.67418000963349 139.7377876041072 28.631 35.67411094515951 139.73782003137316 28.631 35.67410798598206 139.7378280217156 28.631 35.674186439262044 139.73779118664876 28.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-001610b1-611c-4dc8-a0ab-fb1ad5de6a80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-001610b1-611c-4dc8-a0ab-fb1ad5de6a80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-001610b1-611c-4dc8-a0ab-fb1ad5de6a80">
											<gml:posList>35.67420057424759 139.73783848318527 22.239 35.674186439262044 139.73779118664876 28.631 35.67410798598206 139.7378280217156 28.631 35.67420057424759 139.73783848318527 22.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20f868df-71a8-4238-b95d-bc33f1872b7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20f868df-71a8-4238-b95d-bc33f1872b7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20f868df-71a8-4238-b95d-bc33f1872b7d">
											<gml:posList>35.67420057424759 139.73783848318527 22.239 35.67410798598206 139.7378280217156 28.631 35.674121912797034 139.73787425796982 22.239 35.67420057424759 139.73783848318527 22.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fbcd0a79-9196-49fe-94ef-41a6f63ecbf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbcd0a79-9196-49fe-94ef-41a6f63ecbf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbcd0a79-9196-49fe-94ef-41a6f63ecbf0">
											<gml:posList>35.674110129393505 139.73768941529997 32.269 35.674110129393505 139.73768941529997 31.837 35.67410566020472 139.73769145323814 31.837 35.67410566020472 139.73769145323814 32.269 35.674110129393505 139.73768941529997 32.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3656d665-d886-4c2d-a186-b5feed8cc830">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3656d665-d886-4c2d-a186-b5feed8cc830">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3656d665-d886-4c2d-a186-b5feed8cc830">
											<gml:posList>35.674103048396184 139.73768283987187 32.269 35.674103048396184 139.73768283987187 31.837 35.67414484793993 139.73766380058763 31.837 35.67414484793993 139.73766380058763 32.269 35.674103048396184 139.73768283987187 32.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cba9e880-4f55-42c5-8695-7f24924dd741">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cba9e880-4f55-42c5-8695-7f24924dd741">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cba9e880-4f55-42c5-8695-7f24924dd741">
											<gml:posList>35.67406777801148 139.73769459152794 9.127 35.67406777801148 139.73769459152794 28.631 35.67409881005396 139.7376804588262 28.631 35.67409881005396 139.7376804588262 32.269 35.67414679978222 139.7376585952258 32.269 35.67414679978222 139.7376585952258 9.127 35.67406777801148 139.73769459152794 9.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94b65a2b-dacb-47ca-a47c-64a0fab35ba5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94b65a2b-dacb-47ca-a47c-64a0fab35ba5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94b65a2b-dacb-47ca-a47c-64a0fab35ba5">
											<gml:posList>35.67410566020472 139.73769145323814 32.269 35.67410566020472 139.73769145323814 31.837 35.674103048396184 139.73768283987187 31.837 35.674103048396184 139.73768283987187 32.269 35.67410566020472 139.73769145323814 32.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f17e7a1b-ba17-4609-a6b8-64f556ebc49b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f17e7a1b-ba17-4609-a6b8-64f556ebc49b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f17e7a1b-ba17-4609-a6b8-64f556ebc49b">
											<gml:posList>35.674103717348395 139.73769662544544 27.692 35.674103717348395 139.73769662544544 32.269 35.67409881005396 139.7376804588262 32.269 35.67409881005396 139.7376804588262 28.631 35.67410056331323 139.73768624524266 28.631 35.67410056331323 139.73768624524266 27.692 35.674103717348395 139.73769662544544 27.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9d4fe44-27a7-489c-afef-8b450cd74e19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9d4fe44-27a7-489c-afef-8b450cd74e19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9d4fe44-27a7-489c-afef-8b450cd74e19">
											<gml:posList>35.67414484793993 139.73766380058763 32.269 35.67414484793993 139.73766380058763 31.837 35.67415999516988 139.737714443044 31.837 35.67415999516988 139.737714443044 32.269 35.67414484793993 139.73766380058763 32.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3a3e170-4312-453a-a60c-1d216edcd56d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3a3e170-4312-453a-a60c-1d216edcd56d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3a3e170-4312-453a-a60c-1d216edcd56d">
											<gml:posList>35.67407423472792 139.73769822925854 28.631 35.67407423472792 139.73769822925854 27.692 35.67410056331323 139.73768624524266 27.692 35.67410056331323 139.73768624524266 28.631 35.67407423472792 139.73769822925854 28.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-612eadb2-e5ad-4f7b-ab3e-8afd1d3cb47f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-612eadb2-e5ad-4f7b-ab3e-8afd1d3cb47f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-612eadb2-e5ad-4f7b-ab3e-8afd1d3cb47f">
											<gml:posList>35.674103717348395 139.73769662544544 27.692 35.67410818653726 139.7376945875076 27.692 35.67410818653726 139.7376945875076 32.269 35.674103717348395 139.73769662544544 32.269 35.674103717348395 139.73769662544544 27.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b665c33-f2c6-46e4-a69a-751d45e21e47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b665c33-f2c6-46e4-a69a-751d45e21e47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b665c33-f2c6-46e4-a69a-751d45e21e47">
											<gml:posList>35.67412285403433 139.73773136681626 32.269 35.67412285403433 139.73773136681626 31.837 35.674110129393505 139.73768941529997 31.837 35.674110129393505 139.73768941529997 32.269 35.67412285403433 139.73773136681626 32.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6671624-8f8f-4bff-9adf-7a84dc09124f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6671624-8f8f-4bff-9adf-7a84dc09124f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6671624-8f8f-4bff-9adf-7a84dc09124f">
											<gml:posList>35.67410818653726 139.7376945875076 27.692 35.67412091118506 139.73773655007048 27.692 35.67412091118506 139.73773655007048 32.269 35.67410818653726 139.7376945875076 32.269 35.67410818653726 139.7376945875076 27.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77e5493a-d865-410d-9f53-926a9646f82c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77e5493a-d865-410d-9f53-926a9646f82c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77e5493a-d865-410d-9f53-926a9646f82c">
											<gml:posList>35.67415999516988 139.737714443044 32.269 35.67415999516988 139.737714443044 31.837 35.67412285403433 139.73773136681626 31.837 35.67412285403433 139.73773136681626 32.269 35.67415999516988 139.737714443044 32.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fdc3efc-1dba-4754-ab0f-8ad84b285e6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fdc3efc-1dba-4754-ab0f-8ad84b285e6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fdc3efc-1dba-4754-ab0f-8ad84b285e6f">
											<gml:posList>35.67415945795232 139.73771898391132 28.631 35.67416420647024 139.73771682412558 28.631 35.67416420647024 139.73771682412558 32.269 35.67412091118506 139.73773655007048 32.269 35.67412091118506 139.73773655007048 27.692 35.67415945795232 139.73771898391132 27.692 35.67415945795232 139.73771898391132 28.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a5419c3-fa60-44d9-bc1e-702290dfa3cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a5419c3-fa60-44d9-bc1e-702290dfa3cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a5419c3-fa60-44d9-bc1e-702290dfa3cc">
											<gml:posList>35.67411094515951 139.73782003137316 28.631 35.67411094515951 139.73782003137316 27.692 35.67407423472792 139.73769822925854 27.692 35.67407423472792 139.73769822925854 28.631 35.67411094515951 139.73782003137316 28.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2efdfd48-d205-4b91-907a-26d74b6a5f65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2efdfd48-d205-4b91-907a-26d74b6a5f65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2efdfd48-d205-4b91-907a-26d74b6a5f65">
											<gml:posList>35.67406777801148 139.73769459152794 28.631 35.67406777801148 139.73769459152794 9.127 35.674121912797034 139.73787425796982 9.127 35.674121912797034 139.73787425796982 22.239 35.67410798598206 139.7378280217156 28.631 35.67406777801148 139.73769459152794 28.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e4382bb-ebe9-4a76-8831-901b7b4d6739">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e4382bb-ebe9-4a76-8831-901b7b4d6739">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e4382bb-ebe9-4a76-8831-901b7b4d6739">
											<gml:posList>35.67418000963349 139.7377876041072 28.631 35.67418000963349 139.7377876041072 27.692 35.67411094515951 139.73782003137316 27.692 35.67411094515951 139.73782003137316 28.631 35.67418000963349 139.7377876041072 28.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f02da8d-d56b-481d-908f-6cca28b5825a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f02da8d-d56b-481d-908f-6cca28b5825a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f02da8d-d56b-481d-908f-6cca28b5825a">
											<gml:posList>35.67416420647024 139.73771682412558 28.631 35.674186439262044 139.73779118664876 28.631 35.67420057424759 139.73783848318527 22.239 35.67420057424759 139.73783848318527 9.127 35.67414679978222 139.7376585952258 9.127 35.67414679978222 139.7376585952258 32.269 35.67416420647024 139.73771682412558 32.269 35.67416420647024 139.73771682412558 28.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cefa671-f248-4921-a9c6-079be48fb9f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cefa671-f248-4921-a9c6-079be48fb9f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cefa671-f248-4921-a9c6-079be48fb9f2">
											<gml:posList>35.67415945795232 139.73771898391132 28.631 35.67415945795232 139.73771898391132 27.692 35.67418000963349 139.7377876041072 27.692 35.67418000963349 139.7377876041072 28.631 35.67415945795232 139.73771898391132 28.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b44d3adc-60d9-4f7e-8089-1df570d4c863">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b44d3adc-60d9-4f7e-8089-1df570d4c863">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b44d3adc-60d9-4f7e-8089-1df570d4c863">
											<gml:posList>35.674121912797034 139.73787425796982 9.127 35.67420057424759 139.73783848318527 9.127 35.67420057424759 139.73783848318527 22.239 35.674121912797034 139.73787425796982 22.239 35.674121912797034 139.73787425796982 9.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6048</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">161.7928</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>