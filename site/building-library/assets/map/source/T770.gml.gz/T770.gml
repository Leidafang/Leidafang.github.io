<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_dbf4ac73-3b26-4be6-ab21-0e15cca8c73c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">9.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668817946655736 139.73951477988354 0 35.668807161784194 139.73953221211178 0 35.668780597113425 139.7395075331993 0 35.66874826046989 139.7395597635513 0 35.66880066813685 139.7396084153044 0 35.6688437896934 139.73953877479914 0 35.668817946655736 139.73951477988354 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668817946655736 139.73951477988354 11.702 35.6688437896934 139.73953877479914 11.702 35.66880066813685 139.7396084153044 11.702 35.66874826046989 139.7395597635513 11.702 35.668780597113425 139.7395075331993 11.702 35.668807161784194 139.73953221211178 11.702 35.668817946655736 139.73951477988354 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668817946655736 139.73951477988354 11.702 35.668807161784194 139.73953221211178 11.702 35.668807161784194 139.73953221211178 20.86 35.668817946655736 139.73951477988354 20.86 35.668817946655736 139.73951477988354 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668807161784194 139.73953221211178 11.702 35.668780597113425 139.7395075331993 11.702 35.668780597113425 139.7395075331993 20.86 35.668807161784194 139.73953221211178 20.86 35.668807161784194 139.73953221211178 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668780597113425 139.7395075331993 11.702 35.66874826046989 139.7395597635513 11.702 35.66874826046989 139.7395597635513 20.86 35.668780597113425 139.7395075331993 20.86 35.668780597113425 139.7395075331993 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66874826046989 139.7395597635513 11.702 35.66880066813685 139.7396084153044 11.702 35.66880066813685 139.7396084153044 20.86 35.66874826046989 139.7395597635513 20.86 35.66874826046989 139.7395597635513 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880066813685 139.7396084153044 11.702 35.6688437896934 139.73953877479914 11.702 35.6688437896934 139.73953877479914 20.86 35.66880066813685 139.7396084153044 20.86 35.66880066813685 139.7396084153044 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688437896934 139.73953877479914 11.702 35.668817946655736 139.73951477988354 11.702 35.668817946655736 139.73951477988354 20.86 35.6688437896934 139.73953877479914 20.86 35.6688437896934 139.73953877479914 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668817946655736 139.73951477988354 20.86 35.668807161784194 139.73953221211178 20.86 35.668780597113425 139.7395075331993 20.86 35.66874826046989 139.7395597635513 20.86 35.66880066813685 139.7396084153044 20.86 35.6688437896934 139.73953877479914 20.86 35.668817946655736 139.73951477988354 20.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8791c3a9-92ab-49b7-8745-8141147d6eae"/>
							<gml:surfaceMember xlink:href="#poly-16680542-27e8-43c9-90dd-2db7eeb841f8"/>
							<gml:surfaceMember xlink:href="#poly-8244002b-954e-4891-99cb-7c62de833215"/>
							<gml:surfaceMember xlink:href="#poly-ba8c0f3d-8641-46a9-8ed7-ffce52a15ac5"/>
							<gml:surfaceMember xlink:href="#poly-cf9d1673-df2a-419e-91f3-a07cf39c2097"/>
							<gml:surfaceMember xlink:href="#poly-63208638-be2b-4644-aae7-496a03586905"/>
							<gml:surfaceMember xlink:href="#poly-5d370df5-3350-4fbf-abf1-6823e57a4532"/>
							<gml:surfaceMember xlink:href="#poly-d1553570-efb4-4399-9267-d5301018ab2a"/>
							<gml:surfaceMember xlink:href="#poly-acd41bb0-9abc-45c7-9f36-661c2aec40db"/>
							<gml:surfaceMember xlink:href="#poly-39a18678-a106-4217-97a9-151af2f799e6"/>
							<gml:surfaceMember xlink:href="#poly-1d00071d-6484-4076-bb07-8d69e590d8e8"/>
							<gml:surfaceMember xlink:href="#poly-944cc325-9d3a-451d-b337-6c70e7156b92"/>
							<gml:surfaceMember xlink:href="#poly-43e9937c-34fd-4574-bded-00b3aa3d00e2"/>
							<gml:surfaceMember xlink:href="#poly-ebc6c299-a289-4f94-a3ce-65766dbaa042"/>
							<gml:surfaceMember xlink:href="#poly-19d8bff6-f1ee-463c-94fb-93a8d7b1fc41"/>
							<gml:surfaceMember xlink:href="#poly-74c937be-db48-4bb2-a0ad-b916fae27533"/>
							<gml:surfaceMember xlink:href="#poly-379dfd44-eb05-426f-be1f-84c15433b9bc"/>
							<gml:surfaceMember xlink:href="#poly-93305c18-5489-4903-863f-9df5abca0e93"/>
							<gml:surfaceMember xlink:href="#poly-48372777-0a5f-4f7a-b5c5-5679f026fa77"/>
							<gml:surfaceMember xlink:href="#poly-184618be-2270-43b5-a0e7-2d9aa84455c0"/>
							<gml:surfaceMember xlink:href="#poly-a6f8744f-949b-4a79-9d4b-08ba04949b02"/>
							<gml:surfaceMember xlink:href="#poly-0e42cbc8-7584-4e65-8361-c7dfeaf4be63"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_dbf4ac73-3b26-4be6-ab21-0e15cca8c73c_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a712aaf-6fc6-4e60-8a3f-4445ddbda17b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880716178416 139.73953221211178 11.72 35.66878059710483 139.73950752215325 11.72 35.66879138199868 139.73949012306554 11.72 35.668817946655714 139.73951477988354 11.72 35.66880716178416 139.73953221211178 11.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76cbc2f1-d1dd-430c-adbb-92ad8f57826d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76cbc2f1-d1dd-430c-adbb-92ad8f57826d_0">
											<gml:posList>35.66878059711343 139.7395075331993 19.359 35.66879138199868 139.73949012306554 19.359 35.66879138199868 139.73949012306554 11.72 35.66878059710483 139.73950752215325 11.72 35.66878059711343 139.7395075331993 19.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3da7ee8b-6d6a-410d-ac1f-37f5279f595a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3da7ee8b-6d6a-410d-ac1f-37f5279f595a_0">
											<gml:posList>35.668817946655714 139.73951477988354 11.72 35.66879138199868 139.73949012306554 11.72 35.66879138199868 139.73949012306554 19.359 35.668817946655714 139.73951477988354 21.245 35.668817946655714 139.73951477988354 11.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ad48607-22bc-45b3-9fb0-4b5fb1638aea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ad48607-22bc-45b3-9fb0-4b5fb1638aea_0">
											<gml:posList>35.66879138199868 139.73949012306554 19.359 35.66878059711343 139.7395075331993 19.359 35.66880716178416 139.73953221211178 21.244 35.668817946655714 139.73951477988354 21.245 35.66879138199868 139.73949012306554 19.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cc07229-6056-47d8-a60c-a6702320fcdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cc07229-6056-47d8-a60c-a6702320fcdf_0">
											<gml:posList>35.66878059711343 139.7395075331993 19.359 35.66878059710483 139.73950752215325 11.72 35.66880716178416 139.73953221211178 11.72 35.66880716178416 139.73953221211178 21.244 35.66878059711343 139.7395075331993 19.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b650a104-6e7d-47e5-bea1-62fd77338b37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b650a104-6e7d-47e5-bea1-62fd77338b37_0">
											<gml:posList>35.66880716178416 139.73953221211178 21.244 35.66880716178416 139.73953221211178 11.72 35.668817946655714 139.73951477988354 11.72 35.668817946655714 139.73951477988354 21.245 35.66880716178416 139.73953221211178 21.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8791c3a9-92ab-49b7-8745-8141147d6eae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8791c3a9-92ab-49b7-8745-8141147d6eae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8791c3a9-92ab-49b7-8745-8141147d6eae">
											<gml:posList>35.66874826046989 139.7395597635513 11.702 35.66878059711343 139.7395075331993 11.702 35.66880716178416 139.73953221211178 11.702 35.668817946655714 139.73951477988354 11.702 35.66884378969337 139.73953877479912 11.702 35.66880066813685 139.7396084153044 11.702 35.66874826046989 139.7395597635513 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16680542-27e8-43c9-90dd-2db7eeb841f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16680542-27e8-43c9-90dd-2db7eeb841f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16680542-27e8-43c9-90dd-2db7eeb841f8">
											<gml:posList>35.668795237008986 139.73952114688288 19.248 35.66878059711343 139.7395075331993 19.248 35.66874826046989 139.7395597635513 19.248 35.66876271993891 139.7395731896673 19.248 35.668795237008986 139.73952114688288 19.248</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8244002b-954e-4891-99cb-7c62de833215">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8244002b-954e-4891-99cb-7c62de833215">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8244002b-954e-4891-99cb-7c62de833215">
											<gml:posList>35.66876271993891 139.7395731896673 21.307 35.66876444133674 139.73957290045746 21.307 35.66879546398716 139.73952324536512 21.307 35.668795237008986 139.73952114688288 21.307 35.66876271993891 139.7395731896673 21.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba8c0f3d-8641-46a9-8ed7-ffce52a15ac5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba8c0f3d-8641-46a9-8ed7-ffce52a15ac5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba8c0f3d-8641-46a9-8ed7-ffce52a15ac5">
											<gml:posList>35.66880066813685 139.7396084153044 21.307 35.66880043214644 139.7396063168323 21.307 35.66876444133674 139.73957290045746 21.307 35.66876271993891 139.7395731896673 21.307 35.66880066813685 139.7396084153044 21.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf9d1673-df2a-419e-91f3-a07cf39c2097">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf9d1673-df2a-419e-91f3-a07cf39c2097">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf9d1673-df2a-419e-91f3-a07cf39c2097">
											<gml:posList>35.66880716178416 139.73953221211178 21.307 35.668795237008986 139.73952114688288 21.307 35.66879546398716 139.73952324536512 21.307 35.66880739777587 139.73953431058385 21.307 35.66880716178416 139.73953221211178 21.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63208638-be2b-4644-aae7-496a03586905">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63208638-be2b-4644-aae7-496a03586905">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63208638-be2b-4644-aae7-496a03586905">
											<gml:posList>35.66880043214644 139.7396063168323 20.976 35.66884206830426 139.73953907505606 20.976 35.668818182656324 139.73951688940184 20.976 35.66880739777587 139.73953431058385 20.976 35.66879546398716 139.73952324536512 20.976 35.66876444133674 139.73957290045746 20.976 35.66880043214644 139.7396063168323 20.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d370df5-3350-4fbf-abf1-6823e57a4532">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d370df5-3350-4fbf-abf1-6823e57a4532">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d370df5-3350-4fbf-abf1-6823e57a4532">
											<gml:posList>35.66880716178416 139.73953221211178 21.307 35.66880739777587 139.73953431058385 21.307 35.668818182656324 139.73951688940184 21.307 35.668817946655714 139.73951477988354 21.307 35.66880716178416 139.73953221211178 21.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1553570-efb4-4399-9267-d5301018ab2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1553570-efb4-4399-9267-d5301018ab2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1553570-efb4-4399-9267-d5301018ab2a">
											<gml:posList>35.66884378969337 139.73953877479912 21.307 35.66884206830426 139.73953907505606 21.307 35.66880043214644 139.7396063168323 21.307 35.66880066813685 139.7396084153044 21.307 35.66884378969337 139.73953877479912 21.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-acd41bb0-9abc-45c7-9f36-661c2aec40db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acd41bb0-9abc-45c7-9f36-661c2aec40db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acd41bb0-9abc-45c7-9f36-661c2aec40db">
											<gml:posList>35.668817946655714 139.73951477988354 21.307 35.668818182656324 139.73951688940184 21.307 35.66884206830426 139.73953907505606 21.307 35.66884378969337 139.73953877479912 21.307 35.668817946655714 139.73951477988354 21.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39a18678-a106-4217-97a9-151af2f799e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39a18678-a106-4217-97a9-151af2f799e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39a18678-a106-4217-97a9-151af2f799e6">
											<gml:posList>35.66880716178416 139.73953221211178 21.307 35.66880716178416 139.73953221211178 11.702 35.66878059711343 139.7395075331993 11.702 35.66878059711343 139.7395075331993 19.248 35.668795237008986 139.73952114688288 19.248 35.668795237008986 139.73952114688288 21.307 35.66880716178416 139.73953221211178 21.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d00071d-6484-4076-bb07-8d69e590d8e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d00071d-6484-4076-bb07-8d69e590d8e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d00071d-6484-4076-bb07-8d69e590d8e8">
											<gml:posList>35.668817946655714 139.73951477988354 11.702 35.66880716178416 139.73953221211178 11.702 35.66880716178416 139.73953221211178 21.307 35.668817946655714 139.73951477988354 21.307 35.668817946655714 139.73951477988354 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-944cc325-9d3a-451d-b337-6c70e7156b92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-944cc325-9d3a-451d-b337-6c70e7156b92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-944cc325-9d3a-451d-b337-6c70e7156b92">
											<gml:posList>35.66880739777587 139.73953431058385 21.307 35.66880739777587 139.73953431058385 20.976 35.668818182656324 139.73951688940184 20.976 35.668818182656324 139.73951688940184 21.307 35.66880739777587 139.73953431058385 21.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43e9937c-34fd-4574-bded-00b3aa3d00e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43e9937c-34fd-4574-bded-00b3aa3d00e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43e9937c-34fd-4574-bded-00b3aa3d00e2">
											<gml:posList>35.66884378969337 139.73953877479912 11.702 35.668817946655714 139.73951477988354 11.702 35.668817946655714 139.73951477988354 21.307 35.66884378969337 139.73953877479912 21.307 35.66884378969337 139.73953877479912 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebc6c299-a289-4f94-a3ce-65766dbaa042">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebc6c299-a289-4f94-a3ce-65766dbaa042">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebc6c299-a289-4f94-a3ce-65766dbaa042">
											<gml:posList>35.668818182656324 139.73951688940184 21.307 35.668818182656324 139.73951688940184 20.976 35.66884206830426 139.73953907505606 20.976 35.66884206830426 139.73953907505606 21.307 35.668818182656324 139.73951688940184 21.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19d8bff6-f1ee-463c-94fb-93a8d7b1fc41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19d8bff6-f1ee-463c-94fb-93a8d7b1fc41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19d8bff6-f1ee-463c-94fb-93a8d7b1fc41">
											<gml:posList>35.66879546398716 139.73952324536512 21.307 35.66879546398716 139.73952324536512 20.976 35.66880739777587 139.73953431058385 20.976 35.66880739777587 139.73953431058385 21.307 35.66879546398716 139.73952324536512 21.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74c937be-db48-4bb2-a0ad-b916fae27533">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74c937be-db48-4bb2-a0ad-b916fae27533">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74c937be-db48-4bb2-a0ad-b916fae27533">
											<gml:posList>35.66878059711343 139.7395075331993 11.702 35.66874826046989 139.7395597635513 11.702 35.66874826046989 139.7395597635513 19.248 35.66878059711343 139.7395075331993 19.248 35.66878059711343 139.7395075331993 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-379dfd44-eb05-426f-be1f-84c15433b9bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-379dfd44-eb05-426f-be1f-84c15433b9bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-379dfd44-eb05-426f-be1f-84c15433b9bc">
											<gml:posList>35.66876271993891 139.7395731896673 19.248 35.66876271993891 139.7395731896673 21.307 35.668795237008986 139.73952114688288 21.307 35.668795237008986 139.73952114688288 19.248 35.66876271993891 139.7395731896673 19.248</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93305c18-5489-4903-863f-9df5abca0e93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93305c18-5489-4903-863f-9df5abca0e93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93305c18-5489-4903-863f-9df5abca0e93">
											<gml:posList>35.66876444133674 139.73957290045746 21.307 35.66876444133674 139.73957290045746 20.976 35.66879546398716 139.73952324536512 20.976 35.66879546398716 139.73952324536512 21.307 35.66876444133674 139.73957290045746 21.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48372777-0a5f-4f7a-b5c5-5679f026fa77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48372777-0a5f-4f7a-b5c5-5679f026fa77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48372777-0a5f-4f7a-b5c5-5679f026fa77">
											<gml:posList>35.66884206830426 139.73953907505606 21.307 35.66884206830426 139.73953907505606 20.976 35.66880043214644 139.7396063168323 20.976 35.66880043214644 139.7396063168323 21.307 35.66884206830426 139.73953907505606 21.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-184618be-2270-43b5-a0e7-2d9aa84455c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-184618be-2270-43b5-a0e7-2d9aa84455c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-184618be-2270-43b5-a0e7-2d9aa84455c0">
											<gml:posList>35.66880066813685 139.7396084153044 11.702 35.66884378969337 139.73953877479912 11.702 35.66884378969337 139.73953877479912 21.307 35.66880066813685 139.7396084153044 21.307 35.66880066813685 139.7396084153044 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6f8744f-949b-4a79-9d4b-08ba04949b02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6f8744f-949b-4a79-9d4b-08ba04949b02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6f8744f-949b-4a79-9d4b-08ba04949b02">
											<gml:posList>35.66880066813685 139.7396084153044 11.702 35.66880066813685 139.7396084153044 21.307 35.66876271993891 139.7395731896673 21.307 35.66876271993891 139.7395731896673 19.248 35.66874826046989 139.7395597635513 19.248 35.66874826046989 139.7395597635513 11.702 35.66880066813685 139.7396084153044 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e42cbc8-7584-4e65-8361-c7dfeaf4be63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e42cbc8-7584-4e65-8361-c7dfeaf4be63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e42cbc8-7584-4e65-8361-c7dfeaf4be63">
											<gml:posList>35.66880043214644 139.7396063168323 21.307 35.66880043214644 139.7396063168323 20.976 35.66876444133674 139.73957290045746 20.976 35.66876444133674 139.73957290045746 21.307 35.66880043214644 139.7396063168323 21.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3204</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">57.7269</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>