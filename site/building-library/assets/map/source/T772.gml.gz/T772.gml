<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_dd2feae4-ab34-4961-9675-6ff202c5c099">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67050423930221 139.7416020111001 0 35.67048055941085 139.74160093356508 0 35.67047964506274 139.7416312345388 0 35.67050332494544 139.74163230103645 0 35.67050423930221 139.7416020111001 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050423930221 139.7416020111001 8.61 35.67050332494544 139.74163230103645 8.61 35.67047964506274 139.7416312345388 8.61 35.67048055941085 139.74160093356508 8.61 35.67050423930221 139.7416020111001 8.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050423930221 139.7416020111001 8.61 35.67048055941085 139.74160093356508 8.61 35.67048055941085 139.74160093356508 11.61 35.67050423930221 139.7416020111001 11.61 35.67050423930221 139.7416020111001 8.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67048055941085 139.74160093356508 8.61 35.67047964506274 139.7416312345388 8.61 35.67047964506274 139.7416312345388 11.61 35.67048055941085 139.74160093356508 11.61 35.67048055941085 139.74160093356508 8.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047964506274 139.7416312345388 8.61 35.67050332494544 139.74163230103645 8.61 35.67050332494544 139.74163230103645 11.61 35.67047964506274 139.7416312345388 11.61 35.67047964506274 139.7416312345388 8.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050332494544 139.74163230103645 8.61 35.67050423930221 139.7416020111001 8.61 35.67050423930221 139.7416020111001 11.61 35.67050332494544 139.74163230103645 11.61 35.67050332494544 139.74163230103645 8.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050423930221 139.7416020111001 11.61 35.67048055941085 139.74160093356508 11.61 35.67047964506274 139.7416312345388 11.61 35.67050332494544 139.74163230103645 11.61 35.67050423930221 139.7416020111001 11.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ec5f9054-2589-4d41-a82d-f8c1c425a6cc"/>
							<gml:surfaceMember xlink:href="#poly-c010ffd3-2b7a-44b7-852b-fb3c99751040"/>
							<gml:surfaceMember xlink:href="#poly-293b0c4b-c69a-4df8-9a79-ea45e1abf052"/>
							<gml:surfaceMember xlink:href="#poly-635465d1-2513-48f0-9e00-a9ba812e7b2d"/>
							<gml:surfaceMember xlink:href="#poly-f09f7129-c305-4c16-977e-ab42b52b33c2"/>
							<gml:surfaceMember xlink:href="#poly-cd05d532-9ade-44c0-a0ba-2ebe4702b0b9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ec5f9054-2589-4d41-a82d-f8c1c425a6cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec5f9054-2589-4d41-a82d-f8c1c425a6cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec5f9054-2589-4d41-a82d-f8c1c425a6cc">
											<gml:posList>35.67050423930218 139.7416020111001 8.61 35.670503324945436 139.74163230103645 8.61 35.67047964506274 139.74163123453877 8.61 35.67048055941082 139.74160093356508 8.61 35.67050423930218 139.7416020111001 8.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c010ffd3-2b7a-44b7-852b-fb3c99751040">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c010ffd3-2b7a-44b7-852b-fb3c99751040">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c010ffd3-2b7a-44b7-852b-fb3c99751040">
											<gml:posList>35.67048055941082 139.74160093356508 12.009 35.67047964506274 139.74163123453877 12.009 35.670503324945436 139.74163230103645 12.009 35.67050423930218 139.7416020111001 12.009 35.67048055941082 139.74160093356508 12.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-293b0c4b-c69a-4df8-9a79-ea45e1abf052">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-293b0c4b-c69a-4df8-9a79-ea45e1abf052">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-293b0c4b-c69a-4df8-9a79-ea45e1abf052">
											<gml:posList>35.67050423930218 139.7416020111001 12.009 35.67050423930218 139.7416020111001 8.61 35.67048055941082 139.74160093356508 8.61 35.67048055941082 139.74160093356508 12.009 35.67050423930218 139.7416020111001 12.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-635465d1-2513-48f0-9e00-a9ba812e7b2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-635465d1-2513-48f0-9e00-a9ba812e7b2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-635465d1-2513-48f0-9e00-a9ba812e7b2d">
											<gml:posList>35.67048055941082 139.74160093356508 12.009 35.67048055941082 139.74160093356508 8.61 35.67047964506274 139.74163123453877 8.61 35.67047964506274 139.74163123453877 12.009 35.67048055941082 139.74160093356508 12.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f09f7129-c305-4c16-977e-ab42b52b33c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f09f7129-c305-4c16-977e-ab42b52b33c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f09f7129-c305-4c16-977e-ab42b52b33c2">
											<gml:posList>35.670503324945436 139.74163230103645 12.009 35.670503324945436 139.74163230103645 8.61 35.67050423930218 139.7416020111001 8.61 35.67050423930218 139.7416020111001 12.009 35.670503324945436 139.74163230103645 12.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd05d532-9ade-44c0-a0ba-2ebe4702b0b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd05d532-9ade-44c0-a0ba-2ebe4702b0b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd05d532-9ade-44c0-a0ba-2ebe4702b0b9">
											<gml:posList>35.67047964506274 139.74163123453877 12.009 35.67047964506274 139.74163123453877 8.61 35.670503324945436 139.74163230103645 8.61 35.670503324945436 139.74163230103645 12.009 35.67047964506274 139.74163123453877 12.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-555</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>