<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_de37e7d5-a52c-45bb-81ef-d0888574e736">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">9.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67499856410524 139.74174311839184 0 35.6750028546677 139.7417431576773 0 35.67500302099152 139.741724819639 0 35.67495438888588 139.74166157653528 0 35.67494285124507 139.7416614792603 0 35.67494293423292 139.74165208931035 0 35.67488722416743 139.7416451934895 0 35.674886576720695 139.74174196490313 0 35.67499856410524 139.74174311839184 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67499856410524 139.74174311839184 9.5 35.674886576720695 139.74174196490313 9.5 35.67488722416743 139.7416451934895 9.5 35.67494293423292 139.74165208931035 9.5 35.67494285124507 139.7416614792603 9.5 35.67495438888588 139.74166157653528 9.5 35.67500302099152 139.741724819639 9.5 35.6750028546677 139.7417431576773 9.5 35.67499856410524 139.74174311839184 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67499856410524 139.74174311839184 9.5 35.6750028546677 139.7417431576773 9.5 35.6750028546677 139.7417431576773 19.19 35.67499856410524 139.74174311839184 19.19 35.67499856410524 139.74174311839184 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6750028546677 139.7417431576773 9.5 35.67500302099152 139.741724819639 9.5 35.67500302099152 139.741724819639 19.19 35.6750028546677 139.7417431576773 19.19 35.6750028546677 139.7417431576773 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67500302099152 139.741724819639 9.5 35.67495438888588 139.74166157653528 9.5 35.67495438888588 139.74166157653528 19.19 35.67500302099152 139.741724819639 19.19 35.67500302099152 139.741724819639 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67495438888588 139.74166157653528 9.5 35.67494285124507 139.7416614792603 9.5 35.67494285124507 139.7416614792603 19.19 35.67495438888588 139.74166157653528 19.19 35.67495438888588 139.74166157653528 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67494285124507 139.7416614792603 9.5 35.67494293423292 139.74165208931035 9.5 35.67494293423292 139.74165208931035 19.19 35.67494285124507 139.7416614792603 19.19 35.67494285124507 139.7416614792603 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67494293423292 139.74165208931035 9.5 35.67488722416743 139.7416451934895 9.5 35.67488722416743 139.7416451934895 19.19 35.67494293423292 139.74165208931035 19.19 35.67494293423292 139.74165208931035 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67488722416743 139.7416451934895 9.5 35.674886576720695 139.74174196490313 9.5 35.674886576720695 139.74174196490313 19.19 35.67488722416743 139.7416451934895 19.19 35.67488722416743 139.7416451934895 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674886576720695 139.74174196490313 9.5 35.67499856410524 139.74174311839184 9.5 35.67499856410524 139.74174311839184 19.19 35.674886576720695 139.74174196490313 19.19 35.674886576720695 139.74174196490313 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67499856410524 139.74174311839184 19.19 35.6750028546677 139.7417431576773 19.19 35.67500302099152 139.741724819639 19.19 35.67495438888588 139.74166157653528 19.19 35.67494285124507 139.7416614792603 19.19 35.67494293423292 139.74165208931035 19.19 35.67488722416743 139.7416451934895 19.19 35.674886576720695 139.74174196490313 19.19 35.67499856410524 139.74174311839184 19.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c133f667-399e-49ae-87d4-240ea15ee18c"/>
							<gml:surfaceMember xlink:href="#poly-3e039747-24a5-4c99-b942-1ab1fdb3d87b"/>
							<gml:surfaceMember xlink:href="#poly-13f1588d-a819-4678-a378-32928b638a76"/>
							<gml:surfaceMember xlink:href="#poly-18b0af81-4de9-4c16-8546-52d74d8c167c"/>
							<gml:surfaceMember xlink:href="#poly-8ddc155c-60ad-42ee-94bd-8f0851d2fb14"/>
							<gml:surfaceMember xlink:href="#poly-1257e143-2e9e-426a-b36c-4053ef80225e"/>
							<gml:surfaceMember xlink:href="#poly-bae5888b-a492-4852-8d58-10ed0b6ae496"/>
							<gml:surfaceMember xlink:href="#poly-790ab975-4f83-42bb-82ee-47cd5a840d6c"/>
							<gml:surfaceMember xlink:href="#poly-77ecf748-a1a8-4783-868e-6ac698163781"/>
							<gml:surfaceMember xlink:href="#poly-462c22cd-61a3-46da-9908-dfad7d89a822"/>
							<gml:surfaceMember xlink:href="#poly-e146b411-eda0-43a1-aabc-270928c18845"/>
							<gml:surfaceMember xlink:href="#poly-96244f06-8d9d-4e92-84bc-13df3a0b5c35"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c133f667-399e-49ae-87d4-240ea15ee18c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c133f667-399e-49ae-87d4-240ea15ee18c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c133f667-399e-49ae-87d4-240ea15ee18c">
											<gml:posList>35.67494285124506 139.7416614792603 9.5 35.67495438888584 139.74166157653528 9.5 35.675003020991525 139.741724819639 9.5 35.67500285466771 139.74174315767726 9.5 35.67488657672069 139.74174196490313 9.5 35.67488722416741 139.7416451934895 9.5 35.67494293423289 139.74165208931035 9.5 35.67494285124506 139.7416614792603 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e039747-24a5-4c99-b942-1ab1fdb3d87b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e039747-24a5-4c99-b942-1ab1fdb3d87b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e039747-24a5-4c99-b942-1ab1fdb3d87b">
											<gml:posList>35.67488657672069 139.74174196490313 18.67 35.67499856410524 139.74174311839184 18.67 35.674943517412515 139.74167220502707 18.67 35.67494285124506 139.7416614792603 18.67 35.67494293423289 139.74165208931035 18.67 35.67488722416741 139.7416451934895 18.67 35.67488657672069 139.74174196490313 18.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-13f1588d-a819-4678-a378-32928b638a76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13f1588d-a819-4678-a378-32928b638a76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13f1588d-a819-4678-a378-32928b638a76">
											<gml:posList>35.67495438888584 139.74166157653528 16.67 35.67494285124506 139.7416614792603 16.67 35.674943517412515 139.74167220502707 16.67 35.67499856410524 139.74174311839184 16.67 35.67500285466771 139.74174315767726 16.67 35.675003020991525 139.741724819639 16.67 35.67495438888584 139.74166157653528 16.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18b0af81-4de9-4c16-8546-52d74d8c167c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18b0af81-4de9-4c16-8546-52d74d8c167c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18b0af81-4de9-4c16-8546-52d74d8c167c">
											<gml:posList>35.67494293423289 139.74165208931035 9.5 35.67488722416741 139.7416451934895 9.5 35.67488722416741 139.7416451934895 18.67 35.67494293423289 139.74165208931035 18.67 35.67494293423289 139.74165208931035 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ddc155c-60ad-42ee-94bd-8f0851d2fb14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ddc155c-60ad-42ee-94bd-8f0851d2fb14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ddc155c-60ad-42ee-94bd-8f0851d2fb14">
											<gml:posList>35.67494293423289 139.74165208931035 18.67 35.67494285124506 139.7416614792603 18.67 35.67494285124506 139.7416614792603 16.67 35.67494285124506 139.7416614792603 9.5 35.67494293423289 139.74165208931035 9.5 35.67494293423289 139.74165208931035 18.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1257e143-2e9e-426a-b36c-4053ef80225e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1257e143-2e9e-426a-b36c-4053ef80225e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1257e143-2e9e-426a-b36c-4053ef80225e">
											<gml:posList>35.67495438888584 139.74166157653528 9.5 35.67494285124506 139.7416614792603 9.5 35.67494285124506 139.7416614792603 16.67 35.67495438888584 139.74166157653528 16.67 35.67495438888584 139.74166157653528 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bae5888b-a492-4852-8d58-10ed0b6ae496">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bae5888b-a492-4852-8d58-10ed0b6ae496">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bae5888b-a492-4852-8d58-10ed0b6ae496">
											<gml:posList>35.67494285124506 139.7416614792603 18.67 35.674943517412515 139.74167220502707 18.67 35.674943517412515 139.74167220502707 16.67 35.67494285124506 139.7416614792603 16.67 35.67494285124506 139.7416614792603 18.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-790ab975-4f83-42bb-82ee-47cd5a840d6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-790ab975-4f83-42bb-82ee-47cd5a840d6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-790ab975-4f83-42bb-82ee-47cd5a840d6c">
											<gml:posList>35.675003020991525 139.741724819639 9.5 35.67495438888584 139.74166157653528 9.5 35.67495438888584 139.74166157653528 16.67 35.675003020991525 139.741724819639 16.67 35.675003020991525 139.741724819639 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77ecf748-a1a8-4783-868e-6ac698163781">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77ecf748-a1a8-4783-868e-6ac698163781">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77ecf748-a1a8-4783-868e-6ac698163781">
											<gml:posList>35.67488722416741 139.7416451934895 9.5 35.67488657672069 139.74174196490313 9.5 35.67488657672069 139.74174196490313 18.67 35.67488722416741 139.7416451934895 18.67 35.67488722416741 139.7416451934895 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-462c22cd-61a3-46da-9908-dfad7d89a822">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-462c22cd-61a3-46da-9908-dfad7d89a822">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-462c22cd-61a3-46da-9908-dfad7d89a822">
											<gml:posList>35.674943517412515 139.74167220502707 18.67 35.67499856410524 139.74174311839184 18.67 35.67499856410524 139.74174311839184 16.67 35.674943517412515 139.74167220502707 16.67 35.674943517412515 139.74167220502707 18.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e146b411-eda0-43a1-aabc-270928c18845">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e146b411-eda0-43a1-aabc-270928c18845">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e146b411-eda0-43a1-aabc-270928c18845">
											<gml:posList>35.67500285466771 139.74174315767726 9.5 35.675003020991525 139.741724819639 9.5 35.675003020991525 139.741724819639 16.67 35.67500285466771 139.74174315767726 16.67 35.67500285466771 139.74174315767726 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96244f06-8d9d-4e92-84bc-13df3a0b5c35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96244f06-8d9d-4e92-84bc-13df3a0b5c35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96244f06-8d9d-4e92-84bc-13df3a0b5c35">
											<gml:posList>35.67500285466771 139.74174315767726 9.5 35.67500285466771 139.74174315767726 16.67 35.67499856410524 139.74174311839184 16.67 35.67499856410524 139.74174311839184 18.67 35.67488657672069 139.74174196490313 18.67 35.67488657672069 139.74174196490313 9.5 35.67500285466771 139.74174315767726 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4628</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">86.10198</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.07</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>