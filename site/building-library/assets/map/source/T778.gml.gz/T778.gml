<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_dea0fa6f-a403-4805-b485-6b63cd5f3de4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">180.2</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66949221450195 139.74079037207056 0 35.670178574118296 139.7407083237889 0 35.67017673555125 139.74068519510425 0 35.67021425626352 139.74068071116082 0 35.670177111249146 139.7402140508057 0 35.66984388637341 139.74025388374008 0 35.66981383057309 139.73987630492132 0 35.66978583652011 139.73987965140446 0 35.66978444383959 139.73986215588286 0 35.6697910593038 139.73986136389206 0 35.66978907494793 139.73983642393557 0 35.6694169054514 139.73988090987092 0 35.66946594800978 139.7404970060349 0 35.669486019742266 139.74049460787563 0 35.669488313382736 139.74052338040565 0 35.66950833103332 139.7405209823149 0 35.669511398315215 139.7405594635153 0 35.66949040726679 139.74056197318416 0 35.66949341995982 139.74059981376473 0 35.66947719673663 139.7406017545554 0 35.66949221450195 139.74079037207056 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949221450195 139.74079037207056 9.22 35.66947719673663 139.7406017545554 9.22 35.66949341995982 139.74059981376473 9.22 35.66949040726679 139.74056197318416 9.22 35.669511398315215 139.7405594635153 9.22 35.66950833103332 139.7405209823149 9.22 35.669488313382736 139.74052338040565 9.22 35.669486019742266 139.74049460787563 9.22 35.66946594800978 139.7404970060349 9.22 35.6694169054514 139.73988090987092 9.22 35.66978907494793 139.73983642393557 9.22 35.6697910593038 139.73986136389206 9.22 35.66978444383959 139.73986215588286 9.22 35.66978583652011 139.73987965140446 9.22 35.66981383057309 139.73987630492132 9.22 35.66984388637341 139.74025388374008 9.22 35.670177111249146 139.7402140508057 9.22 35.67021425626352 139.74068071116082 9.22 35.67017673555125 139.74068519510425 9.22 35.670178574118296 139.7407083237889 9.22 35.66949221450195 139.74079037207056 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949221450195 139.74079037207056 9.22 35.670178574118296 139.7407083237889 9.22 35.670178574118296 139.7407083237889 189.37 35.66949221450195 139.74079037207056 189.37 35.66949221450195 139.74079037207056 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670178574118296 139.7407083237889 9.22 35.67017673555125 139.74068519510425 9.22 35.67017673555125 139.74068519510425 189.37 35.670178574118296 139.7407083237889 189.37 35.670178574118296 139.7407083237889 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67017673555125 139.74068519510425 9.22 35.67021425626352 139.74068071116082 9.22 35.67021425626352 139.74068071116082 189.37 35.67017673555125 139.74068519510425 189.37 35.67017673555125 139.74068519510425 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021425626352 139.74068071116082 9.22 35.670177111249146 139.7402140508057 9.22 35.670177111249146 139.7402140508057 189.37 35.67021425626352 139.74068071116082 189.37 35.67021425626352 139.74068071116082 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670177111249146 139.7402140508057 9.22 35.66984388637341 139.74025388374008 9.22 35.66984388637341 139.74025388374008 189.37 35.670177111249146 139.7402140508057 189.37 35.670177111249146 139.7402140508057 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66984388637341 139.74025388374008 9.22 35.66981383057309 139.73987630492132 9.22 35.66981383057309 139.73987630492132 189.37 35.66984388637341 139.74025388374008 189.37 35.66984388637341 139.74025388374008 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66981383057309 139.73987630492132 9.22 35.66978583652011 139.73987965140446 9.22 35.66978583652011 139.73987965140446 189.37 35.66981383057309 139.73987630492132 189.37 35.66981383057309 139.73987630492132 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66978583652011 139.73987965140446 9.22 35.66978444383959 139.73986215588286 9.22 35.66978444383959 139.73986215588286 189.37 35.66978583652011 139.73987965140446 189.37 35.66978583652011 139.73987965140446 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66978444383959 139.73986215588286 9.22 35.6697910593038 139.73986136389206 9.22 35.6697910593038 139.73986136389206 189.37 35.66978444383959 139.73986215588286 189.37 35.66978444383959 139.73986215588286 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6697910593038 139.73986136389206 9.22 35.66978907494793 139.73983642393557 9.22 35.66978907494793 139.73983642393557 189.37 35.6697910593038 139.73986136389206 189.37 35.6697910593038 139.73986136389206 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66978907494793 139.73983642393557 9.22 35.6694169054514 139.73988090987092 9.22 35.6694169054514 139.73988090987092 189.37 35.66978907494793 139.73983642393557 189.37 35.66978907494793 139.73983642393557 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6694169054514 139.73988090987092 9.22 35.66946594800978 139.7404970060349 9.22 35.66946594800978 139.7404970060349 189.37 35.6694169054514 139.73988090987092 189.37 35.6694169054514 139.73988090987092 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66946594800978 139.7404970060349 9.22 35.669486019742266 139.74049460787563 9.22 35.669486019742266 139.74049460787563 189.37 35.66946594800978 139.7404970060349 189.37 35.66946594800978 139.7404970060349 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669486019742266 139.74049460787563 9.22 35.669488313382736 139.74052338040565 9.22 35.669488313382736 139.74052338040565 189.37 35.669486019742266 139.74049460787563 189.37 35.669486019742266 139.74049460787563 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669488313382736 139.74052338040565 9.22 35.66950833103332 139.7405209823149 9.22 35.66950833103332 139.7405209823149 189.37 35.669488313382736 139.74052338040565 189.37 35.669488313382736 139.74052338040565 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66950833103332 139.7405209823149 9.22 35.669511398315215 139.7405594635153 9.22 35.669511398315215 139.7405594635153 189.37 35.66950833103332 139.7405209823149 189.37 35.66950833103332 139.7405209823149 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669511398315215 139.7405594635153 9.22 35.66949040726679 139.74056197318416 9.22 35.66949040726679 139.74056197318416 189.37 35.669511398315215 139.7405594635153 189.37 35.669511398315215 139.7405594635153 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949040726679 139.74056197318416 9.22 35.66949341995982 139.74059981376473 9.22 35.66949341995982 139.74059981376473 189.37 35.66949040726679 139.74056197318416 189.37 35.66949040726679 139.74056197318416 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949341995982 139.74059981376473 9.22 35.66947719673663 139.7406017545554 9.22 35.66947719673663 139.7406017545554 189.37 35.66949341995982 139.74059981376473 189.37 35.66949341995982 139.74059981376473 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66947719673663 139.7406017545554 9.22 35.66949221450195 139.74079037207056 9.22 35.66949221450195 139.74079037207056 189.37 35.66947719673663 139.7406017545554 189.37 35.66947719673663 139.7406017545554 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949221450195 139.74079037207056 189.37 35.670178574118296 139.7407083237889 189.37 35.67017673555125 139.74068519510425 189.37 35.67021425626352 139.74068071116082 189.37 35.670177111249146 139.7402140508057 189.37 35.66984388637341 139.74025388374008 189.37 35.66981383057309 139.73987630492132 189.37 35.66978583652011 139.73987965140446 189.37 35.66978444383959 139.73986215588286 189.37 35.6697910593038 139.73986136389206 189.37 35.66978907494793 139.73983642393557 189.37 35.6694169054514 139.73988090987092 189.37 35.66946594800978 139.7404970060349 189.37 35.669486019742266 139.74049460787563 189.37 35.669488313382736 139.74052338040565 189.37 35.66950833103332 139.7405209823149 189.37 35.669511398315215 139.7405594635153 189.37 35.66949040726679 139.74056197318416 189.37 35.66949341995982 139.74059981376473 189.37 35.66947719673663 139.7406017545554 189.37 35.66949221450195 139.74079037207056 189.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1a608e53-9f1b-4ea3-8743-f0fdab3e36e2"/>
							<gml:surfaceMember xlink:href="#poly-4b812c34-3edb-443a-a2b7-95876606aa38"/>
							<gml:surfaceMember xlink:href="#poly-0c719723-0cc1-4eb6-a4eb-c9238f949e2f"/>
							<gml:surfaceMember xlink:href="#poly-74794b2c-8bea-4463-819e-61e28f1bd06a"/>
							<gml:surfaceMember xlink:href="#poly-a8833880-daa4-4b6b-a0d3-db7d20cb23d5"/>
							<gml:surfaceMember xlink:href="#poly-61ecc7a8-a0b7-4fb9-b642-d69b820a8dd3"/>
							<gml:surfaceMember xlink:href="#poly-a47df8d0-cd9f-47b2-bfc0-60999b7b68ed"/>
							<gml:surfaceMember xlink:href="#poly-1e03478b-a968-4abd-b7c2-e242f6982eff"/>
							<gml:surfaceMember xlink:href="#poly-b54deeba-41a4-4b61-9cea-b88bd1c25dad"/>
							<gml:surfaceMember xlink:href="#poly-37b7cf74-4450-45da-ba88-70f65c353523"/>
							<gml:surfaceMember xlink:href="#poly-55da1436-eb7f-4992-9934-7471b58a091b"/>
							<gml:surfaceMember xlink:href="#poly-22cc92b0-6f7e-4e4c-8ca0-4199a2ad931c"/>
							<gml:surfaceMember xlink:href="#poly-17153b07-86da-4b01-80c6-96a8716a84ff"/>
							<gml:surfaceMember xlink:href="#poly-bf6ec914-96ac-4f27-9ab6-4e57594fac5c"/>
							<gml:surfaceMember xlink:href="#poly-7f892476-abb8-4833-8411-0facd4479ec2"/>
							<gml:surfaceMember xlink:href="#poly-bdbc6419-d979-4965-a138-3f61168e9b1e"/>
							<gml:surfaceMember xlink:href="#poly-8759db05-8d38-455b-9787-f07a54f6633d"/>
							<gml:surfaceMember xlink:href="#poly-78672676-6ead-4790-b363-1a9966dd3606"/>
							<gml:surfaceMember xlink:href="#poly-9dd8b353-ee3e-44df-9610-d1c937a1d6d1"/>
							<gml:surfaceMember xlink:href="#poly-f4827e7c-48f7-412a-b4e3-9408b8131315"/>
							<gml:surfaceMember xlink:href="#poly-eb94c5fa-e604-422c-a8e6-8f2848c84781"/>
							<gml:surfaceMember xlink:href="#poly-c1b939b8-6a6a-4394-8ebd-9ac660ace8b2"/>
							<gml:surfaceMember xlink:href="#poly-06df7c7e-e55f-4596-97a1-48239dec85e1"/>
							<gml:surfaceMember xlink:href="#poly-41754045-784e-45a2-a36b-5dc9ff49bd8a"/>
							<gml:surfaceMember xlink:href="#poly-392f5668-cdb9-4282-bbcc-2002ca0a3fc1"/>
							<gml:surfaceMember xlink:href="#poly-8dd6c30d-ce6b-4465-979d-bd4ddcd498ad"/>
							<gml:surfaceMember xlink:href="#poly-411ed526-a7b3-4717-a211-54470403dcf3"/>
							<gml:surfaceMember xlink:href="#poly-11f6ec1c-c652-44cd-b783-10091bb783b5"/>
							<gml:surfaceMember xlink:href="#poly-ccbbe64f-344c-4f72-a4ae-de1835398b78"/>
							<gml:surfaceMember xlink:href="#poly-817c3e84-8b7b-40fd-920b-ab5f13607a6d"/>
							<gml:surfaceMember xlink:href="#poly-16f1f44e-8321-4f2d-9127-31d7767b6a9a"/>
							<gml:surfaceMember xlink:href="#poly-037d67be-b81a-4b97-9cd1-7d22eb3f01b9"/>
							<gml:surfaceMember xlink:href="#poly-87feb44b-6a86-4af2-9ee3-d9acb351c6da"/>
							<gml:surfaceMember xlink:href="#poly-f2bab77b-21de-4421-8806-8c085a962db9"/>
							<gml:surfaceMember xlink:href="#poly-3b4e8d8e-a9a7-4519-9edb-ee3e9990c2e8"/>
							<gml:surfaceMember xlink:href="#poly-fe13264f-ca19-41da-b39a-37b261dca01e"/>
							<gml:surfaceMember xlink:href="#poly-cbce8ede-c37d-4530-a339-bbdaa60347a5"/>
							<gml:surfaceMember xlink:href="#poly-64d1fbb6-57aa-429b-8b47-7e5af930dd9d"/>
							<gml:surfaceMember xlink:href="#poly-5a753f3c-7ac5-4640-a6d7-25730426d79a"/>
							<gml:surfaceMember xlink:href="#poly-8dd61b1d-f384-4f0c-bbe1-eef90f998291"/>
							<gml:surfaceMember xlink:href="#poly-0900dce7-9136-4bb3-8f34-c75b3d5cded6"/>
							<gml:surfaceMember xlink:href="#poly-8b2f5a18-86c7-48f6-9155-0357b053f58e"/>
							<gml:surfaceMember xlink:href="#poly-69348154-d1ab-4fda-a37e-01085ced2c63"/>
							<gml:surfaceMember xlink:href="#poly-91de2125-5c6d-453a-ba13-58f28fc8c324"/>
							<gml:surfaceMember xlink:href="#poly-4d76b19f-7a9b-4037-8c9e-e54afec9551a"/>
							<gml:surfaceMember xlink:href="#poly-711ebc35-4378-4b65-beba-538ba63b0245"/>
							<gml:surfaceMember xlink:href="#poly-fa4a1fda-0b74-45f0-be4a-fb1fb7bc4b0f"/>
							<gml:surfaceMember xlink:href="#poly-962dee94-3a30-4f09-a698-7db43ea5b836"/>
							<gml:surfaceMember xlink:href="#poly-ccad7894-17d5-4681-8458-bae7cc7c3c15"/>
							<gml:surfaceMember xlink:href="#poly-a6f405d8-6e85-44ae-b346-d2af3729609e"/>
							<gml:surfaceMember xlink:href="#poly-72863676-32eb-45fc-9f49-4e85f8fc304a"/>
							<gml:surfaceMember xlink:href="#poly-7263f97f-194a-4dcc-b3d8-08a2d32b5cf8"/>
							<gml:surfaceMember xlink:href="#poly-599473a2-e45b-4dd7-965f-382b863c02f9"/>
							<gml:surfaceMember xlink:href="#poly-632ddeb4-bbf0-4532-9d48-646f1caf7865"/>
							<gml:surfaceMember xlink:href="#poly-bd838c55-0d0b-4d9c-869f-321e2de7c142"/>
							<gml:surfaceMember xlink:href="#poly-96adcd1e-7490-46a7-a517-24b1e7b03f58"/>
							<gml:surfaceMember xlink:href="#poly-530ad74e-d8df-4714-81f5-f54ab514ad53"/>
							<gml:surfaceMember xlink:href="#poly-2c3461a0-15d8-4b28-be2b-765010cc7799"/>
							<gml:surfaceMember xlink:href="#poly-21b094d4-a778-477d-a472-40ee8584c4ac"/>
							<gml:surfaceMember xlink:href="#poly-e555fb2a-5316-4749-9022-696054d5422d"/>
							<gml:surfaceMember xlink:href="#poly-26086ea2-5a40-4ba7-b85d-48bf4e46f168"/>
							<gml:surfaceMember xlink:href="#poly-ecb28fe0-6109-49af-9407-f1dcb9b238f0"/>
							<gml:surfaceMember xlink:href="#poly-dc2ca75b-cf3d-4b59-b424-bb5d63ea5cc0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1a608e53-9f1b-4ea3-8743-f0fdab3e36e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a608e53-9f1b-4ea3-8743-f0fdab3e36e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a608e53-9f1b-4ea3-8743-f0fdab3e36e2">
											<gml:posList>35.67017673555125 139.74068519510422 9.22 35.670178574118296 139.74070832378888 9.22 35.66949221450191 139.74079037207056 9.22 35.66947719673663 139.7406017545554 9.22 35.6694934199598 139.7405998137647 9.22 35.66949040726675 139.74056197318416 9.22 35.669511398315194 139.7405594635153 9.22 35.669508331033306 139.7405209823149 9.22 35.66948831338273 139.74052338040565 9.22 35.66948601974225 139.74049460787563 9.22 35.66946594800978 139.7404970060349 9.22 35.66941690545139 139.73988090987092 9.22 35.669789074947936 139.73983642393557 9.22 35.66979105930377 139.73986136389203 9.22 35.66978444383956 139.73986215588286 9.22 35.6697858365201 139.73987965140446 9.22 35.66981383057309 139.7398763049213 9.22 35.66984388637339 139.74025388374008 9.22 35.670177111249124 139.7402140508057 9.22 35.670214256263485 139.74068071116082 9.22 35.67017673555125 139.74068519510422 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b812c34-3edb-443a-a2b7-95876606aa38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b812c34-3edb-443a-a2b7-95876606aa38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b812c34-3edb-443a-a2b7-95876606aa38">
											<gml:posList>35.66979105930377 139.73986136389203 195.988 35.669789074947936 139.73983642393557 195.988 35.6697723577755 139.73985228364532 195.988 35.66978444383956 139.73986215588286 195.988 35.66979105930377 139.73986136389203 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c719723-0cc1-4eb6-a4eb-c9238f949e2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c719723-0cc1-4eb6-a4eb-c9238f949e2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c719723-0cc1-4eb6-a4eb-c9238f949e2f">
											<gml:posList>35.66941690545139 139.73988090987092 195.988 35.66942920078376 139.73989330034252 195.988 35.6697723577755 139.73985228364532 195.988 35.669789074947936 139.73983642393557 195.988 35.66941690545139 139.73988090987092 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74794b2c-8bea-4463-819e-61e28f1bd06a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74794b2c-8bea-4463-819e-61e28f1bd06a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74794b2c-8bea-4463-819e-61e28f1bd06a">
											<gml:posList>35.6697858365201 139.73987965140446 195.988 35.66978444383956 139.73986215588286 195.988 35.6697723577755 139.73985228364532 195.988 35.6697757348064 139.73989471911665 195.988 35.6697858365201 139.73987965140446 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a8833880-daa4-4b6b-a0d3-db7d20cb23d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8833880-daa4-4b6b-a0d3-db7d20cb23d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8833880-daa4-4b6b-a0d3-db7d20cb23d5">
											<gml:posList>35.66980372885986 139.73989137263916 180.377 35.66981383057309 139.7398763049213 180.377 35.6697858365201 139.73987965140446 180.377 35.66978692882231 139.73989338053013 180.377 35.66980372885986 139.73989137263916 180.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61ecc7a8-a0b7-4fb9-b642-d69b820a8dd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61ecc7a8-a0b7-4fb9-b642-d69b820a8dd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61ecc7a8-a0b7-4fb9-b642-d69b820a8dd3">
											<gml:posList>35.6697858365201 139.73987965140446 195.988 35.6697757348064 139.73989471911665 195.988 35.66978692882231 139.73989338053013 195.988 35.6697858365201 139.73987965140446 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a47df8d0-cd9f-47b2-bfc0-60999b7b68ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a47df8d0-cd9f-47b2-bfc0-60999b7b68ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a47df8d0-cd9f-47b2-bfc0-60999b7b68ed">
											<gml:posList>35.66984388637339 139.74025388374008 181.542 35.66981383057309 139.7398763049213 181.542 35.66980372885986 139.73989137263916 181.542 35.669833784612905 139.74026895141614 181.542 35.66984388637339 139.74025388374008 181.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e03478b-a968-4abd-b7c2-e242f6982eff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e03478b-a968-4abd-b7c2-e242f6982eff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e03478b-a968-4abd-b7c2-e242f6982eff">
											<gml:posList>35.66978692882231 139.73989338053013 180.377 35.6697757348064 139.73989471911665 180.377 35.669795568826906 139.74014389779762 180.377 35.66980800241067 139.7403001536633 180.377 35.669894553276556 139.74028980237014 180.377 35.67016922135757 139.74025696352774 180.377 35.67016700949428 139.74022911854948 180.377 35.669833784612905 139.74026895141614 180.377 35.66980372885986 139.73989137263916 180.377 35.66978692882231 139.73989338053013 180.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b54deeba-41a4-4b61-9cea-b88bd1c25dad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b54deeba-41a4-4b61-9cea-b88bd1c25dad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b54deeba-41a4-4b61-9cea-b88bd1c25dad">
											<gml:posList>35.66946594800978 139.7404970060349 195.988 35.669476058821814 139.74048194949242 195.988 35.66942920078376 139.73989330034252 195.988 35.66941690545139 139.73988090987092 195.988 35.66946594800978 139.7404970060349 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37b7cf74-4450-45da-ba88-70f65c353523">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37b7cf74-4450-45da-ba88-70f65c353523">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37b7cf74-4450-45da-ba88-70f65c353523">
											<gml:posList>35.67018042439058 139.74025562497468 181.542 35.670177111249124 139.7402140508057 181.542 35.67016700949428 139.74022911854948 181.542 35.67016922135757 139.74025696352774 181.542 35.67018042439058 139.74025562497468 181.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-55da1436-eb7f-4992-9934-7471b58a091b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55da1436-eb7f-4992-9934-7471b58a091b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55da1436-eb7f-4992-9934-7471b58a091b">
											<gml:posList>35.66984388637339 139.74025388374008 181.542 35.669833784612905 139.74026895141614 181.542 35.67016700949428 139.74022911854948 181.542 35.670177111249124 139.7402140508057 181.542 35.66984388637339 139.74025388374008 181.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22cc92b0-6f7e-4e4c-8ca0-4199a2ad931c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22cc92b0-6f7e-4e4c-8ca0-4199a2ad931c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22cc92b0-6f7e-4e4c-8ca0-4199a2ad931c">
											<gml:posList>35.66980800241067 139.7403001536633 181.542 35.669795568826906 139.74014389779762 181.542 35.669755497487984 139.74014869422558 181.542 35.669771708421784 139.74035241104778 181.542 35.6698983306474 139.7403372745244 181.542 35.669894553276556 139.74028980237014 181.542 35.66980800241067 139.7403001536633 181.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17153b07-86da-4b01-80c6-96a8716a84ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17153b07-86da-4b01-80c6-96a8716a84ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17153b07-86da-4b01-80c6-96a8716a84ff">
											<gml:posList>35.66952369356922 139.74057184305957 195.988 35.66950270252056 139.74057435272556 195.988 35.66950571520972 139.7406121933124 195.988 35.6694894919864 139.7406141341009 195.988 35.669502325350635 139.74077531556006 195.988 35.67016628789318 139.74069594411236 195.988 35.67016444932376 139.74067281543154 195.988 35.67020197003559 139.74066833148305 195.988 35.67016922135757 139.74025696352774 195.988 35.669894553276556 139.74028980237014 195.988 35.66990973547292 139.74048061881027 195.988 35.66969154215935 139.74050670847072 195.988 35.6696639174276 139.74015963694353 195.988 35.669795568826906 139.74014389779762 195.988 35.6697757348064 139.73989471911665 195.988 35.6697723577755 139.73985228364532 195.988 35.66942920078376 139.73989330034252 195.988 35.669476058821814 139.74048194949242 195.988 35.66949613055394 139.7404795513291 195.988 35.66949842419802 139.7405083238623 195.988 35.66951844184826 139.74050592576748 195.988 35.66952369356922 139.74057184305957 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bf6ec914-96ac-4f27-9ab6-4e57594fac5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf6ec914-96ac-4f27-9ab6-4e57594fac5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf6ec914-96ac-4f27-9ab6-4e57594fac5c">
											<gml:posList>35.66969154215935 139.74050670847072 186.688 35.66990973547292 139.74048061881027 186.688 35.6698983306474 139.7403372745244 186.688 35.669771708421784 139.74035241104778 186.688 35.669755497487984 139.74014869422558 186.688 35.6696639174276 139.74015963694353 186.688 35.66969154215935 139.74050670847072 186.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f892476-abb8-4833-8411-0facd4479ec2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f892476-abb8-4833-8411-0facd4479ec2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f892476-abb8-4833-8411-0facd4479ec2">
											<gml:posList>35.67020197003559 139.74066833148305 195.988 35.670214256263485 139.74068071116082 195.988 35.67018042439058 139.74025562497468 195.988 35.67016922135757 139.74025696352774 195.988 35.67020197003559 139.74066833148305 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdbc6419-d979-4965-a138-3f61168e9b1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdbc6419-d979-4965-a138-3f61168e9b1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdbc6419-d979-4965-a138-3f61168e9b1e">
											<gml:posList>35.66948601974225 139.74049460787563 195.988 35.66949613055394 139.7404795513291 195.988 35.669476058821814 139.74048194949242 195.988 35.66946594800978 139.7404970060349 195.988 35.66948601974225 139.74049460787563 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8759db05-8d38-455b-9787-f07a54f6633d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8759db05-8d38-455b-9787-f07a54f6633d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8759db05-8d38-455b-9787-f07a54f6633d">
											<gml:posList>35.66948601974225 139.74049460787563 195.988 35.66948831338273 139.74052338040565 195.988 35.66949842419802 139.7405083238623 195.988 35.66949613055394 139.7404795513291 195.988 35.66948601974225 139.74049460787563 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78672676-6ead-4790-b363-1a9966dd3606">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78672676-6ead-4790-b363-1a9966dd3606">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78672676-6ead-4790-b363-1a9966dd3606">
											<gml:posList>35.669508331033306 139.7405209823149 195.988 35.66951844184826 139.74050592576748 195.988 35.66949842419802 139.7405083238623 195.988 35.66948831338273 139.74052338040565 195.988 35.669508331033306 139.7405209823149 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9dd8b353-ee3e-44df-9610-d1c937a1d6d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dd8b353-ee3e-44df-9610-d1c937a1d6d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dd8b353-ee3e-44df-9610-d1c937a1d6d1">
											<gml:posList>35.669511398315194 139.7405594635153 195.988 35.66952369356922 139.74057184305957 195.988 35.66951844184826 139.74050592576748 195.988 35.669508331033306 139.7405209823149 195.988 35.669511398315194 139.7405594635153 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4827e7c-48f7-412a-b4e3-9408b8131315">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4827e7c-48f7-412a-b4e3-9408b8131315">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4827e7c-48f7-412a-b4e3-9408b8131315">
											<gml:posList>35.669511398315194 139.7405594635153 195.988 35.66949040726675 139.74056197318416 195.988 35.66950270252056 139.74057435272556 195.988 35.66952369356922 139.74057184305957 195.988 35.669511398315194 139.7405594635153 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eb94c5fa-e604-422c-a8e6-8f2848c84781">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb94c5fa-e604-422c-a8e6-8f2848c84781">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb94c5fa-e604-422c-a8e6-8f2848c84781">
											<gml:posList>35.6694934199598 139.7405998137647 195.988 35.66950571520972 139.7406121933124 195.988 35.66950270252056 139.74057435272556 195.988 35.66949040726675 139.74056197318416 195.988 35.6694934199598 139.7405998137647 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1b939b8-6a6a-4394-8ebd-9ac660ace8b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1b939b8-6a6a-4394-8ebd-9ac660ace8b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1b939b8-6a6a-4394-8ebd-9ac660ace8b2">
											<gml:posList>35.6694934199598 139.7405998137647 195.988 35.66947719673663 139.7406017545554 195.988 35.6694894919864 139.7406141341009 195.988 35.66950571520972 139.7406121933124 195.988 35.6694934199598 139.7405998137647 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06df7c7e-e55f-4596-97a1-48239dec85e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06df7c7e-e55f-4596-97a1-48239dec85e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06df7c7e-e55f-4596-97a1-48239dec85e1">
											<gml:posList>35.67017673555125 139.74068519510422 195.988 35.670214256263485 139.74068071116082 195.988 35.67020197003559 139.74066833148305 195.988 35.67016444932376 139.74067281543154 195.988 35.67017673555125 139.74068519510422 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41754045-784e-45a2-a36b-5dc9ff49bd8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41754045-784e-45a2-a36b-5dc9ff49bd8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41754045-784e-45a2-a36b-5dc9ff49bd8a">
											<gml:posList>35.67017673555125 139.74068519510422 195.988 35.67016444932376 139.74067281543154 195.988 35.67016628789318 139.74069594411236 195.988 35.670178574118296 139.74070832378888 195.988 35.67017673555125 139.74068519510422 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-392f5668-cdb9-4282-bbcc-2002ca0a3fc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-392f5668-cdb9-4282-bbcc-2002ca0a3fc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-392f5668-cdb9-4282-bbcc-2002ca0a3fc1">
											<gml:posList>35.66949221450191 139.74079037207056 195.988 35.669502325350635 139.74077531556006 195.988 35.6694894919864 139.7406141341009 195.988 35.66947719673663 139.7406017545554 195.988 35.66949221450191 139.74079037207056 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8dd6c30d-ce6b-4465-979d-bd4ddcd498ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dd6c30d-ce6b-4465-979d-bd4ddcd498ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dd6c30d-ce6b-4465-979d-bd4ddcd498ad">
											<gml:posList>35.670178574118296 139.74070832378888 195.988 35.67016628789318 139.74069594411236 195.988 35.669502325350635 139.74077531556006 195.988 35.66949221450191 139.74079037207056 195.988 35.670178574118296 139.74070832378888 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-411ed526-a7b3-4717-a211-54470403dcf3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-411ed526-a7b3-4717-a211-54470403dcf3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-411ed526-a7b3-4717-a211-54470403dcf3">
											<gml:posList>35.66969154215935 139.74050670847072 195.988 35.66969154215935 139.74050670847072 186.688 35.6696639174276 139.74015963694353 186.688 35.6696639174276 139.74015963694353 195.988 35.66969154215935 139.74050670847072 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11f6ec1c-c652-44cd-b783-10091bb783b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11f6ec1c-c652-44cd-b783-10091bb783b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11f6ec1c-c652-44cd-b783-10091bb783b5">
											<gml:posList>35.669755497487984 139.74014869422558 186.688 35.669755497487984 139.74014869422558 181.542 35.669795568826906 139.74014389779762 181.542 35.669795568826906 139.74014389779762 195.988 35.6696639174276 139.74015963694353 195.988 35.6696639174276 139.74015963694353 186.688 35.669755497487984 139.74014869422558 186.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccbbe64f-344c-4f72-a4ae-de1835398b78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccbbe64f-344c-4f72-a4ae-de1835398b78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccbbe64f-344c-4f72-a4ae-de1835398b78">
											<gml:posList>35.669771708421784 139.74035241104778 186.688 35.669771708421784 139.74035241104778 181.542 35.669755497487984 139.74014869422558 181.542 35.669755497487984 139.74014869422558 186.688 35.669771708421784 139.74035241104778 186.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-817c3e84-8b7b-40fd-920b-ab5f13607a6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-817c3e84-8b7b-40fd-920b-ab5f13607a6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-817c3e84-8b7b-40fd-920b-ab5f13607a6d">
											<gml:posList>35.66978692882231 139.73989338053013 180.377 35.66978692882231 139.73989338053013 195.988 35.6697757348064 139.73989471911665 195.988 35.6697757348064 139.73989471911665 180.377 35.66978692882231 139.73989338053013 180.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16f1f44e-8321-4f2d-9127-31d7767b6a9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16f1f44e-8321-4f2d-9127-31d7767b6a9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16f1f44e-8321-4f2d-9127-31d7767b6a9a">
											<gml:posList>35.66978444383956 139.73986215588286 9.22 35.66978444383956 139.73986215588286 195.988 35.6697858365201 139.73987965140446 195.988 35.6697858365201 139.73987965140446 180.377 35.6697858365201 139.73987965140446 9.22 35.66978444383956 139.73986215588286 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-037d67be-b81a-4b97-9cd1-7d22eb3f01b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-037d67be-b81a-4b97-9cd1-7d22eb3f01b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-037d67be-b81a-4b97-9cd1-7d22eb3f01b9">
											<gml:posList>35.6697757348064 139.73989471911665 180.377 35.6697757348064 139.73989471911665 195.988 35.669795568826906 139.74014389779762 195.988 35.669795568826906 139.74014389779762 181.542 35.669795568826906 139.74014389779762 180.377 35.6697757348064 139.73989471911665 180.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87feb44b-6a86-4af2-9ee3-d9acb351c6da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87feb44b-6a86-4af2-9ee3-d9acb351c6da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87feb44b-6a86-4af2-9ee3-d9acb351c6da">
											<gml:posList>35.66978692882231 139.73989338053013 195.988 35.66978692882231 139.73989338053013 180.377 35.6697858365201 139.73987965140446 180.377 35.6697858365201 139.73987965140446 195.988 35.66978692882231 139.73989338053013 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2bab77b-21de-4421-8806-8c085a962db9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2bab77b-21de-4421-8806-8c085a962db9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2bab77b-21de-4421-8806-8c085a962db9">
											<gml:posList>35.66978444383956 139.73986215588286 9.22 35.66979105930377 139.73986136389203 9.22 35.66979105930377 139.73986136389203 195.988 35.66978444383956 139.73986215588286 195.988 35.66978444383956 139.73986215588286 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b4e8d8e-a9a7-4519-9edb-ee3e9990c2e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b4e8d8e-a9a7-4519-9edb-ee3e9990c2e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b4e8d8e-a9a7-4519-9edb-ee3e9990c2e8">
											<gml:posList>35.66979105930377 139.73986136389203 9.22 35.669789074947936 139.73983642393557 9.22 35.669789074947936 139.73983642393557 195.988 35.66979105930377 139.73986136389203 195.988 35.66979105930377 139.73986136389203 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe13264f-ca19-41da-b39a-37b261dca01e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe13264f-ca19-41da-b39a-37b261dca01e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe13264f-ca19-41da-b39a-37b261dca01e">
											<gml:posList>35.6697858365201 139.73987965140446 180.377 35.66981383057309 139.7398763049213 180.377 35.66981383057309 139.7398763049213 9.22 35.6697858365201 139.73987965140446 9.22 35.6697858365201 139.73987965140446 180.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbce8ede-c37d-4530-a339-bbdaa60347a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbce8ede-c37d-4530-a339-bbdaa60347a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbce8ede-c37d-4530-a339-bbdaa60347a5">
											<gml:posList>35.66990973547292 139.74048061881027 195.988 35.66990973547292 139.74048061881027 186.688 35.66969154215935 139.74050670847072 186.688 35.66969154215935 139.74050670847072 195.988 35.66990973547292 139.74048061881027 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64d1fbb6-57aa-429b-8b47-7e5af930dd9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64d1fbb6-57aa-429b-8b47-7e5af930dd9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64d1fbb6-57aa-429b-8b47-7e5af930dd9d">
											<gml:posList>35.66980800241067 139.7403001536633 180.377 35.669795568826906 139.74014389779762 180.377 35.669795568826906 139.74014389779762 181.542 35.66980800241067 139.7403001536633 181.542 35.66980800241067 139.7403001536633 180.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a753f3c-7ac5-4640-a6d7-25730426d79a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a753f3c-7ac5-4640-a6d7-25730426d79a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a753f3c-7ac5-4640-a6d7-25730426d79a">
											<gml:posList>35.66980372885986 139.73989137263916 180.377 35.66980372885986 139.73989137263916 181.542 35.66981383057309 139.7398763049213 181.542 35.66981383057309 139.7398763049213 180.377 35.66980372885986 139.73989137263916 180.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8dd61b1d-f384-4f0c-bbe1-eef90f998291">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dd61b1d-f384-4f0c-bbe1-eef90f998291">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dd61b1d-f384-4f0c-bbe1-eef90f998291">
											<gml:posList>35.669833784612905 139.74026895141614 181.542 35.66980372885986 139.73989137263916 181.542 35.66980372885986 139.73989137263916 180.377 35.669833784612905 139.74026895141614 180.377 35.669833784612905 139.74026895141614 181.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0900dce7-9136-4bb3-8f34-c75b3d5cded6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0900dce7-9136-4bb3-8f34-c75b3d5cded6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0900dce7-9136-4bb3-8f34-c75b3d5cded6">
											<gml:posList>35.66984388637339 139.74025388374008 181.542 35.66984388637339 139.74025388374008 9.22 35.66981383057309 139.7398763049213 9.22 35.66981383057309 139.7398763049213 180.377 35.66981383057309 139.7398763049213 181.542 35.66984388637339 139.74025388374008 181.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b2f5a18-86c7-48f6-9155-0357b053f58e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b2f5a18-86c7-48f6-9155-0357b053f58e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b2f5a18-86c7-48f6-9155-0357b053f58e">
											<gml:posList>35.6698983306474 139.7403372745244 186.688 35.6698983306474 139.7403372745244 181.542 35.669771708421784 139.74035241104778 181.542 35.669771708421784 139.74035241104778 186.688 35.6698983306474 139.7403372745244 186.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69348154-d1ab-4fda-a37e-01085ced2c63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69348154-d1ab-4fda-a37e-01085ced2c63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69348154-d1ab-4fda-a37e-01085ced2c63">
											<gml:posList>35.669894553276556 139.74028980237014 181.542 35.669894553276556 139.74028980237014 180.377 35.66980800241067 139.7403001536633 180.377 35.66980800241067 139.7403001536633 181.542 35.669894553276556 139.74028980237014 181.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91de2125-5c6d-453a-ba13-58f28fc8c324">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91de2125-5c6d-453a-ba13-58f28fc8c324">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91de2125-5c6d-453a-ba13-58f28fc8c324">
											<gml:posList>35.669894553276556 139.74028980237014 195.988 35.669894553276556 139.74028980237014 181.542 35.6698983306474 139.7403372745244 181.542 35.6698983306474 139.7403372745244 186.688 35.66990973547292 139.74048061881027 186.688 35.66990973547292 139.74048061881027 195.988 35.669894553276556 139.74028980237014 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d76b19f-7a9b-4037-8c9e-e54afec9551a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d76b19f-7a9b-4037-8c9e-e54afec9551a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d76b19f-7a9b-4037-8c9e-e54afec9551a">
											<gml:posList>35.67016700949428 139.74022911854948 180.377 35.67016700949428 139.74022911854948 181.542 35.669833784612905 139.74026895141614 181.542 35.669833784612905 139.74026895141614 180.377 35.67016700949428 139.74022911854948 180.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-711ebc35-4378-4b65-beba-538ba63b0245">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-711ebc35-4378-4b65-beba-538ba63b0245">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-711ebc35-4378-4b65-beba-538ba63b0245">
											<gml:posList>35.66984388637339 139.74025388374008 181.542 35.670177111249124 139.7402140508057 181.542 35.670177111249124 139.7402140508057 9.22 35.66984388637339 139.74025388374008 9.22 35.66984388637339 139.74025388374008 181.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa4a1fda-0b74-45f0-be4a-fb1fb7bc4b0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa4a1fda-0b74-45f0-be4a-fb1fb7bc4b0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa4a1fda-0b74-45f0-be4a-fb1fb7bc4b0f">
											<gml:posList>35.669894553276556 139.74028980237014 181.542 35.669894553276556 139.74028980237014 195.988 35.67016922135757 139.74025696352774 195.988 35.67016922135757 139.74025696352774 181.542 35.67016922135757 139.74025696352774 180.377 35.669894553276556 139.74028980237014 180.377 35.669894553276556 139.74028980237014 181.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-962dee94-3a30-4f09-a698-7db43ea5b836">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-962dee94-3a30-4f09-a698-7db43ea5b836">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-962dee94-3a30-4f09-a698-7db43ea5b836">
											<gml:posList>35.67016922135757 139.74025696352774 181.542 35.67016700949428 139.74022911854948 181.542 35.67016700949428 139.74022911854948 180.377 35.67016922135757 139.74025696352774 180.377 35.67016922135757 139.74025696352774 181.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccad7894-17d5-4681-8458-bae7cc7c3c15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccad7894-17d5-4681-8458-bae7cc7c3c15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccad7894-17d5-4681-8458-bae7cc7c3c15">
											<gml:posList>35.67018042439058 139.74025562497468 195.988 35.67018042439058 139.74025562497468 181.542 35.67016922135757 139.74025696352774 181.542 35.67016922135757 139.74025696352774 195.988 35.67018042439058 139.74025562497468 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6f405d8-6e85-44ae-b346-d2af3729609e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6f405d8-6e85-44ae-b346-d2af3729609e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6f405d8-6e85-44ae-b346-d2af3729609e">
											<gml:posList>35.670178574118296 139.74070832378888 9.22 35.67017673555125 139.74068519510422 9.22 35.67017673555125 139.74068519510422 195.988 35.670178574118296 139.74070832378888 195.988 35.670178574118296 139.74070832378888 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72863676-32eb-45fc-9f49-4e85f8fc304a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72863676-32eb-45fc-9f49-4e85f8fc304a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72863676-32eb-45fc-9f49-4e85f8fc304a">
											<gml:posList>35.67017673555125 139.74068519510422 9.22 35.670214256263485 139.74068071116082 9.22 35.670214256263485 139.74068071116082 195.988 35.67017673555125 139.74068519510422 195.988 35.67017673555125 139.74068519510422 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7263f97f-194a-4dcc-b3d8-08a2d32b5cf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7263f97f-194a-4dcc-b3d8-08a2d32b5cf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7263f97f-194a-4dcc-b3d8-08a2d32b5cf8">
											<gml:posList>35.670214256263485 139.74068071116082 195.988 35.670214256263485 139.74068071116082 9.22 35.670177111249124 139.7402140508057 9.22 35.670177111249124 139.7402140508057 181.542 35.67018042439058 139.74025562497468 181.542 35.67018042439058 139.74025562497468 195.988 35.670214256263485 139.74068071116082 195.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-599473a2-e45b-4dd7-965f-382b863c02f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-599473a2-e45b-4dd7-965f-382b863c02f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-599473a2-e45b-4dd7-965f-382b863c02f9">
											<gml:posList>35.66949221450191 139.74079037207056 9.22 35.670178574118296 139.74070832378888 9.22 35.670178574118296 139.74070832378888 195.988 35.66949221450191 139.74079037207056 195.988 35.66949221450191 139.74079037207056 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-632ddeb4-bbf0-4532-9d48-646f1caf7865">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-632ddeb4-bbf0-4532-9d48-646f1caf7865">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-632ddeb4-bbf0-4532-9d48-646f1caf7865">
											<gml:posList>35.669789074947936 139.73983642393557 9.22 35.66941690545139 139.73988090987092 9.22 35.66941690545139 139.73988090987092 195.988 35.669789074947936 139.73983642393557 195.988 35.669789074947936 139.73983642393557 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd838c55-0d0b-4d9c-869f-321e2de7c142">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd838c55-0d0b-4d9c-869f-321e2de7c142">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd838c55-0d0b-4d9c-869f-321e2de7c142">
											<gml:posList>35.66941690545139 139.73988090987092 9.22 35.66946594800978 139.7404970060349 9.22 35.66946594800978 139.7404970060349 195.988 35.66941690545139 139.73988090987092 195.988 35.66941690545139 139.73988090987092 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96adcd1e-7490-46a7-a517-24b1e7b03f58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96adcd1e-7490-46a7-a517-24b1e7b03f58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96adcd1e-7490-46a7-a517-24b1e7b03f58">
											<gml:posList>35.66946594800978 139.7404970060349 9.22 35.66948601974225 139.74049460787563 9.22 35.66948601974225 139.74049460787563 195.988 35.66946594800978 139.7404970060349 195.988 35.66946594800978 139.7404970060349 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-530ad74e-d8df-4714-81f5-f54ab514ad53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-530ad74e-d8df-4714-81f5-f54ab514ad53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-530ad74e-d8df-4714-81f5-f54ab514ad53">
											<gml:posList>35.66948601974225 139.74049460787563 9.22 35.66948831338273 139.74052338040565 9.22 35.66948831338273 139.74052338040565 195.988 35.66948601974225 139.74049460787563 195.988 35.66948601974225 139.74049460787563 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c3461a0-15d8-4b28-be2b-765010cc7799">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c3461a0-15d8-4b28-be2b-765010cc7799">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c3461a0-15d8-4b28-be2b-765010cc7799">
											<gml:posList>35.66948831338273 139.74052338040565 9.22 35.669508331033306 139.7405209823149 9.22 35.669508331033306 139.7405209823149 195.988 35.66948831338273 139.74052338040565 195.988 35.66948831338273 139.74052338040565 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21b094d4-a778-477d-a472-40ee8584c4ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21b094d4-a778-477d-a472-40ee8584c4ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21b094d4-a778-477d-a472-40ee8584c4ac">
											<gml:posList>35.669508331033306 139.7405209823149 9.22 35.669511398315194 139.7405594635153 9.22 35.669511398315194 139.7405594635153 195.988 35.669508331033306 139.7405209823149 195.988 35.669508331033306 139.7405209823149 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e555fb2a-5316-4749-9022-696054d5422d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e555fb2a-5316-4749-9022-696054d5422d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e555fb2a-5316-4749-9022-696054d5422d">
											<gml:posList>35.669511398315194 139.7405594635153 9.22 35.66949040726675 139.74056197318416 9.22 35.66949040726675 139.74056197318416 195.988 35.669511398315194 139.7405594635153 195.988 35.669511398315194 139.7405594635153 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26086ea2-5a40-4ba7-b85d-48bf4e46f168">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26086ea2-5a40-4ba7-b85d-48bf4e46f168">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26086ea2-5a40-4ba7-b85d-48bf4e46f168">
											<gml:posList>35.66949040726675 139.74056197318416 9.22 35.6694934199598 139.7405998137647 9.22 35.6694934199598 139.7405998137647 195.988 35.66949040726675 139.74056197318416 195.988 35.66949040726675 139.74056197318416 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecb28fe0-6109-49af-9407-f1dcb9b238f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecb28fe0-6109-49af-9407-f1dcb9b238f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecb28fe0-6109-49af-9407-f1dcb9b238f0">
											<gml:posList>35.6694934199598 139.7405998137647 9.22 35.66947719673663 139.7406017545554 9.22 35.66947719673663 139.7406017545554 195.988 35.6694934199598 139.7405998137647 195.988 35.6694934199598 139.7405998137647 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc2ca75b-cf3d-4b59-b424-bb5d63ea5cc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc2ca75b-cf3d-4b59-b424-bb5d63ea5cc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc2ca75b-cf3d-4b59-b424-bb5d63ea5cc0">
											<gml:posList>35.66947719673663 139.7406017545554 9.22 35.66949221450191 139.74079037207056 9.22 35.66949221450191 139.74079037207056 195.988 35.66947719673663 139.7406017545554 195.988 35.66947719673663 139.7406017545554 9.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10859</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>