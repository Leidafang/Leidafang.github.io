<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_df262593-5dbf-4311-841e-484a657cedc8">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">44.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>15</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67279232313305 139.73886605761038 0 35.67277547120931 139.738824884736 0 35.672760752329175 139.7387911216234 0 35.67273545479003 139.73880768819177 0 35.672734118348835 139.7388046188173 0 35.672705766726395 139.73882318840728 0 35.6727868468352 139.73900919474133 0 35.67279254960287 139.73900546533037 0 35.6727958726309 139.73901309461564 0 35.672862395871554 139.73896954797502 0 35.67285903672533 139.7389618414015 0 35.67286358631559 139.7389588534636 0 35.67281635956554 139.73885051986818 0 35.67279232313305 139.73886605761038 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67279232313305 139.73886605761038 7.74 35.67281635956554 139.73885051986818 7.74 35.67286358631559 139.7389588534636 7.74 35.67285903672533 139.7389618414015 7.74 35.672862395871554 139.73896954797502 7.74 35.6727958726309 139.73901309461564 7.74 35.67279254960287 139.73900546533037 7.74 35.6727868468352 139.73900919474133 7.74 35.672705766726395 139.73882318840728 7.74 35.672734118348835 139.7388046188173 7.74 35.67273545479003 139.73880768819177 7.74 35.672760752329175 139.7387911216234 7.74 35.67277547120931 139.738824884736 7.74 35.67279232313305 139.73886605761038 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67279232313305 139.73886605761038 7.74 35.67277547120931 139.738824884736 7.74 35.67277547120931 139.738824884736 51.92 35.67279232313305 139.73886605761038 51.92 35.67279232313305 139.73886605761038 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67277547120931 139.738824884736 7.74 35.672760752329175 139.7387911216234 7.74 35.672760752329175 139.7387911216234 51.92 35.67277547120931 139.738824884736 51.92 35.67277547120931 139.738824884736 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672760752329175 139.7387911216234 7.74 35.67273545479003 139.73880768819177 7.74 35.67273545479003 139.73880768819177 51.92 35.672760752329175 139.7387911216234 51.92 35.672760752329175 139.7387911216234 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67273545479003 139.73880768819177 7.74 35.672734118348835 139.7388046188173 7.74 35.672734118348835 139.7388046188173 51.92 35.67273545479003 139.73880768819177 51.92 35.67273545479003 139.73880768819177 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672734118348835 139.7388046188173 7.74 35.672705766726395 139.73882318840728 7.74 35.672705766726395 139.73882318840728 51.92 35.672734118348835 139.7388046188173 51.92 35.672734118348835 139.7388046188173 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672705766726395 139.73882318840728 7.74 35.6727868468352 139.73900919474133 7.74 35.6727868468352 139.73900919474133 51.92 35.672705766726395 139.73882318840728 51.92 35.672705766726395 139.73882318840728 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6727868468352 139.73900919474133 7.74 35.67279254960287 139.73900546533037 7.74 35.67279254960287 139.73900546533037 51.92 35.6727868468352 139.73900919474133 51.92 35.6727868468352 139.73900919474133 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67279254960287 139.73900546533037 7.74 35.6727958726309 139.73901309461564 7.74 35.6727958726309 139.73901309461564 51.92 35.67279254960287 139.73900546533037 51.92 35.67279254960287 139.73900546533037 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6727958726309 139.73901309461564 7.74 35.672862395871554 139.73896954797502 7.74 35.672862395871554 139.73896954797502 51.92 35.6727958726309 139.73901309461564 51.92 35.6727958726309 139.73901309461564 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672862395871554 139.73896954797502 7.74 35.67285903672533 139.7389618414015 7.74 35.67285903672533 139.7389618414015 51.92 35.672862395871554 139.73896954797502 51.92 35.672862395871554 139.73896954797502 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285903672533 139.7389618414015 7.74 35.67286358631559 139.7389588534636 7.74 35.67286358631559 139.7389588534636 51.92 35.67285903672533 139.7389618414015 51.92 35.67285903672533 139.7389618414015 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286358631559 139.7389588534636 7.74 35.67281635956554 139.73885051986818 7.74 35.67281635956554 139.73885051986818 51.92 35.67286358631559 139.7389588534636 51.92 35.67286358631559 139.7389588534636 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67281635956554 139.73885051986818 7.74 35.67279232313305 139.73886605761038 7.74 35.67279232313305 139.73886605761038 51.92 35.67281635956554 139.73885051986818 51.92 35.67281635956554 139.73885051986818 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67279232313305 139.73886605761038 51.92 35.67277547120931 139.738824884736 51.92 35.672760752329175 139.7387911216234 51.92 35.67273545479003 139.73880768819177 51.92 35.672734118348835 139.7388046188173 51.92 35.672705766726395 139.73882318840728 51.92 35.6727868468352 139.73900919474133 51.92 35.67279254960287 139.73900546533037 51.92 35.6727958726309 139.73901309461564 51.92 35.672862395871554 139.73896954797502 51.92 35.67285903672533 139.7389618414015 51.92 35.67286358631559 139.7389588534636 51.92 35.67281635956554 139.73885051986818 51.92 35.67279232313305 139.73886605761038 51.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-18451b8e-d206-43da-b176-fba7899a0603"/>
							<gml:surfaceMember xlink:href="#poly-c3348440-b3d2-4fda-aed7-805e40600390"/>
							<gml:surfaceMember xlink:href="#poly-6b6c90d2-999c-4ddc-80db-b8c17aa8749a"/>
							<gml:surfaceMember xlink:href="#poly-7b1be310-ea85-4d96-b962-605c96fe13d5"/>
							<gml:surfaceMember xlink:href="#poly-41229e70-dd80-44b4-b07f-fe55f1dd324f"/>
							<gml:surfaceMember xlink:href="#poly-3fc51a1b-5971-4448-8c6d-7ca47d07ba80"/>
							<gml:surfaceMember xlink:href="#poly-9eba5e72-41b6-44c9-b912-f89a43e3731d"/>
							<gml:surfaceMember xlink:href="#poly-07406b8b-1105-407a-9400-65ec84e95f9a"/>
							<gml:surfaceMember xlink:href="#poly-3d184ab0-d328-4127-a9de-791201858d63"/>
							<gml:surfaceMember xlink:href="#poly-3f4025dd-c15d-41d4-bccb-a0a4b31cf806"/>
							<gml:surfaceMember xlink:href="#poly-bab3a8ed-19c5-464f-aeb8-167c6f7f9d82"/>
							<gml:surfaceMember xlink:href="#poly-c5305bc2-5ce2-4859-8483-cd729d019f13"/>
							<gml:surfaceMember xlink:href="#poly-28634481-abcf-4f9c-81d5-6589b1bee1c7"/>
							<gml:surfaceMember xlink:href="#poly-612606d9-f32c-45df-af27-ecba63a2d826"/>
							<gml:surfaceMember xlink:href="#poly-b478beec-1a58-4f68-b6ed-a0ee88d98658"/>
							<gml:surfaceMember xlink:href="#poly-ca72117b-d3f4-490e-bb28-471496a4e2fa"/>
							<gml:surfaceMember xlink:href="#poly-8e1ffe94-dff9-4a5d-a399-51cfe1907c03"/>
							<gml:surfaceMember xlink:href="#poly-78ae3373-0fca-488f-9470-633fee1f72c4"/>
							<gml:surfaceMember xlink:href="#poly-9d1b8a67-5378-4b95-abb0-5f0b5c4c44a5"/>
							<gml:surfaceMember xlink:href="#poly-5e6290bf-116a-43ae-b5ee-b4b26648b533"/>
							<gml:surfaceMember xlink:href="#poly-1b5e918b-1cb4-4cf3-a156-d304f1828cc0"/>
							<gml:surfaceMember xlink:href="#poly-127730e3-7148-44ce-b1fb-d18e4c10278f"/>
							<gml:surfaceMember xlink:href="#poly-0bfc705b-f4a2-4ee1-99b3-4f3c111c939b"/>
							<gml:surfaceMember xlink:href="#poly-b5fa287b-e1f9-4e64-9a4a-1245cf656ce0"/>
							<gml:surfaceMember xlink:href="#poly-2bfff2ee-10f6-46d4-8711-4fd6b01a48b6"/>
							<gml:surfaceMember xlink:href="#poly-8685c1a2-e252-49e1-9d8e-aaae717e6ac9"/>
							<gml:surfaceMember xlink:href="#poly-94ded27b-8d8e-4c51-ba45-02dc9b2a6215"/>
							<gml:surfaceMember xlink:href="#poly-1d77788c-8a10-4d5e-954b-7f6e0dab9b9b"/>
							<gml:surfaceMember xlink:href="#poly-397545bf-c7f1-4352-9a46-5bfb00c85008"/>
							<gml:surfaceMember xlink:href="#poly-711586a9-26d2-4dbe-825d-e579c270c03a"/>
							<gml:surfaceMember xlink:href="#poly-497165cb-e484-45a3-869b-37062dd1fff1"/>
							<gml:surfaceMember xlink:href="#poly-e4822af3-5abe-4f7e-90c8-67e7a29bcaa3"/>
							<gml:surfaceMember xlink:href="#poly-0066bad5-8df7-436b-b7a2-6e1bf78bd5e8"/>
							<gml:surfaceMember xlink:href="#poly-c004292e-bc87-4900-bb11-2b96c4b55be2"/>
							<gml:surfaceMember xlink:href="#poly-1944323b-d04c-48ab-8205-3e9131a16828"/>
							<gml:surfaceMember xlink:href="#poly-345094ad-d72c-4bf7-82de-5bb6bfd676ec"/>
							<gml:surfaceMember xlink:href="#poly-9a27e373-158d-4f66-aacf-04276df6e600"/>
							<gml:surfaceMember xlink:href="#poly-1c271388-e883-4377-8a84-8330c97a86ab"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_df262593-5dbf-4311-841e-484a657cedc8_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6086b25c-052a-4ae9-bbed-af9419bac2fd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67279276867884 139.7388135636817 7.84 35.67281053968502 139.73885432675544 7.84 35.672792323133045 139.73886605761038 7.84 35.6727754712093 139.738824884736 7.84 35.67279276867884 139.7388135636817 7.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbb5cf4b-a0c0-4d47-8720-4c3d9c1a58f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbb5cf4b-a0c0-4d47-8720-4c3d9c1a58f2_0">
											<gml:posList>35.6727754712093 139.738824884736 50.209 35.6727754712093 139.738824884736 7.84 35.672792323133045 139.73886605761038 7.84 35.672792323133045 139.73886605761038 50.209 35.6727754712093 139.738824884736 50.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1af6d2c9-7152-4744-a734-6917da3be3ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1af6d2c9-7152-4744-a734-6917da3be3ab_0">
											<gml:posList>35.67279276867884 139.7388135636817 50.209 35.67279276867884 139.7388135636817 7.84 35.6727754712093 139.738824884736 7.84 35.6727754712093 139.738824884736 50.209 35.67279276867884 139.7388135636817 50.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8dd6276-cc71-47ca-9daa-ac3a5cae0989">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8dd6276-cc71-47ca-9daa-ac3a5cae0989_0">
											<gml:posList>35.6727754712093 139.738824884736 50.209 35.672792323133045 139.73886605761038 50.209 35.67281053968502 139.73885432675544 50.209 35.67279276867884 139.7388135636817 50.209 35.6727754712093 139.738824884736 50.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f7bc9da-b764-4a28-b43a-42cadd503ad5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f7bc9da-b764-4a28-b43a-42cadd503ad5_0">
											<gml:posList>35.672792323133045 139.73886605761038 50.209 35.672792323133045 139.73886605761038 7.84 35.67281053968502 139.73885432675544 7.84 35.67281053968502 139.73885432675544 50.209 35.672792323133045 139.73886605761038 50.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f67e0a1-a252-4215-ac36-93ad657d454a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f67e0a1-a252-4215-ac36-93ad657d454a_0">
											<gml:posList>35.67281053968502 139.73885432675544 50.209 35.67281053968502 139.73885432675544 7.84 35.67279276867884 139.7388135636817 7.84 35.67279276867884 139.7388135636817 50.209 35.67281053968502 139.73885432675544 50.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_df262593-5dbf-4311-841e-484a657cedc8_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e693501-5302-4a5f-a3c7-01feb29f26a0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672801364453896 139.7389127298582 52.062 35.672811157670964 139.73890673107016 52.062 35.67281494170418 139.73891601679944 52.062 35.67280514848665 139.7389220155866 52.062 35.672801364453896 139.7389127298582 52.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccc7c2a9-5705-4971-888c-eb5b62fd6d56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccc7c2a9-5705-4971-888c-eb5b62fd6d56_0">
											<gml:posList>35.67280514848665 139.7389220155866 52.062 35.67280514848665 139.7389220155866 54.308 35.672801364453896 139.7389127298582 54.308 35.672801364453896 139.7389127298582 52.062 35.67280514848665 139.7389220155866 52.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80624e35-e94b-4c7b-80f6-2d928b8768ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80624e35-e94b-4c7b-80f6-2d928b8768ed_0">
											<gml:posList>35.672801364453896 139.7389127298582 52.062 35.672801364453896 139.7389127298582 54.308 35.672811157670964 139.73890673107016 54.308 35.672811157670964 139.73890673107016 52.062 35.672801364453896 139.7389127298582 52.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bb584b9-fba7-4dbe-8979-ad77c320dfbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bb584b9-fba7-4dbe-8979-ad77c320dfbe_0">
											<gml:posList>35.672801364453896 139.7389127298582 54.308 35.67280514848665 139.7389220155866 54.308 35.67281494170418 139.73891601679944 54.308 35.672811157670964 139.73890673107016 54.308 35.672801364453896 139.7389127298582 54.308</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eff5fa9-c88f-459a-8eb0-18c4c3bda6c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eff5fa9-c88f-459a-8eb0-18c4c3bda6c2_0">
											<gml:posList>35.67281494170418 139.73891601679944 52.062 35.67281494170418 139.73891601679944 54.308 35.67280514848665 139.7389220155866 54.308 35.67280514848665 139.7389220155866 52.062 35.67281494170418 139.73891601679944 52.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d5b4504-20cd-48ef-98e9-3ffce5bd7656">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d5b4504-20cd-48ef-98e9-3ffce5bd7656_0">
											<gml:posList>35.672811157670964 139.73890673107016 52.062 35.672811157670964 139.73890673107016 54.308 35.67281494170418 139.73891601679944 54.308 35.67281494170418 139.73891601679944 52.062 35.672811157670964 139.73890673107016 52.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-18451b8e-d206-43da-b176-fba7899a0603">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18451b8e-d206-43da-b176-fba7899a0603">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18451b8e-d206-43da-b176-fba7899a0603">
											<gml:posList>35.672792323133045 139.73886605761038 7.74 35.672816359565516 139.73885051986818 7.74 35.672863586315586 139.7389588534636 7.74 35.67285903672535 139.73896184140148 7.74 35.672862395871554 139.738969547975 7.74 35.67279587263088 139.73901309461567 7.74 35.67279254960287 139.73900546533037 7.74 35.6727868468352 139.7390091947413 7.74 35.6727057667264 139.73882318840728 7.74 35.67273411834882 139.73880461881728 7.74 35.672735454790036 139.73880768819177 7.74 35.67276075232918 139.7387911216234 7.74 35.6727754712093 139.738824884736 7.74 35.672792323133045 139.73886605761038 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c3348440-b3d2-4fda-aed7-805e40600390">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3348440-b3d2-4fda-aed7-805e40600390">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3348440-b3d2-4fda-aed7-805e40600390">
											<gml:posList>35.6727057667264 139.73882318840728 52.541 35.67270894048315 139.7388243666499 52.541 35.67273316593851 139.73880849729107 52.541 35.67273411834882 139.73880461881728 52.541 35.6727057667264 139.73882318840728 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b6c90d2-999c-4ddc-80db-b8c17aa8749a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b6c90d2-999c-4ddc-80db-b8c17aa8749a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b6c90d2-999c-4ddc-80db-b8c17aa8749a">
											<gml:posList>35.672735454790036 139.73880768819177 52.541 35.67273411834882 139.73880461881728 52.541 35.67273316593851 139.73880849729107 52.541 35.6727345023883 139.73881157771217 52.541 35.672735454790036 139.73880768819177 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b1be310-ea85-4d96-b962-605c96fe13d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b1be310-ea85-4d96-b962-605c96fe13d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b1be310-ea85-4d96-b962-605c96fe13d5">
											<gml:posList>35.6727868468352 139.7390091947413 52.541 35.67278780825703 139.73900530521013 52.541 35.67270894048315 139.7388243666499 52.541 35.6727057667264 139.73882318840728 52.541 35.6727868468352 139.7390091947413 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41229e70-dd80-44b4-b07f-fe55f1dd324f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41229e70-dd80-44b4-b07f-fe55f1dd324f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41229e70-dd80-44b4-b07f-fe55f1dd324f">
											<gml:posList>35.672735454790036 139.73880768819177 52.541 35.6727345023883 139.73881157771217 52.541 35.67275979991932 139.73879500009863 52.541 35.67276075232918 139.7387911216234 52.541 35.672735454790036 139.73880768819177 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3fc51a1b-5971-4448-8c6d-7ca47d07ba80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fc51a1b-5971-4448-8c6d-7ca47d07ba80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fc51a1b-5971-4448-8c6d-7ca47d07ba80">
											<gml:posList>35.6727754712093 139.738824884736 52.541 35.67276075232918 139.7387911216234 52.541 35.67275979991932 139.73879500009863 52.541 35.672773390046046 139.7388261685937 52.541 35.6727754712093 139.738824884736 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9eba5e72-41b6-44c9-b912-f89a43e3731d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9eba5e72-41b6-44c9-b912-f89a43e3731d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9eba5e72-41b6-44c9-b912-f89a43e3731d">
											<gml:posList>35.672792323133045 139.73886605761038 52.541 35.6727754712093 139.738824884736 52.541 35.672773390046046 139.7388261685937 52.541 35.67279129862835 139.7388699582644 52.541 35.672792323133045 139.73886605761038 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-07406b8b-1105-407a-9400-65ec84e95f9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07406b8b-1105-407a-9400-65ec84e95f9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07406b8b-1105-407a-9400-65ec84e95f9a">
											<gml:posList>35.67273316593851 139.73880849729107 52.062 35.67270894048315 139.7388243666499 52.062 35.67278780825703 139.73900530521013 52.062 35.67279144793879 139.7390029259105 52.062 35.67285793506036 139.73895930198015 52.062 35.67286042156528 139.73895766415615 52.062 35.67281539813136 139.73885438730943 52.062 35.67279129862835 139.7388699582644 52.062 35.672773390046046 139.7388261685937 52.062 35.67275979991932 139.73879500009863 52.062 35.6727345023883 139.73881157771217 52.062 35.67273316593851 139.73880849729107 52.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d184ab0-d328-4127-a9de-791201858d63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d184ab0-d328-4127-a9de-791201858d63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d184ab0-d328-4127-a9de-791201858d63">
											<gml:posList>35.67279254960287 139.73900546533037 52.541 35.67279144793879 139.7390029259105 52.541 35.67278780825703 139.73900530521013 52.541 35.6727868468352 139.7390091947413 52.541 35.67279254960287 139.73900546533037 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f4025dd-c15d-41d4-bccb-a0a4b31cf806">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f4025dd-c15d-41d4-bccb-a0a4b31cf806">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f4025dd-c15d-41d4-bccb-a0a4b31cf806">
											<gml:posList>35.672792323133045 139.73886605761038 52.541 35.67279129862835 139.7388699582644 52.541 35.67281539813136 139.73885438730943 52.541 35.672816359565516 139.73885051986818 52.541 35.672792323133045 139.73886605761038 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bab3a8ed-19c5-464f-aeb8-167c6f7f9d82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bab3a8ed-19c5-464f-aeb8-167c6f7f9d82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bab3a8ed-19c5-464f-aeb8-167c6f7f9d82">
											<gml:posList>35.67285903672535 139.73896184140148 52.541 35.67285793506036 139.73895930198015 52.541 35.67279144793879 139.7390029259105 52.541 35.67279254960287 139.73900546533037 52.541 35.67285903672535 139.73896184140148 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c5305bc2-5ce2-4859-8483-cd729d019f13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5305bc2-5ce2-4859-8483-cd729d019f13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5305bc2-5ce2-4859-8483-cd729d019f13">
											<gml:posList>35.67279587263088 139.73901309461567 52.541 35.672862395871554 139.738969547975 52.541 35.67285903672535 139.73896184140148 52.541 35.67279254960287 139.73900546533037 52.541 35.67279587263088 139.73901309461567 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28634481-abcf-4f9c-81d5-6589b1bee1c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28634481-abcf-4f9c-81d5-6589b1bee1c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28634481-abcf-4f9c-81d5-6589b1bee1c7">
											<gml:posList>35.672816359565516 139.73885051986818 52.541 35.67281539813136 139.73885438730943 52.541 35.67286042156528 139.73895766415615 52.541 35.672863586315586 139.7389588534636 52.541 35.672816359565516 139.73885051986818 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-612606d9-f32c-45df-af27-ecba63a2d826">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-612606d9-f32c-45df-af27-ecba63a2d826">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-612606d9-f32c-45df-af27-ecba63a2d826">
											<gml:posList>35.67285903672535 139.73896184140148 52.541 35.672863586315586 139.7389588534636 52.541 35.67286042156528 139.73895766415615 52.541 35.67285793506036 139.73895930198015 52.541 35.67285903672535 139.73896184140148 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b478beec-1a58-4f68-b6ed-a0ee88d98658">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b478beec-1a58-4f68-b6ed-a0ee88d98658">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b478beec-1a58-4f68-b6ed-a0ee88d98658">
											<gml:posList>35.67275979991932 139.73879500009863 52.541 35.67275979991932 139.73879500009863 52.062 35.672773390046046 139.7388261685937 52.062 35.672773390046046 139.7388261685937 52.541 35.67275979991932 139.73879500009863 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca72117b-d3f4-490e-bb28-471496a4e2fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca72117b-d3f4-490e-bb28-471496a4e2fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca72117b-d3f4-490e-bb28-471496a4e2fa">
											<gml:posList>35.672773390046046 139.7388261685937 52.541 35.672773390046046 139.7388261685937 52.062 35.67279129862835 139.7388699582644 52.062 35.67279129862835 139.7388699582644 52.541 35.672773390046046 139.7388261685937 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e1ffe94-dff9-4a5d-a399-51cfe1907c03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e1ffe94-dff9-4a5d-a399-51cfe1907c03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e1ffe94-dff9-4a5d-a399-51cfe1907c03">
											<gml:posList>35.67276075232918 139.7387911216234 7.74 35.672735454790036 139.73880768819177 7.74 35.672735454790036 139.73880768819177 52.541 35.67276075232918 139.7387911216234 52.541 35.67276075232918 139.7387911216234 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78ae3373-0fca-488f-9470-633fee1f72c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78ae3373-0fca-488f-9470-633fee1f72c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78ae3373-0fca-488f-9470-633fee1f72c4">
											<gml:posList>35.6727345023883 139.73881157771217 52.541 35.6727345023883 139.73881157771217 52.062 35.67275979991932 139.73879500009863 52.062 35.67275979991932 139.73879500009863 52.541 35.6727345023883 139.73881157771217 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d1b8a67-5378-4b95-abb0-5f0b5c4c44a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d1b8a67-5378-4b95-abb0-5f0b5c4c44a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d1b8a67-5378-4b95-abb0-5f0b5c4c44a5">
											<gml:posList>35.672735454790036 139.73880768819177 7.74 35.67273411834882 139.73880461881728 7.74 35.67273411834882 139.73880461881728 52.541 35.672735454790036 139.73880768819177 52.541 35.672735454790036 139.73880768819177 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e6290bf-116a-43ae-b5ee-b4b26648b533">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e6290bf-116a-43ae-b5ee-b4b26648b533">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e6290bf-116a-43ae-b5ee-b4b26648b533">
											<gml:posList>35.6727754712093 139.738824884736 7.74 35.67276075232918 139.7387911216234 7.74 35.67276075232918 139.7387911216234 52.541 35.6727754712093 139.738824884736 52.541 35.6727754712093 139.738824884736 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b5e918b-1cb4-4cf3-a156-d304f1828cc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b5e918b-1cb4-4cf3-a156-d304f1828cc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b5e918b-1cb4-4cf3-a156-d304f1828cc0">
											<gml:posList>35.67273316593851 139.73880849729107 52.541 35.67273316593851 139.73880849729107 52.062 35.6727345023883 139.73881157771217 52.062 35.6727345023883 139.73881157771217 52.541 35.67273316593851 139.73880849729107 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-127730e3-7148-44ce-b1fb-d18e4c10278f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-127730e3-7148-44ce-b1fb-d18e4c10278f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-127730e3-7148-44ce-b1fb-d18e4c10278f">
											<gml:posList>35.67273411834882 139.73880461881728 7.74 35.6727057667264 139.73882318840728 7.74 35.6727057667264 139.73882318840728 52.541 35.67273411834882 139.73880461881728 52.541 35.67273411834882 139.73880461881728 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bfc705b-f4a2-4ee1-99b3-4f3c111c939b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bfc705b-f4a2-4ee1-99b3-4f3c111c939b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bfc705b-f4a2-4ee1-99b3-4f3c111c939b">
											<gml:posList>35.67270894048315 139.7388243666499 52.541 35.67270894048315 139.7388243666499 52.062 35.67273316593851 139.73880849729107 52.062 35.67273316593851 139.73880849729107 52.541 35.67270894048315 139.7388243666499 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5fa287b-e1f9-4e64-9a4a-1245cf656ce0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5fa287b-e1f9-4e64-9a4a-1245cf656ce0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5fa287b-e1f9-4e64-9a4a-1245cf656ce0">
											<gml:posList>35.672792323133045 139.73886605761038 7.74 35.6727754712093 139.738824884736 7.74 35.6727754712093 139.738824884736 52.541 35.672792323133045 139.73886605761038 52.541 35.672792323133045 139.73886605761038 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2bfff2ee-10f6-46d4-8711-4fd6b01a48b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bfff2ee-10f6-46d4-8711-4fd6b01a48b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bfff2ee-10f6-46d4-8711-4fd6b01a48b6">
											<gml:posList>35.672816359565516 139.73885051986818 7.74 35.672792323133045 139.73886605761038 7.74 35.672792323133045 139.73886605761038 52.541 35.672816359565516 139.73885051986818 52.541 35.672816359565516 139.73885051986818 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8685c1a2-e252-49e1-9d8e-aaae717e6ac9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8685c1a2-e252-49e1-9d8e-aaae717e6ac9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8685c1a2-e252-49e1-9d8e-aaae717e6ac9">
											<gml:posList>35.67279129862835 139.7388699582644 52.541 35.67279129862835 139.7388699582644 52.062 35.67281539813136 139.73885438730943 52.062 35.67281539813136 139.73885438730943 52.541 35.67279129862835 139.7388699582644 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94ded27b-8d8e-4c51-ba45-02dc9b2a6215">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94ded27b-8d8e-4c51-ba45-02dc9b2a6215">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94ded27b-8d8e-4c51-ba45-02dc9b2a6215">
											<gml:posList>35.672863586315586 139.7389588534636 7.74 35.672816359565516 139.73885051986818 7.74 35.672816359565516 139.73885051986818 52.541 35.672863586315586 139.7389588534636 52.541 35.672863586315586 139.7389588534636 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d77788c-8a10-4d5e-954b-7f6e0dab9b9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d77788c-8a10-4d5e-954b-7f6e0dab9b9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d77788c-8a10-4d5e-954b-7f6e0dab9b9b">
											<gml:posList>35.67281539813136 139.73885438730943 52.541 35.67281539813136 139.73885438730943 52.062 35.67286042156528 139.73895766415615 52.062 35.67286042156528 139.73895766415615 52.541 35.67281539813136 139.73885438730943 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-397545bf-c7f1-4352-9a46-5bfb00c85008">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-397545bf-c7f1-4352-9a46-5bfb00c85008">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-397545bf-c7f1-4352-9a46-5bfb00c85008">
											<gml:posList>35.67278780825703 139.73900530521013 52.541 35.67278780825703 139.73900530521013 52.062 35.67270894048315 139.7388243666499 52.062 35.67270894048315 139.7388243666499 52.541 35.67278780825703 139.73900530521013 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-711586a9-26d2-4dbe-825d-e579c270c03a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-711586a9-26d2-4dbe-825d-e579c270c03a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-711586a9-26d2-4dbe-825d-e579c270c03a">
											<gml:posList>35.6727057667264 139.73882318840728 7.74 35.6727868468352 139.7390091947413 7.74 35.6727868468352 139.7390091947413 52.541 35.6727057667264 139.73882318840728 52.541 35.6727057667264 139.73882318840728 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-497165cb-e484-45a3-869b-37062dd1fff1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-497165cb-e484-45a3-869b-37062dd1fff1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-497165cb-e484-45a3-869b-37062dd1fff1">
											<gml:posList>35.67286042156528 139.73895766415615 52.541 35.67286042156528 139.73895766415615 52.062 35.67285793506036 139.73895930198015 52.062 35.67285793506036 139.73895930198015 52.541 35.67286042156528 139.73895766415615 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4822af3-5abe-4f7e-90c8-67e7a29bcaa3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4822af3-5abe-4f7e-90c8-67e7a29bcaa3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4822af3-5abe-4f7e-90c8-67e7a29bcaa3">
											<gml:posList>35.67285903672535 139.73896184140148 7.74 35.672863586315586 139.7389588534636 7.74 35.672863586315586 139.7389588534636 52.541 35.67285903672535 139.73896184140148 52.541 35.67285903672535 139.73896184140148 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0066bad5-8df7-436b-b7a2-6e1bf78bd5e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0066bad5-8df7-436b-b7a2-6e1bf78bd5e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0066bad5-8df7-436b-b7a2-6e1bf78bd5e8">
											<gml:posList>35.672862395871554 139.738969547975 7.74 35.67285903672535 139.73896184140148 7.74 35.67285903672535 139.73896184140148 52.541 35.672862395871554 139.738969547975 52.541 35.672862395871554 139.738969547975 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c004292e-bc87-4900-bb11-2b96c4b55be2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c004292e-bc87-4900-bb11-2b96c4b55be2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c004292e-bc87-4900-bb11-2b96c4b55be2">
											<gml:posList>35.67285793506036 139.73895930198015 52.541 35.67285793506036 139.73895930198015 52.062 35.67279144793879 139.7390029259105 52.062 35.67279144793879 139.7390029259105 52.541 35.67285793506036 139.73895930198015 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1944323b-d04c-48ab-8205-3e9131a16828">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1944323b-d04c-48ab-8205-3e9131a16828">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1944323b-d04c-48ab-8205-3e9131a16828">
											<gml:posList>35.67279587263088 139.73901309461567 7.74 35.672862395871554 139.738969547975 7.74 35.672862395871554 139.738969547975 52.541 35.67279587263088 139.73901309461567 52.541 35.67279587263088 139.73901309461567 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-345094ad-d72c-4bf7-82de-5bb6bfd676ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-345094ad-d72c-4bf7-82de-5bb6bfd676ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-345094ad-d72c-4bf7-82de-5bb6bfd676ec">
											<gml:posList>35.67279144793879 139.7390029259105 52.541 35.67279144793879 139.7390029259105 52.062 35.67278780825703 139.73900530521013 52.062 35.67278780825703 139.73900530521013 52.541 35.67279144793879 139.7390029259105 52.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a27e373-158d-4f66-aacf-04276df6e600">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a27e373-158d-4f66-aacf-04276df6e600">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a27e373-158d-4f66-aacf-04276df6e600">
											<gml:posList>35.6727868468352 139.7390091947413 7.74 35.67279254960287 139.73900546533037 7.74 35.67279254960287 139.73900546533037 52.541 35.6727868468352 139.7390091947413 52.541 35.6727868468352 139.7390091947413 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c271388-e883-4377-8a84-8330c97a86ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c271388-e883-4377-8a84-8330c97a86ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c271388-e883-4377-8a84-8330c97a86ab">
											<gml:posList>35.67279254960287 139.73900546533037 7.74 35.67279587263088 139.73901309461567 7.74 35.67279587263088 139.73901309461567 52.541 35.67279254960287 139.73900546533037 52.541 35.67279254960287 139.73900546533037 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1827</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">185.82033</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.09</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>