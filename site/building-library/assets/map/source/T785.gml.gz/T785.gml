<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e11bfca9-1576-40ea-ad2b-67bade10de0f">
			<core:creationDate>2023-08-22</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門一・二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">32.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66875644527903 139.74694007899586 0 35.668703243728054 139.74701955726718 0 35.668726112814376 139.7470477044499 0 35.66872780418019 139.74704573201763 0 35.66879385951067 139.74712625395637 0 35.66899907897947 139.74695671805304 0 35.66889691965171 139.74683439030966 0 35.668890539924014 139.7468421879745 0 35.668870230255926 139.7468171994112 0 35.66876281997874 139.7469478783619 0 35.66875644527903 139.74694007899586 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875644527903 139.74694007899586 5.789 35.66876281997874 139.7469478783619 5.789 35.668870230255926 139.7468171994112 5.789 35.668890539924014 139.7468421879745 5.789 35.66889691965171 139.74683439030966 5.789 35.66899907897947 139.74695671805304 5.789 35.66879385951067 139.74712625395637 5.789 35.66872780418019 139.74704573201763 5.789 35.668726112814376 139.7470477044499 5.789 35.668703243728054 139.74701955726718 5.789 35.66875644527903 139.74694007899586 5.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875644527903 139.74694007899586 5.789 35.668703243728054 139.74701955726718 5.789 35.668703243728054 139.74701955726718 35.442 35.66875644527903 139.74694007899586 35.442 35.66875644527903 139.74694007899586 5.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668703243728054 139.74701955726718 5.789 35.668726112814376 139.7470477044499 5.789 35.668726112814376 139.7470477044499 35.442 35.668703243728054 139.74701955726718 35.442 35.668703243728054 139.74701955726718 5.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668726112814376 139.7470477044499 5.789 35.66872780418019 139.74704573201763 5.789 35.66872780418019 139.74704573201763 35.442 35.668726112814376 139.7470477044499 35.442 35.668726112814376 139.7470477044499 5.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872780418019 139.74704573201763 5.789 35.66879385951067 139.74712625395637 5.789 35.66879385951067 139.74712625395637 35.442 35.66872780418019 139.74704573201763 35.442 35.66872780418019 139.74704573201763 5.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879385951067 139.74712625395637 5.789 35.66899907897947 139.74695671805304 5.789 35.66899907897947 139.74695671805304 35.442 35.66879385951067 139.74712625395637 35.442 35.66879385951067 139.74712625395637 5.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66899907897947 139.74695671805304 5.789 35.66889691965171 139.74683439030966 5.789 35.66889691965171 139.74683439030966 35.442 35.66899907897947 139.74695671805304 35.442 35.66899907897947 139.74695671805304 5.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889691965171 139.74683439030966 5.789 35.668890539924014 139.7468421879745 5.789 35.668890539924014 139.7468421879745 35.442 35.66889691965171 139.74683439030966 35.442 35.66889691965171 139.74683439030966 5.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668890539924014 139.7468421879745 5.789 35.668870230255926 139.7468171994112 5.789 35.668870230255926 139.7468171994112 35.442 35.668890539924014 139.7468421879745 35.442 35.668890539924014 139.7468421879745 5.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668870230255926 139.7468171994112 5.789 35.66876281997874 139.7469478783619 5.789 35.66876281997874 139.7469478783619 35.442 35.668870230255926 139.7468171994112 35.442 35.668870230255926 139.7468171994112 5.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876281997874 139.7469478783619 5.789 35.66875644527903 139.74694007899586 5.789 35.66875644527903 139.74694007899586 35.442 35.66876281997874 139.7469478783619 35.442 35.66876281997874 139.7469478783619 5.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875644527903 139.74694007899586 35.442 35.668703243728054 139.74701955726718 35.442 35.668726112814376 139.7470477044499 35.442 35.66872780418019 139.74704573201763 35.442 35.66879385951067 139.74712625395637 35.442 35.66899907897947 139.74695671805304 35.442 35.66889691965171 139.74683439030966 35.442 35.668890539924014 139.7468421879745 35.442 35.668870230255926 139.7468171994112 35.442 35.66876281997874 139.7469478783619 35.442 35.66875644527903 139.74694007899586 35.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1037_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1037_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1037_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1037_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1035_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1035_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1035_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1034_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1034_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1034_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1034_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1034_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1034_5"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_p1034_6"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0166_b_0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gnd_TMmnt0166_b_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_b_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_b_0">
											<gml:posList>35.66889058421758 139.7468422428056 5.79062195 35.668896957407576 139.7468343967882 5.79087279 35.66899907896092 139.74695671793145 5.79632261 35.66879391538999 139.74712626444614 5.78781859 35.66872785058888 139.74704567459315 5.78428881 35.66872617351469 139.74704771630016 5.78422376 35.66870336532 139.74701958091805 5.78300719 35.668756506171626 139.74694009024327 5.78498741 35.66876288975531 139.74694796479653 5.78532755 35.668870291720246 139.74681721075314 5.78953961 35.66889058421758 139.7468422428056 5.79062195</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gml_4df623af-0bfa-4f7a-9f41-f72bc433e376">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_63e002e5-ab04-4ce3-9bc9-4ff94056179c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a8eb415f-2762-4526-b3de-abdf17b6ad1f">
											<gml:posList>35.6689780460303 139.7469660742764 6.862499933012771 35.66894061286278 139.74700621842882 6.862499933012771 35.66893717061708 139.74699998782526 6.862499933012771 35.6689780460303 139.7469660742764 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a99d2763-a3b2-46d5-aa57-5c02051d4361">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c302c7a4-50d4-4293-8365-cefa6c28b208">
											<gml:posList>35.66894061286278 139.74700621842882 6.862499933012771 35.6689780460303 139.7469660742764 6.862499933012771 35.66898148814006 139.74697230471327 6.862499933012771 35.66894061286278 139.74700621842882 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0709b26c-ebff-4486-a2f7-469a846e63f4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fcd9c3d3-2556-4fe4-a48f-34b107e8236c">
											<gml:posList>35.6689780460303 139.7469660742764 6.862499933012771 35.66893717061708 139.74699998782526 6.862499933012771 35.66886723503126 139.74680616729975 6.862499933012771 35.6689780460303 139.7469660742764 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d7c3b8ec-8fd5-4abb-8b10-cf8fa0f68214">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9bb15b22-4b8c-438c-98b1-6aeb3d0063ba">
											<gml:posList>35.66886723503126 139.74680616729975 6.862499933012771 35.66893717061708 139.74699998782526 6.862499933012771 35.668926862691535 139.747005808151 6.862499933012771 35.66886723503126 139.74680616729975 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0cdb6ea2-e8d8-4b1a-9fe0-e51c45f7c45f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ddd5f2d3-ab99-4d53-9fee-cb145590f495">
											<gml:posList>35.66886723503126 139.74680616729975 6.862499933012771 35.668926862691535 139.747005808151 6.862499933012771 35.668906420829224 139.74702244222533 6.862499933012771 35.66886723503126 139.74680616729975 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bd757961-dbb2-46bb-adb7-ce4a6c278260">
									<gml:exterior>
										<gml:LinearRing gml:id="line_feae3e06-9815-4f96-8a5b-b1be38857faf">
											<gml:posList>35.668926862691535 139.747005808151 6.862499933012771 35.66893717061708 139.74699998782526 6.862499933012771 35.668928215025566 139.74700741819677 6.862499933012771 35.668926862691535 139.747005808151 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8529d853-9360-4c8b-9e5d-b43fa621f52c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8d43988a-9457-4fe5-847d-356f2e3527bc">
											<gml:posList>35.66886723503126 139.74680616729975 6.862499933012771 35.668906420829224 139.74702244222533 6.862499933012771 35.66888242642479 139.74704303175528 6.862499933012771 35.66886723503126 139.74680616729975 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0a584516-ddab-4c78-8749-ba5b45eea290">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a21943a6-cbc3-4d87-a6b9-900e7e6e7568">
											<gml:posList>35.668906420829224 139.74702244222533 6.862499933012771 35.668926862691535 139.747005808151 6.862499933012771 35.668910152962226 139.7470268857226 6.862499933012771 35.668906420829224 139.74702244222533 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8738af03-b3b0-4a11-bbc0-7514efb3adcb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1e6cee17-6cdb-4306-be2d-69e680b93774">
											<gml:posList>35.66886723503126 139.74680616729975 6.862499933012771 35.66888242642479 139.74704303175528 6.862499933012771 35.668728509383584 139.74704993834914 6.862499933012771 35.66886723503126 139.74680616729975 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_508916ea-1eec-4e90-940f-601334c65abb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_944313c2-eba8-4bef-b6af-8737feb43899">
											<gml:posList>35.66888242642479 139.74704303175528 6.862499933012771 35.668906420829224 139.74702244222533 6.862499933012771 35.6688863730252 139.74704773054228 6.862499933012771 35.66888242642479 139.74704303175528 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_98974dbf-742a-499b-b23d-35b3c183db32">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a8c0f489-949b-4520-98dd-91adbeaf9b27">
											<gml:posList>35.66886723503126 139.74680616729975 6.862499933012771 35.668728509383584 139.74704993834914 6.862499933012771 35.66870207904577 139.74701815687015 6.862499933012771 35.66886723503126 139.74680616729975 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_71cd12fc-756c-4598-9afb-bd6b3ebe1584">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8578bae2-540d-43cc-895c-b4c624d5f173">
											<gml:posList>35.66885994949103 139.74706267576386 6.862499933012771 35.66888242642479 139.74704303175528 6.862499933012771 35.6688635010178 139.74706690421718 6.862499933012771 35.66885994949103 139.74706267576386 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_08d9f51b-791f-4d88-b1e7-8eec63373c5c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a1be7c53-5ed7-4f9e-9a48-7a7ce4f4a1a0">
											<gml:posList>35.66888242642479 139.74704303175528 6.862499933012771 35.66885994949103 139.74706267576386 6.862499933012771 35.668728509383584 139.74704993834914 6.862499933012771 35.66888242642479 139.74704303175528 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_25c5e7bb-6859-48cf-b36e-d7e0b6c94171">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1ad8d8de-6a27-4724-9866-703902fd4085">
											<gml:posList>35.668728509383584 139.74704993834914 6.862499933012771 35.66885994949103 139.74706267576386 6.862499933012771 35.6688490060764 139.74707647993023 6.862499933012771 35.668728509383584 139.74704993834914 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a1a03033-96e2-444b-a611-f9f6f47bd166">
									<gml:exterior>
										<gml:LinearRing gml:id="line_82da90b7-e02d-4294-846f-33104321abef">
											<gml:posList>35.668728509383584 139.74704993834914 6.862499933012771 35.6688490060764 139.74707647993023 6.862499933012771 35.668786560566524 139.74713496373204 6.862499933012771 35.668728509383584 139.74704993834914 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0024e684-f9ec-4838-9730-83b990cbb02d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c2d33747-c063-405e-b7bd-b46eae5e9607">
											<gml:posList>35.668728509383584 139.74704993834914 6.862499933012771 35.668786560566524 139.74713496373204 6.862499933012771 35.668722386704474 139.74705779730166 6.862499933012771 35.668728509383584 139.74704993834914 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_346e83a7-8ec4-410b-97b6-a8d49ae6f4f9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4a6511e1-07c0-40a6-8cda-5400a1c1d48e">
											<gml:posList>35.6689780460303 139.7469660742764 6.862499933012771 35.66886723503126 139.74680616729975 6.862499933012771 35.66899116587438 139.74695518886168 6.862499933012771 35.6689780460303 139.7469660742764 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a157e5e3-1484-4805-b2b7-b36dd1a46751">
									<gml:exterior>
										<gml:LinearRing gml:id="line_627ee944-3b94-4b2b-8795-c4d481ce2c89">
											<gml:posList>35.668786560566524 139.74713496373204 6.862499933012771 35.6688490060764 139.74707647993023 6.862499933012771 35.66885153428912 139.74708105619038 6.862499933012771 35.668786560566524 139.74713496373204 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_0cfb9c86-c60f-4cf5-9930-b3f5ee96d3b5">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bcd6409e-d2d7-431b-b5a5-968f8be4ee59">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2dfa09bc-fadf-4658-b2ea-8ffa80723751">
											<gml:posList>35.66897983086256 139.74695762768138 13.130490045317458 35.66898854976548 139.7469630696895 13.130490045317458 35.66898769123957 139.74696420680735 13.130490045317458 35.66897983086256 139.74695762768138 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_32bc60e4-9e7e-485e-9943-e4644e158564">
									<gml:exterior>
										<gml:LinearRing gml:id="line_06ac27c2-217a-4841-8540-80a7c9b905fb">
											<gml:posList>35.66898854976548 139.7469630696895 13.130490045317458 35.66897983086256 139.74695762768138 13.130490045317458 35.66898926576778 139.74696169405894 13.130490045317458 35.66898854976548 139.7469630696895 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eba27e07-64b3-49f7-b4ed-49fce617bd5d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b4beb00a-1f90-4e3d-9ffc-e6cfed255312">
											<gml:posList>35.66897983086256 139.74695762768138 13.130490045317458 35.66898769123957 139.74696420680735 13.130490045317458 35.668986752485125 139.74696509152423 13.130490045317458 35.66897983086256 139.74695762768138 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f42b075c-16c4-427a-bf44-ef0d8dfc5623">
									<gml:exterior>
										<gml:LinearRing gml:id="line_06788486-0ab1-430d-8dde-591199766847">
											<gml:posList>35.66897983086256 139.74695762768138 13.130490045317458 35.668986752485125 139.74696509152423 13.130490045317458 35.66897928921328 139.7469600895948 13.130490045317458 35.66897983086256 139.74695762768138 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2003b574-c6b1-405b-b98c-921ddc9bb63e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2533533c-bf25-4d9f-a93f-bb74d5559a7a">
											<gml:posList>35.66897928921328 139.7469600895948 13.130490045317458 35.668986752485125 139.74696509152423 13.130490045317458 35.66897813957459 139.74696226428037 13.130490045317458 35.66897928921328 139.7469600895948 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_385a28c7-47a9-486a-90d5-d0836c50537d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a7a20378-6b69-4bb5-b02e-ca36f13e5002">
											<gml:posList>35.66897813957459 139.74696226428037 13.130490045317458 35.668986752485125 139.74696509152423 13.130490045317458 35.66898090232122 139.74696994531257 13.130490045317458 35.66897813957459 139.74696226428037 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b8b083fb-6e8e-4969-a517-2d5eae7200ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b6cff7a0-ab28-401f-8c78-8f57bc2998ba">
											<gml:posList>35.66897813957459 139.74696226428037 13.130490045317458 35.66898090232122 139.74696994531257 13.130490045317458 35.668977187393125 139.74696322115085 13.130490045317458 35.66897813957459 139.74696226428037 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ae61299f-ac3b-40d2-8f87-57af7e335ecb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c2b5a42a-8a02-4b20-ac45-c2e0c9eaba74">
											<gml:posList>35.66897975982506 139.74695523266797 13.130490045317458 35.66898780317941 139.74695114527066 13.130490045317458 35.668988593976614 139.7469522258331 13.130490045317458 35.66897975982506 139.74695523266797 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6ffbaf3f-8ae0-4969-b813-835d656cc0cb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c278364f-3f6e-440b-9b87-d8ec8a6bf423">
											<gml:posList>35.66898780317941 139.74695114527066 13.130490045317458 35.66897975982506 139.74695523266797 13.130490045317458 35.668979215479894 139.74695316936445 13.130490045317458 35.66898780317941 139.74695114527066 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_32879f9d-e4ef-4baa-bcb3-9ba6a9520f62">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4b16f332-afcf-40d2-a6f2-4927eb4796af">
											<gml:posList>35.66897975982506 139.74695523266797 13.130490045317458 35.668988593976614 139.7469522258331 13.130490045317458 35.668989268030835 139.7469535362545 13.130490045317458 35.66897975982506 139.74695523266797 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_234504fa-ee25-4f43-8f36-5e780a4f0304">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4b5c88aa-5d9f-408c-a279-906fb40a8dea">
											<gml:posList>35.66898780317941 139.74695114527066 13.130490045317458 35.668979215479894 139.74695316936445 13.130490045317458 35.66898256682945 139.74694484884185 13.130490045317458 35.66898780317941 139.74695114527066 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_afd8ec90-ce02-40b0-816e-974769566ae4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2711324a-055d-42b4-9190-aa652eceffce">
											<gml:posList>35.66897975982506 139.74695523266797 13.130490045317458 35.668989268030835 139.7469535362545 13.130490045317458 35.66897983086256 139.74695762768138 13.130490045317458 35.66897975982506 139.74695523266797 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b2224703-b8a6-4543-a163-c7f0845c1a03">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d09a784c-5578-4ede-8a23-e6dfee3a3def">
											<gml:posList>35.66897983086256 139.74695762768138 13.130490045317458 35.668989268030835 139.7469535362545 13.130490045317458 35.66898976631845 139.74695504929335 13.130490045317458 35.66897983086256 139.74695762768138 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0227ee06-d939-49b9-bc7c-320e2bcc6ccc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e0a342f9-8c4f-4568-89b6-328e2edf89e0">
											<gml:posList>35.66897983086256 139.74695762768138 13.130490045317458 35.66898976631845 139.74695504929335 13.130490045317458 35.66899003625884 139.74695670803658 13.130490045317458 35.66897983086256 139.74695762768138 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6660978b-40d1-4f09-a8e4-48a8c25538c5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3df29100-1af0-46cc-9eea-e1ff04c2bd5d">
											<gml:posList>35.668978328505005 139.74695146038422 13.130490045317458 35.66898256682945 139.74694484884185 13.130490045317458 35.668979215479894 139.74695316936445 13.130490045317458 35.668978328505005 139.74695146038422 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_95c772b2-c6e3-4408-9fe6-39c5b3049e17">
									<gml:exterior>
										<gml:LinearRing gml:id="line_12ccad8f-2db3-407c-a29a-1cd48a110e2a">
											<gml:posList>35.66898256682945 139.74694484884185 13.130490045317458 35.668978328505005 139.74695146038422 13.130490045317458 35.66897777473761 139.7469508339763 13.130490045317458 35.66898256682945 139.74694484884185 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b8fcd9fe-fd00-4557-9b78-1fc5665ea3b5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1cef1bb8-23bb-4f8e-9b51-8a25925aa5cb">
											<gml:posList>35.66897983086256 139.74695762768138 13.130490045317458 35.66899003625884 139.74695670803658 13.130490045317458 35.668990043134045 139.74695843128058 13.130490045317458 35.66897983086256 139.74695762768138 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_79630afd-daf5-45c5-bf50-ba00005b4311">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c8a790cd-7e59-492b-9c59-dfa4cc4f56f8">
											<gml:posList>35.66897983086256 139.74695762768138 13.130490045317458 35.668990043134045 139.74695843128058 13.130490045317458 35.668989778898485 139.7469601238035 13.130490045317458 35.66897983086256 139.74695762768138 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_250361bd-69a7-41c8-9b1f-2cc01fb6c3bf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_58a5f005-02dc-4db5-998d-00b0adeedcb9">
											<gml:posList>35.66897983086256 139.74695762768138 13.130490045317458 35.668989778898485 139.7469601238035 13.130490045317458 35.66898926576778 139.74696169405894 13.130490045317458 35.66897983086256 139.74695762768138 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_dd1f4d19-f141-46e9-a045-0a30d840324b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_22579e4a-e2b3-4440-ab19-9270c905de76">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b7eaafad-699e-460e-a2e0-5e5f1453e193">
											<gml:posList>35.66899423701073 139.74695888167824 26.006245355376052 35.66898854976548 139.7469630696895 26.006245355376052 35.66898926576778 139.74696169405894 26.006245355376052 35.66899423701073 139.74695888167824 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bef58467-4fd7-43be-a07a-8925f192cf5f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_27992146-e2eb-4ea3-8342-a42cd19b438f">
											<gml:posList>35.66898854976548 139.7469630696895 26.006245355376052 35.66899423701073 139.74695888167824 26.006245355376052 35.66898769123957 139.74696420680735 26.006245355376052 35.66898854976548 139.7469630696895 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_39b8604a-b31c-4022-ae40-e65d09d9e8ed">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a66fb01c-1d52-40ed-90ac-88e313639196">
											<gml:posList>35.66899423701073 139.74695888167824 26.006245355376052 35.66898926576778 139.74696169405894 26.006245355376052 35.668989778898485 139.7469601238035 26.006245355376052 35.66899423701073 139.74695888167824 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6fa066f3-bf1c-4232-b556-f4d189bcd083">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e7c53f71-a80d-4ed4-9d36-9fee2431a64d">
											<gml:posList>35.66899423701073 139.74695888167824 26.006245355376052 35.668989778898485 139.7469601238035 26.006245355376052 35.668990043134045 139.74695843128058 26.006245355376052 35.66899423701073 139.74695888167824 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_153754d1-e61c-4408-9f03-40624de560f4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aaadacc4-c296-45c3-8ace-c66d9d5b8b7c">
											<gml:posList>35.66899423701073 139.74695888167824 26.006245355376052 35.668990043134045 139.74695843128058 26.006245355376052 35.66899003625884 139.74695670803658 26.006245355376052 35.66899423701073 139.74695888167824 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c5267217-bca1-4ce0-a27d-8252394c9d63">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7bcefbde-f263-48ea-84e9-8e63e10f50fb">
											<gml:posList>35.66899423701073 139.74695888167824 26.006245355376052 35.66899003625884 139.74695670803658 26.006245355376052 35.66898976631845 139.74695504929335 26.006245355376052 35.66899423701073 139.74695888167824 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8d0b4280-64b4-44aa-97f8-805cd4db9423">
									<gml:exterior>
										<gml:LinearRing gml:id="line_70c49266-1361-4a06-a942-27def483f4cc">
											<gml:posList>35.66899423701073 139.74695888167824 26.006245355376052 35.66898976631845 139.74695504929335 26.006245355376052 35.668989268030835 139.7469535362545 26.006245355376052 35.66899423701073 139.74695888167824 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d9ccaf3b-a5b7-4b51-b052-93b959a96a94">
									<gml:exterior>
										<gml:LinearRing gml:id="line_568c6696-7275-4eba-a352-8f2f40a14977">
											<gml:posList>35.66899423701073 139.74695888167824 26.006245355376052 35.668989268030835 139.7469535362545 26.006245355376052 35.668988593976614 139.7469522258331 26.006245355376052 35.66899423701073 139.74695888167824 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_30861ce2-3eff-4318-8614-f9ef9da9b3ae">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0c83ecac-fb48-4f43-b60d-390bec27f688">
											<gml:posList>35.66899423701073 139.74695888167824 26.006245355376052 35.668988593976614 139.7469522258331 26.006245355376052 35.66898780317941 139.74695114527066 26.006245355376052 35.66899423701073 139.74695888167824 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_59903f5e-885b-4993-bcc3-c971be5ba4b6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_171a01c1-f20c-4045-8b12-4532d20bd4aa">
											<gml:posList>35.66898769123957 139.74696420680735 26.006245355376052 35.66899423701073 139.74695888167824 26.006245355376052 35.668986752485125 139.74696509152423 26.006245355376052 35.66898769123957 139.74696420680735 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_d20d99ec-4c47-4ca0-b71a-fef41f47b87e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a0ffdf3d-0a1d-4cd1-a168-bc383b3a0be2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0520f57f-b504-4d29-825a-218515fcd017">
											<gml:posList>35.66898256682945 139.74694484884185 9.82349083877449 35.6689769793936 139.74694993393553 9.82349083877449 35.66897518235527 139.7469488418161 9.82349083877449 35.66898256682945 139.74694484884185 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b99df9d2-53dd-45d7-8a6d-94e60cedfe3e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_62bf7cbd-f051-4a9a-aff0-ef0e27fdd69b">
											<gml:posList>35.6689769793936 139.74694993393553 9.82349083877449 35.66898256682945 139.74694484884185 9.82349083877449 35.66897777473761 139.7469508339763 9.82349083877449 35.6689769793936 139.74694993393553 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cf8f1ade-aa38-41bc-8d05-7cc588458613">
									<gml:exterior>
										<gml:LinearRing gml:id="line_65125506-1c1e-43b6-a6f5-9e193fb6e99a">
											<gml:posList>35.668906415466786 139.74686830662048 9.82349083877449 35.668930700464365 139.74690442435693 9.82349083877449 35.668903594190766 139.7468718303237 9.82349083877449 35.668906415466786 139.74686830662048 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_30283c21-51ab-4610-8a01-37c39e2670a0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3cfab2a4-9f49-458a-880a-4d77a4587969">
											<gml:posList>35.668930700464365 139.74690442435693 9.82349083877449 35.668906415466786 139.74686830662048 9.82349083877449 35.66898256682945 139.74694484884185 9.82349083877449 35.668930700464365 139.74690442435693 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5404a7be-56f6-487c-b586-58e9dd581d96">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4b615f4e-e773-4b60-b5e0-a091438e28df">
											<gml:posList>35.66898256682945 139.74694484884185 9.82349083877449 35.668906415466786 139.74686830662048 9.82349083877449 35.66886723503126 139.74680616729975 9.82349083877449 35.66898256682945 139.74694484884185 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3b173468-e202-4e38-a01a-33b5c2e51de3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7c44fbc6-9ef9-4ffa-9526-64bc4a57bff0">
											<gml:posList>35.66886723503126 139.74680616729975 9.82349083877449 35.668906415466786 139.74686830662048 9.82349083877449 35.668861190555496 139.74681392574468 9.82349083877449 35.66886723503126 139.74680616729975 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2d3a4927-1654-4114-a9b3-50361023b3de">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3b93ee84-dfee-4335-86ad-865b31233856">
											<gml:posList>35.66896700054374 139.74695318252367 9.82349083877449 35.668945139145826 139.74694986592885 9.82349083877449 35.668944889214174 139.74694542306383 9.82349083877449 35.66896700054374 139.74695318252367 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dba4cf79-48b6-45d9-8948-89cb5d6cd98f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cf8135d5-5fd8-4963-b6c2-097db6bb2880">
											<gml:posList>35.668945139145826 139.74694986592885 9.82349083877449 35.66896700054374 139.74695318252367 9.82349083877449 35.668966459159606 139.74695524699652 9.82349083877449 35.668945139145826 139.74694986592885 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aaefc90e-79bd-481e-9485-6a8c660b7a46">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0499676b-b48f-43b7-b2d1-cfa809e45c76">
											<gml:posList>35.66896700054374 139.74695318252367 9.82349083877449 35.668944889214174 139.74694542306383 9.82349083877449 35.66896788506536 139.74695147163524 9.82349083877449 35.66896700054374 139.74695318252367 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5b50607a-e0a5-4235-8f2a-0d1f94cb0232">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c38d571c-98cb-4705-97c8-3a38e298a7e2">
											<gml:posList>35.66896788506536 139.74695147163524 9.82349083877449 35.668944889214174 139.74694542306383 9.82349083877449 35.66894482916951 139.74694435604144 9.82349083877449 35.66896788506536 139.74695147163524 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7d1b23ef-ddbd-47ad-b19a-37d6df94ddf0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_de884d0f-d90d-45c9-a809-8f6fa35168a6">
											<gml:posList>35.66896788506536 139.74695147163524 9.82349083877449 35.66894482916951 139.74694435604144 9.82349083877449 35.668944180467044 139.74693889051042 9.82349083877449 35.66896788506536 139.74695147163524 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_52c54992-3b2c-46b2-9a49-4213bf976eb5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cf6d282c-8f27-4b3c-9aa6-bbeeea738a42">
											<gml:posList>35.66896788506536 139.74695147163524 9.82349083877449 35.668944180467044 139.74693889051042 9.82349083877449 35.66896923198461 139.74694994228216 9.82349083877449 35.66896788506536 139.74695147163524 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a4bd423a-f211-4de0-bbaf-2c1b6df64aeb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c59e3096-4247-47f1-8427-826db7ca743e">
											<gml:posList>35.66896923198461 139.74694994228216 9.82349083877449 35.668944180467044 139.74693889051042 9.82349083877449 35.668943196636945 139.74693350068227 9.82349083877449 35.66896923198461 139.74694994228216 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_06683d50-e625-47a0-86ac-8c367d097ec1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f6365b16-3a34-44f0-b910-fa41937d9e2f">
											<gml:posList>35.66896923198461 139.74694994228216 9.82349083877449 35.668943196636945 139.74693350068227 9.82349083877449 35.668971027453225 139.7469488462924 9.82349083877449 35.66896923198461 139.74694994228216 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a89a9f0e-fb04-427e-a770-50469e8a9319">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4959bf72-2bcc-48a5-9976-c2a03f9770dd">
											<gml:posList>35.668971027453225 139.7469488462924 9.82349083877449 35.668943196636945 139.74693350068227 9.82349083877449 35.66894188334043 139.7469282173955 9.82349083877449 35.668971027453225 139.7469488462924 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_395de5d4-bd78-4a07-ba82-62261444fe02">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d178ec7d-13b3-47d0-8f1a-8be651ee0379">
											<gml:posList>35.668971027453225 139.7469488462924 9.82349083877449 35.66894188334043 139.7469282173955 9.82349083877449 35.668973104547945 139.7469484432437 9.82349083877449 35.668971027453225 139.7469488462924 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_90d21a69-ca24-42a6-8dd2-e3e34826e0ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a2f4bb36-c30f-4dfe-b501-bd5cd86f6e69">
											<gml:posList>35.668973104547945 139.7469484432437 9.82349083877449 35.66894188334043 139.7469282173955 9.82349083877449 35.66894024802613 139.7469230706439 9.82349083877449 35.668973104547945 139.7469484432437 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_31169f9c-5482-4e73-94d0-16f8b84a7a8e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f49b61c6-34f5-408b-a7ee-90be20e834c0">
											<gml:posList>35.668973104547945 139.7469484432437 9.82349083877449 35.66894024802613 139.7469230706439 9.82349083877449 35.66898256682945 139.74694484884185 9.82349083877449 35.668973104547945 139.7469484432437 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_24362567-ea83-4381-8c23-a693b8756ef4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_55b65e27-47f9-453e-9a89-508c881af383">
											<gml:posList>35.66898256682945 139.74694484884185 9.82349083877449 35.66894024802613 139.7469230706439 9.82349083877449 35.66893830020564 139.74691809025063 9.82349083877449 35.66898256682945 139.74694484884185 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4de5de6b-7d6e-4f26-ba31-bc4eaba9917f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6abf5bf1-9d80-4d47-aa3c-27c3fdfa5e98">
											<gml:posList>35.66898256682945 139.74694484884185 9.82349083877449 35.66893830020564 139.74691809025063 9.82349083877449 35.6689360507647 139.74691330435175 9.82349083877449 35.66898256682945 139.74694484884185 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eea770dd-a17e-4043-8f41-8ffb33412390">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fa57f561-6b8a-4840-b86e-21062da713da">
											<gml:posList>35.66898256682945 139.74694484884185 9.82349083877449 35.6689360507647 139.74691330435175 9.82349083877449 35.66893351265158 139.74690874023833 9.82349083877449 35.66898256682945 139.74694484884185 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2c878214-b0ef-4173-a29e-0439db9a2206">
									<gml:exterior>
										<gml:LinearRing gml:id="line_768f374a-bd6f-4778-a44b-4e412d8d0707">
											<gml:posList>35.668973104547945 139.7469484432437 9.82349083877449 35.66898256682945 139.74694484884185 9.82349083877449 35.66897518235527 139.7469488418161 9.82349083877449 35.668973104547945 139.7469484432437 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cce930dc-2021-4f31-bedf-b3642f45757d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4581a838-dc5c-4d70-be28-2c3509959435">
											<gml:posList>35.66898256682945 139.74694484884185 9.82349083877449 35.66893351265158 139.74690874023833 9.82349083877449 35.668930700464365 139.74690442435693 9.82349083877449 35.66898256682945 139.74694484884185 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f81f07ce-fbdc-49ad-8039-7372d6bf3a7c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3804d52b-b7f4-4143-9608-1ab525e06170">
											<gml:posList>35.66885044045238 139.74707818747746 9.82349083877449 35.6688635010178 139.74706690421718 9.82349083877449 35.6688863730252 139.74704773054228 9.82349083877449 35.66885044045238 139.74707818747746 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cfdac334-b1ef-44de-9a0f-7dde21c53996">
									<gml:exterior>
										<gml:LinearRing gml:id="line_405e1450-c4ad-4075-b048-4f3becc6883c">
											<gml:posList>35.6688635010178 139.74706690421718 9.82349083877449 35.66885044045238 139.74707818747746 9.82349083877449 35.66885994949103 139.74706267576386 9.82349083877449 35.6688635010178 139.74706690421718 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c734a4cd-b0eb-48d3-8afd-657a71f54025">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0e3d7e19-5a03-4a7d-839f-dac59f405db9">
											<gml:posList>35.66885044045238 139.74707818747746 9.82349083877449 35.6688863730252 139.74704773054228 9.82349083877449 35.66898090232122 139.74696994531257 9.82349083877449 35.66885044045238 139.74707818747746 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_141feb9d-6c43-4f33-8813-1f4dbd1071c9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e1103673-d7bc-498a-8997-eded577a7ee1">
											<gml:posList>35.66898090232122 139.74696994531257 9.82349083877449 35.6688863730252 139.74704773054228 9.82349083877449 35.668910152962226 139.7470268857226 9.82349083877449 35.66898090232122 139.74696994531257 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6fcaee61-fde0-46e9-826c-a748032a1bca">
									<gml:exterior>
										<gml:LinearRing gml:id="line_407acfc4-94be-4205-b684-95e5e27f05c5">
											<gml:posList>35.66898090232122 139.74696994531257 9.82349083877449 35.668910152962226 139.7470268857226 9.82349083877449 35.668926862691535 139.747005808151 9.82349083877449 35.66898090232122 139.74696994531257 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fb7ca30d-65f0-4aa2-909d-1c2559130372">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3cd7c086-d204-4d85-afd2-1ca9b59fdd4b">
											<gml:posList>35.66898090232122 139.74696994531257 9.82349083877449 35.668926862691535 139.747005808151 9.82349083877449 35.668932786690256 139.74699669925667 9.82349083877449 35.66898090232122 139.74696994531257 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8104d65a-7a1b-4ee9-bf26-c857e800195e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8cf8972d-81aa-401d-9ca8-01e659b2c280">
											<gml:posList>35.668932786690256 139.74699669925667 9.82349083877449 35.668926862691535 139.747005808151 9.82349083877449 35.66892611246553 139.7470049149722 9.82349083877449 35.668932786690256 139.74699669925667 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f8ce7174-9a63-4c60-b109-91ff6006f940">
									<gml:exterior>
										<gml:LinearRing gml:id="line_def8d65c-5285-4150-bfdf-cfaa127fc00b">
											<gml:posList>35.66898090232122 139.74696994531257 9.82349083877449 35.668932786690256 139.74699669925667 9.82349083877449 35.66893561413224 139.74699179529793 9.82349083877449 35.66898090232122 139.74696994531257 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7c0f8ea6-1230-4d9a-a1d2-313d3307f056">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4e038f2d-cf74-40c1-aed3-3d22ad606158">
											<gml:posList>35.66898090232122 139.74696994531257 9.82349083877449 35.66893561413224 139.74699179529793 9.82349083877449 35.668937916700926 139.74698704747524 9.82349083877449 35.66898090232122 139.74696994531257 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a1413b1b-9dd1-4f09-8dc7-a80ec6bedf84">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9c7c714f-8a7b-4c6a-9c31-5e7fbb16a8d4">
											<gml:posList>35.66898090232122 139.74696994531257 9.82349083877449 35.668937916700926 139.74698704747524 9.82349083877449 35.66893991984208 139.7469820999065 9.82349083877449 35.66898090232122 139.74696994531257 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_83077f70-49c7-4c69-87ba-2a755ae777ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b3aed3bf-b84d-44fb-aa1b-bf18fa80e53d">
											<gml:posList>35.66898090232122 139.74696994531257 9.82349083877449 35.66893991984208 139.7469820999065 9.82349083877449 35.6689714298853 139.74696475222086 9.82349083877449 35.66898090232122 139.74696994531257 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_12aaa9f4-4846-491a-afad-caae2c2fc295">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dd751750-1894-4113-a472-32dd6fe98880">
											<gml:posList>35.6689714298853 139.74696475222086 9.82349083877449 35.66893991984208 139.7469820999065 9.82349083877449 35.668969675354546 139.7469638629891 9.82349083877449 35.6689714298853 139.74696475222086 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_52b6b0ae-9a47-4750-8c2c-a2a2dfecfae5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c3ed55ba-fda9-49b2-aa4f-8021c7004c82">
											<gml:posList>35.668969675354546 139.7469638629891 9.82349083877449 35.66893991984208 139.7469820999065 9.82349083877449 35.66894161216038 139.74697698108884 9.82349083877449 35.668969675354546 139.7469638629891 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_78221c3e-46dd-45c9-a1a0-1aa5f39e9aec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ec040873-4c5b-430a-afea-d32f46bd23a7">
											<gml:posList>35.668969675354546 139.7469638629891 9.82349083877449 35.66894161216038 139.74697698108884 9.82349083877449 35.66894298418658 139.7469717201916 9.82349083877449 35.668969675354546 139.7469638629891 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4583394f-94d1-42f3-9041-1a31fd1d43d8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d94c3a31-d6d2-4a9d-8f66-47c795511491">
											<gml:posList>35.668969675354546 139.7469638629891 9.82349083877449 35.66894298418658 139.7469717201916 9.82349083877449 35.6689680894952 139.74696227510623 9.82349083877449 35.668969675354546 139.7469638629891 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_486c0db2-2803-4cf1-93b5-6d10858ee7d9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f808d62b-9c9c-469d-8557-0b16d9fa96ee">
											<gml:posList>35.6689680894952 139.74696227510623 9.82349083877449 35.66894298418658 139.7469717201916 9.82349083877449 35.66894402782738 139.74696634722534 9.82349083877449 35.6689680894952 139.74696227510623 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9c3d22ec-87ff-4708-9705-51b087ec20b2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_df2db6d1-4c47-44cd-978f-45f1fa04528c">
											<gml:posList>35.6689680894952 139.74696227510623 9.82349083877449 35.66894402782738 139.74696634722534 9.82349083877449 35.66896693673856 139.7469601029011 9.82349083877449 35.6689680894952 139.74696227510623 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a0e27814-4f5d-44b6-84fb-760c6c9676aa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a5f024f7-c8b9-4823-849e-7e8275f6d40a">
											<gml:posList>35.66896693673856 139.7469601029011 9.82349083877449 35.66894438250915 139.74696362021746 9.82349083877449 35.66894473719088 139.7469608932096 9.82349083877449 35.66896693673856 139.7469601029011 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_246f4d51-6117-4a5a-87f9-c5227d18b4cd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_196f1c79-0f41-4f9b-a83f-09110306a810">
											<gml:posList>35.66894438250915 139.74696362021746 9.82349083877449 35.66896693673856 139.7469601029011 9.82349083877449 35.66894402782738 139.74696634722534 9.82349083877449 35.66894438250915 139.74696362021746 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_64a0dc1b-d6cd-4165-9dc0-113d7438afd8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_441ec9d5-831d-4e58-9543-1ecb91ae8e1a">
											<gml:posList>35.66896693673856 139.7469601029011 9.82349083877449 35.66894473719088 139.7469608932096 9.82349083877449 35.66896639155822 139.74695764215886 9.82349083877449 35.66896693673856 139.7469601029011 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2a98aea0-adf2-4120-bb7d-70bf82398212">
									<gml:exterior>
										<gml:LinearRing gml:id="line_76d3e8e3-1ce2-4796-b534-e4a9295f3b44">
											<gml:posList>35.66896639155822 139.74695764215886 9.82349083877449 35.66894473719088 139.7469608932096 9.82349083877449 35.66894510831043 139.74695538882472 9.82349083877449 35.66896639155822 139.74695764215886 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c6a78b99-ca36-43fd-af1f-85c68720e0b9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d88e680f-a0cd-40f1-8fa2-b84f290239aa">
											<gml:posList>35.66896639155822 139.74695764215886 9.82349083877449 35.66894510831043 139.74695538882472 9.82349083877449 35.668966459159606 139.74695524699652 9.82349083877449 35.66896639155822 139.74695764215886 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a64bff69-e56e-4c4e-a93b-1470d0831a94">
									<gml:exterior>
										<gml:LinearRing gml:id="line_977c2349-118c-4fc3-b7fd-dfac9d99a9e4">
											<gml:posList>35.668966459159606 139.74695524699652 9.82349083877449 35.66894510831043 139.74695538882472 9.82349083877449 35.668945139145826 139.74694986592885 9.82349083877449 35.668966459159606 139.74695524699652 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8b17be39-6434-4904-ada7-5a05c23724a9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cba6f059-231e-45d3-99c3-84ae573a22dd">
											<gml:posList>35.66898090232122 139.74696994531257 9.82349083877449 35.6689714298853 139.74696475222086 9.82349083877449 35.668973116433335 139.74696501233024 9.82349083877449 35.66898090232122 139.74696994531257 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_21d96363-028a-43b7-b46b-8aacedd962ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e4fa14f6-bc32-4887-91e0-6605fe0fde15">
											<gml:posList>35.66898090232122 139.74696994531257 9.82349083877449 35.668973116433335 139.74696501233024 9.82349083877449 35.668974802743165 139.74696474858774 9.82349083877449 35.66898090232122 139.74696994531257 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1155e61b-201d-4e86-8543-86dcdcb6048b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_454d2dc3-f7b6-4e74-9669-a4dfc9430af5">
											<gml:posList>35.66898090232122 139.74696994531257 9.82349083877449 35.668974802743165 139.74696474858774 9.82349083877449 35.668976555995584 139.7469638555775 9.82349083877449 35.66898090232122 139.74696994531257 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5928a691-d5bd-400d-b309-a9d1a51ea1da">
									<gml:exterior>
										<gml:LinearRing gml:id="line_82b580fd-a1b8-4329-959a-6e39147af378">
											<gml:posList>35.66898090232122 139.74696994531257 9.82349083877449 35.668976555995584 139.7469638555775 9.82349083877449 35.668977187393125 139.74696322115085 9.82349083877449 35.66898090232122 139.74696994531257 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_979c02b0-e1f2-4759-b83e-34847d1691d0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_572abe0c-ec00-4142-862e-8715903ab0c4">
											<gml:posList>35.668910152962226 139.7470268857226 9.82349083877449 35.6688863730252 139.74704773054228 9.82349083877449 35.668906420829224 139.74702244222533 9.82349083877449 35.668910152962226 139.7470268857226 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ad919656-5c43-4417-a601-a69b5da2bb03">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a3f9e44b-26cd-4071-8ddd-6685e1a75d57">
											<gml:posList>35.6688863730252 139.74704773054228 9.82349083877449 35.6688635010178 139.74706690421718 9.82349083877449 35.66888242642479 139.74704303175528 9.82349083877449 35.6688863730252 139.74704773054228 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dbb97038-c8c2-4cb3-aecd-2d723960be8c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f230979d-5e5f-41af-9aa4-e0fbaca95bc7">
											<gml:posList>35.66885994949103 139.74706267576386 9.82349083877449 35.66885044045238 139.74707818747746 9.82349083877449 35.6688490060764 139.74707647993023 9.82349083877449 35.66885994949103 139.74706267576386 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_2045e93b-195e-477c-adc4-527eeb7a13f7">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_4b515546-8142-4e6c-8006-883f95ce6bb2">
											<gml:exterior>
												<gml:LinearRing gml:id="line_764b5910-6d97-4540-b939-9912ad3d7d05">
													<gml:posList>35.66894438250915 139.74696362021746 9.82349083877449 35.66894438250915 139.74696362021746 7.403500299223708 35.66894473719088 139.7469608932096 9.82349083877449 35.66894438250915 139.74696362021746 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_1c8c0465-81f3-40ca-9ecf-c90cb4f97572">
											<gml:exterior>
												<gml:LinearRing gml:id="line_8fc973a8-5f74-4ed9-9b0c-6eacbfabd85c">
													<gml:posList>35.66894473719088 139.7469608932096 9.82349083877449 35.66894438250915 139.74696362021746 7.403500299223708 35.66894473719088 139.7469608932096 7.403500299223708 35.66894473719088 139.7469608932096 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
					<bldg:opening>
						<bldg:Door gml:id="dor_70c0ae96-a4c4-4a76-a6af-db2ae720698c">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a1dc8853-f2a8-4931-bcb5-e11cb83e89ee">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a8272b19-178c-4585-970b-f1446e0db2c8">
													<gml:posList>35.668945139145826 139.74694986592885 7.403500299223708 35.668945139145826 139.74694986592885 9.82349083877449 35.66894510831043 139.74695538882472 7.403500299223708 35.668945139145826 139.74694986592885 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_6b04adbe-239f-4cdd-83a7-849eb1987f6b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2343512f-102a-4c15-a539-3db8ee88ae01">
													<gml:posList>35.66894510831043 139.74695538882472 7.403500299223708 35.668945139145826 139.74694986592885 9.82349083877449 35.66894510831043 139.74695538882472 9.82349083877449 35.66894510831043 139.74695538882472 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
					<bldg:opening>
						<bldg:Door gml:id="dor_14b8f4cc-402f-4ece-b01d-575f123ada4f">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_45f01eb6-521c-4aad-b04d-f48e04860de6">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ddf25aee-bd38-4dce-af63-58a544780ef1">
													<gml:posList>35.668945139145826 139.74694986592885 7.403500299223708 35.668944889214174 139.74694542306383 7.403500299223708 35.668944889214174 139.74694542306383 9.82349083877449 35.668945139145826 139.74694986592885 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_65affafd-9af2-434b-bac1-fee789ad0d64">
											<gml:exterior>
												<gml:LinearRing gml:id="line_707d086a-bde4-4d1b-b325-1e82dd695c43">
													<gml:posList>35.668945139145826 139.74694986592885 7.403500299223708 35.668944889214174 139.74694542306383 9.82349083877449 35.668945139145826 139.74694986592885 9.82349083877449 35.668945139145826 139.74694986592885 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
					<bldg:opening>
						<bldg:Door gml:id="dor_383d5e64-7ad6-4407-a996-557b6615b87e">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_532a366d-c8af-4076-8559-78df0fc19b2d">
											<gml:exterior>
												<gml:LinearRing gml:id="line_8c0bf8af-ae58-4a44-aff6-23ac87e8686e">
													<gml:posList>35.66894510831043 139.74695538882472 9.82349083877449 35.66894473719088 139.7469608932096 9.82349083877449 35.66894510831043 139.74695538882472 7.403500299223708 35.66894510831043 139.74695538882472 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7737930c-1954-4f5c-a1fa-01b6d61bc118">
											<gml:exterior>
												<gml:LinearRing gml:id="line_eacb7253-6b3f-4b61-bca2-4b1e3b1f4029">
													<gml:posList>35.66894510831043 139.74695538882472 7.403500299223708 35.66894473719088 139.7469608932096 9.82349083877449 35.66894473719088 139.7469608932096 7.403500299223708 35.66894510831043 139.74695538882472 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_7a8149ee-a8d5-414b-a9c7-15b80bab5c62">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_266b4c31-faf5-4e2a-832b-900f11c48ff3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_b69de438-2f64-4099-a045-cac7ac0baaa2">
													<gml:posList>35.668944180467044 139.74693889051042 7.403500299223708 35.668944180467044 139.74693889051042 9.82349083877449 35.66894482916951 139.74694435604144 7.403500299223708 35.668944180467044 139.74693889051042 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_58993f00-75b5-42da-b5d0-0830ce92b15c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_cb62fcc0-a12e-44e8-84d6-55d30c4bd859">
													<gml:posList>35.66894482916951 139.74694435604144 7.403500299223708 35.668944180467044 139.74693889051042 9.82349083877449 35.66894482916951 139.74694435604144 9.82349083877449 35.66894482916951 139.74694435604144 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_8bf168da-7ad0-4185-b65c-212605d87bab">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_2d225004-8ad6-4327-af5b-3bd29e72e9b9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_873361cf-99f2-43dc-bae8-7653cce144d0">
													<gml:posList>35.66894161216038 139.74697698108884 9.82349083877449 35.66894161216038 139.74697698108884 7.403500299223708 35.66894298418658 139.7469717201916 9.82349083877449 35.66894161216038 139.74697698108884 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_50383625-aa19-4ab7-8115-7176e9239f0a">
											<gml:exterior>
												<gml:LinearRing gml:id="line_4cb934ca-9eee-4b1e-b30d-5738c238c438">
													<gml:posList>35.66894298418658 139.7469717201916 9.82349083877449 35.66894161216038 139.74697698108884 7.403500299223708 35.66894298418658 139.7469717201916 7.403500299223708 35.66894298418658 139.7469717201916 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_ce88b699-f282-443e-bdbf-dc57cdc7c26d">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_1af3900a-ce46-4d7c-8d61-79fa236df99a">
											<gml:exterior>
												<gml:LinearRing gml:id="line_5d5d7e4c-c89c-4633-aba5-49c8888889d7">
													<gml:posList>35.66893991984208 139.7469820999065 7.403500299223708 35.66894161216038 139.74697698108884 7.403500299223708 35.66893991984208 139.7469820999065 9.82349083877449 35.66893991984208 139.7469820999065 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_5eacf559-f8a8-427f-a31e-26c456ef1847">
											<gml:exterior>
												<gml:LinearRing gml:id="line_090814f7-d7b6-44b7-b49a-e2c3c5ee066c">
													<gml:posList>35.66893991984208 139.7469820999065 9.82349083877449 35.66894161216038 139.74697698108884 7.403500299223708 35.66894161216038 139.74697698108884 9.82349083877449 35.66893991984208 139.7469820999065 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_7b77a2a0-469b-494e-8afe-7b93c3a5ec8d">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e032bfca-1c50-4076-baaa-aeffb77210e0">
											<gml:exterior>
												<gml:LinearRing gml:id="line_7576d86c-9b56-456d-ae5f-355c701f002c">
													<gml:posList>35.66894402782738 139.74696634722534 7.403500299223708 35.66894402782738 139.74696634722534 9.82349083877449 35.66894298418658 139.7469717201916 7.403500299223708 35.66894402782738 139.74696634722534 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_67ab0a6b-4010-42db-bbe1-e54204cefc73">
											<gml:exterior>
												<gml:LinearRing gml:id="line_85659552-420f-43c7-a9eb-97a52fb1635f">
													<gml:posList>35.66894298418658 139.7469717201916 7.403500299223708 35.66894402782738 139.74696634722534 9.82349083877449 35.66894298418658 139.7469717201916 9.82349083877449 35.66894298418658 139.7469717201916 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_ca045a55-a58e-4ee6-8791-c29e4ac1207d">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_36be9dbb-0833-4cc7-99c0-8ed58f354e36">
											<gml:exterior>
												<gml:LinearRing gml:id="line_23ec86a1-867a-4ac7-9353-787bbffdd0a4">
													<gml:posList>35.668932786690256 139.74699669925667 9.82349083877449 35.668932786690256 139.74699669925667 7.403500299223708 35.66893561413224 139.74699179529793 7.403500299223708 35.668932786690256 139.74699669925667 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_70906a99-f0af-41ae-8733-8f5a7a733071">
											<gml:exterior>
												<gml:LinearRing gml:id="line_18492fb8-2e92-4c71-814a-e04fe42d2fbe">
													<gml:posList>35.668932786690256 139.74699669925667 9.82349083877449 35.66893561413224 139.74699179529793 7.403500299223708 35.66893561413224 139.74699179529793 9.82349083877449 35.668932786690256 139.74699669925667 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_f9da2d14-4df0-4383-8cbd-d057d0afa13c">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e15cfa50-b5d6-40e7-a276-7911361080c4">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d3cea56b-190b-4901-a78e-f964e770558b">
													<gml:posList>35.66893351265158 139.74690874023833 9.82349083877449 35.6689360507647 139.74691330435175 9.82349083877449 35.6689360507647 139.74691330435175 7.403500299223708 35.66893351265158 139.74690874023833 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_424c5ac8-ad55-4369-8d01-385201e2b0a5">
											<gml:exterior>
												<gml:LinearRing gml:id="line_bbfa9658-3ae8-4a6d-9547-fc6f24cbf347">
													<gml:posList>35.66893351265158 139.74690874023833 9.82349083877449 35.6689360507647 139.74691330435175 7.403500299223708 35.66893351265158 139.74690874023833 7.403500299223708 35.66893351265158 139.74690874023833 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_d9a50610-f879-40cf-a177-d06e2c4aa7d6">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_df1f2578-8d2a-4a51-8d25-77a2f64821aa">
											<gml:exterior>
												<gml:LinearRing gml:id="line_52eeb5e7-7830-4ecd-b790-0e02da24f443">
													<gml:posList>35.66893991984208 139.7469820999065 9.82349083877449 35.668937916700926 139.74698704747524 9.82349083877449 35.66893991984208 139.7469820999065 7.403500299223708 35.66893991984208 139.7469820999065 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a6bf097a-31ff-4b75-a61b-fb72d6ad6fe8">
											<gml:exterior>
												<gml:LinearRing gml:id="line_937fb271-9a9e-4ff7-9c7d-f94e9063fcad">
													<gml:posList>35.66893991984208 139.7469820999065 7.403500299223708 35.668937916700926 139.74698704747524 9.82349083877449 35.668937916700926 139.74698704747524 7.403500299223708 35.66893991984208 139.7469820999065 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_5854eb52-f143-4656-b447-20454abe12ba">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d389b069-5433-45e3-80c4-a7fcc0370ae3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d1c314f6-4d11-488c-8c90-d618b323cdb2">
													<gml:posList>35.66894024802613 139.7469230706439 9.82349083877449 35.66894024802613 139.7469230706439 7.403500299223708 35.66893830020564 139.74691809025063 9.82349083877449 35.66894024802613 139.7469230706439 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_2dfea69e-5ead-4e35-9ee8-26c98a258303">
											<gml:exterior>
												<gml:LinearRing gml:id="line_baaea0a2-ed14-46b0-8cb9-fdc447012f20">
													<gml:posList>35.66893830020564 139.74691809025063 9.82349083877449 35.66894024802613 139.7469230706439 7.403500299223708 35.66893830020564 139.74691809025063 7.403500299223708 35.66893830020564 139.74691809025063 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_c36964d9-4364-40c0-ac01-e2022d3b1e83">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d0794036-b8e6-4053-9ee0-c57acb7910cf">
											<gml:exterior>
												<gml:LinearRing gml:id="line_b3c7d684-8425-4786-ab3a-236991c73e15">
													<gml:posList>35.66894024802613 139.7469230706439 7.403500299223708 35.66894024802613 139.7469230706439 9.82349083877449 35.66894188334043 139.7469282173955 7.403500299223708 35.66894024802613 139.7469230706439 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_3ebc585e-dfdd-4170-b0ad-1480aa6c74e2">
											<gml:exterior>
												<gml:LinearRing gml:id="line_328048b0-001d-47b5-8131-800e005b051d">
													<gml:posList>35.66894188334043 139.7469282173955 7.403500299223708 35.66894024802613 139.7469230706439 9.82349083877449 35.66894188334043 139.7469282173955 9.82349083877449 35.66894188334043 139.7469282173955 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_4734d521-2400-4535-8f10-298a05fbf71a">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_85beea04-54ea-4e75-baa6-d557a60cddc6">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a7b93e0c-01ec-4cae-948d-605dd05cb8fd">
													<gml:posList>35.668943196636945 139.74693350068227 7.403500299223708 35.66894188334043 139.7469282173955 7.403500299223708 35.668943196636945 139.74693350068227 9.82349083877449 35.668943196636945 139.74693350068227 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0f73dc64-b614-4530-8f08-a1a617ba3fec">
											<gml:exterior>
												<gml:LinearRing gml:id="line_85c00e8c-db39-487b-a515-bd1d33c5f702">
													<gml:posList>35.668943196636945 139.74693350068227 9.82349083877449 35.66894188334043 139.7469282173955 7.403500299223708 35.66894188334043 139.7469282173955 9.82349083877449 35.668943196636945 139.74693350068227 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_8f23b8a3-3bbb-4fe5-92c8-56dcced7a66a">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e7697ecb-dbbc-4e50-bce1-e2e5f7155f82">
											<gml:exterior>
												<gml:LinearRing gml:id="line_18aaccad-9c0c-498e-8f41-92f0bbc4e464">
													<gml:posList>35.66894402782738 139.74696634722534 7.403500299223708 35.66894438250915 139.74696362021746 7.403500299223708 35.66894438250915 139.74696362021746 9.82349083877449 35.66894402782738 139.74696634722534 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_dcba4c51-cfd4-42b6-a8a6-4f1d181f7da9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_67073d2c-9693-49e6-bcd3-f38d63d813f7">
													<gml:posList>35.66894402782738 139.74696634722534 7.403500299223708 35.66894438250915 139.74696362021746 9.82349083877449 35.66894402782738 139.74696634722534 9.82349083877449 35.66894402782738 139.74696634722534 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_ac0fd010-86ad-46f2-b142-d0aee9b24623">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_810d9c21-283c-466d-a962-504be2fff095">
											<gml:exterior>
												<gml:LinearRing gml:id="line_3d739c0d-9164-4876-86c2-147ba790a8e5">
													<gml:posList>35.66893561413224 139.74699179529793 9.82349083877449 35.66893561413224 139.74699179529793 7.403500299223708 35.668937916700926 139.74698704747524 9.82349083877449 35.66893561413224 139.74699179529793 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7bb0e566-8e67-40ad-9c26-be0528525c05">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2a074191-95a5-41f0-b896-161fdc9c6158">
													<gml:posList>35.668937916700926 139.74698704747524 9.82349083877449 35.66893561413224 139.74699179529793 7.403500299223708 35.668937916700926 139.74698704747524 7.403500299223708 35.668937916700926 139.74698704747524 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_41284b44-fbc9-4f53-ba48-e70a0e5480ac">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0c78cfe4-a99e-4e1a-b363-b359c756a181">
											<gml:exterior>
												<gml:LinearRing gml:id="line_953a6229-b5c5-4ec9-b88f-ecae080b46db">
													<gml:posList>35.668943196636945 139.74693350068227 9.82349083877449 35.668944180467044 139.74693889051042 9.82349083877449 35.668943196636945 139.74693350068227 7.403500299223708 35.668943196636945 139.74693350068227 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_f50f7ac5-c597-41dd-a72d-8a3f56e6d092">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ce939fac-e4e4-4871-918b-43a5a6f9f846">
													<gml:posList>35.668943196636945 139.74693350068227 7.403500299223708 35.668944180467044 139.74693889051042 9.82349083877449 35.668944180467044 139.74693889051042 7.403500299223708 35.668943196636945 139.74693350068227 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_2a1876ae-3aee-4554-968a-24660f5ac544">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d0a65bfc-d1f5-425f-bbd3-8a5674970c4c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_86df3471-6295-4be0-be6d-dc69da1b1e9f">
													<gml:posList>35.66893830020564 139.74691809025063 9.82349083877449 35.66893830020564 139.74691809025063 7.403500299223708 35.6689360507647 139.74691330435175 9.82349083877449 35.66893830020564 139.74691809025063 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_bb8949b1-7677-4220-ad37-f1153651aa0f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_f4c38b70-654f-41f0-abd4-75011c744241">
													<gml:posList>35.6689360507647 139.74691330435175 9.82349083877449 35.66893830020564 139.74691809025063 7.403500299223708 35.6689360507647 139.74691330435175 7.403500299223708 35.6689360507647 139.74691330435175 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_1bfa6b0a-2e05-4fd5-ab92-bed380bd8eef">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_80db9cce-9264-45e7-9740-d763ffea8640">
											<gml:exterior>
												<gml:LinearRing gml:id="line_0fce441c-9f05-44e7-8991-1ddf8e76d11d">
													<gml:posList>35.668944889214174 139.74694542306383 9.82349083877449 35.668944889214174 139.74694542306383 7.403500299223708 35.66894482916951 139.74694435604144 7.403500299223708 35.668944889214174 139.74694542306383 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_b28f322b-b027-4106-bef8-7912705dc1f5">
											<gml:exterior>
												<gml:LinearRing gml:id="line_5adf9b59-f23c-476e-987c-d3afa0dfdb71">
													<gml:posList>35.668944889214174 139.74694542306383 9.82349083877449 35.66894482916951 139.74694435604144 7.403500299223708 35.66894482916951 139.74694435604144 9.82349083877449 35.668944889214174 139.74694542306383 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_cbc805e1-e449-4cbb-8b07-29d1572e368d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a85aa1fd-7e38-4537-89e3-7cb13273898d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_21058c06-366d-4bc7-b5ab-6916a5f3fa97">
											<gml:posList>35.66877792145051 139.74712031008303 9.53999016738777 35.66878470233259 139.74713272925038 9.53999016738777 35.668760943530145 139.74710416026082 9.53999016738777 35.66877792145051 139.74712031008303 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ce1ba85c-7747-4f06-b482-640fd2d44e4d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_29f26c2b-c761-45b9-b543-d5e9f65fad10">
											<gml:posList>35.66878470233259 139.74713272925038 9.53999016738777 35.66877792145051 139.74712031008303 9.53999016738777 35.668779507307946 139.74712189813383 9.53999016738777 35.66878470233259 139.74713272925038 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_86db9533-517e-46d7-87c8-19a0b90f5f83">
									<gml:exterior>
										<gml:LinearRing gml:id="line_84dc1bf5-be0e-4880-aff8-89130201dd02">
											<gml:posList>35.66877792145051 139.74712031008303 9.53999016738777 35.668760943530145 139.74710416026082 9.53999016738777 35.668776768696695 139.7471181378808 9.53999016738777 35.66877792145051 139.74712031008303 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cceeae28-e8c3-4228-bea5-8993f5649056">
									<gml:exterior>
										<gml:LinearRing gml:id="line_96f78b3a-445c-4c52-9b93-9dbfa504a5a8">
											<gml:posList>35.668776768696695 139.7471181378808 9.53999016738777 35.668760943530145 139.74710416026082 9.53999016738777 35.66877622365711 139.74711567714314 9.53999016738777 35.668776768696695 139.7471181378808 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bff7fc74-6061-4422-93f5-8be85c3a3996">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8ea0dd94-998b-405c-9588-175d4dd3f235">
											<gml:posList>35.66877622365711 139.74711567714314 9.53999016738777 35.668760943530145 139.74710416026082 9.53999016738777 35.6687762911241 139.74711328198674 9.53999016738777 35.66877622365711 139.74711567714314 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f009875d-79e2-403d-bdd5-714109115f05">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c859041f-922d-4c31-b1d8-034a8d5192ed">
											<gml:posList>35.6687762911241 139.74711328198674 9.53999016738777 35.668760943530145 139.74710416026082 9.53999016738777 35.66877683251109 139.7471112176884 9.53999016738777 35.6687762911241 139.74711328198674 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_84f4560b-0635-4199-9dcc-7085d81416bc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e75be78c-2a83-4200-8342-cc5e246d147f">
											<gml:posList>35.66877683251109 139.7471112176884 9.53999016738777 35.668760943530145 139.74710416026082 9.53999016738777 35.66877771717241 139.74710950663706 9.53999016738777 35.66877683251109 139.7471112176884 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9dfd4387-6ad4-4245-b92c-56c1bfc5c41e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d0f8e628-3c9d-458e-a551-e6e5db9ad6c9">
											<gml:posList>35.66877771717241 139.74710950663706 9.53999016738777 35.668760943530145 139.74710416026082 9.53999016738777 35.66878004439929 139.7470950114325 9.53999016738777 35.66877771717241 139.74710950663706 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9592a788-eee9-4453-b4ac-55a0ec1a57b7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2c4cb9eb-c147-41d6-80aa-558e65ca6d0e">
											<gml:posList>35.66878004439929 139.7470950114325 9.53999016738777 35.668760943530145 139.74710416026082 9.53999016738777 35.66877394926528 139.7470877548669 9.53999016738777 35.66878004439929 139.7470950114325 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_77a7c280-2716-43ee-a31a-cc2f41226ad0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_00814a37-de68-453b-91fd-06becdf6bc97">
											<gml:posList>35.66877771717241 139.74710950663706 9.53999016738777 35.66878004439929 139.7470950114325 9.53999016738777 35.668779063956315 139.747107977459 9.53999016738777 35.66877771717241 139.74710950663706 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5896c448-8080-4b4f-b76d-e6afbf196d2c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6923a3b5-742a-4882-b9ac-da797687a6cf">
											<gml:posList>35.668779063956315 139.747107977459 9.53999016738777 35.66878004439929 139.7470950114325 9.53999016738777 35.66878085956396 139.74710688147525 9.53999016738777 35.668779063956315 139.747107977459 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0c172af9-6e50-4f89-9da2-2b4e1d224e71">
									<gml:exterior>
										<gml:LinearRing gml:id="line_16de1cb4-3fe8-42ab-a1e0-c1e5036d510a">
											<gml:posList>35.66878085956396 139.74710688147525 9.53999016738777 35.66878004439929 139.7470950114325 9.53999016738777 35.668782936659156 139.74710647826305 9.53999016738777 35.66878085956396 139.74710688147525 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ba46e76e-7640-464d-9c7c-dab2049b4319">
									<gml:exterior>
										<gml:LinearRing gml:id="line_70ec9b16-d8e3-40dd-bc3b-5878d47ed725">
											<gml:posList>35.668782936659156 139.74710647826305 9.53999016738777 35.66878004439929 139.7470950114325 9.53999016738777 35.66878501432863 139.7471068770073 9.53999016738777 35.668782936659156 139.74710647826305 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_54ffd82b-dc8e-4dc2-84ea-5b03a763a9d0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_705a57c4-90e0-459e-a0d4-03eeaad03c56">
											<gml:posList>35.66878501432863 139.7471068770073 9.53999016738777 35.66878004439929 139.7470950114325 9.53999016738777 35.66878508064132 139.74708865862158 9.53999016738777 35.66878501432863 139.7471068770073 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_79bf9b2d-9116-4d14-b7ac-bcbed634a2f0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ab57a366-6214-4d35-bada-d560a0ae3af1">
											<gml:posList>35.668822571491525 139.74709405249337 9.53999016738777 35.66878508064132 139.74708865862158 9.53999016738777 35.66879567557436 139.74707529408204 9.53999016738777 35.668822571491525 139.74709405249337 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4c2f12f8-0bfd-4059-9996-4f6dadb4b8bc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ebe21bb1-daa0-4b46-b6cf-4dbc6c8e5713">
											<gml:posList>35.66878508064132 139.74708865862158 9.53999016738777 35.668822571491525 139.74709405249337 9.53999016738777 35.66878816047488 139.7471094954069 9.53999016738777 35.66878508064132 139.74708865862158 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e0d03d86-3ba9-42c4-a448-9e833fa2c715">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c076c6e0-56a1-4e99-998b-766f4c4f5dfc">
											<gml:posList>35.668822571491525 139.74709405249337 9.53999016738777 35.66879567557436 139.74707529408204 9.53999016738777 35.66880108475844 139.7470684711207 9.53999016738777 35.668822571491525 139.74709405249337 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fff9da39-9304-4d68-bb10-b840285fa2bb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f9e07a44-f03c-460c-a3b4-4ddd566c5970">
											<gml:posList>35.66882834239515 139.74709451552772 9.53999016738777 35.66878744306315 139.74713599228184 9.53999016738777 35.668827541505635 139.7470948969734 9.53999016738777 35.66882834239515 139.74709451552772 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b56ff0f9-deeb-42d1-bdbf-51d154657aad">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aac9bcac-01f4-4174-929b-289455653a66">
											<gml:posList>35.66878744306315 139.74713599228184 9.53999016738777 35.66882834239515 139.74709451552772 9.53999016738777 35.668853181184396 139.74708145050974 9.53999016738777 35.66878744306315 139.74713599228184 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_079c3a1e-6be4-42e8-8187-02be231b6803">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fe52c8e0-95e3-4ad4-acab-9c1c6063867c">
											<gml:posList>35.668786388086765 139.74712189073566 9.53999016738777 35.66878470233259 139.74713272925038 9.53999016738777 35.66878463483299 139.74712278357183 9.53999016738777 35.668786388086765 139.74712189073566 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_053fb075-4d22-4c4a-8a75-b492790b4483">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d66b106e-21bb-44af-aced-3d7ab5b863c9">
											<gml:posList>35.66878470233259 139.74713272925038 9.53999016738777 35.668786388086765 139.74712189073566 9.53999016738777 35.66878744306315 139.74713599228184 9.53999016738777 35.66878470233259 139.74713272925038 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2323e040-8e5d-4a3a-ad2b-a2a704d10996">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3c287a85-9903-44ba-842e-519956fcb2e2">
											<gml:posList>35.66878463483299 139.74712278357183 9.53999016738777 35.66878470233259 139.74713272925038 9.53999016738777 35.668782948522754 139.74712304731034 9.53999016738777 35.66878463483299 139.74712278357183 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6974600f-5fa0-48d3-a44b-38d7b2670773">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a1acdf27-0a41-4f49-8885-dc6d7894f66b">
											<gml:posList>35.668782948522754 139.74712304731034 9.53999016738777 35.66878470233259 139.74713272925038 9.53999016738777 35.668781261837466 139.7471227871984 9.53999016738777 35.668782948522754 139.74712304731034 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_47d79847-1027-421e-a53b-1b222fe23a2c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a74dbd3e-68a8-4580-9cb9-55107bce65b9">
											<gml:posList>35.668781261837466 139.7471227871984 9.53999016738777 35.66878470233259 139.74713272925038 9.53999016738777 35.668779507307946 139.74712189813383 9.53999016738777 35.668781261837466 139.7471227871984 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9fc73364-1dcf-406b-bcb9-4856c8f6d74c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c53c8bbc-eed5-436f-8995-9fb60f5f3824">
											<gml:posList>35.668827541505635 139.7470948969734 9.53999016738777 35.66878744306315 139.74713599228184 9.53999016738777 35.66882669017441 139.74709513520645 9.53999016738777 35.668827541505635 139.7470948969734 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ea0301fe-9fe5-4a7f-9d1c-7dc03f4fe79e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1371bb6b-7391-44ca-982c-eba1cf589b2d">
											<gml:posList>35.66882669017441 139.74709513520645 9.53999016738777 35.66878744306315 139.74713599228184 9.53999016738777 35.668825814799824 139.74709521755724 9.53999016738777 35.66882669017441 139.74709513520645 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a94c7d50-1332-43f4-9d68-62388a6efa25">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f1f459fc-8e74-46f7-8e82-918587296a93">
											<gml:posList>35.66878744306315 139.74713599228184 9.53999016738777 35.668786388086765 139.74712189073566 9.53999016738777 35.668787971667804 139.7471202992769 9.53999016738777 35.66878744306315 139.74713599228184 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0a4fd5a6-b698-4805-bb17-4fee3d3e5ded">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ac2a6f22-413c-464d-a580-e9a176a3a637">
											<gml:posList>35.668825814799824 139.74709521755724 9.53999016738777 35.66878744306315 139.74713599228184 9.53999016738777 35.66882494371311 139.74709514163564 9.53999016738777 35.668825814799824 139.74709521755724 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_18bf8dbb-4101-4537-ac90-4636ec960e40">
									<gml:exterior>
										<gml:LinearRing gml:id="line_66009e1c-1d93-41d5-a02f-56bac4d359eb">
											<gml:posList>35.66882494371311 139.74709514163564 9.53999016738777 35.66878744306315 139.74713599228184 9.53999016738777 35.668824104702395 139.74709491482795 9.53999016738777 35.66882494371311 139.74709514163564 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_abb34992-4c70-4070-acab-5089e9b3937c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4cf86d51-5a51-45be-9c64-9c2ee2a58963">
											<gml:posList>35.66878744306315 139.74713599228184 9.53999016738777 35.668787971667804 139.7471202992769 9.53999016738777 35.66878912130939 139.74711812459876 9.53999016738777 35.66878744306315 139.74713599228184 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7eda74b1-a1c1-4083-96e1-6a42ddc73f66">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9cb7dc73-b7fd-460e-a266-af508b7d699a">
											<gml:posList>35.66878744306315 139.74713599228184 9.53999016738777 35.66878912130939 139.74711812459876 9.53999016738777 35.668824104702395 139.74709491482795 9.53999016738777 35.66878744306315 139.74713599228184 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bfa3fdfb-2655-4f96-8b08-fd16b65b8336">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a1724797-dd56-4f0f-a305-0c03cafff81c">
											<gml:posList>35.668824104702395 139.74709491482795 9.53999016738777 35.66878912130939 139.74711812459876 9.53999016738777 35.66878966282438 139.7471156626924 9.53999016738777 35.668824104702395 139.74709491482795 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7322168b-5b27-44ad-918f-05cda5c85ba9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_da21a540-d305-4abc-ac12-214360af647e">
											<gml:posList>35.668824104702395 139.74709491482795 9.53999016738777 35.66878966282438 139.7471156626924 9.53999016738777 35.66882332157342 139.7470945532893 9.53999016738777 35.668824104702395 139.74709491482795 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_815db495-cb15-4f3c-8724-433a236d75c9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_906ea118-b7f0-49ef-915f-e38fc73387c8">
											<gml:posList>35.66882332157342 139.7470945532893 9.53999016738777 35.66878966282438 139.7471156626924 9.53999016738777 35.668822571491525 139.74709405249337 9.53999016738777 35.66882332157342 139.7470945532893 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_00276ab2-820a-43c6-8c9d-3e30e0fc840b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1f051f54-9007-4356-b2eb-55ce53b691b4">
											<gml:posList>35.668822571491525 139.74709405249337 9.53999016738777 35.66878966282438 139.7471156626924 9.53999016738777 35.668789591927585 139.74711326768437 9.53999016738777 35.668822571491525 139.74709405249337 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a534dd64-67dc-48db-af9f-8c1c58085eb3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c5342ff8-eec1-49be-b741-bef30648db67">
											<gml:posList>35.668822571491525 139.74709405249337 9.53999016738777 35.668789591927585 139.74711326768437 9.53999016738777 35.66878904758522 139.74711120455322 9.53999016738777 35.668822571491525 139.74709405249337 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_15c11e64-46aa-4f7e-a6b1-b7b1796d27fe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6818023c-61dc-42c0-a6c6-fa7d4933058a">
											<gml:posList>35.668822571491525 139.74709405249337 9.53999016738777 35.66878904758522 139.74711120455322 9.53999016738777 35.66878816047488 139.7471094954069 9.53999016738777 35.668822571491525 139.74709405249337 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d91e52a1-26f1-46e9-8a63-29a00bdf3549">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e372e048-ba16-446b-9502-db81898d7803">
											<gml:posList>35.66878508064132 139.74708865862158 9.53999016738777 35.66878816047488 139.7471094954069 9.53999016738777 35.668786811503104 139.7471079691275 9.53999016738777 35.66878508064132 139.74708865862158 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d8d2d01a-2c6f-42dd-bcac-af9c56df012c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_04d65e2c-2c7c-4c21-8a70-866c3ceed3f7">
											<gml:posList>35.668853181184396 139.74708145050974 9.53999016738777 35.66882834239515 139.74709451552772 9.53999016738777 35.66882907126424 139.74709401162417 9.53999016738777 35.668853181184396 139.74708145050974 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3c471a8d-2958-46b3-ba00-47e3f888124d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3c982615-c867-48e4-8e1c-1069544cfae4">
											<gml:posList>35.668853181184396 139.74708145050974 9.53999016738777 35.66882907126424 139.74709401162417 9.53999016738777 35.66882958792571 139.74709352800622 9.53999016738777 35.668853181184396 139.74708145050974 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_82225e50-2396-44ed-bb4d-321bf0909cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e3fc493b-500c-4279-a97f-b1c8508b13ec">
											<gml:posList>35.668853181184396 139.74708145050974 9.53999016738777 35.66882958792571 139.74709352800622 9.53999016738777 35.6688490060764 139.74707647993023 9.53999016738777 35.668853181184396 139.74708145050974 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8f5c9831-1ff3-49cd-91d5-f8e460083941">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0aea17a1-3557-4d78-af23-8415be5a884e">
											<gml:posList>35.6688490060764 139.74707647993023 9.53999016738777 35.66882958792571 139.74709352800622 9.53999016738777 35.66884596938364 139.74707286444294 9.53999016738777 35.6688490060764 139.74707647993023 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_61cea21e-657a-44c8-8947-c99cde9f6611">
									<gml:exterior>
										<gml:LinearRing gml:id="line_951a3f64-e052-45a1-bae5-0e476ad26639">
											<gml:posList>35.66878508064132 139.74708865862158 9.53999016738777 35.668786811503104 139.7471079691275 9.53999016738777 35.66878501432863 139.7471068770073 9.53999016738777 35.66878508064132 139.74708865862158 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0166_p1035_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1035_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1035_0">
											<gml:posList>35.66899900196845 139.74695670343104 26.15145925 35.66889688074204 139.74683438267795 26.14600944 35.66889050757248 139.74684222867023 26.1457586 35.66889267634999 139.74684490399287 26.14587437 35.66887603447342 139.74686516429955 26.14521881 35.668970430573786 139.7469803148041 26.15026787 35.66899900196845 139.74695670343104 26.15145925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0166_p1034_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1034_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1034_1">
											<gml:posList>35.6688926304082 139.74684489551566 38.34587328 35.66887016924144 139.74681718827335 38.34467518 35.66876276782651 139.74694794164992 38.34046315 35.668756384275575 139.74694006713696 38.34012301 35.66870324369607 139.7470195574062 38.33814279 35.66872605177402 139.74704769264488 38.33935936 35.6688926304082 139.74684489551566 38.34587328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_122d0327-fa23-4611-ac47-8595b39d7749">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_45c2f95d-7ce2-4741-90b0-daa6f4d8158a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0c19596c-fd10-45f5-a3f2-26e694a4e03e">
											<gml:posList>35.668889870133086 139.74684841169682 27.38849328018074 35.66899423701073 139.74695888167824 27.38849328018074 35.66889403751255 139.74683839604 27.38849328018074 35.668889870133086 139.74684841169682 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a6b69821-a7eb-4379-98a7-bceab4e68d9c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_50020038-7b14-48f6-a171-f3f5ca677e23">
											<gml:posList>35.66899423701073 139.74695888167824 27.38849328018074 35.668889870133086 139.74684841169682 27.38849328018074 35.66896268365045 139.7469850610783 27.38849328018074 35.66899423701073 139.74695888167824 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e1c75e84-d060-48fa-8dcd-de1037d172ab">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d2ff9bc1-f11f-40fd-bef1-0348db8f8fe3">
											<gml:posList>35.66896268365045 139.7469850610783 27.38849328018074 35.668889870133086 139.74684841169682 27.38849328018074 35.66886984293583 139.74687342411445 27.38849328018074 35.66896268365045 139.7469850610783 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ec36079d-b310-4967-8871-3ac24d0e3f5f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ec10e149-de69-40fc-a67c-f25d443cdee4">
											<gml:posList>35.668889870133086 139.74684841169682 27.38849328018074 35.66889403751255 139.74683839604 27.38849328018074 35.668887907687 139.74684605176202 27.38849328018074 35.668889870133086 139.74684841169682 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_63b6b178-66d6-42b4-8e4b-26f1614cd9d2">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4dcb7791-294d-4cb2-ae84-d49c3a59ac03">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5ced6cbf-0ee4-464e-bf73-134987566308">
											<gml:posList>35.66885665916082 139.74688988975828 36.27749321914558 35.6687388262778 139.74703705329827 36.27749321914558 35.66893889005837 139.74698876866609 36.27749321914558 35.66885665916082 139.74688988975828 36.27749321914558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e5f91db5-1869-43c4-b3bc-da1f3b546009">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bccf4cf2-bf6d-4d27-8443-43908c82af1c">
											<gml:posList>35.66893889005837 139.74698876866609 36.27749321914558 35.6687388262778 139.74703705329827 36.27749321914558 35.66879674790133 139.74710670173926 36.27749321914558 35.66893889005837 139.74698876866609 36.27749321914558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0166_p1037_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1037_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1037_0">
											<gml:posList>35.66872773938575 139.74704565299632 35.51942466 35.668793803877804 139.74712624247397 35.52295442 35.668970395136704 139.74698030808736 35.53026702 35.66887599917553 139.74686515775207 35.52521798 35.66872773938575 139.74704565299632 35.51942466</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_58ec1efa-cfd3-4124-8316-9dd67a17c35d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cace2828-fed4-49d0-a66c-e660596939e3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_29f8759d-21a7-41be-98ae-4247229b3354">
											<gml:posList>35.66893889005837 139.74698876866609 33.88324425674324 35.66886984293583 139.74687342411445 33.88324425674324 35.66885665916082 139.74688988975828 33.88324425674324 35.66893889005837 139.74698876866609 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6395a1a9-4c47-4980-8de9-1f09a9fbc4ac">
									<gml:exterior>
										<gml:LinearRing gml:id="line_719ca54e-86d7-4a17-8aa9-ca6b0d718dd1">
											<gml:posList>35.66886984293583 139.74687342411445 33.88324425674324 35.66893889005837 139.74698876866609 33.88324425674324 35.66896268365045 139.7469850610783 33.88324425674324 35.66886984293583 139.74687342411445 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_66554aff-54bc-4cf3-b858-fc2ef5b6578d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fc0098c9-41ad-49da-976d-deef370e7752">
											<gml:posList>35.66878793408452 139.74713004786625 33.88324425674324 35.66893889005837 139.74698876866609 33.88324425674324 35.66879674790133 139.74710670173926 33.88324425674324 35.66878793408452 139.74713004786625 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4de63487-73bf-477a-aa95-163647a7422d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_73121e2c-0b95-4685-b582-d0475e71e81b">
											<gml:posList>35.66893889005837 139.74698876866609 33.88324425674324 35.66878793408452 139.74713004786625 33.88324425674324 35.66896268365045 139.7469850610783 33.88324425674324 35.66893889005837 139.74698876866609 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9e54f7f5-00c6-4fb6-98f3-611a0f08ef33">
									<gml:exterior>
										<gml:LinearRing gml:id="line_65404c56-4317-4eab-8864-bbc48afb0c8c">
											<gml:posList>35.66878793408452 139.74713004786625 33.88324425674324 35.66879674790133 139.74710670173926 33.88324425674324 35.66872502845572 139.74705440645425 33.88324425674324 35.66878793408452 139.74713004786625 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f8653643-80f8-4835-883b-641e4c5a50fe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1eb959d7-e17f-416a-98c5-608978cfd83c">
											<gml:posList>35.66872502845572 139.74705440645425 33.88324425674324 35.66879674790133 139.74710670173926 33.88324425674324 35.668728509383584 139.74704993834914 33.88324425674324 35.66872502845572 139.74705440645425 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_12df8e71-2d53-4332-ab07-62ca9ea6a559">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6404ec75-600e-49aa-989a-ccbf61f8d24b">
											<gml:posList>35.668728509383584 139.74704993834914 33.88324425674324 35.66879674790133 139.74710670173926 33.88324425674324 35.6687388262778 139.74703705329827 33.88324425674324 35.668728509383584 139.74704993834914 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_4b8bb2d4-e49f-4f8d-ba96-71d8b2646f39">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_00f3efb9-1b78-4b16-86f2-f00a4c88ce17">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a05d40b4-6086-40fb-b16e-ee92d84f4fd0">
											<gml:posList>35.668861190555496 139.74681392574468 39.04224083877449 35.66870207904577 139.74701815687015 39.04224083877449 35.668889870133086 139.74684841169682 39.04224083877449 35.668861190555496 139.74681392574468 39.04224083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e6fbd2dd-e20b-4005-9cb9-c858c1deb2af">
									<gml:exterior>
										<gml:LinearRing gml:id="line_06593313-db95-44cb-8fb8-a63da76b407c">
											<gml:posList>35.668889870133086 139.74684841169682 39.04224083877449 35.66870207904577 139.74701815687015 39.04224083877449 35.668728509383584 139.74704993834914 39.04224083877449 35.668889870133086 139.74684841169682 39.04224083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0166_p1034_6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1034_6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1034_6">
											<gml:posList>35.6688926304082 139.74684489551566 38.34587328 35.66872605177402 139.74704769264488 38.33935936 35.66872617351469 139.74704771630016 5.78422376 35.66872785058888 139.74704567459315 5.78428881 35.66872773938575 139.74704565299632 35.51942466 35.66887599917553 139.74686515775207 35.52521798 35.66887603447342 139.74686516429955 26.14521881 35.66889267634999 139.74684490399287 26.14587437 35.6688926304082 139.74684489551566 38.34587328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_bf944c52-a3de-43b2-a291-137a22b5a5bb">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_63a1abcc-8bc2-4bd6-83bd-3bafa9892939">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e13f973a-3dfd-4f60-9115-f316d6e3a2a8">
											<gml:posList>35.66882464767257 139.74709506155605 7.334240655669021 35.668824104702395 139.74709491482795 9.53999016738777 35.668824104702395 139.74709491482795 7.334240655669021 35.66882464767257 139.74709506155605 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6888884b-e1d0-4c9e-871a-e1f36bd437de">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8c50093c-ecb3-42e5-ab3d-7e6c4b6925b7">
											<gml:posList>35.668824104702395 139.74709491482795 9.53999016738777 35.66882464767257 139.74709506155605 7.334240655669021 35.66882494371311 139.74709514163564 9.53999016738777 35.668824104702395 139.74709491482795 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_607c8aaa-e304-4414-9dc2-482b3494dbe8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fe5bf667-edaf-4ab1-935e-f7350631871d">
											<gml:posList>35.66882494371311 139.74709514163564 7.169247369536208 35.66882464767257 139.74709506155605 7.334240655669021 35.66882464767257 139.74709506155605 7.169247369536208 35.66882494371311 139.74709514163564 7.169247369536208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b457f44b-8b46-4dd4-bbbb-8ed3a69295bb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_55507c98-b685-4231-8d57-71697c47219d">
											<gml:posList>35.66882464767257 139.74709506155605 7.334240655669021 35.66882494371311 139.74709514163564 7.169247369536208 35.66882494371311 139.74709514163564 9.53999016738777 35.66882464767257 139.74709506155605 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7ed1aff2-19f6-43bc-8dc7-d59bb24d722e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_47d7ff37-77d2-476d-9d77-672a706bb8ee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_808c6f01-5aad-47cc-b2d6-3eb67bb1b948">
											<gml:posList>35.66877622365711 139.74711567714314 7.334240655669021 35.668776768696695 139.7471181378808 7.334240655669021 35.66877622365711 139.74711567714314 9.53999016738777 35.66877622365711 139.74711567714314 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0596d3d0-be7e-481e-a70f-ea8450ad7654">
									<gml:exterior>
										<gml:LinearRing gml:id="line_994a55b2-cf2f-42fa-9d79-4eec85a9bd61">
											<gml:posList>35.66877622365711 139.74711567714314 9.53999016738777 35.668776768696695 139.7471181378808 7.334240655669021 35.668776768696695 139.7471181378808 9.53999016738777 35.66877622365711 139.74711567714314 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7341e8b4-4c2f-4527-83df-f5b078a0393d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_10687453-96b9-4b31-a50e-4b7edf38d2c5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_92403226-5df2-4c1e-aad0-b1f394120343">
											<gml:posList>35.668906415466786 139.74686830662048 9.82349083877449 35.668906415466786 139.74686830662048 7.403500299223708 35.668861190555496 139.74681392574468 9.82349083877449 35.668906415466786 139.74686830662048 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_963ba6cc-0719-4f69-a707-316010c1d73f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d4e6f5cf-826d-4b58-9c18-7bb7725a573a">
											<gml:posList>35.668861190555496 139.74681392574468 9.82349083877449 35.668906415466786 139.74686830662048 7.403500299223708 35.668861190555496 139.74681392574468 7.403500299223708 35.668861190555496 139.74681392574468 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_febeac03-f74d-4436-9871-0fbea4933056">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e3c5ec38-cf9d-4ca3-b88f-0f4c3f96ce9b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c51034d4-f539-47f4-94df-65ff269c58ae">
											<gml:posList>35.66878816047488 139.7471094954069 7.334240655669021 35.668786811503104 139.7471079691275 7.334240655669021 35.66878816047488 139.7471094954069 9.53999016738777 35.66878816047488 139.7471094954069 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1db0f71a-d285-4772-a273-8572f02db73f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_988658ef-3074-42d7-9c3d-ad3be4e1f85e">
											<gml:posList>35.66878816047488 139.7471094954069 9.53999016738777 35.668786811503104 139.7471079691275 7.334240655669021 35.668786811503104 139.7471079691275 9.53999016738777 35.66878816047488 139.7471094954069 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_3da5d048-44b6-407b-9d69-36959b4d4a62">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_46924451-665f-459b-9bef-e41d1527d539">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f5c5f5b3-4316-4466-94ec-201935a4b0d1">
											<gml:posList>35.66888242642479 139.74704303175528 7.540844659575271 35.6688635010178 139.74706690421718 7.540844659575271 35.66888242642479 139.74704303175528 6.862499933012771 35.66888242642479 139.74704303175528 7.540844659575271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3b2eb3a4-01e0-4ebd-9e28-0ad691dca758">
									<gml:exterior>
										<gml:LinearRing gml:id="line_54c00107-3361-4875-bd27-f99f8d6bbd47">
											<gml:posList>35.66888242642479 139.74704303175528 6.862499933012771 35.6688635010178 139.74706690421718 7.540844659575271 35.6688635010178 139.74706690421718 6.862499933012771 35.66888242642479 139.74704303175528 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_520aff9e-2dd9-4129-8b38-7795bed7c89c">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_5758ecf7-9169-40f5-965e-3aec1bfa8315">
											<gml:exterior>
												<gml:LinearRing gml:id="line_6a0f1a9f-fdf0-4c40-affd-e1b66a40cd1d">
													<gml:posList>35.66888242642479 139.74704303175528 7.540844659575271 35.66888242642479 139.74704303175528 9.32349846816902 35.6688635010178 139.74706690421718 7.540844659575271 35.66888242642479 139.74704303175528 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ac099cf6-665a-4d51-a3bd-9d25d4932674">
											<gml:exterior>
												<gml:LinearRing gml:id="line_60d24b3c-ba51-4ac6-9f16-ab4de7997bdc">
													<gml:posList>35.6688635010178 139.74706690421718 7.540844659575271 35.66888242642479 139.74704303175528 9.32349846816902 35.6688635010178 139.74706690421718 9.32349846816902 35.6688635010178 139.74706690421718 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_db7b1a88-4f74-4555-a683-2580b8d580c0">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8d54133e-934d-4b9f-ac22-756b8555c3c7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bfbb0498-1856-44ad-ae52-0a1b65056299">
											<gml:posList>35.66882464767257 139.74709506155605 7.334240655669021 35.66878247531512 139.74713005137525 7.334240655669021 35.66882464767257 139.74709506155605 7.169247369536208 35.66882464767257 139.74709506155605 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_88f7798d-ec03-4d8f-b9ac-7b7402825b35">
									<gml:exterior>
										<gml:LinearRing gml:id="line_31e9fce4-76ee-441c-8882-b80bc236a2b0">
											<gml:posList>35.66882464767257 139.74709506155605 7.169247369536208 35.66878247531512 139.74713005137525 7.334240655669021 35.66878247531512 139.74713005137525 7.169247369536208 35.66882464767257 139.74709506155605 7.169247369536208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_540e3606-73eb-464d-94b7-c669dc860cee">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eda1a2b6-bb9d-4050-b5b9-0e557d3853dc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a6123bb8-54f5-4b6b-8d40-34bed64ac768">
											<gml:posList>35.66888242642479 139.74704303175528 9.32349846816902 35.6688863730252 139.74704773054228 9.32349846816902 35.66888242642479 139.74704303175528 9.82349083877449 35.66888242642479 139.74704303175528 9.32349846816902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d0707d20-dcef-4786-905a-72f95bd20098">
									<gml:exterior>
										<gml:LinearRing gml:id="line_47e7e526-dabd-4ba5-bbc1-56f6f15a32a4">
											<gml:posList>35.66888242642479 139.74704303175528 9.82349083877449 35.6688863730252 139.74704773054228 9.32349846816902 35.6688863730252 139.74704773054228 9.82349083877449 35.66888242642479 139.74704303175528 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1f4a4b70-d92e-4792-83c7-353768a7eac2">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aaa4a429-18ad-407e-99fa-b21d2838082b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a1240e41-46a9-45db-96b6-fc79dd833463">
											<gml:posList>35.668906420829224 139.74702244222533 9.32349846816902 35.668910152962226 139.7470268857226 9.32349846816902 35.668906420829224 139.74702244222533 9.82349083877449 35.668906420829224 139.74702244222533 9.32349846816902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4f9812ee-6374-4027-ab14-03e8f245422f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9dd4c969-3301-4d28-9cb8-e61ee1d0b76e">
											<gml:posList>35.668906420829224 139.74702244222533 9.82349083877449 35.668910152962226 139.7470268857226 9.32349846816902 35.668910152962226 139.7470268857226 9.82349083877449 35.668906420829224 139.74702244222533 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_51518eb9-739f-43fd-98be-bca9b3f9d332">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7639d46e-a1a4-451a-8a45-def70ce56b76">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e28d9122-3200-413b-a977-1034bbff24b1">
													<gml:posList>35.668910152962226 139.7470268857226 7.540844659575271 35.668910152962226 139.7470268857226 9.32349846816902 35.668906420829224 139.74702244222533 9.32349846816902 35.668910152962226 139.7470268857226 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_35150210-62dc-45a9-b054-9064d98b9975">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ceafcaf7-5c1e-4c27-ab2d-c7528bee72ba">
													<gml:posList>35.668910152962226 139.7470268857226 7.540844659575271 35.668906420829224 139.74702244222533 9.32349846816902 35.668906420829224 139.74702244222533 7.540844659575271 35.668910152962226 139.7470268857226 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a2f16584-7d3a-4aff-b9c0-71c47fbdad0c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_69b7aa15-3e73-46c4-bf22-d8cec1ec8c73">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ef48d32f-7481-4be7-b08e-ebb61a031bad">
											<gml:posList>35.66877792145051 139.74712031008303 7.334240655669021 35.668779507307946 139.74712189813383 7.334240655669021 35.66877792145051 139.74712031008303 9.53999016738777 35.66877792145051 139.74712031008303 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ccf31957-1a05-4af9-92e6-628595ae2c9d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_44738294-c807-4692-88df-ae4168d37608">
											<gml:posList>35.66877792145051 139.74712031008303 9.53999016738777 35.668779507307946 139.74712189813383 7.334240655669021 35.668779507307946 139.74712189813383 9.53999016738777 35.66877792145051 139.74712031008303 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_8a3aaa75-d301-4898-ae69-ff82a1f9dbe6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fb6dc0e7-0a4b-4d12-b5ef-07aa43ac24d1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bc081052-f2ac-44ae-89ce-6dfeb62db2c2">
											<gml:posList>35.668826681301006 139.74709714870576 7.005749444731521 35.668825604352556 139.74709519924318 7.005749444731521 35.668826681301006 139.74709714870576 7.169247369536208 35.668826681301006 139.74709714870576 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e04b240e-0d61-435f-b0ad-6a903e93eebd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9fca9766-b089-4be1-8f14-f05c646b623d">
											<gml:posList>35.668826681301006 139.74709714870576 7.169247369536208 35.668825604352556 139.74709519924318 7.005749444731521 35.668825604352556 139.74709519924318 7.169247369536208 35.668826681301006 139.74709714870576 7.169247369536208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_61934fab-552c-4ec7-8803-1a4d40bdb944">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b514aaaa-3558-425c-9c0c-8b4d0c1d431f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_08494704-66ab-456c-95ea-4b21b022b995">
											<gml:posList>35.668853181184396 139.74708145050974 10.527806024321364 35.66878744306315 139.74713599228184 10.527806024321364 35.668853181184396 139.74708145050974 9.53999016738777 35.668853181184396 139.74708145050974 10.527806024321364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d2504de6-aaa7-4892-a4cb-807f46b45878">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4a9b129f-95ba-4b84-8bc6-331e3fa05384">
											<gml:posList>35.668853181184396 139.74708145050974 9.53999016738777 35.66878744306315 139.74713599228184 10.527806024321364 35.66878744306315 139.74713599228184 9.53999016738777 35.668853181184396 139.74708145050974 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_f98fac1d-1735-43dd-b2e1-b4598788b8bf">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6d42433f-cd18-49ad-b129-2c4c431ef884">
									<gml:exterior>
										<gml:LinearRing gml:id="line_289b5510-ffd2-4777-8068-ff7d76812121">
											<gml:posList>35.668782948522754 139.74712304731034 7.334240655669021 35.66878463483299 139.74712278357183 7.334240655669021 35.668782948522754 139.74712304731034 9.53999016738777 35.668782948522754 139.74712304731034 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_675af024-0504-4265-9bcf-e8bea28b6349">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8780eaa8-3521-4bdc-a924-9de652772ada">
											<gml:posList>35.668782948522754 139.74712304731034 9.53999016738777 35.66878463483299 139.74712278357183 7.334240655669021 35.66878463483299 139.74712278357183 9.53999016738777 35.668782948522754 139.74712304731034 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_5ef9c76b-4fdb-4caa-b75f-344061b665ae">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f072672c-fd81-49fa-a6cc-7e9bf8a77813">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7ff4ffea-e92a-4ec0-873b-0ef822fa3afd">
											<gml:posList>35.6688863730252 139.74704773054228 9.32349846816902 35.668906420829224 139.74702244222533 9.32349846816902 35.6688863730252 139.74704773054228 9.82349083877449 35.6688863730252 139.74704773054228 9.32349846816902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_063d4663-9a72-47e9-b8d0-94b25282cb18">
									<gml:exterior>
										<gml:LinearRing gml:id="line_04e11098-1939-42a2-a032-4205bf0a856b">
											<gml:posList>35.6688863730252 139.74704773054228 9.82349083877449 35.668906420829224 139.74702244222533 9.32349846816902 35.668906420829224 139.74702244222533 9.82349083877449 35.6688863730252 139.74704773054228 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_2c86974d-9f4c-43de-9f48-f27d7ed9c4ee">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d20eca30-5714-4a57-bdce-3ee2959c9e76">
											<gml:exterior>
												<gml:LinearRing gml:id="line_b0bfd397-58fc-4b6f-8488-edfedeec38b2">
													<gml:posList>35.668906420829224 139.74702244222533 7.540844659575271 35.668906420829224 139.74702244222533 9.32349846816902 35.6688863730252 139.74704773054228 9.32349846816902 35.668906420829224 139.74702244222533 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_983597ab-9548-4889-a522-4bd02b5dc59c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_40bf78a7-eeaf-42e1-b956-3d4760138021">
													<gml:posList>35.668906420829224 139.74702244222533 7.540844659575271 35.6688863730252 139.74704773054228 9.32349846816902 35.6688863730252 139.74704773054228 7.540844659575271 35.668906420829224 139.74702244222533 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_af96fe16-590d-47d1-9ae8-e0e65821679e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_66d422ce-3684-476a-9bca-3e4ec9523c7a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_623cbe87-466f-499f-ab52-0a2d74a9fc97">
											<gml:posList>35.66898256682945 139.74694484884185 11.427670221098708 35.66897777473761 139.7469508339763 13.130490045317458 35.66897777473761 139.7469508339763 9.82349083877449 35.66898256682945 139.74694484884185 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d005ec81-4e33-4be9-9a5f-fa437ca2312a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_95da30d8-8e5c-4580-a979-d6946946a92e">
											<gml:posList>35.66897777473761 139.7469508339763 13.130490045317458 35.66898256682945 139.74694484884185 11.427670221098708 35.66898256682945 139.74694484884185 13.130490045317458 35.66897777473761 139.7469508339763 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c269a38c-4e98-4f75-81d0-f13bbfac44f7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_62d84c36-5b57-4bac-b431-5686cf9b9a79">
											<gml:posList>35.66898256682945 139.74694484884185 11.427670221098708 35.66897777473761 139.7469508339763 9.82349083877449 35.66898256682945 139.74694484884185 9.82349083877449 35.66898256682945 139.74694484884185 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_d409d8f9-0aa6-4d4f-912d-40d7708f5fdf">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9f2c463b-0ead-47b6-bb3b-b5d64afa2b09">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f5bf528a-5572-44ac-bd65-6ad7a2dedd47">
											<gml:posList>35.66882907126424 139.74709401162417 9.53999016738777 35.66882907126424 139.74709401162417 7.005749444731521 35.66882958792571 139.74709352800622 9.53999016738777 35.66882907126424 139.74709401162417 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_67e0bdc6-9561-4a85-8348-9f12f20d15d3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_921f2229-e79a-4a8a-b222-c2cb16ef7d0b">
											<gml:posList>35.66882958792571 139.74709352800622 9.53999016738777 35.66882907126424 139.74709401162417 7.005749444731521 35.66882958792571 139.74709352800622 7.005749444731521 35.66882958792571 139.74709352800622 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a0415d5e-51ee-462f-bde2-b88fa5b51a3f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d2d9c3aa-3e37-4c1b-9494-242c62c98ff3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_66f10c41-8450-4d3e-a152-165e768641c8">
											<gml:posList>35.668976555995584 139.7469638555775 9.82349083877449 35.668974802743165 139.74696474858774 9.82349083877449 35.668976555995584 139.7469638555775 7.403500299223708 35.668976555995584 139.7469638555775 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_275de563-5c37-41aa-bdea-d989d4aa06e6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7f9bfe16-5dc3-4251-9fd9-1034d529e4fa">
											<gml:posList>35.668976555995584 139.7469638555775 7.403500299223708 35.668974802743165 139.74696474858774 9.82349083877449 35.668974802743165 139.74696474858774 7.403500299223708 35.668976555995584 139.7469638555775 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0166_p1034_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1034_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1034_4">
											<gml:posList>35.668756384275575 139.74694006713696 38.34012301 35.66876276782651 139.74694794164992 38.34046315 35.66876288975531 139.74694796479653 5.78532755 35.668756506171626 139.74694009024327 5.78498741 35.668756384275575 139.74694006713696 38.34012301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_950a7a24-130e-4836-a284-4479aff55f3a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_999aeeac-034c-4a84-88f5-c2250d8cee6e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a16943e3-a321-47a6-8291-e9f901896da9">
											<gml:posList>35.66882834239515 139.74709451552772 7.005749444731521 35.66882907126424 139.74709401162417 7.005749444731521 35.66882907126424 139.74709401162417 9.53999016738777 35.66882834239515 139.74709451552772 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ed852d28-0b26-4703-baa6-72a953f05ef4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a744e755-d396-4a7a-9640-35589fa596df">
											<gml:posList>35.66882834239515 139.74709451552772 7.005749444731521 35.66882907126424 139.74709401162417 9.53999016738777 35.66882834239515 139.74709451552772 9.53999016738777 35.66882834239515 139.74709451552772 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7d61da1c-87dd-4a6c-8766-5630ac42db8b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1a4bb48d-d615-443f-9ad7-214266c748ad">
									<gml:exterior>
										<gml:LinearRing gml:id="line_08388292-18a0-4ae3-b749-9480501eafa1">
											<gml:posList>35.66899003625884 139.74695670803658 26.006245355376052 35.66899003625884 139.74695670803658 13.130490045317458 35.66898976631845 139.74695504929335 26.006245355376052 35.66899003625884 139.74695670803658 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_89dc6b87-53b3-4875-841e-f92c4c7c9458">
									<gml:exterior>
										<gml:LinearRing gml:id="line_00c345c9-48bb-4291-8ac9-2422747b7e85">
											<gml:posList>35.66898976631845 139.74695504929335 26.006245355376052 35.66899003625884 139.74695670803658 13.130490045317458 35.66898976631845 139.74695504929335 13.130490045317458 35.66898976631845 139.74695504929335 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a5de4b29-0100-4942-9996-c8b49473bad3">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_403b1f89-5a53-4301-badb-2f8b3f3bf28f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3e8dc00e-47a4-4570-ba90-169f838a2183">
											<gml:posList>35.668906420829224 139.74702244222533 7.540844659575271 35.6688863730252 139.74704773054228 7.540844659575271 35.668906420829224 139.74702244222533 6.862499933012771 35.668906420829224 139.74702244222533 7.540844659575271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3df4f652-3508-4d8d-bfee-6f7803e84399">
									<gml:exterior>
										<gml:LinearRing gml:id="line_499eed38-cc36-41d4-ad20-6b068dc3e4ca">
											<gml:posList>35.668906420829224 139.74702244222533 6.862499933012771 35.6688863730252 139.74704773054228 7.540844659575271 35.6688863730252 139.74704773054228 6.862499933012771 35.668906420829224 139.74702244222533 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c9cc6ba7-c160-46d6-8ddc-702f50042a7e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_21a11183-4d35-450b-a59b-b34b35635f03">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f9a9eeeb-52f9-4f0b-87cc-f9fcb93759d9">
											<gml:posList>35.668990043134045 139.74695843128058 26.006245355376052 35.668990043134045 139.74695843128058 13.130490045317458 35.66899003625884 139.74695670803658 26.006245355376052 35.668990043134045 139.74695843128058 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1dcdab39-30cc-420e-af35-213b336889f2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a0992b5e-d324-42eb-b733-b7fbd713c1ee">
											<gml:posList>35.66899003625884 139.74695670803658 26.006245355376052 35.668990043134045 139.74695843128058 13.130490045317458 35.66899003625884 139.74695670803658 13.130490045317458 35.66899003625884 139.74695670803658 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_0f0ba0aa-7c75-4f19-972c-e45c852c232e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e1c9f409-e7a7-4102-9fe3-c11a87fd9a1c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_83744d1d-11cb-45bd-966a-7fc91fa86934">
											<gml:posList>35.66878966282438 139.7471156626924 7.334240655669021 35.668789591927585 139.74711326768437 7.334240655669021 35.66878966282438 139.7471156626924 9.53999016738777 35.66878966282438 139.7471156626924 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1c400695-f943-48bd-8d2e-37bc90eae4ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c6679ff5-cd12-4a29-b29f-ac5abc550a12">
											<gml:posList>35.66878966282438 139.7471156626924 9.53999016738777 35.668789591927585 139.74711326768437 7.334240655669021 35.668789591927585 139.74711326768437 9.53999016738777 35.66878966282438 139.7471156626924 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_9b9894c6-80de-405b-a16a-4ff8878aa798">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e419b488-aef8-4acb-823e-ed8515c4c926">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e79e3dd9-6ed6-4279-a51b-c68db9642250">
											<gml:posList>35.668825604352556 139.74709519924318 7.169247369536208 35.66882494371311 139.74709514163564 9.53999016738777 35.66882494371311 139.74709514163564 7.169247369536208 35.668825604352556 139.74709519924318 7.169247369536208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3c4e2af8-45d2-4f91-8b64-6032c7733293">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e04a36b4-b2e9-4e59-bce6-8ac38f78cba0">
											<gml:posList>35.66882494371311 139.74709514163564 9.53999016738777 35.668825604352556 139.74709519924318 7.169247369536208 35.668825814799824 139.74709521755724 9.53999016738777 35.66882494371311 139.74709514163564 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0d1e98b6-f772-4aab-b1dc-19b127618fbd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9dfe39df-dea4-4ca9-b98c-d830e488b0b7">
											<gml:posList>35.668825814799824 139.74709521755724 7.005749444731521 35.668825604352556 139.74709519924318 7.169247369536208 35.668825604352556 139.74709519924318 7.005749444731521 35.668825814799824 139.74709521755724 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c3933c9e-4157-407b-898a-03d75dbfc84e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_30664b40-91c6-4a1b-8682-10aa14cca6bf">
											<gml:posList>35.668825604352556 139.74709519924318 7.169247369536208 35.668825814799824 139.74709521755724 7.005749444731521 35.668825814799824 139.74709521755724 9.53999016738777 35.668825604352556 139.74709519924318 7.169247369536208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e64dd7ce-e238-4cda-9d25-15914b1ad53e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0a8b9cb1-ed14-4744-8884-e3e3f2bd3ff8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2ae25af1-efc9-4857-b18e-5aaea0ab4d40">
											<gml:posList>35.66898090232122 139.74696994531257 11.427670221098708 35.668977187393125 139.74696322115085 13.130490045317458 35.66898090232122 139.74696994531257 13.130490045317458 35.66898090232122 139.74696994531257 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9401c5ea-cebc-4923-98f7-3bb5b39ecabe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_348eec67-f7b9-4430-bb08-5ce416db7c33">
											<gml:posList>35.668977187393125 139.74696322115085 13.130490045317458 35.66898090232122 139.74696994531257 11.427670221098708 35.668977187393125 139.74696322115085 9.82349083877449 35.668977187393125 139.74696322115085 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cd98210e-bc75-4d0d-802c-16beff19c474">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5da9a778-0bc4-442d-9177-905a6d62bd14">
											<gml:posList>35.668977187393125 139.74696322115085 9.82349083877449 35.66898090232122 139.74696994531257 11.427670221098708 35.66898090232122 139.74696994531257 9.82349083877449 35.668977187393125 139.74696322115085 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_4566b387-64bc-45cb-b909-1ce24be2ae96">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bd93266f-c8e0-4dfd-b9ca-c3d03fcb6646">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f0f8f7d6-261f-4bae-84ac-0a8ec6af4a56">
											<gml:posList>35.66896639155822 139.74695764215886 9.82349083877449 35.668966459159606 139.74695524699652 9.82349083877449 35.66896639155822 139.74695764215886 7.403500299223708 35.66896639155822 139.74695764215886 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_43cf823d-49b1-456a-8e32-2c2ab39482e9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7a8a9dbb-1484-4740-985e-d5ba6e3fe656">
											<gml:posList>35.66896639155822 139.74695764215886 7.403500299223708 35.668966459159606 139.74695524699652 9.82349083877449 35.668966459159606 139.74695524699652 7.403500299223708 35.66896639155822 139.74695764215886 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c7fe983c-fdf0-45aa-be4b-bd0b20e85cee">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c9271af6-13e5-4087-9c0e-437e28b1d7c1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1d019963-fd5e-4d36-bb89-f8f81b0c94de">
											<gml:posList>35.668910152962226 139.7470268857226 9.32349846816902 35.668926862691535 139.747005808151 9.32349846816902 35.668910152962226 139.7470268857226 9.82349083877449 35.668910152962226 139.7470268857226 9.32349846816902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_53c1fbe3-48d4-4873-92d6-2dce129eec76">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0a533eb4-788b-4995-ac5f-eed95c96803b">
											<gml:posList>35.668910152962226 139.7470268857226 9.82349083877449 35.668926862691535 139.747005808151 9.32349846816902 35.668926862691535 139.747005808151 9.82349083877449 35.668910152962226 139.7470268857226 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e25fdf7e-e4ef-4698-9df9-9e748f50b179">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_270a2c00-afcd-4a66-9bf4-ee64600b853b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_94c01b62-c19b-492a-b839-cb4ea3709caf">
											<gml:posList>35.668827541505635 139.7470948969734 7.005749444731521 35.66882834239515 139.74709451552772 7.005749444731521 35.668827541505635 139.7470948969734 9.53999016738777 35.668827541505635 139.7470948969734 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_754ce5d5-184d-477a-8780-422a12e1b63a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a40d9896-9479-4cdc-a2ed-5f2e8d83871d">
											<gml:posList>35.668827541505635 139.7470948969734 9.53999016738777 35.66882834239515 139.74709451552772 7.005749444731521 35.66882834239515 139.74709451552772 9.53999016738777 35.668827541505635 139.7470948969734 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c27d45bc-6a60-44c0-8343-c5836825de08">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5cbea044-6a50-45f6-a14e-c449dcdac44a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_078b90ca-4f1c-4975-970e-5d6e38ae97bf">
											<gml:posList>35.66898780317941 139.74695114527066 26.006245355376052 35.668988593976614 139.7469522258331 26.006245355376052 35.66898780317941 139.74695114527066 13.130490045317458 35.66898780317941 139.74695114527066 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_61d04ae4-d962-4fa3-90cd-8c60cfa2226d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_31beb4c2-1c80-4ee9-9984-b56f09291d7b">
											<gml:posList>35.66898780317941 139.74695114527066 13.130490045317458 35.668988593976614 139.7469522258331 26.006245355376052 35.668988593976614 139.7469522258331 13.130490045317458 35.66898780317941 139.74695114527066 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_3b5185f0-2383-410f-8d28-79ec18da061c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a4a7bcf1-c52a-4cff-8c37-5946cefea7be">
									<gml:exterior>
										<gml:LinearRing gml:id="line_824cea88-51a7-42a1-8854-6755e10823c7">
											<gml:posList>35.66893889005837 139.74698876866609 33.88324425674324 35.66893889005837 139.74698876866609 36.27749321914558 35.66879674790133 139.74710670173926 36.27749321914558 35.66893889005837 139.74698876866609 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1006b66a-c84f-4b7e-8d15-fd68d6ff8a36">
									<gml:exterior>
										<gml:LinearRing gml:id="line_224265aa-2f8b-4f10-99f5-e3b46142bc06">
											<gml:posList>35.66893889005837 139.74698876866609 33.88324425674324 35.66879674790133 139.74710670173926 36.27749321914558 35.66879674790133 139.74710670173926 33.88324425674324 35.66893889005837 139.74698876866609 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0166_p1037_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1037_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1037_3">
											<gml:posList>35.668970395136704 139.74698030808736 35.53026702 35.668970430573786 139.7469803148041 26.15026787 35.66887603447342 139.74686516429955 26.14521881 35.66887599917553 139.74686515775207 35.52521798 35.668970395136704 139.74698030808736 35.53026702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_9d3dc515-1e9d-4c8e-b8b6-5bcff6808035">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_de3847e9-16af-4fd6-8606-87b5b5eb21d9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8cffec23-a2e3-47cf-9b65-716c7ba70c30">
											<gml:posList>35.668779063956315 139.747107977459 7.334240655669021 35.66877771717241 139.74710950663706 7.334240655669021 35.668779063956315 139.747107977459 9.53999016738777 35.668779063956315 139.747107977459 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a0711f0e-ef27-46c2-978e-ab6b0b5d3c65">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5d7bceb8-821e-46de-87c1-d1284d1d8bfc">
											<gml:posList>35.668779063956315 139.747107977459 9.53999016738777 35.66877771717241 139.74710950663706 7.334240655669021 35.66877771717241 139.74710950663706 9.53999016738777 35.668779063956315 139.747107977459 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_9950a273-ec48-45da-b592-3298ef5c846c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_28900b4a-6308-4159-90d1-3297c9fbd3ad">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8d0ba045-3dbd-46d0-b461-ce28203a3928">
											<gml:posList>35.668887907687 139.74684605176202 11.427670221098708 35.668887907687 139.74684605176202 27.38849328018074 35.66889403751255 139.74683839604 11.427670221098708 35.668887907687 139.74684605176202 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b7aab4e-8811-44f5-8655-48b8df8c1e61">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c8690751-a859-44aa-9be3-aff5a462568f">
											<gml:posList>35.66889403751255 139.74683839604 11.427670221098708 35.668887907687 139.74684605176202 27.38849328018074 35.66889403751255 139.74683839604 27.38849328018074 35.66889403751255 139.74683839604 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e5b1708f-93e5-4fa2-890e-e9f4d72ded38">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e1606bf5-09ce-4e8c-b8c1-92e6ff15b9f5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b49da20a-0656-461e-8bcc-561b23b5609f">
											<gml:posList>35.66878501432863 139.7471068770073 7.334240655669021 35.668782936659156 139.74710647826305 7.334240655669021 35.66878501432863 139.7471068770073 9.53999016738777 35.66878501432863 139.7471068770073 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_786877c9-fda2-4e7d-8d39-5911ff4d7ee1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9a3e9a79-e5ff-43d3-a7f4-ec179df361fd">
											<gml:posList>35.66878501432863 139.7471068770073 9.53999016738777 35.668782936659156 139.74710647826305 7.334240655669021 35.668782936659156 139.74710647826305 9.53999016738777 35.66878501432863 139.7471068770073 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_cff70fc9-9208-45fa-bf67-dbec43f41ae5">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_05b0b2dc-d12c-489a-9733-fca7b17c9b0a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f83a21ab-742f-471f-90f5-97e388b858a4">
											<gml:posList>35.66878508064132 139.74708865862158 7.334240655669021 35.66878508064132 139.74708865862158 9.53999016738777 35.66878004439929 139.7470950114325 7.334240655669021 35.66878508064132 139.74708865862158 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c33a2e9d-e47f-4c23-84cf-ef834d07461d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_02b4a788-87be-45ac-9e0e-e739498cb827">
											<gml:posList>35.66878004439929 139.7470950114325 7.334240655669021 35.66878508064132 139.74708865862158 9.53999016738777 35.66878004439929 139.7470950114325 9.53999016738777 35.66878004439929 139.7470950114325 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_38de3ae3-6ef6-4aef-82b8-022ef33c5b1d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_90f02b09-0797-44ce-8177-29bbe826bc3b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2d57f86d-db79-43b7-8c19-5e56a2e47937">
											<gml:posList>35.6688635010178 139.74706690421718 7.540844659575271 35.66885994949103 139.74706267576386 7.540844659575271 35.6688635010178 139.74706690421718 6.862499933012771 35.6688635010178 139.74706690421718 7.540844659575271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_002afdb6-9730-4c20-8efb-87dee4076453">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d32edfbb-83e6-42bc-b217-55daae37a4af">
											<gml:posList>35.6688635010178 139.74706690421718 6.862499933012771 35.66885994949103 139.74706267576386 7.540844659575271 35.66885994949103 139.74706267576386 6.862499933012771 35.6688635010178 139.74706690421718 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0166_p1037_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1037_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1037_1">
											<gml:posList>35.66879391538999 139.74712626444614 5.78781859 35.66899907896092 139.74695671793145 5.79632261 35.66899900196845 139.74695670343104 26.15145925 35.668970430573786 139.7469803148041 26.15026787 35.668970395136704 139.74698030808736 35.53026702 35.668793803877804 139.74712624247397 35.52295442 35.66879391538999 139.74712626444614 5.78781859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_14445673-e073-4c11-8673-b46f8d3ec47b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_783e9d2b-8afb-4036-b453-93c73bbe464f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0cffcad3-19ea-4487-98a5-e36a8fe77809">
											<gml:posList>35.668989778898485 139.7469601238035 26.006245355376052 35.668989778898485 139.7469601238035 13.130490045317458 35.668990043134045 139.74695843128058 26.006245355376052 35.668989778898485 139.7469601238035 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_32841516-ec62-472b-9573-36cbd545d77c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_19921e8c-dde8-4e8d-95c5-bc9074d150be">
											<gml:posList>35.668990043134045 139.74695843128058 26.006245355376052 35.668989778898485 139.7469601238035 13.130490045317458 35.668990043134045 139.74695843128058 13.130490045317458 35.668990043134045 139.74695843128058 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_79775fdc-2479-4ced-9892-bcdf4190e21a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fb1f8213-05ee-4cce-a3e3-d59b1462aa63">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6b42a428-24cb-4bb8-bfe5-9dce69d3382f">
											<gml:posList>35.66898780317941 139.74695114527066 13.130490045317458 35.668987423382646 139.74695068857324 16.297390680083083 35.668987423382646 139.74695068857324 17.862324456938552 35.66898780317941 139.74695114527066 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c2e2d870-7373-4563-a376-bd6a78c73ab6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8ec5d864-4a71-48b2-924c-d896949a34d1">
											<gml:posList>35.668987423382646 139.74695068857324 16.297390680083083 35.66898780317941 139.74695114527066 13.130490045317458 35.668987423382646 139.74695068857324 14.63159630752449 35.668987423382646 139.74695068857324 16.297390680083083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1ebc5109-7c07-42d2-ab94-b5a70a52e6b9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3d118ed1-19c7-4f78-8cf3-4a4da0302955">
											<gml:posList>35.66898780317941 139.74695114527066 13.130490045317458 35.668987423382646 139.74695068857324 17.862324456938552 35.668987423382646 139.74695068857324 19.528118829497146 35.66898780317941 139.74695114527066 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_22bb66bb-c0ae-457e-97a5-a7ecac6c0984">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d339c44f-0e51-4073-bcae-effea0e94250">
											<gml:posList>35.66898780317941 139.74695114527066 13.130490045317458 35.668987423382646 139.74695068857324 19.528118829497146 35.66898780317941 139.74695114527066 26.006245355376052 35.66898780317941 139.74695114527066 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f6165428-08ec-4b9e-8270-c61c40426978">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0b96fc2a-3274-4b4c-975a-643a9b280213">
											<gml:posList>35.66898780317941 139.74695114527066 26.006245355376052 35.668987423382646 139.74695068857324 19.528118829497146 35.668987423382646 139.74695068857324 21.093052606352614 35.66898780317941 139.74695114527066 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8217fc22-e724-4bc6-9f3e-fbb0f8dfb154">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b51edbde-8639-487e-855d-aef6e9ac583a">
											<gml:posList>35.66898780317941 139.74695114527066 26.006245355376052 35.668987423382646 139.74695068857324 21.093052606352614 35.668987423382646 139.74695068857324 22.75884697891121 35.66898780317941 139.74695114527066 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a1fdaea5-0a94-4e9e-8866-ffd60089a2e4">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dd2ef206-8e88-4d01-b9d9-59554d93d46a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d91e0842-b2a5-4abe-856a-50ce16ba9dc6">
											<gml:posList>35.668969675354546 139.7469638629891 7.403500299223708 35.668969675354546 139.7469638629891 9.82349083877449 35.6689680894952 139.74696227510623 7.403500299223708 35.668969675354546 139.7469638629891 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_15a4d3f9-dbfe-439c-9b6f-3d44e34c1c88">
									<gml:exterior>
										<gml:LinearRing gml:id="line_110fd9b9-00a3-4dd0-a62f-854d9d290acb">
											<gml:posList>35.6689680894952 139.74696227510623 7.403500299223708 35.668969675354546 139.7469638629891 9.82349083877449 35.6689680894952 139.74696227510623 9.82349083877449 35.6689680894952 139.74696227510623 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_019f0c13-79fd-48a2-8376-c9c1cd2cae0f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c8443b46-cff1-4e9a-9042-bf7b03fa8cab">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aa4c10af-9ffe-474d-a454-ab518fbe15bc">
											<gml:posList>35.668979215479894 139.74695316936445 7.403500299223708 35.668979215479894 139.74695316936445 13.130490045317458 35.66897975982506 139.74695523266797 7.403500299223708 35.668979215479894 139.74695316936445 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1210f4c1-146e-43fe-91ec-cb1345c04e2d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_25b26a5a-9417-4c1c-9793-276bfc0b0db5">
											<gml:posList>35.66897975982506 139.74695523266797 7.403500299223708 35.668979215479894 139.74695316936445 13.130490045317458 35.66897975982506 139.74695523266797 13.130490045317458 35.66897975982506 139.74695523266797 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_0ebbb45a-5105-426f-87e8-3b729106253a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a4b5532d-dabb-4168-a37c-54be518a7dfc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0c00a471-d07d-47b2-9ebc-60c70d37ad72">
											<gml:posList>35.66886984293583 139.74687342411445 27.55450890518074 35.66896268365045 139.7469850610783 27.55450890518074 35.66886984293583 139.74687342411445 27.38849328018074 35.66886984293583 139.74687342411445 27.55450890518074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4c9367a1-7130-43fd-bf3b-3d125988d700">
									<gml:exterior>
										<gml:LinearRing gml:id="line_da8c549b-a177-40b9-b150-2ff2ed7364f8">
											<gml:posList>35.66886984293583 139.74687342411445 27.38849328018074 35.66896268365045 139.7469850610783 27.55450890518074 35.66896268365045 139.7469850610783 27.38849328018074 35.66886984293583 139.74687342411445 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e89b5982-998c-4395-a64e-cbafbe856c39">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f993bed8-c8ca-484d-b511-4c64e01bb540">
									<gml:exterior>
										<gml:LinearRing gml:id="line_44ea5a1a-62fc-4c0f-9b9b-6574c5f39ba8">
											<gml:posList>35.668910152962226 139.7470268857226 6.862499933012771 35.668926862691535 139.747005808151 7.403500299223708 35.668910152962226 139.7470268857226 7.540844659575271 35.668910152962226 139.7470268857226 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a5f9b948-c4d6-4748-9721-673f7d7cac6a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_668d21c4-5835-4db1-a62e-9635711de9db">
											<gml:posList>35.668926862691535 139.747005808151 7.403500299223708 35.668910152962226 139.7470268857226 6.862499933012771 35.668926862691535 139.747005808151 6.862499933012771 35.668926862691535 139.747005808151 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9c808957-c31c-4d68-9c95-b30ede0b3787">
									<gml:exterior>
										<gml:LinearRing gml:id="line_215d371c-c31b-4fcf-acbb-1372d491b93d">
											<gml:posList>35.668910152962226 139.7470268857226 7.540844659575271 35.668926862691535 139.747005808151 7.403500299223708 35.668926862691535 139.747005808151 7.540844659575271 35.668910152962226 139.7470268857226 7.540844659575271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_1d8a790e-36ac-4e23-a029-7a6760356de9">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e55f3692-7df3-493f-98e7-acaf334d42a3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_745198e3-1671-4103-b2e1-7e7f2b83d9ae">
													<gml:posList>35.668926862691535 139.747005808151 7.540844659575271 35.668926862691535 139.747005808151 9.32349846816902 35.668910152962226 139.7470268857226 7.540844659575271 35.668926862691535 139.747005808151 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_cf69dd22-0b1f-4d3f-9a2f-40bf909771f7">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e30087bb-afdf-438b-9b91-072e1604fa63">
													<gml:posList>35.668910152962226 139.7470268857226 7.540844659575271 35.668926862691535 139.747005808151 9.32349846816902 35.668910152962226 139.7470268857226 9.32349846816902 35.668910152962226 139.7470268857226 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_751a2ae4-9204-452b-9dfd-8635d84aac22">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dbc66202-ee36-40e0-a764-c391f20660dc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a663d36a-4a61-4296-b8dc-201f40454962">
											<gml:posList>35.668973104547945 139.7469484432437 9.82349083877449 35.66897518235527 139.7469488418161 9.82349083877449 35.66897518235527 139.7469488418161 7.403500299223708 35.668973104547945 139.7469484432437 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_382e4e0a-9a7e-40cc-ae72-7a2fb2feea3e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_21faf896-941d-4306-bb50-b4dd33277cef">
											<gml:posList>35.668973104547945 139.7469484432437 9.82349083877449 35.66897518235527 139.7469488418161 7.403500299223708 35.668973104547945 139.7469484432437 7.403500299223708 35.668973104547945 139.7469484432437 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0166_p1037_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1037_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1037_2">
											<gml:posList>35.668793803877804 139.74712624247397 35.52295442 35.66872773938575 139.74704565299632 35.51942466 35.66872785058888 139.74704567459315 5.78428881 35.66879391538999 139.74712626444614 5.78781859 35.668793803877804 139.74712624247397 35.52295442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_3273f0be-5861-463b-8c64-99b8c341d2a7">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_347cd4ce-3959-4353-9cc2-9ee52ecb30b9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_07f74fd8-9d3d-4cbb-a9b3-1487b31b9284">
											<gml:posList>35.66893717061708 139.74699998782526 7.028240899809646 35.668928215025566 139.74700741819677 6.862499933012771 35.66893717061708 139.74699998782526 6.862499933012771 35.66893717061708 139.74699998782526 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_77580377-df63-4283-8792-f1de720c524c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6a5235c2-a08f-4478-8e5c-0e94406d1d85">
											<gml:posList>35.668928215025566 139.74700741819677 6.862499933012771 35.66893717061708 139.74699998782526 7.028240899809646 35.668928215025566 139.74700741819677 7.403500299223708 35.668928215025566 139.74700741819677 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_262cd248-ddd2-41e2-99ec-6c27b4e14480">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a09258ab-27d8-4789-aef5-40e6238ec1c1">
											<gml:posList>35.668928215025566 139.74700741819677 7.403500299223708 35.66893962092371 139.74699795500794 7.193997125395583 35.668975702115844 139.74696801882962 7.193997125395583 35.668928215025566 139.74700741819677 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3bbb24d1-924e-4b9a-96ea-eb2c3724e842">
									<gml:exterior>
										<gml:LinearRing gml:id="line_49eada3d-e168-49cc-91e9-19afb174649d">
											<gml:posList>35.66893962092371 139.74699795500794 7.193997125395583 35.668928215025566 139.74700741819677 7.403500299223708 35.66893717061708 139.74699998782526 7.028240899809646 35.66893962092371 139.74699795500794 7.193997125395583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_daa67583-5cbf-46bc-aeca-514143e5b922">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cef1b1df-cf2f-4750-bc1e-dfa6a841e5fd">
											<gml:posList>35.668928215025566 139.74700741819677 7.403500299223708 35.668975702115844 139.74696801882962 7.193997125395583 35.66899116587438 139.74695518886168 7.403500299223708 35.668928215025566 139.74700741819677 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0d20d44d-d947-4d72-9d4b-4f101c6c7a98">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0422b065-9595-413a-b126-c6d5fd102eac">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.668975702115844 139.74696801882962 7.193997125395583 35.6689780460303 139.7469660742764 7.028240899809646 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bece02e9-1d4c-4ffc-8184-c9bb72020a26">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5c7f1d45-fbdd-460e-843d-07c331fab6a5">
											<gml:posList>35.6689780460303 139.7469660742764 7.028240899809646 35.668975702115844 139.74696801882962 7.193997125395583 35.668975702115844 139.74696801882962 7.028240899809646 35.6689780460303 139.7469660742764 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5e8996be-da8c-47b5-a479-ca22ee006512">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a70bcae1-2aa3-47ca-ac90-33f33b76d92c">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.6689780460303 139.7469660742764 7.028240899809646 35.66899116587438 139.74695518886168 6.862499933012771 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8bc0efab-a2c3-4fbd-b0e3-d5037a75d3e9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9c4fc09b-6193-4c5d-adf6-8828ae8f02ca">
											<gml:posList>35.66899116587438 139.74695518886168 6.862499933012771 35.6689780460303 139.7469660742764 7.028240899809646 35.6689780460303 139.7469660742764 6.862499933012771 35.66899116587438 139.74695518886168 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4b647e63-f9c6-4d11-acbd-1708eab8ce95">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a5a0e3c1-951d-49ad-9a37-ca1cda42b08a">
											<gml:posList>35.66893962092371 139.74699795500794 7.193997125395583 35.66893717061708 139.74699998782526 7.028240899809646 35.66893962092371 139.74699795500794 7.028240899809646 35.66893962092371 139.74699795500794 7.193997125395583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c2495196-f5a8-4561-897e-96a6294afae9">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_53d6e832-e425-4d9d-989c-3406e376527a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e822fdd4-cfbe-4d4d-96a8-af651580cf57">
											<gml:posList>35.668977187393125 139.74696322115085 9.82349083877449 35.668976555995584 139.7469638555775 7.403500299223708 35.66897813957459 139.74696226428037 7.403500299223708 35.668977187393125 139.74696322115085 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8df2a477-62d8-44e6-a233-b04886b72950">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bd7623f9-7345-43a0-9fde-6b0757281f26">
											<gml:posList>35.668976555995584 139.7469638555775 7.403500299223708 35.668977187393125 139.74696322115085 9.82349083877449 35.668976555995584 139.7469638555775 9.82349083877449 35.668976555995584 139.7469638555775 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1db1c7fc-9786-4c82-9df4-e17b65bae284">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ba4f1a55-c7a3-4629-aadd-b8d4e5f4a37d">
											<gml:posList>35.668977187393125 139.74696322115085 9.82349083877449 35.66897813957459 139.74696226428037 7.403500299223708 35.66897813957459 139.74696226428037 13.130490045317458 35.668977187393125 139.74696322115085 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_158459f6-aead-408d-bd19-52a7b87a2970">
									<gml:exterior>
										<gml:LinearRing gml:id="line_87152fe6-a1d7-4d61-a4a6-257abcb6b17c">
											<gml:posList>35.668977187393125 139.74696322115085 9.82349083877449 35.66897813957459 139.74696226428037 13.130490045317458 35.668977187393125 139.74696322115085 13.130490045317458 35.668977187393125 139.74696322115085 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_55fae024-a7cf-4c28-ba0e-ff474ac8de29">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_63b9ab0e-be7e-4a6b-8c9e-b57b1c4eac68">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7d7cc675-6987-4236-a121-1c30df1856fe">
											<gml:posList>35.66896693673856 139.7469601029011 9.82349083877449 35.66896639155822 139.74695764215886 9.82349083877449 35.66896693673856 139.7469601029011 7.403500299223708 35.66896693673856 139.7469601029011 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9c050ae6-795e-4d59-9f6c-5f0f38284833">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e1ef078c-10ee-4458-9f93-80df58847236">
											<gml:posList>35.66896693673856 139.7469601029011 7.403500299223708 35.66896639155822 139.74695764215886 9.82349083877449 35.66896639155822 139.74695764215886 7.403500299223708 35.66896693673856 139.7469601029011 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_5eb29278-1a6d-4651-80a7-589bf1c89c70">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_38e6fd0d-5b1d-4208-8499-3ca961335a0d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_979a48ea-b0cc-4d76-97bb-137c08ac864d">
											<gml:posList>35.668887907687 139.74684605176202 27.38849328018074 35.668861190555496 139.74681392574468 11.427670221098708 35.668861190555496 139.74681392574468 39.04224083877449 35.668887907687 139.74684605176202 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5f8bd96f-c06f-441f-b5e5-504c0cc1787c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c3603be6-4d94-4200-9de9-9f4fced83581">
											<gml:posList>35.668861190555496 139.74681392574468 11.427670221098708 35.668887907687 139.74684605176202 27.38849328018074 35.668887907687 139.74684605176202 11.427670221098708 35.668861190555496 139.74681392574468 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4e1efab1-71e8-48cc-b865-84a073f0ab8d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_910bb3af-76aa-42d7-b676-0bb66c69753e">
											<gml:posList>35.668887907687 139.74684605176202 27.38849328018074 35.668861190555496 139.74681392574468 39.04224083877449 35.668889870133086 139.74684841169682 39.04224083877449 35.668887907687 139.74684605176202 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_adf09f33-d38f-4755-b9c8-972007907b22">
									<gml:exterior>
										<gml:LinearRing gml:id="line_489a06ae-c40c-49ed-a9c3-646c407cbb6c">
											<gml:posList>35.668887907687 139.74684605176202 27.38849328018074 35.668889870133086 139.74684841169682 39.04224083877449 35.668889870133086 139.74684841169682 27.38849328018074 35.668887907687 139.74684605176202 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_fd76cc5f-ce5e-4c7a-9a39-a37b5335e097">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a7c632bc-2431-488f-b4be-5f8b85a439ef">
									<gml:exterior>
										<gml:LinearRing gml:id="line_78ba25dd-7a1a-49ff-a8ea-182e84918c92">
											<gml:posList>35.66886984293583 139.74687342411445 33.88324425674324 35.668889870133086 139.74684841169682 39.04224083877449 35.66885665916082 139.74688988975828 36.27749321914558 35.66886984293583 139.74687342411445 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0f17b503-99b1-4a1e-912b-e62696f8614b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_61aecb51-fd67-42e8-a82e-828ba5cdc119">
											<gml:posList>35.668889870133086 139.74684841169682 39.04224083877449 35.66886984293583 139.74687342411445 33.88324425674324 35.668889870133086 139.74684841169682 27.38849328018074 35.668889870133086 139.74684841169682 39.04224083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3a16a51c-2ebf-4865-b127-6ffae15bcc0b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_42f51549-82a6-4fb1-8595-481731798c61">
											<gml:posList>35.66885665916082 139.74688988975828 36.27749321914558 35.668889870133086 139.74684841169682 39.04224083877449 35.668728509383584 139.74704993834914 39.04224083877449 35.66885665916082 139.74688988975828 36.27749321914558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3561025d-e7ca-45a1-a114-d540be2158ed">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a9286a3c-e1d3-4edf-a280-7757942bd3d3">
											<gml:posList>35.668889870133086 139.74684841169682 27.38849328018074 35.66886984293583 139.74687342411445 33.88324425674324 35.66886984293583 139.74687342411445 32.451023797758864 35.668889870133086 139.74684841169682 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_090f4287-0dce-4350-954a-e005b7e48201">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2aa1e6c0-5c8b-47f5-a992-c2d2b6ed0db2">
											<gml:posList>35.66886984293583 139.74687342411445 33.88324425674324 35.66885665916082 139.74688988975828 36.27749321914558 35.66885665916082 139.74688988975828 33.88324425674324 35.66886984293583 139.74687342411445 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_28d816ca-1ba2-4b36-b459-88b6cf9fcfa1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_92903378-23a9-434f-9bd4-f025743c0f6d">
											<gml:posList>35.66885665916082 139.74688988975828 36.27749321914558 35.668728509383584 139.74704993834914 39.04224083877449 35.6687388262778 139.74703705329827 36.27749321914558 35.66885665916082 139.74688988975828 36.27749321914558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_21fae298-76d3-4717-b3b0-d7485dac99b8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4d3e9ceb-abe1-46e0-aaf4-172ebd62af95">
											<gml:posList>35.6687388262778 139.74703705329827 36.27749321914558 35.668728509383584 139.74704993834914 39.04224083877449 35.668728509383584 139.74704993834914 33.88324425674324 35.6687388262778 139.74703705329827 36.27749321914558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9058e256-be43-49fd-af62-d34bafeeb274">
									<gml:exterior>
										<gml:LinearRing gml:id="line_90def3d8-038c-46a7-beb2-f56e17555713">
											<gml:posList>35.66886984293583 139.74687342411445 27.55450890518074 35.668889870133086 139.74684841169682 27.38849328018074 35.66886984293583 139.74687342411445 29.220295648344802 35.66886984293583 139.74687342411445 27.55450890518074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7ac73259-5690-438a-bf12-68332c49db2f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d06fe6df-e032-4255-b473-365f8947b0e8">
											<gml:posList>35.668889870133086 139.74684841169682 27.38849328018074 35.66886984293583 139.74687342411445 27.55450890518074 35.66886984293583 139.74687342411445 27.38849328018074 35.668889870133086 139.74684841169682 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d9c46e33-b2f2-4aaf-b68a-abd3d50e1a39">
									<gml:exterior>
										<gml:LinearRing gml:id="line_416f4f02-1bed-4f8f-96ee-61b732509196">
											<gml:posList>35.66886984293583 139.74687342411445 29.220295648344802 35.668889870133086 139.74684841169682 27.38849328018074 35.66886984293583 139.74687342411445 30.785237054594802 35.66886984293583 139.74687342411445 29.220295648344802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9676fbd1-b2d0-4d02-8547-2c94aa6cb19d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0fce0149-184b-41cc-91eb-23a9069973e2">
											<gml:posList>35.66886984293583 139.74687342411445 30.785237054594802 35.668889870133086 139.74684841169682 27.38849328018074 35.66886984293583 139.74687342411445 32.451023797758864 35.66886984293583 139.74687342411445 30.785237054594802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ca7450ae-b573-4a12-a64d-bc0a2fe65794">
									<gml:exterior>
										<gml:LinearRing gml:id="line_125da4f6-65d8-4df2-a532-91d053f3a8ba">
											<gml:posList>35.6687388262778 139.74703705329827 36.27749321914558 35.668728509383584 139.74704993834914 33.88324425674324 35.6687388262778 139.74703705329827 33.88324425674324 35.6687388262778 139.74703705329827 36.27749321914558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_4ec00780-06f6-4b24-b3b7-7515119f44ce">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a44fa756-dd1b-4e81-a39c-ad128a1dbd1f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3354b7ca-80dc-4e85-b853-a4f2f386829f">
											<gml:posList>35.668903594190766 139.7468718303237 7.403500299223708 35.668906415466786 139.74686830662048 7.403500299223708 35.668903594190766 139.7468718303237 9.82349083877449 35.668903594190766 139.7468718303237 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d2c9c7bf-7296-4c51-8f44-bfa98ededd8e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_64729fe7-e7f4-4366-8c78-1450863eb246">
											<gml:posList>35.668903594190766 139.7468718303237 9.82349083877449 35.668906415466786 139.74686830662048 7.403500299223708 35.668906415466786 139.74686830662048 9.82349083877449 35.668903594190766 139.7468718303237 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_3c07b9f8-4ff7-42fa-afd3-7398f9371cf2">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d0411067-e4ed-438a-ad07-987d171a2e46">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fa134b20-dfb5-4695-b5ea-6c639858dea7">
											<gml:posList>35.668910152962226 139.7470268857226 7.540844659575271 35.668906420829224 139.74702244222533 7.540844659575271 35.668910152962226 139.7470268857226 6.862499933012771 35.668910152962226 139.7470268857226 7.540844659575271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7cba646c-a30a-40fd-ac86-ccfc5c85282a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2c8b8695-11c1-422d-bacc-ba195bf9dd96">
											<gml:posList>35.668910152962226 139.7470268857226 6.862499933012771 35.668906420829224 139.74702244222533 7.540844659575271 35.668906420829224 139.74702244222533 6.862499933012771 35.668910152962226 139.7470268857226 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_3966a609-9d7a-4db9-841f-cfed23fc8c89">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9098d845-fa55-4c70-a5c2-408ace5325a5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1a1849cd-9682-4d2f-85a3-942c5c06c2d3">
											<gml:posList>35.66896268365045 139.7469850610783 29.220295648344802 35.66886984293583 139.74687342411445 29.220295648344802 35.66886984293583 139.74687342411445 30.785237054594802 35.66896268365045 139.7469850610783 29.220295648344802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3d4df037-c685-4426-98c4-52f55323e36b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_656cdc99-c9bf-4dfd-992b-7eab7af98ebd">
											<gml:posList>35.66896268365045 139.7469850610783 29.220295648344802 35.66886984293583 139.74687342411445 30.785237054594802 35.66896268365045 139.7469850610783 30.785237054594802 35.66896268365045 139.7469850610783 29.220295648344802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_0f1a9e15-c86b-4154-aabd-ad65868226cf">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_60af26fa-d1b2-4f77-83d1-c446e7e58078">
											<gml:exterior>
												<gml:LinearRing gml:id="line_131a41f5-30dd-4843-833e-0804c701a812">
													<gml:posList>35.66896268365045 139.7469850610783 29.220295648344802 35.66896268365045 139.7469850610783 27.55450890518074 35.66886984293583 139.74687342411445 29.220295648344802 35.66896268365045 139.7469850610783 29.220295648344802</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_724ef00d-cb6d-4843-9e4c-5f32311c6b55">
											<gml:exterior>
												<gml:LinearRing gml:id="line_5cc1d54f-3cc1-4f19-80f4-bf007af80a39">
													<gml:posList>35.66886984293583 139.74687342411445 29.220295648344802 35.66896268365045 139.7469850610783 27.55450890518074 35.66886984293583 139.74687342411445 27.55450890518074 35.66886984293583 139.74687342411445 29.220295648344802</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_19d40c7f-6e41-4755-9ac6-bf44d419bdac">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0569995d-2594-4f0e-b3e0-f6f132a601a5">
											<gml:exterior>
												<gml:LinearRing gml:id="line_5ffb75f7-3914-4a3d-950b-34a32b3c29ab">
													<gml:posList>35.66886984293583 139.74687342411445 30.785237054594802 35.66886984293583 139.74687342411445 32.451023797758864 35.66896268365045 139.7469850610783 30.785237054594802 35.66886984293583 139.74687342411445 30.785237054594802</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ddd4c59a-ab57-4f53-8a05-d7d2d2e085a4">
											<gml:exterior>
												<gml:LinearRing gml:id="line_f8335294-4324-43bd-98ae-ca6340c06ae9">
													<gml:posList>35.66896268365045 139.7469850610783 30.785237054594802 35.66886984293583 139.74687342411445 32.451023797758864 35.66896268365045 139.7469850610783 32.451023797758864 35.66896268365045 139.7469850610783 30.785237054594802</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_675e2c69-8cb4-4e49-92d7-7f8b809f8ca3">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_16119644-b50b-418b-a767-763bd22268fb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d392169a-aeec-42c3-8c54-d8a8f97e53da">
											<gml:posList>35.668930700464365 139.74690442435693 7.403500299223708 35.668903594190766 139.7468718303237 7.403500299223708 35.668930700464365 139.74690442435693 9.82349083877449 35.668930700464365 139.74690442435693 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7cd2c6d5-cd57-44ad-807a-2561f3531a66">
									<gml:exterior>
										<gml:LinearRing gml:id="line_55decfea-dee2-444c-b155-657d93208bcf">
											<gml:posList>35.668930700464365 139.74690442435693 9.82349083877449 35.668903594190766 139.7468718303237 7.403500299223708 35.668903594190766 139.7468718303237 9.82349083877449 35.668930700464365 139.74690442435693 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_414afa0c-598b-48ca-8b08-6301e7b01b93">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e2a56f93-1762-4ff1-8d8e-4f7fdc0ddd51">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a00a5ed2-f13b-4b4e-951b-1b895af09118">
													<gml:posList>35.668930700464365 139.74690442435693 9.82349083877449 35.66893351265158 139.74690874023833 9.82349083877449 35.668930700464365 139.74690442435693 7.403500299223708 35.668930700464365 139.74690442435693 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a5884a0a-fa4d-4cb6-884b-21d6741734c6">
											<gml:exterior>
												<gml:LinearRing gml:id="line_3d3594a7-f7af-4740-964f-adafc812bc4b">
													<gml:posList>35.668930700464365 139.74690442435693 7.403500299223708 35.66893351265158 139.74690874023833 9.82349083877449 35.66893351265158 139.74690874023833 7.403500299223708 35.668930700464365 139.74690442435693 7.403500299223708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_46a54e82-ef3d-45b1-bdc0-47503a2c968d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_37d1ba3b-2160-4471-b3f2-c04c11d1cf37">
									<gml:exterior>
										<gml:LinearRing gml:id="line_509dc76b-4036-4301-bc01-cefd07937c6c">
											<gml:posList>35.66898926576778 139.74696169405894 26.006245355376052 35.66898926576778 139.74696169405894 13.130490045317458 35.668989778898485 139.7469601238035 13.130490045317458 35.66898926576778 139.74696169405894 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a0698fe2-4bdb-4b3a-b6a0-41a90ad5897a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_09cb9774-75b8-4d48-9fa4-c08309621461">
											<gml:posList>35.66898926576778 139.74696169405894 26.006245355376052 35.668989778898485 139.7469601238035 13.130490045317458 35.668989778898485 139.7469601238035 26.006245355376052 35.66898926576778 139.74696169405894 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c72b8c79-a96b-457c-9e83-52de0758ef7a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f36ddd58-71fe-4d23-802e-2f896b4ddaf3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4725c903-2fa6-4059-95b0-1d0d3174ecf3">
											<gml:posList>35.668926862691535 139.747005808151 6.862499933012771 35.668928215025566 139.74700741819677 6.862499933012771 35.668926862691535 139.747005808151 7.403500299223708 35.668926862691535 139.747005808151 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_addefab9-4fd2-4d81-b0c6-712aaf0b4c52">
									<gml:exterior>
										<gml:LinearRing gml:id="line_17cafb75-ff37-44a5-8fa7-9704811da5ce">
											<gml:posList>35.668926862691535 139.747005808151 7.403500299223708 35.668928215025566 139.74700741819677 6.862499933012771 35.668928215025566 139.74700741819677 7.403500299223708 35.668926862691535 139.747005808151 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_edde43f7-0f67-490f-a6b0-26a0123e810f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_254714a6-8913-4bdc-bbbd-073de605ced2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e26aadd6-9679-4d55-8fe5-6f24e8588419">
											<gml:posList>35.66878912130939 139.74711812459876 7.334240655669021 35.66878966282438 139.7471156626924 7.334240655669021 35.66878912130939 139.74711812459876 9.53999016738777 35.66878912130939 139.74711812459876 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1f5e35df-b14c-42cc-af26-66ab114035a7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_71d0891f-f632-46dd-baa1-db9f7ef0a520">
											<gml:posList>35.66878912130939 139.74711812459876 9.53999016738777 35.66878966282438 139.7471156626924 7.334240655669021 35.66878966282438 139.7471156626924 9.53999016738777 35.66878912130939 139.74711812459876 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2d49b8d6-2889-4e63-a699-78dc13c74933">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_258fbead-53e1-40df-a321-149bdbb10f86">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1bbdfaac-eed1-48c3-a34e-e7ed61d9fbfe">
											<gml:posList>35.66872502845572 139.74705440645425 33.88324425674324 35.66872502845572 139.74705440645425 10.527806024321364 35.66878793408452 139.74713004786625 10.527806024321364 35.66872502845572 139.74705440645425 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_163b0615-953e-4ca3-8e34-f9da32c170dc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e3485894-5c8a-478b-8821-8a3233cc6469">
											<gml:posList>35.66872502845572 139.74705440645425 33.88324425674324 35.66878793408452 139.74713004786625 10.527806024321364 35.66878793408452 139.74713004786625 33.88324425674324 35.66872502845572 139.74705440645425 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2c68959b-731d-4a88-a62a-e5e1bbdaacf4">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3db872a2-f7a6-4adf-9a39-9b3c543393ec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f7168c62-93ee-41b3-b9ce-f11b59925713">
											<gml:posList>35.6688635010178 139.74706690421718 9.32349846816902 35.66888242642479 139.74704303175528 9.32349846816902 35.6688635010178 139.74706690421718 9.82349083877449 35.6688635010178 139.74706690421718 9.32349846816902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8c2a6be2-eeb5-4e05-b096-f3df824faeba">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b31ebc7f-4719-43d5-861f-e0189412cedc">
											<gml:posList>35.6688635010178 139.74706690421718 9.82349083877449 35.66888242642479 139.74704303175528 9.32349846816902 35.66888242642479 139.74704303175528 9.82349083877449 35.6688635010178 139.74706690421718 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0166_p1034_5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1034_5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1034_5">
											<gml:posList>35.66876276782651 139.74694794164992 38.34046315 35.66887016924144 139.74681718827335 38.34467518 35.668870291720246 139.74681721075314 5.78953961 35.66876288975531 139.74694796479653 5.78532755 35.66876276782651 139.74694794164992 38.34046315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_ce01d679-f2e4-4e2d-9522-e60c4165e5b6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_07aab5b0-8b3c-4120-a569-d4c86e8a2603">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a73d85f9-d3f4-48b8-b181-3f1b43c324ff">
											<gml:posList>35.66894061286278 139.74700621842882 6.862499933012771 35.66894061286278 139.74700621842882 7.028240899809646 35.66893717061708 139.74699998782526 6.862499933012771 35.66894061286278 139.74700621842882 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_73185008-e5d3-475f-9aa7-80586480819c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eb52338f-667b-412a-a360-2eda6e1b676c">
											<gml:posList>35.66893717061708 139.74699998782526 6.862499933012771 35.66894061286278 139.74700621842882 7.028240899809646 35.66893717061708 139.74699998782526 7.028240899809646 35.66893717061708 139.74699998782526 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_37eafc49-978b-422b-a10d-cdb6fdcd1568">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f7ea122a-5cc5-4799-93d5-5c64e4cf51df">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5a14d7b9-31b0-4a87-8180-6b2f5b158539">
											<gml:posList>35.6688490060764 139.74707647993023 9.53999016738777 35.66885994949103 139.74706267576386 9.82349083877449 35.6688490060764 139.74707647993023 9.82349083877449 35.6688490060764 139.74707647993023 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6320fd55-e62a-46f1-9e28-f7012af89e5a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3430838c-dfb9-4d48-8538-372f86e51f50">
											<gml:posList>35.66885994949103 139.74706267576386 9.82349083877449 35.6688490060764 139.74707647993023 9.53999016738777 35.66885994949103 139.74706267576386 9.32349846816902 35.66885994949103 139.74706267576386 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3ba33ce6-7ced-4423-93a4-a3b3cb4fd609">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0f4c8649-5c8d-497b-b976-67ad7b687824">
											<gml:posList>35.66885994949103 139.74706267576386 9.32349846816902 35.6688490060764 139.74707647993023 9.53999016738777 35.6688490060764 139.74707647993023 9.32349846816902 35.66885994949103 139.74706267576386 9.32349846816902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2eec4559-559c-4f0c-9359-8b9871362aaf">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0308ab7e-b064-4105-93e7-f636d1fd4477">
									<gml:exterior>
										<gml:LinearRing gml:id="line_770a92d1-dbed-4214-80aa-6ddf7e40730e">
											<gml:posList>35.668779507307946 139.74712189813383 7.334240655669021 35.668781261837466 139.7471227871984 7.334240655669021 35.668779507307946 139.74712189813383 9.53999016738777 35.668779507307946 139.74712189813383 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_249abf4a-5744-4fb1-a735-95333e25e98d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_062c2044-f943-4f53-9aea-d800cebf742e">
											<gml:posList>35.668779507307946 139.74712189813383 9.53999016738777 35.668781261837466 139.7471227871984 7.334240655669021 35.668781261837466 139.7471227871984 9.53999016738777 35.668779507307946 139.74712189813383 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_0f15cc1b-a6b4-4704-91a9-4c333d7a7749">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4480ca48-dab0-4ca5-8d9d-245d6157dd40">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b1f9c5dc-2f7f-4512-8294-3d8997d48726">
											<gml:posList>35.668786560566524 139.74713496373204 6.862499933012771 35.66885153428912 139.74708105619038 6.862499933012771 35.668786560566524 139.74713496373204 7.005749444731521 35.668786560566524 139.74713496373204 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1d02bee9-8858-4064-af77-35d4e5ac92e6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_86914053-630c-4d8d-b37c-92cd1c06b452">
											<gml:posList>35.668786560566524 139.74713496373204 7.005749444731521 35.66885153428912 139.74708105619038 6.862499933012771 35.66885153428912 139.74708105619038 7.005749444731521 35.668786560566524 139.74713496373204 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_20bb04de-74d2-4cf8-b18c-65467ec0e413">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2fda163a-9f84-4258-a6be-b0a95d54df63">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5c1adf37-9274-4387-ba2f-ed20d4bf93c0">
											<gml:posList>35.668786388086765 139.74712189073566 7.334240655669021 35.668786388086765 139.74712189073566 9.53999016738777 35.66878463483299 139.74712278357183 7.334240655669021 35.668786388086765 139.74712189073566 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ea0397c4-d63c-458a-9b26-488ec9a2cb94">
									<gml:exterior>
										<gml:LinearRing gml:id="line_675bcbf8-be0e-44ba-a394-53110798ec5b">
											<gml:posList>35.66878463483299 139.74712278357183 7.334240655669021 35.668786388086765 139.74712189073566 9.53999016738777 35.66878463483299 139.74712278357183 9.53999016738777 35.66878463483299 139.74712278357183 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_353cd70c-9128-4dc7-b291-1bda6eb6139a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bba238c1-e06b-4281-b94a-e583a0405925">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cb0672df-d6dd-469e-9f18-17888640a6c7">
											<gml:posList>35.66898148814006 139.74697230471327 7.028240899809646 35.66894061286278 139.74700621842882 7.028240899809646 35.66894061286278 139.74700621842882 6.862499933012771 35.66898148814006 139.74697230471327 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a450fa7c-80f1-43bf-bea7-3acf74669fdb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_995add5d-1d3c-49fa-953f-7c4c36a29b4b">
											<gml:posList>35.66898148814006 139.74697230471327 7.028240899809646 35.66894061286278 139.74700621842882 6.862499933012771 35.66898148814006 139.74697230471327 6.862499933012771 35.66898148814006 139.74697230471327 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_fd7f64c0-ba3f-41ae-9034-a9420cd92d38">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aaeebf58-8b57-44f6-a137-6217699edea8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dd09de1c-a9b8-4936-83c8-67da4b1cbf67">
											<gml:posList>35.66897928921328 139.7469600895948 7.403500299223708 35.66897928921328 139.7469600895948 13.130490045317458 35.66897813957459 139.74696226428037 7.403500299223708 35.66897928921328 139.7469600895948 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_59a69b9c-de6f-46a1-8a04-0cc57ed05ec7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ee726af0-f13f-4ff3-8259-080d52a9b341">
											<gml:posList>35.66897813957459 139.74696226428037 7.403500299223708 35.66897928921328 139.7469600895948 13.130490045317458 35.66897813957459 139.74696226428037 13.130490045317458 35.66897813957459 139.74696226428037 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_820bb9c6-8762-4260-b380-da88ff4697fc">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ed795a03-dc30-41cd-a109-50182d75e715">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d5f77920-278a-4c98-bc9b-0cb404f8a492">
											<gml:posList>35.66878004439929 139.7470950114325 9.53999016738777 35.66877394926528 139.7470877548669 9.53999016738777 35.66878004439929 139.7470950114325 7.334240655669021 35.66878004439929 139.7470950114325 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_384d1fea-3163-4421-b924-e3328e826fec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0117a625-5535-4dbb-bfd5-33886afd59e7">
											<gml:posList>35.66878004439929 139.7470950114325 7.334240655669021 35.66877394926528 139.7470877548669 9.53999016738777 35.66877394926528 139.7470877548669 7.334240655669021 35.66878004439929 139.7470950114325 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2966cda3-ad67-4abf-b957-731b4a676ca1">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_036aa223-0569-441a-8164-67f94ef6a16c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_828022bc-270d-407d-94a3-00e75a6aa012">
											<gml:posList>35.66870207904577 139.74701815687015 39.04224083877449 35.668861190555496 139.74681392574468 11.427670221098708 35.66870207904577 139.74701815687015 6.862499933012771 35.66870207904577 139.74701815687015 39.04224083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8ac95b06-0099-465d-a04c-ffdc23db8428">
									<gml:exterior>
										<gml:LinearRing gml:id="line_503cd2ae-cf2b-48a6-887c-0fa4ffa03262">
											<gml:posList>35.668861190555496 139.74681392574468 11.427670221098708 35.66870207904577 139.74701815687015 39.04224083877449 35.668861190555496 139.74681392574468 39.04224083877449 35.668861190555496 139.74681392574468 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8addd6d8-59a0-4945-b0d8-1608117d5997">
									<gml:exterior>
										<gml:LinearRing gml:id="line_75ac1319-a837-4e35-8618-b514eee54ad7">
											<gml:posList>35.66870207904577 139.74701815687015 6.862499933012771 35.668861190555496 139.74681392574468 11.427670221098708 35.668861190555496 139.74681392574468 9.82349083877449 35.66870207904577 139.74701815687015 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_963c1f65-ca19-47db-96a9-289815da503c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b2d9d9a2-540b-47a7-bb8b-19fe21582fc1">
											<gml:posList>35.66870207904577 139.74701815687015 6.862499933012771 35.668861190555496 139.74681392574468 9.82349083877449 35.668861190555496 139.74681392574468 7.403500299223708 35.66870207904577 139.74701815687015 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3f4faf00-ecba-428d-8748-153113ff885c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_73423707-d6bd-45fd-9b2f-9cd9313c83c3">
											<gml:posList>35.66870207904577 139.74701815687015 6.862499933012771 35.668861190555496 139.74681392574468 7.403500299223708 35.66886723503126 139.74680616729975 6.862499933012771 35.66870207904577 139.74701815687015 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dfc521d9-9c8d-4de9-8541-105b97fc187b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_21d03c8e-d2cf-4264-a3ae-6825265bc5cb">
											<gml:posList>35.66886723503126 139.74680616729975 6.862499933012771 35.668861190555496 139.74681392574468 7.403500299223708 35.66886723503126 139.74680616729975 7.403500299223708 35.66886723503126 139.74680616729975 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bb6668a3-b261-4f57-b313-7a004a403695">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0432878e-474b-45b0-aae2-a569ef6f5de7">
											<gml:posList>35.668861190555496 139.74681392574468 9.82349083877449 35.66886723503126 139.74680616729975 11.427670221098708 35.66886723503126 139.74680616729975 9.82349083877449 35.668861190555496 139.74681392574468 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e5168e09-bfd8-4480-87c1-bda6003ec3c4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_713da9ba-c085-4a8c-b4e3-5b656a4c13f0">
											<gml:posList>35.66886723503126 139.74680616729975 11.427670221098708 35.668861190555496 139.74681392574468 9.82349083877449 35.668861190555496 139.74681392574468 11.427670221098708 35.66886723503126 139.74680616729975 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e23b7c64-aa61-4f97-a8e3-f0c8cd862e29">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_77461c39-683f-4c79-b873-342bcd0742a0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3f1d2701-eab6-4ba8-b715-5f37b1b74633">
											<gml:posList>35.66893889005837 139.74698876866609 36.27749321914558 35.66893889005837 139.74698876866609 33.88324425674324 35.66885665916082 139.74688988975828 36.27749321914558 35.66893889005837 139.74698876866609 36.27749321914558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_db96c8d4-280a-4e86-be15-6c83c8ef80c5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ba76d04-f4a8-4b34-8263-0066e6183872">
											<gml:posList>35.66885665916082 139.74688988975828 36.27749321914558 35.66893889005837 139.74698876866609 33.88324425674324 35.66885665916082 139.74688988975828 33.88324425674324 35.66885665916082 139.74688988975828 36.27749321914558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_88e08fe7-7531-46b9-a637-0bbde861377c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_49a7e904-21bf-419e-b7ab-a35725969775">
									<gml:exterior>
										<gml:LinearRing gml:id="line_061c2a71-ca88-4423-84f5-48f3e2b4dec1">
											<gml:posList>35.66892611246553 139.7470049149722 9.82349083877449 35.668926862691535 139.747005808151 9.32349846816902 35.66892611246553 139.7470049149722 7.403500299223708 35.66892611246553 139.7470049149722 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_79be6bb7-00e3-401e-96dc-25ae13294f70">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5d4e8a74-6ede-4fd4-bc43-b549d5eed809">
											<gml:posList>35.668926862691535 139.747005808151 9.32349846816902 35.66892611246553 139.7470049149722 9.82349083877449 35.668926862691535 139.747005808151 9.82349083877449 35.668926862691535 139.747005808151 9.32349846816902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_94b782f5-30a4-45d2-b270-565812a0fd9e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_30c7bfdf-d8b5-4453-acba-5520322ffbdb">
											<gml:posList>35.66892611246553 139.7470049149722 7.403500299223708 35.668926862691535 139.747005808151 9.32349846816902 35.668926862691535 139.747005808151 7.540844659575271 35.66892611246553 139.7470049149722 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3e5d1fe0-9a64-4f3c-8c4c-4121935d3bda">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3c5ddc6f-b029-403e-82b4-a3bbc310c01c">
											<gml:posList>35.66892611246553 139.7470049149722 7.403500299223708 35.668926862691535 139.747005808151 7.540844659575271 35.668926862691535 139.747005808151 7.403500299223708 35.66892611246553 139.7470049149722 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_320a0f59-93f1-40fe-8cda-5a98cc39fa8f">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_3aa523ff-02af-4f72-b6e1-060a1788b203">
											<gml:exterior>
												<gml:LinearRing gml:id="line_0b82e0c6-b2dc-41cf-bd28-eebbf9e11f89">
													<gml:posList>35.66892611246553 139.7470049149722 9.82349083877449 35.66892611246553 139.7470049149722 7.403500299223708 35.668932786690256 139.74699669925667 9.82349083877449 35.66892611246553 139.7470049149722 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_5a3d0a7d-3fdd-49d5-96f7-36b351f0f77e">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ddf10d92-ec22-4ad0-bf7e-dbb724ffa369">
													<gml:posList>35.668932786690256 139.74699669925667 9.82349083877449 35.66892611246553 139.7470049149722 7.403500299223708 35.668932786690256 139.74699669925667 7.403500299223708 35.668932786690256 139.74699669925667 9.82349083877449</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_723fa032-6ce5-4c3f-aca9-aedb98f98220">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_40a0fdef-25b5-4eda-9ae7-94bd1eabcbaf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_60b5300c-3894-4393-9ca9-6e869ce89736">
											<gml:posList>35.6687762911241 139.74711328198674 7.334240655669021 35.66877622365711 139.74711567714314 7.334240655669021 35.6687762911241 139.74711328198674 9.53999016738777 35.6687762911241 139.74711328198674 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3305a482-e30d-48fe-afef-67e01d5fcf06">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fdb5c1f8-8f3c-45d9-9ea4-450e0bfb18de">
											<gml:posList>35.6687762911241 139.74711328198674 9.53999016738777 35.66877622365711 139.74711567714314 7.334240655669021 35.66877622365711 139.74711567714314 9.53999016738777 35.6687762911241 139.74711328198674 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0166_p1035_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1035_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1035_1">
											<gml:posList>35.668896957407576 139.7468343967882 5.79087279 35.66889058421758 139.7468422428056 5.79062195 35.66889050757248 139.74684222867023 26.1457586 35.66889688074204 139.74683438267795 26.14600944 35.668896957407576 139.7468343967882 5.79087279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_8cb8dabd-f38f-4a45-9dea-4e0b6e0fcc63">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8e36f381-cdf6-409f-aec4-5f67f2f511a9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0610f030-9857-4cdb-a04f-7ad9aa00db4d">
											<gml:posList>35.668986752485125 139.74696509152423 13.130490045317458 35.66898633227941 139.74696544003183 19.528118829497146 35.66898633227941 139.74696544003183 17.862324456938552 35.668986752485125 139.74696509152423 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eba2c741-025d-4786-b534-88a65d1e6340">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c01f22dc-a43e-4901-848c-f169e31cba7e">
											<gml:posList>35.66898633227941 139.74696544003183 19.528118829497146 35.668986752485125 139.74696509152423 13.130490045317458 35.668986752485125 139.74696509152423 26.006245355376052 35.66898633227941 139.74696544003183 19.528118829497146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9f0b36be-bfb4-45f5-84d0-46fe226153cc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5fccde62-18b5-4810-b310-80b472ba9b56">
											<gml:posList>35.668986752485125 139.74696509152423 13.130490045317458 35.66898633227941 139.74696544003183 17.862324456938552 35.66898633227941 139.74696544003183 16.297390680083083 35.668986752485125 139.74696509152423 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a61c8bda-7509-4d64-bd6d-bb39db626d07">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1a3c398d-da3a-4d5d-9188-5fdce33a59f8">
											<gml:posList>35.668986752485125 139.74696509152423 13.130490045317458 35.66898633227941 139.74696544003183 16.297390680083083 35.66898633227941 139.74696544003183 14.63159630752449 35.668986752485125 139.74696509152423 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fada73b2-86a8-4664-97ff-4ffc48730424">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6d4276f6-863a-4654-8233-9ab7fa75aade">
											<gml:posList>35.668986752485125 139.74696509152423 13.130490045317458 35.66898633227941 139.74696544003183 14.63159630752449 35.66898090232122 139.74696994531257 13.130490045317458 35.668986752485125 139.74696509152423 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d6a024a0-73fc-4d25-a0b3-a8d706d8c666">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c0ca1ef1-2aed-4cf1-bece-ea3947761c06">
											<gml:posList>35.66879064872318 139.74712779565854 32.451023797758864 35.66878793408452 139.74713004786625 33.88324425674324 35.66879064872318 139.74712779565854 30.785237054594802 35.66879064872318 139.74712779565854 32.451023797758864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a5797704-f137-45a8-baa1-147aadaeecee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ef9f2c09-5888-42b4-9bfa-e71389240020">
											<gml:posList>35.66878793408452 139.74713004786625 33.88324425674324 35.66879064872318 139.74712779565854 32.451023797758864 35.66896268365045 139.7469850610783 33.88324425674324 35.66878793408452 139.74713004786625 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5fef7948-d259-41a8-aca2-94e219387ea1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cd485bc3-2e39-4f3f-9a74-b5db57668d65">
											<gml:posList>35.66896268365045 139.7469850610783 33.88324425674324 35.66879064872318 139.74712779565854 32.451023797758864 35.66896268365045 139.7469850610783 32.451023797758864 35.66896268365045 139.7469850610783 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8df78219-fc5f-4870-b249-10878f4380d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c7f30097-20fe-4210-9a75-1aac382e9cdf">
											<gml:posList>35.66879064872318 139.74712779565854 30.785237054594802 35.66878793408452 139.74713004786625 33.88324425674324 35.66879064872318 139.74712779565854 29.220295648344802 35.66879064872318 139.74712779565854 30.785237054594802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a2084fa2-42dc-47f8-bc95-9e5afbe9e272">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e87cc162-6eb0-4e25-95df-96f62cfee5ec">
											<gml:posList>35.66879064872318 139.74712779565854 29.220295648344802 35.66878793408452 139.74713004786625 33.88324425674324 35.66879064872318 139.74712779565854 27.55450890518074 35.66879064872318 139.74712779565854 29.220295648344802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bfc5dba8-ad6f-456e-a5f3-75dc19fead1c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_84e30ab6-6b40-4f84-a212-b2d9d6a62d50">
											<gml:posList>35.66879064872318 139.74712779565854 30.785237054594802 35.66879064872318 139.74712779565854 29.220295648344802 35.66896268365045 139.7469850610783 30.785237054594802 35.66879064872318 139.74712779565854 30.785237054594802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_059b2871-e0fe-4357-807c-b597b44a3c13">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4bd8f88e-497e-4165-871f-be978d133958">
											<gml:posList>35.66896268365045 139.7469850610783 30.785237054594802 35.66879064872318 139.74712779565854 29.220295648344802 35.66896268365045 139.7469850610783 29.220295648344802 35.66896268365045 139.7469850610783 30.785237054594802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_be7945e4-62d1-444c-b1fe-bd2abe24ac40">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d92d0cd6-44a7-42f9-85f0-02d6af8c956b">
											<gml:posList>35.66879064872318 139.74712779565854 27.55450890518074 35.66878793408452 139.74713004786625 33.88324425674324 35.66879064872318 139.74712779565854 25.98956749893074 35.66879064872318 139.74712779565854 27.55450890518074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_33907144-b775-4504-8030-b5605a5bcedb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d7b2c2eb-b8a5-4f73-a963-4a31e462ede7">
											<gml:posList>35.66879064872318 139.74712779565854 25.98956749893074 35.66878793408452 139.74713004786625 33.88324425674324 35.66879064872318 139.74712779565854 24.323780755766677 35.66879064872318 139.74712779565854 25.98956749893074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e3fe6960-0e0c-4fa6-b4a6-28196bcc8eee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_495bd5f7-69da-47f0-b217-ba7cf110d847">
											<gml:posList>35.66879064872318 139.74712779565854 27.55450890518074 35.66879064872318 139.74712779565854 25.98956749893074 35.66896268365045 139.7469850610783 27.38849328018074 35.66879064872318 139.74712779565854 27.55450890518074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eec8ff56-c538-4213-addc-95d94fea8aab">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a26abeb4-6deb-4590-860e-415595f46b4e">
											<gml:posList>35.66879064872318 139.74712779565854 27.55450890518074 35.66896268365045 139.7469850610783 27.38849328018074 35.66896268365045 139.7469850610783 27.55450890518074 35.66879064872318 139.74712779565854 27.55450890518074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cf0255f6-3eba-4622-bdea-25f18a38f318">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e745dd16-a330-4710-bb72-8e39c625a4db">
											<gml:posList>35.66896268365045 139.7469850610783 27.38849328018074 35.66879064872318 139.74712779565854 25.98956749893074 35.66898633227941 139.74696544003183 25.98956749893074 35.66896268365045 139.7469850610783 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5d4f4536-7a4c-4c6f-a534-b75d59de88f8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_edff17a7-e032-4424-b24c-3c0bab0bf18f">
											<gml:posList>35.66896268365045 139.7469850610783 27.38849328018074 35.66898633227941 139.74696544003183 25.98956749893074 35.66899423701073 139.74695888167824 27.38849328018074 35.66896268365045 139.7469850610783 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d9f82de7-4236-4315-94b4-618e084090df">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f38c77f7-519d-4efb-997c-cbcb2400ed6d">
											<gml:posList>35.66899423701073 139.74695888167824 27.38849328018074 35.668986752485125 139.74696509152423 26.006245355376052 35.66899423701073 139.74695888167824 26.006245355376052 35.66899423701073 139.74695888167824 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bd8990e3-b7a4-43a4-ad98-6c73ddedb936">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4fb20277-471d-47a4-8f46-3a06ba56aa78">
											<gml:posList>35.668986752485125 139.74696509152423 26.006245355376052 35.66899423701073 139.74695888167824 27.38849328018074 35.66898633227941 139.74696544003183 25.98956749893074 35.668986752485125 139.74696509152423 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e10f8204-10c6-4b32-ade3-e61a411f6769">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f99d63d4-2fb3-422d-a391-97c553b603c7">
											<gml:posList>35.66879064872318 139.74712779565854 24.323780755766677 35.66878793408452 139.74713004786625 33.88324425674324 35.66879064872318 139.74712779565854 22.75884697891121 35.66879064872318 139.74712779565854 24.323780755766677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8f3514b7-be1f-4907-a2ac-4e0c3f950bc1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a0502fd9-100f-4ec4-9df2-3b9411ac9b54">
											<gml:posList>35.66879064872318 139.74712779565854 22.75884697891121 35.66878793408452 139.74713004786625 33.88324425674324 35.66878793408452 139.74713004786625 10.527806024321364 35.66879064872318 139.74712779565854 22.75884697891121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_36a38d72-639a-4d28-9818-01bc387f275e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_03ce77c5-110b-4ab7-aca2-b5fa6bff65f5">
											<gml:posList>35.66879064872318 139.74712779565854 24.323780755766677 35.66879064872318 139.74712779565854 22.75884697891121 35.66898633227941 139.74696544003183 22.75884697891121 35.66879064872318 139.74712779565854 24.323780755766677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3a0b6827-cb72-4ae7-8e49-42f458d6c6a1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8bd5e2f5-803f-4340-bb0a-1592faddf9d2">
											<gml:posList>35.66879064872318 139.74712779565854 24.323780755766677 35.66898633227941 139.74696544003183 22.75884697891121 35.66898633227941 139.74696544003183 24.323780755766677 35.66879064872318 139.74712779565854 24.323780755766677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_132d96b3-ed12-4375-b5d6-5343f3a8510e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1b21a610-e05f-4588-90d6-5cca328b8c73">
											<gml:posList>35.66879064872318 139.74712779565854 22.75884697891121 35.66878793408452 139.74713004786625 10.527806024321364 35.66879064872318 139.74712779565854 21.093052606352614 35.66879064872318 139.74712779565854 22.75884697891121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ed1f0597-5125-438b-8a8b-6528581bc65f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e208fe33-5ce5-4d06-badc-20cb59e520e5">
											<gml:posList>35.66879064872318 139.74712779565854 21.093052606352614 35.66878793408452 139.74713004786625 10.527806024321364 35.66879064872318 139.74712779565854 19.528118829497146 35.66879064872318 139.74712779565854 21.093052606352614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_696785e0-5cb7-4961-be3c-f79bd05aa33d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_83c675cb-e9c1-438e-912e-a301c10e18af">
											<gml:posList>35.66879064872318 139.74712779565854 21.093052606352614 35.66879064872318 139.74712779565854 19.528118829497146 35.66898633227941 139.74696544003183 21.093052606352614 35.66879064872318 139.74712779565854 21.093052606352614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8d026f44-1eda-47be-94b3-aa38887738bb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5cb263b4-4b77-4c32-aad9-ec20ccc70535">
											<gml:posList>35.66898633227941 139.74696544003183 21.093052606352614 35.66879064872318 139.74712779565854 19.528118829497146 35.66898633227941 139.74696544003183 19.528118829497146 35.66898633227941 139.74696544003183 21.093052606352614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e159366d-e9cb-4ecf-91ae-e4cd3b12c406">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0a770ffe-a90a-4543-9011-271efbd4c9fe">
											<gml:posList>35.66879064872318 139.74712779565854 19.528118829497146 35.66878793408452 139.74713004786625 10.527806024321364 35.66879064872318 139.74712779565854 17.862324456938552 35.66879064872318 139.74712779565854 19.528118829497146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_03cf873f-c848-4382-b0b0-4095ed564afd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_059cef26-bca9-4b2f-9079-2797ab03e79e">
											<gml:posList>35.66879064872318 139.74712779565854 17.862324456938552 35.66878793408452 139.74713004786625 10.527806024321364 35.66879064872318 139.74712779565854 16.297390680083083 35.66879064872318 139.74712779565854 17.862324456938552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_531feb44-5b95-483b-9b8c-8b53c5b3bf65">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1278f297-6a99-4ef6-85af-bf6e2ac869d7">
											<gml:posList>35.66879064872318 139.74712779565854 17.862324456938552 35.66879064872318 139.74712779565854 16.297390680083083 35.66898633227941 139.74696544003183 17.862324456938552 35.66879064872318 139.74712779565854 17.862324456938552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_967f8357-3907-4c15-a8a4-dd2418697fff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a9475363-a870-435f-be0c-2c73aba6a131">
											<gml:posList>35.66898633227941 139.74696544003183 17.862324456938552 35.66879064872318 139.74712779565854 16.297390680083083 35.66898633227941 139.74696544003183 16.297390680083083 35.66898633227941 139.74696544003183 17.862324456938552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b2e55194-a00c-4049-b2c3-d1f57b36e115">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1d1e0834-d560-4e85-a126-3eccfb0cf10a">
											<gml:posList>35.66879064872318 139.74712779565854 16.297390680083083 35.66878793408452 139.74713004786625 10.527806024321364 35.66879064872318 139.74712779565854 14.63159630752449 35.66879064872318 139.74712779565854 16.297390680083083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a2231cfd-c431-41fb-a87e-566d9982827e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ea85d0b5-8c70-413f-9ae2-b20c46f6a223">
											<gml:posList>35.66879064872318 139.74712779565854 14.63159630752449 35.66878793408452 139.74713004786625 10.527806024321364 35.66879064872318 139.74712779565854 13.130490045317458 35.66879064872318 139.74712779565854 14.63159630752449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d7663597-ced5-4050-9f6a-93e453862290">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0b407a32-3c9c-4b95-a4d2-9338c45dd73e">
											<gml:posList>35.66879064872318 139.74712779565854 14.63159630752449 35.66879064872318 139.74712779565854 13.130490045317458 35.66898090232122 139.74696994531257 13.130490045317458 35.66879064872318 139.74712779565854 14.63159630752449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_80ca357d-f5a1-4477-8cc1-84445f9b9136">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cb8b91d6-b5d9-4fe6-9c28-7569c8629684">
											<gml:posList>35.66879064872318 139.74712779565854 14.63159630752449 35.66898090232122 139.74696994531257 13.130490045317458 35.66898633227941 139.74696544003183 14.63159630752449 35.66879064872318 139.74712779565854 14.63159630752449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_346c4001-35b9-45f1-81b3-9db72e14a1a7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7347c7d3-8526-4d55-93ec-f5c5cd155958">
											<gml:posList>35.66879064872318 139.74712779565854 13.130490045317458 35.66878793408452 139.74713004786625 10.527806024321364 35.66879064872318 139.74712779565854 11.427670221098708 35.66879064872318 139.74712779565854 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6c8d6936-597e-4a21-8500-75f1bf735406">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7d97ce4e-2005-4c77-b75a-1edd834af7a2">
											<gml:posList>35.66879064872318 139.74712779565854 11.427670221098708 35.66878793408452 139.74713004786625 10.527806024321364 35.66885044045238 139.74707818747746 10.527806024321364 35.66879064872318 139.74712779565854 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f04d9bfe-ab68-4b66-8802-43ee563db1d6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2fd1db57-b7e9-48cf-ba38-d4e9e1997ac4">
											<gml:posList>35.66879064872318 139.74712779565854 11.427670221098708 35.66885044045238 139.74707818747746 10.527806024321364 35.66898090232122 139.74696994531257 11.427670221098708 35.66879064872318 139.74712779565854 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9e44e29a-4065-482d-b401-47b2e77257a3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e871e4f2-8853-442b-a325-ca040c94b5e9">
											<gml:posList>35.66898090232122 139.74696994531257 11.427670221098708 35.66885044045238 139.74707818747746 10.527806024321364 35.66898090232122 139.74696994531257 9.82349083877449 35.66898090232122 139.74696994531257 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a9a72554-78cc-467f-ab1f-6f48e5670629">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f08fd781-462f-4b93-94f9-366f6c04f00c">
											<gml:posList>35.66898090232122 139.74696994531257 9.82349083877449 35.66885044045238 139.74707818747746 10.527806024321364 35.66885044045238 139.74707818747746 9.82349083877449 35.66898090232122 139.74696994531257 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_63ce7287-9172-4eb7-8a2f-e9760d80b66b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d225d855-cbe5-46ce-9a40-a1b4f9900e5e">
											<gml:posList>35.66898633227941 139.74696544003183 24.323780755766677 35.668986752485125 139.74696509152423 26.006245355376052 35.66898633227941 139.74696544003183 25.98956749893074 35.66898633227941 139.74696544003183 24.323780755766677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f70e8d09-6e27-463b-9da8-26b868d7fc71">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b6e54110-072f-4daf-a274-39ff0f91a10d">
											<gml:posList>35.668986752485125 139.74696509152423 26.006245355376052 35.66898633227941 139.74696544003183 24.323780755766677 35.66898633227941 139.74696544003183 22.75884697891121 35.668986752485125 139.74696509152423 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a3d32216-2280-437e-b12e-10640a278532">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f8695263-c4f4-4191-9cb0-9b12ffc28381">
											<gml:posList>35.668986752485125 139.74696509152423 26.006245355376052 35.66898633227941 139.74696544003183 22.75884697891121 35.66898633227941 139.74696544003183 21.093052606352614 35.668986752485125 139.74696509152423 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9bd0e486-698c-41d8-8aca-d89a441d46d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ecf49c94-5080-43ad-bc53-eaa9c96244eb">
											<gml:posList>35.668986752485125 139.74696509152423 26.006245355376052 35.66898633227941 139.74696544003183 21.093052606352614 35.66898633227941 139.74696544003183 19.528118829497146 35.668986752485125 139.74696509152423 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_c3933330-1fed-4419-b2ec-83b841db697b">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d4abcba0-f380-4bcd-b511-ffc96ae9e712">
											<gml:exterior>
												<gml:LinearRing gml:id="line_4bfd74d3-66a3-41c0-8335-cf112ecf9ee1">
													<gml:posList>35.66879064872318 139.74712779565854 22.75884697891121 35.66879064872318 139.74712779565854 21.093052606352614 35.66898633227941 139.74696544003183 22.75884697891121 35.66879064872318 139.74712779565854 22.75884697891121</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d60e9a84-be8b-4f13-b81b-c09a9545e7c3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_6de9d5ba-3520-467a-961d-6bbafd2b4e77">
													<gml:posList>35.66898633227941 139.74696544003183 22.75884697891121 35.66879064872318 139.74712779565854 21.093052606352614 35.66898633227941 139.74696544003183 21.093052606352614 35.66898633227941 139.74696544003183 22.75884697891121</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_bdb03d5e-9b97-4c6f-9ca3-8d350be89d44">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_8db7017e-e47d-4a35-a9be-e9fe9ac19abe">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d84ecab1-92e4-447d-b503-298f63128fad">
													<gml:posList>35.66879064872318 139.74712779565854 25.98956749893074 35.66879064872318 139.74712779565854 24.323780755766677 35.66898633227941 139.74696544003183 25.98956749893074 35.66879064872318 139.74712779565854 25.98956749893074</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e9a81529-338a-4c2c-8f3d-ff3f5225a037">
											<gml:exterior>
												<gml:LinearRing gml:id="line_aa003b56-323e-4803-8529-868047edd31a">
													<gml:posList>35.66898633227941 139.74696544003183 25.98956749893074 35.66879064872318 139.74712779565854 24.323780755766677 35.66898633227941 139.74696544003183 24.323780755766677 35.66898633227941 139.74696544003183 25.98956749893074</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_f15dbb38-be44-42f9-ab8f-9e8199addc56">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_06c667a5-b476-41d6-b598-b5f239279cc4">
											<gml:exterior>
												<gml:LinearRing gml:id="line_efe96278-bcf5-4e5b-9cd2-5f8ee56ec23a">
													<gml:posList>35.66879064872318 139.74712779565854 19.528118829497146 35.66879064872318 139.74712779565854 17.862324456938552 35.66898633227941 139.74696544003183 17.862324456938552 35.66879064872318 139.74712779565854 19.528118829497146</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_fcb8ad53-c4a8-4ade-a193-34f37817ad87">
											<gml:exterior>
												<gml:LinearRing gml:id="line_81f6b87c-d769-41bf-a66b-9e186dae38ab">
													<gml:posList>35.66879064872318 139.74712779565854 19.528118829497146 35.66898633227941 139.74696544003183 17.862324456938552 35.66898633227941 139.74696544003183 19.528118829497146 35.66879064872318 139.74712779565854 19.528118829497146</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_60c94b09-4b46-4fea-85e1-9bd199fd44c3">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0d8ca10c-3e21-4673-be23-682bba005be5">
											<gml:exterior>
												<gml:LinearRing gml:id="line_5f5668c0-a311-4857-9444-9706c8d20099">
													<gml:posList>35.66898090232122 139.74696994531257 11.427670221098708 35.66898090232122 139.74696994531257 13.130490045317458 35.66879064872318 139.74712779565854 13.130490045317458 35.66898090232122 139.74696994531257 11.427670221098708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_8169f1a2-f09c-476a-8683-00df479b2349">
											<gml:exterior>
												<gml:LinearRing gml:id="line_fd918179-1020-4ff0-bed9-a2c914748daa">
													<gml:posList>35.66898090232122 139.74696994531257 11.427670221098708 35.66879064872318 139.74712779565854 13.130490045317458 35.66879064872318 139.74712779565854 11.427670221098708 35.66898090232122 139.74696994531257 11.427670221098708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_e2bc62bb-d30e-4e69-95d3-0f14357e43c3">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_f1903cb9-b96f-4d36-a248-23bb8bfb2c37">
											<gml:exterior>
												<gml:LinearRing gml:id="line_7c0c4488-e896-474f-bab6-62a8c677655f">
													<gml:posList>35.66879064872318 139.74712779565854 16.297390680083083 35.66879064872318 139.74712779565854 14.63159630752449 35.66898633227941 139.74696544003183 16.297390680083083 35.66879064872318 139.74712779565854 16.297390680083083</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_2b66c184-e492-419f-a34e-2c153db47f37">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a1982633-b414-49e8-8d8d-dded4fbe967c">
													<gml:posList>35.66898633227941 139.74696544003183 16.297390680083083 35.66879064872318 139.74712779565854 14.63159630752449 35.66898633227941 139.74696544003183 14.63159630752449 35.66898633227941 139.74696544003183 16.297390680083083</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_3269a104-b1bf-498e-b14b-eb71cadecd1a">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_3a0d7a23-3ab3-494e-a52c-a037d181e821">
											<gml:exterior>
												<gml:LinearRing gml:id="line_195f1460-815f-40ce-860c-a8841af2eb58">
													<gml:posList>35.66879064872318 139.74712779565854 29.220295648344802 35.66879064872318 139.74712779565854 27.55450890518074 35.66896268365045 139.7469850610783 29.220295648344802 35.66879064872318 139.74712779565854 29.220295648344802</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_1d19b3ce-2946-4a5e-99ed-6cb6f8ed6c7b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_280cf665-aa84-4c30-bf60-a2de6ed08baf">
													<gml:posList>35.66896268365045 139.7469850610783 29.220295648344802 35.66879064872318 139.74712779565854 27.55450890518074 35.66896268365045 139.7469850610783 27.55450890518074 35.66896268365045 139.7469850610783 29.220295648344802</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_ca66aee9-a969-4a0c-86ed-618073b4de5a">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_1e475fa0-475a-4627-827e-3e2b0ebd38d7">
											<gml:exterior>
												<gml:LinearRing gml:id="line_06c4e232-9ebb-4dd8-884f-a877af9c5a1c">
													<gml:posList>35.66896268365045 139.7469850610783 30.785237054594802 35.66896268365045 139.7469850610783 32.451023797758864 35.66879064872318 139.74712779565854 30.785237054594802 35.66896268365045 139.7469850610783 30.785237054594802</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_cf24dc4d-c607-465e-a968-24ad0acd2f0f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_deea677a-91b6-4fb2-bb53-a07bc371afca">
													<gml:posList>35.66879064872318 139.74712779565854 30.785237054594802 35.66896268365045 139.7469850610783 32.451023797758864 35.66879064872318 139.74712779565854 32.451023797758864 35.66879064872318 139.74712779565854 30.785237054594802</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_19bea175-d76a-45c4-ac46-9c7a7dffb3a6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_176234fd-6852-48a1-a543-6f1dc712bd06">
									<gml:exterior>
										<gml:LinearRing gml:id="line_68e649c9-80f8-4086-8d66-77475e5237ca">
											<gml:posList>35.668779063956315 139.747107977459 7.334240655669021 35.668779063956315 139.747107977459 9.53999016738777 35.66878085956396 139.74710688147525 7.334240655669021 35.668779063956315 139.747107977459 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1a9e071f-c583-429d-8e77-c58ad5e3f794">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9f1fa048-b208-4c7d-bdfa-78e632a0b661">
											<gml:posList>35.66878085956396 139.74710688147525 7.334240655669021 35.668779063956315 139.747107977459 9.53999016738777 35.66878085956396 139.74710688147525 9.53999016738777 35.66878085956396 139.74710688147525 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_713167fe-d566-43bd-aa48-beeb19d645df">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_62d39be0-3e82-4974-9649-f22c4579c8c4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_12223012-2c68-470f-9dbb-b3ef415b00a3">
											<gml:posList>35.668789591927585 139.74711326768437 7.334240655669021 35.66878904758522 139.74711120455322 7.334240655669021 35.668789591927585 139.74711326768437 9.53999016738777 35.668789591927585 139.74711326768437 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_846ab9fd-7233-4e7c-9726-a804248f7a38">
									<gml:exterior>
										<gml:LinearRing gml:id="line_974cc668-2bdf-460b-8292-66e473909be4">
											<gml:posList>35.668789591927585 139.74711326768437 9.53999016738777 35.66878904758522 139.74711120455322 7.334240655669021 35.66878904758522 139.74711120455322 9.53999016738777 35.668789591927585 139.74711326768437 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_bd5c00e0-aeaf-4c82-8934-e775ef4ed53b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_16d52e3a-b081-4157-bfa3-d24a60045d1f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7126db3e-4794-4d71-9d69-19316e1edfcd">
											<gml:posList>35.668776768696695 139.7471181378808 7.334240655669021 35.66877792145051 139.74712031008303 7.334240655669021 35.668776768696695 139.7471181378808 9.53999016738777 35.668776768696695 139.7471181378808 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_50899eed-1293-43d4-9523-8f0eacbf2a40">
									<gml:exterior>
										<gml:LinearRing gml:id="line_15f813c6-fe96-477d-8762-f5bccb205e92">
											<gml:posList>35.668776768696695 139.7471181378808 9.53999016738777 35.66877792145051 139.74712031008303 7.334240655669021 35.66877792145051 139.74712031008303 9.53999016738777 35.668776768696695 139.7471181378808 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c02b98ca-7dcd-49c0-8ec8-37fe53285561">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_026fe7d0-edcb-4b42-8ddb-c5dfe546c8bc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_748b53b4-e8cc-42ca-b52d-594c1304afb2">
											<gml:posList>35.668825814799824 139.74709521755724 7.005749444731521 35.66882669017441 139.74709513520645 7.005749444731521 35.668825814799824 139.74709521755724 9.53999016738777 35.668825814799824 139.74709521755724 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ead7fd3d-d1e4-485a-a686-42cd7f22c947">
									<gml:exterior>
										<gml:LinearRing gml:id="line_500cafaf-7e32-4ef5-b8e0-b31d235c79c6">
											<gml:posList>35.668825814799824 139.74709521755724 9.53999016738777 35.66882669017441 139.74709513520645 7.005749444731521 35.66882669017441 139.74709513520645 9.53999016738777 35.668825814799824 139.74709521755724 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_583b798a-ca21-4b17-89e6-c9f5e5cd2928">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4a8fb56a-4667-495d-82d6-928967cc9dfd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_565d9d35-76f5-4b88-a579-fe4813da9d6c">
											<gml:posList>35.668826681301006 139.74709714870576 7.005749444731521 35.668826681301006 139.74709714870576 7.169247369536208 35.66878433258549 139.74713228467797 7.005749444731521 35.668826681301006 139.74709714870576 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c5f05bb2-0f15-4cf5-b49b-cb75977b6548">
									<gml:exterior>
										<gml:LinearRing gml:id="line_986f597e-a16e-4c7e-bdad-2ca2b9d02e4f">
											<gml:posList>35.66878433258549 139.74713228467797 7.005749444731521 35.668826681301006 139.74709714870576 7.169247369536208 35.66878433258549 139.74713228467797 7.169247369536208 35.66878433258549 139.74713228467797 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a42d3911-563f-4c13-970d-18f764efc169">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b49448be-1360-4fa6-8b98-a9264cf83db8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ca99f257-4f18-47bb-a780-ea54a603c010">
											<gml:posList>35.66897975982506 139.74695523266797 7.403500299223708 35.66897975982506 139.74695523266797 13.130490045317458 35.66897983086256 139.74695762768138 7.403500299223708 35.66897975982506 139.74695523266797 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_954be5ad-91b5-4ec0-b981-14a149258952">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7eccc3ef-94c8-4aa0-8764-e90f3f281ddb">
											<gml:posList>35.66897983086256 139.74695762768138 7.403500299223708 35.66897975982506 139.74695523266797 13.130490045317458 35.66897983086256 139.74695762768138 13.130490045317458 35.66897983086256 139.74695762768138 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_f9ef81dc-96e5-4ccf-a9cf-e3bf3ddbc584">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cdbed090-ca64-441a-bf19-c7db4b1bb84d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e89ad695-8303-4387-93e5-211aa735921c">
											<gml:posList>35.668786811503104 139.7471079691275 7.334240655669021 35.66878501432863 139.7471068770073 7.334240655669021 35.668786811503104 139.7471079691275 9.53999016738777 35.668786811503104 139.7471079691275 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8d62840b-e8af-41c4-9b5a-01dc67f035dd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6fa4cb4e-8332-4c24-9401-36accd04beef">
											<gml:posList>35.668786811503104 139.7471079691275 9.53999016738777 35.66878501432863 139.7471068770073 7.334240655669021 35.66878501432863 139.7471068770073 9.53999016738777 35.668786811503104 139.7471079691275 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_ae52fbed-1af4-44f5-b7d2-0c4a5512e7b4">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_63be3d00-222a-46de-9fcb-ef04d734d720">
									<gml:exterior>
										<gml:LinearRing gml:id="line_187b6ffb-1170-4cec-8bfe-c59e676ca805">
											<gml:posList>35.66894144609213 139.74700125863606 7.028240899809646 35.66894144609213 139.74700125863606 7.193997125395583 35.66893962092371 139.74699795500794 7.028240899809646 35.66894144609213 139.74700125863606 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d35d12b4-1314-446c-a31f-acee8433d3fd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6bc978dd-82dd-4b6f-a5b6-9ae316413826">
											<gml:posList>35.66893962092371 139.74699795500794 7.028240899809646 35.66894144609213 139.74700125863606 7.193997125395583 35.66893962092371 139.74699795500794 7.193997125395583 35.66893962092371 139.74699795500794 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a2afd1f3-eff4-4885-afc2-99a46cf71a1b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ea00df2f-c6e1-4d60-be44-1d0870a9ff5a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b444d011-0163-4998-93bd-5046e9f48d7c">
											<gml:posList>35.66898769123957 139.74696420680735 26.006245355376052 35.66898769123957 139.74696420680735 13.130490045317458 35.66898854976548 139.7469630696895 13.130490045317458 35.66898769123957 139.74696420680735 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a1498327-907a-4b48-abcb-32775f65364e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6a2fee11-59ea-4470-a589-78f3b428b19f">
											<gml:posList>35.66898769123957 139.74696420680735 26.006245355376052 35.66898854976548 139.7469630696895 13.130490045317458 35.66898854976548 139.7469630696895 26.006245355376052 35.66898769123957 139.74696420680735 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_abe10909-2351-4e73-8473-bbd6715ea28e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_008256f4-ea57-4007-b68e-25ae27a1c970">
									<gml:exterior>
										<gml:LinearRing gml:id="line_333f8b29-1b1c-4510-9bd4-22a5b84109fc">
											<gml:posList>35.668973116433335 139.74696501233024 7.403500299223708 35.668973116433335 139.74696501233024 9.82349083877449 35.6689714298853 139.74696475222086 7.403500299223708 35.668973116433335 139.74696501233024 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_59267463-3cbb-4e96-81ed-555520945948">
									<gml:exterior>
										<gml:LinearRing gml:id="line_348a3fcb-6d9d-4e11-a796-432b302eb743">
											<gml:posList>35.6689714298853 139.74696475222086 7.403500299223708 35.668973116433335 139.74696501233024 9.82349083877449 35.6689714298853 139.74696475222086 9.82349083877449 35.6689714298853 139.74696475222086 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_d8e9720c-4685-4adc-ae26-fa4c85cc8c1e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_57a4de5c-23a0-4a2a-94c2-b4fb8f55d196">
									<gml:exterior>
										<gml:LinearRing gml:id="line_04ff6a63-ac15-4486-bc36-5143ec2852ec">
											<gml:posList>35.6689680894952 139.74696227510623 9.82349083877449 35.66896693673856 139.7469601029011 9.82349083877449 35.6689680894952 139.74696227510623 7.403500299223708 35.6689680894952 139.74696227510623 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4d2338a5-d513-4bd4-b727-24c9a803ff19">
									<gml:exterior>
										<gml:LinearRing gml:id="line_595e0ba3-acc9-4934-a85f-1f2d9b919ce4">
											<gml:posList>35.6689680894952 139.74696227510623 7.403500299223708 35.66896693673856 139.7469601029011 9.82349083877449 35.66896693673856 139.7469601029011 7.403500299223708 35.6689680894952 139.74696227510623 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_8aca095e-0e6f-485b-a26a-c459c96d7b88">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a64db9fa-cd5f-4990-8850-363ec372415f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0bfb143b-ff5e-4682-9615-17d873c13831">
											<gml:posList>35.66897518235527 139.7469488418161 9.82349083877449 35.6689769793936 139.74694993393553 9.82349083877449 35.66897518235527 139.7469488418161 7.403500299223708 35.66897518235527 139.7469488418161 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8713567a-1879-47b7-886b-0a3e4fcf2abc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6318d46d-3cba-4551-aa41-52eda27de96f">
											<gml:posList>35.66897518235527 139.7469488418161 7.403500299223708 35.6689769793936 139.74694993393553 9.82349083877449 35.6689769793936 139.74694993393553 7.403500299223708 35.66897518235527 139.7469488418161 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_fee5525c-ce69-444d-8684-c8a7c5e50c65">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ae476bb5-393f-45f3-918a-974b365545ea">
									<gml:exterior>
										<gml:LinearRing gml:id="line_180b939d-29d6-4ca1-a0ba-e307129425c2">
											<gml:posList>35.668973116433335 139.74696501233024 9.82349083877449 35.668973116433335 139.74696501233024 7.403500299223708 35.668974802743165 139.74696474858774 9.82349083877449 35.668973116433335 139.74696501233024 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5de060fa-b75a-4489-ba7b-9e56aa5a3af8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_84a2f6c1-37a6-46ca-bb86-e1b03c98f7e5">
											<gml:posList>35.668974802743165 139.74696474858774 9.82349083877449 35.668973116433335 139.74696501233024 7.403500299223708 35.668974802743165 139.74696474858774 7.403500299223708 35.668974802743165 139.74696474858774 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0166_p1034_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1034_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1034_0">
											<gml:posList>35.66887016924144 139.74681718827335 38.34467518 35.6688926304082 139.74684489551566 38.34587328 35.66889267634999 139.74684490399287 26.14587437 35.66889050757248 139.74684222867023 26.1457586 35.66889058421758 139.7468422428056 5.79062195 35.668870291720246 139.74681721075314 5.78953961 35.66887016924144 139.74681718827335 38.34467518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_91e4874c-e984-4d5d-9e6a-4d5b1916f79e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7c94cc76-5976-48b7-997f-a2813b76201e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_687fa6f9-560e-4028-8113-e8ddb26eebc5">
											<gml:posList>35.66878816047488 139.7471094954069 7.334240655669021 35.66878816047488 139.7471094954069 9.53999016738777 35.66878904758522 139.74711120455322 7.334240655669021 35.66878816047488 139.7471094954069 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e2c72e0f-830e-4335-8d3a-12d2044677f1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7503030e-56a7-477e-801a-6f05cab4039d">
											<gml:posList>35.66878904758522 139.74711120455322 7.334240655669021 35.66878816047488 139.7471094954069 9.53999016738777 35.66878904758522 139.74711120455322 9.53999016738777 35.66878904758522 139.74711120455322 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1ad09c53-80f3-4201-9d05-1906376a422c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_688a2490-c305-4d6b-bb6b-0a4a146bb48a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_29fbbfab-1b81-4405-ae64-91ddd0a79aa5">
											<gml:posList>35.6688490060764 139.74707647993023 7.005749444731521 35.66885994949103 139.74706267576386 6.862499933012771 35.66885994949103 139.74706267576386 7.540844659575271 35.6688490060764 139.74707647993023 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c7987562-ccbd-45cb-9698-1f356ba6d1ed">
									<gml:exterior>
										<gml:LinearRing gml:id="line_824f3ef5-222f-440c-a3e3-dce13526c87f">
											<gml:posList>35.66885994949103 139.74706267576386 6.862499933012771 35.6688490060764 139.74707647993023 7.005749444731521 35.6688490060764 139.74707647993023 6.862499933012771 35.66885994949103 139.74706267576386 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3a5b2d86-8ac5-4f9a-8cce-a9ebbd0ab91a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e4b4e868-59ff-460a-9f5f-4dbc5b4920bc">
											<gml:posList>35.6688490060764 139.74707647993023 7.005749444731521 35.66885994949103 139.74706267576386 7.540844659575271 35.6688490060764 139.74707647993023 7.540844659575271 35.6688490060764 139.74707647993023 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_56e4a5d3-8d7b-43e7-bef0-48b2e4ee2b99">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7c2885a5-174c-408d-b75b-1d4813f61525">
											<gml:exterior>
												<gml:LinearRing gml:id="line_1a3b1ad9-26b8-4e50-bf81-96a26eebae25">
													<gml:posList>35.66885994949103 139.74706267576386 7.540844659575271 35.66885994949103 139.74706267576386 9.32349846816902 35.6688490060764 139.74707647993023 7.540844659575271 35.66885994949103 139.74706267576386 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a49c894f-046e-4ff7-8f1c-31c823499983">
											<gml:exterior>
												<gml:LinearRing gml:id="line_23e00f0c-6c96-4ef5-87cb-fb7574cfd4c6">
													<gml:posList>35.6688490060764 139.74707647993023 7.540844659575271 35.66885994949103 139.74706267576386 9.32349846816902 35.6688490060764 139.74707647993023 9.32349846816902 35.6688490060764 139.74707647993023 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c2ce7189-7ef3-4c4e-a7be-24c522e2d052">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8fef1ea6-691f-4c10-a5a0-ab24e8683ff4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_af3249c4-0bda-4904-ae30-4e12326cc11c">
											<gml:posList>35.668822571491525 139.74709405249337 7.334240655669021 35.66882332157342 139.7470945532893 7.334240655669021 35.668822571491525 139.74709405249337 9.53999016738777 35.668822571491525 139.74709405249337 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aa00d8a2-e469-4a3b-9044-c0106e5626b7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7ce64f86-be08-45d5-9567-f38a2fadfa5e">
											<gml:posList>35.668822571491525 139.74709405249337 9.53999016738777 35.66882332157342 139.7470945532893 7.334240655669021 35.66882332157342 139.7470945532893 9.53999016738777 35.668822571491525 139.74709405249337 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e0d5863a-836a-40f1-8760-f215fe0fa017">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c0a8bef8-d4ed-4694-a6d5-7f6d616d79ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7eb3161d-a6a4-46ed-8f7b-8da87484de67">
											<gml:posList>35.66880108475844 139.7470684711207 7.334240655669021 35.668822571491525 139.74709405249337 7.334240655669021 35.668822571491525 139.74709405249337 9.53999016738777 35.66880108475844 139.7470684711207 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9c39ec3e-f43d-4cc8-8aae-aa476a241ee7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bb38b9d6-aca9-4286-8822-938a9e85d5fb">
											<gml:posList>35.66880108475844 139.7470684711207 7.334240655669021 35.668822571491525 139.74709405249337 9.53999016738777 35.66880108475844 139.7470684711207 9.53999016738777 35.66880108475844 139.7470684711207 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_34ec493c-524c-4557-b9d5-b7d9d4709f74">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2ecfe516-acca-421e-976e-fbe360a623a4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1140daa9-3c01-4d4a-9e6d-4df18110cb6a">
											<gml:posList>35.66884596938364 139.74707286444294 7.540844659575271 35.66882958792571 139.74709352800622 7.005749444731521 35.66884596938364 139.74707286444294 7.005749444731521 35.66884596938364 139.74707286444294 7.540844659575271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c93e23b8-f2da-4273-a5e4-c7887c0b5bf4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8efadabc-9a71-403d-afea-78ce69326db6">
											<gml:posList>35.66882958792571 139.74709352800622 7.005749444731521 35.66884596938364 139.74707286444294 7.540844659575271 35.66882958792571 139.74709352800622 9.53999016738777 35.66882958792571 139.74709352800622 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ff19b8f2-0959-499c-9a4e-46b31f98cc25">
									<gml:exterior>
										<gml:LinearRing gml:id="line_457566e6-ecef-49ea-899c-f1c1ab9a2f74">
											<gml:posList>35.66882958792571 139.74709352800622 9.53999016738777 35.66884596938364 139.74707286444294 7.540844659575271 35.66884596938364 139.74707286444294 9.32349846816902 35.66882958792571 139.74709352800622 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9a0e0409-391c-472f-91fc-0885cca887ec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1741179e-11d5-42ac-b03c-ab8fd37b54b7">
											<gml:posList>35.66882958792571 139.74709352800622 9.53999016738777 35.66884596938364 139.74707286444294 9.32349846816902 35.66884596938364 139.74707286444294 9.53999016738777 35.66882958792571 139.74709352800622 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_82285372-b3cd-4295-b5e1-db56f6f73c88">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_3805da49-ddea-47d7-b103-543ad3273564">
											<gml:exterior>
												<gml:LinearRing gml:id="line_6ea8f8ab-2bac-44f1-96e5-b33fdc90a3e5">
													<gml:posList>35.6688490060764 139.74707647993023 7.540844659575271 35.6688490060764 139.74707647993023 9.32349846816902 35.66884596938364 139.74707286444294 7.540844659575271 35.6688490060764 139.74707647993023 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_437de65d-ac85-4c18-b928-fccda1ac3e17">
											<gml:exterior>
												<gml:LinearRing gml:id="line_101c9805-9291-404a-91a6-2801264493b0">
													<gml:posList>35.66884596938364 139.74707286444294 7.540844659575271 35.6688490060764 139.74707647993023 9.32349846816902 35.66884596938364 139.74707286444294 9.32349846816902 35.66884596938364 139.74707286444294 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_03d342d5-7c2e-479b-a4a0-92b0933fdb2b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f07d6b9f-533a-4ca6-866e-21002ace4c84">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d3188777-d5eb-48ef-9859-dc08e53e096d">
											<gml:posList>35.668989268030835 139.7469535362545 26.006245355376052 35.66898976631845 139.74695504929335 26.006245355376052 35.668989268030835 139.7469535362545 13.130490045317458 35.668989268030835 139.7469535362545 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dd7b4766-de9f-46ed-a73e-8f1aa12352e6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8d0bfc60-510b-443c-928b-9947606f15a5">
											<gml:posList>35.668989268030835 139.7469535362545 13.130490045317458 35.66898976631845 139.74695504929335 26.006245355376052 35.66898976631845 139.74695504929335 13.130490045317458 35.668989268030835 139.7469535362545 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7b189f2f-c06c-4a67-8678-62deff86a521">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5db9a5c8-f866-4da4-b277-fe7a000b2e3d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fdeca2e0-a3b0-49b0-8358-cad63297f058">
											<gml:posList>35.66885153428912 139.74708105619038 6.862499933012771 35.6688490060764 139.74707647993023 6.862499933012771 35.66885153428912 139.74708105619038 7.005749444731521 35.66885153428912 139.74708105619038 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c0d2e926-bc50-4d15-8cc7-9ecba466ae52">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e3b6a862-ded5-44a2-af14-a592de097541">
											<gml:posList>35.66885153428912 139.74708105619038 7.005749444731521 35.6688490060764 139.74707647993023 6.862499933012771 35.6688490060764 139.74707647993023 7.005749444731521 35.66885153428912 139.74708105619038 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1b252444-155a-43ec-9213-63d29b045eac">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7d8e4601-c30d-4b90-a066-c6e38c1c6bd7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eae12aa0-cc59-4ed0-88fd-a57f98d589e3">
											<gml:posList>35.66896923198461 139.74694994228216 7.403500299223708 35.66896923198461 139.74694994228216 9.82349083877449 35.668971027453225 139.7469488462924 7.403500299223708 35.66896923198461 139.74694994228216 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b56ff259-5120-4bc5-b3ef-8be53eaabf81">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a00daee2-69fc-45f4-8641-33f6dcdc54f1">
											<gml:posList>35.668971027453225 139.7469488462924 7.403500299223708 35.66896923198461 139.74694994228216 9.82349083877449 35.668971027453225 139.7469488462924 9.82349083877449 35.668971027453225 139.7469488462924 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_25126a4a-4032-48be-8d1a-fcdf2fcc30af">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5014a310-11a4-454c-9f90-fa8837868d5b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f6b8d953-2a09-4e8f-8c91-426cc798e2f8">
											<gml:posList>35.668975702115844 139.74696801882962 7.028240899809646 35.668975702115844 139.74696801882962 7.193997125395583 35.668977527285186 139.74697132262708 7.028240899809646 35.668975702115844 139.74696801882962 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f3de77d8-1818-41e4-b71a-c96eab33f116">
									<gml:exterior>
										<gml:LinearRing gml:id="line_afa9e6df-3f64-4e98-a7aa-f4935e47d173">
											<gml:posList>35.668977527285186 139.74697132262708 7.028240899809646 35.668975702115844 139.74696801882962 7.193997125395583 35.668977527285186 139.74697132262708 7.193997125395583 35.668977527285186 139.74697132262708 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_f8a6c79a-6c8a-45d8-be19-005addf54d63">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4d24f893-7772-43a8-a271-5dcfc2a89ebf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e0a03428-0d2a-4388-afb8-3ada40d60f0e">
											<gml:posList>35.6687762911241 139.74711328198674 7.334240655669021 35.6687762911241 139.74711328198674 9.53999016738777 35.66877683251109 139.7471112176884 7.334240655669021 35.6687762911241 139.74711328198674 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_50728059-e966-4024-b4df-9f733beae56f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b8564e42-b90c-4e05-a3be-3c4fe4d89986">
											<gml:posList>35.66877683251109 139.7471112176884 7.334240655669021 35.6687762911241 139.74711328198674 9.53999016738777 35.66877683251109 139.7471112176884 9.53999016738777 35.66877683251109 139.7471112176884 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_52d6d6f9-3fee-4a4d-9535-2e1b3a2e2f56">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a84791dc-f89c-4567-82fd-6f6ee7e2ed59">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f6b7211f-307b-4f15-b19a-6fd0ecce3b6a">
											<gml:posList>35.668978328505005 139.74695146038422 7.403500299223708 35.66897777473761 139.7469508339763 9.82349083877449 35.668978328505005 139.74695146038422 13.130490045317458 35.668978328505005 139.74695146038422 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_df56c8b5-41c6-46b4-b935-3149c4bbc603">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fb9e65ee-6c6a-49b6-8f70-31fd6bcc192c">
											<gml:posList>35.66897777473761 139.7469508339763 9.82349083877449 35.668978328505005 139.74695146038422 7.403500299223708 35.6689769793936 139.74694993393553 7.403500299223708 35.66897777473761 139.7469508339763 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4393183f-aed2-4e57-98e8-d1260a776f2a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f08bfe03-3827-4ba2-975f-9b4fb72ff84d">
											<gml:posList>35.668978328505005 139.74695146038422 13.130490045317458 35.66897777473761 139.7469508339763 9.82349083877449 35.66897777473761 139.7469508339763 13.130490045317458 35.668978328505005 139.74695146038422 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_08c1dfb7-acca-4b5b-95d4-0135c1d26d0f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bb466aa9-471f-446b-8293-3de9944461cb">
											<gml:posList>35.66897777473761 139.7469508339763 9.82349083877449 35.6689769793936 139.74694993393553 7.403500299223708 35.6689769793936 139.74694993393553 9.82349083877449 35.66897777473761 139.7469508339763 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c0e3945e-ae72-4ca6-a30a-fe32e4e05ca7">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_22aeafc9-baaa-467b-a7a4-e8ae02032d4c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7e7002b7-9011-47ec-8110-ab5d6500d16c">
											<gml:posList>35.66872502845572 139.74705440645425 10.527806024321364 35.668728509383584 139.74704993834914 33.88324425674324 35.668728509383584 139.74704993834914 6.862499933012771 35.66872502845572 139.74705440645425 10.527806024321364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2fb5491b-e495-4634-b151-9a404329b2ef">
									<gml:exterior>
										<gml:LinearRing gml:id="line_08235acc-9bf5-432b-bc6b-7ba3b4ca71ca">
											<gml:posList>35.668728509383584 139.74704993834914 33.88324425674324 35.66872502845572 139.74705440645425 10.527806024321364 35.66872502845572 139.74705440645425 33.88324425674324 35.668728509383584 139.74704993834914 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_578cab84-bebc-4509-a868-cc518765f731">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6e57aa99-b32c-4d9b-888d-583c38a85ad0">
											<gml:posList>35.66872502845572 139.74705440645425 10.527806024321364 35.668728509383584 139.74704993834914 6.862499933012771 35.668722386704474 139.74705779730166 6.862499933012771 35.66872502845572 139.74705440645425 10.527806024321364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3cda19fd-cedb-401a-b731-92425fb4a561">
									<gml:exterior>
										<gml:LinearRing gml:id="line_29328140-51cc-493a-b1da-132d0f9f2705">
											<gml:posList>35.66872502845572 139.74705440645425 10.527806024321364 35.668722386704474 139.74705779730166 6.862499933012771 35.668722386704474 139.74705779730166 10.527806024321364 35.66872502845572 139.74705440645425 10.527806024321364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_70ac9c78-47f9-48b1-adcd-04c63de9fe51">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_71a69733-b72b-4210-8715-0649c72da60e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_85452406-ce6f-4b81-a4f9-193ea29651f5">
											<gml:posList>35.66885994949103 139.74706267576386 9.32349846816902 35.6688635010178 139.74706690421718 9.32349846816902 35.66885994949103 139.74706267576386 9.82349083877449 35.66885994949103 139.74706267576386 9.32349846816902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_edced436-d3db-4203-aaa4-dc8c344b3b6b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aee0971f-55e5-4f9a-bec0-db8e4aeb7751">
											<gml:posList>35.66885994949103 139.74706267576386 9.82349083877449 35.6688635010178 139.74706690421718 9.32349846816902 35.6688635010178 139.74706690421718 9.82349083877449 35.66885994949103 139.74706267576386 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_b0b99ea8-62db-4f0b-9ccf-b436bf1a2b2d">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_5c6e66c3-1c13-4a38-8be2-3d186ac22076">
											<gml:exterior>
												<gml:LinearRing gml:id="line_8d000bbc-e044-4b95-b3b3-34390cd9993f">
													<gml:posList>35.6688635010178 139.74706690421718 7.540844659575271 35.6688635010178 139.74706690421718 9.32349846816902 35.66885994949103 139.74706267576386 9.32349846816902 35.6688635010178 139.74706690421718 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7301d0d8-5375-4d7e-afbe-11a921a5e8bb">
											<gml:exterior>
												<gml:LinearRing gml:id="line_8839f1f9-151b-4091-948a-d05a7792b9bd">
													<gml:posList>35.6688635010178 139.74706690421718 7.540844659575271 35.66885994949103 139.74706267576386 9.32349846816902 35.66885994949103 139.74706267576386 7.540844659575271 35.6688635010178 139.74706690421718 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_f97e145d-500f-402a-82ce-0ed7bf897a94">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_600219ef-1705-4bf5-a152-54513c81f059">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3bef3f39-9034-43ed-92e7-52d2979ed83e">
											<gml:posList>35.668787971667804 139.7471202992769 7.334240655669021 35.66878912130939 139.74711812459876 7.334240655669021 35.668787971667804 139.7471202992769 9.53999016738777 35.668787971667804 139.7471202992769 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5cb8bf9d-3b70-4a9c-88d1-477ce05ebc28">
									<gml:exterior>
										<gml:LinearRing gml:id="line_095c9d83-ca35-4322-aeba-d02c02aa3afa">
											<gml:posList>35.668787971667804 139.7471202992769 9.53999016738777 35.66878912130939 139.74711812459876 7.334240655669021 35.66878912130939 139.74711812459876 9.53999016738777 35.668787971667804 139.7471202992769 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a832d4bc-c580-481e-8d5f-fe4e416f99be">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_338d51cc-e2c2-4dfb-b28b-b7d2521445e0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c8837d86-107d-4297-84d6-b5d5b9dcd831">
											<gml:posList>35.668782948522754 139.74712304731034 7.334240655669021 35.668782948522754 139.74712304731034 9.53999016738777 35.668781261837466 139.7471227871984 7.334240655669021 35.668782948522754 139.74712304731034 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2609d02c-cfc1-426e-8686-d14a09f5536f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_79d40a79-9f46-43cc-a8d4-4d46ec0fa0ff">
											<gml:posList>35.668781261837466 139.7471227871984 7.334240655669021 35.668782948522754 139.74712304731034 9.53999016738777 35.668781261837466 139.7471227871984 9.53999016738777 35.668781261837466 139.7471227871984 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_92c976c3-9ca4-40c2-88ec-9a511381d187">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8be40ad6-1aa1-4c5a-a56b-834597d8f378">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8e820407-f07a-4fc4-830f-b51db4bd0806">
											<gml:posList>35.668782936659156 139.74710647826305 7.334240655669021 35.66878085956396 139.74710688147525 7.334240655669021 35.668782936659156 139.74710647826305 9.53999016738777 35.668782936659156 139.74710647826305 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ea108a2f-1275-49c4-8305-6b5361533144">
									<gml:exterior>
										<gml:LinearRing gml:id="line_973c93e5-db22-4caf-baae-2887ba30ab4d">
											<gml:posList>35.668782936659156 139.74710647826305 9.53999016738777 35.66878085956396 139.74710688147525 7.334240655669021 35.66878085956396 139.74710688147525 9.53999016738777 35.668782936659156 139.74710647826305 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_4d449897-d22b-4af5-aa54-03c2e75f94a3">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1a150aa5-539e-4b4b-80c6-90b742e95b13">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d9a053f4-6046-46d7-9d86-d1c10ebcd78f">
											<gml:posList>35.6689780460303 139.7469660742764 7.028240899809646 35.66898148814006 139.74697230471327 7.028240899809646 35.6689780460303 139.7469660742764 6.862499933012771 35.6689780460303 139.7469660742764 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_57ec3e61-93d6-4ae3-890f-219708ec076c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_741ee763-4e19-42f5-a516-f0b8c7d45455">
											<gml:posList>35.6689780460303 139.7469660742764 6.862499933012771 35.66898148814006 139.74697230471327 7.028240899809646 35.66898148814006 139.74697230471327 6.862499933012771 35.6689780460303 139.7469660742764 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e5b9b1d4-6b36-4e1d-a0ed-98c8ac0e595b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aa659ab4-9923-4dc1-b733-a0feb728c34a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ea6abf8e-4be7-4e44-b20f-f55fb48a4c28">
											<gml:posList>35.66885044045238 139.74707818747746 9.82349083877449 35.6688490060764 139.74707647993023 9.53999016738777 35.6688490060764 139.74707647993023 9.82349083877449 35.66885044045238 139.74707818747746 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f8082a87-aeda-4222-82b9-fc29fa9971bf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6c6ef906-8dc4-4595-9480-71a130823043">
											<gml:posList>35.6688490060764 139.74707647993023 9.53999016738777 35.66885044045238 139.74707818747746 9.82349083877449 35.668853181184396 139.74708145050974 9.53999016738777 35.6688490060764 139.74707647993023 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f958d2ae-7d78-4a5b-876d-40d1985a12fb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_403859b5-de1e-452d-8843-f4d06c452028">
											<gml:posList>35.668853181184396 139.74708145050974 9.53999016738777 35.66885044045238 139.74707818747746 9.82349083877449 35.668853181184396 139.74708145050974 10.527806024321364 35.668853181184396 139.74708145050974 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_232d6f58-7916-4f64-b7d5-4160653d915b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_462be479-e511-4909-9b68-56ef31f67693">
											<gml:posList>35.668853181184396 139.74708145050974 10.527806024321364 35.66885044045238 139.74707818747746 9.82349083877449 35.66885044045238 139.74707818747746 10.527806024321364 35.668853181184396 139.74708145050974 10.527806024321364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a21d64bf-dee3-4ec5-b20a-fa7680284d9e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2adcce02-14c3-4f90-8c67-d1e476580304">
									<gml:exterior>
										<gml:LinearRing gml:id="line_08b46b04-9551-469f-83b0-7ec8b2401c82">
											<gml:posList>35.66898769123957 139.74696420680735 26.006245355376052 35.668986752485125 139.74696509152423 26.006245355376052 35.66898769123957 139.74696420680735 13.130490045317458 35.66898769123957 139.74696420680735 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_600ee51e-ced5-47d3-8861-9371329fecc6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f93da30d-e10f-4abc-a932-d5530a84cfff">
											<gml:posList>35.66898769123957 139.74696420680735 13.130490045317458 35.668986752485125 139.74696509152423 26.006245355376052 35.668986752485125 139.74696509152423 13.130490045317458 35.66898769123957 139.74696420680735 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a59ca0b4-1c32-43a2-a050-674d8f431ce9">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_56caa3d9-5844-4cd4-9828-531776b193a4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9ec53219-6481-4f9f-88de-ea1782863bd1">
											<gml:posList>35.66896923198461 139.74694994228216 7.403500299223708 35.66896788506536 139.74695147163524 7.403500299223708 35.66896923198461 139.74694994228216 9.82349083877449 35.66896923198461 139.74694994228216 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_60557647-52ab-4595-9038-ee22f21de927">
									<gml:exterior>
										<gml:LinearRing gml:id="line_083dd0d2-e7c1-489f-b258-22188091806f">
											<gml:posList>35.66896923198461 139.74694994228216 9.82349083877449 35.66896788506536 139.74695147163524 7.403500299223708 35.66896788506536 139.74695147163524 9.82349083877449 35.66896923198461 139.74694994228216 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0166_p1034_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1034_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1034_3">
											<gml:posList>35.66870324369607 139.7470195574062 38.33814279 35.668756384275575 139.74694006713696 38.34012301 35.668756506171626 139.74694009024327 5.78498741 35.66870336532 139.74701958091805 5.78300719 35.66870324369607 139.7470195574062 38.33814279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_08deb0f0-65c8-4d28-8bd2-7f0a104ade66">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1af0d57a-b2b2-4fad-8547-da9e315af188">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7ae26b98-262d-4c9c-b6d0-613a67096c1e">
											<gml:posList>35.66896268365045 139.7469850610783 32.451023797758864 35.66886984293583 139.74687342411445 32.451023797758864 35.66896268365045 139.7469850610783 33.88324425674324 35.66896268365045 139.7469850610783 32.451023797758864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5c44f637-8993-4614-89e3-72e2e6a46b2b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f75535aa-6012-4a9a-b64d-f3921a10997d">
											<gml:posList>35.66896268365045 139.7469850610783 33.88324425674324 35.66886984293583 139.74687342411445 32.451023797758864 35.66886984293583 139.74687342411445 33.88324425674324 35.66896268365045 139.7469850610783 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_6ed22471-7f36-4c2d-865e-538c893dac82">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aa7c2631-f9e8-41c0-8697-099451429bee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_49ec28d8-8e1a-4418-9594-f10fdcd911c7">
											<gml:posList>35.6688490060764 139.74707647993023 7.540844659575271 35.66884596938364 139.74707286444294 7.540844659575271 35.6688490060764 139.74707647993023 7.005749444731521 35.6688490060764 139.74707647993023 7.540844659575271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_62c7e84e-4e93-439b-a92f-9e4305a4acf9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f9819e99-134d-41de-addc-dc74ecc2b688">
											<gml:posList>35.6688490060764 139.74707647993023 7.005749444731521 35.66884596938364 139.74707286444294 7.540844659575271 35.66884596938364 139.74707286444294 7.005749444731521 35.6688490060764 139.74707647993023 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_92a94eb1-76ed-4a5b-aab9-52e0dc8142b6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_794c915e-2b27-410e-b65b-d7351ca94429">
									<gml:exterior>
										<gml:LinearRing gml:id="line_beb2d3b8-1e85-4600-a1ea-0d99ac4ea22c">
											<gml:posList>35.66882332157342 139.7470945532893 7.334240655669021 35.668824104702395 139.74709491482795 7.334240655669021 35.66882332157342 139.7470945532893 9.53999016738777 35.66882332157342 139.7470945532893 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3b50d839-31ac-455a-a7c3-8668599a8032">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ee21548b-d195-4e1e-949e-e9914a65ae2f">
											<gml:posList>35.66882332157342 139.7470945532893 9.53999016738777 35.668824104702395 139.74709491482795 7.334240655669021 35.668824104702395 139.74709491482795 9.53999016738777 35.66882332157342 139.7470945532893 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_5342d31e-78a0-414f-83a7-a80dfc11688d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7cfb5ed1-4805-4dcb-b91f-3abad5c90356">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b37ad6e9-5c02-43d6-bdcb-add03c08be3b">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.66899116587438 139.74695518886168 6.862499933012771 35.66886723503126 139.74680616729975 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2f098ee2-8724-4de5-9bda-d9dd57afd6fc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6afa07ae-a804-4ce1-aaac-6815fd2f49d6">
											<gml:posList>35.66886723503126 139.74680616729975 7.403500299223708 35.66899116587438 139.74695518886168 6.862499933012771 35.66886723503126 139.74680616729975 6.862499933012771 35.66886723503126 139.74680616729975 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2ad58eb3-b3ef-48f3-9023-6d9296f65e1d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6e95726a-8adc-4fe7-bc04-79adf9a324b6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6c5d93fe-bf1c-44bf-a321-4af2079d8925">
											<gml:posList>35.668987423382646 139.74695068857324 24.323780755766677 35.66898780317941 139.74695114527066 26.006245355376052 35.668987423382646 139.74695068857324 22.75884697891121 35.668987423382646 139.74695068857324 24.323780755766677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fb1448a1-25a6-4a7e-986a-fd189a240b86">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2f5cac66-e670-433a-8fc4-6d9f164aea49">
											<gml:posList>35.66898780317941 139.74695114527066 26.006245355376052 35.668987423382646 139.74695068857324 24.323780755766677 35.668987423382646 139.74695068857324 25.98956749893074 35.66898780317941 139.74695114527066 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1a9cd466-5900-4cac-b77f-176f5834387b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_112ea5a0-b8b1-480f-a21c-d37efc0d163b">
											<gml:posList>35.668987423382646 139.74695068857324 24.323780755766677 35.668987423382646 139.74695068857324 22.75884697891121 35.668895999958785 139.74684075597477 24.323780755766677 35.668987423382646 139.74695068857324 24.323780755766677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d13409c0-2583-4c62-b035-f2da4661f197">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ed236191-5d83-4461-8bca-c80f05af5459">
											<gml:posList>35.668895999958785 139.74684075597477 11.427670221098708 35.66898256682945 139.74694484884185 9.82349083877449 35.66886723503126 139.74680616729975 9.82349083877449 35.668895999958785 139.74684075597477 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e72f0f02-afef-4f4f-b3ae-684f2461f638">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d099cf18-5aad-496b-b1bb-be296efcfffe">
											<gml:posList>35.66898256682945 139.74694484884185 9.82349083877449 35.668895999958785 139.74684075597477 11.427670221098708 35.66898256682945 139.74694484884185 11.427670221098708 35.66898256682945 139.74694484884185 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_17771914-cabe-4e4d-8027-b853c44414a9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8dad0d77-7a3b-490a-83ca-10c128d5a94e">
											<gml:posList>35.668895999958785 139.74684075597477 11.427670221098708 35.66886723503126 139.74680616729975 9.82349083877449 35.66889403751255 139.74683839604 11.427670221098708 35.668895999958785 139.74684075597477 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_97baa191-5975-4f7c-b573-088ab09297d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e8b3e1ac-ec4b-4086-8661-156263c52029">
											<gml:posList>35.66889403751255 139.74683839604 11.427670221098708 35.66886723503126 139.74680616729975 9.82349083877449 35.66886723503126 139.74680616729975 11.427670221098708 35.66889403751255 139.74683839604 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ade0fb2a-a2a4-42fa-9a66-49c261ae519c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c9c338b4-17ec-407c-9945-e39397187712">
											<gml:posList>35.66898780317941 139.74695114527066 26.006245355376052 35.66899423701073 139.74695888167824 27.38849328018074 35.66899423701073 139.74695888167824 26.006245355376052 35.66898780317941 139.74695114527066 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a57994e4-10e7-4fb5-bb3d-063615dded59">
									<gml:exterior>
										<gml:LinearRing gml:id="line_15cd2fd6-4d13-42e2-8825-6a406ba3b207">
											<gml:posList>35.66899423701073 139.74695888167824 27.38849328018074 35.66898780317941 139.74695114527066 26.006245355376052 35.668987423382646 139.74695068857324 25.98956749893074 35.66899423701073 139.74695888167824 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9efa4999-8f5b-46a2-968f-8ebe41f5b708">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cabbad32-4eee-41e9-937c-9b6dd87c3f3e">
											<gml:posList>35.66899423701073 139.74695888167824 27.38849328018074 35.668987423382646 139.74695068857324 25.98956749893074 35.66889403751255 139.74683839604 27.38849328018074 35.66899423701073 139.74695888167824 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ee919bc0-edb7-40eb-9a58-972c0d9438f1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d5815899-55c0-43e8-8922-e42ebc6319b0">
											<gml:posList>35.66889403751255 139.74683839604 27.38849328018074 35.668895999958785 139.74684075597477 25.98956749893074 35.668895999958785 139.74684075597477 24.323780755766677 35.66889403751255 139.74683839604 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4f9fcdf4-7439-4c17-95b2-649ab3c4ee98">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1d39fd62-61f4-4afd-b4ba-c90d6999b2d9">
											<gml:posList>35.668895999958785 139.74684075597477 25.98956749893074 35.66889403751255 139.74683839604 27.38849328018074 35.668987423382646 139.74695068857324 25.98956749893074 35.668895999958785 139.74684075597477 25.98956749893074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0872657a-2c01-482b-8273-3cf2e73bf4d6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_273edd01-0887-4ed7-9235-0e46382bf240">
											<gml:posList>35.66889403751255 139.74683839604 27.38849328018074 35.668895999958785 139.74684075597477 24.323780755766677 35.668895999958785 139.74684075597477 22.75884697891121 35.66889403751255 139.74683839604 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c6b1726d-cdcc-44b9-845a-22e260885591">
									<gml:exterior>
										<gml:LinearRing gml:id="line_71ac952e-3b83-406e-8f58-86db0d5d6231">
											<gml:posList>35.66889403751255 139.74683839604 27.38849328018074 35.668895999958785 139.74684075597477 22.75884697891121 35.668895999958785 139.74684075597477 21.093052606352614 35.66889403751255 139.74683839604 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_98f074ee-0d94-45c2-aff6-1f787d07fdaa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_805b16bd-6e69-4c13-91cb-f31df83a0880">
											<gml:posList>35.668895999958785 139.74684075597477 22.75884697891121 35.668895999958785 139.74684075597477 24.323780755766677 35.668987423382646 139.74695068857324 22.75884697891121 35.668895999958785 139.74684075597477 22.75884697891121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_509526c4-17f3-4f75-b34b-5d4cb44a2125">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f7d952f7-9ed6-4ec5-9daf-e01cbf9f21e3">
											<gml:posList>35.66889403751255 139.74683839604 27.38849328018074 35.668895999958785 139.74684075597477 21.093052606352614 35.668895999958785 139.74684075597477 19.528118829497146 35.66889403751255 139.74683839604 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c70a0f92-e5a9-40fa-b633-588524ff19d9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7db25166-1f2f-4d7b-912c-36c1db881bca">
											<gml:posList>35.66889403751255 139.74683839604 27.38849328018074 35.668895999958785 139.74684075597477 19.528118829497146 35.66889403751255 139.74683839604 11.427670221098708 35.66889403751255 139.74683839604 27.38849328018074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f6797553-4556-4a9e-9fa4-b85b11952809">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b555e2ab-897e-47c4-a805-5501646b483a">
											<gml:posList>35.668895999958785 139.74684075597477 19.528118829497146 35.668895999958785 139.74684075597477 21.093052606352614 35.668987423382646 139.74695068857324 21.093052606352614 35.668895999958785 139.74684075597477 19.528118829497146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7ff8cb5d-4293-4121-9f30-cb886a22bc7c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d2037921-07ea-417b-9da2-d9bd72e1c9d1">
											<gml:posList>35.66889403751255 139.74683839604 11.427670221098708 35.668895999958785 139.74684075597477 19.528118829497146 35.668895999958785 139.74684075597477 17.862324456938552 35.66889403751255 139.74683839604 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eb773b67-c9e9-4a74-b403-a177253271bb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_49488c70-579b-48f5-8acf-f6fb3e6d670b">
											<gml:posList>35.66889403751255 139.74683839604 11.427670221098708 35.668895999958785 139.74684075597477 17.862324456938552 35.668895999958785 139.74684075597477 16.297390680083083 35.66889403751255 139.74683839604 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_944d108c-d2f4-44c3-9dcf-eb4c75668b2d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1b2babda-fc47-4359-9c47-194f9985eb03">
											<gml:posList>35.668895999958785 139.74684075597477 16.297390680083083 35.668895999958785 139.74684075597477 17.862324456938552 35.668987423382646 139.74695068857324 17.862324456938552 35.668895999958785 139.74684075597477 16.297390680083083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4a336aa4-e4ea-45cc-be79-b8f36d045b46">
									<gml:exterior>
										<gml:LinearRing gml:id="line_056b2af6-0e90-48da-b9a1-484cea669f73">
											<gml:posList>35.66889403751255 139.74683839604 11.427670221098708 35.668895999958785 139.74684075597477 16.297390680083083 35.668895999958785 139.74684075597477 14.63159630752449 35.66889403751255 139.74683839604 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_af1ccf23-3b0b-44a6-8aac-c58242f5aee5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_030cdd45-df94-43d9-8446-e2603ff4a581">
											<gml:posList>35.66889403751255 139.74683839604 11.427670221098708 35.668895999958785 139.74684075597477 14.63159630752449 35.668895999958785 139.74684075597477 13.130490045317458 35.66889403751255 139.74683839604 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_038f69a6-1ef4-4f97-a7c0-cb32ae53edcc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_51bd2489-ed2f-4458-8374-a10f41fcfc41">
											<gml:posList>35.668895999958785 139.74684075597477 13.130490045317458 35.668895999958785 139.74684075597477 14.63159630752449 35.66898256682945 139.74694484884185 13.130490045317458 35.668895999958785 139.74684075597477 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4033322e-e97f-467b-a95f-f30091ddcae1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ad4ccf6b-1a03-4ea3-b442-5ec447a4a9fc">
											<gml:posList>35.66889403751255 139.74683839604 11.427670221098708 35.668895999958785 139.74684075597477 13.130490045317458 35.668895999958785 139.74684075597477 11.427670221098708 35.66889403751255 139.74683839604 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_724472f6-9aa1-4599-bad5-3df7ab05da80">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4e4ed3f7-ab04-43af-8f21-410b3c41ff64">
											<gml:posList>35.668987423382646 139.74695068857324 14.63159630752449 35.66898256682945 139.74694484884185 13.130490045317458 35.668895999958785 139.74684075597477 14.63159630752449 35.668987423382646 139.74695068857324 14.63159630752449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d8f60cc5-c82b-4716-96d8-6f6001b4509b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5e3ad65a-dcf6-44f1-8424-94e4d5ad35c7">
											<gml:posList>35.66898256682945 139.74694484884185 13.130490045317458 35.668987423382646 139.74695068857324 14.63159630752449 35.66898780317941 139.74695114527066 13.130490045317458 35.66898256682945 139.74694484884185 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6829b91f-e419-4921-bcc5-6f66c4122487">
									<gml:exterior>
										<gml:LinearRing gml:id="line_65ab1e33-2946-4bce-b2fd-4015648c06f3">
											<gml:posList>35.668895999958785 139.74684075597477 19.528118829497146 35.668987423382646 139.74695068857324 21.093052606352614 35.668987423382646 139.74695068857324 19.528118829497146 35.668895999958785 139.74684075597477 19.528118829497146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c723891f-f64e-4753-acdc-66d25f9909df">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d7ad1296-a031-4761-afa4-4e7d66a5f3b3">
											<gml:posList>35.668895999958785 139.74684075597477 16.297390680083083 35.668987423382646 139.74695068857324 17.862324456938552 35.668987423382646 139.74695068857324 16.297390680083083 35.668895999958785 139.74684075597477 16.297390680083083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_bb91bcf6-0708-4619-8f4c-3c41a21824c2">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_3f82c5f7-8abd-4608-a0fe-8e9d36404dc6">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a3f7c52d-c59d-4409-af43-28ffd05e77ce">
													<gml:posList>35.668987423382646 139.74695068857324 16.297390680083083 35.668987423382646 139.74695068857324 14.63159630752449 35.668895999958785 139.74684075597477 16.297390680083083 35.668987423382646 139.74695068857324 16.297390680083083</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_754eba55-5278-4f8e-8692-4629b96c630c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_91786c27-1e1f-4904-84f6-8638c4ec2c2a">
													<gml:posList>35.668895999958785 139.74684075597477 16.297390680083083 35.668987423382646 139.74695068857324 14.63159630752449 35.668895999958785 139.74684075597477 14.63159630752449 35.668895999958785 139.74684075597477 16.297390680083083</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_1d4795a7-c842-40b4-9523-c2bafd255064">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_dab88fa1-a5be-41cd-99b3-61e52c0930fd">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2b03283b-88fd-4bcf-8383-cc78f8a7336b">
													<gml:posList>35.668895999958785 139.74684075597477 11.427670221098708 35.668895999958785 139.74684075597477 13.130490045317458 35.66898256682945 139.74694484884185 11.427670221098708 35.668895999958785 139.74684075597477 11.427670221098708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_924d8c5b-469f-492a-9d79-6a70a6f48380">
											<gml:exterior>
												<gml:LinearRing gml:id="line_69fd3b19-dea0-4575-a646-2817da8e0ca0">
													<gml:posList>35.66898256682945 139.74694484884185 11.427670221098708 35.668895999958785 139.74684075597477 13.130490045317458 35.66898256682945 139.74694484884185 13.130490045317458 35.66898256682945 139.74694484884185 11.427670221098708</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_1b396f94-5db0-4a59-8b3c-270be950f8d4">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_3054972c-ff32-4f56-aa95-9761812e5aae">
											<gml:exterior>
												<gml:LinearRing gml:id="line_03bbbcdd-7be1-47a0-9ff6-1906e73067b9">
													<gml:posList>35.668895999958785 139.74684075597477 25.98956749893074 35.668987423382646 139.74695068857324 25.98956749893074 35.668895999958785 139.74684075597477 24.323780755766677 35.668895999958785 139.74684075597477 25.98956749893074</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a4116a1f-40c7-494c-ba13-063c4f0043df">
											<gml:exterior>
												<gml:LinearRing gml:id="line_5d8a1e69-3e36-45e6-a1c4-909a5692362a">
													<gml:posList>35.668895999958785 139.74684075597477 24.323780755766677 35.668987423382646 139.74695068857324 25.98956749893074 35.668987423382646 139.74695068857324 24.323780755766677 35.668895999958785 139.74684075597477 24.323780755766677</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_ba890383-7bf2-467d-a75c-5ad0512ff7f5">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e864b613-b9ca-416c-ad6a-a08c6e89efe8">
											<gml:exterior>
												<gml:LinearRing gml:id="line_87ef8891-ad02-49d1-842e-5eed6048bc77">
													<gml:posList>35.668987423382646 139.74695068857324 19.528118829497146 35.668987423382646 139.74695068857324 17.862324456938552 35.668895999958785 139.74684075597477 19.528118829497146 35.668987423382646 139.74695068857324 19.528118829497146</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_aaa2900b-c20a-4d6e-b933-eee2f8040c3c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_fa3dd88b-e1d1-47c5-b197-ca7680cdb66b">
													<gml:posList>35.668895999958785 139.74684075597477 19.528118829497146 35.668987423382646 139.74695068857324 17.862324456938552 35.668895999958785 139.74684075597477 17.862324456938552 35.668895999958785 139.74684075597477 19.528118829497146</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_1c57d43f-ee27-4ab7-ac37-5042b3348840">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_2405ae9d-a990-4e17-bcd6-3b87d8250c8c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_8713440a-0e10-423b-b65a-414336bbe806">
													<gml:posList>35.668987423382646 139.74695068857324 22.75884697891121 35.668987423382646 139.74695068857324 21.093052606352614 35.668895999958785 139.74684075597477 22.75884697891121 35.668987423382646 139.74695068857324 22.75884697891121</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a2ac1f98-c07f-47a8-b377-099ae88fc262">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ab8957f2-74fe-4a6a-8121-817c0fc79036">
													<gml:posList>35.668895999958785 139.74684075597477 22.75884697891121 35.668987423382646 139.74695068857324 21.093052606352614 35.668895999958785 139.74684075597477 21.093052606352614 35.668895999958785 139.74684075597477 22.75884697891121</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_ae048af6-a28e-4520-ba7e-f59a10af6ade">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_20065bbb-3861-4bc7-bc20-15e39e4ae2ad">
									<gml:exterior>
										<gml:LinearRing gml:id="line_444c8364-0e68-444d-9adb-d469122b21f9">
											<gml:posList>35.668978328505005 139.74695146038422 13.130490045317458 35.668979215479894 139.74695316936445 13.130490045317458 35.668978328505005 139.74695146038422 7.403500299223708 35.668978328505005 139.74695146038422 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5b6ad5d4-88ce-4ed5-963c-b308456f817d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3e840106-c52b-42df-bf8d-59d10de78da0">
											<gml:posList>35.668978328505005 139.74695146038422 7.403500299223708 35.668979215479894 139.74695316936445 13.130490045317458 35.668979215479894 139.74695316936445 7.403500299223708 35.668978328505005 139.74695146038422 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1f5eb9c5-802b-4049-b527-ba36e9d2404f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9e9418ec-374e-4792-a387-826f70d8addf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_57036bdb-249f-43ca-b60a-4a5e653975ed">
											<gml:posList>35.66896700054374 139.74695318252367 7.403500299223708 35.66896700054374 139.74695318252367 9.82349083877449 35.66896788506536 139.74695147163524 7.403500299223708 35.66896700054374 139.74695318252367 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_88e4ebff-032b-4ef9-b93e-aacdd1c3234e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fe2465e7-5500-4965-abf7-d14a68de292a">
											<gml:posList>35.66896788506536 139.74695147163524 7.403500299223708 35.66896700054374 139.74695318252367 9.82349083877449 35.66896788506536 139.74695147163524 9.82349083877449 35.66896788506536 139.74695147163524 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_9f1ad0d0-50f5-45b3-b387-0e43893d96a3">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_44fb275a-d545-41e4-a57c-ca7ab5879f31">
									<gml:exterior>
										<gml:LinearRing gml:id="line_716d657c-e1b0-423b-b64e-d76816803a83">
											<gml:posList>35.66882669017441 139.74709513520645 7.005749444731521 35.668827541505635 139.7470948969734 7.005749444731521 35.66882669017441 139.74709513520645 9.53999016738777 35.66882669017441 139.74709513520645 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6ab8bd91-1f6b-43e1-b17d-7c16bf32825b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f1da090a-c0f4-4903-b304-92fda81fd514">
											<gml:posList>35.66882669017441 139.74709513520645 9.53999016738777 35.668827541505635 139.7470948969734 7.005749444731521 35.668827541505635 139.7470948969734 9.53999016738777 35.66882669017441 139.74709513520645 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0166_p1034_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1034_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1034_2">
											<gml:posList>35.66872605177402 139.74704769264488 38.33935936 35.66870324369607 139.7470195574062 38.33814279 35.66870336532 139.74701958091805 5.78300719 35.66872617351469 139.74704771630016 5.78422376 35.66872605177402 139.74704769264488 38.33935936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_fb49cd69-1371-490c-842f-465b2a4de4bb">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c24a5b13-1ac7-4a7b-b7bb-5688d1468993">
									<gml:exterior>
										<gml:LinearRing gml:id="line_81424af0-380b-4998-982a-df56f874967a">
											<gml:posList>35.668988593976614 139.7469522258331 26.006245355376052 35.668989268030835 139.7469535362545 26.006245355376052 35.668988593976614 139.7469522258331 13.130490045317458 35.668988593976614 139.7469522258331 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b1e6842e-2834-422c-8799-b72638967785">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7a1ff43a-6e2b-4719-8f31-b92334172025">
											<gml:posList>35.668988593976614 139.7469522258331 13.130490045317458 35.668989268030835 139.7469535362545 26.006245355376052 35.668989268030835 139.7469535362545 13.130490045317458 35.668988593976614 139.7469522258331 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e7305233-57f6-4b13-a790-4567ef813abd">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4e3e05f8-5527-421f-9a61-7a19630f95b8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eb8323d4-5be2-4ac1-bb03-dbff17947692">
											<gml:posList>35.668971027453225 139.7469488462924 7.403500299223708 35.668971027453225 139.7469488462924 9.82349083877449 35.668973104547945 139.7469484432437 7.403500299223708 35.668971027453225 139.7469488462924 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ec11eb6f-ece4-44bd-9b29-6aa9416bbcdb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_44561958-05b1-4912-948f-b32eb9731db8">
											<gml:posList>35.668973104547945 139.7469484432437 7.403500299223708 35.668971027453225 139.7469488462924 9.82349083877449 35.668973104547945 139.7469484432437 9.82349083877449 35.668973104547945 139.7469484432437 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_6ba59574-519b-4581-a6cc-da67e9bb61fe">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c55474b5-98d9-43a0-ad0d-8e3f6db5dc24">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dd66efe7-3858-4493-8a44-64bb0198f7aa">
											<gml:posList>35.668977527285186 139.74697132262708 7.028240899809646 35.668977527285186 139.74697132262708 7.193997125395583 35.66894144609213 139.74700125863606 7.028240899809646 35.668977527285186 139.74697132262708 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e3e4bf17-7f6e-48fd-98d5-8f5b510ce1a7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_198b212c-907d-4b43-a896-56e181538cc2">
											<gml:posList>35.66894144609213 139.74700125863606 7.028240899809646 35.668977527285186 139.74697132262708 7.193997125395583 35.66894144609213 139.74700125863606 7.193997125395583 35.66894144609213 139.74700125863606 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7614b4ee-7b05-45d6-92b5-136766bfb5b6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f7168663-fbaa-44d7-985d-62026a0ffce3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_99601b0b-6d68-4bf4-89d2-69c40e761c2e">
											<gml:posList>35.66884596938364 139.74707286444294 9.32349846816902 35.6688490060764 139.74707647993023 9.32349846816902 35.66884596938364 139.74707286444294 9.53999016738777 35.66884596938364 139.74707286444294 9.32349846816902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1eac4b70-a285-4883-9efc-a5a03121f718">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cc95bbd5-5006-4f22-a988-606f6981797c">
											<gml:posList>35.66884596938364 139.74707286444294 9.53999016738777 35.6688490060764 139.74707647993023 9.32349846816902 35.6688490060764 139.74707647993023 9.53999016738777 35.66884596938364 139.74707286444294 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_336ef295-11b7-42b8-bfa8-d9ce6b0b6479">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4da1bd01-5014-4fcd-aeb5-6a8603287c9f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_01502a15-5b1b-42f4-9237-3bc096494316">
											<gml:posList>35.6688863730252 139.74704773054228 7.540844659575271 35.66888242642479 139.74704303175528 7.540844659575271 35.6688863730252 139.74704773054228 6.862499933012771 35.6688863730252 139.74704773054228 7.540844659575271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_90fe4db1-ff01-4960-adf8-edd1d977be21">
									<gml:exterior>
										<gml:LinearRing gml:id="line_97c2478d-0ae9-4cac-802c-239771a36225">
											<gml:posList>35.6688863730252 139.74704773054228 6.862499933012771 35.66888242642479 139.74704303175528 7.540844659575271 35.66888242642479 139.74704303175528 6.862499933012771 35.6688863730252 139.74704773054228 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_9ba93fb4-6000-4586-90c0-9ba64a4d9d35">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a8b973fa-fc7d-4e6c-86a4-815e2efc5101">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d17390f4-3d38-4862-bd0c-4b27fd0bc07c">
													<gml:posList>35.6688863730252 139.74704773054228 7.540844659575271 35.6688863730252 139.74704773054228 9.32349846816902 35.66888242642479 139.74704303175528 7.540844659575271 35.6688863730252 139.74704773054228 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_4955d318-6d2c-444d-b549-d3e74310f793">
											<gml:exterior>
												<gml:LinearRing gml:id="line_12e9a853-81f9-413d-b096-575c3ad2baf2">
													<gml:posList>35.66888242642479 139.74704303175528 7.540844659575271 35.6688863730252 139.74704773054228 9.32349846816902 35.66888242642479 139.74704303175528 9.32349846816902 35.66888242642479 139.74704303175528 7.540844659575271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_66ef9f97-dc52-45b3-b6a3-a607453291cd">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c1efe2ce-8e1e-4804-a455-a1c0310aa7e1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cf04fa6d-223a-48f5-ab67-338ca6d6c066">
											<gml:posList>35.66897983086256 139.74695762768138 13.130490045317458 35.66897928921328 139.7469600895948 13.130490045317458 35.66897928921328 139.7469600895948 7.403500299223708 35.66897983086256 139.74695762768138 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a823749f-e88b-4cb9-8a63-4e4a6c211056">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f4b7adc2-d3d2-4cf3-af68-34d1fc2cfa12">
											<gml:posList>35.66897983086256 139.74695762768138 13.130490045317458 35.66897928921328 139.7469600895948 7.403500299223708 35.66897983086256 139.74695762768138 7.403500299223708 35.66897983086256 139.74695762768138 13.130490045317458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e2058a8b-9f44-4e7d-9a7a-22d02d0acaa6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0f1433c1-650a-401e-b26a-78119feb1e52">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5bfbdfa2-e754-49d0-9691-54cbaa922852">
											<gml:posList>35.668966459159606 139.74695524699652 7.403500299223708 35.668966459159606 139.74695524699652 9.82349083877449 35.66896700054374 139.74695318252367 7.403500299223708 35.668966459159606 139.74695524699652 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5492ad2e-15cf-4eb3-aa75-b94751493a20">
									<gml:exterior>
										<gml:LinearRing gml:id="line_571e3de3-debe-4f86-aa62-1d6512375567">
											<gml:posList>35.66896700054374 139.74695318252367 7.403500299223708 35.668966459159606 139.74695524699652 9.82349083877449 35.66896700054374 139.74695318252367 9.82349083877449 35.66896700054374 139.74695318252367 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_992f7263-e7cf-4ea4-8a08-bb56e8153f6a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_14f22cf8-76ac-4901-9503-43d61068a2bb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5b3c52c1-0fa1-4656-bbbb-1536622c3271">
											<gml:posList>35.668969675354546 139.7469638629891 7.403500299223708 35.6689714298853 139.74696475222086 7.403500299223708 35.668969675354546 139.7469638629891 9.82349083877449 35.668969675354546 139.7469638629891 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9e642300-7d6a-4f61-ad72-33c8ed0af7f7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b1888ea4-805d-4b53-83a4-3d9d7611f7ea">
											<gml:posList>35.668969675354546 139.7469638629891 9.82349083877449 35.6689714298853 139.74696475222086 7.403500299223708 35.6689714298853 139.74696475222086 9.82349083877449 35.668969675354546 139.7469638629891 9.82349083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_b4e1832e-2d76-4d08-bab1-8ccd671521e6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d07b2c72-13a2-4efd-acc4-36289155475c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3fe4100d-9421-4416-a8a5-530ed794e36d">
											<gml:posList>35.668760943530145 139.74710416026082 9.53999016738777 35.668722386704474 139.74705779730166 10.527806024321364 35.668722386704474 139.74705779730166 6.862499933012771 35.668760943530145 139.74710416026082 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_febbd580-e8ce-4dfc-8cea-e3c1f9489f0e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b387ce51-69e4-4df6-a7d2-b16c3280196a">
											<gml:posList>35.668722386704474 139.74705779730166 10.527806024321364 35.668760943530145 139.74710416026082 9.53999016738777 35.66878470233259 139.74713272925038 10.527806024321364 35.668722386704474 139.74705779730166 10.527806024321364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5fd9a412-66a1-4ebb-9de6-130a7b9291ac">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8d3c4d15-3e25-44ae-985e-10b55b15e443">
											<gml:posList>35.668760943530145 139.74710416026082 9.53999016738777 35.668722386704474 139.74705779730166 6.862499933012771 35.668760943530145 139.74710416026082 7.334240655669021 35.668760943530145 139.74710416026082 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1de8f145-08fc-4bfe-9437-784f35ad2bd2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b709e60f-446c-4858-90d7-2f43472ad5d4">
											<gml:posList>35.668760943530145 139.74710416026082 7.334240655669021 35.668722386704474 139.74705779730166 6.862499933012771 35.668786560566524 139.74713496373204 6.862499933012771 35.668760943530145 139.74710416026082 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3ac9f652-3cf1-47cd-9860-17327fb1c7ba">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c2932fd4-a9f4-4580-85f5-944cefa32a10">
											<gml:posList>35.66878247531512 139.74713005137525 7.169247369536208 35.668760943530145 139.74710416026082 7.334240655669021 35.66878433258549 139.74713228467797 7.005749444731521 35.66878247531512 139.74713005137525 7.169247369536208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_00e4d592-553e-4f0e-94ed-283dddcd8807">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ae147a65-c181-4da5-aa79-6712429fef26">
											<gml:posList>35.668760943530145 139.74710416026082 7.334240655669021 35.66878247531512 139.74713005137525 7.169247369536208 35.66878247531512 139.74713005137525 7.334240655669021 35.668760943530145 139.74710416026082 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_55922cfa-0e87-4419-91f7-8a5975b58e84">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3ca5fa8c-ddd3-4c25-a3bf-6dd9aeef3f03">
											<gml:posList>35.66878433258549 139.74713228467797 7.005749444731521 35.668760943530145 139.74710416026082 7.334240655669021 35.668786560566524 139.74713496373204 6.862499933012771 35.66878433258549 139.74713228467797 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_84171398-3865-4ca9-a63c-b57cdaf4dd14">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8a4024a4-aaea-41c1-9e3d-5269718f1f98">
											<gml:posList>35.66878247531512 139.74713005137525 7.169247369536208 35.66878433258549 139.74713228467797 7.005749444731521 35.66878433258549 139.74713228467797 7.169247369536208 35.66878247531512 139.74713005137525 7.169247369536208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f7657701-3f49-4895-977d-151eeb707ba3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b29adf1d-6e31-44b4-8e82-eb32cf5e5ed6">
											<gml:posList>35.66878433258549 139.74713228467797 7.005749444731521 35.668786560566524 139.74713496373204 6.862499933012771 35.668786560566524 139.74713496373204 7.005749444731521 35.66878433258549 139.74713228467797 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e8380201-0714-4ac4-9528-dfda215d65b6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dd0a08d8-04c8-4829-9df1-48a26396cad9">
											<gml:posList>35.66878470233259 139.74713272925038 10.527806024321364 35.668760943530145 139.74710416026082 9.53999016738777 35.66878470233259 139.74713272925038 9.53999016738777 35.66878470233259 139.74713272925038 10.527806024321364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_dde836ab-86e9-4eaa-a6f4-129cdd90f223">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5e1138e4-fc09-41a7-80b0-74eefd5bfc7c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_72695c7c-2aaf-46f0-96ea-c32a8ac888f1">
											<gml:posList>35.66898854976548 139.7469630696895 26.006245355376052 35.66898854976548 139.7469630696895 13.130490045317458 35.66898926576778 139.74696169405894 26.006245355376052 35.66898854976548 139.7469630696895 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2362fb93-b518-4fb0-ba8a-47e4a7acefdd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_444d253d-8c0f-4648-ad24-a52efa4145f2">
											<gml:posList>35.66898926576778 139.74696169405894 26.006245355376052 35.66898854976548 139.7469630696895 13.130490045317458 35.66898926576778 139.74696169405894 13.130490045317458 35.66898926576778 139.74696169405894 26.006245355376052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_efed3bf6-9e8f-4e40-9188-e6dc4d171bde">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_242eb660-a6ed-4319-a76d-41e18786c8d8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eb44fc0e-04b4-4990-bb69-56e3eecca4ca">
											<gml:posList>35.66878744306315 139.74713599228184 10.527806024321364 35.66878470233259 139.74713272925038 10.527806024321364 35.66878744306315 139.74713599228184 9.53999016738777 35.66878744306315 139.74713599228184 10.527806024321364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fbefb2a4-5268-4f29-844a-90886a45fbba">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6e0bb0af-6027-4fb9-b406-1e800f4ea89c">
											<gml:posList>35.66878744306315 139.74713599228184 9.53999016738777 35.66878470233259 139.74713272925038 10.527806024321364 35.66878470233259 139.74713272925038 9.53999016738777 35.66878744306315 139.74713599228184 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a10822ac-b551-479a-a531-fec2249ca772">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9e180dab-a619-473b-b89f-03ae4993dd8d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c3785498-a595-4f46-b8ac-3adb2a6b31a6">
											<gml:posList>35.66879674790133 139.74710670173926 36.27749321914558 35.6687388262778 139.74703705329827 36.27749321914558 35.66879674790133 139.74710670173926 33.88324425674324 35.66879674790133 139.74710670173926 36.27749321914558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_21e70422-ec0d-4e57-8c93-9c5c48b69655">
									<gml:exterior>
										<gml:LinearRing gml:id="line_78dbfc38-5a83-44ab-aa92-eccfafe05f5f">
											<gml:posList>35.66879674790133 139.74710670173926 33.88324425674324 35.6687388262778 139.74703705329827 36.27749321914558 35.6687388262778 139.74703705329827 33.88324425674324 35.66879674790133 139.74710670173926 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_d2cd584a-e6af-499b-bd48-7d29e15967f3">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6a74b114-6639-4b17-8493-fdc7cf2fa06e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f802df7d-82b1-4365-aaea-fccc9d2a8047">
											<gml:posList>35.66879567557436 139.74707529408204 9.53999016738777 35.66879567557436 139.74707529408204 7.334240655669021 35.66880108475844 139.7470684711207 9.53999016738777 35.66879567557436 139.74707529408204 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_94061e7a-58e2-45a6-b8f6-d3629f0078b2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aa72e8d2-c0b2-4e19-a28b-426941751a23">
											<gml:posList>35.66880108475844 139.7470684711207 9.53999016738777 35.66879567557436 139.74707529408204 7.334240655669021 35.66880108475844 139.7470684711207 7.334240655669021 35.66880108475844 139.7470684711207 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_3cc95642-4108-458f-85d4-0a188213eb77">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e17c182b-2c0d-4d16-b7c9-f5ff1315a151">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e5cde816-afbd-4a06-ae67-7168c2c7e650">
													<gml:posList>35.66879567557436 139.74707529408204 9.53999016738777 35.66878508064132 139.74708865862158 9.53999016738777 35.66879567557436 139.74707529408204 7.334240655669021 35.66879567557436 139.74707529408204 9.53999016738777</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0f776909-25fd-4dee-a863-5255878ec489">
											<gml:exterior>
												<gml:LinearRing gml:id="line_74b74afe-ba34-403c-b6ce-15a3218ee7ad">
													<gml:posList>35.66879567557436 139.74707529408204 7.334240655669021 35.66878508064132 139.74708865862158 9.53999016738777 35.66878508064132 139.74708865862158 7.334240655669021 35.66879567557436 139.74707529408204 7.334240655669021</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_d9803182-c913-40df-9a04-601e183a7a84">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bc9fc428-d616-4f09-a935-772b357c63b0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b683d207-4fab-4193-9a1d-a22f1605c901">
											<gml:posList>35.66877771717241 139.74710950663706 7.334240655669021 35.66877683251109 139.7471112176884 7.334240655669021 35.66877771717241 139.74710950663706 9.53999016738777 35.66877771717241 139.74710950663706 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_31dc53ff-e1fb-4689-b303-fdb67d6f9a63">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4022c730-3e0c-4cb7-aabe-6d6348dcc255">
											<gml:posList>35.66877771717241 139.74710950663706 9.53999016738777 35.66877683251109 139.7471112176884 7.334240655669021 35.66877683251109 139.7471112176884 9.53999016738777 35.66877771717241 139.74710950663706 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0166_p1035_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0166_p1035_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0166_p1035_2">
											<gml:posList>35.66889688074204 139.74683438267795 26.14600944 35.66899900196845 139.74695670343104 26.15145925 35.66899907896092 139.74695671793145 5.79632261 35.668896957407576 139.7468343967882 5.79087279 35.66889688074204 139.74683438267795 26.14600944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e6d61a58-5ab8-4310-85de-9a1bd077c1a9">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_80e99de8-297f-4bb8-be4a-98d63b334a11">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d6e558b1-0a3d-441c-845c-0d0fc62f79b9">
											<gml:posList>35.66877394926528 139.7470877548669 7.334240655669021 35.66877394926528 139.7470877548669 9.53999016738777 35.668760943530145 139.74710416026082 7.334240655669021 35.66877394926528 139.7470877548669 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c6c15be3-c00a-4938-bff4-843577054516">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ef6058b-99c7-4e91-a0ce-2b99c98f29f9">
											<gml:posList>35.668760943530145 139.74710416026082 7.334240655669021 35.66877394926528 139.7470877548669 9.53999016738777 35.668760943530145 139.74710416026082 9.53999016738777 35.668760943530145 139.74710416026082 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_9588d22f-115b-420b-9ff8-ab4692a0388c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_45bb41d1-3b95-4afd-af7a-d2083030c1a2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bb6578fb-41dc-4a03-b212-d8b866db6fe8">
											<gml:posList>35.668728509383584 139.74704993834914 33.88324425674324 35.66870207904577 139.74701815687015 6.862499933012771 35.668728509383584 139.74704993834914 6.862499933012771 35.668728509383584 139.74704993834914 33.88324425674324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3f9d358a-d613-43eb-bf94-e9599c28b1b8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_81117fd4-7050-4569-848b-461f5ae2e627">
											<gml:posList>35.66870207904577 139.74701815687015 6.862499933012771 35.668728509383584 139.74704993834914 33.88324425674324 35.66870207904577 139.74701815687015 39.04224083877449 35.66870207904577 139.74701815687015 6.862499933012771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1e63a3a5-9ba8-4311-8c68-f67510feee3a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_530f08e8-0475-40c7-aecb-f062c99efecf">
											<gml:posList>35.66870207904577 139.74701815687015 39.04224083877449 35.668728509383584 139.74704993834914 33.88324425674324 35.668728509383584 139.74704993834914 39.04224083877449 35.66870207904577 139.74701815687015 39.04224083877449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_86787bf1-a1fc-431f-9b47-a70b78b8723d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ed236c79-0cbd-4c51-a9a9-2d2e57a90d11">
									<gml:exterior>
										<gml:LinearRing gml:id="line_72eed3e8-01ce-4b80-a3ac-be81bb9dad4e">
											<gml:posList>35.668786388086765 139.74712189073566 7.334240655669021 35.668787971667804 139.7471202992769 7.334240655669021 35.668786388086765 139.74712189073566 9.53999016738777 35.668786388086765 139.74712189073566 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_90ff2c26-c44b-41a2-b973-8f97f27c2201">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eced93c5-4211-4805-9ab0-63306fb27181">
											<gml:posList>35.668786388086765 139.74712189073566 9.53999016738777 35.668787971667804 139.7471202992769 7.334240655669021 35.668787971667804 139.7471202992769 9.53999016738777 35.668786388086765 139.74712189073566 9.53999016738777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_f4579199-f91b-4861-9663-ebd8379a8706">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_77df0420-898e-4da9-ada5-9a5d01ce6e1e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_192bc8a0-d315-457c-a930-bf7b134bc7b5">
											<gml:posList>35.66878793408452 139.74713004786625 10.527806024321364 35.66878470233259 139.74713272925038 10.527806024321364 35.66878744306315 139.74713599228184 10.527806024321364 35.66878793408452 139.74713004786625 10.527806024321364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3cb355ef-64d5-42ec-8237-c11829b185c5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4cd7e69d-f686-4312-9078-1a0fd08103e1">
											<gml:posList>35.66878470233259 139.74713272925038 10.527806024321364 35.66878793408452 139.74713004786625 10.527806024321364 35.66872502845572 139.74705440645425 10.527806024321364 35.66878470233259 139.74713272925038 10.527806024321364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_87315c77-175a-4c68-b8cf-3d7d86f3e3aa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_53f8c2cb-ac4c-4fa0-9933-c935a2a17622">
											<gml:posList>35.66878470233259 139.74713272925038 10.527806024321364 35.66872502845572 139.74705440645425 10.527806024321364 35.668722386704474 139.74705779730166 10.527806024321364 35.66878470233259 139.74713272925038 10.527806024321364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6db55a98-3e87-4075-9c6d-28fa0f9a156a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_47ec12c0-a76d-486d-8e49-ed63f72ddd2b">
											<gml:posList>35.66878793408452 139.74713004786625 10.527806024321364 35.66878744306315 139.74713599228184 10.527806024321364 35.668853181184396 139.74708145050974 10.527806024321364 35.66878793408452 139.74713004786625 10.527806024321364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ad78bde4-84ba-47d8-b77b-04634c8c23bd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_740b1d99-6a39-4739-a902-311436235d11">
											<gml:posList>35.66878793408452 139.74713004786625 10.527806024321364 35.668853181184396 139.74708145050974 10.527806024321364 35.66885044045238 139.74707818747746 10.527806024321364 35.66878793408452 139.74713004786625 10.527806024321364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_89410a64-8c97-43f8-8660-bb5d6a360b33">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dde2273e-0bf2-4e2e-95e8-731462ed1b6c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_45b3d9cc-c5bc-4910-9dd2-53eeaf3185df">
											<gml:posList>35.668861190555496 139.74681392574468 11.427670221098708 35.668887907687 139.74684605176202 11.427670221098708 35.66889403751255 139.74683839604 11.427670221098708 35.668861190555496 139.74681392574468 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_80acee62-5e8d-4be0-9f75-599d352007b4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9981c9e1-34a7-4d58-87d7-530430607306">
											<gml:posList>35.668861190555496 139.74681392574468 11.427670221098708 35.66889403751255 139.74683839604 11.427670221098708 35.66886723503126 139.74680616729975 11.427670221098708 35.668861190555496 139.74681392574468 11.427670221098708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_7dcf8414-08f5-406e-af87-fed070baa63f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8c2301ea-aa60-4775-8be0-1babf34ac923">
									<gml:exterior>
										<gml:LinearRing gml:id="line_633380ed-1180-4e41-b190-d481bf2ef9a7">
											<gml:posList>35.66896639155822 139.74695764215886 7.403500299223708 35.66894510831043 139.74695538882472 7.403500299223708 35.66894473719088 139.7469608932096 7.403500299223708 35.66896639155822 139.74695764215886 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_82ee9492-ae97-4839-a20a-ea372dd74905">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e90b9850-496c-46d4-88e7-b398944d95ae">
											<gml:posList>35.66894510831043 139.74695538882472 7.403500299223708 35.66896639155822 139.74695764215886 7.403500299223708 35.668966459159606 139.74695524699652 7.403500299223708 35.66894510831043 139.74695538882472 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_71424f09-3cab-44ae-8152-f780d62af675">
									<gml:exterior>
										<gml:LinearRing gml:id="line_01c8dbbe-df63-4c40-b488-48e0fbc38c5a">
											<gml:posList>35.66896639155822 139.74695764215886 7.403500299223708 35.66894473719088 139.7469608932096 7.403500299223708 35.66896693673856 139.7469601029011 7.403500299223708 35.66896639155822 139.74695764215886 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4ed456ca-62df-4595-abdf-9ab797bd4bc8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_28ee77d1-69f5-4cb0-af75-ccdb4f680964">
											<gml:posList>35.66896693673856 139.7469601029011 7.403500299223708 35.66894473719088 139.7469608932096 7.403500299223708 35.66894438250915 139.74696362021746 7.403500299223708 35.66896693673856 139.7469601029011 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9e6eacae-757f-47df-923a-260f857b3672">
									<gml:exterior>
										<gml:LinearRing gml:id="line_29bf1fc5-1b31-4f0a-b466-2984433bf20e">
											<gml:posList>35.66896693673856 139.7469601029011 7.403500299223708 35.66894438250915 139.74696362021746 7.403500299223708 35.66894402782738 139.74696634722534 7.403500299223708 35.66896693673856 139.7469601029011 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_41dfd5bb-495e-4eef-b293-5dc4196b117a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9b898597-452e-486b-a0f7-d47d76804e34">
											<gml:posList>35.66896693673856 139.7469601029011 7.403500299223708 35.66894402782738 139.74696634722534 7.403500299223708 35.6689680894952 139.74696227510623 7.403500299223708 35.66896693673856 139.7469601029011 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5381d9ca-2484-487c-bfe5-b6ea5274c434">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c27607df-f2a6-4f7e-97ab-b8595ab54d3f">
											<gml:posList>35.6689680894952 139.74696227510623 7.403500299223708 35.66894402782738 139.74696634722534 7.403500299223708 35.66894298418658 139.7469717201916 7.403500299223708 35.6689680894952 139.74696227510623 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_848ade0c-0552-40df-8758-3104f366368f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b4d590eb-eeae-424e-81bb-50bfa389f5b0">
											<gml:posList>35.6689680894952 139.74696227510623 7.403500299223708 35.66894298418658 139.7469717201916 7.403500299223708 35.668969675354546 139.7469638629891 7.403500299223708 35.6689680894952 139.74696227510623 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_546ec3b3-8d52-4788-8286-5023ac1d4c72">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a0113c6a-44e7-4b9b-9192-6aaa7fe878ca">
											<gml:posList>35.668969675354546 139.7469638629891 7.403500299223708 35.66894298418658 139.7469717201916 7.403500299223708 35.66894161216038 139.74697698108884 7.403500299223708 35.668969675354546 139.7469638629891 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_11073d8a-888a-4c82-8f8e-c5f2b364507a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c3b89719-ad3a-41ea-bc77-deeae991c3d8">
											<gml:posList>35.668969675354546 139.7469638629891 7.403500299223708 35.66894161216038 139.74697698108884 7.403500299223708 35.66893991984208 139.7469820999065 7.403500299223708 35.668969675354546 139.7469638629891 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_69c589cd-0d8c-4635-8d43-dc66b1a56c0b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_53180da3-d1ac-4a8a-bc0a-30393f3553ec">
											<gml:posList>35.668969675354546 139.7469638629891 7.403500299223708 35.66893991984208 139.7469820999065 7.403500299223708 35.6689714298853 139.74696475222086 7.403500299223708 35.668969675354546 139.7469638629891 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cbbeea6e-4f63-4d9e-95d3-b1fe5517def9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9b5b95f1-58a4-4592-80c0-b47e009a0228">
											<gml:posList>35.6689714298853 139.74696475222086 7.403500299223708 35.66893991984208 139.7469820999065 7.403500299223708 35.668937916700926 139.74698704747524 7.403500299223708 35.6689714298853 139.74696475222086 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d0c012a3-a5cf-4c74-ad45-607e43c551ae">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e609c040-9d41-4c60-8beb-1d69c6c4c64d">
											<gml:posList>35.6689714298853 139.74696475222086 7.403500299223708 35.668937916700926 139.74698704747524 7.403500299223708 35.668973116433335 139.74696501233024 7.403500299223708 35.6689714298853 139.74696475222086 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c2ef0e4c-c760-49fb-b558-6117fefb1c79">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e11a69c9-8709-4eb0-b025-f1f225597e7c">
											<gml:posList>35.668973116433335 139.74696501233024 7.403500299223708 35.668937916700926 139.74698704747524 7.403500299223708 35.66893561413224 139.74699179529793 7.403500299223708 35.668973116433335 139.74696501233024 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_686cf043-d98b-432d-b0f5-659b660d41ba">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f08503de-64b7-49d1-9add-e0df9ebada7a">
											<gml:posList>35.668973116433335 139.74696501233024 7.403500299223708 35.66893561413224 139.74699179529793 7.403500299223708 35.668932786690256 139.74699669925667 7.403500299223708 35.668973116433335 139.74696501233024 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_92e8d9f3-2a44-4a40-a813-12d6e9e41e91">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f5b2ba2d-5930-4149-ac95-5d3894a3dc74">
											<gml:posList>35.668926862691535 139.747005808151 7.403500299223708 35.668932786690256 139.74699669925667 7.403500299223708 35.66892611246553 139.7470049149722 7.403500299223708 35.668926862691535 139.747005808151 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aa6b3257-c719-42d0-9556-edbd7ef193e9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e665b2cf-729e-451f-9105-0e4cf8185348">
											<gml:posList>35.668932786690256 139.74699669925667 7.403500299223708 35.668926862691535 139.747005808151 7.403500299223708 35.668928215025566 139.74700741819677 7.403500299223708 35.668932786690256 139.74699669925667 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_94ec4e8c-7c75-4ef6-8d71-2fb1ea67b9ad">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9c1d32b6-eeae-46db-99f3-a90373cb1e3f">
											<gml:posList>35.668932786690256 139.74699669925667 7.403500299223708 35.668928215025566 139.74700741819677 7.403500299223708 35.668973116433335 139.74696501233024 7.403500299223708 35.668932786690256 139.74699669925667 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c87ce273-3636-4d2f-be3e-f45f28e33366">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a1ed31a7-e759-46ae-8cc5-34b2be781c86">
											<gml:posList>35.668973116433335 139.74696501233024 7.403500299223708 35.668928215025566 139.74700741819677 7.403500299223708 35.668974802743165 139.74696474858774 7.403500299223708 35.668973116433335 139.74696501233024 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4a2065a6-03cb-4260-8823-93336aaf7368">
									<gml:exterior>
										<gml:LinearRing gml:id="line_124e538d-4e55-4bf4-815b-7bfa5049b75a">
											<gml:posList>35.668906415466786 139.74686830662048 7.403500299223708 35.66886723503126 139.74680616729975 7.403500299223708 35.668861190555496 139.74681392574468 7.403500299223708 35.668906415466786 139.74686830662048 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_49824040-55fc-4da3-9b1d-2924cc9e703b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2385cf83-6a96-4826-8d29-0c029be95cb0">
											<gml:posList>35.66886723503126 139.74680616729975 7.403500299223708 35.668906415466786 139.74686830662048 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708 35.66886723503126 139.74680616729975 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6b681dab-3d09-4bf5-bc09-75eb346d5058">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1d9eb846-b4dd-4843-8a19-74f6be0eb66d">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.668906415466786 139.74686830662048 7.403500299223708 35.668930700464365 139.74690442435693 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6b771148-7e97-4282-aa3f-dcf3210197e3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_448294c3-29c1-484f-9db7-c26d9b45afb4">
											<gml:posList>35.668930700464365 139.74690442435693 7.403500299223708 35.668906415466786 139.74686830662048 7.403500299223708 35.668903594190766 139.7468718303237 7.403500299223708 35.668930700464365 139.74690442435693 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_11282eb9-a212-487a-a98a-ce42b2ec976e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_add962fd-a145-4529-9061-1fbd012ea382">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.668930700464365 139.74690442435693 7.403500299223708 35.66893351265158 139.74690874023833 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cd46b275-0428-4bd0-b1ce-f636b651359c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6db71a29-78f2-4a98-b833-e36b241b3bcb">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.66893351265158 139.74690874023833 7.403500299223708 35.66897518235527 139.7469488418161 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cbb67d4c-c1a2-41c9-9962-88133489992e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7b88a20f-ccf9-4ac8-86db-0a2f51470abd">
											<gml:posList>35.66897518235527 139.7469488418161 7.403500299223708 35.66893351265158 139.74690874023833 7.403500299223708 35.6689360507647 139.74691330435175 7.403500299223708 35.66897518235527 139.7469488418161 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_82b10347-47a4-4061-bf82-ae6b90866921">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3d4f74b7-6f3e-44f0-8785-46c458bdca5a">
											<gml:posList>35.66897518235527 139.7469488418161 7.403500299223708 35.6689360507647 139.74691330435175 7.403500299223708 35.66893830020564 139.74691809025063 7.403500299223708 35.66897518235527 139.7469488418161 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_63d359d7-0f00-4cd9-8cd3-cd6f73222282">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ddce6fb1-3b09-4a3f-9fcc-21ccdbf54e22">
											<gml:posList>35.66897518235527 139.7469488418161 7.403500299223708 35.66893830020564 139.74691809025063 7.403500299223708 35.668973104547945 139.7469484432437 7.403500299223708 35.66897518235527 139.7469488418161 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e6f3d7d1-18be-4448-ab88-90a5711fdda2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6def3a48-b50d-4743-8e88-66796c0a91fe">
											<gml:posList>35.668973104547945 139.7469484432437 7.403500299223708 35.66893830020564 139.74691809025063 7.403500299223708 35.66894024802613 139.7469230706439 7.403500299223708 35.668973104547945 139.7469484432437 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_116b1806-d170-4dc5-bc4b-1bf9e6a35bbc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e3e78462-aea8-41fe-80da-81499309bc09">
											<gml:posList>35.668973104547945 139.7469484432437 7.403500299223708 35.66894024802613 139.7469230706439 7.403500299223708 35.66894188334043 139.7469282173955 7.403500299223708 35.668973104547945 139.7469484432437 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e8c6742d-a945-4488-9963-1d1d1cc8869a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7476a601-c682-4991-8837-1ca194c35092">
											<gml:posList>35.668973104547945 139.7469484432437 7.403500299223708 35.66894188334043 139.7469282173955 7.403500299223708 35.668971027453225 139.7469488462924 7.403500299223708 35.668973104547945 139.7469484432437 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ceb491c4-eee9-4ee4-846e-8873d94a5b3c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cd758136-a8c8-4eff-bfff-0967454865e4">
											<gml:posList>35.668971027453225 139.7469488462924 7.403500299223708 35.66894188334043 139.7469282173955 7.403500299223708 35.668943196636945 139.74693350068227 7.403500299223708 35.668971027453225 139.7469488462924 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5d1ca59b-300f-43a5-a15b-d56e6b04292a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c8a9c5e7-0f37-4acb-b598-d4a0021d0434">
											<gml:posList>35.668971027453225 139.7469488462924 7.403500299223708 35.668943196636945 139.74693350068227 7.403500299223708 35.66896923198461 139.74694994228216 7.403500299223708 35.668971027453225 139.7469488462924 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_108d7006-60a2-485c-a394-912a1a5ce76d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_20ace362-09dd-4d76-b064-282f2c5ef1a7">
											<gml:posList>35.66896923198461 139.74694994228216 7.403500299223708 35.668943196636945 139.74693350068227 7.403500299223708 35.668944180467044 139.74693889051042 7.403500299223708 35.66896923198461 139.74694994228216 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e3578d4b-83d2-4a65-bc12-e5423a26b235">
									<gml:exterior>
										<gml:LinearRing gml:id="line_133b4361-fb76-40fe-b878-9cd2a0c82c82">
											<gml:posList>35.66896923198461 139.74694994228216 7.403500299223708 35.668944180467044 139.74693889051042 7.403500299223708 35.66896788506536 139.74695147163524 7.403500299223708 35.66896923198461 139.74694994228216 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_29c021d6-07b1-432f-8127-601f58b0200b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ce926e9d-24f9-43b8-85a4-b497275e2126">
											<gml:posList>35.66896788506536 139.74695147163524 7.403500299223708 35.668944180467044 139.74693889051042 7.403500299223708 35.66894482916951 139.74694435604144 7.403500299223708 35.66896788506536 139.74695147163524 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e113b0cf-dc9d-448f-b04f-d0812588107d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1da16028-4abb-4f49-bf71-be0d4bac15e4">
											<gml:posList>35.66896788506536 139.74695147163524 7.403500299223708 35.66894482916951 139.74694435604144 7.403500299223708 35.668944889214174 139.74694542306383 7.403500299223708 35.66896788506536 139.74695147163524 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_720ebdf2-cae9-4e46-ba93-2d6410c0d23c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_24fdeca2-be30-4091-a92a-13e817d09bd3">
											<gml:posList>35.66896788506536 139.74695147163524 7.403500299223708 35.668944889214174 139.74694542306383 7.403500299223708 35.66896700054374 139.74695318252367 7.403500299223708 35.66896788506536 139.74695147163524 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_278872ef-99c9-4e0f-bac5-6b7695fdf166">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2f2d326b-6635-491b-8cfb-943c6d87e20c">
											<gml:posList>35.66896700054374 139.74695318252367 7.403500299223708 35.668944889214174 139.74694542306383 7.403500299223708 35.668945139145826 139.74694986592885 7.403500299223708 35.66896700054374 139.74695318252367 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1c58d0fe-a9c5-4fcb-909e-973adfdf649f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4ce128cd-2760-4682-8f35-cdabf651fa39">
											<gml:posList>35.66896700054374 139.74695318252367 7.403500299223708 35.668945139145826 139.74694986592885 7.403500299223708 35.668966459159606 139.74695524699652 7.403500299223708 35.66896700054374 139.74695318252367 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_688320e9-bd74-4c12-ac48-4da5e2f54803">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f52b4727-8d76-4666-858e-373f6cadf2c0">
											<gml:posList>35.668966459159606 139.74695524699652 7.403500299223708 35.668945139145826 139.74694986592885 7.403500299223708 35.66894510831043 139.74695538882472 7.403500299223708 35.668966459159606 139.74695524699652 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_20ad2535-986b-4013-9857-bc25a4e75e0b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a1c69ed3-e752-4193-b1eb-8262679c0006">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.66897518235527 139.7469488418161 7.403500299223708 35.6689769793936 139.74694993393553 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e72d30d3-36aa-4c53-bd89-e414d0ab4373">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a73ab931-6a8f-4d56-9e1d-efd18925aadd">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.6689769793936 139.74694993393553 7.403500299223708 35.668978328505005 139.74695146038422 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_81bfdca8-e554-4524-a2e2-ff802b02ef40">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f4c182e1-0da9-43a6-a10c-a4f3c3124c72">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.668978328505005 139.74695146038422 7.403500299223708 35.668979215479894 139.74695316936445 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3141f76d-3a27-49ed-913e-86d4cd96de79">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6443ce30-9df7-49d6-8ba4-a532eca75d32">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.668979215479894 139.74695316936445 7.403500299223708 35.66897975982506 139.74695523266797 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5cf46790-e3f7-411e-be7e-f3a7031a00b0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_15d4248b-b1e2-4ad4-b576-45528618ce0e">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.66897975982506 139.74695523266797 7.403500299223708 35.66897983086256 139.74695762768138 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f6647dc3-ee31-4884-b7d9-afc654aa8989">
									<gml:exterior>
										<gml:LinearRing gml:id="line_df313898-1bb4-4d98-8e57-5e5f6c3390ce">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.66897983086256 139.74695762768138 7.403500299223708 35.66897928921328 139.7469600895948 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3edeb77c-3824-4330-9654-bf1ea036fe4c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_89694da5-9900-4cc5-90da-249eedb2515a">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.66897928921328 139.7469600895948 7.403500299223708 35.66897813957459 139.74696226428037 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4ba5cc4d-64d8-48e2-a15b-ef23d52fc384">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9570499f-0b5a-479a-b57b-94b0e2240030">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.66897813957459 139.74696226428037 7.403500299223708 35.668976555995584 139.7469638555775 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_29180d3f-b774-44cf-9329-f383d3679f81">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bb893333-f49a-40cb-9852-f4fb4b90399f">
											<gml:posList>35.66899116587438 139.74695518886168 7.403500299223708 35.668976555995584 139.7469638555775 7.403500299223708 35.668928215025566 139.74700741819677 7.403500299223708 35.66899116587438 139.74695518886168 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1d8b23eb-80fb-4274-82f8-a28b8e1b3477">
									<gml:exterior>
										<gml:LinearRing gml:id="line_71a6443a-4a93-457b-a1c0-3ca667cf93f5">
											<gml:posList>35.668928215025566 139.74700741819677 7.403500299223708 35.668976555995584 139.7469638555775 7.403500299223708 35.668974802743165 139.74696474858774 7.403500299223708 35.668928215025566 139.74700741819677 7.403500299223708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_12b82a92-5f97-4eff-9988-bbb93970b084">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4a1f37d5-dc78-4a7e-9fd3-242ffa0fd96c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8591898b-b340-4a69-8f90-8bb58801cbf1">
											<gml:posList>35.668826681301006 139.74709714870576 7.005749444731521 35.668786560566524 139.74713496373204 7.005749444731521 35.66885153428912 139.74708105619038 7.005749444731521 35.668826681301006 139.74709714870576 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b4882b17-c5cc-4c3b-84fa-9ffadf747439">
									<gml:exterior>
										<gml:LinearRing gml:id="line_37efd6d3-d17f-4d7b-89bd-6b2d59631892">
											<gml:posList>35.668786560566524 139.74713496373204 7.005749444731521 35.668826681301006 139.74709714870576 7.005749444731521 35.66878433258549 139.74713228467797 7.005749444731521 35.668786560566524 139.74713496373204 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_13b25aa3-562a-4b3e-b607-d75a64bbb096">
									<gml:exterior>
										<gml:LinearRing gml:id="line_af936438-880c-4c55-90b6-ec43990221b3">
											<gml:posList>35.668826681301006 139.74709714870576 7.005749444731521 35.66885153428912 139.74708105619038 7.005749444731521 35.66882958792571 139.74709352800622 7.005749444731521 35.668826681301006 139.74709714870576 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_53970898-c0ac-4a4a-97d5-a1ca6ab84c3f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a108e00b-1b8b-46d2-ae6c-7637d8c67ec8">
											<gml:posList>35.668826681301006 139.74709714870576 7.005749444731521 35.66882834239515 139.74709451552772 7.005749444731521 35.668827541505635 139.7470948969734 7.005749444731521 35.668826681301006 139.74709714870576 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ffd66a3e-614e-4d0f-b1eb-2e72f4589577">
									<gml:exterior>
										<gml:LinearRing gml:id="line_90680fad-1eb3-4c2b-85c1-cb2e9080943c">
											<gml:posList>35.66882834239515 139.74709451552772 7.005749444731521 35.668826681301006 139.74709714870576 7.005749444731521 35.66882907126424 139.74709401162417 7.005749444731521 35.66882834239515 139.74709451552772 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_40321561-45f3-47d7-a8a4-a4ab2a0b8d26">
									<gml:exterior>
										<gml:LinearRing gml:id="line_06e3bf25-8e1c-4562-8f9c-d1e5b79e0fb3">
											<gml:posList>35.66882907126424 139.74709401162417 7.005749444731521 35.668826681301006 139.74709714870576 7.005749444731521 35.66882958792571 139.74709352800622 7.005749444731521 35.66882907126424 139.74709401162417 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6dda6bd4-7fd5-4b40-918f-8a387abbc9fe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c9a6852a-76b5-4430-a210-1965b7c2a6d9">
											<gml:posList>35.66882958792571 139.74709352800622 7.005749444731521 35.66885153428912 139.74708105619038 7.005749444731521 35.6688490060764 139.74707647993023 7.005749444731521 35.66882958792571 139.74709352800622 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ebcfad6d-b004-4f13-b102-2fb875a008ed">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fd21e902-3f24-417e-a47b-bfc8e3acde3b">
											<gml:posList>35.66882958792571 139.74709352800622 7.005749444731521 35.6688490060764 139.74707647993023 7.005749444731521 35.66884596938364 139.74707286444294 7.005749444731521 35.66882958792571 139.74709352800622 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e9a2e11a-c450-4493-8bb4-f5215e1184bc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9436de68-d763-48e1-9293-c5d089ad4150">
											<gml:posList>35.668826681301006 139.74709714870576 7.005749444731521 35.66882669017441 139.74709513520645 7.005749444731521 35.668825814799824 139.74709521755724 7.005749444731521 35.668826681301006 139.74709714870576 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5d91e9ea-bf2b-4295-a054-3b5d73239544">
									<gml:exterior>
										<gml:LinearRing gml:id="line_66e37a6d-a6c7-4c74-9b7a-bdbb519efcf2">
											<gml:posList>35.66882669017441 139.74709513520645 7.005749444731521 35.668826681301006 139.74709714870576 7.005749444731521 35.668827541505635 139.7470948969734 7.005749444731521 35.66882669017441 139.74709513520645 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_851c53ca-09f1-44ae-a3ef-32f70b2a0307">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c99cc56b-afc5-48e4-88d2-1fb4096e036b">
											<gml:posList>35.668826681301006 139.74709714870576 7.005749444731521 35.668825814799824 139.74709521755724 7.005749444731521 35.668825604352556 139.74709519924318 7.005749444731521 35.668826681301006 139.74709714870576 7.005749444731521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_4a7728d9-1426-4352-983c-8c37ee7e9bea">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f16dd207-d77d-4df9-a6d2-ad4fd1c92d95">
									<gml:exterior>
										<gml:LinearRing gml:id="line_748ebdd8-57c1-4e69-8eb1-ca6e2e98b16d">
											<gml:posList>35.66877792145051 139.74712031008303 7.334240655669021 35.66878247531512 139.74713005137525 7.334240655669021 35.668779507307946 139.74712189813383 7.334240655669021 35.66877792145051 139.74712031008303 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_003590ac-d2ce-4f2b-92da-62116cece8e8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9889d836-38fd-44f6-ab04-aac7656c230a">
											<gml:posList>35.66878247531512 139.74713005137525 7.334240655669021 35.66877792145051 139.74712031008303 7.334240655669021 35.668760943530145 139.74710416026082 7.334240655669021 35.66878247531512 139.74713005137525 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_62fd7d77-93db-4d04-8125-48a7c4ba4df7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e998a3ac-4e4e-4607-a051-79ddf3eeba58">
											<gml:posList>35.668760943530145 139.74710416026082 7.334240655669021 35.66877792145051 139.74712031008303 7.334240655669021 35.668776768696695 139.7471181378808 7.334240655669021 35.668760943530145 139.74710416026082 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8518517d-28c5-4871-9a16-f03eeab1ca44">
									<gml:exterior>
										<gml:LinearRing gml:id="line_35336612-3892-4bbf-b466-f93eb627c926">
											<gml:posList>35.668760943530145 139.74710416026082 7.334240655669021 35.668776768696695 139.7471181378808 7.334240655669021 35.66877622365711 139.74711567714314 7.334240655669021 35.668760943530145 139.74710416026082 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cfec82bf-22fb-4fb7-8624-1f57435f80d8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_147456f0-4b87-4b82-ad6e-9c53d687d196">
											<gml:posList>35.668760943530145 139.74710416026082 7.334240655669021 35.66877622365711 139.74711567714314 7.334240655669021 35.6687762911241 139.74711328198674 7.334240655669021 35.668760943530145 139.74710416026082 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f1fcd7fd-0ea7-4d83-bb26-b21d940fee5c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a638dcf4-8dbd-41cc-ad55-dd75c849029b">
											<gml:posList>35.668760943530145 139.74710416026082 7.334240655669021 35.6687762911241 139.74711328198674 7.334240655669021 35.66877683251109 139.7471112176884 7.334240655669021 35.668760943530145 139.74710416026082 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e85a4faa-f191-4fee-94cd-0a3d0d480f15">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d822ad31-49bb-4576-a5af-07047ba219e3">
											<gml:posList>35.668760943530145 139.74710416026082 7.334240655669021 35.66877683251109 139.7471112176884 7.334240655669021 35.66877771717241 139.74710950663706 7.334240655669021 35.668760943530145 139.74710416026082 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2db2eaa7-09b6-450e-8f52-0c4a1ff1e97f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8300ccb9-86b2-4684-aec7-6ee3783c713b">
											<gml:posList>35.668760943530145 139.74710416026082 7.334240655669021 35.66877771717241 139.74710950663706 7.334240655669021 35.66878004439929 139.7470950114325 7.334240655669021 35.668760943530145 139.74710416026082 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_120b4ed6-ee9b-44ce-9d64-97b1cbc2dbef">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a9d17a2d-5381-4f6b-aac6-66edb491e039">
											<gml:posList>35.668760943530145 139.74710416026082 7.334240655669021 35.66878004439929 139.7470950114325 7.334240655669021 35.66877394926528 139.7470877548669 7.334240655669021 35.668760943530145 139.74710416026082 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_638dfc81-682b-486c-adf7-552f211d1f4b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_db225adf-1917-4167-ba6b-8f48e75ee6d8">
											<gml:posList>35.66878004439929 139.7470950114325 7.334240655669021 35.66877771717241 139.74710950663706 7.334240655669021 35.668779063956315 139.747107977459 7.334240655669021 35.66878004439929 139.7470950114325 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_64c9687a-185c-4610-823f-7e0abd650612">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8613a9d4-3c61-4c09-988a-b22a868890f5">
											<gml:posList>35.66878004439929 139.7470950114325 7.334240655669021 35.668779063956315 139.747107977459 7.334240655669021 35.66878085956396 139.74710688147525 7.334240655669021 35.66878004439929 139.7470950114325 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_217a3240-2d13-4c8a-82b1-ac210eb99941">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3baa7a36-6d1d-459d-a03e-29cfc901b9de">
											<gml:posList>35.66878004439929 139.7470950114325 7.334240655669021 35.66878085956396 139.74710688147525 7.334240655669021 35.668782936659156 139.74710647826305 7.334240655669021 35.66878004439929 139.7470950114325 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_435ee9bb-4051-4708-beed-9c4791110b4c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b7eb6fed-c22c-45bf-a576-e45e987cf9ac">
											<gml:posList>35.66878004439929 139.7470950114325 7.334240655669021 35.668782936659156 139.74710647826305 7.334240655669021 35.66878501432863 139.7471068770073 7.334240655669021 35.66878004439929 139.7470950114325 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ec74579e-3e32-47e0-94a4-00837fbf608d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_319b37a9-0712-4a00-ae5d-3e1a5fc3c363">
											<gml:posList>35.66878004439929 139.7470950114325 7.334240655669021 35.66878501432863 139.7471068770073 7.334240655669021 35.66878508064132 139.74708865862158 7.334240655669021 35.66878004439929 139.7470950114325 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_68c0ee15-a460-41e6-9b15-a3d9172ab4e6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0a006dc0-4a4b-4ecf-92e9-0db2b9b2d9ee">
											<gml:posList>35.668781261837466 139.7471227871984 7.334240655669021 35.66878247531512 139.74713005137525 7.334240655669021 35.668782948522754 139.74712304731034 7.334240655669021 35.668781261837466 139.7471227871984 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4048aafd-fee3-4016-a585-4025030c0aa5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_723319d7-16cc-44f5-a4b5-b6413cc8e843">
											<gml:posList>35.66878247531512 139.74713005137525 7.334240655669021 35.668781261837466 139.7471227871984 7.334240655669021 35.668779507307946 139.74712189813383 7.334240655669021 35.66878247531512 139.74713005137525 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1437f806-207a-4634-a4ea-5539db3865ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_11bacfe2-c9e2-4dbc-8b84-4085ffc6b4e4">
											<gml:posList>35.668782948522754 139.74712304731034 7.334240655669021 35.66878247531512 139.74713005137525 7.334240655669021 35.66878463483299 139.74712278357183 7.334240655669021 35.668782948522754 139.74712304731034 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ef161d32-e9db-497c-bf40-83b889252e06">
									<gml:exterior>
										<gml:LinearRing gml:id="line_27e7f187-e034-4ff1-b29c-03888c8ffcc1">
											<gml:posList>35.66878463483299 139.74712278357183 7.334240655669021 35.66878247531512 139.74713005137525 7.334240655669021 35.668786388086765 139.74712189073566 7.334240655669021 35.66878463483299 139.74712278357183 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6d542b3a-3a03-40d5-baa4-42018ce7c39f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bb8cf289-27c9-401a-bb2d-e3cb931562e5">
											<gml:posList>35.668786388086765 139.74712189073566 7.334240655669021 35.66878247531512 139.74713005137525 7.334240655669021 35.668787971667804 139.7471202992769 7.334240655669021 35.668786388086765 139.74712189073566 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cdf99f6f-2707-4338-913d-c1f3e5c5ca67">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a8605da8-88fc-4f7b-91c4-6016f5e1e71e">
											<gml:posList>35.668787971667804 139.7471202992769 7.334240655669021 35.66878247531512 139.74713005137525 7.334240655669021 35.66882464767257 139.74709506155605 7.334240655669021 35.668787971667804 139.7471202992769 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6267d857-d6e1-4704-84e3-94a781bc6724">
									<gml:exterior>
										<gml:LinearRing gml:id="line_84160f76-4db2-43b2-91d5-25d91056d615">
											<gml:posList>35.668787971667804 139.7471202992769 7.334240655669021 35.66882464767257 139.74709506155605 7.334240655669021 35.66878912130939 139.74711812459876 7.334240655669021 35.668787971667804 139.7471202992769 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ddf8d01d-a0e2-48db-bfa6-d05103e9c5f3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a4d9f619-d86e-4d45-afba-c11d9af800fa">
											<gml:posList>35.66878912130939 139.74711812459876 7.334240655669021 35.66882464767257 139.74709506155605 7.334240655669021 35.668824104702395 139.74709491482795 7.334240655669021 35.66878912130939 139.74711812459876 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b6cbc77-7dbf-4b6a-9dd8-a42e47362932">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2e6065b8-b4a0-4d3c-9dd3-53aafa56a424">
											<gml:posList>35.66878912130939 139.74711812459876 7.334240655669021 35.668824104702395 139.74709491482795 7.334240655669021 35.66878966282438 139.7471156626924 7.334240655669021 35.66878912130939 139.74711812459876 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_36b4d888-2f89-4c5f-822c-89d343cf9152">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ded9185-c340-444a-91e5-0425c6409706">
											<gml:posList>35.66878966282438 139.7471156626924 7.334240655669021 35.668824104702395 139.74709491482795 7.334240655669021 35.66882332157342 139.7470945532893 7.334240655669021 35.66878966282438 139.7471156626924 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e82acd50-1168-4b5a-bb01-6522c4e2fbe5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a90f747f-9064-4164-aedd-6cfa4eea28f6">
											<gml:posList>35.66878966282438 139.7471156626924 7.334240655669021 35.66882332157342 139.7470945532893 7.334240655669021 35.668822571491525 139.74709405249337 7.334240655669021 35.66878966282438 139.7471156626924 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_859bdadb-aab5-4009-bf71-2f607cae12b5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a454034e-535d-4a64-a448-f37cfe4b0557">
											<gml:posList>35.66878966282438 139.7471156626924 7.334240655669021 35.668822571491525 139.74709405249337 7.334240655669021 35.668789591927585 139.74711326768437 7.334240655669021 35.66878966282438 139.7471156626924 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c16528bc-016d-47ce-acbf-bb71343dba9d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f13b7f9a-75cb-4b63-acb2-d4e7be33bb48">
											<gml:posList>35.668789591927585 139.74711326768437 7.334240655669021 35.668822571491525 139.74709405249337 7.334240655669021 35.66878904758522 139.74711120455322 7.334240655669021 35.668789591927585 139.74711326768437 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bcc0fbf7-b81c-4835-a61f-b803d9c059e2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_01b76986-cd84-4d71-8af3-6abc17ac19bc">
											<gml:posList>35.66878904758522 139.74711120455322 7.334240655669021 35.668822571491525 139.74709405249337 7.334240655669021 35.66878816047488 139.7471094954069 7.334240655669021 35.66878904758522 139.74711120455322 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0eaf5075-bb53-4588-a219-01fe561fa6f4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bc04e05d-813f-4bfd-92b9-37aa69c76065">
											<gml:posList>35.66878816047488 139.7471094954069 7.334240655669021 35.668822571491525 139.74709405249337 7.334240655669021 35.66878508064132 139.74708865862158 7.334240655669021 35.66878816047488 139.7471094954069 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4dbe5a36-a879-4685-8a92-667e8ec8de99">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3ea68bcc-8dd9-4937-a170-c83cfbcfac74">
											<gml:posList>35.66878816047488 139.7471094954069 7.334240655669021 35.66878508064132 139.74708865862158 7.334240655669021 35.668786811503104 139.7471079691275 7.334240655669021 35.66878816047488 139.7471094954069 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7d9ed9d4-808e-4fc7-9597-dcb92b73aab8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b52b42a3-4a98-47be-a6cf-1ddf40b16ad6">
											<gml:posList>35.668786811503104 139.7471079691275 7.334240655669021 35.66878508064132 139.74708865862158 7.334240655669021 35.66878501432863 139.7471068770073 7.334240655669021 35.668786811503104 139.7471079691275 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8d16bd1b-1a8d-48e5-83b2-eeae44a63c68">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c730ab53-0b6c-457d-a57a-f8c4d9876ccc">
											<gml:posList>35.66879567557436 139.74707529408204 7.334240655669021 35.668822571491525 139.74709405249337 7.334240655669021 35.66880108475844 139.7470684711207 7.334240655669021 35.66879567557436 139.74707529408204 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_882fee62-8368-43a0-bc95-29ad9cb43e85">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1351ce4c-86fa-498a-ae82-6705f490c125">
											<gml:posList>35.668822571491525 139.74709405249337 7.334240655669021 35.66879567557436 139.74707529408204 7.334240655669021 35.66878508064132 139.74708865862158 7.334240655669021 35.668822571491525 139.74709405249337 7.334240655669021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_9d477c67-d822-48d2-b083-64c4b4cc4480">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_abca9584-8707-4664-a063-12fabddee791">
									<gml:exterior>
										<gml:LinearRing gml:id="line_687a1b8d-54c4-4fa8-b140-003fceb4ad07">
											<gml:posList>35.66893962092371 139.74699795500794 7.193997125395583 35.66894144609213 139.74700125863606 7.193997125395583 35.668975702115844 139.74696801882962 7.193997125395583 35.66893962092371 139.74699795500794 7.193997125395583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_af768772-558d-43ad-88fa-a8eee10805f1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_91489e9c-a61d-4444-95c2-7ce8735f0cda">
											<gml:posList>35.668975702115844 139.74696801882962 7.193997125395583 35.66894144609213 139.74700125863606 7.193997125395583 35.668977527285186 139.74697132262708 7.193997125395583 35.668975702115844 139.74696801882962 7.193997125395583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_acee5c02-3b04-4f53-8f7b-4782ddc0c385">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e3feffda-aac2-402a-85ae-e96feb079329">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d7f04b1a-a4c7-4594-abbe-a3d24865cab8">
											<gml:posList>35.66882464767257 139.74709506155605 7.169247369536208 35.66878433258549 139.74713228467797 7.169247369536208 35.668826681301006 139.74709714870576 7.169247369536208 35.66882464767257 139.74709506155605 7.169247369536208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3a6bdac9-8f69-44cd-b752-9c110299ad44">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ecf40c0c-2905-4a55-a34b-79cf12e57c42">
											<gml:posList>35.66878433258549 139.74713228467797 7.169247369536208 35.66882464767257 139.74709506155605 7.169247369536208 35.66878247531512 139.74713005137525 7.169247369536208 35.66878433258549 139.74713228467797 7.169247369536208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_42690e13-8d5a-4d2d-be0e-4df248a7c4f6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d016ff26-3f78-4fa8-a0c1-86363e7bf231">
											<gml:posList>35.66882464767257 139.74709506155605 7.169247369536208 35.668826681301006 139.74709714870576 7.169247369536208 35.66882494371311 139.74709514163564 7.169247369536208 35.66882464767257 139.74709506155605 7.169247369536208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6e51fbb6-d233-40f1-b836-604ba9cbf40c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a207f60e-7dc9-42c3-8f01-4428db4943d6">
											<gml:posList>35.66882494371311 139.74709514163564 7.169247369536208 35.668826681301006 139.74709714870576 7.169247369536208 35.668825604352556 139.74709519924318 7.169247369536208 35.66882494371311 139.74709514163564 7.169247369536208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_f326d25d-3468-4119-ac36-d2b7a5215656">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_88efc967-a222-481c-bab0-83c8e854aa7a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0cdb96aa-279f-45a3-9c9e-18d1247b6149">
											<gml:posList>35.668977527285186 139.74697132262708 7.028240899809646 35.6689780460303 139.7469660742764 7.028240899809646 35.668975702115844 139.74696801882962 7.028240899809646 35.668977527285186 139.74697132262708 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b8cfef43-6ceb-466a-afcb-183742ab767b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4ca3ed59-e7e7-424c-a087-02f105b123c0">
											<gml:posList>35.6689780460303 139.7469660742764 7.028240899809646 35.668977527285186 139.74697132262708 7.028240899809646 35.66898148814006 139.74697230471327 7.028240899809646 35.6689780460303 139.7469660742764 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f0786993-3d7e-4d70-b8bf-ed4a4a9612ad">
									<gml:exterior>
										<gml:LinearRing gml:id="line_207d929e-8637-4593-808c-6f3f21fa31bf">
											<gml:posList>35.66894144609213 139.74700125863606 7.028240899809646 35.66898148814006 139.74697230471327 7.028240899809646 35.668977527285186 139.74697132262708 7.028240899809646 35.66894144609213 139.74700125863606 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5004f097-0018-4dc3-8eb2-9339cd03a3ff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_03b1b2ff-0484-40c0-810d-91031784084d">
											<gml:posList>35.66898148814006 139.74697230471327 7.028240899809646 35.66894144609213 139.74700125863606 7.028240899809646 35.66894061286278 139.74700621842882 7.028240899809646 35.66898148814006 139.74697230471327 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_59aade6b-aa44-4d16-88c5-af4aea8ffd05">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c8e69293-352b-49f7-88c9-6576feca81f9">
											<gml:posList>35.66894061286278 139.74700621842882 7.028240899809646 35.66894144609213 139.74700125863606 7.028240899809646 35.66893717061708 139.74699998782526 7.028240899809646 35.66894061286278 139.74700621842882 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3ca67d89-a93d-40d1-93c7-3b9ea781c345">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b41ceb67-5133-4a91-964d-3887f3408d5c">
											<gml:posList>35.66893717061708 139.74699998782526 7.028240899809646 35.66894144609213 139.74700125863606 7.028240899809646 35.66893962092371 139.74699795500794 7.028240899809646 35.66893717061708 139.74699998782526 7.028240899809646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:lod3Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#Poly_45f01eb6-521c-4aad-b04d-f48e04860de6"/>
							<gml:surfaceMember xlink:href="#Poly_65affafd-9af2-434b-bac1-fee789ad0d64"/>
							<gml:surfaceMember xlink:href="#Poly_e7697ecb-dbbc-4e50-bce1-e2e5f7155f82"/>
							<gml:surfaceMember xlink:href="#Poly_dcba4c51-cfd4-42b6-a8a6-4f1d181f7da9"/>
							<gml:surfaceMember xlink:href="#Poly_e17c182b-2c0d-4d16-b7c9-f5ff1315a151"/>
							<gml:surfaceMember xlink:href="#Poly_0f776909-25fd-4dee-a863-5255878ec489"/>
							<gml:surfaceMember xlink:href="#Poly_05b0b2dc-d12c-489a-9733-fca7b17c9b0a"/>
							<gml:surfaceMember xlink:href="#Poly_c33a2e9d-e47f-4c23-84cf-ef834d07461d"/>
							<gml:surfaceMember xlink:href="#Poly_3805da49-ddea-47d7-b103-543ad3273564"/>
							<gml:surfaceMember xlink:href="#Poly_437de65d-ac85-4c18-b928-fccda1ac3e17"/>
							<gml:surfaceMember xlink:href="#Poly_f7168663-fbaa-44d7-985d-62026a0ffce3"/>
							<gml:surfaceMember xlink:href="#Poly_1eac4b70-a285-4883-9efc-a5a03121f718"/>
							<gml:surfaceMember xlink:href="#Poly_5c6e66c3-1c13-4a38-8be2-3d186ac22076"/>
							<gml:surfaceMember xlink:href="#Poly_7301d0d8-5375-4d7e-afbe-11a921a5e8bb"/>
							<gml:surfaceMember xlink:href="#Poly_71a69733-b72b-4210-8715-0649c72da60e"/>
							<gml:surfaceMember xlink:href="#Poly_edced436-d3db-4203-aaa4-dc8c344b3b6b"/>
							<gml:surfaceMember xlink:href="#Poly_a8b973fa-fc7d-4e6c-86a4-815e2efc5101"/>
							<gml:surfaceMember xlink:href="#Poly_4955d318-6d2c-444d-b549-d3e74310f793"/>
							<gml:surfaceMember xlink:href="#Poly_eda1a2b6-bb9d-4050-b5b9-0e557d3853dc"/>
							<gml:surfaceMember xlink:href="#Poly_d0707d20-dcef-4786-905a-72f95bd20098"/>
							<gml:surfaceMember xlink:href="#Poly_7639d46e-a1a4-451a-8a45-def70ce56b76"/>
							<gml:surfaceMember xlink:href="#Poly_35150210-62dc-45a9-b054-9064d98b9975"/>
							<gml:surfaceMember xlink:href="#Poly_aaa4a429-18ad-407e-99fa-b21d2838082b"/>
							<gml:surfaceMember xlink:href="#Poly_4f9812ee-6374-4027-ab14-03e8f245422f"/>
							<gml:surfaceMember xlink:href="#Poly_5758ecf7-9169-40f5-965e-3aec1bfa8315"/>
							<gml:surfaceMember xlink:href="#Poly_ac099cf6-665a-4d51-a3bd-9d25d4932674"/>
							<gml:surfaceMember xlink:href="#Poly_3db872a2-f7a6-4adf-9a39-9b3c543393ec"/>
							<gml:surfaceMember xlink:href="#Poly_8c2a6be2-eeb5-4e05-b096-f3df824faeba"/>
							<gml:surfaceMember xlink:href="#Poly_7c2885a5-174c-408d-b75b-1d4813f61525"/>
							<gml:surfaceMember xlink:href="#Poly_a49c894f-046e-4ff7-8f1c-31c823499983"/>
							<gml:surfaceMember xlink:href="#Poly_f7ea122a-5cc5-4799-93d5-5c64e4cf51df"/>
							<gml:surfaceMember xlink:href="#Poly_6320fd55-e62a-46f1-9e28-f7012af89e5a"/>
							<gml:surfaceMember xlink:href="#Poly_3ba33ce6-7ced-4423-93a4-a3b3cb4fd609"/>
							<gml:surfaceMember xlink:href="#Poly_d20eca30-5714-4a57-bdce-3ee2959c9e76"/>
							<gml:surfaceMember xlink:href="#Poly_983597ab-9548-4889-a522-4bd02b5dc59c"/>
							<gml:surfaceMember xlink:href="#Poly_f072672c-fd81-49fa-a6cc-7e9bf8a77813"/>
							<gml:surfaceMember xlink:href="#Poly_063d4663-9a72-47e9-b8d0-94b25282cb18"/>
							<gml:surfaceMember xlink:href="#Poly_e55f3692-7df3-493f-98e7-acaf334d42a3"/>
							<gml:surfaceMember xlink:href="#Poly_cf69dd22-0b1f-4d3f-9a2f-40bf909771f7"/>
							<gml:surfaceMember xlink:href="#Poly_c9271af6-13e5-4087-9c0e-437e28b1d7c1"/>
							<gml:surfaceMember xlink:href="#Poly_53c1fbe3-48d4-4873-92d6-2dce129eec76"/>
							<gml:surfaceMember xlink:href="#Poly_dab88fa1-a5be-41cd-99b3-61e52c0930fd"/>
							<gml:surfaceMember xlink:href="#Poly_924d8c5b-469f-492a-9d79-6a70a6f48380"/>
							<gml:surfaceMember xlink:href="#Poly_3f82c5f7-8abd-4608-a0fe-8e9d36404dc6"/>
							<gml:surfaceMember xlink:href="#Poly_754eba55-5278-4f8e-8692-4629b96c630c"/>
							<gml:surfaceMember xlink:href="#Poly_e864b613-b9ca-416c-ad6a-a08c6e89efe8"/>
							<gml:surfaceMember xlink:href="#Poly_aaa2900b-c20a-4d6e-b933-eee2f8040c3c"/>
							<gml:surfaceMember xlink:href="#Poly_2405ae9d-a990-4e17-bcd6-3b87d8250c8c"/>
							<gml:surfaceMember xlink:href="#Poly_a2ac1f98-c07f-47a8-b377-099ae88fc262"/>
							<gml:surfaceMember xlink:href="#Poly_3054972c-ff32-4f56-aa95-9761812e5aae"/>
							<gml:surfaceMember xlink:href="#Poly_a4116a1f-40c7-494c-ba13-063c4f0043df"/>
							<gml:surfaceMember xlink:href="#Poly_60af26fa-d1b2-4f77-83d1-c446e7e58078"/>
							<gml:surfaceMember xlink:href="#Poly_724ef00d-cb6d-4843-9e4c-5f32311c6b55"/>
							<gml:surfaceMember xlink:href="#Poly_a4b5532d-dabb-4168-a37c-54be518a7dfc"/>
							<gml:surfaceMember xlink:href="#Poly_4c9367a1-7130-43fd-bf3b-3d125988d700"/>
							<gml:surfaceMember xlink:href="#Poly_0569995d-2594-4f0e-b3e0-f6f132a601a5"/>
							<gml:surfaceMember xlink:href="#Poly_ddd4c59a-ab57-4f53-8a05-d7d2d2e085a4"/>
							<gml:surfaceMember xlink:href="#Poly_1af0d57a-b2b2-4fad-8547-da9e315af188"/>
							<gml:surfaceMember xlink:href="#Poly_5c44f637-8993-4614-89e3-72e2e6a46b2b"/>
							<gml:surfaceMember xlink:href="#Poly_1e475fa0-475a-4627-827e-3e2b0ebd38d7"/>
							<gml:surfaceMember xlink:href="#Poly_cf24dc4d-c607-465e-a968-24ad0acd2f0f"/>
							<gml:surfaceMember xlink:href="#Poly_3a0d7a23-3ab3-494e-a52c-a037d181e821"/>
							<gml:surfaceMember xlink:href="#Poly_1d19b3ce-2946-4a5e-99ed-6cb6f8ed6c7b"/>
							<gml:surfaceMember xlink:href="#Poly_8db7017e-e47d-4a35-a9be-e9fe9ac19abe"/>
							<gml:surfaceMember xlink:href="#Poly_e9a81529-338a-4c2c-8f3d-ff3f5225a037"/>
							<gml:surfaceMember xlink:href="#Poly_d4abcba0-f380-4bcd-b511-ffc96ae9e712"/>
							<gml:surfaceMember xlink:href="#Poly_d60e9a84-be8b-4f13-b81b-c09a9545e7c3"/>
							<gml:surfaceMember xlink:href="#Poly_06c667a5-b476-41d6-b598-b5f239279cc4"/>
							<gml:surfaceMember xlink:href="#Poly_fcb8ad53-c4a8-4ade-a193-34f37817ad87"/>
							<gml:surfaceMember xlink:href="#Poly_f1903cb9-b96f-4d36-a248-23bb8bfb2c37"/>
							<gml:surfaceMember xlink:href="#Poly_2b66c184-e492-419f-a34e-2c153db47f37"/>
							<gml:surfaceMember xlink:href="#Poly_0d8ca10c-3e21-4673-be23-682bba005be5"/>
							<gml:surfaceMember xlink:href="#Poly_8169f1a2-f09c-476a-8683-00df479b2349"/>
							<gml:surfaceMember xlink:href="#Poly_5014a310-11a4-454c-9f90-fa8837868d5b"/>
							<gml:surfaceMember xlink:href="#Poly_f3de77d8-1818-41e4-b71a-c96eab33f116"/>
							<gml:surfaceMember xlink:href="#Poly_abca9584-8707-4664-a063-12fabddee791"/>
							<gml:surfaceMember xlink:href="#Poly_af768772-558d-43ad-88fa-a8eee10805f1"/>
							<gml:surfaceMember xlink:href="#Poly_c55474b5-98d9-43a0-ad0d-8e3f6db5dc24"/>
							<gml:surfaceMember xlink:href="#Poly_e3e4bf17-7f6e-48fd-98d5-8f5b510ce1a7"/>
							<gml:surfaceMember xlink:href="#Poly_88efc967-a222-481c-bab0-83c8e854aa7a"/>
							<gml:surfaceMember xlink:href="#Poly_b8cfef43-6ceb-466a-afcb-183742ab767b"/>
							<gml:surfaceMember xlink:href="#Poly_f0786993-3d7e-4d70-b8bf-ed4a4a9612ad"/>
							<gml:surfaceMember xlink:href="#Poly_5004f097-0018-4dc3-8eb2-9339cd03a3ff"/>
							<gml:surfaceMember xlink:href="#Poly_59aade6b-aa44-4d16-88c5-af4aea8ffd05"/>
							<gml:surfaceMember xlink:href="#Poly_3ca67d89-a93d-40d1-93c7-3b9ea781c345"/>
							<gml:surfaceMember xlink:href="#Poly_347cd4ce-3959-4353-9cc2-9ee52ecb30b9"/>
							<gml:surfaceMember xlink:href="#Poly_77580377-df63-4283-8792-f1de720c524c"/>
							<gml:surfaceMember xlink:href="#Poly_262cd248-ddd2-41e2-99ec-6c27b4e14480"/>
							<gml:surfaceMember xlink:href="#Poly_3bbb24d1-924e-4b9a-96ea-eb2c3724e842"/>
							<gml:surfaceMember xlink:href="#Poly_daa67583-5cbf-46bc-aeca-514143e5b922"/>
							<gml:surfaceMember xlink:href="#Poly_0d20d44d-d947-4d72-9d4b-4f101c6c7a98"/>
							<gml:surfaceMember xlink:href="#Poly_bece02e9-1d4c-4ffc-8184-c9bb72020a26"/>
							<gml:surfaceMember xlink:href="#Poly_5e8996be-da8c-47b5-a479-ca22ee006512"/>
							<gml:surfaceMember xlink:href="#Poly_8bc0efab-a2c3-4fbd-b0e3-d5037a75d3e9"/>
							<gml:surfaceMember xlink:href="#Poly_4b647e63-f9c6-4d11-acbd-1708eab8ce95"/>
							<gml:surfaceMember xlink:href="#Poly_1a150aa5-539e-4b4b-80c6-90b742e95b13"/>
							<gml:surfaceMember xlink:href="#Poly_57ec3e61-93d6-4ae3-890f-219708ec076c"/>
							<gml:surfaceMember xlink:href="#Poly_bba238c1-e06b-4281-b94a-e583a0405925"/>
							<gml:surfaceMember xlink:href="#Poly_a450fa7c-80f1-43bf-bea7-3acf74669fdb"/>
							<gml:surfaceMember xlink:href="#Poly_63be3d00-222a-46de-9fcb-ef04d734d720"/>
							<gml:surfaceMember xlink:href="#Poly_d35d12b4-1314-446c-a31f-acee8433d3fd"/>
							<gml:surfaceMember xlink:href="#Poly_07aab5b0-8b3c-4120-a569-d4c86e8a2603"/>
							<gml:surfaceMember xlink:href="#Poly_73185008-e5d3-475f-9aa7-80586480819c"/>
							<gml:surfaceMember xlink:href="#Poly_63e002e5-ab04-4ce3-9bc9-4ff94056179c"/>
							<gml:surfaceMember xlink:href="#Poly_a99d2763-a3b2-46d5-aa57-5c02051d4361"/>
							<gml:surfaceMember xlink:href="#Poly_0709b26c-ebff-4486-a2f7-469a846e63f4"/>
							<gml:surfaceMember xlink:href="#Poly_d7c3b8ec-8fd5-4abb-8b10-cf8fa0f68214"/>
							<gml:surfaceMember xlink:href="#Poly_0cdb6ea2-e8d8-4b1a-9fe0-e51c45f7c45f"/>
							<gml:surfaceMember xlink:href="#Poly_bd757961-dbb2-46bb-adb7-ce4a6c278260"/>
							<gml:surfaceMember xlink:href="#Poly_8529d853-9360-4c8b-9e5d-b43fa621f52c"/>
							<gml:surfaceMember xlink:href="#Poly_0a584516-ddab-4c78-8749-ba5b45eea290"/>
							<gml:surfaceMember xlink:href="#Poly_8738af03-b3b0-4a11-bbc0-7514efb3adcb"/>
							<gml:surfaceMember xlink:href="#Poly_508916ea-1eec-4e90-940f-601334c65abb"/>
							<gml:surfaceMember xlink:href="#Poly_98974dbf-742a-499b-b23d-35b3c183db32"/>
							<gml:surfaceMember xlink:href="#Poly_71cd12fc-756c-4598-9afb-bd6b3ebe1584"/>
							<gml:surfaceMember xlink:href="#Poly_08d9f51b-791f-4d88-b1e7-8eec63373c5c"/>
							<gml:surfaceMember xlink:href="#Poly_25c5e7bb-6859-48cf-b36e-d7e0b6c94171"/>
							<gml:surfaceMember xlink:href="#Poly_a1a03033-96e2-444b-a611-f9f6f47bd166"/>
							<gml:surfaceMember xlink:href="#Poly_0024e684-f9ec-4838-9730-83b990cbb02d"/>
							<gml:surfaceMember xlink:href="#Poly_346e83a7-8ec4-410b-97b6-a8d49ae6f4f9"/>
							<gml:surfaceMember xlink:href="#Poly_a157e5e3-1484-4805-b2b7-b36dd1a46751"/>
							<gml:surfaceMember xlink:href="#Poly_90f02b09-0797-44ce-8177-29bbe826bc3b"/>
							<gml:surfaceMember xlink:href="#Poly_002afdb6-9730-4c20-8efb-87dee4076453"/>
							<gml:surfaceMember xlink:href="#Poly_22aeafc9-baaa-467b-a7a4-e8ae02032d4c"/>
							<gml:surfaceMember xlink:href="#Poly_2fb5491b-e495-4634-b151-9a404329b2ef"/>
							<gml:surfaceMember xlink:href="#Poly_578cab84-bebc-4509-a868-cc518765f731"/>
							<gml:surfaceMember xlink:href="#Poly_3cda19fd-cedb-401a-b731-92425fb4a561"/>
							<gml:surfaceMember xlink:href="#Poly_45bb41d1-3b95-4afd-af7a-d2083030c1a2"/>
							<gml:surfaceMember xlink:href="#Poly_3f9d358a-d613-43eb-bf94-e9599c28b1b8"/>
							<gml:surfaceMember xlink:href="#Poly_1e63a3a5-9ba8-4311-8c68-f67510feee3a"/>
							<gml:surfaceMember xlink:href="#Poly_cace2828-fed4-49d0-a66c-e660596939e3"/>
							<gml:surfaceMember xlink:href="#Poly_6395a1a9-4c47-4980-8de9-1f09a9fbc4ac"/>
							<gml:surfaceMember xlink:href="#Poly_66554aff-54bc-4cf3-b858-fc2ef5b6578d"/>
							<gml:surfaceMember xlink:href="#Poly_4de63487-73bf-477a-aa95-163647a7422d"/>
							<gml:surfaceMember xlink:href="#Poly_9e54f7f5-00c6-4fb6-98f3-611a0f08ef33"/>
							<gml:surfaceMember xlink:href="#Poly_f8653643-80f8-4835-883b-641e4c5a50fe"/>
							<gml:surfaceMember xlink:href="#Poly_12df8e71-2d53-4332-ab07-62ca9ea6a559"/>
							<gml:surfaceMember xlink:href="#Poly_0308ab7e-b064-4105-93e7-f636d1fd4477"/>
							<gml:surfaceMember xlink:href="#Poly_249abf4a-5744-4fb1-a735-95333e25e98d"/>
							<gml:surfaceMember xlink:href="#Poly_f16dd207-d77d-4df9-a6d2-ad4fd1c92d95"/>
							<gml:surfaceMember xlink:href="#Poly_003590ac-d2ce-4f2b-92da-62116cece8e8"/>
							<gml:surfaceMember xlink:href="#Poly_62fd7d77-93db-4d04-8125-48a7c4ba4df7"/>
							<gml:surfaceMember xlink:href="#Poly_8518517d-28c5-4871-9a16-f03eeab1ca44"/>
							<gml:surfaceMember xlink:href="#Poly_cfec82bf-22fb-4fb7-8624-1f57435f80d8"/>
							<gml:surfaceMember xlink:href="#Poly_f1fcd7fd-0ea7-4d83-bb26-b21d940fee5c"/>
							<gml:surfaceMember xlink:href="#Poly_e85a4faa-f191-4fee-94cd-0a3d0d480f15"/>
							<gml:surfaceMember xlink:href="#Poly_2db2eaa7-09b6-450e-8f52-0c4a1ff1e97f"/>
							<gml:surfaceMember xlink:href="#Poly_120b4ed6-ee9b-44ce-9d64-97b1cbc2dbef"/>
							<gml:surfaceMember xlink:href="#Poly_638dfc81-682b-486c-adf7-552f211d1f4b"/>
							<gml:surfaceMember xlink:href="#Poly_64c9687a-185c-4610-823f-7e0abd650612"/>
							<gml:surfaceMember xlink:href="#Poly_217a3240-2d13-4c8a-82b1-ac210eb99941"/>
							<gml:surfaceMember xlink:href="#Poly_435ee9bb-4051-4708-beed-9c4791110b4c"/>
							<gml:surfaceMember xlink:href="#Poly_ec74579e-3e32-47e0-94a4-00837fbf608d"/>
							<gml:surfaceMember xlink:href="#Poly_68c0ee15-a460-41e6-9b15-a3d9172ab4e6"/>
							<gml:surfaceMember xlink:href="#Poly_4048aafd-fee3-4016-a585-4025030c0aa5"/>
							<gml:surfaceMember xlink:href="#Poly_1437f806-207a-4634-a4ea-5539db3865ce"/>
							<gml:surfaceMember xlink:href="#Poly_ef161d32-e9db-497c-bf40-83b889252e06"/>
							<gml:surfaceMember xlink:href="#Poly_6d542b3a-3a03-40d5-baa4-42018ce7c39f"/>
							<gml:surfaceMember xlink:href="#Poly_cdf99f6f-2707-4338-913d-c1f3e5c5ca67"/>
							<gml:surfaceMember xlink:href="#Poly_6267d857-d6e1-4704-84e3-94a781bc6724"/>
							<gml:surfaceMember xlink:href="#Poly_ddf8d01d-a0e2-48db-bfa6-d05103e9c5f3"/>
							<gml:surfaceMember xlink:href="#Poly_1b6cbc77-7dbf-4b6a-9dd8-a42e47362932"/>
							<gml:surfaceMember xlink:href="#Poly_36b4d888-2f89-4c5f-822c-89d343cf9152"/>
							<gml:surfaceMember xlink:href="#Poly_e82acd50-1168-4b5a-bb01-6522c4e2fbe5"/>
							<gml:surfaceMember xlink:href="#Poly_859bdadb-aab5-4009-bf71-2f607cae12b5"/>
							<gml:surfaceMember xlink:href="#Poly_c16528bc-016d-47ce-acbf-bb71343dba9d"/>
							<gml:surfaceMember xlink:href="#Poly_bcc0fbf7-b81c-4835-a61f-b803d9c059e2"/>
							<gml:surfaceMember xlink:href="#Poly_0eaf5075-bb53-4588-a219-01fe561fa6f4"/>
							<gml:surfaceMember xlink:href="#Poly_4dbe5a36-a879-4685-8a92-667e8ec8de99"/>
							<gml:surfaceMember xlink:href="#Poly_7d9ed9d4-808e-4fc7-9597-dcb92b73aab8"/>
							<gml:surfaceMember xlink:href="#Poly_8d16bd1b-1a8d-48e5-83b2-eeae44a63c68"/>
							<gml:surfaceMember xlink:href="#Poly_882fee62-8368-43a0-bc95-29ad9cb43e85"/>
							<gml:surfaceMember xlink:href="#Poly_69b7aa15-3e73-46c4-bf22-d8cec1ec8c73"/>
							<gml:surfaceMember xlink:href="#Poly_ccf31957-1a05-4af9-92e6-628595ae2c9d"/>
							<gml:surfaceMember xlink:href="#Poly_16d52e3a-b081-4157-bfa3-d24a60045d1f"/>
							<gml:surfaceMember xlink:href="#Poly_50899eed-1293-43d4-9523-8f0eacbf2a40"/>
							<gml:surfaceMember xlink:href="#Poly_47d7ff37-77d2-476d-9d77-672a706bb8ee"/>
							<gml:surfaceMember xlink:href="#Poly_0596d3d0-be7e-481e-a70f-ea8450ad7654"/>
							<gml:surfaceMember xlink:href="#Poly_40a0fdef-25b5-4eda-9ae7-94bd1eabcbaf"/>
							<gml:surfaceMember xlink:href="#Poly_3305a482-e30d-48fe-afef-67e01d5fcf06"/>
							<gml:surfaceMember xlink:href="#Poly_4d24f893-7772-43a8-a271-5dcfc2a89ebf"/>
							<gml:surfaceMember xlink:href="#Poly_50728059-e966-4024-b4df-9f733beae56f"/>
							<gml:surfaceMember xlink:href="#Poly_bc9fc428-d616-4f09-a935-772b357c63b0"/>
							<gml:surfaceMember xlink:href="#Poly_31dc53ff-e1fb-4689-b303-fdb67d6f9a63"/>
							<gml:surfaceMember xlink:href="#Poly_de3847e9-16af-4fd6-8606-87b5b5eb21d9"/>
							<gml:surfaceMember xlink:href="#Poly_a0711f0e-ef27-46c2-978e-ab6b0b5d3c65"/>
							<gml:surfaceMember xlink:href="#Poly_176234fd-6852-48a1-a543-6f1dc712bd06"/>
							<gml:surfaceMember xlink:href="#Poly_1a9e071f-c583-429d-8e77-c58ad5e3f794"/>
							<gml:surfaceMember xlink:href="#Poly_8be40ad6-1aa1-4c5a-a56b-834597d8f378"/>
							<gml:surfaceMember xlink:href="#Poly_ea108a2f-1275-49c4-8305-6b5361533144"/>
							<gml:surfaceMember xlink:href="#Poly_e1606bf5-09ce-4e8c-b8c1-92e6ff15b9f5"/>
							<gml:surfaceMember xlink:href="#Poly_786877c9-fda2-4e7d-8d39-5911ff4d7ee1"/>
							<gml:surfaceMember xlink:href="#Poly_cdbed090-ca64-441a-bf19-c7db4b1bb84d"/>
							<gml:surfaceMember xlink:href="#Poly_8d62840b-e8af-41c4-9b5a-01dc67f035dd"/>
							<gml:surfaceMember xlink:href="#Poly_e3c5ec38-cf9d-4ca3-b88f-0f4c3f96ce9b"/>
							<gml:surfaceMember xlink:href="#Poly_1db0f71a-d285-4772-a273-8572f02db73f"/>
							<gml:surfaceMember xlink:href="#Poly_7c94cc76-5976-48b7-997f-a2813b76201e"/>
							<gml:surfaceMember xlink:href="#Poly_e2c72e0f-830e-4335-8d3a-12d2044677f1"/>
							<gml:surfaceMember xlink:href="#Poly_62d39be0-3e82-4974-9649-f22c4579c8c4"/>
							<gml:surfaceMember xlink:href="#Poly_846ab9fd-7233-4e7c-9726-a804248f7a38"/>
							<gml:surfaceMember xlink:href="#Poly_e1c9f409-e7a7-4102-9fe3-c11a87fd9a1c"/>
							<gml:surfaceMember xlink:href="#Poly_1c400695-f943-48bd-8d2e-37bc90eae4ce"/>
							<gml:surfaceMember xlink:href="#Poly_254714a6-8913-4bdc-bbbd-073de605ced2"/>
							<gml:surfaceMember xlink:href="#Poly_1f5e35df-b14c-42cc-af26-66ab114035a7"/>
							<gml:surfaceMember xlink:href="#Poly_600219ef-1705-4bf5-a152-54513c81f059"/>
							<gml:surfaceMember xlink:href="#Poly_5cb8bf9d-3b70-4a9c-88d1-477ce05ebc28"/>
							<gml:surfaceMember xlink:href="#Poly_ed236c79-0cbd-4c51-a9a9-2d2e57a90d11"/>
							<gml:surfaceMember xlink:href="#Poly_90ff2c26-c44b-41a2-b973-8f97f27c2201"/>
							<gml:surfaceMember xlink:href="#Poly_2fda163a-9f84-4258-a6be-b0a95d54df63"/>
							<gml:surfaceMember xlink:href="#Poly_ea0397c4-d63c-458a-9b26-488ec9a2cb94"/>
							<gml:surfaceMember xlink:href="#Poly_6d42433f-cd18-49ad-b129-2c4c431ef884"/>
							<gml:surfaceMember xlink:href="#Poly_675af024-0504-4265-9bcf-e8bea28b6349"/>
							<gml:surfaceMember xlink:href="#Poly_338d51cc-e2c2-4dfb-b28b-b7d2521445e0"/>
							<gml:surfaceMember xlink:href="#Poly_2609d02c-cfc1-426e-8686-d14a09f5536f"/>
							<gml:surfaceMember xlink:href="#Poly_a85aa1fd-7e38-4537-89e3-7cb13273898d"/>
							<gml:surfaceMember xlink:href="#Poly_ce1ba85c-7747-4f06-b482-640fd2d44e4d"/>
							<gml:surfaceMember xlink:href="#Poly_86db9533-517e-46d7-87c8-19a0b90f5f83"/>
							<gml:surfaceMember xlink:href="#Poly_cceeae28-e8c3-4228-bea5-8993f5649056"/>
							<gml:surfaceMember xlink:href="#Poly_bff7fc74-6061-4422-93f5-8be85c3a3996"/>
							<gml:surfaceMember xlink:href="#Poly_f009875d-79e2-403d-bdd5-714109115f05"/>
							<gml:surfaceMember xlink:href="#Poly_84f4560b-0635-4199-9dcc-7085d81416bc"/>
							<gml:surfaceMember xlink:href="#Poly_9dfd4387-6ad4-4245-b92c-56c1bfc5c41e"/>
							<gml:surfaceMember xlink:href="#Poly_9592a788-eee9-4453-b4ac-55a0ec1a57b7"/>
							<gml:surfaceMember xlink:href="#Poly_77a7c280-2716-43ee-a31a-cc2f41226ad0"/>
							<gml:surfaceMember xlink:href="#Poly_5896c448-8080-4b4f-b76d-e6afbf196d2c"/>
							<gml:surfaceMember xlink:href="#Poly_0c172af9-6e50-4f89-9da2-2b4e1d224e71"/>
							<gml:surfaceMember xlink:href="#Poly_ba46e76e-7640-464d-9c7c-dab2049b4319"/>
							<gml:surfaceMember xlink:href="#Poly_54ffd82b-dc8e-4dc2-84ea-5b03a763a9d0"/>
							<gml:surfaceMember xlink:href="#Poly_79bf9b2d-9116-4d14-b7ac-bcbed634a2f0"/>
							<gml:surfaceMember xlink:href="#Poly_4c2f12f8-0bfd-4059-9996-4f6dadb4b8bc"/>
							<gml:surfaceMember xlink:href="#Poly_e0d03d86-3ba9-42c4-a448-9e833fa2c715"/>
							<gml:surfaceMember xlink:href="#Poly_fff9da39-9304-4d68-bb10-b840285fa2bb"/>
							<gml:surfaceMember xlink:href="#Poly_b56ff0f9-deeb-42d1-bdbf-51d154657aad"/>
							<gml:surfaceMember xlink:href="#Poly_079c3a1e-6be4-42e8-8187-02be231b6803"/>
							<gml:surfaceMember xlink:href="#Poly_053fb075-4d22-4c4a-8a75-b492790b4483"/>
							<gml:surfaceMember xlink:href="#Poly_2323e040-8e5d-4a3a-ad2b-a2a704d10996"/>
							<gml:surfaceMember xlink:href="#Poly_6974600f-5fa0-48d3-a44b-38d7b2670773"/>
							<gml:surfaceMember xlink:href="#Poly_47d79847-1027-421e-a53b-1b222fe23a2c"/>
							<gml:surfaceMember xlink:href="#Poly_9fc73364-1dcf-406b-bcb9-4856c8f6d74c"/>
							<gml:surfaceMember xlink:href="#Poly_ea0301fe-9fe5-4a7f-9d1c-7dc03f4fe79e"/>
							<gml:surfaceMember xlink:href="#Poly_a94c7d50-1332-43f4-9d68-62388a6efa25"/>
							<gml:surfaceMember xlink:href="#Poly_0a4fd5a6-b698-4805-bb17-4fee3d3e5ded"/>
							<gml:surfaceMember xlink:href="#Poly_18bf8dbb-4101-4537-ac90-4636ec960e40"/>
							<gml:surfaceMember xlink:href="#Poly_abb34992-4c70-4070-acab-5089e9b3937c"/>
							<gml:surfaceMember xlink:href="#Poly_7eda74b1-a1c1-4083-96e1-6a42ddc73f66"/>
							<gml:surfaceMember xlink:href="#Poly_bfa3fdfb-2655-4f96-8b08-fd16b65b8336"/>
							<gml:surfaceMember xlink:href="#Poly_7322168b-5b27-44ad-918f-05cda5c85ba9"/>
							<gml:surfaceMember xlink:href="#Poly_815db495-cb15-4f3c-8724-433a236d75c9"/>
							<gml:surfaceMember xlink:href="#Poly_00276ab2-820a-43c6-8c9d-3e30e0fc840b"/>
							<gml:surfaceMember xlink:href="#Poly_a534dd64-67dc-48db-af9f-8c1c58085eb3"/>
							<gml:surfaceMember xlink:href="#Poly_15c11e64-46aa-4f7e-a6b1-b7b1796d27fe"/>
							<gml:surfaceMember xlink:href="#Poly_d91e52a1-26f1-46e9-8a63-29a00bdf3549"/>
							<gml:surfaceMember xlink:href="#Poly_d8d2d01a-2c6f-42dd-bcac-af9c56df012c"/>
							<gml:surfaceMember xlink:href="#Poly_3c471a8d-2958-46b3-ba00-47e3f888124d"/>
							<gml:surfaceMember xlink:href="#Poly_82225e50-2396-44ed-bb4d-321bf0909cf0"/>
							<gml:surfaceMember xlink:href="#Poly_8f5c9831-1ff3-49cd-91d5-f8e460083941"/>
							<gml:surfaceMember xlink:href="#Poly_61cea21e-657a-44c8-8947-c99cde9f6611"/>
							<gml:surfaceMember xlink:href="#Poly_ed795a03-dc30-41cd-a109-50182d75e715"/>
							<gml:surfaceMember xlink:href="#Poly_384d1fea-3163-4421-b924-e3328e826fec"/>
							<gml:surfaceMember xlink:href="#Poly_6a74b114-6639-4b17-8493-fdc7cf2fa06e"/>
							<gml:surfaceMember xlink:href="#Poly_94061e7a-58e2-45a6-b8f6-d3629f0078b2"/>
							<gml:surfaceMember xlink:href="#Poly_ae476bb5-393f-45f3-918a-974b365545ea"/>
							<gml:surfaceMember xlink:href="#Poly_5de060fa-b75a-4489-ba7b-9e56aa5a3af8"/>
							<gml:surfaceMember xlink:href="#Poly_008256f4-ea57-4007-b68e-25ae27a1c970"/>
							<gml:surfaceMember xlink:href="#Poly_59267463-3cbb-4e96-81ed-555520945948"/>
							<gml:surfaceMember xlink:href="#Poly_8c2301ea-aa60-4775-8be0-1babf34ac923"/>
							<gml:surfaceMember xlink:href="#Poly_82ee9492-ae97-4839-a20a-ea372dd74905"/>
							<gml:surfaceMember xlink:href="#Poly_71424f09-3cab-44ae-8152-f780d62af675"/>
							<gml:surfaceMember xlink:href="#Poly_4ed456ca-62df-4595-abdf-9ab797bd4bc8"/>
							<gml:surfaceMember xlink:href="#Poly_9e6eacae-757f-47df-923a-260f857b3672"/>
							<gml:surfaceMember xlink:href="#Poly_41dfd5bb-495e-4eef-b293-5dc4196b117a"/>
							<gml:surfaceMember xlink:href="#Poly_5381d9ca-2484-487c-bfe5-b6ea5274c434"/>
							<gml:surfaceMember xlink:href="#Poly_848ade0c-0552-40df-8758-3104f366368f"/>
							<gml:surfaceMember xlink:href="#Poly_546ec3b3-8d52-4788-8286-5023ac1d4c72"/>
							<gml:surfaceMember xlink:href="#Poly_11073d8a-888a-4c82-8f8e-c5f2b364507a"/>
							<gml:surfaceMember xlink:href="#Poly_69c589cd-0d8c-4635-8d43-dc66b1a56c0b"/>
							<gml:surfaceMember xlink:href="#Poly_cbbeea6e-4f63-4d9e-95d3-b1fe5517def9"/>
							<gml:surfaceMember xlink:href="#Poly_d0c012a3-a5cf-4c74-ad45-607e43c551ae"/>
							<gml:surfaceMember xlink:href="#Poly_c2ef0e4c-c760-49fb-b558-6117fefb1c79"/>
							<gml:surfaceMember xlink:href="#Poly_686cf043-d98b-432d-b0f5-659b660d41ba"/>
							<gml:surfaceMember xlink:href="#Poly_92e8d9f3-2a44-4a40-a813-12d6e9e41e91"/>
							<gml:surfaceMember xlink:href="#Poly_aa6b3257-c719-42d0-9556-edbd7ef193e9"/>
							<gml:surfaceMember xlink:href="#Poly_94ec4e8c-7c75-4ef6-8d71-2fb1ea67b9ad"/>
							<gml:surfaceMember xlink:href="#Poly_c87ce273-3636-4d2f-be3e-f45f28e33366"/>
							<gml:surfaceMember xlink:href="#Poly_4a2065a6-03cb-4260-8823-93336aaf7368"/>
							<gml:surfaceMember xlink:href="#Poly_49824040-55fc-4da3-9b1d-2924cc9e703b"/>
							<gml:surfaceMember xlink:href="#Poly_6b681dab-3d09-4bf5-bc09-75eb346d5058"/>
							<gml:surfaceMember xlink:href="#Poly_6b771148-7e97-4282-aa3f-dcf3210197e3"/>
							<gml:surfaceMember xlink:href="#Poly_11282eb9-a212-487a-a98a-ce42b2ec976e"/>
							<gml:surfaceMember xlink:href="#Poly_cd46b275-0428-4bd0-b1ce-f636b651359c"/>
							<gml:surfaceMember xlink:href="#Poly_cbb67d4c-c1a2-41c9-9962-88133489992e"/>
							<gml:surfaceMember xlink:href="#Poly_82b10347-47a4-4061-bf82-ae6b90866921"/>
							<gml:surfaceMember xlink:href="#Poly_63d359d7-0f00-4cd9-8cd3-cd6f73222282"/>
							<gml:surfaceMember xlink:href="#Poly_e6f3d7d1-18be-4448-ab88-90a5711fdda2"/>
							<gml:surfaceMember xlink:href="#Poly_116b1806-d170-4dc5-bc4b-1bf9e6a35bbc"/>
							<gml:surfaceMember xlink:href="#Poly_e8c6742d-a945-4488-9963-1d1d1cc8869a"/>
							<gml:surfaceMember xlink:href="#Poly_ceb491c4-eee9-4ee4-846e-8873d94a5b3c"/>
							<gml:surfaceMember xlink:href="#Poly_5d1ca59b-300f-43a5-a15b-d56e6b04292a"/>
							<gml:surfaceMember xlink:href="#Poly_108d7006-60a2-485c-a394-912a1a5ce76d"/>
							<gml:surfaceMember xlink:href="#Poly_e3578d4b-83d2-4a65-bc12-e5423a26b235"/>
							<gml:surfaceMember xlink:href="#Poly_29c021d6-07b1-432f-8127-601f58b0200b"/>
							<gml:surfaceMember xlink:href="#Poly_e113b0cf-dc9d-448f-b04f-d0812588107d"/>
							<gml:surfaceMember xlink:href="#Poly_720ebdf2-cae9-4e46-ba93-2d6410c0d23c"/>
							<gml:surfaceMember xlink:href="#Poly_278872ef-99c9-4e0f-bac5-6b7695fdf166"/>
							<gml:surfaceMember xlink:href="#Poly_1c58d0fe-a9c5-4fcb-909e-973adfdf649f"/>
							<gml:surfaceMember xlink:href="#Poly_688320e9-bd74-4c12-ac48-4da5e2f54803"/>
							<gml:surfaceMember xlink:href="#Poly_20ad2535-986b-4013-9857-bc25a4e75e0b"/>
							<gml:surfaceMember xlink:href="#Poly_e72d30d3-36aa-4c53-bd89-e414d0ab4373"/>
							<gml:surfaceMember xlink:href="#Poly_81bfdca8-e554-4524-a2e2-ff802b02ef40"/>
							<gml:surfaceMember xlink:href="#Poly_3141f76d-3a27-49ed-913e-86d4cd96de79"/>
							<gml:surfaceMember xlink:href="#Poly_5cf46790-e3f7-411e-be7e-f3a7031a00b0"/>
							<gml:surfaceMember xlink:href="#Poly_f6647dc3-ee31-4884-b7d9-afc654aa8989"/>
							<gml:surfaceMember xlink:href="#Poly_3edeb77c-3824-4330-9654-bf1ea036fe4c"/>
							<gml:surfaceMember xlink:href="#Poly_4ba5cc4d-64d8-48e2-a15b-ef23d52fc384"/>
							<gml:surfaceMember xlink:href="#Poly_29180d3f-b774-44cf-9329-f383d3679f81"/>
							<gml:surfaceMember xlink:href="#Poly_1d8b23eb-80fb-4274-82f8-a28b8e1b3477"/>
							<gml:surfaceMember xlink:href="#Poly_14f22cf8-76ac-4901-9503-43d61068a2bb"/>
							<gml:surfaceMember xlink:href="#Poly_9e642300-7d6a-4f61-ad72-33c8ed0af7f7"/>
							<gml:surfaceMember xlink:href="#Poly_dd2ef206-8e88-4d01-b9d9-59554d93d46a"/>
							<gml:surfaceMember xlink:href="#Poly_15a4d3f9-dbfe-439c-9b6f-3d44e34c1c88"/>
							<gml:surfaceMember xlink:href="#Poly_a0ffdf3d-0a1d-4cd1-a168-bc383b3a0be2"/>
							<gml:surfaceMember xlink:href="#Poly_b99df9d2-53dd-45d7-8a6d-94e60cedfe3e"/>
							<gml:surfaceMember xlink:href="#Poly_cf8f1ade-aa38-41bc-8d05-7cc588458613"/>
							<gml:surfaceMember xlink:href="#Poly_30283c21-51ab-4610-8a01-37c39e2670a0"/>
							<gml:surfaceMember xlink:href="#Poly_5404a7be-56f6-487c-b586-58e9dd581d96"/>
							<gml:surfaceMember xlink:href="#Poly_3b173468-e202-4e38-a01a-33b5c2e51de3"/>
							<gml:surfaceMember xlink:href="#Poly_2d3a4927-1654-4114-a9b3-50361023b3de"/>
							<gml:surfaceMember xlink:href="#Poly_dba4cf79-48b6-45d9-8948-89cb5d6cd98f"/>
							<gml:surfaceMember xlink:href="#Poly_aaefc90e-79bd-481e-9485-6a8c660b7a46"/>
							<gml:surfaceMember xlink:href="#Poly_5b50607a-e0a5-4235-8f2a-0d1f94cb0232"/>
							<gml:surfaceMember xlink:href="#Poly_7d1b23ef-ddbd-47ad-b19a-37d6df94ddf0"/>
							<gml:surfaceMember xlink:href="#Poly_52c54992-3b2c-46b2-9a49-4213bf976eb5"/>
							<gml:surfaceMember xlink:href="#Poly_a4bd423a-f211-4de0-bbaf-2c1b6df64aeb"/>
							<gml:surfaceMember xlink:href="#Poly_06683d50-e625-47a0-86ac-8c367d097ec1"/>
							<gml:surfaceMember xlink:href="#Poly_a89a9f0e-fb04-427e-a770-50469e8a9319"/>
							<gml:surfaceMember xlink:href="#Poly_395de5d4-bd78-4a07-ba82-62261444fe02"/>
							<gml:surfaceMember xlink:href="#Poly_90d21a69-ca24-42a6-8dd2-e3e34826e0ce"/>
							<gml:surfaceMember xlink:href="#Poly_31169f9c-5482-4e73-94d0-16f8b84a7a8e"/>
							<gml:surfaceMember xlink:href="#Poly_24362567-ea83-4381-8c23-a693b8756ef4"/>
							<gml:surfaceMember xlink:href="#Poly_4de5de6b-7d6e-4f26-ba31-bc4eaba9917f"/>
							<gml:surfaceMember xlink:href="#Poly_eea770dd-a17e-4043-8f41-8ffb33412390"/>
							<gml:surfaceMember xlink:href="#Poly_2c878214-b0ef-4173-a29e-0439db9a2206"/>
							<gml:surfaceMember xlink:href="#Poly_cce930dc-2021-4f31-bedf-b3642f45757d"/>
							<gml:surfaceMember xlink:href="#Poly_f81f07ce-fbdc-49ad-8039-7372d6bf3a7c"/>
							<gml:surfaceMember xlink:href="#Poly_cfdac334-b1ef-44de-9a0f-7dde21c53996"/>
							<gml:surfaceMember xlink:href="#Poly_c734a4cd-b0eb-48d3-8afd-657a71f54025"/>
							<gml:surfaceMember xlink:href="#Poly_141feb9d-6c43-4f33-8813-1f4dbd1071c9"/>
							<gml:surfaceMember xlink:href="#Poly_6fcaee61-fde0-46e9-826c-a748032a1bca"/>
							<gml:surfaceMember xlink:href="#Poly_fb7ca30d-65f0-4aa2-909d-1c2559130372"/>
							<gml:surfaceMember xlink:href="#Poly_8104d65a-7a1b-4ee9-bf26-c857e800195e"/>
							<gml:surfaceMember xlink:href="#Poly_f8ce7174-9a63-4c60-b109-91ff6006f940"/>
							<gml:surfaceMember xlink:href="#Poly_7c0f8ea6-1230-4d9a-a1d2-313d3307f056"/>
							<gml:surfaceMember xlink:href="#Poly_a1413b1b-9dd1-4f09-8dc7-a80ec6bedf84"/>
							<gml:surfaceMember xlink:href="#Poly_83077f70-49c7-4c69-87ba-2a755ae777ce"/>
							<gml:surfaceMember xlink:href="#Poly_12aaa9f4-4846-491a-afad-caae2c2fc295"/>
							<gml:surfaceMember xlink:href="#Poly_52b6b0ae-9a47-4750-8c2c-a2a2dfecfae5"/>
							<gml:surfaceMember xlink:href="#Poly_78221c3e-46dd-45c9-a1a0-1aa5f39e9aec"/>
							<gml:surfaceMember xlink:href="#Poly_4583394f-94d1-42f3-9041-1a31fd1d43d8"/>
							<gml:surfaceMember xlink:href="#Poly_486c0db2-2803-4cf1-93b5-6d10858ee7d9"/>
							<gml:surfaceMember xlink:href="#Poly_9c3d22ec-87ff-4708-9705-51b087ec20b2"/>
							<gml:surfaceMember xlink:href="#Poly_a0e27814-4f5d-44b6-84fb-760c6c9676aa"/>
							<gml:surfaceMember xlink:href="#Poly_246f4d51-6117-4a5a-87f9-c5227d18b4cd"/>
							<gml:surfaceMember xlink:href="#Poly_64a0dc1b-d6cd-4165-9dc0-113d7438afd8"/>
							<gml:surfaceMember xlink:href="#Poly_2a98aea0-adf2-4120-bb7d-70bf82398212"/>
							<gml:surfaceMember xlink:href="#Poly_c6a78b99-ca36-43fd-af1f-85c68720e0b9"/>
							<gml:surfaceMember xlink:href="#Poly_a64bff69-e56e-4c4e-a93b-1470d0831a94"/>
							<gml:surfaceMember xlink:href="#Poly_8b17be39-6434-4904-ada7-5a05c23724a9"/>
							<gml:surfaceMember xlink:href="#Poly_21d96363-028a-43b7-b46b-8aacedd962ce"/>
							<gml:surfaceMember xlink:href="#Poly_1155e61b-201d-4e86-8543-86dcdcb6048b"/>
							<gml:surfaceMember xlink:href="#Poly_5928a691-d5bd-400d-b309-a9d1a51ea1da"/>
							<gml:surfaceMember xlink:href="#Poly_979c02b0-e1f2-4759-b83e-34847d1691d0"/>
							<gml:surfaceMember xlink:href="#Poly_ad919656-5c43-4417-a601-a69b5da2bb03"/>
							<gml:surfaceMember xlink:href="#Poly_dbb97038-c8c2-4cb3-aecd-2d723960be8c"/>
							<gml:surfaceMember xlink:href="#Poly_57a4de5c-23a0-4a2a-94c2-b4fb8f55d196"/>
							<gml:surfaceMember xlink:href="#Poly_4d2338a5-d513-4bd4-b727-24c9a803ff19"/>
							<gml:surfaceMember xlink:href="#Poly_63b9ab0e-be7e-4a6b-8c9e-b57b1c4eac68"/>
							<gml:surfaceMember xlink:href="#Poly_9c050ae6-795e-4d59-9f6c-5f0f38284833"/>
							<gml:surfaceMember xlink:href="#Poly_bd93266f-c8e0-4dfd-b9ca-c3d03fcb6646"/>
							<gml:surfaceMember xlink:href="#Poly_43cf823d-49b1-456a-8e32-2c2ab39482e9"/>
							<gml:surfaceMember xlink:href="#Poly_0f1433c1-650a-401e-b26a-78119feb1e52"/>
							<gml:surfaceMember xlink:href="#Poly_5492ad2e-15cf-4eb3-aa75-b94751493a20"/>
							<gml:surfaceMember xlink:href="#Poly_9e9418ec-374e-4792-a387-826f70d8addf"/>
							<gml:surfaceMember xlink:href="#Poly_88e4ebff-032b-4ef9-b93e-aacdd1c3234e"/>
							<gml:surfaceMember xlink:href="#Poly_56caa3d9-5844-4cd4-9828-531776b193a4"/>
							<gml:surfaceMember xlink:href="#Poly_60557647-52ab-4595-9038-ee22f21de927"/>
							<gml:surfaceMember xlink:href="#Poly_7d8e4601-c30d-4b90-a066-c6e38c1c6bd7"/>
							<gml:surfaceMember xlink:href="#Poly_b56ff259-5120-4bc5-b3ef-8be53eaabf81"/>
							<gml:surfaceMember xlink:href="#Poly_4e3e05f8-5527-421f-9a61-7a19630f95b8"/>
							<gml:surfaceMember xlink:href="#Poly_ec11eb6f-ece4-44bd-9b29-6aa9416bbcdb"/>
							<gml:surfaceMember xlink:href="#Poly_dbc66202-ee36-40e0-a764-c391f20660dc"/>
							<gml:surfaceMember xlink:href="#Poly_382e4e0a-9a7e-40cc-ae72-7a2fb2feea3e"/>
							<gml:surfaceMember xlink:href="#Poly_a84791dc-f89c-4567-82fd-6f6ee7e2ed59"/>
							<gml:surfaceMember xlink:href="#Poly_df56c8b5-41c6-46b4-b935-3149c4bbc603"/>
							<gml:surfaceMember xlink:href="#Poly_4393183f-aed2-4e57-98e8-d1260a776f2a"/>
							<gml:surfaceMember xlink:href="#Poly_08c1dfb7-acca-4b5b-95d4-0135c1d26d0f"/>
							<gml:surfaceMember xlink:href="#Poly_20065bbb-3861-4bc7-bc20-15e39e4ae2ad"/>
							<gml:surfaceMember xlink:href="#Poly_5b6ad5d4-88ce-4ed5-963c-b308456f817d"/>
							<gml:surfaceMember xlink:href="#Poly_bcd6409e-d2d7-431b-b5a5-968f8be4ee59"/>
							<gml:surfaceMember xlink:href="#Poly_32bc60e4-9e7e-485e-9943-e4644e158564"/>
							<gml:surfaceMember xlink:href="#Poly_eba27e07-64b3-49f7-b4ed-49fce617bd5d"/>
							<gml:surfaceMember xlink:href="#Poly_f42b075c-16c4-427a-bf44-ef0d8dfc5623"/>
							<gml:surfaceMember xlink:href="#Poly_2003b574-c6b1-405b-b98c-921ddc9bb63e"/>
							<gml:surfaceMember xlink:href="#Poly_385a28c7-47a9-486a-90d5-d0836c50537d"/>
							<gml:surfaceMember xlink:href="#Poly_b8b083fb-6e8e-4969-a517-2d5eae7200ce"/>
							<gml:surfaceMember xlink:href="#Poly_ae61299f-ac3b-40d2-8f87-57af7e335ecb"/>
							<gml:surfaceMember xlink:href="#Poly_6ffbaf3f-8ae0-4969-b813-835d656cc0cb"/>
							<gml:surfaceMember xlink:href="#Poly_32879f9d-e4ef-4baa-bcb3-9ba6a9520f62"/>
							<gml:surfaceMember xlink:href="#Poly_234504fa-ee25-4f43-8f36-5e780a4f0304"/>
							<gml:surfaceMember xlink:href="#Poly_afd8ec90-ce02-40b0-816e-974769566ae4"/>
							<gml:surfaceMember xlink:href="#Poly_b2224703-b8a6-4543-a163-c7f0845c1a03"/>
							<gml:surfaceMember xlink:href="#Poly_0227ee06-d939-49b9-bc7c-320e2bcc6ccc"/>
							<gml:surfaceMember xlink:href="#Poly_6660978b-40d1-4f09-a8e4-48a8c25538c5"/>
							<gml:surfaceMember xlink:href="#Poly_95c772b2-c6e3-4408-9fe6-39c5b3049e17"/>
							<gml:surfaceMember xlink:href="#Poly_b8fcd9fe-fd00-4557-9b78-1fc5665ea3b5"/>
							<gml:surfaceMember xlink:href="#Poly_79630afd-daf5-45c5-bf50-ba00005b4311"/>
							<gml:surfaceMember xlink:href="#Poly_250361bd-69a7-41c8-9b1f-2cc01fb6c3bf"/>
							<gml:surfaceMember xlink:href="#Poly_c8443b46-cff1-4e9a-9042-bf7b03fa8cab"/>
							<gml:surfaceMember xlink:href="#Poly_1210f4c1-146e-43fe-91ec-cb1345c04e2d"/>
							<gml:surfaceMember xlink:href="#Poly_b49448be-1360-4fa6-8b98-a9264cf83db8"/>
							<gml:surfaceMember xlink:href="#Poly_954be5ad-91b5-4ec0-b981-14a149258952"/>
							<gml:surfaceMember xlink:href="#Poly_c1efe2ce-8e1e-4804-a455-a1c0310aa7e1"/>
							<gml:surfaceMember xlink:href="#Poly_a823749f-e88b-4cb9-8a63-4e4a6c211056"/>
							<gml:surfaceMember xlink:href="#Poly_aaeebf58-8b57-44f6-a137-6217699edea8"/>
							<gml:surfaceMember xlink:href="#Poly_59a69b9c-de6f-46a1-8a04-0cc57ed05ec7"/>
							<gml:surfaceMember xlink:href="#Poly_53d6e832-e425-4d9d-989c-3406e376527a"/>
							<gml:surfaceMember xlink:href="#Poly_8df2a477-62d8-44e6-a233-b04886b72950"/>
							<gml:surfaceMember xlink:href="#Poly_1db1c7fc-9786-4c82-9df4-e17b65bae284"/>
							<gml:surfaceMember xlink:href="#Poly_158459f6-aead-408d-bd19-52a7b87a2970"/>
							<gml:surfaceMember xlink:href="#Poly_28900b4a-6308-4159-90d1-3297c9fbd3ad"/>
							<gml:surfaceMember xlink:href="#Poly_1b7aab4e-8811-44f5-8655-48b8df8c1e61"/>
							<gml:surfaceMember xlink:href="#Poly_38e6fd0d-5b1d-4208-8499-3ca961335a0d"/>
							<gml:surfaceMember xlink:href="#Poly_5f8bd96f-c06f-441f-b5e5-504c0cc1787c"/>
							<gml:surfaceMember xlink:href="#Poly_4e1efab1-71e8-48cc-b865-84a073f0ab8d"/>
							<gml:surfaceMember xlink:href="#Poly_adf09f33-d38f-4755-b9c8-972007907b22"/>
							<gml:surfaceMember xlink:href="#Poly_45c2f95d-7ce2-4741-90b0-daa6f4d8158a"/>
							<gml:surfaceMember xlink:href="#Poly_a6b69821-a7eb-4379-98a7-bceab4e68d9c"/>
							<gml:surfaceMember xlink:href="#Poly_e1c75e84-d060-48fa-8dcd-de1037d172ab"/>
							<gml:surfaceMember xlink:href="#Poly_ec36079d-b310-4967-8871-3ac24d0e3f5f"/>
							<gml:surfaceMember xlink:href="#Poly_fb6dc0e7-0a4b-4d12-b5ef-07aa43ac24d1"/>
							<gml:surfaceMember xlink:href="#Poly_e04b240e-0d61-435f-b0ad-6a903e93eebd"/>
							<gml:surfaceMember xlink:href="#Poly_4a1f37d5-dc78-4a7e-9fd3-242ffa0fd96c"/>
							<gml:surfaceMember xlink:href="#Poly_b4882b17-c5cc-4c3b-84fa-9ffadf747439"/>
							<gml:surfaceMember xlink:href="#Poly_13b25aa3-562a-4b3e-b607-d75a64bbb096"/>
							<gml:surfaceMember xlink:href="#Poly_53970898-c0ac-4a4a-97d5-a1ca6ab84c3f"/>
							<gml:surfaceMember xlink:href="#Poly_ffd66a3e-614e-4d0f-b1eb-2e72f4589577"/>
							<gml:surfaceMember xlink:href="#Poly_40321561-45f3-47d7-a8a4-a4ab2a0b8d26"/>
							<gml:surfaceMember xlink:href="#Poly_6dda6bd4-7fd5-4b40-918f-8a387abbc9fe"/>
							<gml:surfaceMember xlink:href="#Poly_ebcfad6d-b004-4f13-b102-2fb875a008ed"/>
							<gml:surfaceMember xlink:href="#Poly_e9a2e11a-c450-4493-8bb4-f5215e1184bc"/>
							<gml:surfaceMember xlink:href="#Poly_5d91e9ea-bf2b-4295-a054-3b5d73239544"/>
							<gml:surfaceMember xlink:href="#Poly_851c53ca-09f1-44ae-a3ef-32f70b2a0307"/>
							<gml:surfaceMember xlink:href="#Poly_270a2c00-afcd-4a66-9bf4-ee64600b853b"/>
							<gml:surfaceMember xlink:href="#Poly_754ce5d5-184d-477a-8780-422a12e1b63a"/>
							<gml:surfaceMember xlink:href="#Poly_44fb275a-d545-41e4-a57c-ca7ab5879f31"/>
							<gml:surfaceMember xlink:href="#Poly_6ab8bd91-1f6b-43e1-b17d-7c16bf32825b"/>
							<gml:surfaceMember xlink:href="#Poly_e419b488-aef8-4acb-823e-ed8515c4c926"/>
							<gml:surfaceMember xlink:href="#Poly_3c4e2af8-45d2-4f91-8b64-6032c7733293"/>
							<gml:surfaceMember xlink:href="#Poly_0d1e98b6-f772-4aab-b1dc-19b127618fbd"/>
							<gml:surfaceMember xlink:href="#Poly_c3933c9e-4157-407b-898a-03d75dbfc84e"/>
							<gml:surfaceMember xlink:href="#Poly_026fe7d0-edcb-4b42-8ddb-c5dfe546c8bc"/>
							<gml:surfaceMember xlink:href="#Poly_ead7fd3d-d1e4-485a-a686-42cd7f22c947"/>
							<gml:surfaceMember xlink:href="#Poly_258fbead-53e1-40df-a321-149bdbb10f86"/>
							<gml:surfaceMember xlink:href="#Poly_163b0615-953e-4ca3-8e34-f9da32c170dc"/>
							<gml:surfaceMember xlink:href="#Poly_77df0420-898e-4da9-ada5-9a5d01ce6e1e"/>
							<gml:surfaceMember xlink:href="#Poly_3cb355ef-64d5-42ec-8237-c11829b185c5"/>
							<gml:surfaceMember xlink:href="#Poly_87315c77-175a-4c68-b8cf-3d7d86f3e3aa"/>
							<gml:surfaceMember xlink:href="#Poly_6db55a98-3e87-4075-9c6d-28fa0f9a156a"/>
							<gml:surfaceMember xlink:href="#Poly_ad78bde4-84ba-47d8-b77b-04634c8c23bd"/>
							<gml:surfaceMember xlink:href="#Poly_242eb660-a6ed-4319-a76d-41e18786c8d8"/>
							<gml:surfaceMember xlink:href="#Poly_fbefb2a4-5268-4f29-844a-90886a45fbba"/>
							<gml:surfaceMember xlink:href="#Poly_8e36f381-cdf6-409f-aec4-5f67f2f511a9"/>
							<gml:surfaceMember xlink:href="#Poly_eba2c741-025d-4786-b534-88a65d1e6340"/>
							<gml:surfaceMember xlink:href="#Poly_9f0b36be-bfb4-45f5-84d0-46fe226153cc"/>
							<gml:surfaceMember xlink:href="#Poly_a61c8bda-7509-4d64-bd6d-bb39db626d07"/>
							<gml:surfaceMember xlink:href="#Poly_fada73b2-86a8-4664-97ff-4ffc48730424"/>
							<gml:surfaceMember xlink:href="#Poly_d6a024a0-73fc-4d25-a0b3-a8d706d8c666"/>
							<gml:surfaceMember xlink:href="#Poly_a5797704-f137-45a8-baa1-147aadaeecee"/>
							<gml:surfaceMember xlink:href="#Poly_5fef7948-d259-41a8-aca2-94e219387ea1"/>
							<gml:surfaceMember xlink:href="#Poly_8df78219-fc5f-4870-b249-10878f4380d5"/>
							<gml:surfaceMember xlink:href="#Poly_a2084fa2-42dc-47f8-bc95-9e5afbe9e272"/>
							<gml:surfaceMember xlink:href="#Poly_bfc5dba8-ad6f-456e-a5f3-75dc19fead1c"/>
							<gml:surfaceMember xlink:href="#Poly_059b2871-e0fe-4357-807c-b597b44a3c13"/>
							<gml:surfaceMember xlink:href="#Poly_be7945e4-62d1-444c-b1fe-bd2abe24ac40"/>
							<gml:surfaceMember xlink:href="#Poly_33907144-b775-4504-8030-b5605a5bcedb"/>
							<gml:surfaceMember xlink:href="#Poly_e3fe6960-0e0c-4fa6-b4a6-28196bcc8eee"/>
							<gml:surfaceMember xlink:href="#Poly_eec8ff56-c538-4213-addc-95d94fea8aab"/>
							<gml:surfaceMember xlink:href="#Poly_cf0255f6-3eba-4622-bdea-25f18a38f318"/>
							<gml:surfaceMember xlink:href="#Poly_5d4f4536-7a4c-4c6f-a534-b75d59de88f8"/>
							<gml:surfaceMember xlink:href="#Poly_d9f82de7-4236-4315-94b4-618e084090df"/>
							<gml:surfaceMember xlink:href="#Poly_bd8990e3-b7a4-43a4-ad98-6c73ddedb936"/>
							<gml:surfaceMember xlink:href="#Poly_e10f8204-10c6-4b32-ade3-e61a411f6769"/>
							<gml:surfaceMember xlink:href="#Poly_8f3514b7-be1f-4907-a2ac-4e0c3f950bc1"/>
							<gml:surfaceMember xlink:href="#Poly_36a38d72-639a-4d28-9818-01bc387f275e"/>
							<gml:surfaceMember xlink:href="#Poly_3a0b6827-cb72-4ae7-8e49-42f458d6c6a1"/>
							<gml:surfaceMember xlink:href="#Poly_132d96b3-ed12-4375-b5d6-5343f3a8510e"/>
							<gml:surfaceMember xlink:href="#Poly_ed1f0597-5125-438b-8a8b-6528581bc65f"/>
							<gml:surfaceMember xlink:href="#Poly_696785e0-5cb7-4961-be3c-f79bd05aa33d"/>
							<gml:surfaceMember xlink:href="#Poly_8d026f44-1eda-47be-94b3-aa38887738bb"/>
							<gml:surfaceMember xlink:href="#Poly_e159366d-e9cb-4ecf-91ae-e4cd3b12c406"/>
							<gml:surfaceMember xlink:href="#Poly_03cf873f-c848-4382-b0b0-4095ed564afd"/>
							<gml:surfaceMember xlink:href="#Poly_531feb44-5b95-483b-9b8c-8b53c5b3bf65"/>
							<gml:surfaceMember xlink:href="#Poly_967f8357-3907-4c15-a8a4-dd2418697fff"/>
							<gml:surfaceMember xlink:href="#Poly_b2e55194-a00c-4049-b2c3-d1f57b36e115"/>
							<gml:surfaceMember xlink:href="#Poly_a2231cfd-c431-41fb-a87e-566d9982827e"/>
							<gml:surfaceMember xlink:href="#Poly_d7663597-ced5-4050-9f6a-93e453862290"/>
							<gml:surfaceMember xlink:href="#Poly_80ca357d-f5a1-4477-8cc1-84445f9b9136"/>
							<gml:surfaceMember xlink:href="#Poly_346c4001-35b9-45f1-81b3-9db72e14a1a7"/>
							<gml:surfaceMember xlink:href="#Poly_6c8d6936-597e-4a21-8500-75f1bf735406"/>
							<gml:surfaceMember xlink:href="#Poly_f04d9bfe-ab68-4b66-8802-43ee563db1d6"/>
							<gml:surfaceMember xlink:href="#Poly_9e44e29a-4065-482d-b401-47b2e77257a3"/>
							<gml:surfaceMember xlink:href="#Poly_a9a72554-78cc-467f-ab1f-6f48e5670629"/>
							<gml:surfaceMember xlink:href="#Poly_63ce7287-9172-4eb7-8a2f-e9760d80b66b"/>
							<gml:surfaceMember xlink:href="#Poly_f70e8d09-6e27-463b-9da8-26b868d7fc71"/>
							<gml:surfaceMember xlink:href="#Poly_a3d32216-2280-437e-b12e-10640a278532"/>
							<gml:surfaceMember xlink:href="#Poly_9bd0e486-698c-41d8-8aca-d89a441d46d5"/>
							<gml:surfaceMember xlink:href="#Poly_b514aaaa-3558-425c-9c0c-8b4d0c1d431f"/>
							<gml:surfaceMember xlink:href="#Poly_d2504de6-aaa7-4892-a4cb-807f46b45878"/>
							<gml:surfaceMember xlink:href="#Poly_aa659ab4-9923-4dc1-b733-a0feb728c34a"/>
							<gml:surfaceMember xlink:href="#Poly_f8082a87-aeda-4222-82b9-fc29fa9971bf"/>
							<gml:surfaceMember xlink:href="#Poly_f958d2ae-7d78-4a5b-876d-40d1985a12fb"/>
							<gml:surfaceMember xlink:href="#Poly_232d6f58-7916-4f64-b7d5-4160653d915b"/>
							<gml:surfaceMember xlink:href="#Poly_22579e4a-e2b3-4440-ab19-9270c905de76"/>
							<gml:surfaceMember xlink:href="#Poly_bef58467-4fd7-43be-a07a-8925f192cf5f"/>
							<gml:surfaceMember xlink:href="#Poly_39b8604a-b31c-4022-ae40-e65d09d9e8ed"/>
							<gml:surfaceMember xlink:href="#Poly_6fa066f3-bf1c-4232-b556-f4d189bcd083"/>
							<gml:surfaceMember xlink:href="#Poly_153754d1-e61c-4408-9f03-40624de560f4"/>
							<gml:surfaceMember xlink:href="#Poly_c5267217-bca1-4ce0-a27d-8252394c9d63"/>
							<gml:surfaceMember xlink:href="#Poly_8d0b4280-64b4-44aa-97f8-805cd4db9423"/>
							<gml:surfaceMember xlink:href="#Poly_d9ccaf3b-a5b7-4b51-b052-93b959a96a94"/>
							<gml:surfaceMember xlink:href="#Poly_30861ce2-3eff-4318-8614-f9ef9da9b3ae"/>
							<gml:surfaceMember xlink:href="#Poly_59903f5e-885b-4993-bcc3-c971be5ba4b6"/>
							<gml:surfaceMember xlink:href="#Poly_2adcce02-14c3-4f90-8c67-d1e476580304"/>
							<gml:surfaceMember xlink:href="#Poly_600ee51e-ced5-47d3-8861-9371329fecc6"/>
							<gml:surfaceMember xlink:href="#Poly_ea00df2f-c6e1-4d60-be44-1d0870a9ff5a"/>
							<gml:surfaceMember xlink:href="#Poly_a1498327-907a-4b48-abcb-32775f65364e"/>
							<gml:surfaceMember xlink:href="#Poly_5e1138e4-fc09-41a7-80b0-74eefd5bfc7c"/>
							<gml:surfaceMember xlink:href="#Poly_2362fb93-b518-4fb0-ba8a-47e4a7acefdd"/>
							<gml:surfaceMember xlink:href="#Poly_37d1ba3b-2160-4471-b3f2-c04c11d1cf37"/>
							<gml:surfaceMember xlink:href="#Poly_a0698fe2-4bdb-4b3a-b6a0-41a90ad5897a"/>
							<gml:surfaceMember xlink:href="#Poly_783e9d2b-8afb-4036-b453-93c73bbe464f"/>
							<gml:surfaceMember xlink:href="#Poly_32841516-ec62-472b-9573-36cbd545d77c"/>
							<gml:surfaceMember xlink:href="#Poly_21a11183-4d35-450b-a59b-b34b35635f03"/>
							<gml:surfaceMember xlink:href="#Poly_1dcdab39-30cc-420e-af35-213b336889f2"/>
							<gml:surfaceMember xlink:href="#Poly_1a4bb48d-d615-443f-9ad7-214266c748ad"/>
							<gml:surfaceMember xlink:href="#Poly_89dc6b87-53b3-4875-841e-f92c4c7c9458"/>
							<gml:surfaceMember xlink:href="#Poly_f07d6b9f-533a-4ca6-866e-21002ace4c84"/>
							<gml:surfaceMember xlink:href="#Poly_dd7b4766-de9f-46ed-a73e-8f1aa12352e6"/>
							<gml:surfaceMember xlink:href="#Poly_c24a5b13-1ac7-4a7b-b7bb-5688d1468993"/>
							<gml:surfaceMember xlink:href="#Poly_b1e6842e-2834-422c-8799-b72638967785"/>
							<gml:surfaceMember xlink:href="#Poly_5cbea044-6a50-45f6-a14e-c449dcdac44a"/>
							<gml:surfaceMember xlink:href="#Poly_61d04ae4-d962-4fa3-90cd-8c60cfa2226d"/>
							<gml:surfaceMember xlink:href="#Poly_fb1f8213-05ee-4cce-a3e3-d59b1462aa63"/>
							<gml:surfaceMember xlink:href="#Poly_c2e2d870-7373-4563-a376-bd6a78c73ab6"/>
							<gml:surfaceMember xlink:href="#Poly_1ebc5109-7c07-42d2-ab94-b5a70a52e6b9"/>
							<gml:surfaceMember xlink:href="#Poly_22bb66bb-c0ae-457e-97a5-a7ecac6c0984"/>
							<gml:surfaceMember xlink:href="#Poly_f6165428-08ec-4b9e-8270-c61c40426978"/>
							<gml:surfaceMember xlink:href="#Poly_8217fc22-e724-4bc6-9f3e-fbb0f8dfb154"/>
							<gml:surfaceMember xlink:href="#Poly_46924451-665f-459b-9bef-e41d1527d539"/>
							<gml:surfaceMember xlink:href="#Poly_3b2eb3a4-01e0-4ebd-9e28-0ad691dca758"/>
							<gml:surfaceMember xlink:href="#Poly_d0411067-e4ed-438a-ad07-987d171a2e46"/>
							<gml:surfaceMember xlink:href="#Poly_7cba646c-a30a-40fd-ac86-ccfc5c85282a"/>
							<gml:surfaceMember xlink:href="#Poly_4da1bd01-5014-4fcd-aeb5-6a8603287c9f"/>
							<gml:surfaceMember xlink:href="#Poly_90fe4db1-ff01-4960-adf8-edd1d977be21"/>
							<gml:surfaceMember xlink:href="#Poly_403b1f89-5a53-4301-badb-2f8b3f3bf28f"/>
							<gml:surfaceMember xlink:href="#Poly_3df4f652-3508-4d8d-bfee-6f7803e84399"/>
							<gml:surfaceMember xlink:href="#Poly_f993bed8-c8ca-484d-b511-4c64e01bb540"/>
							<gml:surfaceMember xlink:href="#Poly_a5f9b948-c4d6-4748-9721-673f7d7cac6a"/>
							<gml:surfaceMember xlink:href="#Poly_9c808957-c31c-4d68-9c95-b30ede0b3787"/>
							<gml:surfaceMember xlink:href="#Poly_49a7e904-21bf-419e-b7ab-a35725969775"/>
							<gml:surfaceMember xlink:href="#Poly_79be6bb7-00e3-401e-96dc-25ae13294f70"/>
							<gml:surfaceMember xlink:href="#Poly_94b782f5-30a4-45d2-b270-565812a0fd9e"/>
							<gml:surfaceMember xlink:href="#Poly_3e5d1fe0-9a64-4f3c-8c4c-4121935d3bda"/>
							<gml:surfaceMember xlink:href="#Poly_3aa523ff-02af-4f72-b6e1-060a1788b203"/>
							<gml:surfaceMember xlink:href="#Poly_5a3d0a7d-3fdd-49d5-96f7-36b351f0f77e"/>
							<gml:surfaceMember xlink:href="#Poly_f36ddd58-71fe-4d23-802e-2f896b4ddaf3"/>
							<gml:surfaceMember xlink:href="#Poly_addefab9-4fd2-4d81-b0c6-712aaf0b4c52"/>
							<gml:surfaceMember xlink:href="#Poly_36be9dbb-0833-4cc7-99c0-8ed58f354e36"/>
							<gml:surfaceMember xlink:href="#Poly_70906a99-f0af-41ae-8733-8f5a7a733071"/>
							<gml:surfaceMember xlink:href="#Poly_1af3900a-ce46-4d7c-8d61-79fa236df99a"/>
							<gml:surfaceMember xlink:href="#Poly_5eacf559-f8a8-427f-a31e-26c456ef1847"/>
							<gml:surfaceMember xlink:href="#Poly_4b515546-8142-4e6c-8006-883f95ce6bb2"/>
							<gml:surfaceMember xlink:href="#Poly_1c8c0465-81f3-40ca-9ecf-c90cb4f97572"/>
							<gml:surfaceMember xlink:href="#Poly_0c78cfe4-a99e-4e1a-b363-b359c756a181"/>
							<gml:surfaceMember xlink:href="#Poly_f50f7ac5-c597-41dd-a72d-8a3f56e6d092"/>
							<gml:surfaceMember xlink:href="#Poly_266b4c31-faf5-4e2a-832b-900f11c48ff3"/>
							<gml:surfaceMember xlink:href="#Poly_58993f00-75b5-42da-b5d0-0830ce92b15c"/>
							<gml:surfaceMember xlink:href="#Poly_d0794036-b8e6-4053-9ee0-c57acb7910cf"/>
							<gml:surfaceMember xlink:href="#Poly_3ebc585e-dfdd-4170-b0ad-1480aa6c74e2"/>
							<gml:surfaceMember xlink:href="#Poly_d389b069-5433-45e3-80c4-a7fcc0370ae3"/>
							<gml:surfaceMember xlink:href="#Poly_2dfea69e-5ead-4e35-9ee8-26c98a258303"/>
							<gml:surfaceMember xlink:href="#Poly_85beea04-54ea-4e75-baa6-d557a60cddc6"/>
							<gml:surfaceMember xlink:href="#Poly_0f73dc64-b614-4530-8f08-a1a617ba3fec"/>
							<gml:surfaceMember xlink:href="#Poly_d0a65bfc-d1f5-425f-bbd3-8a5674970c4c"/>
							<gml:surfaceMember xlink:href="#Poly_bb8949b1-7677-4220-ad37-f1153651aa0f"/>
							<gml:surfaceMember xlink:href="#Poly_d07b2c72-13a2-4efd-acc4-36289155475c"/>
							<gml:surfaceMember xlink:href="#Poly_febbd580-e8ce-4dfc-8cea-e3c1f9489f0e"/>
							<gml:surfaceMember xlink:href="#Poly_5fd9a412-66a1-4ebb-9de6-130a7b9291ac"/>
							<gml:surfaceMember xlink:href="#Poly_1de8f145-08fc-4bfe-9437-784f35ad2bd2"/>
							<gml:surfaceMember xlink:href="#Poly_3ac9f652-3cf1-47cd-9860-17327fb1c7ba"/>
							<gml:surfaceMember xlink:href="#Poly_00e4d592-553e-4f0e-94ed-283dddcd8807"/>
							<gml:surfaceMember xlink:href="#Poly_55922cfa-0e87-4419-91f7-8a5975b58e84"/>
							<gml:surfaceMember xlink:href="#Poly_84171398-3865-4ca9-a63c-b57cdaf4dd14"/>
							<gml:surfaceMember xlink:href="#Poly_f7657701-3f49-4895-977d-151eeb707ba3"/>
							<gml:surfaceMember xlink:href="#Poly_e8380201-0714-4ac4-9528-dfda215d65b6"/>
							<gml:surfaceMember xlink:href="#Poly_7cfb5ed1-4805-4dcb-b91f-3abad5c90356"/>
							<gml:surfaceMember xlink:href="#Poly_2f098ee2-8724-4de5-9bda-d9dd57afd6fc"/>
							<gml:surfaceMember xlink:href="#Poly_036aa223-0569-441a-8164-67f94ef6a16c"/>
							<gml:surfaceMember xlink:href="#Poly_8ac95b06-0099-465d-a04c-ffdc23db8428"/>
							<gml:surfaceMember xlink:href="#Poly_8addd6d8-59a0-4945-b0d8-1608117d5997"/>
							<gml:surfaceMember xlink:href="#Poly_963c1f65-ca19-47db-96a9-289815da503c"/>
							<gml:surfaceMember xlink:href="#Poly_3f4faf00-ecba-428d-8748-153113ff885c"/>
							<gml:surfaceMember xlink:href="#Poly_dfc521d9-9c8d-4de9-8541-105b97fc187b"/>
							<gml:surfaceMember xlink:href="#Poly_bb6668a3-b261-4f57-b313-7a004a403695"/>
							<gml:surfaceMember xlink:href="#Poly_e5168e09-bfd8-4480-87c1-bda6003ec3c4"/>
							<gml:surfaceMember xlink:href="#Poly_6e95726a-8adc-4fe7-bc04-79adf9a324b6"/>
							<gml:surfaceMember xlink:href="#Poly_fb1448a1-25a6-4a7e-986a-fd189a240b86"/>
							<gml:surfaceMember xlink:href="#Poly_1a9cd466-5900-4cac-b77f-176f5834387b"/>
							<gml:surfaceMember xlink:href="#Poly_d13409c0-2583-4c62-b035-f2da4661f197"/>
							<gml:surfaceMember xlink:href="#Poly_e72f0f02-afef-4f4f-b3ae-684f2461f638"/>
							<gml:surfaceMember xlink:href="#Poly_17771914-cabe-4e4d-8027-b853c44414a9"/>
							<gml:surfaceMember xlink:href="#Poly_97baa191-5975-4f7c-b573-088ab09297d5"/>
							<gml:surfaceMember xlink:href="#Poly_ade0fb2a-a2a4-42fa-9a66-49c261ae519c"/>
							<gml:surfaceMember xlink:href="#Poly_a57994e4-10e7-4fb5-bb3d-063615dded59"/>
							<gml:surfaceMember xlink:href="#Poly_9efa4999-8f5b-46a2-968f-8ebe41f5b708"/>
							<gml:surfaceMember xlink:href="#Poly_ee919bc0-edb7-40eb-9a58-972c0d9438f1"/>
							<gml:surfaceMember xlink:href="#Poly_4f9fcdf4-7439-4c17-95b2-649ab3c4ee98"/>
							<gml:surfaceMember xlink:href="#Poly_0872657a-2c01-482b-8273-3cf2e73bf4d6"/>
							<gml:surfaceMember xlink:href="#Poly_c6b1726d-cdcc-44b9-845a-22e260885591"/>
							<gml:surfaceMember xlink:href="#Poly_98f074ee-0d94-45c2-aff6-1f787d07fdaa"/>
							<gml:surfaceMember xlink:href="#Poly_509526c4-17f3-4f75-b34b-5d4cb44a2125"/>
							<gml:surfaceMember xlink:href="#Poly_c70a0f92-e5a9-40fa-b633-588524ff19d9"/>
							<gml:surfaceMember xlink:href="#Poly_f6797553-4556-4a9e-9fa4-b85b11952809"/>
							<gml:surfaceMember xlink:href="#Poly_7ff8cb5d-4293-4121-9f30-cb886a22bc7c"/>
							<gml:surfaceMember xlink:href="#Poly_eb773b67-c9e9-4a74-b403-a177253271bb"/>
							<gml:surfaceMember xlink:href="#Poly_944d108c-d2f4-44c3-9dcf-eb4c75668b2d"/>
							<gml:surfaceMember xlink:href="#Poly_4a336aa4-e4ea-45cc-be79-b8f36d045b46"/>
							<gml:surfaceMember xlink:href="#Poly_af1ccf23-3b0b-44a6-8aac-c58242f5aee5"/>
							<gml:surfaceMember xlink:href="#Poly_038f69a6-1ef4-4f97-a7c0-cb32ae53edcc"/>
							<gml:surfaceMember xlink:href="#Poly_4033322e-e97f-467b-a95f-f30091ddcae1"/>
							<gml:surfaceMember xlink:href="#Poly_724472f6-9aa1-4599-bad5-3df7ab05da80"/>
							<gml:surfaceMember xlink:href="#Poly_d8f60cc5-c82b-4716-96d8-6f6001b4509b"/>
							<gml:surfaceMember xlink:href="#Poly_6829b91f-e419-4921-bcc5-6f66c4122487"/>
							<gml:surfaceMember xlink:href="#Poly_c723891f-f64e-4753-acdc-66d25f9909df"/>
							<gml:surfaceMember xlink:href="#Poly_dde2273e-0bf2-4e2e-95e8-731462ed1b6c"/>
							<gml:surfaceMember xlink:href="#Poly_80acee62-5e8d-4be0-9f75-599d352007b4"/>
							<gml:surfaceMember xlink:href="#Poly_00f3efb9-1b78-4b16-86f2-f00a4c88ce17"/>
							<gml:surfaceMember xlink:href="#Poly_e6fbd2dd-e20b-4005-9cb9-c858c1deb2af"/>
							<gml:surfaceMember xlink:href="#Poly_aa7c2631-f9e8-41c0-8697-099451429bee"/>
							<gml:surfaceMember xlink:href="#Poly_62c7e84e-4e93-439b-a92f-9e4305a4acf9"/>
							<gml:surfaceMember xlink:href="#Poly_2ecfe516-acca-421e-976e-fbe360a623a4"/>
							<gml:surfaceMember xlink:href="#Poly_c93e23b8-f2da-4273-a5e4-c7887c0b5bf4"/>
							<gml:surfaceMember xlink:href="#Poly_ff19b8f2-0959-499c-9a4e-46b31f98cc25"/>
							<gml:surfaceMember xlink:href="#Poly_9a0e0409-391c-472f-91fc-0885cca887ec"/>
							<gml:surfaceMember xlink:href="#Poly_e3feffda-aac2-402a-85ae-e96feb079329"/>
							<gml:surfaceMember xlink:href="#Poly_3a6bdac9-8f69-44cd-b752-9c110299ad44"/>
							<gml:surfaceMember xlink:href="#Poly_42690e13-8d5a-4d2d-be0e-4df248a7c4f6"/>
							<gml:surfaceMember xlink:href="#Poly_6e51fbb6-d233-40f1-b836-604ba9cbf40c"/>
							<gml:surfaceMember xlink:href="#Poly_8d54133e-934d-4b9f-ac22-756b8555c3c7"/>
							<gml:surfaceMember xlink:href="#Poly_88f7798d-ec03-4d8f-b9ac-7b7402825b35"/>
							<gml:surfaceMember xlink:href="#Poly_63a1abcc-8bc2-4bd6-83bd-3bafa9892939"/>
							<gml:surfaceMember xlink:href="#Poly_6888884b-e1d0-4c9e-871a-e1f36bd437de"/>
							<gml:surfaceMember xlink:href="#Poly_607c8aaa-e304-4414-9dc2-482b3494dbe8"/>
							<gml:surfaceMember xlink:href="#Poly_b457f44b-8b46-4dd4-bbbb-8ed3a69295bb"/>
							<gml:surfaceMember xlink:href="#Poly_794c915e-2b27-410e-b65b-d7351ca94429"/>
							<gml:surfaceMember xlink:href="#Poly_3b50d839-31ac-455a-a7c3-8668599a8032"/>
							<gml:surfaceMember xlink:href="#Poly_8fef1ea6-691f-4c10-a5a0-ab24e8683ff4"/>
							<gml:surfaceMember xlink:href="#Poly_aa00d8a2-e469-4a3b-9044-c0106e5626b7"/>
							<gml:surfaceMember xlink:href="#Poly_688a2490-c305-4d6b-bb6b-0a4a146bb48a"/>
							<gml:surfaceMember xlink:href="#Poly_c7987562-ccbd-45cb-9698-1f356ba6d1ed"/>
							<gml:surfaceMember xlink:href="#Poly_3a5b2d86-8ac5-4f9a-8cce-a9ebbd0ab91a"/>
							<gml:surfaceMember xlink:href="#Poly_4a8fb56a-4667-495d-82d6-928967cc9dfd"/>
							<gml:surfaceMember xlink:href="#Poly_c5f05bb2-0f15-4cf5-b49b-cb75977b6548"/>
							<gml:surfaceMember xlink:href="#Poly_4480ca48-dab0-4ca5-8d9d-245d6157dd40"/>
							<gml:surfaceMember xlink:href="#Poly_1d02bee9-8858-4064-af77-35d4e5ac92e6"/>
							<gml:surfaceMember xlink:href="#Poly_5db9a5c8-f866-4da4-b277-fe7a000b2e3d"/>
							<gml:surfaceMember xlink:href="#Poly_c0d2e926-bc50-4d15-8cc7-9ecba466ae52"/>
							<gml:surfaceMember xlink:href="#Poly_999aeeac-034c-4a84-88f5-c2250d8cee6e"/>
							<gml:surfaceMember xlink:href="#Poly_ed852d28-0b26-4703-baa6-72a953f05ef4"/>
							<gml:surfaceMember xlink:href="#Poly_9f2c463b-0ead-47b6-bb3b-b5d64afa2b09"/>
							<gml:surfaceMember xlink:href="#Poly_67e0bdc6-9561-4a85-8348-9f12f20d15d3"/>
							<gml:surfaceMember xlink:href="#Poly_66d422ce-3684-476a-9bca-3e4ec9523c7a"/>
							<gml:surfaceMember xlink:href="#Poly_d005ec81-4e33-4be9-9a5f-fa437ca2312a"/>
							<gml:surfaceMember xlink:href="#Poly_c269a38c-4e98-4f75-81d0-f13bbfac44f7"/>
							<gml:surfaceMember xlink:href="#Poly_a7c632bc-2431-488f-b4be-5f8b85a439ef"/>
							<gml:surfaceMember xlink:href="#Poly_0f17b503-99b1-4a1e-912b-e62696f8614b"/>
							<gml:surfaceMember xlink:href="#Poly_3a16a51c-2ebf-4865-b127-6ffae15bcc0b"/>
							<gml:surfaceMember xlink:href="#Poly_3561025d-e7ca-45a1-a114-d540be2158ed"/>
							<gml:surfaceMember xlink:href="#Poly_090f4287-0dce-4350-954a-e005b7e48201"/>
							<gml:surfaceMember xlink:href="#Poly_28d816ca-1ba2-4b36-b459-88b6cf9fcfa1"/>
							<gml:surfaceMember xlink:href="#Poly_21fae298-76d3-4717-b3b0-d7485dac99b8"/>
							<gml:surfaceMember xlink:href="#Poly_9058e256-be43-49fd-af62-d34bafeeb274"/>
							<gml:surfaceMember xlink:href="#Poly_7ac73259-5690-438a-bf12-68332c49db2f"/>
							<gml:surfaceMember xlink:href="#Poly_d9c46e33-b2f2-4aaf-b68a-abd3d50e1a39"/>
							<gml:surfaceMember xlink:href="#Poly_9676fbd1-b2d0-4d02-8547-2c94aa6cb19d"/>
							<gml:surfaceMember xlink:href="#Poly_ca7450ae-b573-4a12-a64d-bc0a2fe65794"/>
							<gml:surfaceMember xlink:href="#Poly_9098d845-fa55-4c70-a5c2-408ace5325a5"/>
							<gml:surfaceMember xlink:href="#Poly_3d4df037-c685-4426-98c4-52f55323e36b"/>
							<gml:surfaceMember xlink:href="#Poly_0a8b9cb1-ed14-4744-8884-e3e3f2bd3ff8"/>
							<gml:surfaceMember xlink:href="#Poly_9401c5ea-cebc-4923-98f7-3bb5b39ecabe"/>
							<gml:surfaceMember xlink:href="#Poly_cd98210e-bc75-4d0d-802c-16beff19c474"/>
							<gml:surfaceMember xlink:href="#Poly_80e99de8-297f-4bb8-be4a-98d63b334a11"/>
							<gml:surfaceMember xlink:href="#Poly_c6c15be3-c00a-4938-bff4-843577054516"/>
							<gml:surfaceMember xlink:href="#Poly_c0a8bef8-d4ed-4694-a6d5-7f6d616d79ce"/>
							<gml:surfaceMember xlink:href="#Poly_9c39ec3e-f43d-4cc8-8aae-aa476a241ee7"/>
							<gml:surfaceMember xlink:href="#Poly_80db9cce-9264-45e7-9740-d763ffea8640"/>
							<gml:surfaceMember xlink:href="#Poly_b28f322b-b027-4106-bef8-7912705dc1f5"/>
							<gml:surfaceMember xlink:href="#Poly_a44fa756-dd1b-4e81-a39c-ad128a1dbd1f"/>
							<gml:surfaceMember xlink:href="#Poly_d2c9c7bf-7296-4c51-8f44-bfa98ededd8e"/>
							<gml:surfaceMember xlink:href="#Poly_16119644-b50b-418b-a767-763bd22268fb"/>
							<gml:surfaceMember xlink:href="#Poly_7cd2c6d5-cd57-44ad-807a-2561f3531a66"/>
							<gml:surfaceMember xlink:href="#Poly_e15cfa50-b5d6-40e7-a276-7911361080c4"/>
							<gml:surfaceMember xlink:href="#Poly_424c5ac8-ad55-4369-8d01-385201e2b0a5"/>
							<gml:surfaceMember xlink:href="#Poly_e2a56f93-1762-4ff1-8d8e-4f7fdc0ddd51"/>
							<gml:surfaceMember xlink:href="#Poly_a5884a0a-fa4d-4cb6-884b-21d6741734c6"/>
							<gml:surfaceMember xlink:href="#Poly_a1dc8853-f2a8-4931-bcb5-e11cb83e89ee"/>
							<gml:surfaceMember xlink:href="#Poly_6b04adbe-239f-4cdd-83a7-849eb1987f6b"/>
							<gml:surfaceMember xlink:href="#Poly_532a366d-c8af-4076-8559-78df0fc19b2d"/>
							<gml:surfaceMember xlink:href="#Poly_7737930c-1954-4f5c-a1fa-01b6d61bc118"/>
							<gml:surfaceMember xlink:href="#Poly_e032bfca-1c50-4076-baaa-aeffb77210e0"/>
							<gml:surfaceMember xlink:href="#Poly_67ab0a6b-4010-42db-bbe1-e54204cefc73"/>
							<gml:surfaceMember xlink:href="#Poly_2d225004-8ad6-4327-af5b-3bd29e72e9b9"/>
							<gml:surfaceMember xlink:href="#Poly_50383625-aa19-4ab7-8115-7176e9239f0a"/>
							<gml:surfaceMember xlink:href="#Poly_df1f2578-8d2a-4a51-8d25-77a2f64821aa"/>
							<gml:surfaceMember xlink:href="#Poly_a6bf097a-31ff-4b75-a61b-fb72d6ad6fe8"/>
							<gml:surfaceMember xlink:href="#Poly_810d9c21-283c-466d-a962-504be2fff095"/>
							<gml:surfaceMember xlink:href="#Poly_7bb0e566-8e67-40ad-9c26-be0528525c05"/>
							<gml:surfaceMember xlink:href="#Poly_d2d9c3aa-3e37-4c1b-9494-242c62c98ff3"/>
							<gml:surfaceMember xlink:href="#Poly_275de563-5c37-41aa-bdea-d989d4aa06e6"/>
							<gml:surfaceMember xlink:href="#Poly_a64db9fa-cd5f-4990-8850-363ec372415f"/>
							<gml:surfaceMember xlink:href="#Poly_8713567a-1879-47b7-886b-0a3e4fcf2abc"/>
							<gml:surfaceMember xlink:href="#Poly_10687453-96b9-4b31-a50e-4b7edf38d2c5"/>
							<gml:surfaceMember xlink:href="#Poly_963ba6cc-0719-4f69-a707-316010c1d73f"/>
							<gml:surfaceMember xlink:href="#Poly_4dcb7791-294d-4cb2-ae84-d49c3a59ac03"/>
							<gml:surfaceMember xlink:href="#Poly_e5f91db5-1869-43c4-b3bc-da1f3b546009"/>
							<gml:surfaceMember xlink:href="#Poly_77461c39-683f-4c79-b873-342bcd0742a0"/>
							<gml:surfaceMember xlink:href="#Poly_db96c8d4-280a-4e86-be15-6c83c8ef80c5"/>
							<gml:surfaceMember xlink:href="#Poly_a4a7bcf1-c52a-4cff-8c37-5946cefea7be"/>
							<gml:surfaceMember xlink:href="#Poly_1006b66a-c84f-4b7e-8d15-fd68d6ff8a36"/>
							<gml:surfaceMember xlink:href="#Poly_9e180dab-a619-473b-b89f-03ae4993dd8d"/>
							<gml:surfaceMember xlink:href="#Poly_21e70422-ec0d-4e57-8c93-9c5c48b69655"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod3Solid>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">3</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">2</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">2</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
					<uro:lodType>3.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">416.15045</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">9</uro:districtsAndZonesType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2430100000</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>