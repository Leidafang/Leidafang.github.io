<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e22423bb-8d70-4b4d-8a7a-1585a4c68f4d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">26.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671671644885876 139.7380177966213 0 35.67164369913284 139.73789996440195 0 35.671569842430706 139.73792497304626 0 35.67156294683778 139.73789073734346 0 35.67152886652591 139.73790286269477 0 35.67154188978135 139.73795774789696 0 35.671551802073765 139.73795420125063 0 35.67157495477008 139.73805215548614 0 35.671671644885876 139.7380177966213 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671671644885876 139.7380177966213 10.7 35.67157495477008 139.73805215548614 10.7 35.671551802073765 139.73795420125063 10.7 35.67154188978135 139.73795774789696 10.7 35.67152886652591 139.73790286269477 10.7 35.67156294683778 139.73789073734346 10.7 35.671569842430706 139.73792497304626 10.7 35.67164369913284 139.73789996440195 10.7 35.671671644885876 139.7380177966213 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671671644885876 139.7380177966213 10.7 35.67164369913284 139.73789996440195 10.7 35.67164369913284 139.73789996440195 37.25 35.671671644885876 139.7380177966213 37.25 35.671671644885876 139.7380177966213 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67164369913284 139.73789996440195 10.7 35.671569842430706 139.73792497304626 10.7 35.671569842430706 139.73792497304626 37.25 35.67164369913284 139.73789996440195 37.25 35.67164369913284 139.73789996440195 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671569842430706 139.73792497304626 10.7 35.67156294683778 139.73789073734346 10.7 35.67156294683778 139.73789073734346 37.25 35.671569842430706 139.73792497304626 37.25 35.671569842430706 139.73792497304626 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156294683778 139.73789073734346 10.7 35.67152886652591 139.73790286269477 10.7 35.67152886652591 139.73790286269477 37.25 35.67156294683778 139.73789073734346 37.25 35.67156294683778 139.73789073734346 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152886652591 139.73790286269477 10.7 35.67154188978135 139.73795774789696 10.7 35.67154188978135 139.73795774789696 37.25 35.67152886652591 139.73790286269477 37.25 35.67152886652591 139.73790286269477 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67154188978135 139.73795774789696 10.7 35.671551802073765 139.73795420125063 10.7 35.671551802073765 139.73795420125063 37.25 35.67154188978135 139.73795774789696 37.25 35.67154188978135 139.73795774789696 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671551802073765 139.73795420125063 10.7 35.67157495477008 139.73805215548614 10.7 35.67157495477008 139.73805215548614 37.25 35.671551802073765 139.73795420125063 37.25 35.671551802073765 139.73795420125063 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157495477008 139.73805215548614 10.7 35.671671644885876 139.7380177966213 10.7 35.671671644885876 139.7380177966213 37.25 35.67157495477008 139.73805215548614 37.25 35.67157495477008 139.73805215548614 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671671644885876 139.7380177966213 37.25 35.67164369913284 139.73789996440195 37.25 35.671569842430706 139.73792497304626 37.25 35.67156294683778 139.73789073734346 37.25 35.67152886652591 139.73790286269477 37.25 35.67154188978135 139.73795774789696 37.25 35.671551802073765 139.73795420125063 37.25 35.67157495477008 139.73805215548614 37.25 35.671671644885876 139.7380177966213 37.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0c534e68-acdb-4797-9891-6094006ce41f"/>
							<gml:surfaceMember xlink:href="#poly-5786c979-1551-4c75-875e-92b58b752473"/>
							<gml:surfaceMember xlink:href="#poly-b5aa545b-3be4-4647-8346-3e9c9715ef53"/>
							<gml:surfaceMember xlink:href="#poly-8cf92ddc-209f-449c-8d90-ecedf4cf4bd9"/>
							<gml:surfaceMember xlink:href="#poly-7cfa4318-b6d5-4d74-b8cb-77f876f40d3f"/>
							<gml:surfaceMember xlink:href="#poly-8fca9c27-6258-4515-944a-68f9a66ad6cd"/>
							<gml:surfaceMember xlink:href="#poly-0148aeff-75a6-4e39-be23-1695ed3acfe5"/>
							<gml:surfaceMember xlink:href="#poly-494ab345-a85c-4b36-8b36-dff962baf681"/>
							<gml:surfaceMember xlink:href="#poly-31fc4210-061c-45a2-b7f1-a378af4f281b"/>
							<gml:surfaceMember xlink:href="#poly-1e5a3c6b-06ee-4489-84f4-0b1ec4db52c1"/>
							<gml:surfaceMember xlink:href="#poly-3bd12f74-2653-4d91-9bcf-6ae6d3c42e82"/>
							<gml:surfaceMember xlink:href="#poly-376e30c0-9956-48d8-98b4-a00173968a18"/>
							<gml:surfaceMember xlink:href="#poly-28b3f993-edb4-4b2c-b3d1-c2bd84c31827"/>
							<gml:surfaceMember xlink:href="#poly-ca51e180-b0fc-42fa-b863-0942b86a78a5"/>
							<gml:surfaceMember xlink:href="#poly-f9227b14-0ed4-4e1a-a088-b378a6ac489d"/>
							<gml:surfaceMember xlink:href="#poly-45c8e61e-34ac-4742-9419-72862192af62"/>
							<gml:surfaceMember xlink:href="#poly-6ba12f13-221b-400a-919d-a7fca96e7d87"/>
							<gml:surfaceMember xlink:href="#poly-4dd88bb1-e9cf-489f-945d-c5a7712e1cd9"/>
							<gml:surfaceMember xlink:href="#poly-478aad74-92aa-44c7-8c40-fed21db7b71e"/>
							<gml:surfaceMember xlink:href="#poly-e6027bc1-ebb4-47e9-ae52-e7a8aba7c6bc"/>
							<gml:surfaceMember xlink:href="#poly-d22c46e7-d9e0-4324-9f84-73f2c32a162e"/>
							<gml:surfaceMember xlink:href="#poly-ee9c1c17-ac36-446c-a14d-f96833722748"/>
							<gml:surfaceMember xlink:href="#poly-42a40b48-dbbd-465a-aa56-4547c54307f6"/>
							<gml:surfaceMember xlink:href="#poly-a89e3b2c-538d-498e-bdcd-4f1c2bde7a3d"/>
							<gml:surfaceMember xlink:href="#poly-f8df6572-97aa-4833-b7e4-03b527dd04e7"/>
							<gml:surfaceMember xlink:href="#poly-b5738421-97b5-4210-840b-8f576e1d5bc2"/>
							<gml:surfaceMember xlink:href="#poly-626657d1-3720-4f6d-9c04-2af42ac9aa8a"/>
							<gml:surfaceMember xlink:href="#poly-428fb4a9-1aff-4666-9f30-243a369fd4e6"/>
							<gml:surfaceMember xlink:href="#poly-ded580e4-a832-4b9a-be44-3024afb41d29"/>
							<gml:surfaceMember xlink:href="#poly-b909b3c4-f59f-47d8-8cd0-7271009efcde"/>
							<gml:surfaceMember xlink:href="#poly-58e0a209-a82e-4774-8b81-b3bf69102c13"/>
							<gml:surfaceMember xlink:href="#poly-b0bf3bb5-d0b7-437f-8574-64451946aa7b"/>
							<gml:surfaceMember xlink:href="#poly-dd0a9e34-fb75-469f-baa6-06ba552176ce"/>
							<gml:surfaceMember xlink:href="#poly-cdbbabb8-bbc9-4fbe-a904-8adb58576b55"/>
							<gml:surfaceMember xlink:href="#poly-c68af3af-b087-409e-8a1a-4b0f67b48d4c"/>
							<gml:surfaceMember xlink:href="#poly-9f80288e-4a2b-4829-b6a7-957bf48bbdb5"/>
							<gml:surfaceMember xlink:href="#poly-e10a5fe9-e919-46c0-b3cd-8d1bee0b4f71"/>
							<gml:surfaceMember xlink:href="#poly-057e16d4-1491-4c6f-b30b-1b939d32f982"/>
							<gml:surfaceMember xlink:href="#poly-1b3abfe0-f36e-4f18-8a68-4cd508a62458"/>
							<gml:surfaceMember xlink:href="#poly-db45c155-a956-476f-ad2f-64f6f346c961"/>
							<gml:surfaceMember xlink:href="#poly-6713e16d-dfc5-44a3-9df1-72bf08772e70"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e22423bb-8d70-4b4d-8a7a-1585a4c68f4d_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71329f2a-b308-4467-aec9-7e62ecf8d955">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67154010304909 139.73790969809983 42.042 35.671548339269584 139.73790676099568 42.042 35.67155362094638 139.7379290463865 42.042 35.67154539373907 139.7379319834778 42.042 35.67154010304909 139.73790969809983 42.042</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd8ab649-a1b2-4d40-88db-bdbfcf971039">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd8ab649-a1b2-4d40-88db-bdbfcf971039_0">
											<gml:posList>35.67155362094638 139.7379290463865 42.042 35.67155362094638 139.7379290463865 44.491 35.67154539373907 139.7379319834778 44.491 35.67154539373907 139.7379319834778 42.042 35.67155362094638 139.7379290463865 42.042</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-621f407d-1942-4e04-b1b9-684deadc33ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-621f407d-1942-4e04-b1b9-684deadc33ea_0">
											<gml:posList>35.67154010304909 139.73790969809983 42.042 35.67154010304909 139.73790969809983 44.491 35.671548339269584 139.73790676099568 44.491 35.671548339269584 139.73790676099568 42.042 35.67154010304909 139.73790969809983 42.042</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0e75b68-9482-4e04-abc0-84d9099a54c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0e75b68-9482-4e04-abc0-84d9099a54c9_0">
											<gml:posList>35.671548339269584 139.73790676099568 42.042 35.671548339269584 139.73790676099568 44.491 35.67155362094638 139.7379290463865 44.491 35.67155362094638 139.7379290463865 42.042 35.671548339269584 139.73790676099568 42.042</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20c9a52d-5cf4-4d24-b125-ed955ec949ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20c9a52d-5cf4-4d24-b125-ed955ec949ca_0">
											<gml:posList>35.67155362094638 139.7379290463865 44.491 35.671548339269584 139.73790676099568 44.491 35.67154010304909 139.73790969809983 44.491 35.67154539373907 139.7379319834778 44.491 35.67155362094638 139.7379290463865 44.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36f8aa26-1a84-46f6-a4a5-cd313327bb9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36f8aa26-1a84-46f6-a4a5-cd313327bb9a_0">
											<gml:posList>35.67154539373907 139.7379319834778 42.042 35.67154539373907 139.7379319834778 44.491 35.67154010304909 139.73790969809983 44.491 35.67154010304909 139.73790969809983 42.042 35.67154539373907 139.7379319834778 42.042</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e22423bb-8d70-4b4d-8a7a-1585a4c68f4d_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b40137c-6b95-43e8-a97c-94e06f7465e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b40137c-6b95-43e8-a97c-94e06f7465e0_0">
											<gml:posList>35.671587517271576 139.7379008597588 36.932 35.67156639463546 139.73790785519412 35.938 35.67156639463546 139.73790785519412 38.328 35.671587517271576 139.7379008597588 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6da66889-4b0a-4eb4-8d82-5a868e3e88ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6da66889-4b0a-4eb4-8d82-5a868e3e88ce_0">
											<gml:posList>35.67155818025127 139.73796110872266 37.897 35.67155180427958 139.73793422931956 38.369 35.67155180427958 139.73793422931956 37.897 35.67155818025127 139.73796110872266 37.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33a822d3-c55c-4290-a758-3788f796f778">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33a822d3-c55c-4290-a758-3788f796f778_0">
											<gml:posList>35.67155818025127 139.73796110872266 37.897 35.67155818025127 139.73796110872266 38.369 35.67155180427958 139.73793422931956 38.369 35.67155818025127 139.73796110872266 37.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d08fb0f-2941-433a-b25f-11711ec6d82a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d08fb0f-2941-433a-b25f-11711ec6d82a_0">
											<gml:posList>35.67156097767376 139.73793097075608 37.897 35.67155180427958 139.73793422931956 38.369 35.67156097767376 139.73793097075608 38.369 35.67156097767376 139.73793097075608 37.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a142a535-bb9f-4e9b-9ac5-ee3d4b25b44f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a142a535-bb9f-4e9b-9ac5-ee3d4b25b44f_0">
											<gml:posList>35.67156097767376 139.73793097075608 37.897 35.67155180427958 139.73793422931956 37.897 35.67155180427958 139.73793422931956 38.369 35.67156097767376 139.73793097075608 37.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a416aa9-954d-42ff-8a77-e76b848865f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a416aa9-954d-42ff-8a77-e76b848865f6_0">
											<gml:posList>35.67155818025127 139.73796110872266 38.369 35.67156097767376 139.73793097075608 38.369 35.67155180427958 139.73793422931956 38.369 35.67155818025127 139.73796110872266 38.369</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58cc6e06-52fe-4c62-b8ab-1cf0671f5186">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58cc6e06-52fe-4c62-b8ab-1cf0671f5186_0">
											<gml:posList>35.67155818025127 139.73796110872266 38.369 35.671567353637414 139.7379578391156 38.369 35.67156097767376 139.73793097075608 38.369 35.67155818025127 139.73796110872266 38.369</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac83ccbb-9925-4965-907c-706d08e4dee1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac83ccbb-9925-4965-907c-706d08e4dee1_0">
											<gml:posList>35.671567353637414 139.7379578391156 37.897 35.67155818025127 139.73796110872266 38.369 35.67155818025127 139.73796110872266 37.897 35.671567353637414 139.7379578391156 37.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70110382-e7f5-48eb-af2d-cb15f95658ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70110382-e7f5-48eb-af2d-cb15f95658ec_0">
											<gml:posList>35.671567353637414 139.7379578391156 37.897 35.671567353637414 139.7379578391156 38.369 35.67155818025127 139.73796110872266 38.369 35.671567353637414 139.7379578391156 37.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3215fcc5-b7dc-4c07-b060-ba511bba58c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3215fcc5-b7dc-4c07-b060-ba511bba58c1_0">
											<gml:posList>35.671567353637414 139.7379578391156 37.897 35.67156097767376 139.73793097075608 38.369 35.671567353637414 139.7379578391156 38.369 35.671567353637414 139.7379578391156 37.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71a4b0b1-7713-4714-99c2-3e87b29eecfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71a4b0b1-7713-4714-99c2-3e87b29eecfe_0">
											<gml:posList>35.671567353637414 139.7379578391156 37.897 35.67156097767376 139.73793097075608 37.897 35.67156097767376 139.73793097075608 38.369 35.671567353637414 139.7379578391156 37.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5914eba0-dfea-4959-80fe-79c113c3bb29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5914eba0-dfea-4959-80fe-79c113c3bb29_0">
											<gml:posList>35.67156639463546 139.73790785519412 38.328 35.67156639463546 139.73790785519412 35.938 35.671569842430706 139.73792497304623 38.328 35.67156639463546 139.73790785519412 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-640500f3-6eb4-4977-b153-d5bf78bda43e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-640500f3-6eb4-4977-b153-d5bf78bda43e_0">
											<gml:posList>35.671569842430706 139.73792497304623 38.328 35.67156639463546 139.73790785519412 35.938 35.671569842430706 139.73792497304623 10.72 35.671569842430706 139.73792497304623 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d4a8330-1304-4b9f-835e-4663ba8fe2e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d4a8330-1304-4b9f-835e-4663ba8fe2e3_0">
											<gml:posList>35.671569842430706 139.73792497304623 10.72 35.67156639463546 139.73790785519412 35.938 35.671562946837774 139.73789073734346 10.72 35.671569842430706 139.73792497304623 10.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-801d1d34-e6bb-488f-9f0c-b8d369248b37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-801d1d34-e6bb-488f-9f0c-b8d369248b37_0">
											<gml:posList>35.67156639463546 139.73790785519412 35.938 35.671562946837774 139.73789073734346 35.938 35.671562946837774 139.73789073734346 10.72 35.67156639463546 139.73790785519412 35.938</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0261646c-26fb-4505-a904-a57ca0c3b0f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0261646c-26fb-4505-a904-a57ca0c3b0f9_0">
											<gml:posList>35.671562946837774 139.73789073734346 35.938 35.67156639463546 139.73790785519412 35.938 35.671587517271576 139.7379008597588 36.932 35.671562946837774 139.73789073734346 35.938</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c9a23ac-4e00-4f1e-bb02-0c32dc5b06aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c9a23ac-4e00-4f1e-bb02-0c32dc5b06aa_0">
											<gml:posList>35.6715836996039 139.73788335571942 36.932 35.671562946837774 139.73789073734346 35.938 35.671587517271576 139.7379008597588 36.932 35.6715836996039 139.73788335571942 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-646aca64-07bd-46fb-80cb-0b39dc723a86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-646aca64-07bd-46fb-80cb-0b39dc723a86_0">
											<gml:posList>35.6715836996039 139.73788335571942 36.932 35.671592125068024 139.73788036315355 36.932 35.671562946837774 139.73789073734346 35.938 35.6715836996039 139.73788335571942 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b850b54a-5d91-4d91-91b5-98a045f9c1df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b850b54a-5d91-4d91-91b5-98a045f9c1df_0">
											<gml:posList>35.671592125068024 139.73788036315355 36.932 35.671592125068024 139.73788036315355 10.72 35.671562946837774 139.73789073734346 35.938 35.671592125068024 139.73788036315355 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8795eda-cb28-4141-adc7-02617f45c1f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8795eda-cb28-4141-adc7-02617f45c1f1_0">
											<gml:posList>35.671592125068024 139.73788036315355 10.72 35.671562946837774 139.73789073734346 10.72 35.671562946837774 139.73789073734346 35.938 35.671592125068024 139.73788036315355 10.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9e02149-0d07-49a9-a39f-0c4572307774">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9e02149-0d07-49a9-a39f-0c4572307774_0">
											<gml:posList>35.67156639463546 139.73790785519412 38.328 35.671569842430706 139.73792497304623 38.328 35.67159132592298 139.7379183638106 36.932 35.67156639463546 139.73790785519412 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24731f05-6c75-4a4f-8669-879d74ac5927">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24731f05-6c75-4a4f-8669-879d74ac5927_0">
											<gml:posList>35.671587517271576 139.7379008597588 36.932 35.67156639463546 139.73790785519412 38.328 35.67159132592298 139.7379183638106 36.932 35.671587517271576 139.7379008597588 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8bf284b-eb89-44d8-ab87-c838a0b99016">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8bf284b-eb89-44d8-ab87-c838a0b99016_0">
											<gml:posList>35.671569842430706 139.73792497304623 38.328 35.671569842430706 139.73792497304623 10.72 35.67159132592298 139.7379183638106 36.932 35.671569842430706 139.73792497304623 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-baa044a8-4193-47ca-b8c2-bdb052b419e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-baa044a8-4193-47ca-b8c2-bdb052b419e0_0">
											<gml:posList>35.67159132592298 139.7379183638106 36.932 35.67160027362351 139.73791466365523 10.72 35.671600445444426 139.73791537042206 36.932 35.67159132592298 139.7379183638106 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f4c9aa1-dbad-4710-98c0-468ea1e01792">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f4c9aa1-dbad-4710-98c0-468ea1e01792_0">
											<gml:posList>35.67159132592298 139.7379183638106 36.932 35.671569842430706 139.73792497304623 10.72 35.67160027362351 139.73791466365523 10.72 35.67159132592298 139.7379183638106 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7172fc1-0f30-49a9-8990-52cfa59caa9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7172fc1-0f30-49a9-8990-52cfa59caa9a_0">
											<gml:posList>35.67159628525749 139.73789786678688 36.932 35.6715836996039 139.73788335571942 36.932 35.671587517271576 139.7379008597588 36.932 35.67159628525749 139.73789786678688 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1e7e9ff-d682-4a64-934a-bd5cc93bae55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1e7e9ff-d682-4a64-934a-bd5cc93bae55_0">
											<gml:posList>35.67159628525749 139.73789786678688 36.932 35.671592125068024 139.73788036315355 36.932 35.6715836996039 139.73788335571942 36.932 35.67159628525749 139.73789786678688 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c060487-c5b7-4169-9ad0-9baf7b447bf6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c060487-c5b7-4169-9ad0-9baf7b447bf6_0">
											<gml:posList>35.67159628525749 139.73789786678688 36.932 35.671587517271576 139.7379008597588 36.932 35.67159132592298 139.7379183638106 36.932 35.67159628525749 139.73789786678688 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f29f70b6-1d91-4d33-b3c3-30b5b48bd6fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f29f70b6-1d91-4d33-b3c3-30b5b48bd6fc_0">
											<gml:posList>35.671600445444426 139.73791537042206 36.932 35.67159628525749 139.73789786678688 36.932 35.67159132592298 139.7379183638106 36.932 35.671600445444426 139.73791537042206 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfa1b55c-6557-4ed2-aa1e-eb426bda830a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfa1b55c-6557-4ed2-aa1e-eb426bda830a_0">
											<gml:posList>35.671600445444426 139.73791537042206 36.932 35.67160027362351 139.73791466365523 10.72 35.67159628525749 139.73789786678688 36.932 35.671600445444426 139.73791537042206 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdd6f65b-128f-4f65-8173-fe52e31a3116">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdd6f65b-128f-4f65-8173-fe52e31a3116_0">
											<gml:posList>35.67159628525749 139.73789786678688 36.932 35.671592125068024 139.73788036315355 10.72 35.671592125068024 139.73788036315355 36.932 35.67159628525749 139.73789786678688 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ece2f8d-0df0-46e5-b93c-20173f00582f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ece2f8d-0df0-46e5-b93c-20173f00582f_0">
											<gml:posList>35.67159628525749 139.73789786678688 36.932 35.67160027362351 139.73791466365523 10.72 35.671592125068024 139.73788036315355 10.72 35.67159628525749 139.73789786678688 36.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc416b8e-a7af-4214-b7e2-65916205e121">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671562946837774 139.73789073734346 10.72 35.67160027362351 139.73791466365523 10.72 35.671569842430706 139.73792497304623 10.72 35.671562946837774 139.73789073734346 10.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42800b66-d9b9-4b88-9a4c-576f9fc5e8a2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671562946837774 139.73789073734346 10.72 35.671592125068024 139.73788036315355 10.72 35.67160027362351 139.73791466365523 10.72 35.671562946837774 139.73789073734346 10.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35b440f7-7752-4369-ba34-6acc6005b122">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67155818025127 139.73796110872266 37.897 35.67156097767376 139.73793097075608 37.897 35.671567353637414 139.7379578391156 37.897 35.67155818025127 139.73796110872266 37.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ecd5c47-1f15-4d04-93b0-0d1656d633ac">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67155818025127 139.73796110872266 37.897 35.67155180427958 139.73793422931956 37.897 35.67156097767376 139.73793097075608 37.897 35.67155818025127 139.73796110872266 37.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0c534e68-acdb-4797-9891-6094006ce41f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c534e68-acdb-4797-9891-6094006ce41f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c534e68-acdb-4797-9891-6094006ce41f">
											<gml:posList>35.67167164488586 139.7380177966213 10.7 35.67157495477007 139.73805215548612 10.7 35.67155180207374 139.73795420125063 10.7 35.67154188978136 139.73795774789696 10.7 35.6715288665259 139.73790286269477 10.7 35.671562946837774 139.73789073734346 10.7 35.671569842430706 139.73792497304623 10.7 35.67164369913284 139.73789996440195 10.7 35.67167164488586 139.7380177966213 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5786c979-1551-4c75-875e-92b58b752473">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5786c979-1551-4c75-875e-92b58b752473">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5786c979-1551-4c75-875e-92b58b752473">
											<gml:posList>35.671628319063984 139.73803319162258 38.328 35.671624477155866 139.73803058923173 38.328 35.67157706025686 139.73804744720724 38.328 35.67157495477007 139.73805215548612 38.328 35.671628319063984 139.73803319162258 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5aa545b-3be4-4647-8346-3e9c9715ef53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5aa545b-3be4-4647-8346-3e9c9715ef53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5aa545b-3be4-4647-8346-3e9c9715ef53">
											<gml:posList>35.67153230495546 139.73790816088265 42.29 35.671534758000504 139.73790981492573 42.29 35.67155345619997 139.7379031427257 42.29 35.67155480588547 139.73790014753908 42.29 35.67153230495546 139.73790816088265 42.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8cf92ddc-209f-449c-8d90-ecedf4cf4bd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cf92ddc-209f-449c-8d90-ecedf4cf4bd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cf92ddc-209f-449c-8d90-ecedf4cf4bd9">
											<gml:posList>35.671569842430706 139.73792497304623 38.328 35.671562946837774 139.73789073734346 38.328 35.67156069718136 139.73789550102936 38.328 35.671567574649224 139.73792961524248 38.328 35.671569842430706 139.73792497304623 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7cfa4318-b6d5-4d74-b8cb-77f876f40d3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cfa4318-b6d5-4d74-b8cb-77f876f40d3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cfa4318-b6d5-4d74-b8cb-77f876f40d3f">
											<gml:posList>35.67155480588547 139.73790014753908 42.29 35.67155345619997 139.7379031427257 42.29 35.671559587950426 139.7379289398682 42.29 35.67156203198146 139.73793059392318 42.29 35.67155480588547 139.73790014753908 42.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fca9c27-6258-4515-944a-68f9a66ad6cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fca9c27-6258-4515-944a-68f9a66ad6cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fca9c27-6258-4515-944a-68f9a66ad6cd">
											<gml:posList>35.671559587950426 139.7379289398682 42.042 35.67155345619997 139.7379031427257 42.042 35.671534758000504 139.73790981492573 42.042 35.671540871722094 139.73793561208416 42.042 35.671559587950426 139.7379289398682 42.042</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0148aeff-75a6-4e39-be23-1695ed3acfe5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0148aeff-75a6-4e39-be23-1695ed3acfe5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0148aeff-75a6-4e39-be23-1695ed3acfe5">
											<gml:posList>35.671569842430706 139.73792497304623 38.328 35.671567574649224 139.73792961524248 38.328 35.67159830381164 139.73791995723812 38.328 35.671600445444426 139.73791537042206 38.328 35.671569842430706 139.73792497304623 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-494ab345-a85c-4b36-8b36-dff962baf681">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-494ab345-a85c-4b36-8b36-dff962baf681">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-494ab345-a85c-4b36-8b36-dff962baf681">
											<gml:posList>35.671539531049426 139.73793860725894 42.29 35.671540871722094 139.73793561208416 42.29 35.671534758000504 139.73790981492573 42.29 35.67153230495546 139.73790816088265 42.29 35.671539531049426 139.73793860725894 42.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31fc4210-061c-45a2-b7f1-a378af4f281b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31fc4210-061c-45a2-b7f1-a378af4f281b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31fc4210-061c-45a2-b7f1-a378af4f281b">
											<gml:posList>35.67154188978136 139.73795774789696 38.328 35.67155180207374 139.73795420125063 38.328 35.67155394365535 139.7379495481597 38.328 35.671543057662554 139.73795281980458 38.328 35.671539531049426 139.73793860725894 38.328 35.67153230495546 139.73790816088265 38.328 35.67153171664744 139.73790511277156 38.328 35.67156069718136 139.73789550102936 38.328 35.671562946837774 139.73789073734346 38.328 35.6715288665259 139.73790286269477 38.328 35.67154188978136 139.73795774789696 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e5a3c6b-06ee-4489-84f4-0b1ec4db52c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e5a3c6b-06ee-4489-84f4-0b1ec4db52c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e5a3c6b-06ee-4489-84f4-0b1ec4db52c1">
											<gml:posList>35.67156203198146 139.73793059392318 42.29 35.671559587950426 139.7379289398682 42.29 35.671540871722094 139.73793561208416 42.29 35.671539531049426 139.73793860725894 42.29 35.67156203198146 139.73793059392318 42.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3bd12f74-2653-4d91-9bcf-6ae6d3c42e82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bd12f74-2653-4d91-9bcf-6ae6d3c42e82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bd12f74-2653-4d91-9bcf-6ae6d3c42e82">
											<gml:posList>35.67164369913284 139.73789996440195 31.325 35.671600445444426 139.73791537042206 38.328 35.671628319063984 139.73803319162258 38.328 35.67167164488586 139.7380177966213 31.325 35.67164369913284 139.73789996440195 31.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-376e30c0-9956-48d8-98b4-a00173968a18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-376e30c0-9956-48d8-98b4-a00173968a18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-376e30c0-9956-48d8-98b4-a00173968a18">
											<gml:posList>35.67156069718136 139.73789550102936 37.897 35.67153171664744 139.73790511277156 37.897 35.67153230495546 139.73790816088265 37.897 35.67155480588547 139.73790014753908 37.897 35.67156203198146 139.73793059392318 37.897 35.671539531049426 139.73793860725894 37.897 35.671543057662554 139.73795281980458 37.897 35.67155394365535 139.7379495481597 37.897 35.67157706025686 139.73804744720724 37.897 35.671624477155866 139.73803058923173 37.897 35.67159830381164 139.73791995723812 37.897 35.671567574649224 139.73792961524248 37.897 35.67156069718136 139.73789550102936 37.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28b3f993-edb4-4b2c-b3d1-c2bd84c31827">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28b3f993-edb4-4b2c-b3d1-c2bd84c31827">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28b3f993-edb4-4b2c-b3d1-c2bd84c31827">
											<gml:posList>35.671600445444426 139.73791537042206 38.328 35.67159830381164 139.73791995723812 38.328 35.671624477155866 139.73803058923173 38.328 35.671628319063984 139.73803319162258 38.328 35.671600445444426 139.73791537042206 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca51e180-b0fc-42fa-b863-0942b86a78a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca51e180-b0fc-42fa-b863-0942b86a78a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca51e180-b0fc-42fa-b863-0942b86a78a5">
											<gml:posList>35.67155180207374 139.73795420125063 38.328 35.67157495477007 139.73805215548612 38.328 35.67157706025686 139.73804744720724 38.328 35.67155394365535 139.7379495481597 38.328 35.67155180207374 139.73795420125063 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9227b14-0ed4-4e1a-a088-b378a6ac489d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9227b14-0ed4-4e1a-a088-b378a6ac489d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9227b14-0ed4-4e1a-a088-b378a6ac489d">
											<gml:posList>35.67153230495546 139.73790816088265 38.328 35.67153230495546 139.73790816088265 37.897 35.67153171664744 139.73790511277156 37.897 35.67153171664744 139.73790511277156 38.328 35.67153230495546 139.73790816088265 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45c8e61e-34ac-4742-9419-72862192af62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45c8e61e-34ac-4742-9419-72862192af62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45c8e61e-34ac-4742-9419-72862192af62">
											<gml:posList>35.6715288665259 139.73790286269477 10.7 35.67154188978136 139.73795774789696 10.7 35.67154188978136 139.73795774789696 38.328 35.6715288665259 139.73790286269477 38.328 35.6715288665259 139.73790286269477 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ba12f13-221b-400a-919d-a7fca96e7d87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ba12f13-221b-400a-919d-a7fca96e7d87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ba12f13-221b-400a-919d-a7fca96e7d87">
											<gml:posList>35.671539531049426 139.73793860725894 42.29 35.67153230495546 139.73790816088265 42.29 35.67153230495546 139.73790816088265 38.328 35.671539531049426 139.73793860725894 38.328 35.671539531049426 139.73793860725894 42.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4dd88bb1-e9cf-489f-945d-c5a7712e1cd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4dd88bb1-e9cf-489f-945d-c5a7712e1cd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4dd88bb1-e9cf-489f-945d-c5a7712e1cd9">
											<gml:posList>35.671540871722094 139.73793561208416 42.29 35.671540871722094 139.73793561208416 42.042 35.671534758000504 139.73790981492573 42.042 35.671534758000504 139.73790981492573 42.29 35.671540871722094 139.73793561208416 42.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-478aad74-92aa-44c7-8c40-fed21db7b71e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-478aad74-92aa-44c7-8c40-fed21db7b71e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-478aad74-92aa-44c7-8c40-fed21db7b71e">
											<gml:posList>35.671543057662554 139.73795281980458 38.328 35.671543057662554 139.73795281980458 37.897 35.671539531049426 139.73793860725894 37.897 35.671539531049426 139.73793860725894 38.328 35.671543057662554 139.73795281980458 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6027bc1-ebb4-47e9-ae52-e7a8aba7c6bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6027bc1-ebb4-47e9-ae52-e7a8aba7c6bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6027bc1-ebb4-47e9-ae52-e7a8aba7c6bc">
											<gml:posList>35.67155480588547 139.73790014753908 42.29 35.67155480588547 139.73790014753908 37.897 35.67153230495546 139.73790816088265 37.897 35.67153230495546 139.73790816088265 38.328 35.67153230495546 139.73790816088265 42.29 35.67155480588547 139.73790014753908 42.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d22c46e7-d9e0-4324-9f84-73f2c32a162e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d22c46e7-d9e0-4324-9f84-73f2c32a162e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d22c46e7-d9e0-4324-9f84-73f2c32a162e">
											<gml:posList>35.671534758000504 139.73790981492573 42.29 35.671534758000504 139.73790981492573 42.042 35.67155345619997 139.7379031427257 42.042 35.67155345619997 139.7379031427257 42.29 35.671534758000504 139.73790981492573 42.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee9c1c17-ac36-446c-a14d-f96833722748">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee9c1c17-ac36-446c-a14d-f96833722748">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee9c1c17-ac36-446c-a14d-f96833722748">
											<gml:posList>35.671562946837774 139.73789073734346 10.7 35.6715288665259 139.73790286269477 10.7 35.6715288665259 139.73790286269477 38.328 35.671562946837774 139.73789073734346 38.328 35.671562946837774 139.73789073734346 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-42a40b48-dbbd-465a-aa56-4547c54307f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42a40b48-dbbd-465a-aa56-4547c54307f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42a40b48-dbbd-465a-aa56-4547c54307f6">
											<gml:posList>35.67153171664744 139.73790511277156 38.328 35.67153171664744 139.73790511277156 37.897 35.67156069718136 139.73789550102936 37.897 35.67156069718136 139.73789550102936 38.328 35.67153171664744 139.73790511277156 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a89e3b2c-538d-498e-bdcd-4f1c2bde7a3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a89e3b2c-538d-498e-bdcd-4f1c2bde7a3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a89e3b2c-538d-498e-bdcd-4f1c2bde7a3d">
											<gml:posList>35.67154188978136 139.73795774789696 10.7 35.67155180207374 139.73795420125063 10.7 35.67155180207374 139.73795420125063 38.328 35.67154188978136 139.73795774789696 38.328 35.67154188978136 139.73795774789696 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8df6572-97aa-4833-b7e4-03b527dd04e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8df6572-97aa-4833-b7e4-03b527dd04e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8df6572-97aa-4833-b7e4-03b527dd04e7">
											<gml:posList>35.67155394365535 139.7379495481597 38.328 35.67155394365535 139.7379495481597 37.897 35.671543057662554 139.73795281980458 37.897 35.671543057662554 139.73795281980458 38.328 35.67155394365535 139.7379495481597 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5738421-97b5-4210-840b-8f576e1d5bc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5738421-97b5-4210-840b-8f576e1d5bc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5738421-97b5-4210-840b-8f576e1d5bc2">
											<gml:posList>35.671559587950426 139.7379289398682 42.29 35.671559587950426 139.7379289398682 42.042 35.671540871722094 139.73793561208416 42.042 35.671540871722094 139.73793561208416 42.29 35.671559587950426 139.7379289398682 42.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-626657d1-3720-4f6d-9c04-2af42ac9aa8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-626657d1-3720-4f6d-9c04-2af42ac9aa8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-626657d1-3720-4f6d-9c04-2af42ac9aa8a">
											<gml:posList>35.67156203198146 139.73793059392318 37.897 35.67156203198146 139.73793059392318 42.29 35.671539531049426 139.73793860725894 42.29 35.671539531049426 139.73793860725894 38.328 35.671539531049426 139.73793860725894 37.897 35.67156203198146 139.73793059392318 37.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-428fb4a9-1aff-4666-9f30-243a369fd4e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-428fb4a9-1aff-4666-9f30-243a369fd4e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-428fb4a9-1aff-4666-9f30-243a369fd4e6">
											<gml:posList>35.67155345619997 139.7379031427257 42.29 35.67155345619997 139.7379031427257 42.042 35.671559587950426 139.7379289398682 42.042 35.671559587950426 139.7379289398682 42.29 35.67155345619997 139.7379031427257 42.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ded580e4-a832-4b9a-be44-3024afb41d29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ded580e4-a832-4b9a-be44-3024afb41d29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ded580e4-a832-4b9a-be44-3024afb41d29">
											<gml:posList>35.67155480588547 139.73790014753908 42.29 35.67156203198146 139.73793059392318 42.29 35.67156203198146 139.73793059392318 37.897 35.67155480588547 139.73790014753908 37.897 35.67155480588547 139.73790014753908 42.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b909b3c4-f59f-47d8-8cd0-7271009efcde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b909b3c4-f59f-47d8-8cd0-7271009efcde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b909b3c4-f59f-47d8-8cd0-7271009efcde">
											<gml:posList>35.67155180207374 139.73795420125063 10.7 35.67157495477007 139.73805215548612 10.7 35.67157495477007 139.73805215548612 38.328 35.67155180207374 139.73795420125063 38.328 35.67155180207374 139.73795420125063 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58e0a209-a82e-4774-8b81-b3bf69102c13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58e0a209-a82e-4774-8b81-b3bf69102c13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58e0a209-a82e-4774-8b81-b3bf69102c13">
											<gml:posList>35.67156069718136 139.73789550102936 38.328 35.67156069718136 139.73789550102936 37.897 35.671567574649224 139.73792961524248 37.897 35.671567574649224 139.73792961524248 38.328 35.67156069718136 139.73789550102936 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0bf3bb5-d0b7-437f-8574-64451946aa7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0bf3bb5-d0b7-437f-8574-64451946aa7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0bf3bb5-d0b7-437f-8574-64451946aa7b">
											<gml:posList>35.67157706025686 139.73804744720724 38.328 35.67157706025686 139.73804744720724 37.897 35.67155394365535 139.7379495481597 37.897 35.67155394365535 139.7379495481597 38.328 35.67157706025686 139.73804744720724 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd0a9e34-fb75-469f-baa6-06ba552176ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd0a9e34-fb75-469f-baa6-06ba552176ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd0a9e34-fb75-469f-baa6-06ba552176ce">
											<gml:posList>35.671569842430706 139.73792497304623 10.7 35.671562946837774 139.73789073734346 10.7 35.671562946837774 139.73789073734346 38.328 35.671569842430706 139.73792497304623 38.328 35.671569842430706 139.73792497304623 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdbbabb8-bbc9-4fbe-a904-8adb58576b55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdbbabb8-bbc9-4fbe-a904-8adb58576b55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdbbabb8-bbc9-4fbe-a904-8adb58576b55">
											<gml:posList>35.671567574649224 139.73792961524248 38.328 35.671567574649224 139.73792961524248 37.897 35.67159830381164 139.73791995723812 37.897 35.67159830381164 139.73791995723812 38.328 35.671567574649224 139.73792961524248 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c68af3af-b087-409e-8a1a-4b0f67b48d4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c68af3af-b087-409e-8a1a-4b0f67b48d4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c68af3af-b087-409e-8a1a-4b0f67b48d4c">
											<gml:posList>35.671569842430706 139.73792497304623 10.7 35.671569842430706 139.73792497304623 38.328 35.671600445444426 139.73791537042206 38.328 35.671569842430706 139.73792497304623 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f80288e-4a2b-4829-b6a7-957bf48bbdb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f80288e-4a2b-4829-b6a7-957bf48bbdb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f80288e-4a2b-4829-b6a7-957bf48bbdb5">
											<gml:posList>35.671624477155866 139.73803058923173 38.328 35.671624477155866 139.73803058923173 37.897 35.67157706025686 139.73804744720724 37.897 35.67157706025686 139.73804744720724 38.328 35.671624477155866 139.73803058923173 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e10a5fe9-e919-46c0-b3cd-8d1bee0b4f71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e10a5fe9-e919-46c0-b3cd-8d1bee0b4f71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e10a5fe9-e919-46c0-b3cd-8d1bee0b4f71">
											<gml:posList>35.67164369913284 139.73789996440195 31.325 35.671569842430706 139.73792497304623 10.7 35.671600445444426 139.73791537042206 38.328 35.67164369913284 139.73789996440195 31.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-057e16d4-1491-4c6f-b30b-1b939d32f982">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-057e16d4-1491-4c6f-b30b-1b939d32f982">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-057e16d4-1491-4c6f-b30b-1b939d32f982">
											<gml:posList>35.67164369913284 139.73789996440195 31.325 35.67164369913284 139.73789996440195 10.7 35.671569842430706 139.73792497304623 10.7 35.67164369913284 139.73789996440195 31.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b3abfe0-f36e-4f18-8a68-4cd508a62458">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b3abfe0-f36e-4f18-8a68-4cd508a62458">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b3abfe0-f36e-4f18-8a68-4cd508a62458">
											<gml:posList>35.67159830381164 139.73791995723812 38.328 35.67159830381164 139.73791995723812 37.897 35.671624477155866 139.73803058923173 37.897 35.671624477155866 139.73803058923173 38.328 35.67159830381164 139.73791995723812 38.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db45c155-a956-476f-ad2f-64f6f346c961">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db45c155-a956-476f-ad2f-64f6f346c961">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db45c155-a956-476f-ad2f-64f6f346c961">
											<gml:posList>35.67167164488586 139.7380177966213 31.325 35.671628319063984 139.73803319162258 38.328 35.67157495477007 139.73805215548612 38.328 35.67157495477007 139.73805215548612 10.7 35.67167164488586 139.7380177966213 10.7 35.67167164488586 139.7380177966213 31.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6713e16d-dfc5-44a3-9df1-72bf08772e70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6713e16d-dfc5-44a3-9df1-72bf08772e70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6713e16d-dfc5-44a3-9df1-72bf08772e70">
											<gml:posList>35.67167164488586 139.7380177966213 10.7 35.67164369913284 139.73789996440195 10.7 35.67164369913284 139.73789996440195 31.325 35.67167164488586 139.7380177966213 31.325 35.67167164488586 139.7380177966213 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11203</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">150.25115</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>