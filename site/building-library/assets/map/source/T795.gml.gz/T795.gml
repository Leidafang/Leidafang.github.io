<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e3d57bd2-5958-487e-a33f-f97b750ac0f5">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">17.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670390425637855 139.74363965730788 0 35.670468612758995 139.74332828589777 0 35.67034274558483 139.74328081783557 0 35.670271002050136 139.74356618977683 0 35.67030566959977 139.74357927390736 0 35.670299144999255 139.74360526198794 0 35.670390425637855 139.74363965730788 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670390425637855 139.74363965730788 7.652 35.670299144999255 139.74360526198794 7.652 35.67030566959977 139.74357927390736 7.652 35.670271002050136 139.74356618977683 7.652 35.67034274558483 139.74328081783557 7.652 35.670468612758995 139.74332828589777 7.652 35.670390425637855 139.74363965730788 7.652</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670390425637855 139.74363965730788 7.652 35.670468612758995 139.74332828589777 7.652 35.670468612758995 139.74332828589777 25.41 35.670390425637855 139.74363965730788 25.41 35.670390425637855 139.74363965730788 7.652</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670468612758995 139.74332828589777 7.652 35.67034274558483 139.74328081783557 7.652 35.67034274558483 139.74328081783557 25.41 35.670468612758995 139.74332828589777 25.41 35.670468612758995 139.74332828589777 7.652</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67034274558483 139.74328081783557 7.652 35.670271002050136 139.74356618977683 7.652 35.670271002050136 139.74356618977683 25.41 35.67034274558483 139.74328081783557 25.41 35.67034274558483 139.74328081783557 7.652</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670271002050136 139.74356618977683 7.652 35.67030566959977 139.74357927390736 7.652 35.67030566959977 139.74357927390736 25.41 35.670271002050136 139.74356618977683 25.41 35.670271002050136 139.74356618977683 7.652</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67030566959977 139.74357927390736 7.652 35.670299144999255 139.74360526198794 7.652 35.670299144999255 139.74360526198794 25.41 35.67030566959977 139.74357927390736 25.41 35.67030566959977 139.74357927390736 7.652</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670299144999255 139.74360526198794 7.652 35.670390425637855 139.74363965730788 7.652 35.670390425637855 139.74363965730788 25.41 35.670299144999255 139.74360526198794 25.41 35.670299144999255 139.74360526198794 7.652</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670390425637855 139.74363965730788 25.41 35.670468612758995 139.74332828589777 25.41 35.67034274558483 139.74328081783557 25.41 35.670271002050136 139.74356618977683 25.41 35.67030566959977 139.74357927390736 25.41 35.670299144999255 139.74360526198794 25.41 35.670390425637855 139.74363965730788 25.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fc86a42d-d936-492e-b9bd-7c4cf8dd8ca3"/>
							<gml:surfaceMember xlink:href="#poly-0f19afb7-4bd8-4ef4-b3ec-78ae79f8c7be"/>
							<gml:surfaceMember xlink:href="#poly-f96efa86-7589-4225-8418-ff0db9f27473"/>
							<gml:surfaceMember xlink:href="#poly-dbb4eee7-952d-4941-9bf3-c0999cc73b3b"/>
							<gml:surfaceMember xlink:href="#poly-dff073ac-d2a7-4bee-a38d-e4aef11ce0b4"/>
							<gml:surfaceMember xlink:href="#poly-33332848-3332-4ac7-b520-88ce9586acf8"/>
							<gml:surfaceMember xlink:href="#poly-ea65a0cb-7c6c-4bb8-8804-1f452208e8f7"/>
							<gml:surfaceMember xlink:href="#poly-38586ee8-662d-4182-9ed3-adb0317005ec"/>
							<gml:surfaceMember xlink:href="#poly-4d0a98b0-1b2b-4872-b736-1bdd791e3c70"/>
							<gml:surfaceMember xlink:href="#poly-e0db7fea-2426-47b1-b50e-8c06e36a5608"/>
							<gml:surfaceMember xlink:href="#poly-808fc5eb-048b-495c-be21-1e0c2f07648c"/>
							<gml:surfaceMember xlink:href="#poly-78e4862f-4050-4e92-b217-7b24ce910765"/>
							<gml:surfaceMember xlink:href="#poly-4a336851-f8e0-4c9a-8b1a-5292f6e8e510"/>
							<gml:surfaceMember xlink:href="#poly-8c286b78-b3eb-4778-8fd4-3f67f2fe63ea"/>
							<gml:surfaceMember xlink:href="#poly-3c142e65-df15-4742-8f3e-7acd37e69f9d"/>
							<gml:surfaceMember xlink:href="#poly-0ae4051e-4c5d-4c4b-bf90-9ea4c2d64c02"/>
							<gml:surfaceMember xlink:href="#poly-79e0d772-7475-4f61-a1d2-67a860d067a3"/>
							<gml:surfaceMember xlink:href="#poly-f1adbfd4-56e4-47d7-891e-9cf7590f77c2"/>
							<gml:surfaceMember xlink:href="#poly-61502e67-e701-4794-9ac5-8b3cb4653d9b"/>
							<gml:surfaceMember xlink:href="#poly-60e8a696-7330-4d8c-92df-2eae0533acbe"/>
							<gml:surfaceMember xlink:href="#poly-b57c93f7-4e53-4591-bf7b-65d0e7591322"/>
							<gml:surfaceMember xlink:href="#poly-2c8283bb-bc98-41e5-add5-54dffc1e9942"/>
							<gml:surfaceMember xlink:href="#poly-f2a9ef69-4231-48f0-a50e-a91d90262088"/>
							<gml:surfaceMember xlink:href="#poly-82bdb6a7-88f5-4d01-8d02-581cdcfb60b5"/>
							<gml:surfaceMember xlink:href="#poly-df3d71b6-20c7-4f63-9e3a-1ea47d26e974"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e3d57bd2-5958-487e-a33f-f97b750ac0f5_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09a62ea0-3cf3-4909-a6cd-fb0484eb588e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039364127965 139.74338287231342 24.527 35.67040911304551 139.7433884995965 24.527 35.67040684857562 139.74339785832197 24.527 35.670391367796476 139.74339223104732 24.527 35.67039364127965 139.74338287231342 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61b1bca5-a4fa-43e9-ab5d-da3d6630f362">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670402671375086 139.74341685153337 24.527 35.67038747913495 139.74341135648686 24.527 35.670389752561874 139.7434019204302 24.527 35.670404944802435 139.74340741547508 24.527 35.670402671375086 139.74341685153337 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61b0c55d-1607-4dfa-acd2-33a95bc62c04">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67038322069329 139.74343019513643 24.527 35.67038523331759 139.743421554704 24.527 35.67040046150494 139.74342690611056 24.527 35.67039843986655 139.7434355465546 24.527 35.67038322069329 139.74343019513643 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e2d94cc-221f-4277-b881-3a12c9f0dc24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670393693558694 139.74345288346075 24.527 35.67037719430554 139.74344735673455 24.527 35.670378856286476 139.74343990969237 24.527 35.670395355539966 139.74344543641718 24.527 35.670393693558694 139.74345288346075 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2a3113d-10b2-49dd-9802-f9d3a7737f04">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67038976045367 139.74347285950986 24.527 35.67037230521086 139.74346661584448 24.527 35.67037441683208 139.74345776542427 24.527 35.67039186306162 139.74346400909798 24.527 35.67038976045367 139.74347285950986 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26f8e452-ae53-4a2f-be2a-c41754788fa2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67032290410159 139.74351916300427 24.527 35.67032828534988 139.74349506509935 24.527 35.67035257441941 139.74350321211307 24.527 35.67035067886053 139.74351170880746 24.527 35.67038466912581 139.7435231036082 24.527 35.670382432180894 139.74353312507176 24.527 35.67034844191654 139.7435217302671 24.527 35.670347193169526 139.74352731002475 24.527 35.67032290410159 139.74351916300427 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8de60e10-ff31-4b3a-9bf8-d47fdc91098e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67032155065384 139.74355356254807 24.527 35.67029400623309 139.74354354130563 24.527 35.670298328505396 139.74352566363515 24.527 35.670325881941345 139.7435356848619 24.527 35.67032155065384 139.74355356254807 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a06ed9fb-4c7d-4b7e-974b-7d5c9c3745e4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67038800867973 139.74357745851694 24.527 35.67036382792823 139.7435695101885 24.527 35.670367537962974 139.7435525610751 24.527 35.67039171871557 139.7435605093988 24.527 35.67038800867973 139.74357745851694 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-142c0bee-3e2d-477d-bcaa-5be40e77aee6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-142c0bee-3e2d-477d-bcaa-5be40e77aee6_0">
											<gml:posList>35.67040911304551 139.7433884995965 24.527 35.67039364127965 139.74338287231342 24.527 35.67039364127965 139.74338287231342 27.69 35.67040911304551 139.7433884995965 27.69 35.67040911304551 139.7433884995965 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9c79687-3cac-4a4a-a17b-85f797314163">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9c79687-3cac-4a4a-a17b-85f797314163_0">
											<gml:posList>35.670391367796476 139.74339223104732 24.527 35.670391367796476 139.74339223104732 27.69 35.67039364127965 139.74338287231342 27.69 35.67039364127965 139.74338287231342 24.527 35.670391367796476 139.74339223104732 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b37110bf-fd82-4e4a-a9d8-0828bc90c40c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b37110bf-fd82-4e4a-a9d8-0828bc90c40c_0">
											<gml:posList>35.67040684857562 139.74339785832197 27.69 35.67040911304551 139.7433884995965 27.69 35.67039364127965 139.74338287231342 27.69 35.670391367796476 139.74339223104732 27.69 35.67040684857562 139.74339785832197 27.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b101204-4d6c-48bf-a241-8f58c3995537">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b101204-4d6c-48bf-a241-8f58c3995537_0">
											<gml:posList>35.67040684857562 139.74339785832197 24.527 35.67040911304551 139.7433884995965 24.527 35.67040911304551 139.7433884995965 27.69 35.67040684857562 139.74339785832197 27.69 35.67040684857562 139.74339785832197 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acf064f4-4882-432f-a45b-b80120bf62cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acf064f4-4882-432f-a45b-b80120bf62cb_0">
											<gml:posList>35.670391367796476 139.74339223104732 24.527 35.67040684857562 139.74339785832197 24.527 35.67040684857562 139.74339785832197 27.69 35.670391367796476 139.74339223104732 27.69 35.670391367796476 139.74339223104732 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34807417-5a50-4503-8535-a70f2b9c1897">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34807417-5a50-4503-8535-a70f2b9c1897_0">
											<gml:posList>35.670404944802435 139.74340741547508 24.527 35.670389752561874 139.7434019204302 24.527 35.670389752561874 139.7434019204302 27.69 35.670404944802435 139.74340741547508 27.69 35.670404944802435 139.74340741547508 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-143014c7-d24d-4d43-939a-f4b6ab614456">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-143014c7-d24d-4d43-939a-f4b6ab614456_0">
											<gml:posList>35.670389752561874 139.7434019204302 24.527 35.67038747913495 139.74341135648686 24.527 35.67038747913495 139.74341135648686 27.69 35.670389752561874 139.7434019204302 27.69 35.670389752561874 139.7434019204302 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c44952cc-8b0c-4bdb-a115-55bba7ead78e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c44952cc-8b0c-4bdb-a115-55bba7ead78e_0">
											<gml:posList>35.670402671375086 139.74341685153337 27.69 35.670404944802435 139.74340741547508 27.69 35.670389752561874 139.7434019204302 27.69 35.67038747913495 139.74341135648686 27.69 35.670402671375086 139.74341685153337 27.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9358bf8-d6b8-45e4-b1ab-47f90d2935f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9358bf8-d6b8-45e4-b1ab-47f90d2935f0_0">
											<gml:posList>35.670402671375086 139.74341685153337 24.527 35.670404944802435 139.74340741547508 24.527 35.670404944802435 139.74340741547508 27.69 35.670402671375086 139.74341685153337 27.69 35.670402671375086 139.74341685153337 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f7843a7-8eaf-4ee7-a45f-f895db6a6c96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f7843a7-8eaf-4ee7-a45f-f895db6a6c96_0">
											<gml:posList>35.670402671375086 139.74341685153337 24.527 35.670402671375086 139.74341685153337 27.69 35.67038747913495 139.74341135648686 27.69 35.67038747913495 139.74341135648686 24.527 35.670402671375086 139.74341685153337 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b54b83a4-6a7f-4cb8-936c-3e98ae92edc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b54b83a4-6a7f-4cb8-936c-3e98ae92edc7_0">
											<gml:posList>35.67038523331759 139.743421554704 24.527 35.67038523331759 139.743421554704 27.69 35.67040046150494 139.74342690611056 27.69 35.67040046150494 139.74342690611056 24.527 35.67038523331759 139.743421554704 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61adbfed-0717-48b1-ab28-26af263ad1d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61adbfed-0717-48b1-ab28-26af263ad1d5_0">
											<gml:posList>35.67038523331759 139.743421554704 24.527 35.67038322069329 139.74343019513643 24.527 35.67038322069329 139.74343019513643 27.69 35.67038523331759 139.743421554704 27.69 35.67038523331759 139.743421554704 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-360c2a3d-4860-4b38-8888-4eef54d77ed4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-360c2a3d-4860-4b38-8888-4eef54d77ed4_0">
											<gml:posList>35.67038322069329 139.74343019513643 27.69 35.67039843986655 139.7434355465546 27.69 35.67040046150494 139.74342690611056 27.69 35.67038523331759 139.743421554704 27.69 35.67038322069329 139.74343019513643 27.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ed35ced-4f96-4390-ac47-39f59d39170a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ed35ced-4f96-4390-ac47-39f59d39170a_0">
											<gml:posList>35.67039843986655 139.7434355465546 24.527 35.67040046150494 139.74342690611056 24.527 35.67040046150494 139.74342690611056 27.69 35.67039843986655 139.7434355465546 27.69 35.67039843986655 139.7434355465546 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e84d25e3-b16b-49ee-a2fc-2a481031d01e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e84d25e3-b16b-49ee-a2fc-2a481031d01e_0">
											<gml:posList>35.67039843986655 139.7434355465546 24.527 35.67039843986655 139.7434355465546 27.69 35.67038322069329 139.74343019513643 27.69 35.67038322069329 139.74343019513643 24.527 35.67039843986655 139.7434355465546 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c0640e7-c550-41c7-ac08-23d410509874">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c0640e7-c550-41c7-ac08-23d410509874_0">
											<gml:posList>35.670378856286476 139.74343990969237 24.527 35.670378856286476 139.74343990969237 27.69 35.670395355539966 139.74344543641718 27.69 35.670395355539966 139.74344543641718 24.527 35.670378856286476 139.74343990969237 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08206e56-28d0-48f3-8146-82f9741f5874">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08206e56-28d0-48f3-8146-82f9741f5874_0">
											<gml:posList>35.670378856286476 139.74343990969237 24.527 35.67037719430554 139.74344735673455 24.527 35.67037719430554 139.74344735673455 27.69 35.670378856286476 139.74343990969237 27.69 35.670378856286476 139.74343990969237 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d81c733e-47c8-4d13-bc81-31b3bc887ffa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d81c733e-47c8-4d13-bc81-31b3bc887ffa_0">
											<gml:posList>35.670393693558694 139.74345288346075 27.69 35.670395355539966 139.74344543641718 27.69 35.670378856286476 139.74343990969237 27.69 35.67037719430554 139.74344735673455 27.69 35.670393693558694 139.74345288346075 27.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd345587-bda4-49ee-98d3-fd6dd3e1bfc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd345587-bda4-49ee-98d3-fd6dd3e1bfc9_0">
											<gml:posList>35.670393693558694 139.74345288346075 24.527 35.670395355539966 139.74344543641718 24.527 35.670395355539966 139.74344543641718 27.69 35.670393693558694 139.74345288346075 27.69 35.670393693558694 139.74345288346075 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebfd6d6e-a3ee-4354-b467-f6b5f6d8a9ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebfd6d6e-a3ee-4354-b467-f6b5f6d8a9ea_0">
											<gml:posList>35.670393693558694 139.74345288346075 24.527 35.670393693558694 139.74345288346075 27.69 35.67037719430554 139.74344735673455 27.69 35.67037719430554 139.74344735673455 24.527 35.670393693558694 139.74345288346075 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2778a236-7666-4a3b-8906-86d71fa8d83d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2778a236-7666-4a3b-8906-86d71fa8d83d_0">
											<gml:posList>35.67039186306162 139.74346400909798 24.527 35.67037441683208 139.74345776542427 24.527 35.67037441683208 139.74345776542427 27.759 35.67039186306162 139.74346400909798 27.759 35.67039186306162 139.74346400909798 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f37d110-39f7-49d4-9ef0-45044950e1f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f37d110-39f7-49d4-9ef0-45044950e1f0_0">
											<gml:posList>35.67037441683208 139.74345776542427 24.527 35.67037230521086 139.74346661584448 24.527 35.67037230521086 139.74346661584448 27.759 35.67037441683208 139.74345776542427 27.759 35.67037441683208 139.74345776542427 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f573dd61-3ea0-4223-be8b-a62ac73aca3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f573dd61-3ea0-4223-be8b-a62ac73aca3f_0">
											<gml:posList>35.67038976045367 139.74347285950986 27.759 35.67039186306162 139.74346400909798 27.759 35.67037441683208 139.74345776542427 27.759 35.67037230521086 139.74346661584448 27.759 35.67038976045367 139.74347285950986 27.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e88c5534-e2b4-4885-97ac-b45c7d85dc83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e88c5534-e2b4-4885-97ac-b45c7d85dc83_0">
											<gml:posList>35.67038976045367 139.74347285950986 24.527 35.67039186306162 139.74346400909798 24.527 35.67039186306162 139.74346400909798 27.759 35.67038976045367 139.74347285950986 27.759 35.67038976045367 139.74347285950986 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a986e391-935d-47d8-b034-db2f95c9f864">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a986e391-935d-47d8-b034-db2f95c9f864_0">
											<gml:posList>35.67038976045367 139.74347285950986 24.527 35.67038976045367 139.74347285950986 27.759 35.67037230521086 139.74346661584448 27.759 35.67037230521086 139.74346661584448 24.527 35.67038976045367 139.74347285950986 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7295a8c9-9a9b-4055-8876-639309e58429">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7295a8c9-9a9b-4055-8876-639309e58429_0">
											<gml:posList>35.67035257441941 139.74350321211307 24.527 35.67032828534988 139.74349506509935 24.527 35.67032828534988 139.74349506509935 28.212 35.67035257441941 139.74350321211307 28.212 35.67035257441941 139.74350321211307 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61c4c0ee-3434-475c-bd46-6d229ad79c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61c4c0ee-3434-475c-bd46-6d229ad79c7c_0">
											<gml:posList>35.67032290410159 139.74351916300427 24.527 35.67032290410159 139.74351916300427 28.212 35.67032828534988 139.74349506509935 28.212 35.67032828534988 139.74349506509935 24.527 35.67032290410159 139.74351916300427 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0200e49-87e3-42e0-8c71-ea015d56929a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0200e49-87e3-42e0-8c71-ea015d56929a_0">
											<gml:posList>35.67035257441941 139.74350321211307 28.212 35.67032828534988 139.74349506509935 28.212 35.67032290410159 139.74351916300427 28.212 35.670347193169526 139.74352731002475 28.212 35.67035257441941 139.74350321211307 28.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0704d9de-2ae2-4be9-8100-8f622cd67d87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0704d9de-2ae2-4be9-8100-8f622cd67d87_0">
											<gml:posList>35.67034844191654 139.7435217302671 27.301 35.67035067886053 139.74351170880746 27.301 35.67035067886053 139.74351170880746 24.527 35.67035257441941 139.74350321211307 24.527 35.67035257441941 139.74350321211307 28.212 35.670347193169526 139.74352731002475 28.212 35.670347193169526 139.74352731002475 24.527 35.67034844191654 139.7435217302671 24.527 35.67034844191654 139.7435217302671 27.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8efceced-5e0c-4224-90c7-3cc95355c8c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8efceced-5e0c-4224-90c7-3cc95355c8c6_0">
											<gml:posList>35.67038466912581 139.7435231036082 24.527 35.67035067886053 139.74351170880746 24.527 35.67035067886053 139.74351170880746 27.301 35.67038466912581 139.7435231036082 27.301 35.67038466912581 139.7435231036082 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d52deca7-f489-439d-b94d-4e7003ae9a99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d52deca7-f489-439d-b94d-4e7003ae9a99_0">
											<gml:posList>35.67034844191654 139.7435217302671 27.301 35.670382432180894 139.74353312507176 27.301 35.67038466912581 139.7435231036082 27.301 35.67035067886053 139.74351170880746 27.301 35.67034844191654 139.7435217302671 27.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85f65b03-6d9b-4b94-b80f-47ac2e086954">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85f65b03-6d9b-4b94-b80f-47ac2e086954_0">
											<gml:posList>35.670347193169526 139.74352731002475 24.527 35.670347193169526 139.74352731002475 28.212 35.67032290410159 139.74351916300427 28.212 35.67032290410159 139.74351916300427 24.527 35.670347193169526 139.74352731002475 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cb115c4-2aa5-4c96-b0c8-f2abe5cf3e10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cb115c4-2aa5-4c96-b0c8-f2abe5cf3e10_0">
											<gml:posList>35.670382432180894 139.74353312507176 27.301 35.67034844191654 139.7435217302671 27.301 35.67034844191654 139.7435217302671 24.527 35.670382432180894 139.74353312507176 24.527 35.670382432180894 139.74353312507176 27.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba5f94f8-aa08-4cb9-bdb0-d93a59d9ab0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba5f94f8-aa08-4cb9-bdb0-d93a59d9ab0b_0">
											<gml:posList>35.670382432180894 139.74353312507176 24.527 35.67038466912581 139.7435231036082 24.527 35.67038466912581 139.7435231036082 27.301 35.670382432180894 139.74353312507176 27.301 35.670382432180894 139.74353312507176 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88e5a458-5395-47f4-9581-93ed3ca8d99b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88e5a458-5395-47f4-9581-93ed3ca8d99b_0">
											<gml:posList>35.670325881941345 139.7435356848619 24.527 35.670298328505396 139.74352566363515 24.527 35.670298328505396 139.74352566363515 27.226 35.670325881941345 139.7435356848619 27.226 35.670325881941345 139.7435356848619 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93d03f61-7e7d-44bd-8cc7-9916ab9b2eb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93d03f61-7e7d-44bd-8cc7-9916ab9b2eb8_0">
											<gml:posList>35.67029400623309 139.74354354130563 27.226 35.670298328505396 139.74352566363515 27.226 35.670298328505396 139.74352566363515 24.527 35.67029400623309 139.74354354130563 24.527 35.67029400623309 139.74354354130563 27.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-835d6206-439d-413d-a8ad-b6abf3446658">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-835d6206-439d-413d-a8ad-b6abf3446658_0">
											<gml:posList>35.670298328505396 139.74352566363515 27.226 35.67029400623309 139.74354354130563 27.226 35.67032155065384 139.74355356254807 27.226 35.670325881941345 139.7435356848619 27.226 35.670298328505396 139.74352566363515 27.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-387be17d-568f-4297-9aef-cea74d9b9129">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-387be17d-568f-4297-9aef-cea74d9b9129_0">
											<gml:posList>35.67032155065384 139.74355356254807 24.527 35.670325881941345 139.7435356848619 24.527 35.670325881941345 139.7435356848619 27.226 35.67032155065384 139.74355356254807 27.226 35.67032155065384 139.74355356254807 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62fe6a9a-8749-43f3-8b60-04c1c78fbd11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62fe6a9a-8749-43f3-8b60-04c1c78fbd11_0">
											<gml:posList>35.67032155065384 139.74355356254807 24.527 35.67032155065384 139.74355356254807 27.226 35.67029400623309 139.74354354130563 27.226 35.67029400623309 139.74354354130563 24.527 35.67032155065384 139.74355356254807 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fad5bb9d-1e4d-47a8-a3e3-ce4f7eae38e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fad5bb9d-1e4d-47a8-a3e3-ce4f7eae38e0_0">
											<gml:posList>35.67039171871557 139.7435605093988 24.527 35.670367537962974 139.7435525610751 24.527 35.670367537962974 139.7435525610751 27.226 35.67039171871557 139.7435605093988 27.226 35.67039171871557 139.7435605093988 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7206348e-2be1-44b6-9e92-c8a905fc8eb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7206348e-2be1-44b6-9e92-c8a905fc8eb6_0">
											<gml:posList>35.67036382792823 139.7435695101885 24.527 35.67036382792823 139.7435695101885 27.226 35.670367537962974 139.7435525610751 27.226 35.670367537962974 139.7435525610751 24.527 35.67036382792823 139.7435695101885 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ade75c77-a886-4f31-927a-2d60f37ea6dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ade75c77-a886-4f31-927a-2d60f37ea6dd_0">
											<gml:posList>35.670367537962974 139.7435525610751 27.226 35.67036382792823 139.7435695101885 27.226 35.67038800867973 139.74357745851694 27.226 35.67039171871557 139.7435605093988 27.226 35.670367537962974 139.7435525610751 27.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58b1cceb-0c7c-411f-acbe-c5f7077ea46c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58b1cceb-0c7c-411f-acbe-c5f7077ea46c_0">
											<gml:posList>35.67039171871557 139.7435605093988 24.527 35.67039171871557 139.7435605093988 27.226 35.67038800867973 139.74357745851694 27.226 35.67038800867973 139.74357745851694 24.527 35.67039171871557 139.7435605093988 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a727c56f-ffdd-46b1-b71a-1e392fd155c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a727c56f-ffdd-46b1-b71a-1e392fd155c1_0">
											<gml:posList>35.67038800867973 139.74357745851694 27.226 35.67036382792823 139.7435695101885 27.226 35.67036382792823 139.7435695101885 24.527 35.67038800867973 139.74357745851694 24.527 35.67038800867973 139.74357745851694 27.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e3d57bd2-5958-487e-a33f-f97b750ac0f5_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7dcbe5d2-28ca-4bcb-aaea-00ec275c2a30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67043783934883 139.7433637568699 24.527 35.67034899349381 139.7433309055865 24.527 35.67030081697692 139.74352657768648 24.527 35.670299185048066 139.74352598301698 24.527 35.67034805350702 139.74332748230253 24.527 35.67044080338642 139.74336177626188 24.527 35.67039171871557 139.7435605093988 24.527 35.67038956390859 139.74355980485078 24.527 35.67043783934883 139.7433637568699 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9199e63a-5ee0-4dc3-bfa9-5d5465f356e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9199e63a-5ee0-4dc3-bfa9-5d5465f356e1_0">
											<gml:posList>35.67034805350702 139.74332748230253 24.527 35.67034805350702 139.74332748230253 26.698 35.67044080338642 139.74336177626188 26.698 35.67044080338642 139.74336177626188 24.527 35.67034805350702 139.74332748230253 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d68ad075-7681-4257-8b2d-a789b70ce70b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d68ad075-7681-4257-8b2d-a789b70ce70b_0">
											<gml:posList>35.67043783934883 139.7433637568699 24.527 35.67043783934883 139.7433637568699 26.698 35.67034899349381 139.7433309055865 26.698 35.67034899349381 139.7433309055865 24.527 35.67043783934883 139.7433637568699 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b79048b-656b-49fe-ab72-cc360a84ba9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b79048b-656b-49fe-ab72-cc360a84ba9d_0">
											<gml:posList>35.670299185048066 139.74352598301698 26.698 35.67034805350702 139.74332748230253 26.698 35.67034805350702 139.74332748230253 24.527 35.670299185048066 139.74352598301698 24.527 35.670299185048066 139.74352598301698 26.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0f69d44-b4a2-4f1b-a522-95ba459e89c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0f69d44-b4a2-4f1b-a522-95ba459e89c4_0">
											<gml:posList>35.67034899349381 139.7433309055865 26.698 35.67030081697692 139.74352657768648 26.698 35.67030081697692 139.74352657768648 24.527 35.67034899349381 139.7433309055865 24.527 35.67034899349381 139.7433309055865 26.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0891b491-f085-4045-9259-06cfb8b675b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0891b491-f085-4045-9259-06cfb8b675b6_0">
											<gml:posList>35.67039171871557 139.7435605093988 26.698 35.67044080338642 139.74336177626188 26.698 35.67034805350702 139.74332748230253 26.698 35.670299185048066 139.74352598301698 26.698 35.67030081697692 139.74352657768648 26.698 35.67034899349381 139.7433309055865 26.698 35.67043783934883 139.7433637568699 26.698 35.67038956390859 139.74355980485078 26.698 35.67039171871557 139.7435605093988 26.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47bce590-900e-4f17-8334-4d622d06c9dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47bce590-900e-4f17-8334-4d622d06c9dc_0">
											<gml:posList>35.67044080338642 139.74336177626188 24.527 35.67044080338642 139.74336177626188 26.698 35.67039171871557 139.7435605093988 26.698 35.67039171871557 139.7435605093988 24.527 35.67044080338642 139.74336177626188 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ae49f03-4619-4789-b168-81b75eca6f98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ae49f03-4619-4789-b168-81b75eca6f98_0">
											<gml:posList>35.67038956390859 139.74355980485078 26.698 35.67043783934883 139.7433637568699 26.698 35.67043783934883 139.7433637568699 24.527 35.67038956390859 139.74355980485078 24.527 35.67038956390859 139.74355980485078 26.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52a1c7c8-788b-4df1-8116-17b82f731e05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52a1c7c8-788b-4df1-8116-17b82f731e05_0">
											<gml:posList>35.67030081697692 139.74352657768648 24.527 35.67030081697692 139.74352657768648 26.698 35.670299185048066 139.74352598301698 26.698 35.670299185048066 139.74352598301698 24.527 35.67030081697692 139.74352657768648 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dae95fc9-6e42-45a3-b880-f8ffcba88e78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dae95fc9-6e42-45a3-b880-f8ffcba88e78_0">
											<gml:posList>35.67039171871557 139.7435605093988 24.527 35.67039171871557 139.7435605093988 26.698 35.67038956390859 139.74355980485078 26.698 35.67038956390859 139.74355980485078 24.527 35.67039171871557 139.7435605093988 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e3d57bd2-5958-487e-a33f-f97b750ac0f5_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1d909e4-e89c-44a0-a1e1-42534b80e345">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67026446844689 139.74359218890348 7.72 35.670271002041886 139.74356617873053 7.72 35.67030566959975 139.74357927390736 7.72 35.670299144999234 139.74360526198794 7.72 35.67026446844689 139.74359218890348 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70a095a4-bac8-4b92-ae5f-d58e49eefa04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70a095a4-bac8-4b92-ae5f-d58e49eefa04_0">
											<gml:posList>35.670271002041886 139.74356617873053 24.063 35.670271002041886 139.74356617873053 7.72 35.67026446844689 139.74359218890348 7.72 35.67026446844689 139.74359218890348 24.063 35.670267604924845 139.74357969209066 24.063 35.670271002041886 139.74356617873053 24.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5968b8d-7a07-409c-92e8-073c1f2aca48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5968b8d-7a07-409c-92e8-073c1f2aca48_0">
											<gml:posList>35.670267604924845 139.74357969209066 24.063 35.67026446844689 139.74359218890348 24.063 35.670271861783064 139.74359497532825 24.063 35.67027498908292 139.74358225759977 24.063 35.670267604924845 139.74357969209066 24.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dc0e16e-6494-46e1-af02-d053ad06328f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2dc0e16e-6494-46e1-af02-d053ad06328f_0">
											<gml:posList>35.67027826916182 139.7435689321557 24.063 35.670271002041886 139.74356617873053 24.063 35.670267604924845 139.74357969209066 24.063 35.67027498908292 139.74358225759977 24.063 35.67027826916182 139.7435689321557 24.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d589251-3353-4009-801f-02135aea511a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d589251-3353-4009-801f-02135aea511a_0">
											<gml:posList>35.67026446844689 139.74359218890348 24.063 35.67026446844689 139.74359218890348 7.72 35.670299144999234 139.74360526198794 7.72 35.670299144999234 139.74360526198794 23.22 35.670271861783064 139.74359497532825 24.063 35.67026446844689 139.74359218890348 24.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-390e4593-bf13-4ae3-91cc-32b53642b12f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-390e4593-bf13-4ae3-91cc-32b53642b12f_0">
											<gml:posList>35.670299144999234 139.74360526198794 23.22 35.67030252414931 139.74359182596743 23.22 35.67027498908292 139.74358225759977 24.063 35.670271861783064 139.74359497532825 24.063 35.670299144999234 139.74360526198794 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88cb9881-54fc-4bcb-b123-3dbb2111b092">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88cb9881-54fc-4bcb-b123-3dbb2111b092_0">
											<gml:posList>35.67030566959975 139.74357927390736 25.547 35.67030566959975 139.74357927390736 7.72 35.670271002041886 139.74356617873053 7.72 35.670271002041886 139.74356617873053 24.063 35.67027826916182 139.7435689321557 24.063 35.67030566959975 139.74357927390736 25.547</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71901d73-4485-48db-a929-9804d9a24680">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71901d73-4485-48db-a929-9804d9a24680_0">
											<gml:posList>35.67030252414931 139.74359182596743 23.22 35.67030252414931 139.74359182596743 25.547 35.67027498908292 139.74358225759977 24.063 35.67030252414931 139.74359182596743 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c922eed9-5fa1-4573-95bc-c0c4b283e7fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c922eed9-5fa1-4573-95bc-c0c4b283e7fb_0">
											<gml:posList>35.67030252414931 139.74359182596743 25.547 35.67030566959975 139.74357927390736 25.547 35.67027826916182 139.7435689321557 24.063 35.67027498908292 139.74358225759977 24.063 35.67030252414931 139.74359182596743 25.547</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6dc8d9a-156d-4161-82bf-b902ede3b901">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6dc8d9a-156d-4161-82bf-b902ede3b901_0">
											<gml:posList>35.670299144999234 139.74360526198794 23.22 35.670299144999234 139.74360526198794 7.72 35.67030566959975 139.74357927390736 7.72 35.67030566959975 139.74357927390736 25.547 35.67030252414931 139.74359182596743 25.547 35.67030252414931 139.74359182596743 23.22 35.670299144999234 139.74360526198794 23.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fc86a42d-d936-492e-b9bd-7c4cf8dd8ca3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc86a42d-d936-492e-b9bd-7c4cf8dd8ca3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc86a42d-d936-492e-b9bd-7c4cf8dd8ca3">
											<gml:posList>35.670468612758995 139.74332828589775 7.652 35.67039042563784 139.74363965730788 7.652 35.670299144999234 139.74360526198794 7.652 35.67030566959975 139.74357927390736 7.652 35.67027100205012 139.7435661897768 7.652 35.67034274558481 139.74328081783554 7.652 35.670468612758995 139.74332828589775 7.652</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0f19afb7-4bd8-4ef4-b3ec-78ae79f8c7be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f19afb7-4bd8-4ef4-b3ec-78ae79f8c7be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f19afb7-4bd8-4ef4-b3ec-78ae79f8c7be">
											<gml:posList>35.67030455900151 139.74357671242075 25.7 35.67030566959975 139.74357927390736 25.7 35.67030616388894 139.7435773071216 25.7 35.67030455900151 139.74357671242075 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f96efa86-7589-4225-8418-ff0db9f27473">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f96efa86-7589-4225-8418-ff0db9f27473">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f96efa86-7589-4225-8418-ff0db9f27473">
											<gml:posList>35.67030566959975 139.74357927390736 25.7 35.67030455900151 139.74357671242075 25.7 35.67027309222934 139.74356483979474 25.7 35.67027100205012 139.7435661897768 25.7 35.67030566959975 139.74357927390736 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbb4eee7-952d-4941-9bf3-c0999cc73b3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbb4eee7-952d-4941-9bf3-c0999cc73b3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbb4eee7-952d-4941-9bf3-c0999cc73b3b">
											<gml:posList>35.67027100205012 139.7435661897768 25.7 35.67027309222934 139.74356483979474 25.7 35.67034384718387 139.7432833903756 25.7 35.67034274558481 139.74328081783554 25.7 35.67027100205012 139.7435661897768 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dff073ac-d2a7-4bee-a38d-e4aef11ce0b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dff073ac-d2a7-4bee-a38d-e4aef11ce0b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dff073ac-d2a7-4bee-a38d-e4aef11ce0b4">
											<gml:posList>35.67034913858217 139.7436219632089 24.527 35.67038931504089 139.74363709581775 24.527 35.67046651357704 139.74332964694565 24.527 35.67034384718387 139.7432833903756 24.527 35.67027309222934 139.74356483979474 24.527 35.67030455900151 139.74357671242075 24.527 35.67030616388894 139.7435773071216 24.527 35.67031056752037 139.74355973865414 24.527 35.67035847093016 139.74357778983233 24.527 35.67034754270046 139.7436213574505 24.527 35.67034913858217 139.7436219632089 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33332848-3332-4ac7-b520-88ce9586acf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33332848-3332-4ac7-b520-88ce9586acf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33332848-3332-4ac7-b520-88ce9586acf8">
											<gml:posList>35.67034274558481 139.74328081783554 25.7 35.67034384718387 139.7432833903756 25.7 35.67046651357704 139.74332964694565 25.7 35.670468612758995 139.74332828589775 25.7 35.67034274558481 139.74328081783554 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea65a0cb-7c6c-4bb8-8804-1f452208e8f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea65a0cb-7c6c-4bb8-8804-1f452208e8f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea65a0cb-7c6c-4bb8-8804-1f452208e8f7">
											<gml:posList>35.670468612758995 139.74332828589775 25.7 35.67046651357704 139.74332964694565 25.7 35.67038931504089 139.74363709581775 25.7 35.67039042563784 139.74363965730788 25.7 35.670468612758995 139.74332828589775 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38586ee8-662d-4182-9ed3-adb0317005ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38586ee8-662d-4182-9ed3-adb0317005ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38586ee8-662d-4182-9ed3-adb0317005ec">
											<gml:posList>35.67035847093016 139.74357778983233 30.047 35.67031056752037 139.74355973865414 30.047 35.670299144999234 139.74360526198794 30.047 35.670347048402334 139.74362331319074 30.047 35.67035847093016 139.74357778983233 30.047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d0a98b0-1b2b-4872-b736-1bdd791e3c70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d0a98b0-1b2b-4872-b736-1bdd791e3c70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d0a98b0-1b2b-4872-b736-1bdd791e3c70">
											<gml:posList>35.67034754270046 139.7436213574505 25.7 35.670347048402334 139.74362331319074 25.7 35.67034913858217 139.7436219632089 25.7 35.67034754270046 139.7436213574505 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e0db7fea-2426-47b1-b50e-8c06e36a5608">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0db7fea-2426-47b1-b50e-8c06e36a5608">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0db7fea-2426-47b1-b50e-8c06e36a5608">
											<gml:posList>35.67039042563784 139.74363965730788 25.7 35.67038931504089 139.74363709581775 25.7 35.67034913858217 139.7436219632089 25.7 35.670347048402334 139.74362331319074 25.7 35.67039042563784 139.74363965730788 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-808fc5eb-048b-495c-be21-1e0c2f07648c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-808fc5eb-048b-495c-be21-1e0c2f07648c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-808fc5eb-048b-495c-be21-1e0c2f07648c">
											<gml:posList>35.670468612758995 139.74332828589775 7.652 35.67034274558481 139.74328081783554 7.652 35.67034274558481 139.74328081783554 25.7 35.670468612758995 139.74332828589775 25.7 35.670468612758995 139.74332828589775 7.652</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78e4862f-4050-4e92-b217-7b24ce910765">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78e4862f-4050-4e92-b217-7b24ce910765">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78e4862f-4050-4e92-b217-7b24ce910765">
											<gml:posList>35.67034384718387 139.7432833903756 25.7 35.67034384718387 139.7432833903756 24.527 35.67046651357704 139.74332964694565 24.527 35.67046651357704 139.74332964694565 25.7 35.67034384718387 139.7432833903756 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a336851-f8e0-4c9a-8b1a-5292f6e8e510">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a336851-f8e0-4c9a-8b1a-5292f6e8e510">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a336851-f8e0-4c9a-8b1a-5292f6e8e510">
											<gml:posList>35.67034274558481 139.74328081783554 7.652 35.67027100205012 139.7435661897768 7.652 35.67027100205012 139.7435661897768 25.7 35.67034274558481 139.74328081783554 25.7 35.67034274558481 139.74328081783554 7.652</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c286b78-b3eb-4778-8fd4-3f67f2fe63ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c286b78-b3eb-4778-8fd4-3f67f2fe63ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c286b78-b3eb-4778-8fd4-3f67f2fe63ea">
											<gml:posList>35.67027309222934 139.74356483979474 25.7 35.67027309222934 139.74356483979474 24.527 35.67034384718387 139.7432833903756 24.527 35.67034384718387 139.7432833903756 25.7 35.67027309222934 139.74356483979474 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c142e65-df15-4742-8f3e-7acd37e69f9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c142e65-df15-4742-8f3e-7acd37e69f9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c142e65-df15-4742-8f3e-7acd37e69f9d">
											<gml:posList>35.67046651357704 139.74332964694565 25.7 35.67046651357704 139.74332964694565 24.527 35.67038931504089 139.74363709581775 24.527 35.67038931504089 139.74363709581775 25.7 35.67046651357704 139.74332964694565 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ae4051e-4c5d-4c4b-bf90-9ea4c2d64c02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ae4051e-4c5d-4c4b-bf90-9ea4c2d64c02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ae4051e-4c5d-4c4b-bf90-9ea4c2d64c02">
											<gml:posList>35.67039042563784 139.74363965730788 7.652 35.670468612758995 139.74332828589775 7.652 35.670468612758995 139.74332828589775 25.7 35.67039042563784 139.74363965730788 25.7 35.67039042563784 139.74363965730788 7.652</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79e0d772-7475-4f61-a1d2-67a860d067a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79e0d772-7475-4f61-a1d2-67a860d067a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79e0d772-7475-4f61-a1d2-67a860d067a3">
											<gml:posList>35.67031056752037 139.74355973865414 30.047 35.67035847093016 139.74357778983233 30.047 35.67035847093016 139.74357778983233 24.527 35.67031056752037 139.74355973865414 24.527 35.67031056752037 139.74355973865414 30.047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1adbfd4-56e4-47d7-891e-9cf7590f77c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1adbfd4-56e4-47d7-891e-9cf7590f77c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1adbfd4-56e4-47d7-891e-9cf7590f77c2">
											<gml:posList>35.67030455900151 139.74357671242075 25.7 35.67030455900151 139.74357671242075 24.527 35.67027309222934 139.74356483979474 24.527 35.67027309222934 139.74356483979474 25.7 35.67030455900151 139.74357671242075 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61502e67-e701-4794-9ac5-8b3cb4653d9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61502e67-e701-4794-9ac5-8b3cb4653d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61502e67-e701-4794-9ac5-8b3cb4653d9b">
											<gml:posList>35.67027100205012 139.7435661897768 7.652 35.67030566959975 139.74357927390736 7.652 35.67030566959975 139.74357927390736 25.7 35.67027100205012 139.7435661897768 25.7 35.67027100205012 139.7435661897768 7.652</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60e8a696-7330-4d8c-92df-2eae0533acbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60e8a696-7330-4d8c-92df-2eae0533acbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60e8a696-7330-4d8c-92df-2eae0533acbe">
											<gml:posList>35.67030616388894 139.7435773071216 25.7 35.67030616388894 139.7435773071216 24.527 35.67030455900151 139.74357671242075 24.527 35.67030455900151 139.74357671242075 25.7 35.67030616388894 139.7435773071216 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b57c93f7-4e53-4591-bf7b-65d0e7591322">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b57c93f7-4e53-4591-bf7b-65d0e7591322">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b57c93f7-4e53-4591-bf7b-65d0e7591322">
											<gml:posList>35.67030566959975 139.74357927390736 25.7 35.67030566959975 139.74357927390736 7.652 35.670299144999234 139.74360526198794 7.652 35.670299144999234 139.74360526198794 30.047 35.67031056752037 139.74355973865414 30.047 35.67031056752037 139.74355973865414 24.527 35.67030616388894 139.7435773071216 24.527 35.67030616388894 139.7435773071216 25.7 35.67030566959975 139.74357927390736 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c8283bb-bc98-41e5-add5-54dffc1e9942">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c8283bb-bc98-41e5-add5-54dffc1e9942">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c8283bb-bc98-41e5-add5-54dffc1e9942">
											<gml:posList>35.67035847093016 139.74357778983233 24.527 35.67035847093016 139.74357778983233 30.047 35.670347048402334 139.74362331319074 30.047 35.670347048402334 139.74362331319074 25.7 35.67034754270046 139.7436213574505 25.7 35.67034754270046 139.7436213574505 24.527 35.67035847093016 139.74357778983233 24.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2a9ef69-4231-48f0-a50e-a91d90262088">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2a9ef69-4231-48f0-a50e-a91d90262088">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2a9ef69-4231-48f0-a50e-a91d90262088">
											<gml:posList>35.67034913858217 139.7436219632089 25.7 35.67034913858217 139.7436219632089 24.527 35.67034754270046 139.7436213574505 24.527 35.67034754270046 139.7436213574505 25.7 35.67034913858217 139.7436219632089 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82bdb6a7-88f5-4d01-8d02-581cdcfb60b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82bdb6a7-88f5-4d01-8d02-581cdcfb60b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82bdb6a7-88f5-4d01-8d02-581cdcfb60b5">
											<gml:posList>35.67039042563784 139.74363965730788 7.652 35.67039042563784 139.74363965730788 25.7 35.670347048402334 139.74362331319074 25.7 35.670347048402334 139.74362331319074 30.047 35.670299144999234 139.74360526198794 30.047 35.670299144999234 139.74360526198794 7.652 35.67039042563784 139.74363965730788 7.652</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df3d71b6-20c7-4f63-9e3a-1ea47d26e974">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df3d71b6-20c7-4f63-9e3a-1ea47d26e974">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df3d71b6-20c7-4f63-9e3a-1ea47d26e974">
											<gml:posList>35.67038931504089 139.74363709581775 25.7 35.67038931504089 139.74363709581775 24.527 35.67034913858217 139.7436219632089 24.527 35.67034913858217 139.7436219632089 25.7 35.67038931504089 139.74363709581775 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10172</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">431.05225</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>