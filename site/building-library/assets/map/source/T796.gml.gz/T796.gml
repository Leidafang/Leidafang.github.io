<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e42727e4-af1f-43b7-bc9f-1965eabaa8aa">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">36.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67437514752422 139.73890706511438 0 35.674359690116816 139.7388510539133 0 35.674278692089175 139.7388846322163 0 35.674277200579915 139.7388792210434 0 35.674118882248216 139.73894657196686 0 35.673913524453816 139.73906406391427 0 35.67388535115192 139.73908018110026 0 35.67394052121421 139.73913400228213 0 35.6739710830264 139.73916380365355 0 35.67401824275653 139.73920981324807 0 35.67405105970536 139.73924182138336 0 35.67409673955785 139.73913588446504 0 35.67416399546201 139.73907252947808 0 35.67416783230439 139.73906869173362 0 35.67426475136846 139.738981087157 0 35.67425896761298 139.73896198301108 0 35.67429573136721 139.7389463637465 0 35.67429414948107 139.73894064336733 0 35.67437514752422 139.73890706511438 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67437514752422 139.73890706511438 8.12 35.67429414948107 139.73894064336733 8.12 35.67429573136721 139.7389463637465 8.12 35.67425896761298 139.73896198301108 8.12 35.67426475136846 139.738981087157 8.12 35.67416783230439 139.73906869173362 8.12 35.67416399546201 139.73907252947808 8.12 35.67409673955785 139.73913588446504 8.12 35.67405105970536 139.73924182138336 8.12 35.67401824275653 139.73920981324807 8.12 35.6739710830264 139.73916380365355 8.12 35.67394052121421 139.73913400228213 8.12 35.67388535115192 139.73908018110026 8.12 35.673913524453816 139.73906406391427 8.12 35.674118882248216 139.73894657196686 8.12 35.674277200579915 139.7388792210434 8.12 35.674278692089175 139.7388846322163 8.12 35.674359690116816 139.7388510539133 8.12 35.67437514752422 139.73890706511438 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67437514752422 139.73890706511438 8.12 35.674359690116816 139.7388510539133 8.12 35.674359690116816 139.7388510539133 40.63 35.67437514752422 139.73890706511438 40.63 35.67437514752422 139.73890706511438 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674359690116816 139.7388510539133 8.12 35.674278692089175 139.7388846322163 8.12 35.674278692089175 139.7388846322163 40.63 35.674359690116816 139.7388510539133 40.63 35.674359690116816 139.7388510539133 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674278692089175 139.7388846322163 8.12 35.674277200579915 139.7388792210434 8.12 35.674277200579915 139.7388792210434 40.63 35.674278692089175 139.7388846322163 40.63 35.674278692089175 139.7388846322163 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674277200579915 139.7388792210434 8.12 35.674118882248216 139.73894657196686 8.12 35.674118882248216 139.73894657196686 40.63 35.674277200579915 139.7388792210434 40.63 35.674277200579915 139.7388792210434 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674118882248216 139.73894657196686 8.12 35.673913524453816 139.73906406391427 8.12 35.673913524453816 139.73906406391427 40.63 35.674118882248216 139.73894657196686 40.63 35.674118882248216 139.73894657196686 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673913524453816 139.73906406391427 8.12 35.67388535115192 139.73908018110026 8.12 35.67388535115192 139.73908018110026 40.63 35.673913524453816 139.73906406391427 40.63 35.673913524453816 139.73906406391427 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67388535115192 139.73908018110026 8.12 35.67394052121421 139.73913400228213 8.12 35.67394052121421 139.73913400228213 40.63 35.67388535115192 139.73908018110026 40.63 35.67388535115192 139.73908018110026 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67394052121421 139.73913400228213 8.12 35.6739710830264 139.73916380365355 8.12 35.6739710830264 139.73916380365355 40.63 35.67394052121421 139.73913400228213 40.63 35.67394052121421 139.73913400228213 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6739710830264 139.73916380365355 8.12 35.67401824275653 139.73920981324807 8.12 35.67401824275653 139.73920981324807 40.63 35.6739710830264 139.73916380365355 40.63 35.6739710830264 139.73916380365355 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67401824275653 139.73920981324807 8.12 35.67405105970536 139.73924182138336 8.12 35.67405105970536 139.73924182138336 40.63 35.67401824275653 139.73920981324807 40.63 35.67401824275653 139.73920981324807 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67405105970536 139.73924182138336 8.12 35.67409673955785 139.73913588446504 8.12 35.67409673955785 139.73913588446504 40.63 35.67405105970536 139.73924182138336 40.63 35.67405105970536 139.73924182138336 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67409673955785 139.73913588446504 8.12 35.67416399546201 139.73907252947808 8.12 35.67416399546201 139.73907252947808 40.63 35.67409673955785 139.73913588446504 40.63 35.67409673955785 139.73913588446504 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67416399546201 139.73907252947808 8.12 35.67416783230439 139.73906869173362 8.12 35.67416783230439 139.73906869173362 40.63 35.67416399546201 139.73907252947808 40.63 35.67416399546201 139.73907252947808 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67416783230439 139.73906869173362 8.12 35.67426475136846 139.738981087157 8.12 35.67426475136846 139.738981087157 40.63 35.67416783230439 139.73906869173362 40.63 35.67416783230439 139.73906869173362 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67426475136846 139.738981087157 8.12 35.67425896761298 139.73896198301108 8.12 35.67425896761298 139.73896198301108 40.63 35.67426475136846 139.738981087157 40.63 35.67426475136846 139.738981087157 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67425896761298 139.73896198301108 8.12 35.67429573136721 139.7389463637465 8.12 35.67429573136721 139.7389463637465 40.63 35.67425896761298 139.73896198301108 40.63 35.67425896761298 139.73896198301108 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67429573136721 139.7389463637465 8.12 35.67429414948107 139.73894064336733 8.12 35.67429414948107 139.73894064336733 40.63 35.67429573136721 139.7389463637465 40.63 35.67429573136721 139.7389463637465 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67429414948107 139.73894064336733 8.12 35.67437514752422 139.73890706511438 8.12 35.67437514752422 139.73890706511438 40.63 35.67429414948107 139.73894064336733 40.63 35.67429414948107 139.73894064336733 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67437514752422 139.73890706511438 40.63 35.674359690116816 139.7388510539133 40.63 35.674278692089175 139.7388846322163 40.63 35.674277200579915 139.7388792210434 40.63 35.674118882248216 139.73894657196686 40.63 35.673913524453816 139.73906406391427 40.63 35.67388535115192 139.73908018110026 40.63 35.67394052121421 139.73913400228213 40.63 35.6739710830264 139.73916380365355 40.63 35.67401824275653 139.73920981324807 40.63 35.67405105970536 139.73924182138336 40.63 35.67409673955785 139.73913588446504 40.63 35.67416399546201 139.73907252947808 40.63 35.67416783230439 139.73906869173362 40.63 35.67426475136846 139.738981087157 40.63 35.67425896761298 139.73896198301108 40.63 35.67429573136721 139.7389463637465 40.63 35.67429414948107 139.73894064336733 40.63 35.67437514752422 139.73890706511438 40.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5823f75b-1e88-4c0a-9454-ba5131385baa"/>
							<gml:surfaceMember xlink:href="#poly-234e45ea-b512-449d-bfc9-bd68edd6bff1"/>
							<gml:surfaceMember xlink:href="#poly-5ad8abf4-eb4d-4df4-b872-2fca67db4e1b"/>
							<gml:surfaceMember xlink:href="#poly-2022930a-433c-4e60-ac0f-82882d5c631e"/>
							<gml:surfaceMember xlink:href="#poly-5a4065cd-11a5-41d4-936c-7472b41ab8a8"/>
							<gml:surfaceMember xlink:href="#poly-a2b009ae-bc19-4706-857e-7bef1d06747f"/>
							<gml:surfaceMember xlink:href="#poly-174fdc3c-628f-49d4-b554-685036f76f6c"/>
							<gml:surfaceMember xlink:href="#poly-d7bc8c0b-51a5-4914-a029-46e666262fb6"/>
							<gml:surfaceMember xlink:href="#poly-cc419e07-5a9c-4db2-b239-fe6e7dacd738"/>
							<gml:surfaceMember xlink:href="#poly-45d6b608-d24f-43e1-b6de-751b8e912257"/>
							<gml:surfaceMember xlink:href="#poly-01af4a76-c437-441c-a87f-b7d94445a919"/>
							<gml:surfaceMember xlink:href="#poly-82176fdd-3c4d-429b-8040-4ec84f5686e5"/>
							<gml:surfaceMember xlink:href="#poly-dbff7b24-5320-4f60-8195-cb65a9d52915"/>
							<gml:surfaceMember xlink:href="#poly-da2aa0f9-dbbc-43fd-ab80-bd86471ef89f"/>
							<gml:surfaceMember xlink:href="#poly-f0840657-f3b2-4434-a00c-e64064e1a2a6"/>
							<gml:surfaceMember xlink:href="#poly-87ca76c1-8ab1-487e-9ad4-bc9b8664d965"/>
							<gml:surfaceMember xlink:href="#poly-758e4941-96e0-4f31-98b3-90403b2b3c12"/>
							<gml:surfaceMember xlink:href="#poly-35275bd2-ca14-495d-840f-5f7768e03c75"/>
							<gml:surfaceMember xlink:href="#poly-e6259482-27d3-40c2-93ea-242e04ec1fa4"/>
							<gml:surfaceMember xlink:href="#poly-11a06a3b-6666-402b-b773-5cbc84c0c322"/>
							<gml:surfaceMember xlink:href="#poly-24c471c2-3824-4bc0-9306-198a7ecf9755"/>
							<gml:surfaceMember xlink:href="#poly-a00db8e9-bef0-4bcd-b987-2195e3f0d69a"/>
							<gml:surfaceMember xlink:href="#poly-40ba95db-9817-4f97-ae03-d8872e8d17ae"/>
							<gml:surfaceMember xlink:href="#poly-187998de-caec-4287-b066-e2588db2f2e1"/>
							<gml:surfaceMember xlink:href="#poly-36b0e2c5-5424-4806-abd9-5c8c7595820f"/>
							<gml:surfaceMember xlink:href="#poly-90c4495c-eafe-4c5d-8ca6-29eb54c4e288"/>
							<gml:surfaceMember xlink:href="#poly-d33f0754-9163-4d92-b386-2684f8302458"/>
							<gml:surfaceMember xlink:href="#poly-c3a5a36a-7006-462c-8439-9f82d66c8f92"/>
							<gml:surfaceMember xlink:href="#poly-6185e8bb-8eab-459e-a071-f689055b55a7"/>
							<gml:surfaceMember xlink:href="#poly-5b8e5729-c057-4295-94d0-2a39efde63ca"/>
							<gml:surfaceMember xlink:href="#poly-f1aca1eb-494e-48fb-8e6c-9f4493d44009"/>
							<gml:surfaceMember xlink:href="#poly-6f156df5-a291-433b-bf5d-5d98f1ad4c97"/>
							<gml:surfaceMember xlink:href="#poly-9ea23864-2531-46ac-9e10-af626e1dd8ad"/>
							<gml:surfaceMember xlink:href="#poly-871d4c3c-050c-4397-b6e5-fbac8bfed5ad"/>
							<gml:surfaceMember xlink:href="#poly-2c96af63-d4bf-4327-86cb-67f889fd4c6d"/>
							<gml:surfaceMember xlink:href="#poly-827cd26b-dec0-4c37-8d3b-6e2533892d3f"/>
							<gml:surfaceMember xlink:href="#poly-b9b60e46-e15b-4734-9c82-93126ac3e111"/>
							<gml:surfaceMember xlink:href="#poly-50d7ddea-ee90-4d70-80e2-6c835737b4e8"/>
							<gml:surfaceMember xlink:href="#poly-4cbb84cd-48c5-4389-8688-3368be1c38ee"/>
							<gml:surfaceMember xlink:href="#poly-199fe66a-be46-4792-9c3b-4889b65b5d2f"/>
							<gml:surfaceMember xlink:href="#poly-83c880ba-1eb3-468b-a4a9-240baa4d5199"/>
							<gml:surfaceMember xlink:href="#poly-756f5127-d65d-4a28-a47b-24c217c79087"/>
							<gml:surfaceMember xlink:href="#poly-9243b601-acc8-4980-b3ab-3fd165bd037c"/>
							<gml:surfaceMember xlink:href="#poly-0bf12b36-48cc-4016-aa39-53a08a694a8d"/>
							<gml:surfaceMember xlink:href="#poly-670182e1-4790-4563-aa6e-e225b21df572"/>
							<gml:surfaceMember xlink:href="#poly-43762942-77fb-456d-bee0-23337d719f80"/>
							<gml:surfaceMember xlink:href="#poly-79401103-e447-4556-b803-3715b90a2844"/>
							<gml:surfaceMember xlink:href="#poly-4e6af133-89ba-429b-9288-e62f06ea5c2c"/>
							<gml:surfaceMember xlink:href="#poly-8347f45d-4839-49b7-911c-604a80e43171"/>
							<gml:surfaceMember xlink:href="#poly-993c094e-49b3-4f6f-8ddf-5eeb1cce3874"/>
							<gml:surfaceMember xlink:href="#poly-7604018d-2d28-474e-a693-541b78b9bfa3"/>
							<gml:surfaceMember xlink:href="#poly-2f0c6aba-8de0-4f9b-8342-3c4d3570da81"/>
							<gml:surfaceMember xlink:href="#poly-8c13160a-c9c5-4d4b-b1b5-7b348cc0e416"/>
							<gml:surfaceMember xlink:href="#poly-3d6ce360-778e-44f4-9507-9dcb080de22b"/>
							<gml:surfaceMember xlink:href="#poly-7b0a68fa-9792-4a5a-9067-bdce74477246"/>
							<gml:surfaceMember xlink:href="#poly-89a209b4-955c-4e5b-a8b8-97a427013c99"/>
							<gml:surfaceMember xlink:href="#poly-4ce150b3-d9d0-439a-b5e8-7709e3e62dd1"/>
							<gml:surfaceMember xlink:href="#poly-7763367b-d9dd-40f1-85c3-d6766a6b6125"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5823f75b-1e88-4c0a-9454-ba5131385baa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5823f75b-1e88-4c0a-9454-ba5131385baa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5823f75b-1e88-4c0a-9454-ba5131385baa">
											<gml:posList>35.67427869208917 139.7388846322163 8.12 35.6743596901168 139.73885105391327 8.12 35.67437514752419 139.73890706511438 8.12 35.67429414948106 139.73894064336733 8.12 35.674295731367195 139.7389463637465 8.12 35.67425896761296 139.73896198301108 8.12 35.67426475136847 139.738981087157 8.12 35.67416783230439 139.7390686917336 8.12 35.67416399546198 139.73907252947808 8.12 35.67409673955783 139.73913588446504 8.12 35.67405105970534 139.73924182138336 8.12 35.67388535115192 139.73908018110026 8.12 35.6741188822482 139.73894657196686 8.12 35.67427720057989 139.7388792210434 8.12 35.67427869208917 139.7388846322163 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-234e45ea-b512-449d-bfc9-bd68edd6bff1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-234e45ea-b512-449d-bfc9-bd68edd6bff1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-234e45ea-b512-449d-bfc9-bd68edd6bff1">
											<gml:posList>35.67397522014297 139.73911747975157 44.9 35.673959679709554 139.73907042780297 44.9 35.6739220065632 139.7390873404834 44.9 35.67391352445381 139.7390640639143 44.9 35.67388535115192 139.73908018110026 44.9 35.67394053022793 139.73913400227156 44.9 35.67397522014297 139.73911747975157 44.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ad8abf4-eb4d-4df4-b872-2fca67db4e1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ad8abf4-eb4d-4df4-b872-2fca67db4e1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ad8abf4-eb4d-4df4-b872-2fca67db4e1b">
											<gml:posList>35.674107788666525 139.73909912991536 40.5 35.674102263283515 139.7390761370307 40.5 35.67404125457023 139.73910580304278 40.5 35.67397108302637 139.73916380365355 40.5 35.674107788666525 139.73909912991536 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2022930a-433c-4e60-ac0f-82882d5c631e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2022930a-433c-4e60-ac0f-82882d5c631e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2022930a-433c-4e60-ac0f-82882d5c631e">
											<gml:posList>35.67409673955783 139.73913588446504 23.9 35.674018242756524 139.73920981324807 23.9 35.67405105970534 139.73924182138336 23.9 35.67409673955783 139.73913588446504 23.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a4065cd-11a5-41d4-936c-7472b41ab8a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a4065cd-11a5-41d4-936c-7472b41ab8a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a4065cd-11a5-41d4-936c-7472b41ab8a8">
											<gml:posList>35.67416399546198 139.73907252947808 37.1 35.67397108302637 139.73916380365355 37.1 35.674018242756524 139.73920981324807 37.1 35.67416399546198 139.73907252947808 37.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2b009ae-bc19-4706-857e-7bef1d06747f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2b009ae-bc19-4706-857e-7bef1d06747f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2b009ae-bc19-4706-857e-7bef1d06747f">
											<gml:posList>35.67404125457023 139.73910580304278 43.1 35.674102263283515 139.7390761370307 43.1 35.674093851162674 139.73905015386927 43.1 35.674032842447076 139.7390798088512 43.1 35.67404125457023 139.73910580304278 43.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-174fdc3c-628f-49d4-b554-685036f76f6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-174fdc3c-628f-49d4-b554-685036f76f6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-174fdc3c-628f-49d4-b554-685036f76f6c">
											<gml:posList>35.674093851162674 139.73905015386927 40.5 35.67410657537733 139.73901158566755 40.5 35.67406638936858 139.7390309979322 40.5 35.674032842447076 139.7390798088512 40.5 35.674093851162674 139.73905015386927 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d7bc8c0b-51a5-4914-a029-46e666262fb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7bc8c0b-51a5-4914-a029-46e666262fb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7bc8c0b-51a5-4914-a029-46e666262fb6">
											<gml:posList>35.67405602539406 139.73899878670787 42.5 35.67406638936858 139.7390309979322 42.5 35.67410657537733 139.73901158566755 42.5 35.67409621138901 139.73897936338287 42.5 35.67405602539406 139.73899878670787 42.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc419e07-5a9c-4db2-b239-fe6e7dacd738">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc419e07-5a9c-4db2-b239-fe6e7dacd738">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc419e07-5a9c-4db2-b239-fe6e7dacd738">
											<gml:posList>35.67397522014297 139.73911747975157 40.5 35.67394053022793 139.73913400227156 40.5 35.67397108302637 139.73916380365355 40.5 35.67404125457023 139.73910580304278 40.5 35.674032842447076 139.7390798088512 40.5 35.67406638936858 139.7390309979322 40.5 35.67405602539406 139.73899878670787 40.5 35.67409621138901 139.73897936338287 40.5 35.67410657537733 139.73901158566755 40.5 35.674093851162674 139.73905015386927 40.5 35.674102263283515 139.7390761370307 40.5 35.674107788666525 139.73909912991536 40.5 35.67411550168549 139.7390610978528 40.5 35.67410889701094 139.73904112200717 40.5 35.6741455415562 139.73902289590885 40.5 35.67415215524747 139.73904287175154 40.5 35.67416399546198 139.73907252947808 40.5 35.67416783230439 139.7390686917336 40.5 35.67423220782429 139.73901049887417 40.5 35.67422603418387 139.73897695703923 40.5 35.67425896761296 139.73896198301108 40.5 35.674295731367195 139.7389463637465 40.5 35.67427720057989 139.7388792210434 40.5 35.67419336261097 139.73892351800927 40.5 35.67419936968045 139.73894002587926 40.5 35.674182359057646 139.7389493252066 40.5 35.67417230303168 139.73895352377642 40.5 35.67415504742699 139.73896076868516 40.5 35.67415029290323 139.73894379538328 40.5 35.67416754849824 139.73893653942454 40.5 35.67417635198076 139.7389328062927 40.5 35.6741188822482 139.73894657196686 40.5 35.67391352445381 139.7390640639143 40.5 35.6739220065632 139.7390873404834 40.5 35.673959679709554 139.73907042780297 40.5 35.67397522014297 139.73911747975157 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45d6b608-d24f-43e1-b6de-751b8e912257">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45d6b608-d24f-43e1-b6de-751b8e912257">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45d6b608-d24f-43e1-b6de-751b8e912257">
											<gml:posList>35.67410889701094 139.73904112200717 42.5 35.67411550168549 139.7390610978528 42.5 35.67415215524747 139.73904287175154 42.5 35.6741455415562 139.73902289590885 42.5 35.67410889701094 139.73904112200717 42.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01af4a76-c437-441c-a87f-b7d94445a919">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01af4a76-c437-441c-a87f-b7d94445a919">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01af4a76-c437-441c-a87f-b7d94445a919">
											<gml:posList>35.67411550168549 139.7390610978528 40.5 35.674107788666525 139.73909912991536 40.5 35.67416399546198 139.73907252947808 40.5 35.67415215524747 139.73904287175154 40.5 35.67411550168549 139.7390610978528 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-82176fdd-3c4d-429b-8040-4ec84f5686e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82176fdd-3c4d-429b-8040-4ec84f5686e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82176fdd-3c4d-429b-8040-4ec84f5686e5">
											<gml:posList>35.67415029290323 139.73894379538328 44.1 35.67415504742699 139.73896076868516 44.1 35.67417230303168 139.73895352377642 44.1 35.67416754849824 139.73893653942454 44.1 35.67415029290323 139.73894379538328 44.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbff7b24-5320-4f60-8195-cb65a9d52915">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbff7b24-5320-4f60-8195-cb65a9d52915">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbff7b24-5320-4f60-8195-cb65a9d52915">
											<gml:posList>35.67417635198076 139.7389328062927 40.5 35.67416754849824 139.73893653942454 40.5 35.67417230303168 139.73895352377642 40.5 35.674182359057646 139.7389493252066 40.5 35.67417635198076 139.7389328062927 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da2aa0f9-dbbc-43fd-ab80-bd86471ef89f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da2aa0f9-dbbc-43fd-ab80-bd86471ef89f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da2aa0f9-dbbc-43fd-ab80-bd86471ef89f">
											<gml:posList>35.67417635198076 139.7389328062927 44.1 35.674182359057646 139.7389493252066 44.1 35.67419936968045 139.73894002587926 44.1 35.67419336261097 139.73892351800927 44.1 35.67417635198076 139.7389328062927 44.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0840657-f3b2-4434-a00c-e64064e1a2a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0840657-f3b2-4434-a00c-e64064e1a2a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0840657-f3b2-4434-a00c-e64064e1a2a6">
											<gml:posList>35.6741188822482 139.73894657196686 40.5 35.67417635198076 139.7389328062927 40.5 35.67419336261097 139.73892351800927 40.5 35.67427720057989 139.7388792210434 40.5 35.6741188822482 139.73894657196686 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87ca76c1-8ab1-487e-9ad4-bc9b8664d965">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87ca76c1-8ab1-487e-9ad4-bc9b8664d965">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87ca76c1-8ab1-487e-9ad4-bc9b8664d965">
											<gml:posList>35.67422603418387 139.73897695703923 37.821 35.67423220782429 139.73901049887417 37.821 35.67426475136847 139.738981087157 37.821 35.67425896761296 139.73896198301108 37.821 35.67422603418387 139.73897695703923 37.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-758e4941-96e0-4f31-98b3-90403b2b3c12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-758e4941-96e0-4f31-98b3-90403b2b3c12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-758e4941-96e0-4f31-98b3-90403b2b3c12">
											<gml:posList>35.67427869208917 139.7388846322163 13.733 35.67437514752419 139.73890706511438 13.733 35.6743596901168 139.73885105391327 13.533 35.67427869208917 139.7388846322163 13.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35275bd2-ca14-495d-840f-5f7768e03c75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35275bd2-ca14-495d-840f-5f7768e03c75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35275bd2-ca14-495d-840f-5f7768e03c75">
											<gml:posList>35.67427869208917 139.7388846322163 13.733 35.67429414948106 139.73894064336733 13.733 35.67437514752419 139.73890706511438 13.733 35.67427869208917 139.7388846322163 13.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6259482-27d3-40c2-93ea-242e04ec1fa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6259482-27d3-40c2-93ea-242e04ec1fa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6259482-27d3-40c2-93ea-242e04ec1fa4">
											<gml:posList>35.67388535115192 139.73908018110026 8.12 35.67405105970534 139.73924182138336 8.12 35.67405105970534 139.73924182138336 23.9 35.674018242756524 139.73920981324807 23.9 35.674018242756524 139.73920981324807 37.1 35.67397108302637 139.73916380365355 37.1 35.67397108302637 139.73916380365355 40.5 35.67394053022793 139.73913400227156 40.5 35.67394053022793 139.73913400227156 44.9 35.67388535115192 139.73908018110026 44.9 35.67388535115192 139.73908018110026 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11a06a3b-6666-402b-b773-5cbc84c0c322">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11a06a3b-6666-402b-b773-5cbc84c0c322">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11a06a3b-6666-402b-b773-5cbc84c0c322">
											<gml:posList>35.6739220065632 139.7390873404834 44.9 35.6739220065632 139.7390873404834 40.5 35.67391352445381 139.7390640639143 40.5 35.67391352445381 139.7390640639143 44.9 35.6739220065632 139.7390873404834 44.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24c471c2-3824-4bc0-9306-198a7ecf9755">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24c471c2-3824-4bc0-9306-198a7ecf9755">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24c471c2-3824-4bc0-9306-198a7ecf9755">
											<gml:posList>35.6739220065632 139.7390873404834 40.5 35.6739220065632 139.7390873404834 44.9 35.673959679709554 139.73907042780297 44.9 35.673959679709554 139.73907042780297 40.5 35.6739220065632 139.7390873404834 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a00db8e9-bef0-4bcd-b987-2195e3f0d69a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a00db8e9-bef0-4bcd-b987-2195e3f0d69a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a00db8e9-bef0-4bcd-b987-2195e3f0d69a">
											<gml:posList>35.67394053022793 139.73913400227156 40.5 35.67397522014297 139.73911747975157 40.5 35.67397522014297 139.73911747975157 44.9 35.67394053022793 139.73913400227156 44.9 35.67394053022793 139.73913400227156 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40ba95db-9817-4f97-ae03-d8872e8d17ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40ba95db-9817-4f97-ae03-d8872e8d17ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40ba95db-9817-4f97-ae03-d8872e8d17ae">
											<gml:posList>35.67397522014297 139.73911747975157 40.5 35.673959679709554 139.73907042780297 40.5 35.673959679709554 139.73907042780297 44.9 35.67397522014297 139.73911747975157 44.9 35.67397522014297 139.73911747975157 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-187998de-caec-4287-b066-e2588db2f2e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-187998de-caec-4287-b066-e2588db2f2e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-187998de-caec-4287-b066-e2588db2f2e1">
											<gml:posList>35.67391352445381 139.7390640639143 40.5 35.6741188822482 139.73894657196686 40.5 35.6741188822482 139.73894657196686 8.12 35.67388535115192 139.73908018110026 8.12 35.67388535115192 139.73908018110026 44.9 35.67391352445381 139.7390640639143 44.9 35.67391352445381 139.7390640639143 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36b0e2c5-5424-4806-abd9-5c8c7595820f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36b0e2c5-5424-4806-abd9-5c8c7595820f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36b0e2c5-5424-4806-abd9-5c8c7595820f">
											<gml:posList>35.674032842447076 139.7390798088512 43.1 35.674032842447076 139.7390798088512 40.5 35.67404125457023 139.73910580304278 40.5 35.67404125457023 139.73910580304278 43.1 35.674032842447076 139.7390798088512 43.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90c4495c-eafe-4c5d-8ca6-29eb54c4e288">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90c4495c-eafe-4c5d-8ca6-29eb54c4e288">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90c4495c-eafe-4c5d-8ca6-29eb54c4e288">
											<gml:posList>35.67406638936858 139.7390309979322 40.5 35.67406638936858 139.7390309979322 42.5 35.67405602539406 139.73899878670787 42.5 35.67405602539406 139.73899878670787 40.5 35.67406638936858 139.7390309979322 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d33f0754-9163-4d92-b386-2684f8302458">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d33f0754-9163-4d92-b386-2684f8302458">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d33f0754-9163-4d92-b386-2684f8302458">
											<gml:posList>35.674093851162674 139.73905015386927 43.1 35.674093851162674 139.73905015386927 40.5 35.674032842447076 139.7390798088512 40.5 35.674032842447076 139.7390798088512 43.1 35.674093851162674 139.73905015386927 43.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3a5a36a-7006-462c-8439-9f82d66c8f92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3a5a36a-7006-462c-8439-9f82d66c8f92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3a5a36a-7006-462c-8439-9f82d66c8f92">
											<gml:posList>35.67416399546198 139.73907252947808 37.1 35.67416399546198 139.73907252947808 40.5 35.674107788666525 139.73909912991536 40.5 35.67397108302637 139.73916380365355 40.5 35.67397108302637 139.73916380365355 37.1 35.67416399546198 139.73907252947808 37.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6185e8bb-8eab-459e-a071-f689055b55a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6185e8bb-8eab-459e-a071-f689055b55a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6185e8bb-8eab-459e-a071-f689055b55a7">
											<gml:posList>35.67404125457023 139.73910580304278 43.1 35.67404125457023 139.73910580304278 40.5 35.674102263283515 139.7390761370307 40.5 35.674102263283515 139.7390761370307 43.1 35.67404125457023 139.73910580304278 43.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b8e5729-c057-4295-94d0-2a39efde63ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b8e5729-c057-4295-94d0-2a39efde63ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b8e5729-c057-4295-94d0-2a39efde63ca">
											<gml:posList>35.67409673955783 139.73913588446504 23.9 35.67405105970534 139.73924182138336 23.9 35.67405105970534 139.73924182138336 8.12 35.67409673955783 139.73913588446504 8.12 35.67409673955783 139.73913588446504 23.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1aca1eb-494e-48fb-8e6c-9f4493d44009">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1aca1eb-494e-48fb-8e6c-9f4493d44009">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1aca1eb-494e-48fb-8e6c-9f4493d44009">
											<gml:posList>35.67409621138901 139.73897936338287 42.5 35.67409621138901 139.73897936338287 40.5 35.67405602539406 139.73899878670787 40.5 35.67405602539406 139.73899878670787 42.5 35.67409621138901 139.73897936338287 42.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f156df5-a291-433b-bf5d-5d98f1ad4c97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f156df5-a291-433b-bf5d-5d98f1ad4c97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f156df5-a291-433b-bf5d-5d98f1ad4c97">
											<gml:posList>35.67406638936858 139.7390309979322 40.5 35.67410657537733 139.73901158566755 40.5 35.67410657537733 139.73901158566755 42.5 35.67406638936858 139.7390309979322 42.5 35.67406638936858 139.7390309979322 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ea23864-2531-46ac-9e10-af626e1dd8ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ea23864-2531-46ac-9e10-af626e1dd8ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ea23864-2531-46ac-9e10-af626e1dd8ad">
											<gml:posList>35.67409673955783 139.73913588446504 23.9 35.67409673955783 139.73913588446504 8.12 35.67416399546198 139.73907252947808 8.12 35.67416399546198 139.73907252947808 37.1 35.674018242756524 139.73920981324807 37.1 35.674018242756524 139.73920981324807 23.9 35.67409673955783 139.73913588446504 23.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-871d4c3c-050c-4397-b6e5-fbac8bfed5ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-871d4c3c-050c-4397-b6e5-fbac8bfed5ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-871d4c3c-050c-4397-b6e5-fbac8bfed5ad">
											<gml:posList>35.674102263283515 139.7390761370307 43.1 35.674102263283515 139.7390761370307 40.5 35.674093851162674 139.73905015386927 40.5 35.674093851162674 139.73905015386927 43.1 35.674102263283515 139.7390761370307 43.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c96af63-d4bf-4327-86cb-67f889fd4c6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c96af63-d4bf-4327-86cb-67f889fd4c6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c96af63-d4bf-4327-86cb-67f889fd4c6d">
											<gml:posList>35.67410657537733 139.73901158566755 42.5 35.67410657537733 139.73901158566755 40.5 35.67409621138901 139.73897936338287 40.5 35.67409621138901 139.73897936338287 42.5 35.67410657537733 139.73901158566755 42.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-827cd26b-dec0-4c37-8d3b-6e2533892d3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-827cd26b-dec0-4c37-8d3b-6e2533892d3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-827cd26b-dec0-4c37-8d3b-6e2533892d3f">
											<gml:posList>35.67411550168549 139.7390610978528 40.5 35.67411550168549 139.7390610978528 42.5 35.67410889701094 139.73904112200717 42.5 35.67410889701094 139.73904112200717 40.5 35.67411550168549 139.7390610978528 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9b60e46-e15b-4734-9c82-93126ac3e111">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9b60e46-e15b-4734-9c82-93126ac3e111">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9b60e46-e15b-4734-9c82-93126ac3e111">
											<gml:posList>35.6741455415562 139.73902289590885 42.5 35.6741455415562 139.73902289590885 40.5 35.67410889701094 139.73904112200717 40.5 35.67410889701094 139.73904112200717 42.5 35.6741455415562 139.73902289590885 42.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50d7ddea-ee90-4d70-80e2-6c835737b4e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50d7ddea-ee90-4d70-80e2-6c835737b4e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50d7ddea-ee90-4d70-80e2-6c835737b4e8">
											<gml:posList>35.67415215524747 139.73904287175154 42.5 35.67411550168549 139.7390610978528 42.5 35.67411550168549 139.7390610978528 40.5 35.67415215524747 139.73904287175154 40.5 35.67415215524747 139.73904287175154 42.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cbb84cd-48c5-4389-8688-3368be1c38ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cbb84cd-48c5-4389-8688-3368be1c38ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cbb84cd-48c5-4389-8688-3368be1c38ee">
											<gml:posList>35.67415215524747 139.73904287175154 42.5 35.67415215524747 139.73904287175154 40.5 35.6741455415562 139.73902289590885 40.5 35.6741455415562 139.73902289590885 42.5 35.67415215524747 139.73904287175154 42.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-199fe66a-be46-4792-9c3b-4889b65b5d2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-199fe66a-be46-4792-9c3b-4889b65b5d2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-199fe66a-be46-4792-9c3b-4889b65b5d2f">
											<gml:posList>35.67415029290323 139.73894379538328 44.1 35.67415029290323 139.73894379538328 40.5 35.67415504742699 139.73896076868516 40.5 35.67415504742699 139.73896076868516 44.1 35.67415029290323 139.73894379538328 44.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83c880ba-1eb3-468b-a4a9-240baa4d5199">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83c880ba-1eb3-468b-a4a9-240baa4d5199">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83c880ba-1eb3-468b-a4a9-240baa4d5199">
											<gml:posList>35.67416754849824 139.73893653942454 40.5 35.67415029290323 139.73894379538328 40.5 35.67415029290323 139.73894379538328 44.1 35.67416754849824 139.73893653942454 44.1 35.67416754849824 139.73893653942454 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-756f5127-d65d-4a28-a47b-24c217c79087">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-756f5127-d65d-4a28-a47b-24c217c79087">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-756f5127-d65d-4a28-a47b-24c217c79087">
											<gml:posList>35.67415504742699 139.73896076868516 40.5 35.67417230303168 139.73895352377642 40.5 35.67417230303168 139.73895352377642 44.1 35.67415504742699 139.73896076868516 44.1 35.67415504742699 139.73896076868516 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9243b601-acc8-4980-b3ab-3fd165bd037c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9243b601-acc8-4980-b3ab-3fd165bd037c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9243b601-acc8-4980-b3ab-3fd165bd037c">
											<gml:posList>35.67416783230439 139.7390686917336 40.5 35.67416399546198 139.73907252947808 40.5 35.67416399546198 139.73907252947808 37.1 35.67416399546198 139.73907252947808 8.12 35.67416783230439 139.7390686917336 8.12 35.67416783230439 139.7390686917336 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bf12b36-48cc-4016-aa39-53a08a694a8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bf12b36-48cc-4016-aa39-53a08a694a8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bf12b36-48cc-4016-aa39-53a08a694a8d">
											<gml:posList>35.67417230303168 139.73895352377642 40.5 35.67416754849824 139.73893653942454 40.5 35.67416754849824 139.73893653942454 44.1 35.67417230303168 139.73895352377642 44.1 35.67417230303168 139.73895352377642 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-670182e1-4790-4563-aa6e-e225b21df572">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-670182e1-4790-4563-aa6e-e225b21df572">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-670182e1-4790-4563-aa6e-e225b21df572">
											<gml:posList>35.674182359057646 139.7389493252066 44.1 35.67417635198076 139.7389328062927 44.1 35.67417635198076 139.7389328062927 40.5 35.674182359057646 139.7389493252066 40.5 35.674182359057646 139.7389493252066 44.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43762942-77fb-456d-bee0-23337d719f80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43762942-77fb-456d-bee0-23337d719f80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43762942-77fb-456d-bee0-23337d719f80">
											<gml:posList>35.67419336261097 139.73892351800927 44.1 35.67419336261097 139.73892351800927 40.5 35.67417635198076 139.7389328062927 40.5 35.67417635198076 139.7389328062927 44.1 35.67419336261097 139.73892351800927 44.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79401103-e447-4556-b803-3715b90a2844">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79401103-e447-4556-b803-3715b90a2844">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79401103-e447-4556-b803-3715b90a2844">
											<gml:posList>35.67419936968045 139.73894002587926 40.5 35.67419936968045 139.73894002587926 44.1 35.674182359057646 139.7389493252066 44.1 35.674182359057646 139.7389493252066 40.5 35.67419936968045 139.73894002587926 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e6af133-89ba-429b-9288-e62f06ea5c2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e6af133-89ba-429b-9288-e62f06ea5c2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e6af133-89ba-429b-9288-e62f06ea5c2c">
											<gml:posList>35.67419336261097 139.73892351800927 44.1 35.67419936968045 139.73894002587926 44.1 35.67419936968045 139.73894002587926 40.5 35.67419336261097 139.73892351800927 40.5 35.67419336261097 139.73892351800927 44.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8347f45d-4839-49b7-911c-604a80e43171">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8347f45d-4839-49b7-911c-604a80e43171">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8347f45d-4839-49b7-911c-604a80e43171">
											<gml:posList>35.6741188822482 139.73894657196686 40.5 35.67427720057989 139.7388792210434 40.5 35.67427720057989 139.7388792210434 8.12 35.6741188822482 139.73894657196686 8.12 35.6741188822482 139.73894657196686 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-993c094e-49b3-4f6f-8ddf-5eeb1cce3874">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-993c094e-49b3-4f6f-8ddf-5eeb1cce3874">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-993c094e-49b3-4f6f-8ddf-5eeb1cce3874">
											<gml:posList>35.67416783230439 139.7390686917336 8.12 35.67426475136847 139.738981087157 8.12 35.67426475136847 139.738981087157 37.821 35.67423220782429 139.73901049887417 37.821 35.67423220782429 139.73901049887417 40.5 35.67416783230439 139.7390686917336 40.5 35.67416783230439 139.7390686917336 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7604018d-2d28-474e-a693-541b78b9bfa3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7604018d-2d28-474e-a693-541b78b9bfa3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7604018d-2d28-474e-a693-541b78b9bfa3">
											<gml:posList>35.67422603418387 139.73897695703923 37.821 35.67422603418387 139.73897695703923 40.5 35.67423220782429 139.73901049887417 40.5 35.67423220782429 139.73901049887417 37.821 35.67422603418387 139.73897695703923 37.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f0c6aba-8de0-4f9b-8342-3c4d3570da81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f0c6aba-8de0-4f9b-8342-3c4d3570da81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f0c6aba-8de0-4f9b-8342-3c4d3570da81">
											<gml:posList>35.67422603418387 139.73897695703923 40.5 35.67422603418387 139.73897695703923 37.821 35.67425896761296 139.73896198301108 37.821 35.67425896761296 139.73896198301108 40.5 35.67422603418387 139.73897695703923 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c13160a-c9c5-4d4b-b1b5-7b348cc0e416">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c13160a-c9c5-4d4b-b1b5-7b348cc0e416">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c13160a-c9c5-4d4b-b1b5-7b348cc0e416">
											<gml:posList>35.67426475136847 139.738981087157 8.12 35.67425896761296 139.73896198301108 8.12 35.67425896761296 139.73896198301108 37.821 35.67426475136847 139.738981087157 37.821 35.67426475136847 139.738981087157 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d6ce360-778e-44f4-9507-9dcb080de22b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d6ce360-778e-44f4-9507-9dcb080de22b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d6ce360-778e-44f4-9507-9dcb080de22b">
											<gml:posList>35.674295731367195 139.7389463637465 8.12 35.674295731367195 139.7389463637465 40.5 35.67425896761296 139.73896198301108 40.5 35.67425896761296 139.73896198301108 37.821 35.67425896761296 139.73896198301108 8.12 35.674295731367195 139.7389463637465 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b0a68fa-9792-4a5a-9067-bdce74477246">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b0a68fa-9792-4a5a-9067-bdce74477246">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b0a68fa-9792-4a5a-9067-bdce74477246">
											<gml:posList>35.674295731367195 139.7389463637465 40.5 35.674295731367195 139.7389463637465 8.12 35.67429414948106 139.73894064336733 8.12 35.67429414948106 139.73894064336733 13.733 35.67427869208917 139.7388846322163 13.733 35.67427869208917 139.7388846322163 8.12 35.67427720057989 139.7388792210434 8.12 35.67427720057989 139.7388792210434 40.5 35.674295731367195 139.7389463637465 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89a209b4-955c-4e5b-a8b8-97a427013c99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89a209b4-955c-4e5b-a8b8-97a427013c99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89a209b4-955c-4e5b-a8b8-97a427013c99">
											<gml:posList>35.67427869208917 139.7388846322163 8.12 35.67427869208917 139.7388846322163 13.733 35.6743596901168 139.73885105391327 13.533 35.6743596901168 139.73885105391327 8.12 35.67427869208917 139.7388846322163 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ce150b3-d9d0-439a-b5e8-7709e3e62dd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ce150b3-d9d0-439a-b5e8-7709e3e62dd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ce150b3-d9d0-439a-b5e8-7709e3e62dd1">
											<gml:posList>35.67437514752419 139.73890706511438 13.733 35.67429414948106 139.73894064336733 13.733 35.67429414948106 139.73894064336733 8.12 35.67437514752419 139.73890706511438 8.12 35.67437514752419 139.73890706511438 13.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7763367b-d9dd-40f1-85c3-d6766a6b6125">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7763367b-d9dd-40f1-85c3-d6766a6b6125">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7763367b-d9dd-40f1-85c3-d6766a6b6125">
											<gml:posList>35.67437514752419 139.73890706511438 8.12 35.6743596901168 139.73885105391327 8.12 35.6743596901168 139.73885105391327 13.533 35.67437514752419 139.73890706511438 13.733 35.67437514752419 139.73890706511438 8.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4562</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">475.82296</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.19</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>