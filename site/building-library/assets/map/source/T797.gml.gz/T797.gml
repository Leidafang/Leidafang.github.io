<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e4303378-c93c-4fb6-b3fb-fdcf1ef3d82c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">15.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.674244712886 139.73791608955216 0 35.67412388331974 139.73797224051776 0 35.67418099265401 139.73815245608077 0 35.6743018213424 139.73809509019955 0 35.674244712886 139.73791608955216 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674244712886 139.73791608955216 8.429 35.6743018213424 139.73809509019955 8.429 35.67418099265401 139.73815245608077 8.429 35.67412388331974 139.73797224051776 8.429 35.674244712886 139.73791608955216 8.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674244712886 139.73791608955216 8.429 35.67412388331974 139.73797224051776 8.429 35.67412388331974 139.73797224051776 23.57 35.674244712886 139.73791608955216 23.57 35.674244712886 139.73791608955216 8.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67412388331974 139.73797224051776 8.429 35.67418099265401 139.73815245608077 8.429 35.67418099265401 139.73815245608077 23.57 35.67412388331974 139.73797224051776 23.57 35.67412388331974 139.73797224051776 8.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67418099265401 139.73815245608077 8.429 35.6743018213424 139.73809509019955 8.429 35.6743018213424 139.73809509019955 23.57 35.67418099265401 139.73815245608077 23.57 35.67418099265401 139.73815245608077 8.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6743018213424 139.73809509019955 8.429 35.674244712886 139.73791608955216 8.429 35.674244712886 139.73791608955216 23.57 35.6743018213424 139.73809509019955 23.57 35.6743018213424 139.73809509019955 8.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674244712886 139.73791608955216 23.57 35.67412388331974 139.73797224051776 23.57 35.67418099265401 139.73815245608077 23.57 35.6743018213424 139.73809509019955 23.57 35.674244712886 139.73791608955216 23.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c2588557-5a7c-400c-bca7-b9d815499c0f"/>
							<gml:surfaceMember xlink:href="#poly-62db7d6b-5035-4316-aa7f-0d843085be6e"/>
							<gml:surfaceMember xlink:href="#poly-66b5c8b2-37db-4ffe-bb15-624c4a7baa7d"/>
							<gml:surfaceMember xlink:href="#poly-f2882e3f-ff91-45ec-a095-ac1c0f52f74f"/>
							<gml:surfaceMember xlink:href="#poly-88ebebe7-85c8-402c-8a96-0fd69fe70684"/>
							<gml:surfaceMember xlink:href="#poly-c4bec302-eced-4fcb-a31f-3c598b914bc6"/>
							<gml:surfaceMember xlink:href="#poly-351d7255-82d9-46e6-95d1-a4290cd957c8"/>
							<gml:surfaceMember xlink:href="#poly-cd1aa9e1-6a43-4d0d-b6f4-ad2df3b5f793"/>
							<gml:surfaceMember xlink:href="#poly-9bc2ff17-f301-4529-b93e-f632c6f7d298"/>
							<gml:surfaceMember xlink:href="#poly-27d97e93-aacc-460d-bfef-c72f4ab9931e"/>
							<gml:surfaceMember xlink:href="#poly-47b25917-d77a-4c58-8a34-fbf49fe0a86e"/>
							<gml:surfaceMember xlink:href="#poly-054b7cb5-4db9-473c-8bb3-410b0bd9c542"/>
							<gml:surfaceMember xlink:href="#poly-e57d7649-191c-4c1e-9805-1be4cc6346f4"/>
							<gml:surfaceMember xlink:href="#poly-50c5392c-3e85-45b5-95ff-a072c6e7f3bf"/>
							<gml:surfaceMember xlink:href="#poly-233f9999-4150-483c-8363-0bab61bfa7e1"/>
							<gml:surfaceMember xlink:href="#poly-6d5b1e34-1db6-4c59-ba41-f57c603edbe7"/>
							<gml:surfaceMember xlink:href="#poly-e3dd51d0-25f3-4e1d-b8e1-265d5bf6a597"/>
							<gml:surfaceMember xlink:href="#poly-a9999815-7485-4ee6-9a0d-54922e71dc4c"/>
							<gml:surfaceMember xlink:href="#poly-4d4acc58-aa03-404c-a24c-2d37e8214d79"/>
							<gml:surfaceMember xlink:href="#poly-0409c1e5-5f08-4461-acea-2cfd0a25f1b6"/>
							<gml:surfaceMember xlink:href="#poly-d54ad020-f03c-4605-8fad-ddc57c0af58a"/>
							<gml:surfaceMember xlink:href="#poly-63d333ce-d144-4d7b-9d64-8561c0283de6"/>
							<gml:surfaceMember xlink:href="#poly-f31d5b94-ef1b-42d5-8890-b39d1a35c66b"/>
							<gml:surfaceMember xlink:href="#poly-cca5837d-a5bf-4067-adfd-5ee40afca034"/>
							<gml:surfaceMember xlink:href="#poly-e6fa6333-82ba-4669-a72a-96cc07d69f0b"/>
							<gml:surfaceMember xlink:href="#poly-1c22df2d-91ae-4f00-b6ef-8d5891c1af86"/>
							<gml:surfaceMember xlink:href="#poly-1ae47f49-636b-48cc-895f-2bbc827cda18"/>
							<gml:surfaceMember xlink:href="#poly-8cfd13de-5b95-4972-86ea-8140f4dba138"/>
							<gml:surfaceMember xlink:href="#poly-91c1a1ee-d433-4ef6-9a20-61180bee4206"/>
							<gml:surfaceMember xlink:href="#poly-26ff4943-5052-4b62-a33b-6bb2daaf27ca"/>
							<gml:surfaceMember xlink:href="#poly-f2cd0162-1e1b-45e5-b8bc-5fd6be908081"/>
							<gml:surfaceMember xlink:href="#poly-4a8e6cfa-186c-4214-8590-25c14457a0ce"/>
							<gml:surfaceMember xlink:href="#poly-c0c3c651-3a54-47f8-84b2-30d5ea6f1537"/>
							<gml:surfaceMember xlink:href="#poly-b2ccd96d-4bc4-4630-9b07-04b2fcbcff4f"/>
							<gml:surfaceMember xlink:href="#poly-c2e85f36-57c6-41ff-81e1-9244e7eef740"/>
							<gml:surfaceMember xlink:href="#poly-f3de4693-128a-4a66-b74e-c1d77f011755"/>
							<gml:surfaceMember xlink:href="#poly-6f3aee23-f26a-419c-93ff-01dc60fe0933"/>
							<gml:surfaceMember xlink:href="#poly-6f11fe84-4e7d-43a7-b68e-dc805ffcbafe"/>
							<gml:surfaceMember xlink:href="#poly-6ec1c557-9ca3-482f-9f3f-3046e13fa042"/>
							<gml:surfaceMember xlink:href="#poly-7349dd90-ae4a-4a3c-8704-f60e9876a337"/>
							<gml:surfaceMember xlink:href="#poly-75f7a2d7-adf7-4281-b4e2-ba776f7c7efc"/>
							<gml:surfaceMember xlink:href="#poly-d3b66e75-514f-4948-ae0d-826a8c826df5"/>
							<gml:surfaceMember xlink:href="#poly-b9796a63-5bc7-42e5-b30e-08f45352bdc3"/>
							<gml:surfaceMember xlink:href="#poly-567d3788-d7c1-46a5-9ae7-547237cf2674"/>
							<gml:surfaceMember xlink:href="#poly-41ec5a4d-2fc2-4ed0-a018-4e05c3d11966"/>
							<gml:surfaceMember xlink:href="#poly-62bd2202-5043-4f8c-993a-1a516dc6ecf7"/>
							<gml:surfaceMember xlink:href="#poly-c10fa623-0e78-4f0c-97df-84e5ec2296fc"/>
							<gml:surfaceMember xlink:href="#poly-f07beadf-a03a-462d-b0d4-4451bb740e9a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e4303378-c93c-4fb6-b3fb-fdcf1ef3d82c_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d249344-2895-4f10-94eb-5b70cd169691">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674156132859416 139.73799302533493 24.423 35.67418773208341 139.73797798622215 24.423 35.674194265340454 139.73799861384487 24.423 35.674162666113915 139.7380136529508 24.423 35.674156132859416 139.73799302533493 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d396129-2078-439a-b256-236e8e8804c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d396129-2078-439a-b256-236e8e8804c3_0">
											<gml:posList>35.674156132859416 139.73799302533493 26.592 35.674156132859416 139.73799302533493 24.423 35.674162666113915 139.7380136529508 24.423 35.674162666113915 139.7380136529508 26.592 35.674156132859416 139.73799302533493 26.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a4e0e41-338f-4dc3-a242-d27b04de42ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a4e0e41-338f-4dc3-a242-d27b04de42ac_0">
											<gml:posList>35.67418773208341 139.73797798622215 26.592 35.67418773208341 139.73797798622215 24.423 35.674156132859416 139.73799302533493 24.423 35.674156132859416 139.73799302533493 26.592 35.67418773208341 139.73797798622215 26.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd0b560c-56bc-43ac-954b-0ff4677e3012">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd0b560c-56bc-43ac-954b-0ff4677e3012_0">
											<gml:posList>35.674156132859416 139.73799302533493 26.592 35.674162666113915 139.7380136529508 26.592 35.674194265340454 139.73799861384487 26.592 35.67418773208341 139.73797798622215 26.592 35.674156132859416 139.73799302533493 26.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef46f561-5eb1-4224-8290-d594f655870b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef46f561-5eb1-4224-8290-d594f655870b_0">
											<gml:posList>35.674162666113915 139.7380136529508 26.592 35.674162666113915 139.7380136529508 24.423 35.674194265340454 139.73799861384487 24.423 35.674194265340454 139.73799861384487 26.592 35.674162666113915 139.7380136529508 26.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e009353-653c-420c-a512-06f925c11e3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e009353-653c-420c-a512-06f925c11e3d_0">
											<gml:posList>35.674194265340454 139.73799861384487 24.423 35.67418773208341 139.73797798622215 24.423 35.67418773208341 139.73797798622215 26.592 35.674194265340454 139.73799861384487 26.592 35.674194265340454 139.73799861384487 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e4303378-c93c-4fb6-b3fb-fdcf1ef3d82c_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0be26a73-42da-4106-a6df-3823848c1853">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67415832174936 139.73802535665612 24.423 35.674145103593816 139.73803164694075 24.423 35.67414655675086 139.7380227194165 24.423 35.67414915492033 139.73801413298062 24.423 35.674150856518835 139.7380116122918 24.423 35.67415308188359 139.73801031717264 24.423 35.67415622775807 139.73801042389974 24.423 35.67415851815154 139.73801157004144 24.423 35.67415988988052 139.73801364520503 24.423 35.67416056836658 139.73801674854346 24.423 35.67416024744057 139.7380212560113 24.423 35.67415832174936 139.73802535665612 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30f2755d-dbde-4293-af21-e152e35c9900">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30f2755d-dbde-4293-af21-e152e35c9900_0">
											<gml:posList>35.67414655675086 139.7380227194165 27.16 35.67414655675086 139.7380227194165 24.423 35.674145103593816 139.73803164694075 24.423 35.674145103593816 139.73803164694075 27.16 35.67414655675086 139.7380227194165 27.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-320d7b61-9c0f-4460-8d88-697dc653e44f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-320d7b61-9c0f-4460-8d88-697dc653e44f_0">
											<gml:posList>35.67414915492033 139.73801413298062 27.16 35.67414915492033 139.73801413298062 24.423 35.67414655675086 139.7380227194165 24.423 35.67414655675086 139.7380227194165 27.16 35.67414915492033 139.73801413298062 27.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72e19caa-135b-4289-9e59-463ad7e6ef50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72e19caa-135b-4289-9e59-463ad7e6ef50_0">
											<gml:posList>35.674150856518835 139.7380116122918 27.16 35.674150856518835 139.7380116122918 24.423 35.67414915492033 139.73801413298062 24.423 35.67414915492033 139.73801413298062 27.16 35.674150856518835 139.7380116122918 27.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60594767-089c-4fcf-b3a9-4d849b012966">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60594767-089c-4fcf-b3a9-4d849b012966_0">
											<gml:posList>35.674145103593816 139.73803164694075 27.16 35.674145103593816 139.73803164694075 24.423 35.67415832174936 139.73802535665612 24.423 35.67415832174936 139.73802535665612 27.16 35.674145103593816 139.73803164694075 27.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e81fb43c-e927-4397-94ed-86127d92e2b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e81fb43c-e927-4397-94ed-86127d92e2b1_0">
											<gml:posList>35.67415308188359 139.73801031717264 24.423 35.674150856518835 139.7380116122918 24.423 35.674150856518835 139.7380116122918 27.16 35.67415308188359 139.73801031717264 27.16 35.67415308188359 139.73801031717264 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06cf8e37-8a0d-40f9-bb54-b22b9b9a29ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06cf8e37-8a0d-40f9-bb54-b22b9b9a29ad_0">
											<gml:posList>35.67414655675086 139.7380227194165 27.16 35.674145103593816 139.73803164694075 27.16 35.67415832174936 139.73802535665612 27.16 35.67416024744057 139.7380212560113 27.16 35.67416056836658 139.73801674854346 27.16 35.67415988988052 139.73801364520503 27.16 35.67415851815154 139.73801157004144 27.16 35.67415622775807 139.73801042389974 27.16 35.67415308188359 139.73801031717264 27.16 35.674150856518835 139.7380116122918 27.16 35.67414915492033 139.73801413298062 27.16 35.67414655675086 139.7380227194165 27.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3360d95-f1e7-4572-a612-900df1bf46c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3360d95-f1e7-4572-a612-900df1bf46c7_0">
											<gml:posList>35.67415622775807 139.73801042389974 24.423 35.67415308188359 139.73801031717264 24.423 35.67415308188359 139.73801031717264 27.16 35.67415622775807 139.73801042389974 27.16 35.67415622775807 139.73801042389974 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0ddcefc-dae5-471d-b3dd-ef11571ba509">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0ddcefc-dae5-471d-b3dd-ef11571ba509_0">
											<gml:posList>35.67415851815154 139.73801157004144 24.423 35.67415622775807 139.73801042389974 24.423 35.67415622775807 139.73801042389974 27.16 35.67415851815154 139.73801157004144 27.16 35.67415851815154 139.73801157004144 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbedfc3e-33a6-43c5-bf2a-ffc48208132b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbedfc3e-33a6-43c5-bf2a-ffc48208132b_0">
											<gml:posList>35.67415988988052 139.73801364520503 24.423 35.67415851815154 139.73801157004144 24.423 35.67415851815154 139.73801157004144 27.16 35.67415988988052 139.73801364520503 27.16 35.67415988988052 139.73801364520503 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcf76b20-ebf9-4692-8f08-9122624cb982">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcf76b20-ebf9-4692-8f08-9122624cb982_0">
											<gml:posList>35.67415832174936 139.73802535665612 27.16 35.67415832174936 139.73802535665612 24.423 35.67416024744057 139.7380212560113 24.423 35.67416024744057 139.7380212560113 27.16 35.67415832174936 139.73802535665612 27.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-311252b2-0c8c-4b76-a938-22d53b0768fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-311252b2-0c8c-4b76-a938-22d53b0768fb_0">
											<gml:posList>35.67416056836658 139.73801674854346 27.16 35.67416056836658 139.73801674854346 24.423 35.67415988988052 139.73801364520503 24.423 35.67415988988052 139.73801364520503 27.16 35.67416056836658 139.73801674854346 27.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74848891-0b6a-4d8c-9538-f80dae3dd74d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74848891-0b6a-4d8c-9538-f80dae3dd74d_0">
											<gml:posList>35.67416024744057 139.7380212560113 24.423 35.67416056836658 139.73801674854346 24.423 35.67416056836658 139.73801674854346 27.16 35.67416024744057 139.7380212560113 27.16 35.67416024744057 139.7380212560113 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e4303378-c93c-4fb6-b3fb-fdcf1ef3d82c_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c75da4b3-0d9b-4eae-b7c3-d0b05343cd72">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67422873753474 139.73798053344285 24.423 35.67423707269404 139.7379773310062 24.423 35.674239477813344 139.73798676210484 24.423 35.674231151667506 139.73798996452987 24.423 35.67422873753474 139.73798053344285 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5a9ff07-dde3-4d36-9d6c-2a9d4ea57514">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5a9ff07-dde3-4d36-9d6c-2a9d4ea57514_0">
											<gml:posList>35.67422873753474 139.73798053344285 24.423 35.674231151667506 139.73798996452987 24.423 35.674231151667506 139.73798996452987 29.641 35.67422873753474 139.73798053344285 29.641 35.67422873753474 139.73798053344285 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c67d27d-3b89-4e60-8e1b-ddf606557ddf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c67d27d-3b89-4e60-8e1b-ddf606557ddf_0">
											<gml:posList>35.67423707269404 139.7379773310062 24.423 35.67422873753474 139.73798053344285 24.423 35.67422873753474 139.73798053344285 29.641 35.67423707269404 139.7379773310062 29.641 35.67423707269404 139.7379773310062 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58b7c056-35d5-4aab-9caa-a520b3b7975a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58b7c056-35d5-4aab-9caa-a520b3b7975a_0">
											<gml:posList>35.674239477813344 139.73798676210484 29.641 35.67423707269404 139.7379773310062 29.641 35.67422873753474 139.73798053344285 29.641 35.674231151667506 139.73798996452987 29.641 35.674239477813344 139.73798676210484 29.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a2936c6-bbf5-42a0-b1b6-f6103c8dd436">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a2936c6-bbf5-42a0-b1b6-f6103c8dd436_0">
											<gml:posList>35.674231151667506 139.73798996452987 24.423 35.674239477813344 139.73798676210484 24.423 35.674239477813344 139.73798676210484 29.641 35.674231151667506 139.73798996452987 29.641 35.674231151667506 139.73798996452987 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dae7a71-c839-4d2a-a36f-b1ca48a07436">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dae7a71-c839-4d2a-a36f-b1ca48a07436_0">
											<gml:posList>35.674239477813344 139.73798676210484 29.641 35.674239477813344 139.73798676210484 24.423 35.67423707269404 139.7379773310062 24.423 35.67423707269404 139.7379773310062 29.641 35.674239477813344 139.73798676210484 29.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c2588557-5a7c-400c-bca7-b9d815499c0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2588557-5a7c-400c-bca7-b9d815499c0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2588557-5a7c-400c-bca7-b9d815499c0f">
											<gml:posList>35.674244712885965 139.73791608955216 8.429 35.67430182134237 139.73809509019955 8.429 35.674180992653994 139.73815245608077 8.429 35.67412388331972 139.73797224051776 8.429 35.674244712885965 139.73791608955216 8.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62db7d6b-5035-4316-aa7f-0d843085be6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62db7d6b-5035-4316-aa7f-0d843085be6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62db7d6b-5035-4316-aa7f-0d843085be6e">
											<gml:posList>35.674252781994866 139.73794114512074 25.06 35.674244712885965 139.73791608955216 20.628 35.67412388331972 139.73797224051776 20.628 35.674252781994866 139.73794114512074 25.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66b5c8b2-37db-4ffe-bb15-624c4a7baa7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66b5c8b2-37db-4ffe-bb15-624c4a7baa7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66b5c8b2-37db-4ffe-bb15-624c4a7baa7d">
											<gml:posList>35.67412388331972 139.73797224051776 20.628 35.674132214794426 139.7379985329812 25.06 35.674252781994866 139.73794114512074 25.06 35.67412388331972 139.73797224051776 20.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2882e3f-ff91-45ec-a095-ac1c0f52f74f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2882e3f-ff91-45ec-a095-ac1c0f52f74f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2882e3f-ff91-45ec-a095-ac1c0f52f74f">
											<gml:posList>35.674132214794426 139.7379985329812 25.06 35.67413461346632 139.73799982260152 25.06 35.67425172069553 139.73794407378364 25.06 35.674252781994866 139.73794114512074 25.06 35.674132214794426 139.7379985329812 25.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88ebebe7-85c8-402c-8a96-0fd69fe70684">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88ebebe7-85c8-402c-8a96-0fd69fe70684">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88ebebe7-85c8-402c-8a96-0fd69fe70684">
											<gml:posList>35.674252781994866 139.73794114512074 25.06 35.67425172069553 139.73794407378364 25.06 35.67429493161702 139.7380795997262 25.06 35.67429732128302 139.73808090040905 25.06 35.674252781994866 139.73794114512074 25.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c4bec302-eced-4fcb-a31f-3c598b914bc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4bec302-eced-4fcb-a31f-3c598b914bc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4bec302-eced-4fcb-a31f-3c598b914bc6">
											<gml:posList>35.674132214794426 139.7379985329812 25.06 35.67414302221222 139.7380326436251 25.06 35.67414475219876 139.73803182410694 25.06 35.67414408351374 139.73802971496733 25.06 35.67413461346632 139.73799982260152 25.06 35.674132214794426 139.7379985329812 25.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-351d7255-82d9-46e6-95d1-a4290cd957c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-351d7255-82d9-46e6-95d1-a4290cd957c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-351d7255-82d9-46e6-95d1-a4290cd957c8">
											<gml:posList>35.67414302221222 139.7380326436251 27.468 35.67414584472077 139.73803417577187 27.468 35.67421033164879 139.73800347741843 27.468 35.674211581809054 139.73800000724063 27.468 35.67414302221222 139.7380326436251 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd1aa9e1-6a43-4d0d-b6f4-ad2df3b5f793">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd1aa9e1-6a43-4d0d-b6f4-ad2df3b5f793">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd1aa9e1-6a43-4d0d-b6f4-ad2df3b5f793">
											<gml:posList>35.67422187413301 139.73803246151252 27.468 35.674211581809054 139.73800000724063 27.468 35.67421033164879 139.73800347741843 27.468 35.674220235402785 139.73803469491185 27.468 35.67422227173327 139.73803372037375 27.468 35.67422187413301 139.73803246151252 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9bc2ff17-f301-4529-b93e-f632c6f7d298">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bc2ff17-f301-4529-b93e-f632c6f7d298">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bc2ff17-f301-4529-b93e-f632c6f7d298">
											<gml:posList>35.67415573945317 139.73806539325474 27.183 35.674220235402785 139.73803469491185 27.183 35.67421033164879 139.73800347741843 27.183 35.67414584472077 139.73803417577187 27.183 35.67415573945317 139.73806539325474 27.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27d97e93-aacc-460d-bfef-c72f4ab9931e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27d97e93-aacc-460d-bfef-c72f4ab9931e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27d97e93-aacc-460d-bfef-c72f4ab9931e">
											<gml:posList>35.67425172069553 139.73794407378364 24.423 35.67413461346632 139.73799982260152 24.423 35.67414408351374 139.73802971496733 24.423 35.67414475219876 139.73803182410694 24.423 35.674211581809054 139.73800000724063 24.423 35.67422187413301 139.73803246151252 24.423 35.674262772027525 139.73801300367606 24.423 35.67428345610759 139.73807828774585 24.423 35.67423681862344 139.73810048092986 24.423 35.6742326167601 139.7380872297734 24.423 35.674171526706566 139.73811631120344 24.423 35.67417760811001 139.73813549224138 24.423 35.67429493161702 139.7380795997262 24.423 35.67425172069553 139.73794407378364 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47b25917-d77a-4c58-8a34-fbf49fe0a86e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47b25917-d77a-4c58-8a34-fbf49fe0a86e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47b25917-d77a-4c58-8a34-fbf49fe0a86e">
											<gml:posList>35.6742236683347 139.7380330559062 29.762 35.67422268797296 139.73803575248803 29.762 35.67422846217107 139.73805398387333 29.762 35.67423067147563 139.7380551743008 29.762 35.6742236683347 139.7380330559062 29.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-054b7cb5-4db9-473c-8bb3-410b0bd9c542">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-054b7cb5-4db9-473c-8bb3-410b0bd9c542">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-054b7cb5-4db9-473c-8bb3-410b0bd9c542">
											<gml:posList>35.67414584472077 139.73803417577187 27.468 35.67414302221222 139.7380326436251 27.468 35.67415370311366 139.73806635674447 27.468 35.67415573945317 139.73806539325474 27.468 35.67414584472077 139.73803417577187 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e57d7649-191c-4c1e-9805-1be4cc6346f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e57d7649-191c-4c1e-9805-1be4cc6346f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e57d7649-191c-4c1e-9805-1be4cc6346f4">
											<gml:posList>35.67415370311366 139.73806635674447 29.762 35.674155903404404 139.73806754718188 29.762 35.67422268797296 139.73803575248803 29.762 35.6742236683347 139.7380330559062 29.762 35.67415370311366 139.73806635674447 29.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50c5392c-3e85-45b5-95ff-a072c6e7f3bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50c5392c-3e85-45b5-95ff-a072c6e7f3bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50c5392c-3e85-45b5-95ff-a072c6e7f3bf">
											<gml:posList>35.67422846217107 139.73805398387333 29.111 35.67422268797296 139.73803575248803 29.111 35.674155903404404 139.73806754718188 29.111 35.67416168661147 139.7380857785436 29.111 35.67422846217107 139.73805398387333 29.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-233f9999-4150-483c-8363-0bab61bfa7e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-233f9999-4150-483c-8363-0bab61bfa7e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-233f9999-4150-483c-8363-0bab61bfa7e1">
											<gml:posList>35.67423067147563 139.7380551743008 27.468 35.674160715262246 139.73808847511202 27.468 35.67416979671946 139.73811713072004 27.468 35.6742326167601 139.7380872297734 27.468 35.67423681862344 139.73810048092986 27.468 35.67428345610759 139.73807828774585 27.468 35.674262772027525 139.73801300367606 27.468 35.67422187413301 139.73803246151252 27.468 35.67422227173327 139.73803372037375 27.468 35.6742236683347 139.7380330559062 27.468 35.67423067147563 139.7380551743008 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d5b1e34-1db6-4c59-ba41-f57c603edbe7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d5b1e34-1db6-4c59-ba41-f57c603edbe7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d5b1e34-1db6-4c59-ba41-f57c603edbe7">
											<gml:posList>35.67423067147563 139.7380551743008 29.762 35.67422846217107 139.73805398387333 29.762 35.67416168661147 139.7380857785436 29.762 35.674160715262246 139.73808847511202 29.762 35.67423067147563 139.7380551743008 29.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e3dd51d0-25f3-4e1d-b8e1-265d5bf6a597">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3dd51d0-25f3-4e1d-b8e1-265d5bf6a597">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3dd51d0-25f3-4e1d-b8e1-265d5bf6a597">
											<gml:posList>35.674160715262246 139.73808847511202 29.762 35.67416168661147 139.7380857785436 29.762 35.674155903404404 139.73806754718188 29.762 35.67415370311366 139.73806635674447 29.762 35.674160715262246 139.73808847511202 29.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9999815-7485-4ee6-9a0d-54922e71dc4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9999815-7485-4ee6-9a0d-54922e71dc4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9999815-7485-4ee6-9a0d-54922e71dc4c">
											<gml:posList>35.67429732128302 139.73808090040905 25.06 35.67429493161702 139.7380795997262 25.06 35.67417760811001 139.73813549224138 25.06 35.67417654681466 139.73813843194577 25.06 35.67429732128302 139.73808090040905 25.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d4acc58-aa03-404c-a24c-2d37e8214d79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d4acc58-aa03-404c-a24c-2d37e8214d79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d4acc58-aa03-404c-a24c-2d37e8214d79">
											<gml:posList>35.67417654681466 139.73813843194577 19.633 35.674180992653994 139.73815245608077 19.633 35.67430182134237 139.73809509019955 19.633 35.67429732128302 139.73808090040905 19.633 35.67417654681466 139.73813843194577 19.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0409c1e5-5f08-4461-acea-2cfd0a25f1b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0409c1e5-5f08-4461-acea-2cfd0a25f1b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0409c1e5-5f08-4461-acea-2cfd0a25f1b6">
											<gml:posList>35.67417760811001 139.73813549224138 25.06 35.674171526706566 139.73811631120344 25.06 35.67416979671946 139.73811713072004 25.06 35.67417654681466 139.73813843194577 25.06 35.67417760811001 139.73813549224138 25.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d54ad020-f03c-4605-8fad-ddc57c0af58a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d54ad020-f03c-4605-8fad-ddc57c0af58a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d54ad020-f03c-4605-8fad-ddc57c0af58a">
											<gml:posList>35.674155903404404 139.73806754718188 29.762 35.674155903404404 139.73806754718188 29.111 35.67422268797296 139.73803575248803 29.111 35.67422268797296 139.73803575248803 29.762 35.674155903404404 139.73806754718188 29.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63d333ce-d144-4d7b-9d64-8561c0283de6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63d333ce-d144-4d7b-9d64-8561c0283de6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63d333ce-d144-4d7b-9d64-8561c0283de6">
											<gml:posList>35.67422846217107 139.73805398387333 29.762 35.67422846217107 139.73805398387333 29.111 35.67416168661147 139.7380857785436 29.111 35.67416168661147 139.7380857785436 29.762 35.67422846217107 139.73805398387333 29.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f31d5b94-ef1b-42d5-8890-b39d1a35c66b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f31d5b94-ef1b-42d5-8890-b39d1a35c66b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f31d5b94-ef1b-42d5-8890-b39d1a35c66b">
											<gml:posList>35.67414408351374 139.73802971496733 25.06 35.67414408351374 139.73802971496733 24.423 35.67413461346632 139.73799982260152 24.423 35.67413461346632 139.73799982260152 25.06 35.67414408351374 139.73802971496733 25.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cca5837d-a5bf-4067-adfd-5ee40afca034">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cca5837d-a5bf-4067-adfd-5ee40afca034">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cca5837d-a5bf-4067-adfd-5ee40afca034">
											<gml:posList>35.67414475219876 139.73803182410694 25.06 35.67414475219876 139.73803182410694 24.423 35.67414408351374 139.73802971496733 24.423 35.67414408351374 139.73802971496733 25.06 35.67414475219876 139.73803182410694 25.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6fa6333-82ba-4669-a72a-96cc07d69f0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6fa6333-82ba-4669-a72a-96cc07d69f0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6fa6333-82ba-4669-a72a-96cc07d69f0b">
											<gml:posList>35.67415573945317 139.73806539325474 27.468 35.67415573945317 139.73806539325474 27.183 35.67414584472077 139.73803417577187 27.183 35.67414584472077 139.73803417577187 27.468 35.67415573945317 139.73806539325474 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c22df2d-91ae-4f00-b6ef-8d5891c1af86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c22df2d-91ae-4f00-b6ef-8d5891c1af86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c22df2d-91ae-4f00-b6ef-8d5891c1af86">
											<gml:posList>35.674160715262246 139.73808847511202 27.468 35.674160715262246 139.73808847511202 29.762 35.67415370311366 139.73806635674447 29.762 35.67415370311366 139.73806635674447 27.468 35.67414302221222 139.7380326436251 27.468 35.67414302221222 139.7380326436251 25.06 35.674132214794426 139.7379985329812 25.06 35.67412388331972 139.73797224051776 20.628 35.67412388331972 139.73797224051776 8.429 35.674180992653994 139.73815245608077 8.429 35.674180992653994 139.73815245608077 19.633 35.67417654681466 139.73813843194577 19.633 35.67417654681466 139.73813843194577 25.06 35.67416979671946 139.73811713072004 25.06 35.67416979671946 139.73811713072004 27.468 35.674160715262246 139.73808847511202 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ae47f49-636b-48cc-895f-2bbc827cda18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ae47f49-636b-48cc-895f-2bbc827cda18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ae47f49-636b-48cc-895f-2bbc827cda18">
											<gml:posList>35.67416168661147 139.7380857785436 29.762 35.67416168661147 139.7380857785436 29.111 35.674155903404404 139.73806754718188 29.111 35.674155903404404 139.73806754718188 29.762 35.67416168661147 139.7380857785436 29.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cfd13de-5b95-4972-86ea-8140f4dba138">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cfd13de-5b95-4972-86ea-8140f4dba138">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cfd13de-5b95-4972-86ea-8140f4dba138">
											<gml:posList>35.674244712885965 139.73791608955216 8.429 35.67412388331972 139.73797224051776 8.429 35.67412388331972 139.73797224051776 20.628 35.674244712885965 139.73791608955216 20.628 35.674244712885965 139.73791608955216 8.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91c1a1ee-d433-4ef6-9a20-61180bee4206">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91c1a1ee-d433-4ef6-9a20-61180bee4206">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91c1a1ee-d433-4ef6-9a20-61180bee4206">
											<gml:posList>35.67413461346632 139.73799982260152 25.06 35.67413461346632 139.73799982260152 24.423 35.67425172069553 139.73794407378364 24.423 35.67425172069553 139.73794407378364 25.06 35.67413461346632 139.73799982260152 25.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26ff4943-5052-4b62-a33b-6bb2daaf27ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26ff4943-5052-4b62-a33b-6bb2daaf27ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26ff4943-5052-4b62-a33b-6bb2daaf27ca">
											<gml:posList>35.674244712885965 139.73791608955216 20.628 35.674252781994866 139.73794114512074 25.06 35.67429732128302 139.73808090040905 25.06 35.67429732128302 139.73808090040905 19.633 35.67430182134237 139.73809509019955 19.633 35.67430182134237 139.73809509019955 8.429 35.674244712885965 139.73791608955216 8.429 35.674244712885965 139.73791608955216 20.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2cd0162-1e1b-45e5-b8bc-5fd6be908081">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2cd0162-1e1b-45e5-b8bc-5fd6be908081">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2cd0162-1e1b-45e5-b8bc-5fd6be908081">
											<gml:posList>35.67425172069553 139.73794407378364 25.06 35.67425172069553 139.73794407378364 24.423 35.67429493161702 139.7380795997262 24.423 35.67429493161702 139.7380795997262 25.06 35.67425172069553 139.73794407378364 25.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a8e6cfa-186c-4214-8590-25c14457a0ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a8e6cfa-186c-4214-8590-25c14457a0ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a8e6cfa-186c-4214-8590-25c14457a0ce">
											<gml:posList>35.674211581809054 139.73800000724063 27.468 35.67422187413301 139.73803246151252 27.468 35.67422187413301 139.73803246151252 24.423 35.674211581809054 139.73800000724063 24.423 35.674211581809054 139.73800000724063 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0c3c651-3a54-47f8-84b2-30d5ea6f1537">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0c3c651-3a54-47f8-84b2-30d5ea6f1537">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0c3c651-3a54-47f8-84b2-30d5ea6f1537">
											<gml:posList>35.67414475219876 139.73803182410694 25.06 35.67414302221222 139.7380326436251 25.06 35.67414302221222 139.7380326436251 27.468 35.674211581809054 139.73800000724063 27.468 35.674211581809054 139.73800000724063 24.423 35.67414475219876 139.73803182410694 24.423 35.67414475219876 139.73803182410694 25.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2ccd96d-4bc4-4630-9b07-04b2fcbcff4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2ccd96d-4bc4-4630-9b07-04b2fcbcff4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2ccd96d-4bc4-4630-9b07-04b2fcbcff4f">
											<gml:posList>35.67414584472077 139.73803417577187 27.468 35.67414584472077 139.73803417577187 27.183 35.67421033164879 139.73800347741843 27.183 35.67421033164879 139.73800347741843 27.468 35.67414584472077 139.73803417577187 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2e85f36-57c6-41ff-81e1-9244e7eef740">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2e85f36-57c6-41ff-81e1-9244e7eef740">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2e85f36-57c6-41ff-81e1-9244e7eef740">
											<gml:posList>35.67421033164879 139.73800347741843 27.468 35.67421033164879 139.73800347741843 27.183 35.674220235402785 139.73803469491185 27.183 35.674220235402785 139.73803469491185 27.468 35.67421033164879 139.73800347741843 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3de4693-128a-4a66-b74e-c1d77f011755">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3de4693-128a-4a66-b74e-c1d77f011755">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3de4693-128a-4a66-b74e-c1d77f011755">
											<gml:posList>35.67422187413301 139.73803246151252 27.468 35.674262772027525 139.73801300367606 27.468 35.674262772027525 139.73801300367606 24.423 35.67422187413301 139.73803246151252 24.423 35.67422187413301 139.73803246151252 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f3aee23-f26a-419c-93ff-01dc60fe0933">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f3aee23-f26a-419c-93ff-01dc60fe0933">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f3aee23-f26a-419c-93ff-01dc60fe0933">
											<gml:posList>35.6742236683347 139.7380330559062 27.468 35.6742236683347 139.7380330559062 29.762 35.67423067147563 139.7380551743008 29.762 35.67423067147563 139.7380551743008 27.468 35.6742236683347 139.7380330559062 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f11fe84-4e7d-43a7-b68e-dc805ffcbafe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f11fe84-4e7d-43a7-b68e-dc805ffcbafe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f11fe84-4e7d-43a7-b68e-dc805ffcbafe">
											<gml:posList>35.67422268797296 139.73803575248803 29.762 35.67422268797296 139.73803575248803 29.111 35.67422846217107 139.73805398387333 29.111 35.67422846217107 139.73805398387333 29.762 35.67422268797296 139.73803575248803 29.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ec1c557-9ca3-482f-9f3f-3046e13fa042">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ec1c557-9ca3-482f-9f3f-3046e13fa042">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ec1c557-9ca3-482f-9f3f-3046e13fa042">
											<gml:posList>35.674262772027525 139.73801300367606 27.468 35.67428345610759 139.73807828774585 27.468 35.67428345610759 139.73807828774585 24.423 35.674262772027525 139.73801300367606 24.423 35.674262772027525 139.73801300367606 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7349dd90-ae4a-4a3c-8704-f60e9876a337">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7349dd90-ae4a-4a3c-8704-f60e9876a337">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7349dd90-ae4a-4a3c-8704-f60e9876a337">
											<gml:posList>35.67415370311366 139.73806635674447 29.762 35.6742236683347 139.7380330559062 29.762 35.6742236683347 139.7380330559062 27.468 35.67422227173327 139.73803372037375 27.468 35.674220235402785 139.73803469491185 27.468 35.674220235402785 139.73803469491185 27.183 35.67415573945317 139.73806539325474 27.183 35.67415573945317 139.73806539325474 27.468 35.67415370311366 139.73806635674447 27.468 35.67415370311366 139.73806635674447 29.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75f7a2d7-adf7-4281-b4e2-ba776f7c7efc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75f7a2d7-adf7-4281-b4e2-ba776f7c7efc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75f7a2d7-adf7-4281-b4e2-ba776f7c7efc">
											<gml:posList>35.67423067147563 139.7380551743008 27.468 35.67423067147563 139.7380551743008 29.762 35.674160715262246 139.73808847511202 29.762 35.674160715262246 139.73808847511202 27.468 35.67423067147563 139.7380551743008 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3b66e75-514f-4948-ae0d-826a8c826df5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3b66e75-514f-4948-ae0d-826a8c826df5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3b66e75-514f-4948-ae0d-826a8c826df5">
											<gml:posList>35.67423681862344 139.73810048092986 24.423 35.67428345610759 139.73807828774585 24.423 35.67428345610759 139.73807828774585 27.468 35.67423681862344 139.73810048092986 27.468 35.67423681862344 139.73810048092986 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9796a63-5bc7-42e5-b30e-08f45352bdc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9796a63-5bc7-42e5-b30e-08f45352bdc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9796a63-5bc7-42e5-b30e-08f45352bdc3">
											<gml:posList>35.6742326167601 139.7380872297734 24.423 35.67423681862344 139.73810048092986 24.423 35.67423681862344 139.73810048092986 27.468 35.6742326167601 139.7380872297734 27.468 35.6742326167601 139.7380872297734 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-567d3788-d7c1-46a5-9ae7-547237cf2674">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-567d3788-d7c1-46a5-9ae7-547237cf2674">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-567d3788-d7c1-46a5-9ae7-547237cf2674">
											<gml:posList>35.6742326167601 139.7380872297734 24.423 35.6742326167601 139.7380872297734 27.468 35.67416979671946 139.73811713072004 27.468 35.67416979671946 139.73811713072004 25.06 35.674171526706566 139.73811631120344 25.06 35.674171526706566 139.73811631120344 24.423 35.6742326167601 139.7380872297734 24.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41ec5a4d-2fc2-4ed0-a018-4e05c3d11966">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41ec5a4d-2fc2-4ed0-a018-4e05c3d11966">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41ec5a4d-2fc2-4ed0-a018-4e05c3d11966">
											<gml:posList>35.67429493161702 139.7380795997262 25.06 35.67429493161702 139.7380795997262 24.423 35.67417760811001 139.73813549224138 24.423 35.67417760811001 139.73813549224138 25.06 35.67429493161702 139.7380795997262 25.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62bd2202-5043-4f8c-993a-1a516dc6ecf7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62bd2202-5043-4f8c-993a-1a516dc6ecf7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62bd2202-5043-4f8c-993a-1a516dc6ecf7">
											<gml:posList>35.67429732128302 139.73808090040905 19.633 35.67429732128302 139.73808090040905 25.06 35.67417654681466 139.73813843194577 25.06 35.67417654681466 139.73813843194577 19.633 35.67429732128302 139.73808090040905 19.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c10fa623-0e78-4f0c-97df-84e5ec2296fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c10fa623-0e78-4f0c-97df-84e5ec2296fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c10fa623-0e78-4f0c-97df-84e5ec2296fc">
											<gml:posList>35.674180992653994 139.73815245608077 8.429 35.67430182134237 139.73809509019955 8.429 35.67430182134237 139.73809509019955 19.633 35.674180992653994 139.73815245608077 19.633 35.674180992653994 139.73815245608077 8.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f07beadf-a03a-462d-b0d4-4451bb740e9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f07beadf-a03a-462d-b0d4-4451bb740e9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f07beadf-a03a-462d-b0d4-4451bb740e9a">
											<gml:posList>35.67417760811001 139.73813549224138 25.06 35.67417760811001 139.73813549224138 24.423 35.674171526706566 139.73811631120344 24.423 35.674171526706566 139.73811631120344 25.06 35.67417760811001 139.73813549224138 25.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5610</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">250.69195</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.14</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>