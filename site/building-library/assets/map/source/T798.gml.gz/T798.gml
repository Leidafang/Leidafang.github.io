<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e5159a83-8cad-45f4-99b5-9a58f2d0b940">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">5.6</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67181815777036 139.7451930920427 0 35.67182240234383 139.74519187226593 0 35.67181862924329 139.74517223581154 0 35.67181303289484 139.74517384370176 0 35.67181219138357 139.74516942604419 0 35.67175122637414 139.74518700170665 0 35.671766038304185 139.74526415592743 0 35.67177738419648 139.74526088476065 0 35.67179260323851 139.74534014844625 0 35.671843565138126 139.74532545595207 0 35.67181815777036 139.7451930920427 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181815777036 139.7451930920427 8.954 35.671843565138126 139.74532545595207 8.954 35.67179260323851 139.74534014844625 8.954 35.67177738419648 139.74526088476065 8.954 35.671766038304185 139.74526415592743 8.954 35.67175122637414 139.74518700170665 8.954 35.67181219138357 139.74516942604419 8.954 35.67181303289484 139.74517384370176 8.954 35.67181862924329 139.74517223581154 8.954 35.67182240234383 139.74519187226593 8.954 35.67181815777036 139.7451930920427 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181815777036 139.7451930920427 8.954 35.67182240234383 139.74519187226593 8.954 35.67182240234383 139.74519187226593 14.59 35.67181815777036 139.7451930920427 14.59 35.67181815777036 139.7451930920427 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67182240234383 139.74519187226593 8.954 35.67181862924329 139.74517223581154 8.954 35.67181862924329 139.74517223581154 14.59 35.67182240234383 139.74519187226593 14.59 35.67182240234383 139.74519187226593 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181862924329 139.74517223581154 8.954 35.67181303289484 139.74517384370176 8.954 35.67181303289484 139.74517384370176 14.59 35.67181862924329 139.74517223581154 14.59 35.67181862924329 139.74517223581154 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181303289484 139.74517384370176 8.954 35.67181219138357 139.74516942604419 8.954 35.67181219138357 139.74516942604419 14.59 35.67181303289484 139.74517384370176 14.59 35.67181303289484 139.74517384370176 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181219138357 139.74516942604419 8.954 35.67175122637414 139.74518700170665 8.954 35.67175122637414 139.74518700170665 14.59 35.67181219138357 139.74516942604419 14.59 35.67181219138357 139.74516942604419 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67175122637414 139.74518700170665 8.954 35.671766038304185 139.74526415592743 8.954 35.671766038304185 139.74526415592743 14.59 35.67175122637414 139.74518700170665 14.59 35.67175122637414 139.74518700170665 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671766038304185 139.74526415592743 8.954 35.67177738419648 139.74526088476065 8.954 35.67177738419648 139.74526088476065 14.59 35.671766038304185 139.74526415592743 14.59 35.671766038304185 139.74526415592743 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67177738419648 139.74526088476065 8.954 35.67179260323851 139.74534014844625 8.954 35.67179260323851 139.74534014844625 14.59 35.67177738419648 139.74526088476065 14.59 35.67177738419648 139.74526088476065 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179260323851 139.74534014844625 8.954 35.671843565138126 139.74532545595207 8.954 35.671843565138126 139.74532545595207 14.59 35.67179260323851 139.74534014844625 14.59 35.67179260323851 139.74534014844625 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671843565138126 139.74532545595207 8.954 35.67181815777036 139.7451930920427 8.954 35.67181815777036 139.7451930920427 14.59 35.671843565138126 139.74532545595207 14.59 35.671843565138126 139.74532545595207 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181815777036 139.7451930920427 14.59 35.67182240234383 139.74519187226593 14.59 35.67181862924329 139.74517223581154 14.59 35.67181303289484 139.74517384370176 14.59 35.67181219138357 139.74516942604419 14.59 35.67175122637414 139.74518700170665 14.59 35.671766038304185 139.74526415592743 14.59 35.67177738419648 139.74526088476065 14.59 35.67179260323851 139.74534014844625 14.59 35.671843565138126 139.74532545595207 14.59 35.67181815777036 139.7451930920427 14.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-29b7c30d-ea45-46bc-b201-2c2c5defc541"/>
							<gml:surfaceMember xlink:href="#poly-d78925f4-915e-4567-a26a-78c6378a5528"/>
							<gml:surfaceMember xlink:href="#poly-0f1e2015-1619-4e68-a65d-121aa86a6f1c"/>
							<gml:surfaceMember xlink:href="#poly-f7e4492d-405b-42e8-b9e2-0033e3476953"/>
							<gml:surfaceMember xlink:href="#poly-570969db-fe9e-4287-bf8d-9e5c76e9ae3f"/>
							<gml:surfaceMember xlink:href="#poly-dc264d0e-cbc9-4265-bd18-1101c6e174a7"/>
							<gml:surfaceMember xlink:href="#poly-c3061f7f-ab86-4ac0-ab4b-595c032f02d2"/>
							<gml:surfaceMember xlink:href="#poly-16a82484-e88f-4b5b-94cb-7147658ece00"/>
							<gml:surfaceMember xlink:href="#poly-5f64682f-cb5d-4b17-90f6-6f986bc5c09d"/>
							<gml:surfaceMember xlink:href="#poly-467dd272-370f-4478-9ae1-ebdb0e461aaa"/>
							<gml:surfaceMember xlink:href="#poly-f2aaed37-3d1c-4bfa-889c-d5a70c066b55"/>
							<gml:surfaceMember xlink:href="#poly-abc5ce13-dd5c-4d66-8b27-60c6a00c5774"/>
							<gml:surfaceMember xlink:href="#poly-47c7bddb-572a-4f23-88dc-c88a1a7b0f47"/>
							<gml:surfaceMember xlink:href="#poly-b5499042-bd83-46e3-bad6-9e46da368800"/>
							<gml:surfaceMember xlink:href="#poly-a3340247-eaf3-4dab-9670-e46e2dc65093"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-29b7c30d-ea45-46bc-b201-2c2c5defc541">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29b7c30d-ea45-46bc-b201-2c2c5defc541">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29b7c30d-ea45-46bc-b201-2c2c5defc541">
											<gml:posList>35.67177738419645 139.74526088476065 8.954 35.67176603830418 139.7452641559274 8.954 35.67175122637413 139.74518700170668 8.954 35.67181219138354 139.74516942604419 8.954 35.671813032894825 139.74517384370176 8.954 35.67181862924328 139.7451722358115 8.954 35.67182240234382 139.7451918722659 8.954 35.67181815777036 139.7451930920427 8.954 35.67184356513812 139.74532545595207 8.954 35.67179260323849 139.74534014844625 8.954 35.67177738419645 139.74526088476065 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d78925f4-915e-4567-a26a-78c6378a5528">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d78925f4-915e-4567-a26a-78c6378a5528">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d78925f4-915e-4567-a26a-78c6378a5528">
											<gml:posList>35.67176257226433 139.74518373052962 14.288 35.67175122637413 139.74518700170668 11.846 35.671761324200176 139.7452396158934 11.846 35.67177267009179 139.74523634472337 14.288 35.67176257226433 139.74518373052962 14.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0f1e2015-1619-4e68-a65d-121aa86a6f1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f1e2015-1619-4e68-a65d-121aa86a6f1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f1e2015-1619-4e68-a65d-121aa86a6f1c">
											<gml:posList>35.67176603830418 139.7452641559274 11.5 35.67177738419645 139.74526088476065 11.5 35.67177267009179 139.74523634472337 11.5 35.671761324200176 139.7452396158934 11.5 35.67176603830418 139.7452641559274 11.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7e4492d-405b-42e8-b9e2-0033e3476953">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7e4492d-405b-42e8-b9e2-0033e3476953">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7e4492d-405b-42e8-b9e2-0033e3476953">
											<gml:posList>35.67181815777036 139.7451930920427 14.824 35.67182240234382 139.7451918722659 14.824 35.67181862924328 139.7451722358115 14.824 35.671813032894825 139.74517384370176 14.824 35.67181219138354 139.74516942604419 14.824 35.67176257226433 139.74518373052962 14.824 35.67179260323849 139.74534014844625 14.824 35.67184356513812 139.74532545595207 14.824 35.67181815777036 139.7451930920427 14.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-570969db-fe9e-4287-bf8d-9e5c76e9ae3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-570969db-fe9e-4287-bf8d-9e5c76e9ae3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-570969db-fe9e-4287-bf8d-9e5c76e9ae3f">
											<gml:posList>35.671813032894825 139.74517384370176 8.954 35.67181219138354 139.74516942604419 8.954 35.67181219138354 139.74516942604419 14.824 35.671813032894825 139.74517384370176 14.824 35.671813032894825 139.74517384370176 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc264d0e-cbc9-4265-bd18-1101c6e174a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc264d0e-cbc9-4265-bd18-1101c6e174a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc264d0e-cbc9-4265-bd18-1101c6e174a7">
											<gml:posList>35.67181862924328 139.7451722358115 8.954 35.671813032894825 139.74517384370176 8.954 35.671813032894825 139.74517384370176 14.824 35.67181862924328 139.7451722358115 14.824 35.67181862924328 139.7451722358115 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3061f7f-ab86-4ac0-ab4b-595c032f02d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3061f7f-ab86-4ac0-ab4b-595c032f02d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3061f7f-ab86-4ac0-ab4b-595c032f02d2">
											<gml:posList>35.67176257226433 139.74518373052962 14.288 35.67176257226433 139.74518373052962 14.824 35.67181219138354 139.74516942604419 14.824 35.67181219138354 139.74516942604419 8.954 35.67175122637413 139.74518700170668 8.954 35.67175122637413 139.74518700170668 11.846 35.67176257226433 139.74518373052962 14.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16a82484-e88f-4b5b-94cb-7147658ece00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16a82484-e88f-4b5b-94cb-7147658ece00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16a82484-e88f-4b5b-94cb-7147658ece00">
											<gml:posList>35.67182240234382 139.7451918722659 8.954 35.67181862924328 139.7451722358115 8.954 35.67181862924328 139.7451722358115 14.824 35.67182240234382 139.7451918722659 14.824 35.67182240234382 139.7451918722659 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f64682f-cb5d-4b17-90f6-6f986bc5c09d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f64682f-cb5d-4b17-90f6-6f986bc5c09d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f64682f-cb5d-4b17-90f6-6f986bc5c09d">
											<gml:posList>35.67181815777036 139.7451930920427 8.954 35.67182240234382 139.7451918722659 8.954 35.67182240234382 139.7451918722659 14.824 35.67181815777036 139.7451930920427 14.824 35.67181815777036 139.7451930920427 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-467dd272-370f-4478-9ae1-ebdb0e461aaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-467dd272-370f-4478-9ae1-ebdb0e461aaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-467dd272-370f-4478-9ae1-ebdb0e461aaa">
											<gml:posList>35.67175122637413 139.74518700170668 11.846 35.67175122637413 139.74518700170668 8.954 35.67176603830418 139.7452641559274 8.954 35.67176603830418 139.7452641559274 11.5 35.671761324200176 139.7452396158934 11.5 35.671761324200176 139.7452396158934 11.846 35.67175122637413 139.74518700170668 11.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2aaed37-3d1c-4bfa-889c-d5a70c066b55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2aaed37-3d1c-4bfa-889c-d5a70c066b55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2aaed37-3d1c-4bfa-889c-d5a70c066b55">
											<gml:posList>35.67177267009179 139.74523634472337 11.5 35.67177267009179 139.74523634472337 14.288 35.671761324200176 139.7452396158934 11.846 35.671761324200176 139.7452396158934 11.5 35.67177267009179 139.74523634472337 11.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abc5ce13-dd5c-4d66-8b27-60c6a00c5774">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abc5ce13-dd5c-4d66-8b27-60c6a00c5774">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abc5ce13-dd5c-4d66-8b27-60c6a00c5774">
											<gml:posList>35.67184356513812 139.74532545595207 8.954 35.67181815777036 139.7451930920427 8.954 35.67181815777036 139.7451930920427 14.824 35.67184356513812 139.74532545595207 14.824 35.67184356513812 139.74532545595207 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47c7bddb-572a-4f23-88dc-c88a1a7b0f47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47c7bddb-572a-4f23-88dc-c88a1a7b0f47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47c7bddb-572a-4f23-88dc-c88a1a7b0f47">
											<gml:posList>35.67177738419645 139.74526088476065 11.5 35.67177738419645 139.74526088476065 8.954 35.67179260323849 139.74534014844625 8.954 35.67179260323849 139.74534014844625 14.824 35.67176257226433 139.74518373052962 14.824 35.67176257226433 139.74518373052962 14.288 35.67177267009179 139.74523634472337 14.288 35.67177267009179 139.74523634472337 11.5 35.67177738419645 139.74526088476065 11.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5499042-bd83-46e3-bad6-9e46da368800">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5499042-bd83-46e3-bad6-9e46da368800">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5499042-bd83-46e3-bad6-9e46da368800">
											<gml:posList>35.67176603830418 139.7452641559274 8.954 35.67177738419645 139.74526088476065 8.954 35.67177738419645 139.74526088476065 11.5 35.67176603830418 139.7452641559274 11.5 35.67176603830418 139.7452641559274 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3340247-eaf3-4dab-9670-e46e2dc65093">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3340247-eaf3-4dab-9670-e46e2dc65093">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3340247-eaf3-4dab-9670-e46e2dc65093">
											<gml:posList>35.67179260323849 139.74534014844625 8.954 35.67184356513812 139.74532545595207 8.954 35.67184356513812 139.74532545595207 14.824 35.67179260323849 139.74534014844625 14.824 35.67179260323849 139.74534014844625 8.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-2380</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>