<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e52606fc-15a6-459d-9443-570dc8afa538">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">26</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669260926348734 139.7419525457009 0 35.66923913860839 139.74195050491085 0 35.66923587688529 139.74198778922232 0 35.66935739370846 139.74200322581208 0 35.669363562724065 139.74193672114563 0 35.669263536172174 139.7419233147307 0 35.669260926348734 139.7419525457009 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669260926348734 139.7419525457009 10.027 35.669263536172174 139.7419233147307 10.027 35.669363562724065 139.74193672114563 10.027 35.66935739370846 139.74200322581208 10.027 35.66923587688529 139.74198778922232 10.027 35.66923913860839 139.74195050491085 10.027 35.669260926348734 139.7419525457009 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669260926348734 139.7419525457009 10.027 35.66923913860839 139.74195050491085 10.027 35.66923913860839 139.74195050491085 36.02 35.669260926348734 139.7419525457009 36.02 35.669260926348734 139.7419525457009 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923913860839 139.74195050491085 10.027 35.66923587688529 139.74198778922232 10.027 35.66923587688529 139.74198778922232 36.02 35.66923913860839 139.74195050491085 36.02 35.66923913860839 139.74195050491085 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923587688529 139.74198778922232 10.027 35.66935739370846 139.74200322581208 10.027 35.66935739370846 139.74200322581208 36.02 35.66923587688529 139.74198778922232 36.02 35.66923587688529 139.74198778922232 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66935739370846 139.74200322581208 10.027 35.669363562724065 139.74193672114563 10.027 35.669363562724065 139.74193672114563 36.02 35.66935739370846 139.74200322581208 36.02 35.66935739370846 139.74200322581208 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669363562724065 139.74193672114563 10.027 35.669263536172174 139.7419233147307 10.027 35.669263536172174 139.7419233147307 36.02 35.669363562724065 139.74193672114563 36.02 35.669363562724065 139.74193672114563 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669263536172174 139.7419233147307 10.027 35.669260926348734 139.7419525457009 10.027 35.669260926348734 139.7419525457009 36.02 35.669263536172174 139.7419233147307 36.02 35.669263536172174 139.7419233147307 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669260926348734 139.7419525457009 36.02 35.66923913860839 139.74195050491085 36.02 35.66923587688529 139.74198778922232 36.02 35.66935739370846 139.74200322581208 36.02 35.669363562724065 139.74193672114563 36.02 35.669263536172174 139.7419233147307 36.02 35.669260926348734 139.7419525457009 36.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0a180f6b-9c25-48d8-8c58-0f8c5307f459"/>
							<gml:surfaceMember xlink:href="#poly-923d1172-0582-4c54-a566-89b4ba2f1478"/>
							<gml:surfaceMember xlink:href="#poly-500843a9-ab96-4239-852b-102435c19df6"/>
							<gml:surfaceMember xlink:href="#poly-25039189-15a6-47de-b796-d6bf7b7d3504"/>
							<gml:surfaceMember xlink:href="#poly-00b1697b-29ee-4b6e-914c-19779f4d8bf6"/>
							<gml:surfaceMember xlink:href="#poly-874826a1-b912-44e2-8a52-7d01704869df"/>
							<gml:surfaceMember xlink:href="#poly-e2f87e27-e8c7-475c-8196-c0dd2477bea2"/>
							<gml:surfaceMember xlink:href="#poly-99a843ee-97df-46b0-a312-49e9af69c1b1"/>
							<gml:surfaceMember xlink:href="#poly-a283d1ab-bcba-4015-9267-287c3006d971"/>
							<gml:surfaceMember xlink:href="#poly-4ccaacba-0eaa-4480-a405-584c259d4ac6"/>
							<gml:surfaceMember xlink:href="#poly-ed9d8b57-af43-43a6-89fa-b441b05dc1b5"/>
							<gml:surfaceMember xlink:href="#poly-d5eb99f8-1c9d-4114-8b74-2bfb88b1b531"/>
							<gml:surfaceMember xlink:href="#poly-50de1fb4-6bb6-4fcd-b67f-0485f711e440"/>
							<gml:surfaceMember xlink:href="#poly-236778ae-a44f-4187-aad7-aa1a7a7bd7ab"/>
							<gml:surfaceMember xlink:href="#poly-3f0dd5c1-430e-412f-885e-b9528261cbe2"/>
							<gml:surfaceMember xlink:href="#poly-05e7205f-40c8-4a57-bacf-20cb1dfe37df"/>
							<gml:surfaceMember xlink:href="#poly-d8a4c381-7e15-4fbc-988b-87d82b120e83"/>
							<gml:surfaceMember xlink:href="#poly-1ef6622e-6d25-4d0b-b79b-f83c1b582955"/>
							<gml:surfaceMember xlink:href="#poly-c71e62b5-dc4c-4c5c-b94b-5492fccbb462"/>
							<gml:surfaceMember xlink:href="#poly-8fe3dc23-a026-4f27-89da-35fc7456f5af"/>
							<gml:surfaceMember xlink:href="#poly-44d928a7-1329-494d-8636-ff8189286426"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e52606fc-15a6-459d-9443-570dc8afa538_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-402d53a1-4862-4631-9922-b8eef12d66d0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669240589237006 139.74196161563677 39.6 35.66923853393977 139.74198515722296 39.6 35.669269318801355 139.74198906561054 39.6 35.66926909543574 139.74199167274614 39.6 35.669236192239964 139.74198762317155 39.6 35.669238497826555 139.74196131977533 39.6 35.669240589237006 139.74196161563677 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-052fe913-9263-4c2d-a0b0-28927a04b7ba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669269318801355 139.74198906561054 38.473 35.66923853393977 139.74198515722296 38.473 35.669240589237006 139.74196161563677 38.473 35.66927138336452 139.74196585538803 38.473 35.669269318801355 139.74198906561054 38.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b121eb27-d666-4269-b876-2c83ab05cdfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b121eb27-d666-4269-b876-2c83ab05cdfb_0">
											<gml:posList>35.669236192239964 139.74198762317155 39.6 35.669236192239964 139.74198762317155 43.522 35.669238497826555 139.74196131977533 43.522 35.669238497826555 139.74196131977533 39.6 35.669236192239964 139.74198762317155 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31be6ce1-b90b-469b-b1fe-d28fb74c5aa6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31be6ce1-b90b-469b-b1fe-d28fb74c5aa6_0">
											<gml:posList>35.66923853393977 139.74198515722296 39.6 35.669240589237006 139.74196161563677 39.6 35.669240589237006 139.74196161563677 38.473 35.66923853393977 139.74198515722296 38.473 35.66923853393977 139.74198515722296 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28a60f92-56b8-4255-aa54-d48a6706d53e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28a60f92-56b8-4255-aa54-d48a6706d53e_0">
											<gml:posList>35.66926909543574 139.74199167274614 39.6 35.66926909543574 139.74199167274614 43.522 35.669236192239964 139.74198762317155 43.522 35.669236192239964 139.74198762317155 39.6 35.66926909543574 139.74199167274614 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-847d866d-bd45-4566-948f-9307731ed525">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-847d866d-bd45-4566-948f-9307731ed525_0">
											<gml:posList>35.66926909543574 139.74199167274614 43.522 35.66927138336452 139.74196585538803 43.522 35.669238497826555 139.74196131977533 43.522 35.669236192239964 139.74198762317155 43.522 35.66926909543574 139.74199167274614 43.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3c528fa-2e12-4756-af3a-92715701dae5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3c528fa-2e12-4756-af3a-92715701dae5_0">
											<gml:posList>35.669269318801355 139.74198906561054 38.473 35.669269318801355 139.74198906561054 39.6 35.66923853393977 139.74198515722296 39.6 35.66923853393977 139.74198515722296 38.473 35.669269318801355 139.74198906561054 38.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd20710a-8237-4a57-b0db-56e87fc73c76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd20710a-8237-4a57-b0db-56e87fc73c76_0">
											<gml:posList>35.669240589237006 139.74196161563677 39.6 35.669238497826555 139.74196131977533 39.6 35.669238497826555 139.74196131977533 43.522 35.66927138336452 139.74196585538803 43.522 35.66927138336452 139.74196585538803 38.473 35.669240589237006 139.74196161563677 38.473 35.669240589237006 139.74196161563677 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d4bddd2-34d2-494b-85b6-5b6d5c436159">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d4bddd2-34d2-494b-85b6-5b6d5c436159_0">
											<gml:posList>35.66927138336452 139.74196585538803 38.473 35.66927138336452 139.74196585538803 43.522 35.66926909543574 139.74199167274614 43.522 35.66926909543574 139.74199167274614 39.6 35.669269318801355 139.74198906561054 39.6 35.669269318801355 139.74198906561054 38.473 35.66927138336452 139.74196585538803 38.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e52606fc-15a6-459d-9443-570dc8afa538_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ecec2c3-11bf-436e-979f-1200448712e4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924177481006 139.74192040127636 10.11 35.669263536172174 139.7419233147307 10.11 35.66926092634873 139.74195254570088 10.11 35.669239138608376 139.74195050491085 10.11 35.66924177481006 139.74192040127636 10.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7145bf18-1e61-40a7-b2fe-02030b19bc53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7145bf18-1e61-40a7-b2fe-02030b19bc53_0">
											<gml:posList>35.669263536172174 139.7419233147307 39.6 35.669263536172174 139.7419233147307 10.11 35.66924177481006 139.74192040127636 10.11 35.66924177481006 139.74192040127636 39.6 35.669263536172174 139.7419233147307 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d22e3bec-639a-4cb1-b8ff-c9c80677337e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d22e3bec-639a-4cb1-b8ff-c9c80677337e_0">
											<gml:posList>35.66924177481006 139.74192040127636 39.6 35.66924177481006 139.74192040127636 10.11 35.669239138608376 139.74195050491085 10.11 35.669239138608376 139.74195050491085 39.6 35.66924177481006 139.74192040127636 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-449cb2af-c7fa-4b1e-9bab-62425e046821">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-449cb2af-c7fa-4b1e-9bab-62425e046821_0">
											<gml:posList>35.669239138608376 139.74195050491085 39.6 35.66926092634873 139.74195254570088 39.6 35.669263536172174 139.7419233147307 39.6 35.66924177481006 139.74192040127636 39.6 35.669239138608376 139.74195050491085 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35096a56-7b68-40c1-b518-8270f2e9f5ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35096a56-7b68-40c1-b518-8270f2e9f5ae_0">
											<gml:posList>35.66926092634873 139.74195254570088 39.6 35.66926092634873 139.74195254570088 10.11 35.669263536172174 139.7419233147307 10.11 35.669263536172174 139.7419233147307 39.6 35.66926092634873 139.74195254570088 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0b5395d-991c-4334-b5ee-e5a819cd53f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0b5395d-991c-4334-b5ee-e5a819cd53f8_0">
											<gml:posList>35.669239138608376 139.74195050491085 39.6 35.669239138608376 139.74195050491085 10.11 35.66926092634873 139.74195254570088 10.11 35.66926092634873 139.74195254570088 39.6 35.669239138608376 139.74195050491085 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e52606fc-15a6-459d-9443-570dc8afa538_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-150035a5-8ebe-456d-bd78-1701c52cda5f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66926836146452 139.74195094658788 38.473 35.669269492726634 139.74193318315923 38.473 35.669285249882876 139.74193470060635 38.473 35.66928411862055 139.7419524640385 38.473 35.66926836146452 139.74195094658788 38.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1c724be-b475-472e-9508-2a917412d9d4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924531806957 139.7419690442754 43.522 35.6692617516906 139.74197113535584 43.522 35.669260259790114 139.74198878873207 43.522 35.669243826169364 139.7419866976481 43.522 35.66924531806957 139.7419690442754 43.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6db0cf1c-3768-4fb2-bca0-7b84cdb7df89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6db0cf1c-3768-4fb2-bca0-7b84cdb7df89_0">
											<gml:posList>35.669285249882876 139.74193470060635 38.473 35.669269492726634 139.74193318315923 38.473 35.669269492726634 139.74193318315923 41.739 35.669285249882876 139.74193470060635 41.739 35.669285249882876 139.74193470060635 38.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-473dcafc-8394-4b4c-a23e-0feef6319280">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-473dcafc-8394-4b4c-a23e-0feef6319280_0">
											<gml:posList>35.66926836146452 139.74195094658788 38.473 35.66926836146452 139.74195094658788 41.739 35.669269492726634 139.74193318315923 41.739 35.669269492726634 139.74193318315923 38.473 35.66926836146452 139.74195094658788 38.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f22305a1-d4d2-48fc-a6b7-ede72f163569">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f22305a1-d4d2-48fc-a6b7-ede72f163569_0">
											<gml:posList>35.66926836146452 139.74195094658788 41.739 35.66928411862055 139.7419524640385 41.739 35.669285249882876 139.74193470060635 41.739 35.669269492726634 139.74193318315923 41.739 35.66926836146452 139.74195094658788 41.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce6c0e3f-bf00-4b41-9eb8-f61f008b93be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce6c0e3f-bf00-4b41-9eb8-f61f008b93be_0">
											<gml:posList>35.66928411862055 139.7419524640385 38.473 35.669285249882876 139.74193470060635 38.473 35.669285249882876 139.74193470060635 41.739 35.66928411862055 139.7419524640385 41.739 35.66928411862055 139.7419524640385 38.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0d9a56a-f86b-40f7-92d5-1ff2932ae706">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0d9a56a-f86b-40f7-92d5-1ff2932ae706_0">
											<gml:posList>35.66926836146452 139.74195094658788 38.473 35.66928411862055 139.7419524640385 38.473 35.66928411862055 139.7419524640385 41.739 35.66926836146452 139.74195094658788 41.739 35.66926836146452 139.74195094658788 38.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a64fd78-25da-4969-81b6-60b4affaed10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a64fd78-25da-4969-81b6-60b4affaed10_0">
											<gml:posList>35.6692617516906 139.74197113535584 43.522 35.66924531806957 139.7419690442754 43.522 35.66924531806957 139.7419690442754 45.483 35.6692617516906 139.74197113535584 45.483 35.6692617516906 139.74197113535584 43.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c155bf20-53b8-4b59-a25d-2964b9e62578">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c155bf20-53b8-4b59-a25d-2964b9e62578_0">
											<gml:posList>35.66924531806957 139.7419690442754 43.522 35.669243826169364 139.7419866976481 43.522 35.669243826169364 139.7419866976481 45.483 35.66924531806957 139.7419690442754 45.483 35.66924531806957 139.7419690442754 43.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-125247d1-2dcd-4d0a-935c-f002aba6f758">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-125247d1-2dcd-4d0a-935c-f002aba6f758_0">
											<gml:posList>35.66924531806957 139.7419690442754 45.483 35.669243826169364 139.7419866976481 45.483 35.669260259790114 139.74198878873207 45.483 35.6692617516906 139.74197113535584 45.483 35.66924531806957 139.7419690442754 45.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bd8ddea-8c82-4994-94af-f8844dc1fde6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bd8ddea-8c82-4994-94af-f8844dc1fde6_0">
											<gml:posList>35.669260259790114 139.74198878873207 43.522 35.6692617516906 139.74197113535584 43.522 35.6692617516906 139.74197113535584 45.483 35.669260259790114 139.74198878873207 45.483 35.669260259790114 139.74198878873207 43.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c876392-5e09-4ebc-ac63-afeda8b10eef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c876392-5e09-4ebc-ac63-afeda8b10eef_0">
											<gml:posList>35.669243826169364 139.7419866976481 43.522 35.669260259790114 139.74198878873207 43.522 35.669260259790114 139.74198878873207 45.483 35.669243826169364 139.7419866976481 45.483 35.669243826169364 139.7419866976481 43.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0a180f6b-9c25-48d8-8c58-0f8c5307f459">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a180f6b-9c25-48d8-8c58-0f8c5307f459">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a180f6b-9c25-48d8-8c58-0f8c5307f459">
											<gml:posList>35.66936356272407 139.74193672114563 10.027 35.66935739370846 139.74200322581208 10.027 35.66923587688529 139.74198778922232 10.027 35.669239138608376 139.74195050491085 10.027 35.66926092634873 139.74195254570088 10.027 35.669263536172174 139.7419233147307 10.027 35.66936356272407 139.74193672114563 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-923d1172-0582-4c54-a566-89b4ba2f1478">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-923d1172-0582-4c54-a566-89b4ba2f1478">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-923d1172-0582-4c54-a566-89b4ba2f1478">
											<gml:posList>35.66923587688529 139.74198778922232 39.6 35.66923853393977 139.74198515722296 39.6 35.66924128627233 139.74195366164852 39.6 35.669239138608376 139.74195050491085 39.6 35.66923587688529 139.74198778922232 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-500843a9-ab96-4239-852b-102435c19df6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-500843a9-ab96-4239-852b-102435c19df6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-500843a9-ab96-4239-852b-102435c19df6">
											<gml:posList>35.66926092634873 139.74195254570088 39.6 35.669239138608376 139.74195050491085 39.6 35.66924128627233 139.74195366164852 39.6 35.669263074012626 139.74195570243947 39.6 35.66926092634873 139.74195254570088 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25039189-15a6-47de-b796-d6bf7b7d3504">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25039189-15a6-47de-b796-d6bf7b7d3504">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25039189-15a6-47de-b796-d6bf7b7d3504">
											<gml:posList>35.66926092634873 139.74195254570088 39.6 35.669263074012626 139.74195570243947 39.6 35.6692656748902 139.74192655984763 39.6 35.669263536172174 139.7419233147307 39.6 35.66926092634873 139.74195254570088 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00b1697b-29ee-4b6e-914c-19779f4d8bf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00b1697b-29ee-4b6e-914c-19779f4d8bf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00b1697b-29ee-4b6e-914c-19779f4d8bf6">
											<gml:posList>35.66929100117485 139.7419947959324 39.6 35.669288871472396 139.74199155080234 39.6 35.66923853393977 139.74198515722296 39.6 35.66923587688529 139.74198778922232 39.6 35.66929100117485 139.7419947959324 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-874826a1-b912-44e2-8a52-7d01704869df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-874826a1-b912-44e2-8a52-7d01704869df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-874826a1-b912-44e2-8a52-7d01704869df">
											<gml:posList>35.669288871472396 139.74199155080234 38.473 35.66929433246418 139.74193040436236 38.473 35.6692656748902 139.74192655984763 38.473 35.669263074012626 139.74195570243947 38.473 35.66924128627233 139.74195366164852 38.473 35.66923853393977 139.74198515722296 38.473 35.669288871472396 139.74199155080234 38.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2f87e27-e8c7-475c-8196-c0dd2477bea2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2f87e27-e8c7-475c-8196-c0dd2477bea2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2f87e27-e8c7-475c-8196-c0dd2477bea2">
											<gml:posList>35.669263536172174 139.7419233147307 39.6 35.6692656748902 139.74192655984763 39.6 35.66929433246418 139.74193040436236 39.6 35.66929698052042 139.74192779446165 39.6 35.669263536172174 139.7419233147307 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99a843ee-97df-46b0-a312-49e9af69c1b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99a843ee-97df-46b0-a312-49e9af69c1b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99a843ee-97df-46b0-a312-49e9af69c1b1">
											<gml:posList>35.66929698052042 139.74192779446165 39.6 35.66929433246418 139.74193040436236 39.6 35.669288871472396 139.74199155080234 39.6 35.66929100117485 139.7419947959324 39.6 35.66929698052042 139.74192779446165 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a283d1ab-bcba-4015-9267-287c3006d971">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a283d1ab-bcba-4015-9267-287c3006d971">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a283d1ab-bcba-4015-9267-287c3006d971">
											<gml:posList>35.66935739370846 139.74200322581208 27.4 35.66936356272407 139.74193672114563 27.4 35.66929698052042 139.74192779446165 39.6 35.66929100117485 139.7419947959324 39.6 35.66935739370846 139.74200322581208 27.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ccaacba-0eaa-4480-a405-584c259d4ac6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ccaacba-0eaa-4480-a405-584c259d4ac6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ccaacba-0eaa-4480-a405-584c259d4ac6">
											<gml:posList>35.6692656748902 139.74192655984763 39.6 35.6692656748902 139.74192655984763 38.473 35.66929433246418 139.74193040436236 38.473 35.66929433246418 139.74193040436236 39.6 35.6692656748902 139.74192655984763 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed9d8b57-af43-43a6-89fa-b441b05dc1b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed9d8b57-af43-43a6-89fa-b441b05dc1b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed9d8b57-af43-43a6-89fa-b441b05dc1b5">
											<gml:posList>35.669263536172174 139.7419233147307 10.027 35.669263536172174 139.7419233147307 39.6 35.66929698052042 139.74192779446165 39.6 35.66936356272407 139.74193672114563 27.4 35.66936356272407 139.74193672114563 10.027 35.669263536172174 139.7419233147307 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5eb99f8-1c9d-4114-8b74-2bfb88b1b531">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5eb99f8-1c9d-4114-8b74-2bfb88b1b531">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5eb99f8-1c9d-4114-8b74-2bfb88b1b531">
											<gml:posList>35.669263536172174 139.7419233147307 10.027 35.66926092634873 139.74195254570088 10.027 35.66926092634873 139.74195254570088 39.6 35.669263536172174 139.7419233147307 39.6 35.669263536172174 139.7419233147307 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50de1fb4-6bb6-4fcd-b67f-0485f711e440">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50de1fb4-6bb6-4fcd-b67f-0485f711e440">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50de1fb4-6bb6-4fcd-b67f-0485f711e440">
											<gml:posList>35.669263074012626 139.74195570243947 39.6 35.669263074012626 139.74195570243947 38.473 35.6692656748902 139.74192655984763 38.473 35.6692656748902 139.74192655984763 39.6 35.669263074012626 139.74195570243947 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-236778ae-a44f-4187-aad7-aa1a7a7bd7ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-236778ae-a44f-4187-aad7-aa1a7a7bd7ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-236778ae-a44f-4187-aad7-aa1a7a7bd7ab">
											<gml:posList>35.66926092634873 139.74195254570088 10.027 35.669239138608376 139.74195050491085 10.027 35.669239138608376 139.74195050491085 39.6 35.66926092634873 139.74195254570088 39.6 35.66926092634873 139.74195254570088 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f0dd5c1-430e-412f-885e-b9528261cbe2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f0dd5c1-430e-412f-885e-b9528261cbe2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f0dd5c1-430e-412f-885e-b9528261cbe2">
											<gml:posList>35.66924128627233 139.74195366164852 39.6 35.66924128627233 139.74195366164852 38.473 35.669263074012626 139.74195570243947 38.473 35.669263074012626 139.74195570243947 39.6 35.66924128627233 139.74195366164852 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05e7205f-40c8-4a57-bacf-20cb1dfe37df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05e7205f-40c8-4a57-bacf-20cb1dfe37df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05e7205f-40c8-4a57-bacf-20cb1dfe37df">
											<gml:posList>35.66929433246418 139.74193040436236 39.6 35.66929433246418 139.74193040436236 38.473 35.669288871472396 139.74199155080234 38.473 35.669288871472396 139.74199155080234 39.6 35.66929433246418 139.74193040436236 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8a4c381-7e15-4fbc-988b-87d82b120e83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8a4c381-7e15-4fbc-988b-87d82b120e83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8a4c381-7e15-4fbc-988b-87d82b120e83">
											<gml:posList>35.669239138608376 139.74195050491085 10.027 35.66923587688529 139.74198778922232 10.027 35.66923587688529 139.74198778922232 39.6 35.669239138608376 139.74195050491085 39.6 35.669239138608376 139.74195050491085 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ef6622e-6d25-4d0b-b79b-f83c1b582955">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ef6622e-6d25-4d0b-b79b-f83c1b582955">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ef6622e-6d25-4d0b-b79b-f83c1b582955">
											<gml:posList>35.66923853393977 139.74198515722296 39.6 35.66923853393977 139.74198515722296 38.473 35.66924128627233 139.74195366164852 38.473 35.66924128627233 139.74195366164852 39.6 35.66923853393977 139.74198515722296 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c71e62b5-dc4c-4c5c-b94b-5492fccbb462">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c71e62b5-dc4c-4c5c-b94b-5492fccbb462">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c71e62b5-dc4c-4c5c-b94b-5492fccbb462">
											<gml:posList>35.66935739370846 139.74200322581208 10.027 35.66936356272407 139.74193672114563 10.027 35.66936356272407 139.74193672114563 27.4 35.66935739370846 139.74200322581208 27.4 35.66935739370846 139.74200322581208 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fe3dc23-a026-4f27-89da-35fc7456f5af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fe3dc23-a026-4f27-89da-35fc7456f5af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fe3dc23-a026-4f27-89da-35fc7456f5af">
											<gml:posList>35.669288871472396 139.74199155080234 39.6 35.669288871472396 139.74199155080234 38.473 35.66923853393977 139.74198515722296 38.473 35.66923853393977 139.74198515722296 39.6 35.669288871472396 139.74199155080234 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44d928a7-1329-494d-8636-ff8189286426">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44d928a7-1329-494d-8636-ff8189286426">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44d928a7-1329-494d-8636-ff8189286426">
											<gml:posList>35.66935739370846 139.74200322581208 10.027 35.66935739370846 139.74200322581208 27.4 35.66929100117485 139.7419947959324 39.6 35.66923587688529 139.74198778922232 39.6 35.66923587688529 139.74198778922232 10.027 35.66935739370846 139.74200322581208 10.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4703</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">82.75845</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>