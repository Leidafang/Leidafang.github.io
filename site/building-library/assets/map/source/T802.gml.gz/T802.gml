<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e5a61459-7782-4b5a-8c67-aabc06a66dc3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">20.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67176229263089 139.7378656897067 0 35.671783636442605 139.73795580334405 0 35.67194880427079 139.7378878919592 0 35.671924486932774 139.73779910727438 0 35.67176229263089 139.7378656897067 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176229263089 139.7378656897067 10.18 35.671924486932774 139.73779910727438 10.18 35.67194880427079 139.7378878919592 10.18 35.671783636442605 139.73795580334405 10.18 35.67176229263089 139.7378656897067 10.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176229263089 139.7378656897067 10.18 35.671783636442605 139.73795580334405 10.18 35.671783636442605 139.73795580334405 30.57 35.67176229263089 139.7378656897067 30.57 35.67176229263089 139.7378656897067 10.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671783636442605 139.73795580334405 10.18 35.67194880427079 139.7378878919592 10.18 35.67194880427079 139.7378878919592 30.57 35.671783636442605 139.73795580334405 30.57 35.671783636442605 139.73795580334405 10.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67194880427079 139.7378878919592 10.18 35.671924486932774 139.73779910727438 10.18 35.671924486932774 139.73779910727438 30.57 35.67194880427079 139.7378878919592 30.57 35.67194880427079 139.7378878919592 10.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671924486932774 139.73779910727438 10.18 35.67176229263089 139.7378656897067 10.18 35.67176229263089 139.7378656897067 30.57 35.671924486932774 139.73779910727438 30.57 35.671924486932774 139.73779910727438 10.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176229263089 139.7378656897067 30.57 35.671783636442605 139.73795580334405 30.57 35.67194880427079 139.7378878919592 30.57 35.671924486932774 139.73779910727438 30.57 35.67176229263089 139.7378656897067 30.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-96da8d09-8ef0-4c15-829d-3cab14d6c96d"/>
							<gml:surfaceMember xlink:href="#poly-b5d10555-2028-4884-80c5-5b293f23270a"/>
							<gml:surfaceMember xlink:href="#poly-9fce6e23-64dc-439c-8e71-50cc0938bf59"/>
							<gml:surfaceMember xlink:href="#poly-9eb686ed-6325-475b-81f3-b9320e7c208b"/>
							<gml:surfaceMember xlink:href="#poly-e16c24e6-7e36-4052-b6d4-1a1745465504"/>
							<gml:surfaceMember xlink:href="#poly-65feedaf-87d8-44c5-9211-c06c39d5602f"/>
							<gml:surfaceMember xlink:href="#poly-6483e32b-ba63-4f14-86fe-b3fa21809642"/>
							<gml:surfaceMember xlink:href="#poly-a99486a4-ecec-40cf-8e48-10b7ba7bb228"/>
							<gml:surfaceMember xlink:href="#poly-aa117ffe-30f3-49d9-8ab7-3d007605da7f"/>
							<gml:surfaceMember xlink:href="#poly-e3fe247b-e2f6-4800-93d2-84af0e4c07b6"/>
							<gml:surfaceMember xlink:href="#poly-3c3fbd3e-bb5f-431a-89a6-7569a34ce592"/>
							<gml:surfaceMember xlink:href="#poly-c1d73522-0910-4492-a095-b3cf4726d2d3"/>
							<gml:surfaceMember xlink:href="#poly-960dffd9-1291-4739-90fa-aa4ed84b74e8"/>
							<gml:surfaceMember xlink:href="#poly-99ca4ae4-dabd-4013-9b2f-11f72e36532c"/>
							<gml:surfaceMember xlink:href="#poly-d94f2e53-70ae-4d5c-b4f4-89709b457848"/>
							<gml:surfaceMember xlink:href="#poly-a12555ad-1e86-45b8-96b6-3d584523f3bb"/>
							<gml:surfaceMember xlink:href="#poly-c44b989e-7432-4eb2-b56a-c5f2194578d5"/>
							<gml:surfaceMember xlink:href="#poly-281fc510-6164-4e69-8071-33b7727b4e7b"/>
							<gml:surfaceMember xlink:href="#poly-ae804e20-9a3c-417d-b534-0f65451c819f"/>
							<gml:surfaceMember xlink:href="#poly-4530a0a5-40bd-47e3-9f62-dae7f46c8cf0"/>
							<gml:surfaceMember xlink:href="#poly-897e5605-c26f-4ca1-8137-810ceebf56d1"/>
							<gml:surfaceMember xlink:href="#poly-7a653321-6d3e-41fd-956c-a468f312c546"/>
							<gml:surfaceMember xlink:href="#poly-19bbd109-9195-492e-b51d-b87faf109fd2"/>
							<gml:surfaceMember xlink:href="#poly-fcf06a22-2c66-44a2-bd05-c037cafbedb2"/>
							<gml:surfaceMember xlink:href="#poly-4cad8531-07a9-4e8f-8d68-f5c22f2cb50b"/>
							<gml:surfaceMember xlink:href="#poly-0244595d-4f40-4f4a-b4bf-2582db670e6d"/>
							<gml:surfaceMember xlink:href="#poly-799404e6-33cc-4263-b899-60dbb9df6405"/>
							<gml:surfaceMember xlink:href="#poly-c72748f9-fd41-453a-b196-9463ec0633c3"/>
							<gml:surfaceMember xlink:href="#poly-ccf681af-d48f-407d-9712-ee2c2fbecbe8"/>
							<gml:surfaceMember xlink:href="#poly-fe60269e-72fa-4486-99b6-244118fdbf15"/>
							<gml:surfaceMember xlink:href="#poly-86964acf-4d55-417b-88dd-d534d82dfb83"/>
							<gml:surfaceMember xlink:href="#poly-7a6046bb-b0e0-42e4-a318-2f6329bc5d3c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e5a61459-7782-4b5a-8c67-aabc06a66dc3_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e49133be-1d9e-4a26-b160-c43895433640">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67187567590742 139.7378424344419 30.902 35.671871013000704 139.7378275272685 30.902 35.67189093493112 139.7378181692717 30.902 35.67189559783899 139.73783307644823 30.902 35.67187567590742 139.7378424344419 30.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a248be6a-7a89-4368-a34d-3ef814bf2025">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6718806578205 139.73787315977629 30.902 35.671888510488515 139.73789806020937 30.902 35.67184455803001 139.73791889092186 30.902 35.67183670536627 139.73789399050034 30.902 35.6718806578205 139.73787315977629 30.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cbe0f72-d3df-4355-947b-360bfe2bdc24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671777834190934 139.73787944612567 28.312 35.671780431539766 139.73789257726483 28.312 35.671789029098186 139.73793613424183 28.312 35.67178054920058 139.73793868501593 28.312 35.67176727261559 139.737882617985 28.312 35.671777834190934 139.73787944612567 28.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed78e7f1-dd4b-4bb2-a38f-4460d2b4f20e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed78e7f1-dd4b-4bb2-a38f-4460d2b4f20e_0">
											<gml:posList>35.67189093493112 139.7378181692717 30.902 35.671871013000704 139.7378275272685 30.902 35.671871013000704 139.7378275272685 32.979 35.67189093493112 139.7378181692717 32.979 35.67189093493112 139.7378181692717 30.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-029dfc93-bedd-4935-8217-799f2bc0a343">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-029dfc93-bedd-4935-8217-799f2bc0a343_0">
											<gml:posList>35.67189559783899 139.73783307644823 30.902 35.67189093493112 139.7378181692717 30.902 35.67189093493112 139.7378181692717 32.979 35.67189559783899 139.73783307644823 32.979 35.67189559783899 139.73783307644823 30.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b11974e-1170-4a76-bacc-d612f94e1fca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b11974e-1170-4a76-bacc-d612f94e1fca_0">
											<gml:posList>35.67189093493112 139.7378181692717 32.979 35.671871013000704 139.7378275272685 32.979 35.67187567590742 139.7378424344419 32.979 35.67189559783899 139.73783307644823 32.979 35.67189093493112 139.7378181692717 32.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8548e5ea-bcd2-4fab-b12e-a5dcf314948f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8548e5ea-bcd2-4fab-b12e-a5dcf314948f_0">
											<gml:posList>35.67187567590742 139.7378424344419 30.902 35.67187567590742 139.7378424344419 32.979 35.671871013000704 139.7378275272685 32.979 35.671871013000704 139.7378275272685 30.902 35.67187567590742 139.7378424344419 30.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cafb753-e575-42be-8782-fb2170b4e417">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6cafb753-e575-42be-8782-fb2170b4e417_0">
											<gml:posList>35.67187567590742 139.7378424344419 30.902 35.67189559783899 139.73783307644823 30.902 35.67189559783899 139.73783307644823 32.979 35.67187567590742 139.7378424344419 32.979 35.67187567590742 139.7378424344419 30.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1796b30c-707b-42a9-a254-141f376c8f20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1796b30c-707b-42a9-a254-141f376c8f20_0">
											<gml:posList>35.671777834190934 139.73787944612567 28.312 35.67176727261559 139.737882617985 28.312 35.67176727261559 139.737882617985 30.246 35.671777834190934 139.73787944612567 30.246 35.671777834190934 139.73787944612567 28.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cab51ca9-4183-46bc-8210-6f4589c6350b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cab51ca9-4183-46bc-8210-6f4589c6350b_0">
											<gml:posList>35.67183670536627 139.73789399050034 30.902 35.67183670536627 139.73789399050034 32.979 35.6718806578205 139.73787315977629 32.979 35.6718806578205 139.73787315977629 30.902 35.67183670536627 139.73789399050034 30.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8e88162-8611-48b1-a5ea-094f88f1faf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8e88162-8611-48b1-a5ea-094f88f1faf9_0">
											<gml:posList>35.671888510488515 139.73789806020937 30.902 35.6718806578205 139.73787315977629 30.902 35.6718806578205 139.73787315977629 32.979 35.671888510488515 139.73789806020937 32.979 35.671888510488515 139.73789806020937 30.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ecb623f-2bb8-4193-b61b-12f999312702">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ecb623f-2bb8-4193-b61b-12f999312702_0">
											<gml:posList>35.671780431539766 139.73789257726483 28.312 35.671777834190934 139.73787944612567 28.312 35.671777834190934 139.73787944612567 30.246 35.671780431539766 139.73789257726483 30.246 35.671780431539766 139.73789257726483 28.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-664542db-822d-4d7d-80d1-308ca28dd5e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-664542db-822d-4d7d-80d1-308ca28dd5e6_0">
											<gml:posList>35.6718806578205 139.73787315977629 32.979 35.67183670536627 139.73789399050034 32.979 35.67184455803001 139.73791889092186 32.979 35.671888510488515 139.73789806020937 32.979 35.6718806578205 139.73787315977629 32.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f431c83-fb9f-45a0-8c62-801d3b4d69a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f431c83-fb9f-45a0-8c62-801d3b4d69a8_0">
											<gml:posList>35.67183670536627 139.73789399050034 30.902 35.67184455803001 139.73791889092186 30.902 35.67184455803001 139.73791889092186 32.979 35.67183670536627 139.73789399050034 32.979 35.67183670536627 139.73789399050034 30.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e1538d3-7674-4b24-a70e-cf41bb647281">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e1538d3-7674-4b24-a70e-cf41bb647281_0">
											<gml:posList>35.67184455803001 139.73791889092186 30.902 35.671888510488515 139.73789806020937 30.902 35.671888510488515 139.73789806020937 32.979 35.67184455803001 139.73791889092186 32.979 35.67184455803001 139.73791889092186 30.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78869641-8c28-41d4-a97f-ff19d4bd8d9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78869641-8c28-41d4-a97f-ff19d4bd8d9e_0">
											<gml:posList>35.67178054920058 139.73793868501593 30.246 35.671789029098186 139.73793613424183 30.246 35.671780431539766 139.73789257726483 30.246 35.671777834190934 139.73787944612567 30.246 35.67176727261559 139.737882617985 30.246 35.67178054920058 139.73793868501593 30.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82cb8b9c-9ae2-4729-944b-265aee4dbb86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82cb8b9c-9ae2-4729-944b-265aee4dbb86_0">
											<gml:posList>35.67178054920058 139.73793868501593 28.312 35.67178054920058 139.73793868501593 30.246 35.67176727261559 139.737882617985 30.246 35.67176727261559 139.737882617985 28.312 35.67178054920058 139.73793868501593 28.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae0219a6-c318-4735-bf9d-37dc4c142049">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae0219a6-c318-4735-bf9d-37dc4c142049_0">
											<gml:posList>35.671780431539766 139.73789257726483 30.246 35.671789029098186 139.73793613424183 30.246 35.671789029098186 139.73793613424183 28.312 35.671780431539766 139.73789257726483 28.312 35.671780431539766 139.73789257726483 30.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e65cc74e-702e-430f-8372-a7523c22f3f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e65cc74e-702e-430f-8372-a7523c22f3f3_0">
											<gml:posList>35.671789029098186 139.73793613424183 28.312 35.671789029098186 139.73793613424183 30.246 35.67178054920058 139.73793868501593 30.246 35.67178054920058 139.73793868501593 28.312 35.671789029098186 139.73793613424183 28.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-96da8d09-8ef0-4c15-829d-3cab14d6c96d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96da8d09-8ef0-4c15-829d-3cab14d6c96d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96da8d09-8ef0-4c15-829d-3cab14d6c96d">
											<gml:posList>35.671762292630866 139.7378656897067 10.18 35.671924486932774 139.73779910727438 10.18 35.671948804270784 139.7378878919592 10.18 35.6717836364426 139.73795580334402 10.18 35.671762292630866 139.7378656897067 10.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5d10555-2028-4884-80c5-5b293f23270a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5d10555-2028-4884-80c5-5b293f23270a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5d10555-2028-4884-80c5-5b293f23270a">
											<gml:posList>35.671924486932774 139.73779910727438 31.721 35.67186231245676 139.7378246324131 31.721 35.67186364980798 139.73782881742963 31.721 35.671866902525444 139.73782725600347 31.721 35.67192228286583 139.73780452267187 31.721 35.671924486932774 139.73779910727438 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9fce6e23-64dc-439c-8e71-50cc0938bf59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fce6e23-64dc-439c-8e71-50cc0938bf59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fce6e23-64dc-439c-8e71-50cc0938bf59">
											<gml:posList>35.67186231245676 139.7378246324131 34.539 35.67181916877525 139.73784234709473 34.539 35.671822081529555 139.7378440116406 34.539 35.67186101717097 139.73782802522035 34.539 35.67186231245676 139.7378246324131 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9eb686ed-6325-475b-81f3-b9320e7c208b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9eb686ed-6325-475b-81f3-b9320e7c208b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9eb686ed-6325-475b-81f3-b9320e7c208b">
											<gml:posList>35.671924486932774 139.73779910727438 31.721 35.67192228286583 139.73780452267187 31.721 35.67194438540285 139.73788519083354 31.721 35.671948804270784 139.7378878919592 31.721 35.671924486932774 139.73779910727438 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e16c24e6-7e36-4052-b6d4-1a1745465504">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e16c24e6-7e36-4052-b6d4-1a1745465504">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e16c24e6-7e36-4052-b6d4-1a1745465504">
											<gml:posList>35.67186231245676 139.7378246324131 34.539 35.67186101717097 139.73782802522035 34.539 35.67187196895548 139.73786225621478 34.539 35.67187484558455 139.73786383243376 34.539 35.67186231245676 139.7378246324131 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65feedaf-87d8-44c5-9211-c06c39d5602f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65feedaf-87d8-44c5-9211-c06c39d5602f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65feedaf-87d8-44c5-9211-c06c39d5602f">
											<gml:posList>35.67181714491938 139.73784768494406 31.721 35.67182038860587 139.7378461014374 31.721 35.67181916877525 139.73784234709473 31.721 35.67177415984635 139.7378608151371 31.721 35.67177830839093 139.73786362704212 31.721 35.67181714491938 139.73784768494406 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6483e32b-ba63-4f14-86fe-b3fa21809642">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6483e32b-ba63-4f14-86fe-b3fa21809642">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6483e32b-ba63-4f14-86fe-b3fa21809642">
											<gml:posList>35.67183376470814 139.73787986557932 34.281 35.67187196895548 139.73786225621478 34.281 35.67186101717097 139.73782802522035 34.281 35.671822081529555 139.7378440116406 34.281 35.67183376470814 139.73787986557932 34.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a99486a4-ecec-40cf-8e48-10b7ba7bb228">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a99486a4-ecec-40cf-8e48-10b7ba7bb228">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a99486a4-ecec-40cf-8e48-10b7ba7bb228">
											<gml:posList>35.6718325235644 139.73788333564522 34.539 35.67183376470814 139.73787986557932 34.539 35.671822081529555 139.7378440116406 34.539 35.67181916877525 139.73784234709473 34.539 35.6718325235644 139.73788333564522 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa117ffe-30f3-49d9-8ab7-3d007605da7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa117ffe-30f3-49d9-8ab7-3d007605da7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa117ffe-30f3-49d9-8ab7-3d007605da7f">
											<gml:posList>35.67187484558455 139.73786383243376 34.539 35.67187196895548 139.73786225621478 34.539 35.67183376470814 139.73787986557932 34.539 35.6718325235644 139.73788333564522 34.539 35.67187484558455 139.73786383243376 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e3fe247b-e2f6-4800-93d2-84af0e4c07b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3fe247b-e2f6-4800-93d2-84af0e4c07b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3fe247b-e2f6-4800-93d2-84af0e4c07b6">
											<gml:posList>35.67181714491938 139.73784768494406 30.902 35.67177830839093 139.73786362704212 30.902 35.67179470712916 139.73794673208153 30.902 35.67194438540285 139.73788519083354 30.902 35.67192228286583 139.73780452267187 30.902 35.671866902525444 139.73782725600347 30.902 35.67186364980798 139.73782881742963 30.902 35.67187484558455 139.73786383243376 30.902 35.6718325235644 139.73788333564522 30.902 35.67182038860587 139.7378461014374 30.902 35.67181714491938 139.73784768494406 30.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c3fbd3e-bb5f-431a-89a6-7569a34ce592">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c3fbd3e-bb5f-431a-89a6-7569a34ce592">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c3fbd3e-bb5f-431a-89a6-7569a34ce592">
											<gml:posList>35.67177415984635 139.7378608151371 31.721 35.671792214721464 139.73795228036667 31.721 35.67179470712916 139.73794673208153 31.721 35.67177830839093 139.73786362704212 31.721 35.67177415984635 139.7378608151371 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1d73522-0910-4492-a095-b3cf4726d2d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1d73522-0910-4492-a095-b3cf4726d2d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1d73522-0910-4492-a095-b3cf4726d2d3">
											<gml:posList>35.671762292630866 139.7378656897067 28.312 35.6717836364426 139.73795580334402 28.312 35.671792214721464 139.73795228036667 28.312 35.67177415984635 139.7378608151371 28.312 35.671762292630866 139.7378656897067 28.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-960dffd9-1291-4739-90fa-aa4ed84b74e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-960dffd9-1291-4739-90fa-aa4ed84b74e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-960dffd9-1291-4739-90fa-aa4ed84b74e8">
											<gml:posList>35.671948804270784 139.7378878919592 31.721 35.67194438540285 139.73788519083354 31.721 35.67179470712916 139.73794673208153 31.721 35.671792214721464 139.73795228036667 31.721 35.671948804270784 139.7378878919592 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99ca4ae4-dabd-4013-9b2f-11f72e36532c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99ca4ae4-dabd-4013-9b2f-11f72e36532c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99ca4ae4-dabd-4013-9b2f-11f72e36532c">
											<gml:posList>35.67187196895548 139.73786225621478 34.539 35.67187196895548 139.73786225621478 34.281 35.67183376470814 139.73787986557932 34.281 35.67183376470814 139.73787986557932 34.539 35.67187196895548 139.73786225621478 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d94f2e53-70ae-4d5c-b4f4-89709b457848">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d94f2e53-70ae-4d5c-b4f4-89709b457848">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d94f2e53-70ae-4d5c-b4f4-89709b457848">
											<gml:posList>35.67177830839093 139.73786362704212 31.721 35.67177830839093 139.73786362704212 30.902 35.67181714491938 139.73784768494406 30.902 35.67181714491938 139.73784768494406 31.721 35.67177830839093 139.73786362704212 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a12555ad-1e86-45b8-96b6-3d584523f3bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a12555ad-1e86-45b8-96b6-3d584523f3bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a12555ad-1e86-45b8-96b6-3d584523f3bb">
											<gml:posList>35.67181714491938 139.73784768494406 31.721 35.67181714491938 139.73784768494406 30.902 35.67182038860587 139.7378461014374 30.902 35.67182038860587 139.7378461014374 31.721 35.67181714491938 139.73784768494406 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c44b989e-7432-4eb2-b56a-c5f2194578d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c44b989e-7432-4eb2-b56a-c5f2194578d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c44b989e-7432-4eb2-b56a-c5f2194578d5">
											<gml:posList>35.67181916877525 139.73784234709473 34.539 35.67181916877525 139.73784234709473 31.721 35.67182038860587 139.7378461014374 31.721 35.67182038860587 139.7378461014374 30.902 35.6718325235644 139.73788333564522 30.902 35.6718325235644 139.73788333564522 34.539 35.67181916877525 139.73784234709473 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-281fc510-6164-4e69-8071-33b7727b4e7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-281fc510-6164-4e69-8071-33b7727b4e7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-281fc510-6164-4e69-8071-33b7727b4e7b">
											<gml:posList>35.67183376470814 139.73787986557932 34.539 35.67183376470814 139.73787986557932 34.281 35.671822081529555 139.7378440116406 34.281 35.671822081529555 139.7378440116406 34.539 35.67183376470814 139.73787986557932 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae804e20-9a3c-417d-b534-0f65451c819f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae804e20-9a3c-417d-b534-0f65451c819f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae804e20-9a3c-417d-b534-0f65451c819f">
											<gml:posList>35.671822081529555 139.7378440116406 34.539 35.671822081529555 139.7378440116406 34.281 35.67186101717097 139.73782802522035 34.281 35.67186101717097 139.73782802522035 34.539 35.671822081529555 139.7378440116406 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4530a0a5-40bd-47e3-9f62-dae7f46c8cf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4530a0a5-40bd-47e3-9f62-dae7f46c8cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4530a0a5-40bd-47e3-9f62-dae7f46c8cf0">
											<gml:posList>35.671762292630866 139.7378656897067 10.18 35.671762292630866 139.7378656897067 28.312 35.67177415984635 139.7378608151371 28.312 35.67177415984635 139.7378608151371 31.721 35.67181916877525 139.73784234709473 31.721 35.67181916877525 139.73784234709473 34.539 35.67186231245676 139.7378246324131 34.539 35.67186231245676 139.7378246324131 31.721 35.671924486932774 139.73779910727438 31.721 35.671924486932774 139.73779910727438 10.18 35.671762292630866 139.7378656897067 10.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-897e5605-c26f-4ca1-8137-810ceebf56d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-897e5605-c26f-4ca1-8137-810ceebf56d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-897e5605-c26f-4ca1-8137-810ceebf56d1">
											<gml:posList>35.6718325235644 139.73788333564522 30.902 35.67187484558455 139.73786383243376 30.902 35.67187484558455 139.73786383243376 34.539 35.6718325235644 139.73788333564522 34.539 35.6718325235644 139.73788333564522 30.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a653321-6d3e-41fd-956c-a468f312c546">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a653321-6d3e-41fd-956c-a468f312c546">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a653321-6d3e-41fd-956c-a468f312c546">
											<gml:posList>35.67186364980798 139.73782881742963 31.721 35.67186364980798 139.73782881742963 30.902 35.671866902525444 139.73782725600347 30.902 35.671866902525444 139.73782725600347 31.721 35.67186364980798 139.73782881742963 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19bbd109-9195-492e-b51d-b87faf109fd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19bbd109-9195-492e-b51d-b87faf109fd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19bbd109-9195-492e-b51d-b87faf109fd2">
											<gml:posList>35.67186101717097 139.73782802522035 34.539 35.67186101717097 139.73782802522035 34.281 35.67187196895548 139.73786225621478 34.281 35.67187196895548 139.73786225621478 34.539 35.67186101717097 139.73782802522035 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcf06a22-2c66-44a2-bd05-c037cafbedb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcf06a22-2c66-44a2-bd05-c037cafbedb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcf06a22-2c66-44a2-bd05-c037cafbedb2">
											<gml:posList>35.67186364980798 139.73782881742963 31.721 35.67186231245676 139.7378246324131 31.721 35.67186231245676 139.7378246324131 34.539 35.67187484558455 139.73786383243376 34.539 35.67187484558455 139.73786383243376 30.902 35.67186364980798 139.73782881742963 30.902 35.67186364980798 139.73782881742963 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cad8531-07a9-4e8f-8d68-f5c22f2cb50b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cad8531-07a9-4e8f-8d68-f5c22f2cb50b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cad8531-07a9-4e8f-8d68-f5c22f2cb50b">
											<gml:posList>35.671866902525444 139.73782725600347 31.721 35.671866902525444 139.73782725600347 30.902 35.67192228286583 139.73780452267187 30.902 35.67192228286583 139.73780452267187 31.721 35.671866902525444 139.73782725600347 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0244595d-4f40-4f4a-b4bf-2582db670e6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0244595d-4f40-4f4a-b4bf-2582db670e6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0244595d-4f40-4f4a-b4bf-2582db670e6d">
											<gml:posList>35.67192228286583 139.73780452267187 31.721 35.67192228286583 139.73780452267187 30.902 35.67194438540285 139.73788519083354 30.902 35.67194438540285 139.73788519083354 31.721 35.67192228286583 139.73780452267187 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-799404e6-33cc-4263-b899-60dbb9df6405">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-799404e6-33cc-4263-b899-60dbb9df6405">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-799404e6-33cc-4263-b899-60dbb9df6405">
											<gml:posList>35.671948804270784 139.7378878919592 10.18 35.671924486932774 139.73779910727438 10.18 35.671924486932774 139.73779910727438 31.721 35.671948804270784 139.7378878919592 31.721 35.671948804270784 139.7378878919592 10.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c72748f9-fd41-453a-b196-9463ec0633c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c72748f9-fd41-453a-b196-9463ec0633c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c72748f9-fd41-453a-b196-9463ec0633c3">
											<gml:posList>35.671762292630866 139.7378656897067 10.18 35.6717836364426 139.73795580334402 10.18 35.6717836364426 139.73795580334402 28.312 35.671762292630866 139.7378656897067 28.312 35.671762292630866 139.7378656897067 10.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccf681af-d48f-407d-9712-ee2c2fbecbe8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccf681af-d48f-407d-9712-ee2c2fbecbe8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccf681af-d48f-407d-9712-ee2c2fbecbe8">
											<gml:posList>35.671792214721464 139.73795228036667 31.721 35.67177415984635 139.7378608151371 31.721 35.67177415984635 139.7378608151371 28.312 35.671792214721464 139.73795228036667 28.312 35.671792214721464 139.73795228036667 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe60269e-72fa-4486-99b6-244118fdbf15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe60269e-72fa-4486-99b6-244118fdbf15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe60269e-72fa-4486-99b6-244118fdbf15">
											<gml:posList>35.67179470712916 139.73794673208153 31.721 35.67179470712916 139.73794673208153 30.902 35.67177830839093 139.73786362704212 30.902 35.67177830839093 139.73786362704212 31.721 35.67179470712916 139.73794673208153 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86964acf-4d55-417b-88dd-d534d82dfb83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86964acf-4d55-417b-88dd-d534d82dfb83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86964acf-4d55-417b-88dd-d534d82dfb83">
											<gml:posList>35.671948804270784 139.7378878919592 10.18 35.671948804270784 139.7378878919592 31.721 35.671792214721464 139.73795228036667 31.721 35.671792214721464 139.73795228036667 28.312 35.6717836364426 139.73795580334402 28.312 35.6717836364426 139.73795580334402 10.18 35.671948804270784 139.7378878919592 10.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a6046bb-b0e0-42e4-a318-2f6329bc5d3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a6046bb-b0e0-42e4-a318-2f6329bc5d3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a6046bb-b0e0-42e4-a318-2f6329bc5d3c">
											<gml:posList>35.67194438540285 139.73788519083354 31.721 35.67194438540285 139.73788519083354 30.902 35.67179470712916 139.73794673208153 30.902 35.67179470712916 139.73794673208153 31.721 35.67194438540285 139.73788519083354 31.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4019</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">162.46325</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>