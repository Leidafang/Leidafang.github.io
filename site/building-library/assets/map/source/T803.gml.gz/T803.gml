<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e638587f-c854-4a4a-9ec0-a96f6610ed7a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">9.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669088313423956 139.73893791331855 0 35.66909713656853 139.73892475809305 0 35.669042740843125 139.73887003360846 0 35.668983139798335 139.738959135124 0 35.669047277919624 139.73902356871488 0 35.66909805595244 139.73894773286247 0 35.669088313423956 139.73893791331855 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669088313423956 139.73893791331855 13.888 35.66909805595244 139.73894773286247 13.888 35.669047277919624 139.73902356871488 13.888 35.668983139798335 139.738959135124 13.888 35.669042740843125 139.73887003360846 13.888 35.66909713656853 139.73892475809305 13.888 35.669088313423956 139.73893791331855 13.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669088313423956 139.73893791331855 13.888 35.66909713656853 139.73892475809305 13.888 35.66909713656853 139.73892475809305 23.51 35.669088313423956 139.73893791331855 23.51 35.669088313423956 139.73893791331855 13.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909713656853 139.73892475809305 13.888 35.669042740843125 139.73887003360846 13.888 35.669042740843125 139.73887003360846 23.51 35.66909713656853 139.73892475809305 23.51 35.66909713656853 139.73892475809305 13.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669042740843125 139.73887003360846 13.888 35.668983139798335 139.738959135124 13.888 35.668983139798335 139.738959135124 23.51 35.669042740843125 139.73887003360846 23.51 35.669042740843125 139.73887003360846 13.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668983139798335 139.738959135124 13.888 35.669047277919624 139.73902356871488 13.888 35.669047277919624 139.73902356871488 23.51 35.668983139798335 139.738959135124 23.51 35.668983139798335 139.738959135124 13.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669047277919624 139.73902356871488 13.888 35.66909805595244 139.73894773286247 13.888 35.66909805595244 139.73894773286247 23.51 35.669047277919624 139.73902356871488 23.51 35.669047277919624 139.73902356871488 13.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909805595244 139.73894773286247 13.888 35.669088313423956 139.73893791331855 13.888 35.669088313423956 139.73893791331855 23.51 35.66909805595244 139.73894773286247 23.51 35.66909805595244 139.73894773286247 13.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669088313423956 139.73893791331855 23.51 35.66909713656853 139.73892475809305 23.51 35.669042740843125 139.73887003360846 23.51 35.668983139798335 139.738959135124 23.51 35.669047277919624 139.73902356871488 23.51 35.66909805595244 139.73894773286247 23.51 35.669088313423956 139.73893791331855 23.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-665d0a06-63f7-44c4-b3dd-943225b9f00e"/>
							<gml:surfaceMember xlink:href="#poly-469c062b-8686-40af-8235-3e2fdab20f10"/>
							<gml:surfaceMember xlink:href="#poly-63b49759-06d5-40c3-ae8c-6ba679bdfc9f"/>
							<gml:surfaceMember xlink:href="#poly-0cf36d4c-7891-47eb-96b8-c50fbbde09dc"/>
							<gml:surfaceMember xlink:href="#poly-903477ff-8c7a-4fec-854e-d80ba8e577f0"/>
							<gml:surfaceMember xlink:href="#poly-67963a90-68f8-404a-b840-2c883038950b"/>
							<gml:surfaceMember xlink:href="#poly-3f08f24f-c5cb-4e6d-85c3-dda1a6810b66"/>
							<gml:surfaceMember xlink:href="#poly-01f18a76-29c5-4724-8181-932dcd946990"/>
							<gml:surfaceMember xlink:href="#poly-e0a937f8-df03-427f-8cc5-eb6cab157afd"/>
							<gml:surfaceMember xlink:href="#poly-d3f31cf8-2972-4533-8be6-d89ce9f8dd72"/>
							<gml:surfaceMember xlink:href="#poly-157f996e-d724-47b2-b417-9a5df820bac6"/>
							<gml:surfaceMember xlink:href="#poly-2f2bb9d0-095c-4c06-b017-b10334ff589a"/>
							<gml:surfaceMember xlink:href="#poly-e2dc3e8f-f03f-4ebc-ba1a-8f39b74d03b8"/>
							<gml:surfaceMember xlink:href="#poly-6987a0b3-a371-444c-bc05-270a20b5392e"/>
							<gml:surfaceMember xlink:href="#poly-fb37e27a-9349-49af-a56d-84f3c32ee35d"/>
							<gml:surfaceMember xlink:href="#poly-ad3d7a36-5ef4-42a2-8600-787a9b2e6a98"/>
							<gml:surfaceMember xlink:href="#poly-491bce66-b890-40e5-a496-74c62cc0ea14"/>
							<gml:surfaceMember xlink:href="#poly-40b46640-6e9a-44c6-b158-041bfff9a8a2"/>
							<gml:surfaceMember xlink:href="#poly-0ccff45a-b44c-4aa1-8be6-b3581eba57bb"/>
							<gml:surfaceMember xlink:href="#poly-68da5878-97ed-4571-aa0d-61687c25fe60"/>
							<gml:surfaceMember xlink:href="#poly-7c097a04-8f95-4236-8d84-3bfc2d885d14"/>
							<gml:surfaceMember xlink:href="#poly-638bcf48-d053-48c1-ac49-1122e71a8ab7"/>
							<gml:surfaceMember xlink:href="#poly-317c6b32-12a4-466d-a694-24ee16e92e53"/>
							<gml:surfaceMember xlink:href="#poly-c3b01eee-2cc1-429e-b912-7513f7ad20c3"/>
							<gml:surfaceMember xlink:href="#poly-22c33d8e-7cf3-49ac-bc98-c229d99b929b"/>
							<gml:surfaceMember xlink:href="#poly-dc23b5d9-12eb-4983-8bd8-3afe49eda2bf"/>
							<gml:surfaceMember xlink:href="#poly-ccc23020-f1b9-4119-93b4-998ac275ca0d"/>
							<gml:surfaceMember xlink:href="#poly-15bca204-b034-4dad-ac6e-62231a426af7"/>
							<gml:surfaceMember xlink:href="#poly-50fa51c9-9f8a-43f1-9add-ed9592e14d43"/>
							<gml:surfaceMember xlink:href="#poly-96cb85a4-5f73-42f2-b4c2-0380d364ab22"/>
							<gml:surfaceMember xlink:href="#poly-2fa9de7c-c6e5-47cb-bc43-002957f2d7a1"/>
							<gml:surfaceMember xlink:href="#poly-18e2e381-c4a2-4ddb-926f-bf1f841c0b24"/>
							<gml:surfaceMember xlink:href="#poly-a9f2a8a2-54e6-48c7-80f6-cd0359acb487"/>
							<gml:surfaceMember xlink:href="#poly-878c1e22-50f8-44e5-a3ae-da4cce7f38ea"/>
							<gml:surfaceMember xlink:href="#poly-57aeb1b1-2b3d-43ac-977e-8c1333dac038"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-665d0a06-63f7-44c4-b3dd-943225b9f00e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-665d0a06-63f7-44c4-b3dd-943225b9f00e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-665d0a06-63f7-44c4-b3dd-943225b9f00e">
											<gml:posList>35.669088313423956 139.73893791331852 13.888 35.66909805595243 139.73894773286247 13.888 35.66904727791961 139.73902356871486 13.888 35.668983139798314 139.738959135124 13.888 35.66904274084315 139.73887003360846 13.888 35.66909713656852 139.73892475809305 13.888 35.669088313423956 139.73893791331852 13.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-469c062b-8686-40af-8235-3e2fdab20f10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-469c062b-8686-40af-8235-3e2fdab20f10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-469c062b-8686-40af-8235-3e2fdab20f10">
											<gml:posList>35.66904274084315 139.73887003360846 27.048 35.66904303216786 139.73887371160822 27.048 35.66907658974126 139.7389074841249 27.048 35.66907958200321 139.7389071050343 27.048 35.66904274084315 139.73887003360846 27.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63b49759-06d5-40c3-ae8c-6ba679bdfc9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63b49759-06d5-40c3-ae8c-6ba679bdfc9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63b49759-06d5-40c3-ae8c-6ba679bdfc9f">
											<gml:posList>35.669002667699196 139.73892993946998 27.048 35.669005668974975 139.73892956037 27.048 35.66904303216786 139.73887371160822 27.048 35.66904274084315 139.73887003360846 27.048 35.669002667699196 139.73892993946998 27.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0cf36d4c-7891-47eb-96b8-c50fbbde09dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cf36d4c-7891-47eb-96b8-c50fbbde09dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cf36d4c-7891-47eb-96b8-c50fbbde09dc">
											<gml:posList>35.66907658974126 139.7389074841249 26.585 35.66904303216786 139.73887371160822 26.585 35.669005668974975 139.73892956037 26.585 35.669039704589274 139.73896375208253 26.585 35.66907658974126 139.7389074841249 26.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-903477ff-8c7a-4fec-854e-d80ba8e577f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-903477ff-8c7a-4fec-854e-d80ba8e577f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-903477ff-8c7a-4fec-854e-d80ba8e577f0">
											<gml:posList>35.66907958200321 139.7389071050343 27.048 35.669088313423956 139.73893791331852 23.323 35.66909713656852 139.73892475809305 23.323 35.66907958200321 139.7389071050343 27.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67963a90-68f8-404a-b840-2c883038950b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67963a90-68f8-404a-b840-2c883038950b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67963a90-68f8-404a-b840-2c883038950b">
											<gml:posList>35.66907958200321 139.7389071050343 27.048 35.66907658974126 139.7389074841249 27.048 35.669039704589274 139.73896375208253 27.048 35.669040013955886 139.73896745215342 27.048 35.66907958200321 139.7389071050343 27.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f08f24f-c5cb-4e6d-85c3-dda1a6810b66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f08f24f-c5cb-4e6d-85c3-dda1a6810b66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f08f24f-c5cb-4e6d-85c3-dda1a6810b66">
											<gml:posList>35.66907958200321 139.7389071050343 27.048 35.669053076068614 139.73898050428903 24.258 35.669088313423956 139.73893791331852 23.323 35.66907958200321 139.7389071050343 27.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01f18a76-29c5-4724-8181-932dcd946990">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01f18a76-29c5-4724-8181-932dcd946990">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01f18a76-29c5-4724-8181-932dcd946990">
											<gml:posList>35.66907958200321 139.7389071050343 27.048 35.669040013955886 139.73896745215342 27.048 35.669053076068614 139.73898050428903 24.258 35.66907958200321 139.7389071050343 27.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e0a937f8-df03-427f-8cc5-eb6cab157afd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0a937f8-df03-427f-8cc5-eb6cab157afd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0a937f8-df03-427f-8cc5-eb6cab157afd">
											<gml:posList>35.66898709645107 139.7389586554861 24.258 35.66900484172141 139.73893212403217 24.258 35.669002667699196 139.73892993946998 24.258 35.668983139798314 139.738959135124 24.258 35.66898709645107 139.7389586554861 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3f31cf8-2972-4533-8be6-d89ce9f8dd72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3f31cf8-2972-4533-8be6-d89ce9f8dd72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3f31cf8-2972-4533-8be6-d89ce9f8dd72">
											<gml:posList>35.669040013955886 139.73896745215342 27.048 35.669039704589274 139.73896375208253 27.048 35.669005668974975 139.73892956037 27.048 35.669002667699196 139.73892993946998 27.048 35.669040013955886 139.73896745215342 27.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-157f996e-d724-47b2-b417-9a5df820bac6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-157f996e-d724-47b2-b417-9a5df820bac6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-157f996e-d724-47b2-b417-9a5df820bac6">
											<gml:posList>35.669053076068614 139.73898050428903 24.258 35.66909805595243 139.73894773286247 20.936 35.669088313423956 139.73893791331852 23.323 35.669053076068614 139.73898050428903 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2f2bb9d0-095c-4c06-b017-b10334ff589a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f2bb9d0-095c-4c06-b017-b10334ff589a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f2bb9d0-095c-4c06-b017-b10334ff589a">
											<gml:posList>35.66898709645107 139.7389586554861 24.07 35.66903311172423 139.73900488437442 24.07 35.66905083895987 139.73897833084453 24.07 35.66900484172141 139.73893212403217 24.07 35.66898709645107 139.7389586554861 24.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2dc3e8f-f03f-4ebc-ba1a-8f39b74d03b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2dc3e8f-f03f-4ebc-ba1a-8f39b74d03b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2dc3e8f-f03f-4ebc-ba1a-8f39b74d03b8">
											<gml:posList>35.669053076068614 139.73898050428903 24.258 35.669033512135364 139.7390097441758 24.258 35.66909805595243 139.73894773286247 20.936 35.669053076068614 139.73898050428903 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6987a0b3-a371-444c-bc05-270a20b5392e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6987a0b3-a371-444c-bc05-270a20b5392e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6987a0b3-a371-444c-bc05-270a20b5392e">
											<gml:posList>35.669033512135364 139.7390097441758 24.258 35.66903311172423 139.73900488437442 24.258 35.66898709645107 139.7389586554861 24.258 35.668983139798314 139.738959135124 24.258 35.669033512135364 139.7390097441758 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb37e27a-9349-49af-a56d-84f3c32ee35d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb37e27a-9349-49af-a56d-84f3c32ee35d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb37e27a-9349-49af-a56d-84f3c32ee35d">
											<gml:posList>35.669033512135364 139.7390097441758 24.258 35.66904727791961 139.73902356871486 20.936 35.66909805595243 139.73894773286247 20.936 35.669033512135364 139.7390097441758 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad3d7a36-5ef4-42a2-8600-787a9b2e6a98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad3d7a36-5ef4-42a2-8600-787a9b2e6a98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad3d7a36-5ef4-42a2-8600-787a9b2e6a98">
											<gml:posList>35.66903311172423 139.73900488437442 24.258 35.669033512135364 139.7390097441758 24.258 35.669053076068614 139.73898050428903 24.258 35.66905083895987 139.73897833084453 24.258 35.66903311172423 139.73900488437442 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-491bce66-b890-40e5-a496-74c62cc0ea14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-491bce66-b890-40e5-a496-74c62cc0ea14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-491bce66-b890-40e5-a496-74c62cc0ea14">
											<gml:posList>35.66907658974126 139.7389074841249 27.048 35.66907658974126 139.7389074841249 26.585 35.669039704589274 139.73896375208253 26.585 35.669039704589274 139.73896375208253 27.048 35.66907658974126 139.7389074841249 27.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40b46640-6e9a-44c6-b158-041bfff9a8a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40b46640-6e9a-44c6-b158-041bfff9a8a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40b46640-6e9a-44c6-b158-041bfff9a8a2">
											<gml:posList>35.66900484172141 139.73893212403217 24.258 35.66900484172141 139.73893212403217 24.07 35.66905083895987 139.73897833084453 24.07 35.66900484172141 139.73893212403217 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ccff45a-b44c-4aa1-8be6-b3581eba57bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ccff45a-b44c-4aa1-8be6-b3581eba57bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ccff45a-b44c-4aa1-8be6-b3581eba57bb">
											<gml:posList>35.66904303216786 139.73887371160822 27.048 35.66904303216786 139.73887371160822 26.585 35.66907658974126 139.7389074841249 26.585 35.66907658974126 139.7389074841249 27.048 35.66904303216786 139.73887371160822 27.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68da5878-97ed-4571-aa0d-61687c25fe60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68da5878-97ed-4571-aa0d-61687c25fe60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68da5878-97ed-4571-aa0d-61687c25fe60">
											<gml:posList>35.66904274084315 139.73887003360846 27.048 35.66907958200321 139.7389071050343 27.048 35.66909713656852 139.73892475809305 23.323 35.66909713656852 139.73892475809305 13.888 35.66904274084315 139.73887003360846 13.888 35.66904274084315 139.73887003360846 27.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c097a04-8f95-4236-8d84-3bfc2d885d14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c097a04-8f95-4236-8d84-3bfc2d885d14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c097a04-8f95-4236-8d84-3bfc2d885d14">
											<gml:posList>35.669005668974975 139.73892956037 27.048 35.669005668974975 139.73892956037 26.585 35.66904303216786 139.73887371160822 26.585 35.66904303216786 139.73887371160822 27.048 35.669005668974975 139.73892956037 27.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-638bcf48-d053-48c1-ac49-1122e71a8ab7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-638bcf48-d053-48c1-ac49-1122e71a8ab7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-638bcf48-d053-48c1-ac49-1122e71a8ab7">
											<gml:posList>35.669002667699196 139.73892993946998 24.258 35.669002667699196 139.73892993946998 27.048 35.66904274084315 139.73887003360846 27.048 35.66904274084315 139.73887003360846 13.888 35.668983139798314 139.738959135124 13.888 35.668983139798314 139.738959135124 24.258 35.669002667699196 139.73892993946998 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-317c6b32-12a4-466d-a694-24ee16e92e53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-317c6b32-12a4-466d-a694-24ee16e92e53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-317c6b32-12a4-466d-a694-24ee16e92e53">
											<gml:posList>35.669088313423956 139.73893791331852 13.888 35.66909713656852 139.73892475809305 13.888 35.66909713656852 139.73892475809305 23.323 35.669088313423956 139.73893791331852 23.323 35.669088313423956 139.73893791331852 13.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3b01eee-2cc1-429e-b912-7513f7ad20c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3b01eee-2cc1-429e-b912-7513f7ad20c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3b01eee-2cc1-429e-b912-7513f7ad20c3">
											<gml:posList>35.66909805595243 139.73894773286247 20.936 35.66909805595243 139.73894773286247 13.888 35.669088313423956 139.73893791331852 13.888 35.669088313423956 139.73893791331852 23.323 35.66909805595243 139.73894773286247 20.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22c33d8e-7cf3-49ac-bc98-c229d99b929b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22c33d8e-7cf3-49ac-bc98-c229d99b929b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22c33d8e-7cf3-49ac-bc98-c229d99b929b">
											<gml:posList>35.66898709645107 139.7389586554861 24.258 35.66898709645107 139.7389586554861 24.07 35.66900484172141 139.73893212403217 24.07 35.66900484172141 139.73893212403217 24.258 35.66898709645107 139.7389586554861 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc23b5d9-12eb-4983-8bd8-3afe49eda2bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc23b5d9-12eb-4983-8bd8-3afe49eda2bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc23b5d9-12eb-4983-8bd8-3afe49eda2bf">
											<gml:posList>35.669039704589274 139.73896375208253 27.048 35.669039704589274 139.73896375208253 26.585 35.669005668974975 139.73892956037 26.585 35.669005668974975 139.73892956037 27.048 35.669039704589274 139.73896375208253 27.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccc23020-f1b9-4119-93b4-998ac275ca0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccc23020-f1b9-4119-93b4-998ac275ca0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccc23020-f1b9-4119-93b4-998ac275ca0d">
											<gml:posList>35.66900484172141 139.73893212403217 24.258 35.669040013955886 139.73896745215342 27.048 35.669002667699196 139.73892993946998 24.258 35.66900484172141 139.73893212403217 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15bca204-b034-4dad-ac6e-62231a426af7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15bca204-b034-4dad-ac6e-62231a426af7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15bca204-b034-4dad-ac6e-62231a426af7">
											<gml:posList>35.669040013955886 139.73896745215342 27.048 35.669002667699196 139.73892993946998 27.048 35.669002667699196 139.73892993946998 24.258 35.669040013955886 139.73896745215342 27.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50fa51c9-9f8a-43f1-9add-ed9592e14d43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50fa51c9-9f8a-43f1-9add-ed9592e14d43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50fa51c9-9f8a-43f1-9add-ed9592e14d43">
											<gml:posList>35.66900484172141 139.73893212403217 24.258 35.66905083895987 139.73897833084453 24.07 35.669040013955886 139.73896745215342 27.048 35.66900484172141 139.73893212403217 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96cb85a4-5f73-42f2-b4c2-0380d364ab22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96cb85a4-5f73-42f2-b4c2-0380d364ab22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96cb85a4-5f73-42f2-b4c2-0380d364ab22">
											<gml:posList>35.66905083895987 139.73897833084453 24.07 35.66905083895987 139.73897833084453 24.258 35.669040013955886 139.73896745215342 27.048 35.66905083895987 139.73897833084453 24.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2fa9de7c-c6e5-47cb-bc43-002957f2d7a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fa9de7c-c6e5-47cb-bc43-002957f2d7a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fa9de7c-c6e5-47cb-bc43-002957f2d7a1">
											<gml:posList>35.66905083895987 139.73897833084453 24.258 35.669053076068614 139.73898050428903 24.258 35.669040013955886 139.73896745215342 27.048 35.66905083895987 139.73897833084453 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18e2e381-c4a2-4ddb-926f-bf1f841c0b24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18e2e381-c4a2-4ddb-926f-bf1f841c0b24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18e2e381-c4a2-4ddb-926f-bf1f841c0b24">
											<gml:posList>35.66903311172423 139.73900488437442 24.258 35.66903311172423 139.73900488437442 24.07 35.66898709645107 139.7389586554861 24.07 35.66898709645107 139.7389586554861 24.258 35.66903311172423 139.73900488437442 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9f2a8a2-54e6-48c7-80f6-cd0359acb487">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9f2a8a2-54e6-48c7-80f6-cd0359acb487">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9f2a8a2-54e6-48c7-80f6-cd0359acb487">
											<gml:posList>35.66904727791961 139.73902356871486 13.888 35.66909805595243 139.73894773286247 13.888 35.66909805595243 139.73894773286247 20.936 35.66904727791961 139.73902356871486 20.936 35.66904727791961 139.73902356871486 13.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-878c1e22-50f8-44e5-a3ae-da4cce7f38ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-878c1e22-50f8-44e5-a3ae-da4cce7f38ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-878c1e22-50f8-44e5-a3ae-da4cce7f38ea">
											<gml:posList>35.66904727791961 139.73902356871486 20.936 35.669033512135364 139.7390097441758 24.258 35.668983139798314 139.738959135124 24.258 35.668983139798314 139.738959135124 13.888 35.66904727791961 139.73902356871486 13.888 35.66904727791961 139.73902356871486 20.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57aeb1b1-2b3d-43ac-977e-8c1333dac038">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57aeb1b1-2b3d-43ac-977e-8c1333dac038">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57aeb1b1-2b3d-43ac-977e-8c1333dac038">
											<gml:posList>35.66905083895987 139.73897833084453 24.258 35.66905083895987 139.73897833084453 24.07 35.66903311172423 139.73900488437442 24.07 35.66903311172423 139.73900488437442 24.258 35.66905083895987 139.73897833084453 24.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5852</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">93.8069</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.12</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>