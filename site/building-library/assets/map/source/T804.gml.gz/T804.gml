<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e648e1de-3c16-4629-8347-364954a092cf">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">17.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67058445948784 139.74093916415188 0 35.6705544966494 139.7409493502149 0 35.67058463244 139.74108244534986 0 35.670641397985555 139.74105509568597 0 35.67066551174481 139.7409989527346 0 35.67060215430464 139.7408933127032 0 35.67058595389816 139.7409014945882 0 35.67059331755294 139.74093599470538 0 35.67058445948784 139.74093916415188 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058445948784 139.74093916415188 9.857 35.67059331755294 139.74093599470538 9.857 35.67058595389816 139.7409014945882 9.857 35.67060215430464 139.7408933127032 9.857 35.67066551174481 139.7409989527346 9.857 35.670641397985555 139.74105509568597 9.857 35.67058463244 139.74108244534986 9.857 35.6705544966494 139.7409493502149 9.857 35.67058445948784 139.74093916415188 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058445948784 139.74093916415188 9.857 35.6705544966494 139.7409493502149 9.857 35.6705544966494 139.7409493502149 27.09 35.67058445948784 139.74093916415188 27.09 35.67058445948784 139.74093916415188 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705544966494 139.7409493502149 9.857 35.67058463244 139.74108244534986 9.857 35.67058463244 139.74108244534986 27.09 35.6705544966494 139.7409493502149 27.09 35.6705544966494 139.7409493502149 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058463244 139.74108244534986 9.857 35.670641397985555 139.74105509568597 9.857 35.670641397985555 139.74105509568597 27.09 35.67058463244 139.74108244534986 27.09 35.67058463244 139.74108244534986 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670641397985555 139.74105509568597 9.857 35.67066551174481 139.7409989527346 9.857 35.67066551174481 139.7409989527346 27.09 35.670641397985555 139.74105509568597 27.09 35.670641397985555 139.74105509568597 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066551174481 139.7409989527346 9.857 35.67060215430464 139.7408933127032 9.857 35.67060215430464 139.7408933127032 27.09 35.67066551174481 139.7409989527346 27.09 35.67066551174481 139.7409989527346 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060215430464 139.7408933127032 9.857 35.67058595389816 139.7409014945882 9.857 35.67058595389816 139.7409014945882 27.09 35.67060215430464 139.7408933127032 27.09 35.67060215430464 139.7408933127032 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058595389816 139.7409014945882 9.857 35.67059331755294 139.74093599470538 9.857 35.67059331755294 139.74093599470538 27.09 35.67058595389816 139.7409014945882 27.09 35.67058595389816 139.7409014945882 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059331755294 139.74093599470538 9.857 35.67058445948784 139.74093916415188 9.857 35.67058445948784 139.74093916415188 27.09 35.67059331755294 139.74093599470538 27.09 35.67059331755294 139.74093599470538 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058445948784 139.74093916415188 27.09 35.6705544966494 139.7409493502149 27.09 35.67058463244 139.74108244534986 27.09 35.670641397985555 139.74105509568597 27.09 35.67066551174481 139.7409989527346 27.09 35.67060215430464 139.7408933127032 27.09 35.67058595389816 139.7409014945882 27.09 35.67059331755294 139.74093599470538 27.09 35.67058445948784 139.74093916415188 27.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-20e0e32c-f7ca-408e-94ce-f65de1be62d0"/>
							<gml:surfaceMember xlink:href="#poly-a9457a97-4409-4d5f-8040-d9f5f875e2cf"/>
							<gml:surfaceMember xlink:href="#poly-3acac00b-e51c-4057-b387-49b112489973"/>
							<gml:surfaceMember xlink:href="#poly-5e591a44-04a9-4c78-a667-0f71bc933fb1"/>
							<gml:surfaceMember xlink:href="#poly-95add2f3-a74d-4590-9ac7-0f78a130eacc"/>
							<gml:surfaceMember xlink:href="#poly-44514ac5-e518-48a2-b044-e17c813beb33"/>
							<gml:surfaceMember xlink:href="#poly-5bd8acae-73e8-4805-ba18-bc977abffeb9"/>
							<gml:surfaceMember xlink:href="#poly-fdee8c22-fbe7-4b49-95d6-c8e29ab6c00b"/>
							<gml:surfaceMember xlink:href="#poly-227fd471-ec54-4aab-9af4-ea2efdfe883b"/>
							<gml:surfaceMember xlink:href="#poly-fe3a5064-98dd-4524-8191-8fc752c2aeec"/>
							<gml:surfaceMember xlink:href="#poly-129386ee-d76f-4dfc-94f2-9ca5df3eb6ff"/>
							<gml:surfaceMember xlink:href="#poly-620b7aaa-d6d0-48c8-900f-d569bacc9ef5"/>
							<gml:surfaceMember xlink:href="#poly-4f970d9e-1915-43e0-bc1b-1169a72282c5"/>
							<gml:surfaceMember xlink:href="#poly-781332ae-6b78-417d-b906-94eed4998389"/>
							<gml:surfaceMember xlink:href="#poly-455a0bbb-6267-4630-9527-b1ecfa15f3bf"/>
							<gml:surfaceMember xlink:href="#poly-e73f1762-73cb-4323-aa60-c12ca7c9bc7e"/>
							<gml:surfaceMember xlink:href="#poly-4214982f-ac0d-462d-861b-7cadf23005f0"/>
							<gml:surfaceMember xlink:href="#poly-e78e5e0b-87a2-4900-8846-1188c67056c5"/>
							<gml:surfaceMember xlink:href="#poly-dcc669b8-2c71-4ac6-9b1e-6c1ab27fefa5"/>
							<gml:surfaceMember xlink:href="#poly-90cc2679-a5e6-4175-8bc1-923f958eaf6d"/>
							<gml:surfaceMember xlink:href="#poly-8469ec00-b925-4d99-b1d0-a03a30df7630"/>
							<gml:surfaceMember xlink:href="#poly-3e58b18d-1571-4262-9359-48c0c4b5af63"/>
							<gml:surfaceMember xlink:href="#poly-d348c884-1c5e-4037-8ce1-8a1a45fcc822"/>
							<gml:surfaceMember xlink:href="#poly-33799dc0-411f-4af1-9428-5961aa9e82bb"/>
							<gml:surfaceMember xlink:href="#poly-add4cdad-4894-48df-ac43-5861885b6fbc"/>
							<gml:surfaceMember xlink:href="#poly-195cab26-ce8c-44ee-9750-cf2361007cba"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e648e1de-3c16-4629-8347-364954a092cf_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9ebcf70-d97a-4927-b633-29bd019a5cc8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670611995442634 139.74096136860462 26.405 35.6706110356408 139.740955702963 26.405 35.670609043997956 139.7409562133871 26.405 35.670606861842934 139.74094338011147 26.405 35.670623910805084 139.74093684315258 26.405 35.670635075077584 139.74095546538578 26.405 35.670611995442634 139.74096136860462 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ba42f54-b931-44a0-bb3b-424bea0e7d26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67062639786353 139.74093589030522 27.42 35.67063696758642 139.7409549771683 27.42 35.670635075077584 139.74095546538578 27.42 35.670623910805084 139.74093684315258 27.42 35.67062639786353 139.74093589030522 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb65bc2a-9d6c-4e17-8124-9ca66d8e25a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb65bc2a-9d6c-4e17-8124-9ca66d8e25a8_0">
											<gml:posList>35.670623910805084 139.74093684315258 27.42 35.670623910805084 139.74093684315258 26.405 35.670606861842934 139.74094338011147 26.405 35.670606861842934 139.74094338011147 28.364 35.67062639786353 139.74093589030522 28.364 35.67062639786353 139.74093589030522 27.42 35.670623910805084 139.74093684315258 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27440a0b-789d-4e26-917d-6aa9eaa8c702">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27440a0b-789d-4e26-917d-6aa9eaa8c702_0">
											<gml:posList>35.67062639786353 139.74093589030522 27.42 35.67062639786353 139.74093589030522 28.364 35.67063696758642 139.7409549771683 28.364 35.67063696758642 139.7409549771683 27.42 35.67062639786353 139.74093589030522 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d269eb4e-cad4-4b6a-a18c-477c16463d73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d269eb4e-cad4-4b6a-a18c-477c16463d73_0">
											<gml:posList>35.670623910805084 139.74093684315258 26.405 35.670623910805084 139.74093684315258 27.42 35.670635075077584 139.74095546538578 27.42 35.670635075077584 139.74095546538578 26.405 35.670623910805084 139.74093684315258 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bc74a76-7fff-42a4-a380-5f9c28d7dd3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bc74a76-7fff-42a4-a380-5f9c28d7dd3b_0">
											<gml:posList>35.67062639786353 139.74093589030522 28.364 35.670606861842934 139.74094338011147 28.364 35.670609043997956 139.7409562133871 28.364 35.6706110356408 139.740955702963 28.364 35.670611995442634 139.74096136860462 28.364 35.67063696758642 139.7409549771683 28.364 35.67062639786353 139.74093589030522 28.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db7ba186-3a1e-4031-bbbb-2ce8a7012381">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db7ba186-3a1e-4031-bbbb-2ce8a7012381_0">
											<gml:posList>35.670609043997956 139.7409562133871 26.405 35.670609043997956 139.7409562133871 28.364 35.670606861842934 139.74094338011147 28.364 35.670606861842934 139.74094338011147 26.405 35.670609043997956 139.7409562133871 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-330908fd-dead-410c-9da9-fb07432c2be4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-330908fd-dead-410c-9da9-fb07432c2be4_0">
											<gml:posList>35.6706110356408 139.740955702963 26.405 35.6706110356408 139.740955702963 28.364 35.670609043997956 139.7409562133871 28.364 35.670609043997956 139.7409562133871 26.405 35.6706110356408 139.740955702963 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47762447-0bc7-4a4c-a1f5-6590b837cc92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47762447-0bc7-4a4c-a1f5-6590b837cc92_0">
											<gml:posList>35.67063696758642 139.7409549771683 28.364 35.670611995442634 139.74096136860462 28.364 35.670611995442634 139.74096136860462 26.405 35.670635075077584 139.74095546538578 26.405 35.670635075077584 139.74095546538578 27.42 35.67063696758642 139.7409549771683 27.42 35.67063696758642 139.7409549771683 28.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e0949e2-6477-4e0c-8d57-9a999747ab5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e0949e2-6477-4e0c-8d57-9a999747ab5c_0">
											<gml:posList>35.670611995442634 139.74096136860462 26.405 35.670611995442634 139.74096136860462 28.364 35.6706110356408 139.740955702963 28.364 35.6706110356408 139.740955702963 26.405 35.670611995442634 139.74096136860462 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e648e1de-3c16-4629-8347-364954a092cf_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b07aa9c9-2695-4807-9ed5-0f769ed8804c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059331755291 139.74093599470538 9.857 35.67059313732931 139.7409360611908 9.857 35.67058250401861 139.7409398291825 9.857 35.670554496649366 139.7409493502149 9.857 35.670548002775114 139.74092065945524 9.857 35.670585953898126 139.7409014945882 9.857 35.67059331755291 139.74093599470538 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-109fe848-48d6-4621-a815-70927b8e5ec1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-109fe848-48d6-4621-a815-70927b8e5ec1_0">
											<gml:posList>35.670585953898126 139.7409014945882 9.857 35.670548002775114 139.74092065945524 9.857 35.670548002775114 139.74092065945524 25.26 35.670585953898126 139.7409014945882 25.26 35.670585953898126 139.7409014945882 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d46a24c-e6bf-4672-bf04-634eb0dc30e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d46a24c-e6bf-4672-bf04-634eb0dc30e1_0">
											<gml:posList>35.67059331755291 139.74093599470538 9.857 35.670585953898126 139.7409014945882 9.857 35.670585953898126 139.7409014945882 25.26 35.67059331755291 139.74093599470538 25.26 35.67059331755291 139.74093599470538 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c7b3209-0c0f-44e6-ab80-69669e3dc17a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c7b3209-0c0f-44e6-ab80-69669e3dc17a_0">
											<gml:posList>35.670548002775114 139.74092065945524 25.26 35.67055523828317 139.7409526190603 25.26 35.67057471187801 139.74094600198973 25.26 35.67057409640224 139.74094268881305 25.26 35.67059313732931 139.7409360611908 25.26 35.67059331755291 139.74093599470538 25.26 35.670585953898126 139.7409014945882 25.26 35.670548002775114 139.74092065945524 25.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fd10658-2e01-4af3-bcea-f22913e1173f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fd10658-2e01-4af3-bcea-f22913e1173f_0">
											<gml:posList>35.67059331755291 139.74093599470538 25.26 35.67059313732931 139.7409360611908 25.26 35.67059313732931 139.7409360611908 9.857 35.67059331755291 139.74093599470538 9.857 35.67059331755291 139.74093599470538 25.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90352906-5477-4438-8009-569e16f0ecc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90352906-5477-4438-8009-569e16f0ecc3_0">
											<gml:posList>35.67055523828317 139.7409526190603 25.26 35.670548002775114 139.74092065945524 25.26 35.670548002775114 139.74092065945524 9.857 35.670554496649366 139.7409493502149 9.857 35.670554496649366 139.7409493502149 21.227 35.67055523828317 139.7409526190603 21.227 35.67055523828317 139.7409526190603 25.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-640f1738-f6c0-4fc9-8507-43ccde57d475">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-640f1738-f6c0-4fc9-8507-43ccde57d475_0">
											<gml:posList>35.67057409640224 139.74094268881305 25.26 35.670554496649366 139.7409493502149 21.227 35.67058250401861 139.7409398291825 9.857 35.67059313732931 139.7409360611908 9.857 35.67059313732931 139.7409360611908 25.26 35.67057409640224 139.74094268881305 25.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81dd81d7-8510-4305-a4c5-f73e7807ea8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81dd81d7-8510-4305-a4c5-f73e7807ea8e_0">
											<gml:posList>35.670554496649366 139.7409493502149 9.857 35.67058250401861 139.7409398291825 9.857 35.670554496649366 139.7409493502149 21.227 35.670554496649366 139.7409493502149 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-149b6420-b6d4-4301-b9cc-87771bfa56b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-149b6420-b6d4-4301-b9cc-87771bfa56b4_0">
											<gml:posList>35.67055523828317 139.7409526190603 21.227 35.670554496649366 139.7409493502149 21.227 35.67057409640224 139.74094268881305 25.26 35.67057471187801 139.74094600198973 25.26 35.67055523828317 139.7409526190603 21.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38dc2a5a-58d9-41f5-a32a-845bc93146c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38dc2a5a-58d9-41f5-a32a-845bc93146c4_0">
											<gml:posList>35.67055523828317 139.7409526190603 25.26 35.67055523828317 139.7409526190603 21.227 35.67057471187801 139.74094600198973 25.26 35.67055523828317 139.7409526190603 25.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e648e1de-3c16-4629-8347-364954a092cf_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc4b0a7c-bfbc-4aa6-86cb-b221b9a67937">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670627381326554 139.74097239717204 26.405 35.67063275824917 139.7410020834171 26.405 35.67061346387565 139.74100733053234 26.405 35.6706080869543 139.7409776442941 26.405 35.670627381326554 139.74097239717204 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd6bd648-b72e-41c5-a43b-f7215129918a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd6bd648-b72e-41c5-a43b-f7215129918a_0">
											<gml:posList>35.6706080869543 139.7409776442941 26.405 35.6706080869543 139.7409776442941 29.698 35.670627381326554 139.74097239717204 29.698 35.670627381326554 139.74097239717204 26.405 35.6706080869543 139.7409776442941 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d95a346-a0a7-481b-b385-a8803407030f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d95a346-a0a7-481b-b385-a8803407030f_0">
											<gml:posList>35.670627381326554 139.74097239717204 26.405 35.670627381326554 139.74097239717204 29.698 35.67063275824917 139.7410020834171 29.698 35.67063275824917 139.7410020834171 26.405 35.670627381326554 139.74097239717204 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37738a1f-bb54-477c-916f-e71c1e1c2be9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37738a1f-bb54-477c-916f-e71c1e1c2be9_0">
											<gml:posList>35.670627381326554 139.74097239717204 29.698 35.6706080869543 139.7409776442941 29.698 35.67061346387565 139.74100733053234 29.698 35.67063275824917 139.7410020834171 29.698 35.670627381326554 139.74097239717204 29.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cd22f7d-24e8-43b8-95fb-93fcb6ef9fc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cd22f7d-24e8-43b8-95fb-93fcb6ef9fc3_0">
											<gml:posList>35.67061346387565 139.74100733053234 26.405 35.67061346387565 139.74100733053234 29.698 35.6706080869543 139.7409776442941 29.698 35.6706080869543 139.7409776442941 26.405 35.67061346387565 139.74100733053234 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f88ee1b9-f3d6-4b46-a9aa-c72595fc247e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f88ee1b9-f3d6-4b46-a9aa-c72595fc247e_0">
											<gml:posList>35.67063275824917 139.7410020834171 26.405 35.67063275824917 139.7410020834171 29.698 35.67061346387565 139.74100733053234 29.698 35.67061346387565 139.74100733053234 26.405 35.67063275824917 139.7410020834171 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e648e1de-3c16-4629-8347-364954a092cf_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a1f1e5d-6323-4a4e-b973-a4bd80e89c35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059725392427 139.7409678145288 26.405 35.670610057910075 139.74103244267425 26.405 35.670638652464795 139.74102460002507 26.405 35.67063725393499 139.74101101469248 26.405 35.670648085583615 139.7410072906644 26.405 35.67063819149785 139.74096417732187 26.405 35.67063984042438 139.74096341322783 26.405 35.67064002093608 139.74096372231617 26.405 35.670650502828096 139.74100933144575 26.405 35.67063933787495 139.74101332096853 26.405 35.670640564720365 139.74102635418444 26.405 35.670608121881806 139.74103495241107 26.405 35.67059484776029 139.74096846903183 26.405 35.67059725392427 139.7409678145288 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee066453-c4b5-4d42-a08e-5443bcbace30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063993953295 139.74096335788218 27.42 35.67064002093608 139.74096372231617 27.42 35.67063984042438 139.74096341322783 27.42 35.67063993953295 139.74096335788218 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ebf1cda-dc27-46be-923a-b1510df1094f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ebf1cda-dc27-46be-923a-b1510df1094f_0">
											<gml:posList>35.67064002093608 139.74096372231617 26.405 35.67063984042438 139.74096341322783 26.405 35.67063984042438 139.74096341322783 27.42 35.67064002093608 139.74096372231617 27.42 35.67064002093608 139.74096372231617 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-304fbc8a-d2b6-46e8-a080-c54a575a9a88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-304fbc8a-d2b6-46e8-a080-c54a575a9a88_0">
											<gml:posList>35.67063819149785 139.74096417732187 26.405 35.67063819149785 139.74096417732187 28.095 35.67063993953295 139.74096335788218 28.095 35.67063993953295 139.74096335788218 27.42 35.67063984042438 139.74096341322783 27.42 35.67063984042438 139.74096341322783 26.405 35.67063819149785 139.74096417732187 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9225b225-7647-416f-a8eb-24aeb768b23f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9225b225-7647-416f-a8eb-24aeb768b23f_0">
											<gml:posList>35.67059484776029 139.74096846903183 26.405 35.67059484776029 139.74096846903183 28.095 35.67059725392427 139.7409678145288 28.095 35.67059725392427 139.7409678145288 26.405 35.67059484776029 139.74096846903183 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35e6d1d7-f022-4740-b281-6a555bb9cf50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35e6d1d7-f022-4740-b281-6a555bb9cf50_0">
											<gml:posList>35.670648085583615 139.7410072906644 26.405 35.670648085583615 139.7410072906644 28.095 35.67063819149785 139.74096417732187 28.095 35.67063819149785 139.74096417732187 26.405 35.670648085583615 139.7410072906644 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2c2c26a-5254-4514-a84d-74858113d4c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2c2c26a-5254-4514-a84d-74858113d4c9_0">
											<gml:posList>35.67063993953295 139.74096335788218 28.095 35.670650502828096 139.74100933144575 28.095 35.670650502828096 139.74100933144575 26.405 35.67064002093608 139.74096372231617 26.405 35.67064002093608 139.74096372231617 27.42 35.67063993953295 139.74096335788218 27.42 35.67063993953295 139.74096335788218 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03a82ebb-f03e-4f7d-9bca-ad5182b02f08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03a82ebb-f03e-4f7d-9bca-ad5182b02f08_0">
											<gml:posList>35.67063819149785 139.74096417732187 28.095 35.670648085583615 139.7410072906644 28.095 35.67063725393499 139.74101101469248 28.095 35.670638652464795 139.74102460002507 28.095 35.670610057910075 139.74103244267425 28.095 35.67059725392427 139.7409678145288 28.095 35.67059484776029 139.74096846903183 28.095 35.670608121881806 139.74103495241107 28.095 35.670640564720365 139.74102635418444 28.095 35.67063933787495 139.74101332096853 28.095 35.670650502828096 139.74100933144575 28.095 35.67063993953295 139.74096335788218 28.095 35.67063819149785 139.74096417732187 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b9b2971-fd54-45b5-9f58-7de1cf341370">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b9b2971-fd54-45b5-9f58-7de1cf341370_0">
											<gml:posList>35.67059725392427 139.7409678145288 26.405 35.67059725392427 139.7409678145288 28.095 35.670610057910075 139.74103244267425 28.095 35.670610057910075 139.74103244267425 26.405 35.67059725392427 139.7409678145288 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13d2a635-8ff9-4b49-9caf-56dcfd952562">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13d2a635-8ff9-4b49-9caf-56dcfd952562_0">
											<gml:posList>35.670608121881806 139.74103495241107 26.405 35.670608121881806 139.74103495241107 28.095 35.67059484776029 139.74096846903183 28.095 35.67059484776029 139.74096846903183 26.405 35.670608121881806 139.74103495241107 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd6a24d6-3c72-4b58-ae1e-a1383100b8f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd6a24d6-3c72-4b58-ae1e-a1383100b8f3_0">
											<gml:posList>35.67063725393499 139.74101101469248 26.405 35.67063725393499 139.74101101469248 28.095 35.670648085583615 139.7410072906644 28.095 35.670648085583615 139.7410072906644 26.405 35.67063725393499 139.74101101469248 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35ea6894-beb3-4528-87ca-756a9b412767">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35ea6894-beb3-4528-87ca-756a9b412767_0">
											<gml:posList>35.670650502828096 139.74100933144575 26.405 35.670650502828096 139.74100933144575 28.095 35.67063933787495 139.74101332096853 28.095 35.67063933787495 139.74101332096853 26.405 35.670650502828096 139.74100933144575 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d5e6ca4-465e-492e-9ee9-fc4f5054cd6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d5e6ca4-465e-492e-9ee9-fc4f5054cd6a_0">
											<gml:posList>35.670638652464795 139.74102460002507 26.405 35.670638652464795 139.74102460002507 28.095 35.67063725393499 139.74101101469248 28.095 35.67063725393499 139.74101101469248 26.405 35.670638652464795 139.74102460002507 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5863313-77db-4af8-a0c7-28350e74423f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5863313-77db-4af8-a0c7-28350e74423f_0">
											<gml:posList>35.67063933787495 139.74101332096853 26.405 35.67063933787495 139.74101332096853 28.095 35.670640564720365 139.74102635418444 28.095 35.670640564720365 139.74102635418444 26.405 35.67063933787495 139.74101332096853 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88e1feb4-4f7b-4e88-9451-65855af10ce5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88e1feb4-4f7b-4e88-9451-65855af10ce5_0">
											<gml:posList>35.670610057910075 139.74103244267425 28.095 35.670638652464795 139.74102460002507 28.095 35.670638652464795 139.74102460002507 26.405 35.670610057910075 139.74103244267425 26.405 35.670610057910075 139.74103244267425 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d876084-0956-4e00-8e1e-cca210cb03c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d876084-0956-4e00-8e1e-cca210cb03c1_0">
											<gml:posList>35.670640564720365 139.74102635418444 26.405 35.670640564720365 139.74102635418444 28.095 35.670608121881806 139.74103495241107 28.095 35.670608121881806 139.74103495241107 26.405 35.670640564720365 139.74102635418444 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-20e0e32c-f7ca-408e-94ce-f65de1be62d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20e0e32c-f7ca-408e-94ce-f65de1be62d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20e0e32c-f7ca-408e-94ce-f65de1be62d0">
											<gml:posList>35.67064139798556 139.74105509568597 9.857 35.67058463244 139.74108244534986 9.857 35.670554496649366 139.7409493502149 9.857 35.67058445948785 139.74093916415185 9.857 35.67059331755291 139.74093599470538 9.857 35.670585953898126 139.7409014945882 9.857 35.6706021543046 139.7408933127032 9.857 35.6706655117448 139.7409989527346 9.857 35.67064139798556 139.74105509568597 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9457a97-4409-4d5f-8040-d9f5f875e2cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9457a97-4409-4d5f-8040-d9f5f875e2cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9457a97-4409-4d5f-8040-d9f5f875e2cf">
											<gml:posList>35.6706021543046 139.7408933127032 27.42 35.670585953898126 139.7409014945882 27.42 35.67059012921883 139.7409040525136 27.42 35.67060095952443 139.740898583161 27.42 35.6706021543046 139.7408933127032 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3acac00b-e51c-4057-b387-49b112489973">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3acac00b-e51c-4057-b387-49b112489973">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3acac00b-e51c-4057-b387-49b112489973">
											<gml:posList>35.67059331755291 139.74093599470538 27.42 35.67059758332372 139.7409389612413 27.42 35.67059012921883 139.7409040525136 27.42 35.670585953898126 139.7409014945882 27.42 35.67059331755291 139.74093599470538 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e591a44-04a9-4c78-a667-0f71bc933fb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e591a44-04a9-4c78-a667-0f71bc933fb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e591a44-04a9-4c78-a667-0f71bc933fb1">
											<gml:posList>35.67059331755291 139.74093599470538 27.42 35.67058458564605 139.74093911982132 27.42 35.67058875229127 139.74094211961014 27.42 35.67059758332372 139.7409389612413 27.42 35.67059331755291 139.74093599470538 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-95add2f3-a74d-4590-9ac7-0f78a130eacc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95add2f3-a74d-4590-9ac7-0f78a130eacc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95add2f3-a74d-4590-9ac7-0f78a130eacc">
											<gml:posList>35.67058458564605 139.74093911982132 27.42 35.670609203814024 139.7410706085931 27.42 35.670611714181995 139.74106478430875 27.42 35.67058875229127 139.74094211961014 27.42 35.67058458564605 139.74093911982132 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44514ac5-e518-48a2-b044-e17c813beb33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44514ac5-e518-48a2-b044-e17c813beb33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44514ac5-e518-48a2-b044-e17c813beb33">
											<gml:posList>35.670609203814024 139.7410706085931 27.42 35.67058458564605 139.74093911982132 27.42 35.670554496649366 139.7409493502149 21.227 35.670609203814024 139.7410706085931 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5bd8acae-73e8-4805-ba18-bc977abffeb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bd8acae-73e8-4805-ba18-bc977abffeb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bd8acae-73e8-4805-ba18-bc977abffeb9">
											<gml:posList>35.670554496649366 139.7409493502149 21.227 35.67058463244 139.74108244534986 21.227 35.670609203814024 139.7410706085931 27.42 35.670554496649366 139.7409493502149 21.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fdee8c22-fbe7-4b49-95d6-c8e29ab6c00b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdee8c22-fbe7-4b49-95d6-c8e29ab6c00b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdee8c22-fbe7-4b49-95d6-c8e29ab6c00b">
											<gml:posList>35.6706655117448 139.7409989527346 27.42 35.6706021543046 139.7408933127032 27.42 35.67060095952443 139.740898583161 27.42 35.67066138374793 139.7409993330627 27.42 35.6706655117448 139.7409989527346 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-227fd471-ec54-4aab-9af4-ea2efdfe883b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-227fd471-ec54-4aab-9af4-ea2efdfe883b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-227fd471-ec54-4aab-9af4-ea2efdfe883b">
											<gml:posList>35.67066138374793 139.7409993330627 26.405 35.67060095952443 139.740898583161 26.405 35.67059012921883 139.7409040525136 26.405 35.67059758332372 139.7409389612413 26.405 35.67058875229127 139.74094211961014 26.405 35.670611714181995 139.74106478430875 26.405 35.67063890758233 139.74105168524704 26.405 35.67066138374793 139.7409993330627 26.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fe3a5064-98dd-4524-8191-8fc752c2aeec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe3a5064-98dd-4524-8191-8fc752c2aeec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe3a5064-98dd-4524-8191-8fc752c2aeec">
											<gml:posList>35.67064139798556 139.74105509568597 27.42 35.6706655117448 139.7409989527346 27.42 35.67066138374793 139.7409993330627 27.42 35.67063890758233 139.74105168524704 27.42 35.67064139798556 139.74105509568597 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-129386ee-d76f-4dfc-94f2-9ca5df3eb6ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-129386ee-d76f-4dfc-94f2-9ca5df3eb6ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-129386ee-d76f-4dfc-94f2-9ca5df3eb6ff">
											<gml:posList>35.67064139798556 139.74105509568597 27.42 35.67063890758233 139.74105168524704 27.42 35.670611714181995 139.74106478430875 27.42 35.670609203814024 139.7410706085931 27.42 35.67064139798556 139.74105509568597 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-620b7aaa-d6d0-48c8-900f-d569bacc9ef5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-620b7aaa-d6d0-48c8-900f-d569bacc9ef5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-620b7aaa-d6d0-48c8-900f-d569bacc9ef5">
											<gml:posList>35.670554496649366 139.7409493502149 21.227 35.67058445948785 139.74093916415185 9.857 35.670554496649366 139.7409493502149 9.857 35.670554496649366 139.7409493502149 21.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f970d9e-1915-43e0-bc1b-1169a72282c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f970d9e-1915-43e0-bc1b-1169a72282c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f970d9e-1915-43e0-bc1b-1169a72282c5">
											<gml:posList>35.67058463244 139.74108244534986 9.857 35.67058463244 139.74108244534986 21.227 35.670554496649366 139.7409493502149 21.227 35.670554496649366 139.7409493502149 9.857 35.67058463244 139.74108244534986 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-781332ae-6b78-417d-b906-94eed4998389">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-781332ae-6b78-417d-b906-94eed4998389">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-781332ae-6b78-417d-b906-94eed4998389">
											<gml:posList>35.670554496649366 139.7409493502149 21.227 35.67058458564605 139.74093911982132 27.42 35.67059331755291 139.74093599470538 27.42 35.67059331755291 139.74093599470538 9.857 35.67058445948785 139.74093916415185 9.857 35.670554496649366 139.7409493502149 21.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-455a0bbb-6267-4630-9527-b1ecfa15f3bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-455a0bbb-6267-4630-9527-b1ecfa15f3bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-455a0bbb-6267-4630-9527-b1ecfa15f3bf">
											<gml:posList>35.670585953898126 139.7409014945882 9.857 35.67059331755291 139.74093599470538 9.857 35.67059331755291 139.74093599470538 27.42 35.670585953898126 139.7409014945882 27.42 35.670585953898126 139.7409014945882 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e73f1762-73cb-4323-aa60-c12ca7c9bc7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e73f1762-73cb-4323-aa60-c12ca7c9bc7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e73f1762-73cb-4323-aa60-c12ca7c9bc7e">
											<gml:posList>35.67058875229127 139.74094211961014 27.42 35.67058875229127 139.74094211961014 26.405 35.67059758332372 139.7409389612413 26.405 35.67059758332372 139.7409389612413 27.42 35.67058875229127 139.74094211961014 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4214982f-ac0d-462d-861b-7cadf23005f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4214982f-ac0d-462d-861b-7cadf23005f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4214982f-ac0d-462d-861b-7cadf23005f0">
											<gml:posList>35.67059758332372 139.7409389612413 27.42 35.67059758332372 139.7409389612413 26.405 35.67059012921883 139.7409040525136 26.405 35.67059012921883 139.7409040525136 27.42 35.67059758332372 139.7409389612413 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e78e5e0b-87a2-4900-8846-1188c67056c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e78e5e0b-87a2-4900-8846-1188c67056c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e78e5e0b-87a2-4900-8846-1188c67056c5">
											<gml:posList>35.6706021543046 139.7408933127032 9.857 35.670585953898126 139.7409014945882 9.857 35.670585953898126 139.7409014945882 27.42 35.6706021543046 139.7408933127032 27.42 35.6706021543046 139.7408933127032 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcc669b8-2c71-4ac6-9b1e-6c1ab27fefa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcc669b8-2c71-4ac6-9b1e-6c1ab27fefa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcc669b8-2c71-4ac6-9b1e-6c1ab27fefa5">
											<gml:posList>35.67059012921883 139.7409040525136 27.42 35.67059012921883 139.7409040525136 26.405 35.67060095952443 139.740898583161 26.405 35.67060095952443 139.740898583161 27.42 35.67059012921883 139.7409040525136 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90cc2679-a5e6-4175-8bc1-923f958eaf6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90cc2679-a5e6-4175-8bc1-923f958eaf6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90cc2679-a5e6-4175-8bc1-923f958eaf6d">
											<gml:posList>35.670611714181995 139.74106478430875 27.42 35.670611714181995 139.74106478430875 26.405 35.67058875229127 139.74094211961014 26.405 35.67058875229127 139.74094211961014 27.42 35.670611714181995 139.74106478430875 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8469ec00-b925-4d99-b1d0-a03a30df7630">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8469ec00-b925-4d99-b1d0-a03a30df7630">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8469ec00-b925-4d99-b1d0-a03a30df7630">
											<gml:posList>35.67064139798556 139.74105509568597 27.42 35.670609203814024 139.7410706085931 27.42 35.67058463244 139.74108244534986 21.227 35.67058463244 139.74108244534986 9.857 35.67064139798556 139.74105509568597 9.857 35.67064139798556 139.74105509568597 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e58b18d-1571-4262-9359-48c0c4b5af63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e58b18d-1571-4262-9359-48c0c4b5af63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e58b18d-1571-4262-9359-48c0c4b5af63">
											<gml:posList>35.67063890758233 139.74105168524704 27.42 35.67063890758233 139.74105168524704 26.405 35.670611714181995 139.74106478430875 26.405 35.670611714181995 139.74106478430875 27.42 35.67063890758233 139.74105168524704 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d348c884-1c5e-4037-8ce1-8a1a45fcc822">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d348c884-1c5e-4037-8ce1-8a1a45fcc822">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d348c884-1c5e-4037-8ce1-8a1a45fcc822">
											<gml:posList>35.67060095952443 139.740898583161 27.42 35.67060095952443 139.740898583161 26.405 35.67066138374793 139.7409993330627 26.405 35.67066138374793 139.7409993330627 27.42 35.67060095952443 139.740898583161 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33799dc0-411f-4af1-9428-5961aa9e82bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33799dc0-411f-4af1-9428-5961aa9e82bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33799dc0-411f-4af1-9428-5961aa9e82bb">
											<gml:posList>35.6706655117448 139.7409989527346 9.857 35.6706021543046 139.7408933127032 9.857 35.6706021543046 139.7408933127032 27.42 35.6706655117448 139.7409989527346 27.42 35.6706655117448 139.7409989527346 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-add4cdad-4894-48df-ac43-5861885b6fbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-add4cdad-4894-48df-ac43-5861885b6fbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-add4cdad-4894-48df-ac43-5861885b6fbc">
											<gml:posList>35.67066138374793 139.7409993330627 27.42 35.67066138374793 139.7409993330627 26.405 35.67063890758233 139.74105168524704 26.405 35.67063890758233 139.74105168524704 27.42 35.67066138374793 139.7409993330627 27.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-195cab26-ce8c-44ee-9750-cf2361007cba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-195cab26-ce8c-44ee-9750-cf2361007cba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-195cab26-ce8c-44ee-9750-cf2361007cba">
											<gml:posList>35.67064139798556 139.74105509568597 9.857 35.6706655117448 139.7409989527346 9.857 35.6706655117448 139.7409989527346 27.42 35.67064139798556 139.74105509568597 27.42 35.67064139798556 139.74105509568597 9.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9170</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">131.187</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>