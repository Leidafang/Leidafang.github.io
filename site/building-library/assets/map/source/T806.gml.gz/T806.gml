<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e660c491-81cc-4343-92d2-0b82f4b7302d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">13.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66933794992458 139.73888194700305 0 35.669383144109865 139.7389270724037 0 35.66941719086665 139.73889499854909 0 35.669370038095906 139.73865148713833 0 35.6693561544425 139.7386483001587 0 35.669292410376514 139.73874138367495 0 35.66930143234337 139.73875186683654 0 35.66929603078952 139.7387603787129 0 35.669317138691156 139.7387804577415 0 35.66932239544214 139.73881712463944 0 35.66931168159494 139.73883304367018 0 35.66933595174107 139.73886261865493 0 35.66933794992458 139.73888194700305 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66933794992458 139.73888194700305 15.623 35.66933595174107 139.73886261865493 15.623 35.66931168159494 139.73883304367018 15.623 35.66932239544214 139.73881712463944 15.623 35.669317138691156 139.7387804577415 15.623 35.66929603078952 139.7387603787129 15.623 35.66930143234337 139.73875186683654 15.623 35.669292410376514 139.73874138367495 15.623 35.6693561544425 139.7386483001587 15.623 35.669370038095906 139.73865148713833 15.623 35.66941719086665 139.73889499854909 15.623 35.669383144109865 139.7389270724037 15.623 35.66933794992458 139.73888194700305 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66933794992458 139.73888194700305 15.623 35.669383144109865 139.7389270724037 15.623 35.669383144109865 139.7389270724037 28.88 35.66933794992458 139.73888194700305 28.88 35.66933794992458 139.73888194700305 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669383144109865 139.7389270724037 15.623 35.66941719086665 139.73889499854909 15.623 35.66941719086665 139.73889499854909 28.88 35.669383144109865 139.7389270724037 28.88 35.669383144109865 139.7389270724037 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66941719086665 139.73889499854909 15.623 35.669370038095906 139.73865148713833 15.623 35.669370038095906 139.73865148713833 28.88 35.66941719086665 139.73889499854909 28.88 35.66941719086665 139.73889499854909 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669370038095906 139.73865148713833 15.623 35.6693561544425 139.7386483001587 15.623 35.6693561544425 139.7386483001587 28.88 35.669370038095906 139.73865148713833 28.88 35.669370038095906 139.73865148713833 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6693561544425 139.7386483001587 15.623 35.669292410376514 139.73874138367495 15.623 35.669292410376514 139.73874138367495 28.88 35.6693561544425 139.7386483001587 28.88 35.6693561544425 139.7386483001587 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669292410376514 139.73874138367495 15.623 35.66930143234337 139.73875186683654 15.623 35.66930143234337 139.73875186683654 28.88 35.669292410376514 139.73874138367495 28.88 35.669292410376514 139.73874138367495 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66930143234337 139.73875186683654 15.623 35.66929603078952 139.7387603787129 15.623 35.66929603078952 139.7387603787129 28.88 35.66930143234337 139.73875186683654 28.88 35.66930143234337 139.73875186683654 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929603078952 139.7387603787129 15.623 35.669317138691156 139.7387804577415 15.623 35.669317138691156 139.7387804577415 28.88 35.66929603078952 139.7387603787129 28.88 35.66929603078952 139.7387603787129 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669317138691156 139.7387804577415 15.623 35.66932239544214 139.73881712463944 15.623 35.66932239544214 139.73881712463944 28.88 35.669317138691156 139.7387804577415 28.88 35.669317138691156 139.7387804577415 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66932239544214 139.73881712463944 15.623 35.66931168159494 139.73883304367018 15.623 35.66931168159494 139.73883304367018 28.88 35.66932239544214 139.73881712463944 28.88 35.66932239544214 139.73881712463944 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931168159494 139.73883304367018 15.623 35.66933595174107 139.73886261865493 15.623 35.66933595174107 139.73886261865493 28.88 35.66931168159494 139.73883304367018 28.88 35.66931168159494 139.73883304367018 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66933595174107 139.73886261865493 15.623 35.66933794992458 139.73888194700305 15.623 35.66933794992458 139.73888194700305 28.88 35.66933595174107 139.73886261865493 28.88 35.66933595174107 139.73886261865493 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66933794992458 139.73888194700305 28.88 35.669383144109865 139.7389270724037 28.88 35.66941719086665 139.73889499854909 28.88 35.669370038095906 139.73865148713833 28.88 35.6693561544425 139.7386483001587 28.88 35.669292410376514 139.73874138367495 28.88 35.66930143234337 139.73875186683654 28.88 35.66929603078952 139.7387603787129 28.88 35.669317138691156 139.7387804577415 28.88 35.66932239544214 139.73881712463944 28.88 35.66931168159494 139.73883304367018 28.88 35.66933595174107 139.73886261865493 28.88 35.66933794992458 139.73888194700305 28.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c4ad5e90-a2a1-4b3b-9f58-411b8c6de16a"/>
							<gml:surfaceMember xlink:href="#poly-a1e80b74-448b-4dfa-a629-0d8e8ac9d4fd"/>
							<gml:surfaceMember xlink:href="#poly-d0404416-60dc-4d69-812c-d35115435615"/>
							<gml:surfaceMember xlink:href="#poly-3a035d93-8d15-45ce-9b7e-b6eacf4babfe"/>
							<gml:surfaceMember xlink:href="#poly-b9c494af-43c1-4be0-9c03-6e40ed1ffc38"/>
							<gml:surfaceMember xlink:href="#poly-a6ddfe68-4324-4a2b-8778-00af52385d75"/>
							<gml:surfaceMember xlink:href="#poly-263e7d63-d6a0-47e1-91ca-a76c46e81abf"/>
							<gml:surfaceMember xlink:href="#poly-47c86f5f-8c30-48bf-9bb5-70fa9fc41284"/>
							<gml:surfaceMember xlink:href="#poly-c486cbfd-e307-45ac-8e75-867c3e4ff390"/>
							<gml:surfaceMember xlink:href="#poly-4d1cc031-a461-446b-9fd6-7e314a6f7c0b"/>
							<gml:surfaceMember xlink:href="#poly-0b150efb-d171-41ca-987c-6dcee7050389"/>
							<gml:surfaceMember xlink:href="#poly-8726d803-54b8-44fe-91e6-7d5fa14418b0"/>
							<gml:surfaceMember xlink:href="#poly-469e87c5-e5a4-4c48-9d92-c4f245b119f3"/>
							<gml:surfaceMember xlink:href="#poly-b51ddd0b-8c48-42b8-95ff-7ec5e937a36d"/>
							<gml:surfaceMember xlink:href="#poly-96eac6c9-e9c3-4f2f-a3e5-59cad3d10084"/>
							<gml:surfaceMember xlink:href="#poly-f5c6954a-a75f-4c51-979d-316579ddfb82"/>
							<gml:surfaceMember xlink:href="#poly-74dfd532-4cb7-491d-937a-d53591f3fe4c"/>
							<gml:surfaceMember xlink:href="#poly-6037daff-8ade-4a03-9cbd-ccae036e2796"/>
							<gml:surfaceMember xlink:href="#poly-5c16596b-fc44-427f-83a6-02a60d235b60"/>
							<gml:surfaceMember xlink:href="#poly-5905a554-c57d-4140-b2cf-598eec1258b3"/>
							<gml:surfaceMember xlink:href="#poly-bf5f5e5b-c108-4eb3-99af-abc34ed9a039"/>
							<gml:surfaceMember xlink:href="#poly-0fe741e5-f7bc-4c37-8c44-5415800f586e"/>
							<gml:surfaceMember xlink:href="#poly-82f97141-f40c-4210-8aa4-84f719e8fc4a"/>
							<gml:surfaceMember xlink:href="#poly-333b7694-79ab-4ac6-8e81-f941fbd17a2d"/>
							<gml:surfaceMember xlink:href="#poly-c97a2824-66e3-4f5a-b953-9065a4ad430f"/>
							<gml:surfaceMember xlink:href="#poly-6a010555-e351-4df0-bfef-938f4988904b"/>
							<gml:surfaceMember xlink:href="#poly-dacd7b53-162a-4297-86eb-1675b95b6639"/>
							<gml:surfaceMember xlink:href="#poly-3fa3a4b2-d512-4e1f-9738-ca45b26887eb"/>
							<gml:surfaceMember xlink:href="#poly-c871cc80-e10b-4042-9126-ad404303751f"/>
							<gml:surfaceMember xlink:href="#poly-32c3aa39-490a-44ee-8a9f-0b89dcba0a21"/>
							<gml:surfaceMember xlink:href="#poly-3a3d25ed-cd4e-48db-aa63-08f10384ae83"/>
							<gml:surfaceMember xlink:href="#poly-cb1242fc-57d7-426f-a809-79d4ffb90a6d"/>
							<gml:surfaceMember xlink:href="#poly-600fd4f9-aeb3-4d9c-a8bb-0fe18379afa4"/>
							<gml:surfaceMember xlink:href="#poly-10464f5d-67d7-4a12-aff8-09750579d70a"/>
							<gml:surfaceMember xlink:href="#poly-e7b0896b-25ed-4682-88bc-b6c61f2cfa2c"/>
							<gml:surfaceMember xlink:href="#poly-98e75bad-0037-48f7-a8fd-f1b3779fdeec"/>
							<gml:surfaceMember xlink:href="#poly-9cd53a99-e4ce-417f-b5a7-e60b63a7a0ef"/>
							<gml:surfaceMember xlink:href="#poly-5d78375f-6e80-4c00-87c0-d1b3565abf5b"/>
							<gml:surfaceMember xlink:href="#poly-4dbbbf43-21e0-4aac-9707-268aa8a85434"/>
							<gml:surfaceMember xlink:href="#poly-aa8d5719-4a3d-40cb-b399-ba7622f198d4"/>
							<gml:surfaceMember xlink:href="#poly-6c50929c-e572-410a-9738-ed1a39f21861"/>
							<gml:surfaceMember xlink:href="#poly-9f41882d-a0d3-4bf8-b307-49283a054222"/>
							<gml:surfaceMember xlink:href="#poly-d9257c5d-822b-4a89-8e5c-b30028af43af"/>
							<gml:surfaceMember xlink:href="#poly-cc4ed2a8-e686-4717-9061-43e9acb50a58"/>
							<gml:surfaceMember xlink:href="#poly-5c2fce0a-9267-4987-b15c-ce95311628ed"/>
							<gml:surfaceMember xlink:href="#poly-6dbd33e9-5402-428d-a43e-24a7da4e2a71"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e660c491-81cc-4343-92d2-0b82f4b7302d_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c160aff5-db6b-409d-b97a-954aa9f289d7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66935280924183 139.73877307000873 29.309 35.66935395463533 139.73877389711677 29.309 35.66935493798997 139.73877498952274 29.309 35.66935572322485 139.7387763141309 29.309 35.669356256214215 139.7387778157744 29.309 35.66935652788364 139.7387794171412 29.309 35.66935652015363 139.7387810519758 29.309 35.669356232963466 139.7387826429555 29.309 35.66935568429722 139.73878413482842 29.309 35.66935490113538 139.73878545023996 29.309 35.66935390146201 139.73878653393834 29.309 35.6693527483385 139.73878734166468 29.309 35.66935147779373 139.73878784023813 29.309 35.669350152906425 139.73878800749213 29.309 35.66934882774159 139.7387878212707 29.309 35.669347556407565 139.73878731464842 29.309 35.66934641101416 139.73878648754027 29.309 35.669345427650946 139.73878538408817 29.309 35.66934464241618 139.7387840594801 29.309 35.66934410943555 139.73878256888287 29.309 35.66934383776617 139.73878096751633 29.309 35.66934384549617 139.738779332682 29.309 35.6693441326863 139.73877774170253 29.309 35.669344681352456 139.73877624982975 29.309 35.66934546451421 139.73877493441827 29.309 35.6693464641788 139.73877383967377 29.309 35.66934761730222 139.73877303194735 29.309 35.6693488878556 139.73877254441976 29.309 35.66935021274289 139.7387723771655 29.309 35.66935153789907 139.73877255234055 29.309 35.66935280924183 139.73877307000873 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f817f41e-5756-48e1-b822-3b3351cd4718">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669365917789534 139.73881079913974 29.309 35.66934467591947 139.73881525367392 29.309 35.669342545710755 139.73879999045226 29.309 35.66936377856653 139.73879553592482 29.309 35.669365917789534 139.73881079913974 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78475c2e-85c7-4829-ad2c-7ec78a46b4c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78475c2e-85c7-4829-ad2c-7ec78a46b4c9_0">
											<gml:posList>35.6693488878556 139.73877254441976 29.309 35.6693488878556 139.73877254441976 34.114 35.66935021274289 139.7387723771655 34.114 35.66935021274289 139.7387723771655 29.309 35.6693488878556 139.73877254441976 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f624107-f775-4631-9578-48950b0ccd5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f624107-f775-4631-9578-48950b0ccd5c_0">
											<gml:posList>35.66935153789907 139.73877255234055 29.309 35.66935021274289 139.7387723771655 29.309 35.66935021274289 139.7387723771655 34.114 35.66935153789907 139.73877255234055 34.114 35.66935153789907 139.73877255234055 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08bc81ef-3ebb-4196-b0c0-25b2ba52274d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08bc81ef-3ebb-4196-b0c0-25b2ba52274d_0">
											<gml:posList>35.6693488878556 139.73877254441976 29.309 35.66934761730222 139.73877303194735 29.309 35.66934761730222 139.73877303194735 34.114 35.6693488878556 139.73877254441976 34.114 35.6693488878556 139.73877254441976 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3858359-01f2-449c-9329-16f1881923fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3858359-01f2-449c-9329-16f1881923fd_0">
											<gml:posList>35.66935280924183 139.73877307000873 29.309 35.66935153789907 139.73877255234055 29.309 35.66935153789907 139.73877255234055 34.114 35.66935280924183 139.73877307000873 34.114 35.66935280924183 139.73877307000873 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f217f87d-6eaa-4381-97cf-d594d892d464">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f217f87d-6eaa-4381-97cf-d594d892d464_0">
											<gml:posList>35.66934761730222 139.73877303194735 29.309 35.6693464641788 139.73877383967377 29.309 35.6693464641788 139.73877383967377 34.114 35.66934761730222 139.73877303194735 34.114 35.66934761730222 139.73877303194735 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4d0dc0b-ed04-41a5-81d5-be4199916b73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4d0dc0b-ed04-41a5-81d5-be4199916b73_0">
											<gml:posList>35.66935280924183 139.73877307000873 29.309 35.66935280924183 139.73877307000873 34.114 35.66935395463533 139.73877389711677 34.114 35.66935395463533 139.73877389711677 29.309 35.66935280924183 139.73877307000873 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9996d252-4454-4c88-824b-be020fd29b11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9996d252-4454-4c88-824b-be020fd29b11_0">
											<gml:posList>35.6693464641788 139.73877383967377 29.309 35.66934546451421 139.73877493441827 29.309 35.66934546451421 139.73877493441827 34.114 35.6693464641788 139.73877383967377 34.114 35.6693464641788 139.73877383967377 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e25c35a5-beb2-4a86-91f3-c107489c93e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e25c35a5-beb2-4a86-91f3-c107489c93e8_0">
											<gml:posList>35.66935493798997 139.73877498952274 29.309 35.66935395463533 139.73877389711677 29.309 35.66935395463533 139.73877389711677 34.114 35.66935493798997 139.73877498952274 34.114 35.66935493798997 139.73877498952274 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52e84866-eb21-4b0b-a94b-2814f44cf3c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52e84866-eb21-4b0b-a94b-2814f44cf3c3_0">
											<gml:posList>35.669344681352456 139.73877624982975 29.309 35.669344681352456 139.73877624982975 34.114 35.66934546451421 139.73877493441827 34.114 35.66934546451421 139.73877493441827 29.309 35.669344681352456 139.73877624982975 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2081294-34bb-4ac1-91e3-950e9b82205d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2081294-34bb-4ac1-91e3-950e9b82205d_0">
											<gml:posList>35.66935572322485 139.7387763141309 29.309 35.66935493798997 139.73877498952274 29.309 35.66935493798997 139.73877498952274 34.114 35.66935572322485 139.7387763141309 34.114 35.66935572322485 139.7387763141309 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17afbfcc-f799-4ba2-9aef-f0be14577d23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17afbfcc-f799-4ba2-9aef-f0be14577d23_0">
											<gml:posList>35.669344681352456 139.73877624982975 29.309 35.6693441326863 139.73877774170253 29.309 35.6693441326863 139.73877774170253 34.114 35.669344681352456 139.73877624982975 34.114 35.669344681352456 139.73877624982975 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52f41092-82cf-4490-91c0-ad7f2c96ccd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52f41092-82cf-4490-91c0-ad7f2c96ccd0_0">
											<gml:posList>35.669356256214215 139.7387778157744 29.309 35.66935572322485 139.7387763141309 29.309 35.66935572322485 139.7387763141309 34.114 35.669356256214215 139.7387778157744 34.114 35.669356256214215 139.7387778157744 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a938e6c-35a7-46af-9c93-e535ef54c2f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a938e6c-35a7-46af-9c93-e535ef54c2f0_0">
											<gml:posList>35.66934384549617 139.738779332682 29.309 35.66934384549617 139.738779332682 34.114 35.6693441326863 139.73877774170253 34.114 35.6693441326863 139.73877774170253 29.309 35.66934384549617 139.738779332682 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7dd72151-b083-43a6-8e64-28321e194609">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7dd72151-b083-43a6-8e64-28321e194609_0">
											<gml:posList>35.66935652788364 139.7387794171412 29.309 35.669356256214215 139.7387778157744 29.309 35.669356256214215 139.7387778157744 34.114 35.66935652788364 139.7387794171412 34.114 35.66935652788364 139.7387794171412 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d649e017-ff01-49fb-ac19-ceda4eae016f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d649e017-ff01-49fb-ac19-ceda4eae016f_0">
											<gml:posList>35.66934384549617 139.738779332682 29.309 35.66934383776617 139.73878096751633 29.309 35.66934383776617 139.73878096751633 34.114 35.66934384549617 139.738779332682 34.114 35.66934384549617 139.738779332682 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3695640d-0f8e-460f-ba7e-0966095ec2b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3695640d-0f8e-460f-ba7e-0966095ec2b6_0">
											<gml:posList>35.66935021274289 139.7387723771655 34.114 35.6693488878556 139.73877254441976 34.114 35.66934761730222 139.73877303194735 34.114 35.6693464641788 139.73877383967377 34.114 35.66934546451421 139.73877493441827 34.114 35.669344681352456 139.73877624982975 34.114 35.6693441326863 139.73877774170253 34.114 35.66934384549617 139.738779332682 34.114 35.66934383776617 139.73878096751633 34.114 35.66934410943555 139.73878256888287 34.114 35.66934464241618 139.7387840594801 34.114 35.669345427650946 139.73878538408817 34.114 35.66934641101416 139.73878648754027 34.114 35.669347556407565 139.73878731464842 34.114 35.66934882774159 139.7387878212707 34.114 35.669350152906425 139.73878800749213 34.114 35.66935147779373 139.73878784023813 34.114 35.6693527483385 139.73878734166468 34.114 35.66935390146201 139.73878653393834 34.114 35.66935490113538 139.73878545023996 34.114 35.66935568429722 139.73878413482842 34.114 35.669356232963466 139.7387826429555 34.114 35.66935652015363 139.7387810519758 34.114 35.66935652788364 139.7387794171412 34.114 35.669356256214215 139.7387778157744 34.114 35.66935572322485 139.7387763141309 34.114 35.66935493798997 139.73877498952274 34.114 35.66935395463533 139.73877389711677 34.114 35.66935280924183 139.73877307000873 34.114 35.66935153789907 139.73877255234055 34.114 35.66935021274289 139.7387723771655 34.114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ea479c4-3fb6-4e3a-9cb2-3f551564f2ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ea479c4-3fb6-4e3a-9cb2-3f551564f2ab_0">
											<gml:posList>35.66935652015363 139.7387810519758 29.309 35.66935652788364 139.7387794171412 29.309 35.66935652788364 139.7387794171412 34.114 35.66935652015363 139.7387810519758 34.114 35.66935652015363 139.7387810519758 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4e3c959-94a9-4c6d-95df-4ab41cd0b143">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4e3c959-94a9-4c6d-95df-4ab41cd0b143_0">
											<gml:posList>35.66934383776617 139.73878096751633 29.309 35.66934410943555 139.73878256888287 29.309 35.66934410943555 139.73878256888287 34.114 35.66934383776617 139.73878096751633 34.114 35.66934383776617 139.73878096751633 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92984f5b-83af-41e3-9d9d-3d804d642837">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92984f5b-83af-41e3-9d9d-3d804d642837_0">
											<gml:posList>35.669356232963466 139.7387826429555 29.309 35.66935652015363 139.7387810519758 29.309 35.66935652015363 139.7387810519758 34.114 35.669356232963466 139.7387826429555 34.114 35.669356232963466 139.7387826429555 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01314a54-a230-426a-a3e2-5c718e705004">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01314a54-a230-426a-a3e2-5c718e705004_0">
											<gml:posList>35.66934464241618 139.7387840594801 29.309 35.66934464241618 139.7387840594801 34.114 35.66934410943555 139.73878256888287 34.114 35.66934410943555 139.73878256888287 29.309 35.66934464241618 139.7387840594801 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd97dbc5-c774-419f-aa31-0e6f0c6c8332">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd97dbc5-c774-419f-aa31-0e6f0c6c8332_0">
											<gml:posList>35.669356232963466 139.7387826429555 29.309 35.669356232963466 139.7387826429555 34.114 35.66935568429722 139.73878413482842 34.114 35.66935568429722 139.73878413482842 29.309 35.669356232963466 139.7387826429555 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b31a49b9-4e1a-4f82-9bda-43db7bd33cfc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b31a49b9-4e1a-4f82-9bda-43db7bd33cfc_0">
											<gml:posList>35.66934464241618 139.7387840594801 29.309 35.669345427650946 139.73878538408817 29.309 35.669345427650946 139.73878538408817 34.114 35.66934464241618 139.7387840594801 34.114 35.66934464241618 139.7387840594801 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-931f3901-4d83-4810-a552-555baa3e83b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-931f3901-4d83-4810-a552-555baa3e83b9_0">
											<gml:posList>35.66935568429722 139.73878413482842 29.309 35.66935568429722 139.73878413482842 34.114 35.66935490113538 139.73878545023996 34.114 35.66935490113538 139.73878545023996 29.309 35.66935568429722 139.73878413482842 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d4a9f68-02ab-4271-b88c-131b46c8f34c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d4a9f68-02ab-4271-b88c-131b46c8f34c_0">
											<gml:posList>35.669345427650946 139.73878538408817 29.309 35.66934641101416 139.73878648754027 29.309 35.66934641101416 139.73878648754027 34.114 35.669345427650946 139.73878538408817 34.114 35.669345427650946 139.73878538408817 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f7aeda2-4a9c-491c-b17f-6db3f405c278">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f7aeda2-4a9c-491c-b17f-6db3f405c278_0">
											<gml:posList>35.66935390146201 139.73878653393834 29.309 35.66935490113538 139.73878545023996 29.309 35.66935490113538 139.73878545023996 34.114 35.66935390146201 139.73878653393834 34.114 35.66935390146201 139.73878653393834 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a57176e4-44e1-4527-ad25-d34ebab8a214">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a57176e4-44e1-4527-ad25-d34ebab8a214_0">
											<gml:posList>35.669347556407565 139.73878731464842 29.309 35.669347556407565 139.73878731464842 34.114 35.66934641101416 139.73878648754027 34.114 35.66934641101416 139.73878648754027 29.309 35.669347556407565 139.73878731464842 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-300d9469-675e-454b-aa3f-340e770b269b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-300d9469-675e-454b-aa3f-340e770b269b_0">
											<gml:posList>35.6693527483385 139.73878734166468 29.309 35.66935390146201 139.73878653393834 29.309 35.66935390146201 139.73878653393834 34.114 35.6693527483385 139.73878734166468 34.114 35.6693527483385 139.73878734166468 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c204f01b-1c28-4422-9b9e-4bb6b4222ce3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c204f01b-1c28-4422-9b9e-4bb6b4222ce3_0">
											<gml:posList>35.669347556407565 139.73878731464842 29.309 35.66934882774159 139.7387878212707 29.309 35.66934882774159 139.7387878212707 34.114 35.669347556407565 139.73878731464842 34.114 35.669347556407565 139.73878731464842 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f31e7281-35f4-4319-9258-5c8d142273f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f31e7281-35f4-4319-9258-5c8d142273f0_0">
											<gml:posList>35.66935147779373 139.73878784023813 29.309 35.6693527483385 139.73878734166468 29.309 35.6693527483385 139.73878734166468 34.114 35.66935147779373 139.73878784023813 34.114 35.66935147779373 139.73878784023813 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e280f45-fb0f-4d7a-9ce0-704a0b7629a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e280f45-fb0f-4d7a-9ce0-704a0b7629a0_0">
											<gml:posList>35.66934882774159 139.7387878212707 29.309 35.669350152906425 139.73878800749213 29.309 35.669350152906425 139.73878800749213 34.114 35.66934882774159 139.7387878212707 34.114 35.66934882774159 139.7387878212707 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1333db7-0984-4e2e-9d5f-568a332124c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1333db7-0984-4e2e-9d5f-568a332124c1_0">
											<gml:posList>35.669350152906425 139.73878800749213 29.309 35.66935147779373 139.73878784023813 29.309 35.66935147779373 139.73878784023813 34.114 35.669350152906425 139.73878800749213 34.114 35.669350152906425 139.73878800749213 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-028b4945-f74f-491f-b7cd-8f4162d2d1c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-028b4945-f74f-491f-b7cd-8f4162d2d1c5_0">
											<gml:posList>35.66936377856653 139.73879553592482 29.309 35.669342545710755 139.73879999045226 29.309 35.669342545710755 139.73879999045226 32.077 35.66936377856653 139.73879553592482 32.077 35.66936377856653 139.73879553592482 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-604728a3-3d8a-4cea-a92d-1cc6a38a396e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-604728a3-3d8a-4cea-a92d-1cc6a38a396e_0">
											<gml:posList>35.66936377856653 139.73879553592482 29.309 35.66936377856653 139.73879553592482 32.077 35.669365917789534 139.73881079913974 32.077 35.669365917789534 139.73881079913974 29.309 35.66936377856653 139.73879553592482 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f64734b-9fae-40f1-9274-4763e9db238f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f64734b-9fae-40f1-9274-4763e9db238f_0">
											<gml:posList>35.669342545710755 139.73879999045226 32.077 35.66934467591947 139.73881525367392 32.077 35.669365917789534 139.73881079913974 32.077 35.66936377856653 139.73879553592482 32.077 35.669342545710755 139.73879999045226 32.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c93c9be3-29a2-4c3d-98c3-92fb792e1083">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c93c9be3-29a2-4c3d-98c3-92fb792e1083_0">
											<gml:posList>35.66934467591947 139.73881525367392 29.309 35.66934467591947 139.73881525367392 32.077 35.669342545710755 139.73879999045226 32.077 35.669342545710755 139.73879999045226 29.309 35.66934467591947 139.73881525367392 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-359bf173-9acf-477f-a6c0-9d55475a1dbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-359bf173-9acf-477f-a6c0-9d55475a1dbd_0">
											<gml:posList>35.669365917789534 139.73881079913974 29.309 35.669365917789534 139.73881079913974 32.077 35.66934467591947 139.73881525367392 32.077 35.66934467591947 139.73881525367392 29.309 35.669365917789534 139.73881079913974 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c4ad5e90-a2a1-4b3b-9f58-411b8c6de16a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4ad5e90-a2a1-4b3b-9f58-411b8c6de16a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4ad5e90-a2a1-4b3b-9f58-411b8c6de16a">
											<gml:posList>35.669335951741076 139.7388626186549 15.623 35.66931168159493 139.73883304367018 15.623 35.66932239544209 139.73881712463944 15.623 35.66931713869115 139.73878045774148 15.623 35.66929603078949 139.7387603787129 15.623 35.669301432343346 139.73875186683654 15.623 35.66929241037651 139.73874138367495 15.623 35.66935615444248 139.7386483001587 15.623 35.66937003809591 139.73865148713836 15.623 35.66941719086665 139.73889499854909 15.623 35.66938314410986 139.7389270724037 15.623 35.66933794992457 139.73888194700305 15.623 35.669335951741076 139.7388626186549 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a1e80b74-448b-4dfa-a629-0d8e8ac9d4fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1e80b74-448b-4dfa-a629-0d8e8ac9d4fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1e80b74-448b-4dfa-a629-0d8e8ac9d4fd">
											<gml:posList>35.669361621316746 139.73869995640115 26.884 35.66937847314303 139.7386950541261 26.884 35.66937003809591 139.73865148713836 26.884 35.66935615444248 139.7386483001587 26.884 35.66933563570086 139.73867825936185 26.884 35.669351043608955 139.7386941033971 26.884 35.669361621316746 139.73869995640115 26.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0404416-60dc-4d69-812c-d35115435615">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0404416-60dc-4d69-812c-d35115435615">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0404416-60dc-4d69-812c-d35115435615">
											<gml:posList>35.669361621316746 139.73869995640115 29.858 35.669351043608955 139.7386941033971 29.858 35.66935164092818 139.7386971735128 29.858 35.66935983797972 139.7387017148388 29.858 35.669361621316746 139.73869995640115 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a035d93-8d15-45ce-9b7e-b6eacf4babfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a035d93-8d15-45ce-9b7e-b6eacf4babfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a035d93-8d15-45ce-9b7e-b6eacf4babfe">
											<gml:posList>35.66933563570086 139.73867825936185 26.884 35.66929241037651 139.73874138367495 26.884 35.66931616572992 139.73874669092237 29.858 35.66933563570086 139.73867825936185 26.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9c494af-43c1-4be0-9c03-6e40ed1ffc38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9c494af-43c1-4be0-9c03-6e40ed1ffc38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9c494af-43c1-4be0-9c03-6e40ed1ffc38">
											<gml:posList>35.66931616572992 139.73874669092237 29.858 35.669351043608955 139.7386941033971 29.858 35.66933563570086 139.73867825936185 26.884 35.66931616572992 139.73874669092237 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6ddfe68-4324-4a2b-8778-00af52385d75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6ddfe68-4324-4a2b-8778-00af52385d75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6ddfe68-4324-4a2b-8778-00af52385d75">
											<gml:posList>35.66931616572992 139.73874669092237 29.858 35.66931836559913 139.73874735109405 29.858 35.66935164092818 139.7386971735128 29.858 35.669351043608955 139.7386941033971 29.858 35.66931616572992 139.73874669092237 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-263e7d63-d6a0-47e1-91ca-a76c46e81abf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-263e7d63-d6a0-47e1-91ca-a76c46e81abf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-263e7d63-d6a0-47e1-91ca-a76c46e81abf">
											<gml:posList>35.66931616572992 139.73874669092237 29.858 35.66929241037651 139.73874138367495 26.884 35.669301432343346 139.73875186683654 26.884 35.66931616572992 139.73874669092237 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47c86f5f-8c30-48bf-9bb5-70fa9fc41284">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47c86f5f-8c30-48bf-9bb5-70fa9fc41284">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47c86f5f-8c30-48bf-9bb5-70fa9fc41284">
											<gml:posList>35.66931616572992 139.73874669092237 29.858 35.669301432343346 139.73875186683654 26.884 35.66931713869115 139.73878045774148 26.884 35.66931616572992 139.73874669092237 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c486cbfd-e307-45ac-8e75-867c3e4ff390">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c486cbfd-e307-45ac-8e75-867c3e4ff390">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c486cbfd-e307-45ac-8e75-867c3e4ff390">
											<gml:posList>35.669301432343346 139.73875186683654 26.884 35.66929603078949 139.7387603787129 26.884 35.66931713869115 139.73878045774148 26.884 35.669301432343346 139.73875186683654 26.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d1cc031-a461-446b-9fd6-7e314a6f7c0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d1cc031-a461-446b-9fd6-7e314a6f7c0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d1cc031-a461-446b-9fd6-7e314a6f7c0b">
											<gml:posList>35.66932794678618 139.73881570419292 29.858 35.66931616572992 139.73874669092237 29.858 35.66931713869115 139.73878045774148 26.884 35.66932794678618 139.73881570419292 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b150efb-d171-41ca-987c-6dcee7050389">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b150efb-d171-41ca-987c-6dcee7050389">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b150efb-d171-41ca-987c-6dcee7050389">
											<gml:posList>35.66932794678618 139.73881570419292 29.858 35.6693299384203 139.7388151937239 29.858 35.66931836559913 139.73874735109405 29.858 35.66931616572992 139.73874669092237 29.858 35.66932794678618 139.73881570419292 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8726d803-54b8-44fe-91e6-7d5fa14418b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8726d803-54b8-44fe-91e6-7d5fa14418b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8726d803-54b8-44fe-91e6-7d5fa14418b0">
											<gml:posList>35.66941719086665 139.73889499854909 26.884 35.66937847314303 139.7386950541261 26.884 35.669361621316746 139.73869995640115 29.858 35.66941719086665 139.73889499854909 26.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-469e87c5-e5a4-4c48-9d92-c4f245b119f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-469e87c5-e5a4-4c48-9d92-c4f245b119f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-469e87c5-e5a4-4c48-9d92-c4f245b119f3">
											<gml:posList>35.66932239544209 139.73881712463944 26.884 35.66932794678618 139.73881570419292 29.858 35.66931713869115 139.73878045774148 26.884 35.66932239544209 139.73881712463944 26.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b51ddd0b-8c48-42b8-95ff-7ec5e937a36d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b51ddd0b-8c48-42b8-95ff-7ec5e937a36d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b51ddd0b-8c48-42b8-95ff-7ec5e937a36d">
											<gml:posList>35.66941719086665 139.73889499854909 26.884 35.669361621316746 139.73869995640115 29.858 35.66939832103586 139.73891277189566 29.858 35.66941719086665 139.73889499854909 26.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96eac6c9-e9c3-4f2f-a3e5-59cad3d10084">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96eac6c9-e9c3-4f2f-a3e5-59cad3d10084">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96eac6c9-e9c3-4f2f-a3e5-59cad3d10084">
											<gml:posList>35.669361621316746 139.73869995640115 29.858 35.66935983797972 139.7387017148388 29.858 35.669396066808055 139.7389117583069 29.858 35.66939832103586 139.73891277189566 29.858 35.669361621316746 139.73869995640115 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5c6954a-a75f-4c51-979d-316579ddfb82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5c6954a-a75f-4c51-979d-316579ddfb82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5c6954a-a75f-4c51-979d-316579ddfb82">
											<gml:posList>35.669383186684286 139.73892389107044 29.309 35.669396066808055 139.7389117583069 29.309 35.66935983797972 139.7387017148388 29.309 35.66935164092818 139.7386971735128 29.309 35.66931836559913 139.73874735109405 29.309 35.6693299384203 139.7388151937239 29.309 35.669337970494574 139.73886220757007 29.309 35.669339877839064 139.7388806412903 29.309 35.669383186684286 139.73892389107044 29.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74dfd532-4cb7-491d-937a-d53591f3fe4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74dfd532-4cb7-491d-937a-d53591f3fe4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74dfd532-4cb7-491d-937a-d53591f3fe4c">
											<gml:posList>35.669335951741076 139.7388626186549 29.858 35.669337970494574 139.73886220757007 29.858 35.6693299384203 139.7388151937239 29.858 35.66932794678618 139.73881570419292 29.858 35.669335951741076 139.7388626186549 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6037daff-8ade-4a03-9cbd-ccae036e2796">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6037daff-8ade-4a03-9cbd-ccae036e2796">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6037daff-8ade-4a03-9cbd-ccae036e2796">
											<gml:posList>35.669335951741076 139.7388626186549 29.858 35.66932794678618 139.73881570419292 29.858 35.66932239544209 139.73881712463944 26.884 35.669335951741076 139.7388626186549 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c16596b-fc44-427f-83a6-02a60d235b60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c16596b-fc44-427f-83a6-02a60d235b60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c16596b-fc44-427f-83a6-02a60d235b60">
											<gml:posList>35.66932239544209 139.73881712463944 26.884 35.66931168159493 139.73883304367018 26.884 35.669335951741076 139.7388626186549 26.884 35.66932239544209 139.73881712463944 26.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5905a554-c57d-4140-b2cf-598eec1258b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5905a554-c57d-4140-b2cf-598eec1258b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5905a554-c57d-4140-b2cf-598eec1258b3">
											<gml:posList>35.669335951741076 139.7388626186549 29.858 35.66933794992457 139.73888194700305 29.858 35.669339877839064 139.7388806412903 29.858 35.669337970494574 139.73886220757007 29.858 35.669335951741076 139.7388626186549 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bf5f5e5b-c108-4eb3-99af-abc34ed9a039">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf5f5e5b-c108-4eb3-99af-abc34ed9a039">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf5f5e5b-c108-4eb3-99af-abc34ed9a039">
											<gml:posList>35.66933794992457 139.73888194700305 29.858 35.66938314410986 139.7389270724037 29.858 35.669383186684286 139.73892389107044 29.858 35.669339877839064 139.7388806412903 29.858 35.66933794992457 139.73888194700305 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fe741e5-f7bc-4c37-8c44-5415800f586e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fe741e5-f7bc-4c37-8c44-5415800f586e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fe741e5-f7bc-4c37-8c44-5415800f586e">
											<gml:posList>35.66939832103586 139.73891277189566 29.858 35.669396066808055 139.7389117583069 29.858 35.669383186684286 139.73892389107044 29.858 35.66938314410986 139.7389270724037 29.858 35.66939832103586 139.73891277189566 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82f97141-f40c-4210-8aa4-84f719e8fc4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82f97141-f40c-4210-8aa4-84f719e8fc4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82f97141-f40c-4210-8aa4-84f719e8fc4a">
											<gml:posList>35.66937003809591 139.73865148713836 15.623 35.66935615444248 139.7386483001587 15.623 35.66935615444248 139.7386483001587 26.884 35.66937003809591 139.73865148713836 26.884 35.66937003809591 139.73865148713836 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-333b7694-79ab-4ac6-8e81-f941fbd17a2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-333b7694-79ab-4ac6-8e81-f941fbd17a2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-333b7694-79ab-4ac6-8e81-f941fbd17a2d">
											<gml:posList>35.669351043608955 139.7386941033971 26.884 35.66933563570086 139.73867825936185 26.884 35.669351043608955 139.7386941033971 29.858 35.669351043608955 139.7386941033971 26.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c97a2824-66e3-4f5a-b953-9065a4ad430f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c97a2824-66e3-4f5a-b953-9065a4ad430f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c97a2824-66e3-4f5a-b953-9065a4ad430f">
											<gml:posList>35.66935615444248 139.7386483001587 15.623 35.66929241037651 139.73874138367495 15.623 35.66929241037651 139.73874138367495 26.884 35.66933563570086 139.73867825936185 26.884 35.66935615444248 139.7386483001587 26.884 35.66935615444248 139.7386483001587 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a010555-e351-4df0-bfef-938f4988904b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a010555-e351-4df0-bfef-938f4988904b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a010555-e351-4df0-bfef-938f4988904b">
											<gml:posList>35.669351043608955 139.7386941033971 26.884 35.669351043608955 139.7386941033971 29.858 35.669361621316746 139.73869995640115 29.858 35.669361621316746 139.73869995640115 26.884 35.669351043608955 139.7386941033971 26.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dacd7b53-162a-4297-86eb-1675b95b6639">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dacd7b53-162a-4297-86eb-1675b95b6639">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dacd7b53-162a-4297-86eb-1675b95b6639">
											<gml:posList>35.66937847314303 139.7386950541261 26.884 35.669361621316746 139.73869995640115 26.884 35.669361621316746 139.73869995640115 29.858 35.66937847314303 139.7386950541261 26.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fa3a4b2-d512-4e1f-9738-ca45b26887eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fa3a4b2-d512-4e1f-9738-ca45b26887eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fa3a4b2-d512-4e1f-9738-ca45b26887eb">
											<gml:posList>35.66935164092818 139.7386971735128 29.858 35.66935164092818 139.7386971735128 29.309 35.66935983797972 139.7387017148388 29.309 35.66935983797972 139.7387017148388 29.858 35.66935164092818 139.7386971735128 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c871cc80-e10b-4042-9126-ad404303751f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c871cc80-e10b-4042-9126-ad404303751f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c871cc80-e10b-4042-9126-ad404303751f">
											<gml:posList>35.66931836559913 139.73874735109405 29.858 35.66931836559913 139.73874735109405 29.309 35.66935164092818 139.7386971735128 29.309 35.66935164092818 139.7386971735128 29.858 35.66931836559913 139.73874735109405 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32c3aa39-490a-44ee-8a9f-0b89dcba0a21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32c3aa39-490a-44ee-8a9f-0b89dcba0a21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32c3aa39-490a-44ee-8a9f-0b89dcba0a21">
											<gml:posList>35.66929241037651 139.73874138367495 15.623 35.669301432343346 139.73875186683654 15.623 35.669301432343346 139.73875186683654 26.884 35.66929241037651 139.73874138367495 26.884 35.66929241037651 139.73874138367495 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a3d25ed-cd4e-48db-aa63-08f10384ae83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a3d25ed-cd4e-48db-aa63-08f10384ae83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a3d25ed-cd4e-48db-aa63-08f10384ae83">
											<gml:posList>35.669301432343346 139.73875186683654 15.623 35.66929603078949 139.7387603787129 15.623 35.66929603078949 139.7387603787129 26.884 35.669301432343346 139.73875186683654 26.884 35.669301432343346 139.73875186683654 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb1242fc-57d7-426f-a809-79d4ffb90a6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb1242fc-57d7-426f-a809-79d4ffb90a6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb1242fc-57d7-426f-a809-79d4ffb90a6d">
											<gml:posList>35.66929603078949 139.7387603787129 15.623 35.66931713869115 139.73878045774148 15.623 35.66931713869115 139.73878045774148 26.884 35.66929603078949 139.7387603787129 26.884 35.66929603078949 139.7387603787129 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-600fd4f9-aeb3-4d9c-a8bb-0fe18379afa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-600fd4f9-aeb3-4d9c-a8bb-0fe18379afa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-600fd4f9-aeb3-4d9c-a8bb-0fe18379afa4">
											<gml:posList>35.66941719086665 139.73889499854909 15.623 35.66937003809591 139.73865148713836 15.623 35.66937003809591 139.73865148713836 26.884 35.66937847314303 139.7386950541261 26.884 35.66941719086665 139.73889499854909 26.884 35.66941719086665 139.73889499854909 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10464f5d-67d7-4a12-aff8-09750579d70a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10464f5d-67d7-4a12-aff8-09750579d70a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10464f5d-67d7-4a12-aff8-09750579d70a">
											<gml:posList>35.6693299384203 139.7388151937239 29.858 35.6693299384203 139.7388151937239 29.309 35.66931836559913 139.73874735109405 29.309 35.66931836559913 139.73874735109405 29.858 35.6693299384203 139.7388151937239 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7b0896b-25ed-4682-88bc-b6c61f2cfa2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7b0896b-25ed-4682-88bc-b6c61f2cfa2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7b0896b-25ed-4682-88bc-b6c61f2cfa2c">
											<gml:posList>35.66931713869115 139.73878045774148 15.623 35.66932239544209 139.73881712463944 15.623 35.66932239544209 139.73881712463944 26.884 35.66931713869115 139.73878045774148 26.884 35.66931713869115 139.73878045774148 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98e75bad-0037-48f7-a8fd-f1b3779fdeec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98e75bad-0037-48f7-a8fd-f1b3779fdeec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98e75bad-0037-48f7-a8fd-f1b3779fdeec">
											<gml:posList>35.66935983797972 139.7387017148388 29.858 35.66935983797972 139.7387017148388 29.309 35.669396066808055 139.7389117583069 29.309 35.669396066808055 139.7389117583069 29.858 35.66935983797972 139.7387017148388 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cd53a99-e4ce-417f-b5a7-e60b63a7a0ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cd53a99-e4ce-417f-b5a7-e60b63a7a0ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cd53a99-e4ce-417f-b5a7-e60b63a7a0ef">
											<gml:posList>35.66932239544209 139.73881712463944 15.623 35.66931168159493 139.73883304367018 15.623 35.66931168159493 139.73883304367018 26.884 35.66932239544209 139.73881712463944 26.884 35.66932239544209 139.73881712463944 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d78375f-6e80-4c00-87c0-d1b3565abf5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d78375f-6e80-4c00-87c0-d1b3565abf5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d78375f-6e80-4c00-87c0-d1b3565abf5b">
											<gml:posList>35.669337970494574 139.73886220757007 29.858 35.669337970494574 139.73886220757007 29.309 35.6693299384203 139.7388151937239 29.309 35.6693299384203 139.7388151937239 29.858 35.669337970494574 139.73886220757007 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4dbbbf43-21e0-4aac-9707-268aa8a85434">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4dbbbf43-21e0-4aac-9707-268aa8a85434">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4dbbbf43-21e0-4aac-9707-268aa8a85434">
											<gml:posList>35.669335951741076 139.7388626186549 29.858 35.66932239544209 139.73881712463944 26.884 35.669335951741076 139.7388626186549 26.884 35.669335951741076 139.7388626186549 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa8d5719-4a3d-40cb-b399-ba7622f198d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa8d5719-4a3d-40cb-b399-ba7622f198d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa8d5719-4a3d-40cb-b399-ba7622f198d4">
											<gml:posList>35.66931168159493 139.73883304367018 15.623 35.669335951741076 139.7388626186549 15.623 35.669335951741076 139.7388626186549 26.884 35.66931168159493 139.73883304367018 26.884 35.66931168159493 139.73883304367018 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c50929c-e572-410a-9738-ed1a39f21861">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c50929c-e572-410a-9738-ed1a39f21861">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c50929c-e572-410a-9738-ed1a39f21861">
											<gml:posList>35.669339877839064 139.7388806412903 29.858 35.669339877839064 139.7388806412903 29.309 35.669337970494574 139.73886220757007 29.309 35.669337970494574 139.73886220757007 29.858 35.669339877839064 139.7388806412903 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f41882d-a0d3-4bf8-b307-49283a054222">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f41882d-a0d3-4bf8-b307-49283a054222">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f41882d-a0d3-4bf8-b307-49283a054222">
											<gml:posList>35.66933794992457 139.73888194700305 15.623 35.66933794992457 139.73888194700305 29.858 35.669335951741076 139.7388626186549 29.858 35.669335951741076 139.7388626186549 26.884 35.669335951741076 139.7388626186549 15.623 35.66933794992457 139.73888194700305 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9257c5d-822b-4a89-8e5c-b30028af43af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9257c5d-822b-4a89-8e5c-b30028af43af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9257c5d-822b-4a89-8e5c-b30028af43af">
											<gml:posList>35.669383186684286 139.73892389107044 29.858 35.669383186684286 139.73892389107044 29.309 35.669339877839064 139.7388806412903 29.309 35.669339877839064 139.7388806412903 29.858 35.669383186684286 139.73892389107044 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc4ed2a8-e686-4717-9061-43e9acb50a58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc4ed2a8-e686-4717-9061-43e9acb50a58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc4ed2a8-e686-4717-9061-43e9acb50a58">
											<gml:posList>35.66933794992457 139.73888194700305 15.623 35.66938314410986 139.7389270724037 15.623 35.66938314410986 139.7389270724037 29.858 35.66933794992457 139.73888194700305 29.858 35.66933794992457 139.73888194700305 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c2fce0a-9267-4987-b15c-ce95311628ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c2fce0a-9267-4987-b15c-ce95311628ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c2fce0a-9267-4987-b15c-ce95311628ed">
											<gml:posList>35.66941719086665 139.73889499854909 26.884 35.66939832103586 139.73891277189566 29.858 35.66938314410986 139.7389270724037 29.858 35.66938314410986 139.7389270724037 15.623 35.66941719086665 139.73889499854909 15.623 35.66941719086665 139.73889499854909 26.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6dbd33e9-5402-428d-a43e-24a7da4e2a71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dbd33e9-5402-428d-a43e-24a7da4e2a71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dbd33e9-5402-428d-a43e-24a7da4e2a71">
											<gml:posList>35.669396066808055 139.7389117583069 29.858 35.669396066808055 139.7389117583069 29.309 35.669383186684286 139.73892389107044 29.309 35.669383186684286 139.73892389107044 29.858 35.669396066808055 139.7389117583069 29.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5835</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">187.9524</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>