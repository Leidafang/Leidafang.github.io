<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e6ab1cd5-8895-4ad1-ae93-4386b7c1f4e5">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">19.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66854226628871 139.7499980389146 0 35.668558319622775 139.7499457746059 0 35.66845805330286 139.74989727649884 0 35.668421266088444 139.75001130940012 0 35.66852225369058 139.75006013825873 0 35.66854226628871 139.7499980389146 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854226628871 139.7499980389146 5.067 35.66852225369058 139.75006013825873 5.067 35.668421266088444 139.75001130940012 5.067 35.66845805330286 139.74989727649884 5.067 35.668558319622775 139.7499457746059 5.067 35.66854226628871 139.7499980389146 5.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854226628871 139.7499980389146 5.067 35.668558319622775 139.7499457746059 5.067 35.668558319622775 139.7499457746059 22.41 35.66854226628871 139.7499980389146 22.41 35.66854226628871 139.7499980389146 5.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668558319622775 139.7499457746059 5.067 35.66845805330286 139.74989727649884 5.067 35.66845805330286 139.74989727649884 22.41 35.668558319622775 139.7499457746059 22.41 35.668558319622775 139.7499457746059 5.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845805330286 139.74989727649884 5.067 35.668421266088444 139.75001130940012 5.067 35.668421266088444 139.75001130940012 22.41 35.66845805330286 139.74989727649884 22.41 35.66845805330286 139.74989727649884 5.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668421266088444 139.75001130940012 5.067 35.66852225369058 139.75006013825873 5.067 35.66852225369058 139.75006013825873 22.41 35.668421266088444 139.75001130940012 22.41 35.668421266088444 139.75001130940012 5.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852225369058 139.75006013825873 5.067 35.66854226628871 139.7499980389146 5.067 35.66854226628871 139.7499980389146 22.41 35.66852225369058 139.75006013825873 22.41 35.66852225369058 139.75006013825873 5.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854226628871 139.7499980389146 22.41 35.668558319622775 139.7499457746059 22.41 35.66845805330286 139.74989727649884 22.41 35.668421266088444 139.75001130940012 22.41 35.66852225369058 139.75006013825873 22.41 35.66854226628871 139.7499980389146 22.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-36d80e06-9cc3-4736-bc94-a005defafd47"/>
							<gml:surfaceMember xlink:href="#poly-c0b14434-d0d8-4409-8a60-0536369096c1"/>
							<gml:surfaceMember xlink:href="#poly-3c89fe28-d3d8-4266-80c8-cfaa71ccbb48"/>
							<gml:surfaceMember xlink:href="#poly-03b4a2fd-b1ba-410a-8f57-a4fda22dd8c0"/>
							<gml:surfaceMember xlink:href="#poly-05495b59-5c86-4723-8c73-8e81a098b5dc"/>
							<gml:surfaceMember xlink:href="#poly-07ab90b6-7725-4b9d-abd1-a39469a98c14"/>
							<gml:surfaceMember xlink:href="#poly-3515b776-df75-4b82-960f-316870e6a57f"/>
							<gml:surfaceMember xlink:href="#poly-c30ed9ca-9de0-4e89-9378-ec0be61e2cb5"/>
							<gml:surfaceMember xlink:href="#poly-22bc93fd-90ae-4ed6-a8bf-7963b5cacf8c"/>
							<gml:surfaceMember xlink:href="#poly-f084dd5b-99d9-4656-a6c1-2a7e31bc6e02"/>
							<gml:surfaceMember xlink:href="#poly-0faf543f-a8ec-4285-9b80-22816e49a666"/>
							<gml:surfaceMember xlink:href="#poly-279dca8b-acac-4035-83f3-ff0208332c4f"/>
							<gml:surfaceMember xlink:href="#poly-6eda1352-1ff8-4924-95c9-050115e2c54e"/>
							<gml:surfaceMember xlink:href="#poly-28b3951c-765b-40c1-af86-2990bfcc25ef"/>
							<gml:surfaceMember xlink:href="#poly-f242c29d-ca1b-4c49-bf82-242af15d6e87"/>
							<gml:surfaceMember xlink:href="#poly-5bc1563c-79dd-4c58-9728-7c052f609922"/>
							<gml:surfaceMember xlink:href="#poly-b4e29db3-d719-4a4b-bcc8-4f4f49033691"/>
							<gml:surfaceMember xlink:href="#poly-bd8194a0-f198-4913-8905-8641252aac5d"/>
							<gml:surfaceMember xlink:href="#poly-b01b4b03-bf7d-4880-be68-c28c96972185"/>
							<gml:surfaceMember xlink:href="#poly-75e26b33-543c-439b-b704-05c548b648ad"/>
							<gml:surfaceMember xlink:href="#poly-06d620d6-7fea-4e26-a10b-a02dbd9bb7c0"/>
							<gml:surfaceMember xlink:href="#poly-a53a9ec7-ca6e-4d66-9679-e944ba70f403"/>
							<gml:surfaceMember xlink:href="#poly-08124bba-319b-477e-8558-8ba7b622270a"/>
							<gml:surfaceMember xlink:href="#poly-a5176a50-4bbd-4db7-b475-104edfed2bfc"/>
							<gml:surfaceMember xlink:href="#poly-24835153-fb0b-4b3d-80a3-776c9a18a853"/>
							<gml:surfaceMember xlink:href="#poly-bf9b9181-a0e7-4f59-8130-fb56efe80859"/>
							<gml:surfaceMember xlink:href="#poly-6c754b0c-9099-471b-ba98-4439b0618ed8"/>
							<gml:surfaceMember xlink:href="#poly-e94bee98-9656-4d21-96f7-b9620dbc3b27"/>
							<gml:surfaceMember xlink:href="#poly-4f6303e0-f81a-4f8a-bb51-bc024e474b95"/>
							<gml:surfaceMember xlink:href="#poly-0d5b8f48-8c2f-406a-bc07-f066bff23a66"/>
							<gml:surfaceMember xlink:href="#poly-04464558-7704-417a-91d4-f4769d230703"/>
							<gml:surfaceMember xlink:href="#poly-a58d0a5f-0a7f-4461-8f61-ffab9a6732a0"/>
							<gml:surfaceMember xlink:href="#poly-fe3a09e5-8b49-4097-94e3-cf66c2378fa2"/>
							<gml:surfaceMember xlink:href="#poly-4ab98aea-bc13-4b50-9f73-685011a57e37"/>
							<gml:surfaceMember xlink:href="#poly-975906bf-9ccd-427b-b539-51b09e31e860"/>
							<gml:surfaceMember xlink:href="#poly-846f2fd0-7182-4ace-9f36-2b2c9c52fc0d"/>
							<gml:surfaceMember xlink:href="#poly-d959e18f-0471-4c3a-a03d-68ecbb6ed882"/>
							<gml:surfaceMember xlink:href="#poly-836ef1d1-4286-461d-8910-8cc85d666524"/>
							<gml:surfaceMember xlink:href="#poly-53e4f499-a456-41fd-8063-c3b94751d849"/>
							<gml:surfaceMember xlink:href="#poly-c3f4a082-6ac1-455f-b787-163ae095f352"/>
							<gml:surfaceMember xlink:href="#poly-f67ec9fa-6fdf-4756-8432-5814aa65afbf"/>
							<gml:surfaceMember xlink:href="#poly-a66dcd93-fcb8-4d94-b982-c3e2615a57ef"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e6ab1cd5-8895-4ad1-ae93-4386b7c1f4e5_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3624e1ba-11e1-4fad-a0d3-8dde8d0985a3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851022617293 139.75002945390813 20.9 35.66850643166362 139.75004287874302 20.9 35.66849598167389 139.75003843805965 20.9 35.668499776182706 139.7500250132263 20.9 35.66851022617293 139.75002945390813 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-047d4974-23cf-4c34-8fbd-b566f48e2047">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-047d4974-23cf-4c34-8fbd-b566f48e2047_0">
											<gml:posList>35.668499776182706 139.7500250132263 20.9 35.668499776182706 139.7500250132263 23.069 35.66851022617293 139.75002945390813 23.069 35.66851022617293 139.75002945390813 20.9 35.668499776182706 139.7500250132263 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61712113-5167-4e9b-97f1-4e6d6b5b0de6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61712113-5167-4e9b-97f1-4e6d6b5b0de6_0">
											<gml:posList>35.66849598167389 139.75003843805965 20.9 35.66849598167389 139.75003843805965 23.069 35.668499776182706 139.7500250132263 23.069 35.668499776182706 139.7500250132263 20.9 35.66849598167389 139.75003843805965 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7222429d-fe75-4881-8dc6-4fac40d4dfd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7222429d-fe75-4881-8dc6-4fac40d4dfd6_0">
											<gml:posList>35.66849598167389 139.75003843805965 23.069 35.66850643166362 139.75004287874302 23.069 35.66851022617293 139.75002945390813 23.069 35.668499776182706 139.7500250132263 23.069 35.66849598167389 139.75003843805965 23.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e744e912-e6a9-4573-a627-27d89f471e11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e744e912-e6a9-4573-a627-27d89f471e11_0">
											<gml:posList>35.66851022617293 139.75002945390813 23.069 35.66850643166362 139.75004287874302 23.069 35.66850643166362 139.75004287874302 20.9 35.66851022617293 139.75002945390813 20.9 35.66851022617293 139.75002945390813 23.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-497fc49f-6352-40dc-b116-efe8f461b89d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-497fc49f-6352-40dc-b116-efe8f461b89d_0">
											<gml:posList>35.66850643166362 139.75004287874302 20.9 35.66850643166362 139.75004287874302 23.069 35.66849598167389 139.75003843805965 23.069 35.66849598167389 139.75003843805965 20.9 35.66850643166362 139.75004287874302 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-36d80e06-9cc3-4736-bc94-a005defafd47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36d80e06-9cc3-4736-bc94-a005defafd47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36d80e06-9cc3-4736-bc94-a005defafd47">
											<gml:posList>35.66854226628869 139.7499980389146 5.067 35.66852225369059 139.7500601382587 5.067 35.66842126608843 139.75001130940012 5.067 35.66845805330286 139.74989727649884 5.067 35.66855831962277 139.7499457746059 5.067 35.66854226628869 139.7499980389146 5.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0b14434-d0d8-4409-8a60-0536369096c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0b14434-d0d8-4409-8a60-0536369096c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0b14434-d0d8-4409-8a60-0536369096c1">
											<gml:posList>35.66845805330286 139.74989727649884 27.5 35.66845925447832 139.7499006663696 27.5 35.668535292771274 139.74993743672633 27.5 35.6685380499545 139.7499359647398 27.5 35.66845805330286 139.74989727649884 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c89fe28-d3d8-4266-80c8-cfaa71ccbb48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c89fe28-d3d8-4266-80c8-cfaa71ccbb48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c89fe28-d3d8-4266-80c8-cfaa71ccbb48">
											<gml:posList>35.66844127866178 139.74994921012217 27.5 35.66844404487422 139.74994776022035 27.5 35.66845925447832 139.7499006663696 27.5 35.66845805330286 139.74989727649884 27.5 35.66844127866178 139.74994921012217 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03b4a2fd-b1ba-410a-8f57-a4fda22dd8c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03b4a2fd-b1ba-410a-8f57-a4fda22dd8c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03b4a2fd-b1ba-410a-8f57-a4fda22dd8c0">
											<gml:posList>35.668537267443206 139.74993839567512 27.5 35.6685380499545 139.7499359647398 27.5 35.668535292771274 139.74993743672633 27.5 35.668537267443206 139.74993839567512 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05495b59-5c86-4723-8c73-8e81a098b5dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05495b59-5c86-4723-8c73-8e81a098b5dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05495b59-5c86-4723-8c73-8e81a098b5dc">
											<gml:posList>35.6685380499545 139.7499359647398 29.974 35.668538781489374 139.7499380185362 29.974 35.66855666171646 139.7499466710568 29.974 35.66855831962277 139.7499457746059 29.974 35.6685380499545 139.7499359647398 29.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-07ab90b6-7725-4b9d-abd1-a39469a98c14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07ab90b6-7725-4b9d-abd1-a39469a98c14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07ab90b6-7725-4b9d-abd1-a39469a98c14">
											<gml:posList>35.66844404487422 139.74994776022035 27.157 35.668541047088524 139.7499946490576 27.157 35.66854654210552 139.74997677090582 27.157 35.6685473156115 139.74997435102597 27.157 35.668528596826725 139.74996529066988 27.157 35.668537267443206 139.74993839567512 27.157 35.668535292771274 139.74993743672633 27.157 35.66845925447832 139.7499006663696 27.157 35.66844404487422 139.74994776022035 27.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3515b776-df75-4b82-960f-316870e6a57f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3515b776-df75-4b82-960f-316870e6a57f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3515b776-df75-4b82-960f-316870e6a57f">
											<gml:posList>35.668528596826725 139.74996529066988 29.974 35.668530281774366 139.74996439419152 29.974 35.668538781489374 139.7499380185362 29.974 35.6685380499545 139.7499359647398 29.974 35.668528596826725 139.74996529066988 29.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c30ed9ca-9de0-4e89-9378-ec0be61e2cb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c30ed9ca-9de0-4e89-9378-ec0be61e2cb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c30ed9ca-9de0-4e89-9378-ec0be61e2cb5">
											<gml:posList>35.668445038648386 139.74995102880106 21.6 35.66844127866178 139.74994921012217 21.6 35.66844354555903 139.74995563653303 21.6 35.668445038648386 139.74995102880106 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22bc93fd-90ae-4ed6-a8bf-7963b5cacf8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22bc93fd-90ae-4ed6-a8bf-7963b5cacf8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22bc93fd-90ae-4ed6-a8bf-7963b5cacf8c">
											<gml:posList>35.66855666171646 139.7499466710568 29.787 35.668538781489374 139.7499380185362 29.787 35.668530281774366 139.74996439419152 29.787 35.668548513649675 139.74997321204165 29.787 35.66855666171646 139.7499466710568 29.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f084dd5b-99d9-4656-a6c1-2a7e31bc6e02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f084dd5b-99d9-4656-a6c1-2a7e31bc6e02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f084dd5b-99d9-4656-a6c1-2a7e31bc6e02">
											<gml:posList>35.66855831962277 139.7499457746059 29.974 35.66855666171646 139.7499466710568 29.974 35.668548513649675 139.74997321204165 29.974 35.66854926322666 139.74997528791192 29.974 35.66855831962277 139.7499457746059 29.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0faf543f-a8ec-4285-9b80-22816e49a666">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0faf543f-a8ec-4285-9b80-22816e49a666">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0faf543f-a8ec-4285-9b80-22816e49a666">
											<gml:posList>35.66854926322666 139.74997528791192 29.974 35.668548513649675 139.74997321204165 29.974 35.668530281774366 139.74996439419152 29.974 35.668528596826725 139.74996529066988 29.974 35.66854926322666 139.74997528791192 29.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-279dca8b-acac-4035-83f3-ff0208332c4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-279dca8b-acac-4035-83f3-ff0208332c4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-279dca8b-acac-4035-83f3-ff0208332c4f">
											<gml:posList>35.66854226628869 139.7499980389146 27.5 35.668541047088524 139.7499946490576 27.5 35.66844404487422 139.74994776022035 27.5 35.66844127866178 139.74994921012217 27.5 35.66854226628869 139.7499980389146 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6eda1352-1ff8-4924-95c9-050115e2c54e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6eda1352-1ff8-4924-95c9-050115e2c54e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6eda1352-1ff8-4924-95c9-050115e2c54e">
											<gml:posList>35.66854654210552 139.74997677090582 27.5 35.66854926322666 139.74997528791192 27.5 35.6685473156115 139.74997435102597 27.5 35.66854654210552 139.74997677090582 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28b3951c-765b-40c1-af86-2990bfcc25ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28b3951c-765b-40c1-af86-2990bfcc25ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28b3951c-765b-40c1-af86-2990bfcc25ef">
											<gml:posList>35.66842126608843 139.75001130940012 21.6 35.66842650113823 139.75000852037036 21.6 35.66844354555903 139.74995563653303 21.6 35.66844127866178 139.74994921012217 21.6 35.66842126608843 139.75001130940012 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f242c29d-ca1b-4c49-bf82-242af15d6e87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f242c29d-ca1b-4c49-bf82-242af15d6e87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f242c29d-ca1b-4c49-bf82-242af15d6e87">
											<gml:posList>35.66854926322666 139.74997528791192 27.5 35.66854654210552 139.74997677090582 27.5 35.668541047088524 139.7499946490576 27.5 35.66854226628869 139.7499980389146 27.5 35.66854926322666 139.74997528791192 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5bc1563c-79dd-4c58-9728-7c052f609922">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bc1563c-79dd-4c58-9728-7c052f609922">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bc1563c-79dd-4c58-9728-7c052f609922">
											<gml:posList>35.66853702222552 139.75000082795847 21.6 35.66854226628869 139.7499980389146 21.6 35.66853850630286 139.74999622023134 21.6 35.66853702222552 139.75000082795847 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4e29db3-d719-4a4b-bcc8-4f4f49033691">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4e29db3-d719-4a4b-bcc8-4f4f49033691">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4e29db3-d719-4a4b-bcc8-4f4f49033691">
											<gml:posList>35.66844354555903 139.74995563653303 20.9 35.66842650113823 139.75000852037036 20.9 35.6685199777852 139.75005371184795 20.9 35.66853702222552 139.75000082795847 20.9 35.66853850630286 139.74999622023134 20.9 35.668445038648386 139.74995102880106 20.9 35.66844354555903 139.74995563653303 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd8194a0-f198-4913-8905-8641252aac5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd8194a0-f198-4913-8905-8641252aac5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd8194a0-f198-4913-8905-8641252aac5d">
											<gml:posList>35.66854226628869 139.7499980389146 21.6 35.66853702222552 139.75000082795847 21.6 35.6685199777852 139.75005371184795 21.6 35.66852225369059 139.7500601382587 21.6 35.66854226628869 139.7499980389146 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b01b4b03-bf7d-4880-be68-c28c96972185">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b01b4b03-bf7d-4880-be68-c28c96972185">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b01b4b03-bf7d-4880-be68-c28c96972185">
											<gml:posList>35.66852225369059 139.7500601382587 21.6 35.6685199777852 139.75005371184795 21.6 35.66842650113823 139.75000852037036 21.6 35.66842126608843 139.75001130940012 21.6 35.66852225369059 139.7500601382587 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75e26b33-543c-439b-b704-05c548b648ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75e26b33-543c-439b-b704-05c548b648ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75e26b33-543c-439b-b704-05c548b648ad">
											<gml:posList>35.668530281774366 139.74996439419152 29.974 35.668530281774366 139.74996439419152 29.787 35.668538781489374 139.7499380185362 29.787 35.668538781489374 139.7499380185362 29.974 35.668530281774366 139.74996439419152 29.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06d620d6-7fea-4e26-a10b-a02dbd9bb7c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06d620d6-7fea-4e26-a10b-a02dbd9bb7c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06d620d6-7fea-4e26-a10b-a02dbd9bb7c0">
											<gml:posList>35.668541047088524 139.7499946490576 27.5 35.668541047088524 139.7499946490576 27.157 35.66844404487422 139.74994776022035 27.157 35.66844404487422 139.74994776022035 27.5 35.668541047088524 139.7499946490576 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a53a9ec7-ca6e-4d66-9679-e944ba70f403">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a53a9ec7-ca6e-4d66-9679-e944ba70f403">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a53a9ec7-ca6e-4d66-9679-e944ba70f403">
											<gml:posList>35.66842650113823 139.75000852037036 21.6 35.66842650113823 139.75000852037036 20.9 35.66844354555903 139.74995563653303 20.9 35.66844354555903 139.74995563653303 21.6 35.66842650113823 139.75000852037036 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08124bba-319b-477e-8558-8ba7b622270a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08124bba-319b-477e-8558-8ba7b622270a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08124bba-319b-477e-8558-8ba7b622270a">
											<gml:posList>35.66845805330286 139.74989727649884 27.5 35.66845805330286 139.74989727649884 5.067 35.66842126608843 139.75001130940012 5.067 35.66842126608843 139.75001130940012 21.6 35.66844127866178 139.74994921012217 21.6 35.66844127866178 139.74994921012217 27.5 35.66845805330286 139.74989727649884 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5176a50-4bbd-4db7-b475-104edfed2bfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5176a50-4bbd-4db7-b475-104edfed2bfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5176a50-4bbd-4db7-b475-104edfed2bfc">
											<gml:posList>35.66844354555903 139.74995563653303 21.6 35.66844354555903 139.74995563653303 20.9 35.668445038648386 139.74995102880106 20.9 35.668445038648386 139.74995102880106 21.6 35.66844354555903 139.74995563653303 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24835153-fb0b-4b3d-80a3-776c9a18a853">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24835153-fb0b-4b3d-80a3-776c9a18a853">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24835153-fb0b-4b3d-80a3-776c9a18a853">
											<gml:posList>35.66844404487422 139.74994776022035 27.5 35.66844404487422 139.74994776022035 27.157 35.66845925447832 139.7499006663696 27.157 35.66845925447832 139.7499006663696 27.5 35.66844404487422 139.74994776022035 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf9b9181-a0e7-4f59-8130-fb56efe80859">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf9b9181-a0e7-4f59-8130-fb56efe80859">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf9b9181-a0e7-4f59-8130-fb56efe80859">
											<gml:posList>35.66842126608843 139.75001130940012 5.067 35.66852225369059 139.7500601382587 5.067 35.66852225369059 139.7500601382587 21.6 35.66842126608843 139.75001130940012 21.6 35.66842126608843 139.75001130940012 5.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c754b0c-9099-471b-ba98-4439b0618ed8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c754b0c-9099-471b-ba98-4439b0618ed8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c754b0c-9099-471b-ba98-4439b0618ed8">
											<gml:posList>35.6685199777852 139.75005371184795 21.6 35.6685199777852 139.75005371184795 20.9 35.66842650113823 139.75000852037036 20.9 35.66842650113823 139.75000852037036 21.6 35.6685199777852 139.75005371184795 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e94bee98-9656-4d21-96f7-b9620dbc3b27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e94bee98-9656-4d21-96f7-b9620dbc3b27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e94bee98-9656-4d21-96f7-b9620dbc3b27">
											<gml:posList>35.668445038648386 139.74995102880106 21.6 35.668445038648386 139.74995102880106 20.9 35.66853850630286 139.74999622023134 20.9 35.66853850630286 139.74999622023134 21.6 35.66854226628869 139.7499980389146 21.6 35.66854226628869 139.7499980389146 27.5 35.66844127866178 139.74994921012217 27.5 35.66844127866178 139.74994921012217 21.6 35.668445038648386 139.74995102880106 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f6303e0-f81a-4f8a-bb51-bc024e474b95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f6303e0-f81a-4f8a-bb51-bc024e474b95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f6303e0-f81a-4f8a-bb51-bc024e474b95">
											<gml:posList>35.66845925447832 139.7499006663696 27.5 35.66845925447832 139.7499006663696 27.157 35.668535292771274 139.74993743672633 27.157 35.668535292771274 139.74993743672633 27.5 35.66845925447832 139.7499006663696 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d5b8f48-8c2f-406a-bc07-f066bff23a66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d5b8f48-8c2f-406a-bc07-f066bff23a66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d5b8f48-8c2f-406a-bc07-f066bff23a66">
											<gml:posList>35.6685380499545 139.7499359647398 27.5 35.6685380499545 139.7499359647398 29.974 35.66855831962277 139.7499457746059 29.974 35.66855831962277 139.7499457746059 5.067 35.66845805330286 139.74989727649884 5.067 35.66845805330286 139.74989727649884 27.5 35.6685380499545 139.7499359647398 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04464558-7704-417a-91d4-f4769d230703">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04464558-7704-417a-91d4-f4769d230703">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04464558-7704-417a-91d4-f4769d230703">
											<gml:posList>35.66853702222552 139.75000082795847 21.6 35.66853702222552 139.75000082795847 20.9 35.6685199777852 139.75005371184795 20.9 35.6685199777852 139.75005371184795 21.6 35.66853702222552 139.75000082795847 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a58d0a5f-0a7f-4461-8f61-ffab9a6732a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a58d0a5f-0a7f-4461-8f61-ffab9a6732a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a58d0a5f-0a7f-4461-8f61-ffab9a6732a0">
											<gml:posList>35.66852225369059 139.7500601382587 5.067 35.66854226628869 139.7499980389146 5.067 35.66854226628869 139.7499980389146 21.6 35.66852225369059 139.7500601382587 21.6 35.66852225369059 139.7500601382587 5.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe3a09e5-8b49-4097-94e3-cf66c2378fa2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe3a09e5-8b49-4097-94e3-cf66c2378fa2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe3a09e5-8b49-4097-94e3-cf66c2378fa2">
											<gml:posList>35.668528596826725 139.74996529066988 27.157 35.668528596826725 139.74996529066988 29.974 35.6685380499545 139.7499359647398 29.974 35.6685380499545 139.7499359647398 27.5 35.668537267443206 139.74993839567512 27.5 35.668537267443206 139.74993839567512 27.157 35.668528596826725 139.74996529066988 27.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ab98aea-bc13-4b50-9f73-685011a57e37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ab98aea-bc13-4b50-9f73-685011a57e37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ab98aea-bc13-4b50-9f73-685011a57e37">
											<gml:posList>35.668535292771274 139.74993743672633 27.5 35.668535292771274 139.74993743672633 27.157 35.668537267443206 139.74993839567512 27.157 35.668537267443206 139.74993839567512 27.5 35.668535292771274 139.74993743672633 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-975906bf-9ccd-427b-b539-51b09e31e860">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-975906bf-9ccd-427b-b539-51b09e31e860">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-975906bf-9ccd-427b-b539-51b09e31e860">
											<gml:posList>35.66853850630286 139.74999622023134 21.6 35.66853850630286 139.74999622023134 20.9 35.66853702222552 139.75000082795847 20.9 35.66853702222552 139.75000082795847 21.6 35.66853850630286 139.74999622023134 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-846f2fd0-7182-4ace-9f36-2b2c9c52fc0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-846f2fd0-7182-4ace-9f36-2b2c9c52fc0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-846f2fd0-7182-4ace-9f36-2b2c9c52fc0d">
											<gml:posList>35.66854926322666 139.74997528791192 29.974 35.668528596826725 139.74996529066988 29.974 35.668528596826725 139.74996529066988 27.157 35.6685473156115 139.74997435102597 27.157 35.6685473156115 139.74997435102597 27.5 35.66854926322666 139.74997528791192 27.5 35.66854926322666 139.74997528791192 29.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d959e18f-0471-4c3a-a03d-68ecbb6ed882">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d959e18f-0471-4c3a-a03d-68ecbb6ed882">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d959e18f-0471-4c3a-a03d-68ecbb6ed882">
											<gml:posList>35.668548513649675 139.74997321204165 29.974 35.668548513649675 139.74997321204165 29.787 35.668530281774366 139.74996439419152 29.787 35.668530281774366 139.74996439419152 29.974 35.668548513649675 139.74997321204165 29.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-836ef1d1-4286-461d-8910-8cc85d666524">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-836ef1d1-4286-461d-8910-8cc85d666524">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-836ef1d1-4286-461d-8910-8cc85d666524">
											<gml:posList>35.66854654210552 139.74997677090582 27.5 35.66854654210552 139.74997677090582 27.157 35.668541047088524 139.7499946490576 27.157 35.668541047088524 139.7499946490576 27.5 35.66854654210552 139.74997677090582 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53e4f499-a456-41fd-8063-c3b94751d849">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53e4f499-a456-41fd-8063-c3b94751d849">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53e4f499-a456-41fd-8063-c3b94751d849">
											<gml:posList>35.6685473156115 139.74997435102597 27.5 35.6685473156115 139.74997435102597 27.157 35.66854654210552 139.74997677090582 27.157 35.66854654210552 139.74997677090582 27.5 35.6685473156115 139.74997435102597 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3f4a082-6ac1-455f-b787-163ae095f352">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3f4a082-6ac1-455f-b787-163ae095f352">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3f4a082-6ac1-455f-b787-163ae095f352">
											<gml:posList>35.668538781489374 139.7499380185362 29.974 35.668538781489374 139.7499380185362 29.787 35.66855666171646 139.7499466710568 29.787 35.66855666171646 139.7499466710568 29.974 35.668538781489374 139.7499380185362 29.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f67ec9fa-6fdf-4756-8432-5814aa65afbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f67ec9fa-6fdf-4756-8432-5814aa65afbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f67ec9fa-6fdf-4756-8432-5814aa65afbf">
											<gml:posList>35.66854926322666 139.74997528791192 27.5 35.66854226628869 139.7499980389146 27.5 35.66854226628869 139.7499980389146 21.6 35.66854226628869 139.7499980389146 5.067 35.66855831962277 139.7499457746059 5.067 35.66855831962277 139.7499457746059 29.974 35.66854926322666 139.74997528791192 29.974 35.66854926322666 139.74997528791192 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a66dcd93-fcb8-4d94-b982-c3e2615a57ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a66dcd93-fcb8-4d94-b982-c3e2615a57ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a66dcd93-fcb8-4d94-b982-c3e2615a57ef">
											<gml:posList>35.66855666171646 139.7499466710568 29.974 35.66855666171646 139.7499466710568 29.787 35.668548513649675 139.74997321204165 29.787 35.668548513649675 139.74997321204165 29.974 35.66855666171646 139.7499466710568 29.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5817</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">72.6666</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.07</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>