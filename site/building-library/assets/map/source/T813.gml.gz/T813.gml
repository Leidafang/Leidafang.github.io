<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e80b925e-f612-4ef1-a40a-f5643d827261">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">12.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67018145134054 139.74383354258387 0 35.67018221139976 139.74383745210176 0 35.67018533458963 139.7438434246276 0 35.67017481074031 139.74388545623825 0 35.6702485726897 139.74391321047722 0 35.67026663668695 139.74384105835674 0 35.67019287472129 139.74381330417796 0 35.67018642367892 139.74381705605367 0 35.670184262700865 139.743820173504 0 35.670182202072574 139.74382490359204 0 35.670181357607085 139.74382870443873 0 35.67018145134054 139.74383354258387 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67018145134054 139.74383354258387 8.179 35.670181357607085 139.74382870443873 8.179 35.670182202072574 139.74382490359204 8.179 35.670184262700865 139.743820173504 8.179 35.67018642367892 139.74381705605367 8.179 35.67019287472129 139.74381330417796 8.179 35.67026663668695 139.74384105835674 8.179 35.6702485726897 139.74391321047722 8.179 35.67017481074031 139.74388545623825 8.179 35.67018533458963 139.7438434246276 8.179 35.67018221139976 139.74383745210176 8.179 35.67018145134054 139.74383354258387 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67018145134054 139.74383354258387 8.179 35.67018221139976 139.74383745210176 8.179 35.67018221139976 139.74383745210176 20.24 35.67018145134054 139.74383354258387 20.24 35.67018145134054 139.74383354258387 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67018221139976 139.74383745210176 8.179 35.67018533458963 139.7438434246276 8.179 35.67018533458963 139.7438434246276 20.24 35.67018221139976 139.74383745210176 20.24 35.67018221139976 139.74383745210176 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67018533458963 139.7438434246276 8.179 35.67017481074031 139.74388545623825 8.179 35.67017481074031 139.74388545623825 20.24 35.67018533458963 139.7438434246276 20.24 35.67018533458963 139.7438434246276 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67017481074031 139.74388545623825 8.179 35.6702485726897 139.74391321047722 8.179 35.6702485726897 139.74391321047722 20.24 35.67017481074031 139.74388545623825 20.24 35.67017481074031 139.74388545623825 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6702485726897 139.74391321047722 8.179 35.67026663668695 139.74384105835674 8.179 35.67026663668695 139.74384105835674 20.24 35.6702485726897 139.74391321047722 20.24 35.6702485726897 139.74391321047722 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67026663668695 139.74384105835674 8.179 35.67019287472129 139.74381330417796 8.179 35.67019287472129 139.74381330417796 20.24 35.67026663668695 139.74384105835674 20.24 35.67026663668695 139.74384105835674 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67019287472129 139.74381330417796 8.179 35.67018642367892 139.74381705605367 8.179 35.67018642367892 139.74381705605367 20.24 35.67019287472129 139.74381330417796 20.24 35.67019287472129 139.74381330417796 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67018642367892 139.74381705605367 8.179 35.670184262700865 139.743820173504 8.179 35.670184262700865 139.743820173504 20.24 35.67018642367892 139.74381705605367 20.24 35.67018642367892 139.74381705605367 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670184262700865 139.743820173504 8.179 35.670182202072574 139.74382490359204 8.179 35.670182202072574 139.74382490359204 20.24 35.670184262700865 139.743820173504 20.24 35.670184262700865 139.743820173504 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670182202072574 139.74382490359204 8.179 35.670181357607085 139.74382870443873 8.179 35.670181357607085 139.74382870443873 20.24 35.670182202072574 139.74382490359204 20.24 35.670182202072574 139.74382490359204 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670181357607085 139.74382870443873 8.179 35.67018145134054 139.74383354258387 8.179 35.67018145134054 139.74383354258387 20.24 35.670181357607085 139.74382870443873 20.24 35.670181357607085 139.74382870443873 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67018145134054 139.74383354258387 20.24 35.67018221139976 139.74383745210176 20.24 35.67018533458963 139.7438434246276 20.24 35.67017481074031 139.74388545623825 20.24 35.6702485726897 139.74391321047722 20.24 35.67026663668695 139.74384105835674 20.24 35.67019287472129 139.74381330417796 20.24 35.67018642367892 139.74381705605367 20.24 35.670184262700865 139.743820173504 20.24 35.670182202072574 139.74382490359204 20.24 35.670181357607085 139.74382870443873 20.24 35.67018145134054 139.74383354258387 20.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-37704b11-b8b6-4b68-9af4-0781f8cc1ef1"/>
							<gml:surfaceMember xlink:href="#poly-2e5d4292-0c23-4119-a632-d3e74a75c68f"/>
							<gml:surfaceMember xlink:href="#poly-370cd990-596b-4cfd-b172-c1a05035b47e"/>
							<gml:surfaceMember xlink:href="#poly-efad41c1-d8b2-44d8-a1a5-b0dad93b7f58"/>
							<gml:surfaceMember xlink:href="#poly-6fd481c6-f73b-4788-b88f-0f5b08b5c367"/>
							<gml:surfaceMember xlink:href="#poly-760deb5a-ede9-4390-b8b4-f4c7bb8c55c9"/>
							<gml:surfaceMember xlink:href="#poly-707fdcb7-46f2-489d-b63b-4c39b4b41add"/>
							<gml:surfaceMember xlink:href="#poly-0183a3b9-bc86-443f-af99-723829476d57"/>
							<gml:surfaceMember xlink:href="#poly-0841a50b-8ac5-45d1-9891-4c00eed6a161"/>
							<gml:surfaceMember xlink:href="#poly-70b37e12-e32a-42e3-a9e3-86ce2dd1e577"/>
							<gml:surfaceMember xlink:href="#poly-f9ca1872-8a8e-4150-8aff-ecd4a0b3a347"/>
							<gml:surfaceMember xlink:href="#poly-89ca25fd-344a-4951-907c-9699abd417a4"/>
							<gml:surfaceMember xlink:href="#poly-37cd35ef-3c06-41c5-bd56-5443b1ceb448"/>
							<gml:surfaceMember xlink:href="#poly-eb43fb44-c060-4df6-bb45-5f0bcf1887cf"/>
							<gml:surfaceMember xlink:href="#poly-3bbd9c38-ceff-4130-8b22-8ece3ec7add7"/>
							<gml:surfaceMember xlink:href="#poly-273be6a8-591c-4a79-8e40-fa3a8b2b5434"/>
							<gml:surfaceMember xlink:href="#poly-0561d371-ab9e-4750-be4b-a4b7f5409b7e"/>
							<gml:surfaceMember xlink:href="#poly-d69cf0a9-0581-4f48-9b44-42f4efe81b16"/>
							<gml:surfaceMember xlink:href="#poly-0ac0dcfd-66f4-4edd-910e-647c54c94816"/>
							<gml:surfaceMember xlink:href="#poly-d6cef7eb-28d3-4c73-9a39-c82e2b947003"/>
							<gml:surfaceMember xlink:href="#poly-6f5705b0-6e6d-4987-87fb-96298ee6996a"/>
							<gml:surfaceMember xlink:href="#poly-d14531b0-2708-4c2e-8d83-9639c65045a2"/>
							<gml:surfaceMember xlink:href="#poly-9c6b9268-e92f-4ad1-8c90-e50fe199a323"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e80b925e-f612-4ef1-a40a-f5643d827261_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-232a17a4-39a2-4159-b8b8-68c746b34692">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6702373433189 139.74390341393976 20.168 35.67024658133892 139.7438655923515 20.168 35.670250701735085 139.74386710108885 20.168 35.670241463714596 139.7439049226789 20.168 35.6702373433189 139.74390341393976 20.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64f198b8-4a0d-48c7-bd18-d83d3ff78d40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64f198b8-4a0d-48c7-bd18-d83d3ff78d40_0">
											<gml:posList>35.67024658133892 139.7438655923515 20.168 35.67024658133892 139.7438655923515 21.788 35.670250701735085 139.74386710108885 21.788 35.670250701735085 139.74386710108885 20.168 35.67024658133892 139.7438655923515 20.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac8dda81-f031-46bc-be69-0ee40a91a3ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac8dda81-f031-46bc-be69-0ee40a91a3ae_0">
											<gml:posList>35.6702373433189 139.74390341393976 20.168 35.6702373433189 139.74390341393976 21.788 35.67024658133892 139.7438655923515 21.788 35.67024658133892 139.7438655923515 20.168 35.6702373433189 139.74390341393976 20.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8d34cac-eac1-446c-a759-f5c72a7d3e7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8d34cac-eac1-446c-a759-f5c72a7d3e7e_0">
											<gml:posList>35.670250701735085 139.74386710108885 21.788 35.67024658133892 139.7438655923515 21.788 35.6702373433189 139.74390341393976 21.788 35.670241463714596 139.7439049226789 21.788 35.670250701735085 139.74386710108885 21.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7aca1d40-fb17-4862-90a0-a7aa01ed1d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7aca1d40-fb17-4862-90a0-a7aa01ed1d9b_0">
											<gml:posList>35.670250701735085 139.74386710108885 20.168 35.670250701735085 139.74386710108885 21.788 35.670241463714596 139.7439049226789 21.788 35.670241463714596 139.7439049226789 20.168 35.670250701735085 139.74386710108885 20.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32eba174-573d-443c-8a1a-076378ac2e0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32eba174-573d-443c-8a1a-076378ac2e0d_0">
											<gml:posList>35.670241463714596 139.7439049226789 20.168 35.670241463714596 139.7439049226789 21.788 35.6702373433189 139.74390341393976 21.788 35.6702373433189 139.74390341393976 20.168 35.670241463714596 139.7439049226789 20.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e80b925e-f612-4ef1-a40a-f5643d827261_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f519a23-68e2-4b24-a298-23dea6294684">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67024513806917 139.7438520181316 20.168 35.67022591541681 139.74384478220603 20.168 35.670229986556684 139.74382852864443 20.168 35.67026540240609 139.7438418661102 20.168 35.67025974057125 139.74386449513574 20.168 35.670243538370784 139.74385840464421 20.168 35.67024513806917 139.7438520181316 20.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-246953da-d245-4535-8b1d-6e469f814f5b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025974057125 139.74386449513574 21.1 35.67026540240609 139.7438418661102 21.1 35.670229986556684 139.74382852864443 21.1 35.67023019324831 139.74382768889953 21.1 35.67026643859026 139.74384133473393 21.1 35.67026056105813 139.74386481456125 21.1 35.67025974057125 139.74386449513574 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6147abf-2977-4a00-b5c8-85ebf66752ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6147abf-2977-4a00-b5c8-85ebf66752ad_0">
											<gml:posList>35.670229986556684 139.74382852864443 21.1 35.670229986556684 139.74382852864443 20.168 35.67022591541681 139.74384478220603 20.168 35.67022591541681 139.74384478220603 22.767 35.67023019324831 139.74382768889953 22.767 35.67023019324831 139.74382768889953 21.1 35.670229986556684 139.74382852864443 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9eebd09-76ee-4f5c-8aaf-c69b8ed85344">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9eebd09-76ee-4f5c-8aaf-c69b8ed85344_0">
											<gml:posList>35.67024513806917 139.7438520181316 20.168 35.67024513806917 139.7438520181316 22.767 35.67022591541681 139.74384478220603 22.767 35.67022591541681 139.74384478220603 20.168 35.67024513806917 139.7438520181316 20.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc6aa47a-3b3c-4ada-b2dc-84bc2cc90e8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc6aa47a-3b3c-4ada-b2dc-84bc2cc90e8b_0">
											<gml:posList>35.670243538370784 139.74385840464421 20.168 35.670243538370784 139.74385840464421 22.767 35.67024513806917 139.7438520181316 22.767 35.67024513806917 139.7438520181316 20.168 35.670243538370784 139.74385840464421 20.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c142b00-24e1-439d-aa82-3f1747be72f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c142b00-24e1-439d-aa82-3f1747be72f3_0">
											<gml:posList>35.67026056105813 139.74386481456125 22.767 35.67026643859026 139.74384133473393 22.767 35.67023019324831 139.74382768889953 22.767 35.67022591541681 139.74384478220603 22.767 35.67024513806917 139.7438520181316 22.767 35.670243538370784 139.74385840464421 22.767 35.67026056105813 139.74386481456125 22.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52680bf0-7ae2-4e2f-b636-b3c3930417ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52680bf0-7ae2-4e2f-b636-b3c3930417ee_0">
											<gml:posList>35.67026540240609 139.7438418661102 20.168 35.670229986556684 139.74382852864443 20.168 35.670229986556684 139.74382852864443 21.1 35.67026540240609 139.7438418661102 21.1 35.67026540240609 139.7438418661102 20.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc9e2fd5-c344-465b-9206-5519064f4d2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc9e2fd5-c344-465b-9206-5519064f4d2f_0">
											<gml:posList>35.67023019324831 139.74382768889953 21.1 35.67023019324831 139.74382768889953 22.767 35.67026643859026 139.74384133473393 22.767 35.67026643859026 139.74384133473393 21.1 35.67023019324831 139.74382768889953 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38582459-3040-4d91-b76b-10dd94d99f30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38582459-3040-4d91-b76b-10dd94d99f30_0">
											<gml:posList>35.67025974057125 139.74386449513574 21.1 35.67026056105813 139.74386481456125 21.1 35.67026056105813 139.74386481456125 22.767 35.670243538370784 139.74385840464421 22.767 35.670243538370784 139.74385840464421 20.168 35.67025974057125 139.74386449513574 20.168 35.67025974057125 139.74386449513574 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7101a93a-34b4-4fec-949e-98517454055f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7101a93a-34b4-4fec-949e-98517454055f_0">
											<gml:posList>35.67026540240609 139.7438418661102 21.1 35.67025974057125 139.74386449513574 21.1 35.67025974057125 139.74386449513574 20.168 35.67026540240609 139.7438418661102 20.168 35.67026540240609 139.7438418661102 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4addf062-9ffa-4dc3-af5b-943940c91152">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4addf062-9ffa-4dc3-af5b-943940c91152_0">
											<gml:posList>35.67026643859026 139.74384133473393 22.767 35.67026056105813 139.74386481456125 22.767 35.67026056105813 139.74386481456125 21.1 35.67026643859026 139.74384133473393 21.1 35.67026643859026 139.74384133473393 22.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-37704b11-b8b6-4b68-9af4-0781f8cc1ef1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37704b11-b8b6-4b68-9af4-0781f8cc1ef1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37704b11-b8b6-4b68-9af4-0781f8cc1ef1">
											<gml:posList>35.67018533458964 139.7438434246276 8.179 35.67018221139974 139.74383745210173 8.179 35.67018145134055 139.74383354258387 8.179 35.670181357607085 139.74382870443873 8.179 35.67018220207255 139.74382490359204 8.179 35.67018426270086 139.743820173504 8.179 35.67018642367888 139.74381705605367 8.179 35.67019287472126 139.74381330417796 8.179 35.67026663668694 139.74384105835674 8.179 35.670248572689694 139.7439132104772 8.179 35.670174810740335 139.74388545623825 8.179 35.67018533458964 139.7438434246276 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e5d4292-0c23-4119-a632-d3e74a75c68f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e5d4292-0c23-4119-a632-d3e74a75c68f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e5d4292-0c23-4119-a632-d3e74a75c68f">
											<gml:posList>35.67018642367888 139.74381705605367 18.2 35.67018426270086 139.743820173504 18.2 35.67018220207255 139.74382490359204 18.2 35.670181357607085 139.74382870443873 18.2 35.67018145134055 139.74383354258387 18.2 35.67018221139974 139.74383745210173 18.2 35.67018533458964 139.7438434246276 18.2 35.670174810740335 139.74388545623825 18.2 35.67020070541676 139.74389520326778 18.2 35.67021878743086 139.74382305116626 18.2 35.67019287472126 139.74381330417796 18.2 35.67018642367888 139.74381705605367 18.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-370cd990-596b-4cfd-b172-c1a05035b47e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-370cd990-596b-4cfd-b172-c1a05035b47e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-370cd990-596b-4cfd-b172-c1a05035b47e">
											<gml:posList>35.67020070541676 139.74389520326778 21.1 35.67020193970618 139.74389440656202 21.1 35.670219437543906 139.74382456377504 21.1 35.67021878743086 139.74382305116626 21.1 35.67020070541676 139.74389520326778 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-efad41c1-d8b2-44d8-a1a5-b0dad93b7f58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efad41c1-d8b2-44d8-a1a5-b0dad93b7f58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efad41c1-d8b2-44d8-a1a5-b0dad93b7f58">
											<gml:posList>35.670248572689694 139.7439132104772 21.1 35.67024791357223 139.74391170892343 21.1 35.67020193970618 139.74389440656202 21.1 35.67020070541676 139.74389520326778 21.1 35.670248572689694 139.7439132104772 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6fd481c6-f73b-4788-b88f-0f5b08b5c367">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fd481c6-f73b-4788-b88f-0f5b08b5c367">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fd481c6-f73b-4788-b88f-0f5b08b5c367">
											<gml:posList>35.67026540240609 139.7438418661102 20.168 35.670219437543906 139.74382456377504 20.168 35.67020193970618 139.74389440656202 20.168 35.67024791357223 139.74391170892343 20.168 35.67026540240609 139.7438418661102 20.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-760deb5a-ede9-4390-b8b4-f4c7bb8c55c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-760deb5a-ede9-4390-b8b4-f4c7bb8c55c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-760deb5a-ede9-4390-b8b4-f4c7bb8c55c9">
											<gml:posList>35.67021878743086 139.74382305116626 21.1 35.670219437543906 139.74382456377504 21.1 35.67026540240609 139.7438418661102 21.1 35.67026663668694 139.74384105835674 21.1 35.67021878743086 139.74382305116626 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-707fdcb7-46f2-489d-b63b-4c39b4b41add">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-707fdcb7-46f2-489d-b63b-4c39b4b41add">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-707fdcb7-46f2-489d-b63b-4c39b4b41add">
											<gml:posList>35.67026663668694 139.74384105835674 21.1 35.67026540240609 139.7438418661102 21.1 35.67024791357223 139.74391170892343 21.1 35.670248572689694 139.7439132104772 21.1 35.67026663668694 139.74384105835674 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0183a3b9-bc86-443f-af99-723829476d57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0183a3b9-bc86-443f-af99-723829476d57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0183a3b9-bc86-443f-af99-723829476d57">
											<gml:posList>35.67019287472126 139.74381330417796 8.179 35.67018642367888 139.74381705605367 8.179 35.67018642367888 139.74381705605367 18.2 35.67019287472126 139.74381330417796 18.2 35.67019287472126 139.74381330417796 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0841a50b-8ac5-45d1-9891-4c00eed6a161">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0841a50b-8ac5-45d1-9891-4c00eed6a161">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0841a50b-8ac5-45d1-9891-4c00eed6a161">
											<gml:posList>35.67018642367888 139.74381705605367 8.179 35.67018426270086 139.743820173504 8.179 35.67018426270086 139.743820173504 18.2 35.67018642367888 139.74381705605367 18.2 35.67018642367888 139.74381705605367 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70b37e12-e32a-42e3-a9e3-86ce2dd1e577">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70b37e12-e32a-42e3-a9e3-86ce2dd1e577">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70b37e12-e32a-42e3-a9e3-86ce2dd1e577">
											<gml:posList>35.67018426270086 139.743820173504 8.179 35.67018220207255 139.74382490359204 8.179 35.67018220207255 139.74382490359204 18.2 35.67018426270086 139.743820173504 18.2 35.67018426270086 139.743820173504 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9ca1872-8a8e-4150-8aff-ecd4a0b3a347">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9ca1872-8a8e-4150-8aff-ecd4a0b3a347">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9ca1872-8a8e-4150-8aff-ecd4a0b3a347">
											<gml:posList>35.67018220207255 139.74382490359204 8.179 35.670181357607085 139.74382870443873 8.179 35.670181357607085 139.74382870443873 18.2 35.67018220207255 139.74382490359204 18.2 35.67018220207255 139.74382490359204 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89ca25fd-344a-4951-907c-9699abd417a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89ca25fd-344a-4951-907c-9699abd417a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89ca25fd-344a-4951-907c-9699abd417a4">
											<gml:posList>35.67021878743086 139.74382305116626 18.2 35.67021878743086 139.74382305116626 21.1 35.67026663668694 139.74384105835674 21.1 35.67026663668694 139.74384105835674 8.179 35.67019287472126 139.74381330417796 8.179 35.67019287472126 139.74381330417796 18.2 35.67021878743086 139.74382305116626 18.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37cd35ef-3c06-41c5-bd56-5443b1ceb448">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37cd35ef-3c06-41c5-bd56-5443b1ceb448">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37cd35ef-3c06-41c5-bd56-5443b1ceb448">
											<gml:posList>35.670181357607085 139.74382870443873 8.179 35.67018145134055 139.74383354258387 8.179 35.67018145134055 139.74383354258387 18.2 35.670181357607085 139.74382870443873 18.2 35.670181357607085 139.74382870443873 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb43fb44-c060-4df6-bb45-5f0bcf1887cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb43fb44-c060-4df6-bb45-5f0bcf1887cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb43fb44-c060-4df6-bb45-5f0bcf1887cf">
											<gml:posList>35.670219437543906 139.74382456377504 21.1 35.670219437543906 139.74382456377504 20.168 35.67026540240609 139.7438418661102 20.168 35.67026540240609 139.7438418661102 21.1 35.670219437543906 139.74382456377504 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bbd9c38-ceff-4130-8b22-8ece3ec7add7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bbd9c38-ceff-4130-8b22-8ece3ec7add7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bbd9c38-ceff-4130-8b22-8ece3ec7add7">
											<gml:posList>35.67018145134055 139.74383354258387 8.179 35.67018221139974 139.74383745210173 8.179 35.67018221139974 139.74383745210173 18.2 35.67018145134055 139.74383354258387 18.2 35.67018145134055 139.74383354258387 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-273be6a8-591c-4a79-8e40-fa3a8b2b5434">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-273be6a8-591c-4a79-8e40-fa3a8b2b5434">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-273be6a8-591c-4a79-8e40-fa3a8b2b5434">
											<gml:posList>35.67018221139974 139.74383745210173 8.179 35.67018533458964 139.7438434246276 8.179 35.67018533458964 139.7438434246276 18.2 35.67018221139974 139.74383745210173 18.2 35.67018221139974 139.74383745210173 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0561d371-ab9e-4750-be4b-a4b7f5409b7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0561d371-ab9e-4750-be4b-a4b7f5409b7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0561d371-ab9e-4750-be4b-a4b7f5409b7e">
											<gml:posList>35.67020070541676 139.74389520326778 18.2 35.67020070541676 139.74389520326778 21.1 35.67021878743086 139.74382305116626 21.1 35.67021878743086 139.74382305116626 18.2 35.67020070541676 139.74389520326778 18.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d69cf0a9-0581-4f48-9b44-42f4efe81b16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d69cf0a9-0581-4f48-9b44-42f4efe81b16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d69cf0a9-0581-4f48-9b44-42f4efe81b16">
											<gml:posList>35.67020193970618 139.74389440656202 21.1 35.67020193970618 139.74389440656202 20.168 35.670219437543906 139.74382456377504 20.168 35.670219437543906 139.74382456377504 21.1 35.67020193970618 139.74389440656202 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ac0dcfd-66f4-4edd-910e-647c54c94816">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ac0dcfd-66f4-4edd-910e-647c54c94816">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ac0dcfd-66f4-4edd-910e-647c54c94816">
											<gml:posList>35.67018533458964 139.7438434246276 8.179 35.670174810740335 139.74388545623825 8.179 35.670174810740335 139.74388545623825 18.2 35.67018533458964 139.7438434246276 18.2 35.67018533458964 139.7438434246276 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6cef7eb-28d3-4c73-9a39-c82e2b947003">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6cef7eb-28d3-4c73-9a39-c82e2b947003">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6cef7eb-28d3-4c73-9a39-c82e2b947003">
											<gml:posList>35.67026540240609 139.7438418661102 21.1 35.67026540240609 139.7438418661102 20.168 35.67024791357223 139.74391170892343 20.168 35.67024791357223 139.74391170892343 21.1 35.67026540240609 139.7438418661102 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f5705b0-6e6d-4987-87fb-96298ee6996a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f5705b0-6e6d-4987-87fb-96298ee6996a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f5705b0-6e6d-4987-87fb-96298ee6996a">
											<gml:posList>35.670248572689694 139.7439132104772 8.179 35.67026663668694 139.74384105835674 8.179 35.67026663668694 139.74384105835674 21.1 35.670248572689694 139.7439132104772 21.1 35.670248572689694 139.7439132104772 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d14531b0-2708-4c2e-8d83-9639c65045a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d14531b0-2708-4c2e-8d83-9639c65045a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d14531b0-2708-4c2e-8d83-9639c65045a2">
											<gml:posList>35.670248572689694 139.7439132104772 8.179 35.670248572689694 139.7439132104772 21.1 35.67020070541676 139.74389520326778 21.1 35.67020070541676 139.74389520326778 18.2 35.670174810740335 139.74388545623825 18.2 35.670174810740335 139.74388545623825 8.179 35.670248572689694 139.7439132104772 8.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c6b9268-e92f-4ad1-8c90-e50fe199a323">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c6b9268-e92f-4ad1-8c90-e50fe199a323">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c6b9268-e92f-4ad1-8c90-e50fe199a323">
											<gml:posList>35.67024791357223 139.74391170892343 21.1 35.67024791357223 139.74391170892343 20.168 35.67020193970618 139.74389440656202 20.168 35.67020193970618 139.74389440656202 21.1 35.67024791357223 139.74391170892343 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11429</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">71.7068</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>