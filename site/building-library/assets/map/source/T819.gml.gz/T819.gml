<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e9324a60-7797-42ec-ab75-903dfae5955d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">13</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66925765467569 139.73956121133477 0 35.66925355012904 139.73956855074823 0 35.669258736417916 139.7395729078947 0 35.66925114840108 139.7395864703372 0 35.66927441906373 139.73960603892317 0 35.669273302909545 139.73960802852713 0 35.66930042494745 139.7396308291341 0 35.66949206043419 139.73928850631748 0 35.66947041326973 139.73927031663288 0 35.66948209678153 139.7392494367763 0 35.669470425349886 139.7392396304585 0 35.66946905717141 139.7392420732597 0 35.66945300218622 139.73922858268125 0 35.66944175074119 139.7392486998433 0 35.66942998008078 139.73923879423182 0 35.66943501173451 139.73922980782407 0 35.66942632579489 139.7392224944355 0 35.66942084407708 139.73923227669212 0 35.669414097374506 139.7392266069013 0 35.66927673033097 139.73947199170897 0 35.66924365619681 139.73954944151444 0 35.66925765467569 139.73956121133477 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925765467569 139.73956121133477 11.04 35.66924365619681 139.73954944151444 11.04 35.66927673033097 139.73947199170897 11.04 35.669414097374506 139.7392266069013 11.04 35.66942084407708 139.73923227669212 11.04 35.66942632579489 139.7392224944355 11.04 35.66943501173451 139.73922980782407 11.04 35.66942998008078 139.73923879423182 11.04 35.66944175074119 139.7392486998433 11.04 35.66945300218622 139.73922858268125 11.04 35.66946905717141 139.7392420732597 11.04 35.669470425349886 139.7392396304585 11.04 35.66948209678153 139.7392494367763 11.04 35.66947041326973 139.73927031663288 11.04 35.66949206043419 139.73928850631748 11.04 35.66930042494745 139.7396308291341 11.04 35.669273302909545 139.73960802852713 11.04 35.66927441906373 139.73960603892317 11.04 35.66925114840108 139.7395864703372 11.04 35.669258736417916 139.7395729078947 11.04 35.66925355012904 139.73956855074823 11.04 35.66925765467569 139.73956121133477 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925765467569 139.73956121133477 11.04 35.66925355012904 139.73956855074823 11.04 35.66925355012904 139.73956855074823 24.04 35.66925765467569 139.73956121133477 24.04 35.66925765467569 139.73956121133477 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925355012904 139.73956855074823 11.04 35.669258736417916 139.7395729078947 11.04 35.669258736417916 139.7395729078947 24.04 35.66925355012904 139.73956855074823 24.04 35.66925355012904 139.73956855074823 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669258736417916 139.7395729078947 11.04 35.66925114840108 139.7395864703372 11.04 35.66925114840108 139.7395864703372 24.04 35.669258736417916 139.7395729078947 24.04 35.669258736417916 139.7395729078947 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925114840108 139.7395864703372 11.04 35.66927441906373 139.73960603892317 11.04 35.66927441906373 139.73960603892317 24.04 35.66925114840108 139.7395864703372 24.04 35.66925114840108 139.7395864703372 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927441906373 139.73960603892317 11.04 35.669273302909545 139.73960802852713 11.04 35.669273302909545 139.73960802852713 24.04 35.66927441906373 139.73960603892317 24.04 35.66927441906373 139.73960603892317 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669273302909545 139.73960802852713 11.04 35.66930042494745 139.7396308291341 11.04 35.66930042494745 139.7396308291341 24.04 35.669273302909545 139.73960802852713 24.04 35.669273302909545 139.73960802852713 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66930042494745 139.7396308291341 11.04 35.66949206043419 139.73928850631748 11.04 35.66949206043419 139.73928850631748 24.04 35.66930042494745 139.7396308291341 24.04 35.66930042494745 139.7396308291341 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949206043419 139.73928850631748 11.04 35.66947041326973 139.73927031663288 11.04 35.66947041326973 139.73927031663288 24.04 35.66949206043419 139.73928850631748 24.04 35.66949206043419 139.73928850631748 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66947041326973 139.73927031663288 11.04 35.66948209678153 139.7392494367763 11.04 35.66948209678153 139.7392494367763 24.04 35.66947041326973 139.73927031663288 24.04 35.66947041326973 139.73927031663288 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66948209678153 139.7392494367763 11.04 35.669470425349886 139.7392396304585 11.04 35.669470425349886 139.7392396304585 24.04 35.66948209678153 139.7392494367763 24.04 35.66948209678153 139.7392494367763 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669470425349886 139.7392396304585 11.04 35.66946905717141 139.7392420732597 11.04 35.66946905717141 139.7392420732597 24.04 35.669470425349886 139.7392396304585 24.04 35.669470425349886 139.7392396304585 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66946905717141 139.7392420732597 11.04 35.66945300218622 139.73922858268125 11.04 35.66945300218622 139.73922858268125 24.04 35.66946905717141 139.7392420732597 24.04 35.66946905717141 139.7392420732597 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66945300218622 139.73922858268125 11.04 35.66944175074119 139.7392486998433 11.04 35.66944175074119 139.7392486998433 24.04 35.66945300218622 139.73922858268125 24.04 35.66945300218622 139.73922858268125 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66944175074119 139.7392486998433 11.04 35.66942998008078 139.73923879423182 11.04 35.66942998008078 139.73923879423182 24.04 35.66944175074119 139.7392486998433 24.04 35.66944175074119 139.7392486998433 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66942998008078 139.73923879423182 11.04 35.66943501173451 139.73922980782407 11.04 35.66943501173451 139.73922980782407 24.04 35.66942998008078 139.73923879423182 24.04 35.66942998008078 139.73923879423182 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66943501173451 139.73922980782407 11.04 35.66942632579489 139.7392224944355 11.04 35.66942632579489 139.7392224944355 24.04 35.66943501173451 139.73922980782407 24.04 35.66943501173451 139.73922980782407 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66942632579489 139.7392224944355 11.04 35.66942084407708 139.73923227669212 11.04 35.66942084407708 139.73923227669212 24.04 35.66942632579489 139.7392224944355 24.04 35.66942632579489 139.7392224944355 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66942084407708 139.73923227669212 11.04 35.669414097374506 139.7392266069013 11.04 35.669414097374506 139.7392266069013 24.04 35.66942084407708 139.73923227669212 24.04 35.66942084407708 139.73923227669212 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669414097374506 139.7392266069013 11.04 35.66927673033097 139.73947199170897 11.04 35.66927673033097 139.73947199170897 24.04 35.669414097374506 139.7392266069013 24.04 35.669414097374506 139.7392266069013 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927673033097 139.73947199170897 11.04 35.66924365619681 139.73954944151444 11.04 35.66924365619681 139.73954944151444 24.04 35.66927673033097 139.73947199170897 24.04 35.66927673033097 139.73947199170897 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924365619681 139.73954944151444 11.04 35.66925765467569 139.73956121133477 11.04 35.66925765467569 139.73956121133477 24.04 35.66924365619681 139.73954944151444 24.04 35.66924365619681 139.73954944151444 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925765467569 139.73956121133477 24.04 35.66925355012904 139.73956855074823 24.04 35.669258736417916 139.7395729078947 24.04 35.66925114840108 139.7395864703372 24.04 35.66927441906373 139.73960603892317 24.04 35.669273302909545 139.73960802852713 24.04 35.66930042494745 139.7396308291341 24.04 35.66949206043419 139.73928850631748 24.04 35.66947041326973 139.73927031663288 24.04 35.66948209678153 139.7392494367763 24.04 35.669470425349886 139.7392396304585 24.04 35.66946905717141 139.7392420732597 24.04 35.66945300218622 139.73922858268125 24.04 35.66944175074119 139.7392486998433 24.04 35.66942998008078 139.73923879423182 24.04 35.66943501173451 139.73922980782407 24.04 35.66942632579489 139.7392224944355 24.04 35.66942084407708 139.73923227669212 24.04 35.669414097374506 139.7392266069013 24.04 35.66927673033097 139.73947199170897 24.04 35.66924365619681 139.73954944151444 24.04 35.66925765467569 139.73956121133477 24.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-24f96b0d-8ca9-458d-8d66-56f4b3846ba1"/>
							<gml:surfaceMember xlink:href="#poly-88d22682-c717-462b-bc7f-3f5affac89e2"/>
							<gml:surfaceMember xlink:href="#poly-c34f81c6-a56f-48eb-b25b-f63fc598c43b"/>
							<gml:surfaceMember xlink:href="#poly-9c8322d9-c1c4-4315-b6ff-db54c6143772"/>
							<gml:surfaceMember xlink:href="#poly-e50f4d7f-1106-442b-a906-0525722f3ec6"/>
							<gml:surfaceMember xlink:href="#poly-586bd2d9-ad08-4581-a8f0-e47e00be20cf"/>
							<gml:surfaceMember xlink:href="#poly-7e2d5dd0-b3ca-4adf-b5ab-28f3b7301d47"/>
							<gml:surfaceMember xlink:href="#poly-275231bc-1953-4b41-a81c-7bed3f4331d6"/>
							<gml:surfaceMember xlink:href="#poly-adaf624e-2fcc-4082-9d6f-542e0f09e5d0"/>
							<gml:surfaceMember xlink:href="#poly-ab146194-b002-435c-89d5-0c16f0fcb6c1"/>
							<gml:surfaceMember xlink:href="#poly-c58b0f88-da97-48b1-ab1b-5a239da70892"/>
							<gml:surfaceMember xlink:href="#poly-e1efc81c-7938-44d1-a299-fe8fdfb30829"/>
							<gml:surfaceMember xlink:href="#poly-8f7b23b6-7883-4404-9f99-8855ea60f717"/>
							<gml:surfaceMember xlink:href="#poly-6b0d6183-7b59-4e4c-bc5a-434ab3565c10"/>
							<gml:surfaceMember xlink:href="#poly-85910e45-27ab-4117-bb43-ee2dacd40c3d"/>
							<gml:surfaceMember xlink:href="#poly-1b6d2946-02c6-4eca-aacd-c99d161dec4a"/>
							<gml:surfaceMember xlink:href="#poly-8a4be125-871e-416b-9569-08424d27ca2b"/>
							<gml:surfaceMember xlink:href="#poly-84acf6aa-aea3-4474-9110-ea43dd438396"/>
							<gml:surfaceMember xlink:href="#poly-66142493-42cd-4f28-86d7-4b4c056bbc28"/>
							<gml:surfaceMember xlink:href="#poly-078b0837-ec8e-4673-ae24-0c68af3eb741"/>
							<gml:surfaceMember xlink:href="#poly-8cd840c8-a258-4dbd-8867-3a22fa7d41bd"/>
							<gml:surfaceMember xlink:href="#poly-267f1f62-d43b-4f97-a0b7-d7f8b681f9da"/>
							<gml:surfaceMember xlink:href="#poly-57c73a7d-712b-4e36-8e50-dd2b181b8f37"/>
							<gml:surfaceMember xlink:href="#poly-a025e6cb-271a-45df-ab51-f1a90ae08e99"/>
							<gml:surfaceMember xlink:href="#poly-28dc9710-090e-47bc-9333-d1418413ed99"/>
							<gml:surfaceMember xlink:href="#poly-20e97a19-f3c4-4c86-b735-be2ce25f0ecf"/>
							<gml:surfaceMember xlink:href="#poly-cc7e563f-a983-45fe-b4b3-465a0a609de6"/>
							<gml:surfaceMember xlink:href="#poly-52ede1de-ac6c-4379-9be2-12ae654e9ea0"/>
							<gml:surfaceMember xlink:href="#poly-69e1b005-ab6c-496c-9422-8eb478e9c360"/>
							<gml:surfaceMember xlink:href="#poly-e9c55ab8-b748-4919-8c28-cf469e6c38cd"/>
							<gml:surfaceMember xlink:href="#poly-c08bc7ae-a368-48b1-92e5-1ce3d35d5487"/>
							<gml:surfaceMember xlink:href="#poly-5fa7a421-92d5-48c1-88f0-8d413218a7be"/>
							<gml:surfaceMember xlink:href="#poly-af37eb12-5a8d-45eb-be8d-3176dba30e7e"/>
							<gml:surfaceMember xlink:href="#poly-75472cc7-fd5f-4243-aea1-01718d350464"/>
							<gml:surfaceMember xlink:href="#poly-e75a33e3-39d6-4e8f-ba92-80f821b7e4b6"/>
							<gml:surfaceMember xlink:href="#poly-be583ba7-d0fb-4441-9611-df287970aee1"/>
							<gml:surfaceMember xlink:href="#poly-8e84f57c-d95b-43e5-9d29-4f37ecc3f9b8"/>
							<gml:surfaceMember xlink:href="#poly-480cb10a-ca64-4ca9-84d7-b9581cb7892d"/>
							<gml:surfaceMember xlink:href="#poly-5fbe00fd-54b9-40b9-904c-6487d01ec4b3"/>
							<gml:surfaceMember xlink:href="#poly-826cc1cf-4568-4e9c-a1aa-2ec3987d3932"/>
							<gml:surfaceMember xlink:href="#poly-f1a8af64-b530-4104-831a-918a57fb2628"/>
							<gml:surfaceMember xlink:href="#poly-f90be8b4-75fb-4bc9-92e9-0d1666fbe0c1"/>
							<gml:surfaceMember xlink:href="#poly-f26af369-f071-4b9d-8c14-56b75bffda49"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-24f96b0d-8ca9-458d-8d66-56f4b3846ba1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24f96b0d-8ca9-458d-8d66-56f4b3846ba1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24f96b0d-8ca9-458d-8d66-56f4b3846ba1">
											<gml:posList>35.669257654675675 139.73956121133475 11.04 35.66924365619681 139.73954944151444 11.04 35.669276730330964 139.73947199170897 11.04 35.6694140973745 139.7392266069013 11.04 35.669420844077045 139.73923227669212 11.04 35.66942632579489 139.7392224944355 11.04 35.669435011734485 139.73922980782405 11.04 35.669429980080764 139.73923879423182 11.04 35.66944175074117 139.7392486998433 11.04 35.66945300218621 139.73922858268122 11.04 35.66946905717144 139.7392420732597 11.04 35.66947042534988 139.7392396304585 11.04 35.66948209678151 139.7392494367763 11.04 35.66947041326969 139.73927031663288 11.04 35.66949206043419 139.73928850631748 11.04 35.66930042494744 139.7396308291341 11.04 35.66927330290956 139.73960802852713 11.04 35.66927441906374 139.73960603892314 11.04 35.66925114840107 139.7395864703372 11.04 35.66925873641787 139.7395729078947 11.04 35.669253550129014 139.7395685507482 11.04 35.669257654675675 139.73956121133475 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88d22682-c717-462b-bc7f-3f5affac89e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88d22682-c717-462b-bc7f-3f5affac89e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88d22682-c717-462b-bc7f-3f5affac89e2">
											<gml:posList>35.669429980080764 139.73923879423182 18.895 35.669435011734485 139.73922980782405 18.895 35.66942632579489 139.7392224944355 18.895 35.669420844077045 139.73923227669212 18.895 35.669429980080764 139.73923879423182 18.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c34f81c6-a56f-48eb-b25b-f63fc598c43b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c34f81c6-a56f-48eb-b25b-f63fc598c43b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c34f81c6-a56f-48eb-b25b-f63fc598c43b">
											<gml:posList>35.66933940388912 139.7395080722794 24.524 35.66935972494233 139.73952490487744 24.524 35.66949206043419 139.73928850631748 24.524 35.66947041326969 139.73927031663288 24.524 35.66948209678151 139.7392494367763 24.524 35.66947042534988 139.7392396304585 24.524 35.66946905717144 139.7392420732597 24.524 35.66945300218621 139.73922858268122 24.524 35.66944175074117 139.7392486998433 24.524 35.669429980080764 139.73923879423182 24.524 35.669420844077045 139.73923227669212 24.524 35.6694140973745 139.7392266069013 24.524 35.66929409364895 139.73944098704536 24.524 35.66930045250165 139.73944633696271 24.524 35.669289290494056 139.73946560340084 24.524 35.6693120651803 139.73948486325037 24.524 35.66930148933405 139.73950448247555 24.524 35.669329710695685 139.73952680678642 24.524 35.66933940388912 139.7395080722794 24.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c8322d9-c1c4-4315-b6ff-db54c6143772">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c8322d9-c1c4-4315-b6ff-db54c6143772">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c8322d9-c1c4-4315-b6ff-db54c6143772">
											<gml:posList>35.669276730330964 139.73947199170897 15.187 35.66924365619681 139.73954944151444 15.187 35.669257654675675 139.73956121133475 15.187 35.66928498447988 139.73951513919224 15.187 35.66931597483394 139.73953974680842 15.187 35.66932482224536 139.7395229463657 15.187 35.66930148933405 139.73950448247555 15.187 35.6693120651803 139.73948486325037 15.187 35.669289290494056 139.73946560340084 15.187 35.66930045250165 139.73944633696271 15.187 35.66929409364895 139.73944098704536 15.187 35.669276730330964 139.73947199170897 15.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e50f4d7f-1106-442b-a906-0525722f3ec6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e50f4d7f-1106-442b-a906-0525722f3ec6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e50f4d7f-1106-442b-a906-0525722f3ec6">
											<gml:posList>35.669329710695685 139.73952680678642 18.278 35.66932482224536 139.7395229463657 18.278 35.66931597483394 139.73953974680842 18.278 35.6692866135773 139.7395930896751 18.278 35.669310371297975 139.73961306640842 18.278 35.66935972494233 139.73952490487744 18.278 35.66933940388912 139.7395080722794 18.278 35.669329710695685 139.73952680678642 18.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-586bd2d9-ad08-4581-a8f0-e47e00be20cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-586bd2d9-ad08-4581-a8f0-e47e00be20cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-586bd2d9-ad08-4581-a8f0-e47e00be20cf">
											<gml:posList>35.6692866135773 139.7395930896751 17.148 35.66931597483394 139.73953974680842 17.148 35.66928498447988 139.73951513919224 17.148 35.669257654675675 139.73956121133475 17.148 35.669253550129014 139.7395685507482 17.148 35.66925873641787 139.7395729078947 17.148 35.669282465879725 139.7395913161008 17.148 35.66927441906374 139.73960603892314 17.148 35.66927330290956 139.73960802852713 17.148 35.66930042494744 139.7396308291341 17.148 35.669310371297975 139.73961306640842 17.148 35.6692866135773 139.7395930896751 17.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e2d5dd0-b3ca-4adf-b5ab-28f3b7301d47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e2d5dd0-b3ca-4adf-b5ab-28f3b7301d47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e2d5dd0-b3ca-4adf-b5ab-28f3b7301d47">
											<gml:posList>35.66927441906374 139.73960603892314 14.906 35.669282465879725 139.7395913161008 14.906 35.66925873641787 139.7395729078947 14.906 35.66925114840107 139.7395864703372 14.906 35.66927441906374 139.73960603892314 14.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-275231bc-1953-4b41-a81c-7bed3f4331d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-275231bc-1953-4b41-a81c-7bed3f4331d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-275231bc-1953-4b41-a81c-7bed3f4331d6">
											<gml:posList>35.669435011734485 139.73922980782405 11.04 35.66942632579489 139.7392224944355 11.04 35.66942632579489 139.7392224944355 18.895 35.669435011734485 139.73922980782405 18.895 35.669435011734485 139.73922980782405 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adaf624e-2fcc-4082-9d6f-542e0f09e5d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adaf624e-2fcc-4082-9d6f-542e0f09e5d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adaf624e-2fcc-4082-9d6f-542e0f09e5d0">
											<gml:posList>35.66942632579489 139.7392224944355 11.04 35.669420844077045 139.73923227669212 11.04 35.669420844077045 139.73923227669212 18.895 35.66942632579489 139.7392224944355 18.895 35.66942632579489 139.7392224944355 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab146194-b002-435c-89d5-0c16f0fcb6c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab146194-b002-435c-89d5-0c16f0fcb6c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab146194-b002-435c-89d5-0c16f0fcb6c1">
											<gml:posList>35.6694140973745 139.7392266069013 24.524 35.669420844077045 139.73923227669212 24.524 35.669420844077045 139.73923227669212 18.895 35.669420844077045 139.73923227669212 11.04 35.6694140973745 139.7392266069013 11.04 35.6694140973745 139.7392266069013 24.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c58b0f88-da97-48b1-ab1b-5a239da70892">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c58b0f88-da97-48b1-ab1b-5a239da70892">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c58b0f88-da97-48b1-ab1b-5a239da70892">
											<gml:posList>35.669429980080764 139.73923879423182 11.04 35.669435011734485 139.73922980782405 11.04 35.669435011734485 139.73922980782405 18.895 35.669429980080764 139.73923879423182 18.895 35.669429980080764 139.73923879423182 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1efc81c-7938-44d1-a299-fe8fdfb30829">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1efc81c-7938-44d1-a299-fe8fdfb30829">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1efc81c-7938-44d1-a299-fe8fdfb30829">
											<gml:posList>35.66946905717144 139.7392420732597 11.04 35.66945300218621 139.73922858268122 11.04 35.66945300218621 139.73922858268122 24.524 35.66946905717144 139.7392420732597 24.524 35.66946905717144 139.7392420732597 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f7b23b6-7883-4404-9f99-8855ea60f717">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f7b23b6-7883-4404-9f99-8855ea60f717">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f7b23b6-7883-4404-9f99-8855ea60f717">
											<gml:posList>35.669420844077045 139.73923227669212 18.895 35.669420844077045 139.73923227669212 24.524 35.669429980080764 139.73923879423182 24.524 35.669429980080764 139.73923879423182 18.895 35.669420844077045 139.73923227669212 18.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b0d6183-7b59-4e4c-bc5a-434ab3565c10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b0d6183-7b59-4e4c-bc5a-434ab3565c10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b0d6183-7b59-4e4c-bc5a-434ab3565c10">
											<gml:posList>35.66945300218621 139.73922858268122 11.04 35.66944175074117 139.7392486998433 11.04 35.66944175074117 139.7392486998433 24.524 35.66945300218621 139.73922858268122 24.524 35.66945300218621 139.73922858268122 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85910e45-27ab-4117-bb43-ee2dacd40c3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85910e45-27ab-4117-bb43-ee2dacd40c3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85910e45-27ab-4117-bb43-ee2dacd40c3d">
											<gml:posList>35.66944175074117 139.7392486998433 24.524 35.66944175074117 139.7392486998433 11.04 35.669429980080764 139.73923879423182 11.04 35.669429980080764 139.73923879423182 18.895 35.669429980080764 139.73923879423182 24.524 35.66944175074117 139.7392486998433 24.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b6d2946-02c6-4eca-aacd-c99d161dec4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b6d2946-02c6-4eca-aacd-c99d161dec4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b6d2946-02c6-4eca-aacd-c99d161dec4a">
											<gml:posList>35.66929409364895 139.73944098704536 15.187 35.66929409364895 139.73944098704536 24.524 35.6694140973745 139.7392266069013 24.524 35.6694140973745 139.7392266069013 11.04 35.669276730330964 139.73947199170897 11.04 35.669276730330964 139.73947199170897 15.187 35.66929409364895 139.73944098704536 15.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a4be125-871e-416b-9569-08424d27ca2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a4be125-871e-416b-9569-08424d27ca2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a4be125-871e-416b-9569-08424d27ca2b">
											<gml:posList>35.66930045250165 139.73944633696271 24.524 35.66929409364895 139.73944098704536 24.524 35.66929409364895 139.73944098704536 15.187 35.66930045250165 139.73944633696271 15.187 35.66930045250165 139.73944633696271 24.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84acf6aa-aea3-4474-9110-ea43dd438396">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84acf6aa-aea3-4474-9110-ea43dd438396">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84acf6aa-aea3-4474-9110-ea43dd438396">
											<gml:posList>35.669289290494056 139.73946560340084 24.524 35.66930045250165 139.73944633696271 24.524 35.66930045250165 139.73944633696271 15.187 35.669289290494056 139.73946560340084 15.187 35.669289290494056 139.73946560340084 24.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66142493-42cd-4f28-86d7-4b4c056bbc28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66142493-42cd-4f28-86d7-4b4c056bbc28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66142493-42cd-4f28-86d7-4b4c056bbc28">
											<gml:posList>35.66949206043419 139.73928850631748 24.524 35.66935972494233 139.73952490487744 24.524 35.66935972494233 139.73952490487744 18.278 35.669310371297975 139.73961306640842 18.278 35.669310371297975 139.73961306640842 17.148 35.66930042494744 139.7396308291341 17.148 35.66930042494744 139.7396308291341 11.04 35.66949206043419 139.73928850631748 11.04 35.66949206043419 139.73928850631748 24.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-078b0837-ec8e-4673-ae24-0c68af3eb741">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-078b0837-ec8e-4673-ae24-0c68af3eb741">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-078b0837-ec8e-4673-ae24-0c68af3eb741">
											<gml:posList>35.6693120651803 139.73948486325037 24.524 35.669289290494056 139.73946560340084 24.524 35.669289290494056 139.73946560340084 15.187 35.6693120651803 139.73948486325037 15.187 35.6693120651803 139.73948486325037 24.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cd840c8-a258-4dbd-8867-3a22fa7d41bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cd840c8-a258-4dbd-8867-3a22fa7d41bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cd840c8-a258-4dbd-8867-3a22fa7d41bd">
											<gml:posList>35.66930148933405 139.73950448247555 24.524 35.6693120651803 139.73948486325037 24.524 35.6693120651803 139.73948486325037 15.187 35.66930148933405 139.73950448247555 15.187 35.66930148933405 139.73950448247555 24.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-267f1f62-d43b-4f97-a0b7-d7f8b681f9da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-267f1f62-d43b-4f97-a0b7-d7f8b681f9da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-267f1f62-d43b-4f97-a0b7-d7f8b681f9da">
											<gml:posList>35.669276730330964 139.73947199170897 11.04 35.66924365619681 139.73954944151444 11.04 35.66924365619681 139.73954944151444 15.187 35.669276730330964 139.73947199170897 15.187 35.669276730330964 139.73947199170897 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57c73a7d-712b-4e36-8e50-dd2b181b8f37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57c73a7d-712b-4e36-8e50-dd2b181b8f37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57c73a7d-712b-4e36-8e50-dd2b181b8f37">
											<gml:posList>35.66932482224536 139.7395229463657 18.278 35.669329710695685 139.73952680678642 18.278 35.669329710695685 139.73952680678642 24.524 35.66930148933405 139.73950448247555 24.524 35.66930148933405 139.73950448247555 15.187 35.66932482224536 139.7395229463657 15.187 35.66932482224536 139.7395229463657 18.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a025e6cb-271a-45df-ab51-f1a90ae08e99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a025e6cb-271a-45df-ab51-f1a90ae08e99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a025e6cb-271a-45df-ab51-f1a90ae08e99">
											<gml:posList>35.66935972494233 139.73952490487744 24.524 35.66933940388912 139.7395080722794 24.524 35.66933940388912 139.7395080722794 18.278 35.66935972494233 139.73952490487744 18.278 35.66935972494233 139.73952490487744 24.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28dc9710-090e-47bc-9333-d1418413ed99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28dc9710-090e-47bc-9333-d1418413ed99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28dc9710-090e-47bc-9333-d1418413ed99">
											<gml:posList>35.669329710695685 139.73952680678642 18.278 35.66933940388912 139.7395080722794 18.278 35.66933940388912 139.7395080722794 24.524 35.669329710695685 139.73952680678642 24.524 35.669329710695685 139.73952680678642 18.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20e97a19-f3c4-4c86-b735-be2ce25f0ecf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20e97a19-f3c4-4c86-b735-be2ce25f0ecf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20e97a19-f3c4-4c86-b735-be2ce25f0ecf">
											<gml:posList>35.66928498447988 139.73951513919224 15.187 35.66928498447988 139.73951513919224 17.148 35.66931597483394 139.73953974680842 17.148 35.66931597483394 139.73953974680842 15.187 35.66928498447988 139.73951513919224 15.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc7e563f-a983-45fe-b4b3-465a0a609de6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc7e563f-a983-45fe-b4b3-465a0a609de6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc7e563f-a983-45fe-b4b3-465a0a609de6">
											<gml:posList>35.66932482224536 139.7395229463657 18.278 35.66932482224536 139.7395229463657 15.187 35.66931597483394 139.73953974680842 15.187 35.66931597483394 139.73953974680842 17.148 35.66931597483394 139.73953974680842 18.278 35.66932482224536 139.7395229463657 18.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52ede1de-ac6c-4379-9be2-12ae654e9ea0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52ede1de-ac6c-4379-9be2-12ae654e9ea0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52ede1de-ac6c-4379-9be2-12ae654e9ea0">
											<gml:posList>35.669257654675675 139.73956121133475 15.187 35.669257654675675 139.73956121133475 17.148 35.66928498447988 139.73951513919224 17.148 35.66928498447988 139.73951513919224 15.187 35.669257654675675 139.73956121133475 15.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69e1b005-ab6c-496c-9422-8eb478e9c360">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69e1b005-ab6c-496c-9422-8eb478e9c360">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69e1b005-ab6c-496c-9422-8eb478e9c360">
											<gml:posList>35.66924365619681 139.73954944151444 11.04 35.669257654675675 139.73956121133475 11.04 35.669257654675675 139.73956121133475 15.187 35.66924365619681 139.73954944151444 15.187 35.66924365619681 139.73954944151444 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9c55ab8-b748-4919-8c28-cf469e6c38cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9c55ab8-b748-4919-8c28-cf469e6c38cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9c55ab8-b748-4919-8c28-cf469e6c38cd">
											<gml:posList>35.669253550129014 139.7395685507482 17.148 35.669257654675675 139.73956121133475 17.148 35.669257654675675 139.73956121133475 15.187 35.669257654675675 139.73956121133475 11.04 35.669253550129014 139.7395685507482 11.04 35.669253550129014 139.7395685507482 17.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c08bc7ae-a368-48b1-92e5-1ce3d35d5487">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c08bc7ae-a368-48b1-92e5-1ce3d35d5487">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c08bc7ae-a368-48b1-92e5-1ce3d35d5487">
											<gml:posList>35.6692866135773 139.7395930896751 17.148 35.6692866135773 139.7395930896751 18.278 35.66931597483394 139.73953974680842 18.278 35.66931597483394 139.73953974680842 17.148 35.6692866135773 139.7395930896751 17.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fa7a421-92d5-48c1-88f0-8d413218a7be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fa7a421-92d5-48c1-88f0-8d413218a7be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fa7a421-92d5-48c1-88f0-8d413218a7be">
											<gml:posList>35.669253550129014 139.7395685507482 17.148 35.669253550129014 139.7395685507482 11.04 35.66925873641787 139.7395729078947 11.04 35.66925873641787 139.7395729078947 14.906 35.66925873641787 139.7395729078947 17.148 35.669253550129014 139.7395685507482 17.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af37eb12-5a8d-45eb-be8d-3176dba30e7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af37eb12-5a8d-45eb-be8d-3176dba30e7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af37eb12-5a8d-45eb-be8d-3176dba30e7e">
											<gml:posList>35.66925873641787 139.7395729078947 11.04 35.66925114840107 139.7395864703372 11.04 35.66925114840107 139.7395864703372 14.906 35.66925873641787 139.7395729078947 14.906 35.66925873641787 139.7395729078947 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75472cc7-fd5f-4243-aea1-01718d350464">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75472cc7-fd5f-4243-aea1-01718d350464">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75472cc7-fd5f-4243-aea1-01718d350464">
											<gml:posList>35.669282465879725 139.7395913161008 14.906 35.669282465879725 139.7395913161008 17.148 35.66925873641787 139.7395729078947 17.148 35.66925873641787 139.7395729078947 14.906 35.669282465879725 139.7395913161008 14.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e75a33e3-39d6-4e8f-ba92-80f821b7e4b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e75a33e3-39d6-4e8f-ba92-80f821b7e4b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e75a33e3-39d6-4e8f-ba92-80f821b7e4b6">
											<gml:posList>35.66925114840107 139.7395864703372 11.04 35.66927441906374 139.73960603892314 11.04 35.66927441906374 139.73960603892314 14.906 35.66925114840107 139.7395864703372 14.906 35.66925114840107 139.7395864703372 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be583ba7-d0fb-4441-9611-df287970aee1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be583ba7-d0fb-4441-9611-df287970aee1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be583ba7-d0fb-4441-9611-df287970aee1">
											<gml:posList>35.66927441906374 139.73960603892314 14.906 35.66927441906374 139.73960603892314 17.148 35.669282465879725 139.7395913161008 17.148 35.669282465879725 139.7395913161008 14.906 35.66927441906374 139.73960603892314 14.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e84f57c-d95b-43e5-9d29-4f37ecc3f9b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e84f57c-d95b-43e5-9d29-4f37ecc3f9b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e84f57c-d95b-43e5-9d29-4f37ecc3f9b8">
											<gml:posList>35.669310371297975 139.73961306640842 17.148 35.669310371297975 139.73961306640842 18.278 35.6692866135773 139.7395930896751 18.278 35.6692866135773 139.7395930896751 17.148 35.669310371297975 139.73961306640842 17.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-480cb10a-ca64-4ca9-84d7-b9581cb7892d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-480cb10a-ca64-4ca9-84d7-b9581cb7892d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-480cb10a-ca64-4ca9-84d7-b9581cb7892d">
											<gml:posList>35.66927330290956 139.73960802852713 17.148 35.66927441906374 139.73960603892314 17.148 35.66927441906374 139.73960603892314 14.906 35.66927441906374 139.73960603892314 11.04 35.66927330290956 139.73960802852713 11.04 35.66927330290956 139.73960802852713 17.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fbe00fd-54b9-40b9-904c-6487d01ec4b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fbe00fd-54b9-40b9-904c-6487d01ec4b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fbe00fd-54b9-40b9-904c-6487d01ec4b3">
											<gml:posList>35.66927330290956 139.73960802852713 11.04 35.66930042494744 139.7396308291341 11.04 35.66930042494744 139.7396308291341 17.148 35.66927330290956 139.73960802852713 17.148 35.66927330290956 139.73960802852713 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-826cc1cf-4568-4e9c-a1aa-2ec3987d3932">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-826cc1cf-4568-4e9c-a1aa-2ec3987d3932">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-826cc1cf-4568-4e9c-a1aa-2ec3987d3932">
											<gml:posList>35.66947042534988 139.7392396304585 11.04 35.66946905717144 139.7392420732597 11.04 35.66946905717144 139.7392420732597 24.524 35.66947042534988 139.7392396304585 24.524 35.66947042534988 139.7392396304585 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1a8af64-b530-4104-831a-918a57fb2628">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1a8af64-b530-4104-831a-918a57fb2628">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1a8af64-b530-4104-831a-918a57fb2628">
											<gml:posList>35.66948209678151 139.7392494367763 11.04 35.66947042534988 139.7392396304585 11.04 35.66947042534988 139.7392396304585 24.524 35.66948209678151 139.7392494367763 24.524 35.66948209678151 139.7392494367763 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f90be8b4-75fb-4bc9-92e9-0d1666fbe0c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f90be8b4-75fb-4bc9-92e9-0d1666fbe0c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f90be8b4-75fb-4bc9-92e9-0d1666fbe0c1">
											<gml:posList>35.66947041326969 139.73927031663288 11.04 35.66948209678151 139.7392494367763 11.04 35.66948209678151 139.7392494367763 24.524 35.66947041326969 139.73927031663288 24.524 35.66947041326969 139.73927031663288 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f26af369-f071-4b9d-8c14-56b75bffda49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f26af369-f071-4b9d-8c14-56b75bffda49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f26af369-f071-4b9d-8c14-56b75bffda49">
											<gml:posList>35.66949206043419 139.73928850631748 11.04 35.66947041326969 139.73927031663288 11.04 35.66947041326969 139.73927031663288 24.524 35.66949206043419 139.73928850631748 24.524 35.66949206043419 139.73928850631748 11.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4317</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>