<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ea46a3a4-e5e5-45be-bb7d-a3a48efab8eb">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">31.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6705762400977 139.74369534364942 0 35.670591772384086 139.74361281050614 0 35.670483134133775 139.74358222343395 0 35.67047409311208 139.7436302737945 0 35.67050771238765 139.74363976911823 0 35.67050049987028 139.74367402064345 0 35.6705762400977 139.74369534364942 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705762400977 139.74369534364942 7.35 35.67050049987028 139.74367402064345 7.35 35.67050771238765 139.74363976911823 7.35 35.67047409311208 139.7436302737945 7.35 35.670483134133775 139.74358222343395 7.35 35.670591772384086 139.74361281050614 7.35 35.6705762400977 139.74369534364942 7.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705762400977 139.74369534364942 7.35 35.670591772384086 139.74361281050614 7.35 35.670591772384086 139.74361281050614 38.68 35.6705762400977 139.74369534364942 38.68 35.6705762400977 139.74369534364942 7.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670591772384086 139.74361281050614 7.35 35.670483134133775 139.74358222343395 7.35 35.670483134133775 139.74358222343395 38.68 35.670591772384086 139.74361281050614 38.68 35.670591772384086 139.74361281050614 7.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670483134133775 139.74358222343395 7.35 35.67047409311208 139.7436302737945 7.35 35.67047409311208 139.7436302737945 38.68 35.670483134133775 139.74358222343395 38.68 35.670483134133775 139.74358222343395 7.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047409311208 139.7436302737945 7.35 35.67050771238765 139.74363976911823 7.35 35.67050771238765 139.74363976911823 38.68 35.67047409311208 139.7436302737945 38.68 35.67047409311208 139.7436302737945 7.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050771238765 139.74363976911823 7.35 35.67050049987028 139.74367402064345 7.35 35.67050049987028 139.74367402064345 38.68 35.67050771238765 139.74363976911823 38.68 35.67050771238765 139.74363976911823 7.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050049987028 139.74367402064345 7.35 35.6705762400977 139.74369534364942 7.35 35.6705762400977 139.74369534364942 38.68 35.67050049987028 139.74367402064345 38.68 35.67050049987028 139.74367402064345 7.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705762400977 139.74369534364942 38.68 35.670591772384086 139.74361281050614 38.68 35.670483134133775 139.74358222343395 38.68 35.67047409311208 139.7436302737945 38.68 35.67050771238765 139.74363976911823 38.68 35.67050049987028 139.74367402064345 38.68 35.6705762400977 139.74369534364942 38.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-daa3a4e0-65a7-4eb0-b2e3-da8b99aa0817"/>
							<gml:surfaceMember xlink:href="#poly-3eca0051-624f-4aa3-8127-1f53afce7704"/>
							<gml:surfaceMember xlink:href="#poly-eee1da37-7237-4c3e-a6a9-409fc477f5a5"/>
							<gml:surfaceMember xlink:href="#poly-5944691c-fa24-43d0-b6c8-f44379dd89d7"/>
							<gml:surfaceMember xlink:href="#poly-d27535ed-0bc2-43dd-96ac-95553ce5dc3e"/>
							<gml:surfaceMember xlink:href="#poly-35a065f5-a6e0-4202-ae31-3f380a63129b"/>
							<gml:surfaceMember xlink:href="#poly-a60f7f5e-5525-49dd-ae6b-cc6144e61ae2"/>
							<gml:surfaceMember xlink:href="#poly-91654baf-b54b-433c-a4a9-d27329c3c582"/>
							<gml:surfaceMember xlink:href="#poly-143cd9ff-5b61-4c83-a74a-fee734dad81e"/>
							<gml:surfaceMember xlink:href="#poly-02c20b33-85c4-4205-8e30-1db8fec18095"/>
							<gml:surfaceMember xlink:href="#poly-89445225-4ba0-4052-b4e8-5480b6cfed74"/>
							<gml:surfaceMember xlink:href="#poly-f55101f5-f9ab-41f4-b8b0-922a7bd25adb"/>
							<gml:surfaceMember xlink:href="#poly-510a1f12-40bd-4bf1-83c7-d566c7dc24b2"/>
							<gml:surfaceMember xlink:href="#poly-8c3a70da-d9ca-43ff-a408-26b1f63d2e66"/>
							<gml:surfaceMember xlink:href="#poly-bd5c9003-03e7-43c2-bf25-db538be066f5"/>
							<gml:surfaceMember xlink:href="#poly-8cb44e34-79b5-42cb-bef2-5a1ba464e3e6"/>
							<gml:surfaceMember xlink:href="#poly-f8654817-402a-49a5-998d-33789e58d864"/>
							<gml:surfaceMember xlink:href="#poly-85bed3cf-3746-4025-9782-fa0398ad6878"/>
							<gml:surfaceMember xlink:href="#poly-93d7a32b-18ce-48c0-ba3c-b31df66ec0b2"/>
							<gml:surfaceMember xlink:href="#poly-bf4145e1-6023-46cb-a526-d58f684db463"/>
							<gml:surfaceMember xlink:href="#poly-ffec49a0-e743-4cbd-9eb8-593505ad4968"/>
							<gml:surfaceMember xlink:href="#poly-2eb5eaba-cff6-482b-a098-c681ba237267"/>
							<gml:surfaceMember xlink:href="#poly-ccc992aa-f566-4cf2-95c1-5020f3cb6fc1"/>
							<gml:surfaceMember xlink:href="#poly-09b02a52-1507-4887-adc3-808972967b37"/>
							<gml:surfaceMember xlink:href="#poly-72f69af7-0d5e-4e95-8b4e-3ea631b73baf"/>
							<gml:surfaceMember xlink:href="#poly-ab046e23-61f0-4b7f-b5a6-f1a054e964ea"/>
							<gml:surfaceMember xlink:href="#poly-b026e558-6308-452d-a762-614d9ce67549"/>
							<gml:surfaceMember xlink:href="#poly-1a3cf18e-08f8-48d2-99f1-e36b717b3896"/>
							<gml:surfaceMember xlink:href="#poly-0785d10c-6f88-4b28-b9ed-e224f8d28bf7"/>
							<gml:surfaceMember xlink:href="#poly-0ededea3-acb4-41e0-a9f1-dfc19bb73dea"/>
							<gml:surfaceMember xlink:href="#poly-7055643c-c205-4fdc-a350-3e3067299f54"/>
							<gml:surfaceMember xlink:href="#poly-bd52111e-d647-406f-a43f-4c4013b0f87c"/>
							<gml:surfaceMember xlink:href="#poly-c4c6086b-90b0-4dcc-b91e-1f10aec3d2c2"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ea46a3a4-e5e5-45be-bb7d-a3a48efab8eb_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43d0be29-b42a-4b40-9734-d7affa4c7a4c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67046760186796 139.74366475647125 7.58 35.67047409311206 139.74363027379448 7.58 35.67050771238764 139.74363976911823 7.58 35.670500499870286 139.74367402064343 7.58 35.67046760186796 139.74366475647125 7.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b0b7314-458e-45ed-9606-f52c10a60f9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b0b7314-458e-45ed-9606-f52c10a60f9b_0">
											<gml:posList>35.67047409311206 139.74363027379448 39.1 35.67047409311206 139.74363027379448 7.58 35.67046760186796 139.74366475647125 7.58 35.67046760186796 139.74366475647125 39.1 35.67047409311206 139.74363027379448 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11e58ff9-503a-4fa5-aa06-f6ec868ac739">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11e58ff9-503a-4fa5-aa06-f6ec868ac739_0">
											<gml:posList>35.67046760186796 139.74366475647125 39.1 35.67046760186796 139.74366475647125 7.58 35.670500499870286 139.74367402064343 7.58 35.670500499870286 139.74367402064343 39.1 35.67046760186796 139.74366475647125 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ea23a9b-6e04-4ccd-a7c7-cfa175a984f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ea23a9b-6e04-4ccd-a7c7-cfa175a984f9_0">
											<gml:posList>35.670500499870286 139.74367402064343 39.1 35.67050771238764 139.74363976911823 39.1 35.67047409311206 139.74363027379448 39.1 35.67046760186796 139.74366475647125 39.1 35.670500499870286 139.74367402064343 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-258e06f2-bfa2-4fc2-899f-416569838061">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-258e06f2-bfa2-4fc2-899f-416569838061_0">
											<gml:posList>35.67050771238764 139.74363976911823 39.1 35.67050771238764 139.74363976911823 7.58 35.67047409311206 139.74363027379448 7.58 35.67047409311206 139.74363027379448 39.1 35.67050771238764 139.74363976911823 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11ab68ed-8780-48a1-add9-ec37a138f224">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11ab68ed-8780-48a1-add9-ec37a138f224_0">
											<gml:posList>35.670500499870286 139.74367402064343 39.1 35.670500499870286 139.74367402064343 7.58 35.67050771238764 139.74363976911823 7.58 35.67050771238764 139.74363976911823 39.1 35.670500499870286 139.74367402064343 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ea46a3a4-e5e5-45be-bb7d-a3a48efab8eb_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b7632e5-6865-4ce9-a209-3a24925002a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b7632e5-6865-4ce9-a209-3a24925002a6_0">
											<gml:posList>35.67051521424804 139.7436067433999 38.604 35.67049360301103 139.7435995985524 40.035 35.67051521424804 139.7436067433999 40.035 35.67051521424804 139.7436067433999 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7565b7a9-9475-4130-b254-14a32bfb71cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7565b7a9-9475-4130-b254-14a32bfb71cf_0">
											<gml:posList>35.67051521424804 139.7436067433999 38.604 35.67049360301103 139.7435995985524 38.604 35.67049360301103 139.7435995985524 40.035 35.67051521424804 139.7436067433999 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28e94f48-5ab7-45a5-b033-2294bf179622">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28e94f48-5ab7-45a5-b033-2294bf179622_0">
											<gml:posList>35.67049360301103 139.7435995985524 38.604 35.67049183330829 139.74360765326765 40.035 35.67049360301103 139.7435995985524 40.035 35.67049360301103 139.7435995985524 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-706935a1-fb9e-44c6-84c0-b5a2ffe0c7b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-706935a1-fb9e-44c6-84c0-b5a2ffe0c7b1_0">
											<gml:posList>35.67049360301103 139.7435995985524 38.604 35.67049183330829 139.74360765326765 38.604 35.67049183330829 139.74360765326765 40.035 35.67049360301103 139.7435995985524 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6261ec0d-1a01-46f8-ab3e-40def23d8654">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6261ec0d-1a01-46f8-ab3e-40def23d8654_0">
											<gml:posList>35.67049183330829 139.74360765326765 40.035 35.67051521424804 139.7436067433999 40.035 35.67049360301103 139.7435995985524 40.035 35.67049183330829 139.74360765326765 40.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8335f4f-c48f-42b3-a56b-184dfaaae939">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8335f4f-c48f-42b3-a56b-184dfaaae939_0">
											<gml:posList>35.67049183330829 139.74360765326765 40.035 35.6705134445366 139.74361478707087 40.035 35.67051521424804 139.7436067433999 40.035 35.67049183330829 139.74360765326765 40.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2047a957-1c9b-42c4-97e6-cd3afbf3bca2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2047a957-1c9b-42c4-97e6-cd3afbf3bca2_0">
											<gml:posList>35.6705134445366 139.74361478707087 38.604 35.67051521424804 139.7436067433999 40.035 35.6705134445366 139.74361478707087 40.035 35.6705134445366 139.74361478707087 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c99e35e-cbb6-475e-8ec3-87382edc8c7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c99e35e-cbb6-475e-8ec3-87382edc8c7b_0">
											<gml:posList>35.6705134445366 139.74361478707087 38.604 35.67051521424804 139.7436067433999 38.604 35.67051521424804 139.7436067433999 40.035 35.6705134445366 139.74361478707087 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7c0ec09-1d28-4b78-8ebf-7e1466967117">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7c0ec09-1d28-4b78-8ebf-7e1466967117_0">
											<gml:posList>35.67049183330829 139.74360765326765 38.604 35.6705134445366 139.74361478707087 40.035 35.67049183330829 139.74360765326765 40.035 35.67049183330829 139.74360765326765 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc9cbc5b-c824-481c-b8ca-e962294a1b81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc9cbc5b-c824-481c-b8ca-e962294a1b81_0">
											<gml:posList>35.67049183330829 139.74360765326765 38.604 35.6705134445366 139.74361478707087 38.604 35.6705134445366 139.74361478707087 40.035 35.67049183330829 139.74360765326765 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-757fbe3b-7db0-43f4-abdd-776795e73666">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-757fbe3b-7db0-43f4-abdd-776795e73666_0">
											<gml:posList>35.6705423612522 139.74361568260062 38.604 35.67052060542584 139.74360804082755 40.035 35.6705423612522 139.74361568260062 40.035 35.6705423612522 139.74361568260062 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43f7a350-d731-4067-9890-75edbeda0f3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43f7a350-d731-4067-9890-75edbeda0f3a_0">
											<gml:posList>35.6705423612522 139.74361568260062 38.604 35.67052060542584 139.74360804082755 38.604 35.67052060542584 139.74360804082755 40.035 35.6705423612522 139.74361568260062 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a440f87e-a942-4105-bbab-52c50ccbeb32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a440f87e-a942-4105-bbab-52c50ccbeb32_0">
											<gml:posList>35.67052060542584 139.74360804082755 38.604 35.670518655662065 139.74361638295005 40.035 35.67052060542584 139.74360804082755 40.035 35.67052060542584 139.74360804082755 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94f27d5f-9fe1-4df4-a74e-4c4f35ed4697">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94f27d5f-9fe1-4df4-a74e-4c4f35ed4697_0">
											<gml:posList>35.67052060542584 139.74360804082755 38.604 35.670518655662065 139.74361638295005 38.604 35.670518655662065 139.74361638295005 40.035 35.67052060542584 139.74360804082755 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6aa2eb3d-1f1c-4683-b8b6-855ed8c00bc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6aa2eb3d-1f1c-4683-b8b6-855ed8c00bc6_0">
											<gml:posList>35.67054041147968 139.74362401367893 40.035 35.67052060542584 139.74360804082755 40.035 35.670518655662065 139.74361638295005 40.035 35.67054041147968 139.74362401367893 40.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5364f186-9aab-4bba-b1d1-b201aec5409b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5364f186-9aab-4bba-b1d1-b201aec5409b_0">
											<gml:posList>35.67054041147968 139.74362401367893 40.035 35.6705423612522 139.74361568260062 40.035 35.67052060542584 139.74360804082755 40.035 35.67054041147968 139.74362401367893 40.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2934c46c-0b65-4589-82b3-30eb09e0acff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2934c46c-0b65-4589-82b3-30eb09e0acff_0">
											<gml:posList>35.67054041147968 139.74362401367893 38.604 35.6705423612522 139.74361568260062 40.035 35.67054041147968 139.74362401367893 40.035 35.67054041147968 139.74362401367893 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-853d4684-b037-409a-b147-e6e4496de461">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-853d4684-b037-409a-b147-e6e4496de461_0">
											<gml:posList>35.67054041147968 139.74362401367893 38.604 35.6705423612522 139.74361568260062 38.604 35.6705423612522 139.74361568260062 40.035 35.67054041147968 139.74362401367893 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-138605f0-ebe3-4af8-afef-e6b4723f7889">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-138605f0-ebe3-4af8-afef-e6b4723f7889_0">
											<gml:posList>35.67054041147968 139.74362401367893 38.604 35.670518655662065 139.74361638295005 40.035 35.670518655662065 139.74361638295005 38.604 35.67054041147968 139.74362401367893 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdc7cd58-b905-49b5-814e-df2afcc70d65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdc7cd58-b905-49b5-814e-df2afcc70d65_0">
											<gml:posList>35.67054041147968 139.74362401367893 38.604 35.67054041147968 139.74362401367893 40.035 35.670518655662065 139.74361638295005 40.035 35.67054041147968 139.74362401367893 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7ab56c1-dc9a-4f01-9056-2a5762470be4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7ab56c1-dc9a-4f01-9056-2a5762470be4_0">
											<gml:posList>35.670496106846244 139.74363323165974 38.604 35.67049833439069 139.743622679974 40.229 35.67049833439069 139.743622679974 38.604 35.670496106846244 139.74363323165974 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91e7c0e5-4d98-4d2c-a014-e7283fbb9d64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91e7c0e5-4d98-4d2c-a014-e7283fbb9d64_0">
											<gml:posList>35.670496106846244 139.74363323165974 38.604 35.670496106846244 139.74363323165974 40.229 35.67049833439069 139.743622679974 40.229 35.670496106846244 139.74363323165974 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee9e3f79-531a-4673-8e4e-6b921ef29fcf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee9e3f79-531a-4673-8e4e-6b921ef29fcf_0">
											<gml:posList>35.67054006883188 139.74363594404662 38.604 35.67049833439069 139.743622679974 40.229 35.67054006883188 139.74363594404662 40.229 35.67054006883188 139.74363594404662 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c57814d-1f60-4a14-9eb8-379b9a259c3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c57814d-1f60-4a14-9eb8-379b9a259c3a_0">
											<gml:posList>35.67054006883188 139.74363594404662 38.604 35.67049833439069 139.743622679974 38.604 35.67049833439069 139.743622679974 40.229 35.67054006883188 139.74363594404662 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79e3052e-331d-45d8-a9d8-1b9370b130cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79e3052e-331d-45d8-a9d8-1b9370b130cf_0">
											<gml:posList>35.670508269247236 139.74363709529612 38.604 35.670496106846244 139.74363323165974 40.229 35.670496106846244 139.74363323165974 38.604 35.670508269247236 139.74363709529612 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04df1837-8292-40a8-91fe-083bc9731457">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04df1837-8292-40a8-91fe-083bc9731457_0">
											<gml:posList>35.670508269247236 139.74363709529612 38.604 35.670508269247236 139.74363709529612 40.229 35.670496106846244 139.74363323165974 40.229 35.670508269247236 139.74363709529612 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fa108d0-3353-45c6-949e-0a876a18ef4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fa108d0-3353-45c6-949e-0a876a18ef4a_0">
											<gml:posList>35.670508269247236 139.74363709529612 40.229 35.67051653679806 139.74363972610757 38.604 35.67051653679806 139.74363972610757 40.229 35.670508269247236 139.74363709529612 40.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15d031f4-571e-4972-962d-7f90d4476e0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15d031f4-571e-4972-962d-7f90d4476e0c_0">
											<gml:posList>35.670508269247236 139.74363709529612 40.229 35.670508269247236 139.74363709529612 38.604 35.67051653679806 139.74363972610757 38.604 35.670508269247236 139.74363709529612 40.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b091d7b-705d-49eb-b067-f103e4bfb36a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b091d7b-705d-49eb-b067-f103e4bfb36a_0">
											<gml:posList>35.67053783227258 139.74364649574758 38.604 35.67054006883188 139.74363594404662 40.229 35.67053783227258 139.74364649574758 40.229 35.67053783227258 139.74364649574758 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbd0a04d-56e1-4e1a-83e4-77ec172640ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbd0a04d-56e1-4e1a-83e4-77ec172640ac_0">
											<gml:posList>35.67053783227258 139.74364649574758 38.604 35.67054006883188 139.74363594404662 38.604 35.67054006883188 139.74363594404662 40.229 35.67053783227258 139.74364649574758 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39f299f4-c15f-43b4-a698-63a1e428c65a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39f299f4-c15f-43b4-a698-63a1e428c65a_0">
											<gml:posList>35.67051653679806 139.74363972610757 40.229 35.67053783227258 139.74364649574758 38.604 35.67053783227258 139.74364649574758 40.229 35.67051653679806 139.74363972610757 40.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5231b6b1-acdb-491f-a04e-dc18fb2f64c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5231b6b1-acdb-491f-a04e-dc18fb2f64c9_0">
											<gml:posList>35.67051653679806 139.74363972610757 40.229 35.67051653679806 139.74363972610757 38.604 35.67053783227258 139.74364649574758 38.604 35.67051653679806 139.74363972610757 40.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe7cc613-c894-49c8-92a9-444b8dbca894">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe7cc613-c894-49c8-92a9-444b8dbca894_0">
											<gml:posList>35.67051164971835 139.7436496290397 43.673 35.67053245787541 139.74365562598732 44.788 35.67053245787541 139.74365562598732 43.673 35.67051164971835 139.7436496290397 43.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6345bdf2-aba7-4304-b492-61f8f4a01c57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6345bdf2-aba7-4304-b492-61f8f4a01c57_0">
											<gml:posList>35.67051164971835 139.7436496290397 43.673 35.67051164971835 139.7436496290397 44.788 35.67053245787541 139.74365562598732 44.788 35.67051164971835 139.7436496290397 43.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-314e5211-9f00-4aaa-a8b2-2613df5935b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-314e5211-9f00-4aaa-a8b2-2613df5935b1_0">
											<gml:posList>35.67051164971835 139.7436496290397 43.673 35.670509054821736 139.74366315258595 44.788 35.67051164971835 139.7436496290397 44.788 35.67051164971835 139.7436496290397 43.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f28c997f-5a03-4b8a-9899-532fc237278a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f28c997f-5a03-4b8a-9899-532fc237278a_0">
											<gml:posList>35.67051164971835 139.7436496290397 43.673 35.670509054821736 139.74366315258595 43.673 35.670509054821736 139.74366315258595 44.788 35.67051164971835 139.7436496290397 43.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-852718df-0391-4512-833e-da7ec0dc9ead">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-852718df-0391-4512-833e-da7ec0dc9ead_0">
											<gml:posList>35.670509054821736 139.74366315258595 44.788 35.67053245787541 139.74365562598732 44.788 35.67051164971835 139.7436496290397 44.788 35.670509054821736 139.74366315258595 44.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3afee8a4-ccce-4ad9-b1f7-bbee35a57f1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3afee8a4-ccce-4ad9-b1f7-bbee35a57f1c_0">
											<gml:posList>35.670509054821736 139.74366315258595 44.788 35.670529862978135 139.74366914953688 44.788 35.67053245787541 139.74365562598732 44.788 35.670509054821736 139.74366315258595 44.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16f739ef-91c2-4906-aacd-ecc953b3937e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16f739ef-91c2-4906-aacd-ecc953b3937e_0">
											<gml:posList>35.670529862978135 139.74366914953688 43.673 35.67053245787541 139.74365562598732 44.788 35.670529862978135 139.74366914953688 44.788 35.670529862978135 139.74366914953688 43.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5903a924-0bf3-47c4-a2b8-5fa94a412419">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5903a924-0bf3-47c4-a2b8-5fa94a412419_0">
											<gml:posList>35.670529862978135 139.74366914953688 43.673 35.67053245787541 139.74365562598732 43.673 35.67053245787541 139.74365562598732 44.788 35.670529862978135 139.74366914953688 43.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eb7ad3d-5371-4b61-9b56-186464bb4a70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9eb7ad3d-5371-4b61-9b56-186464bb4a70_0">
											<gml:posList>35.670509054821736 139.74366315258595 43.673 35.670529862978135 139.74366914953688 44.788 35.670509054821736 139.74366315258595 44.788 35.670509054821736 139.74366315258595 43.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3667930b-c63b-42ba-94bb-9d943e8dcab0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3667930b-c63b-42ba-94bb-9d943e8dcab0_0">
											<gml:posList>35.670509054821736 139.74366315258595 43.673 35.670529862978135 139.74366914953688 43.673 35.670529862978135 139.74366914953688 44.788 35.670509054821736 139.74366315258595 43.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-881b2389-ff8f-44ae-a412-fbf1018ac2a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-881b2389-ff8f-44ae-a412-fbf1018ac2a5_0">
											<gml:posList>35.670508269247236 139.74363709529612 40.229 35.67049833439069 139.743622679974 40.229 35.670496106846244 139.74363323165974 40.229 35.670508269247236 139.74363709529612 40.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-273bc281-8065-4d31-8312-6c6068eff709">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-273bc281-8065-4d31-8312-6c6068eff709_0">
											<gml:posList>35.67051653679806 139.74363972610757 40.229 35.67054006883188 139.74363594404662 40.229 35.67049833439069 139.743622679974 40.229 35.67051653679806 139.74363972610757 40.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27ad0a3f-6980-484d-996e-7f4ba74893eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27ad0a3f-6980-484d-996e-7f4ba74893eb_0">
											<gml:posList>35.67053783227258 139.74364649574758 40.229 35.67054006883188 139.74363594404662 40.229 35.67051653679806 139.74363972610757 40.229 35.67053783227258 139.74364649574758 40.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43375c24-01d3-49db-9445-fe75bc6106b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43375c24-01d3-49db-9445-fe75bc6106b1_0">
											<gml:posList>35.67049833439069 139.743622679974 40.229 35.670508269247236 139.74363709529612 40.229 35.67051653679806 139.74363972610757 40.229 35.67049833439069 139.743622679974 40.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81f494b5-4e3d-45cf-b666-da13a6326304">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049183330829 139.74360765326765 38.604 35.67051521424804 139.7436067433999 38.604 35.6705134445366 139.74361478707087 38.604 35.67049183330829 139.74360765326765 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef2a92dd-103f-4fd5-bbf8-ba06167e756c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049183330829 139.74360765326765 38.604 35.67049360301103 139.7435995985524 38.604 35.67051521424804 139.7436067433999 38.604 35.67049183330829 139.74360765326765 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-889fdb9a-2dd2-412d-96bf-70d7b9f4aa79">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054041147968 139.74362401367893 38.604 35.67052060542584 139.74360804082755 38.604 35.6705423612522 139.74361568260062 38.604 35.67054041147968 139.74362401367893 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f88ccc8-806d-4bb6-b370-c5c22e4063ea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054041147968 139.74362401367893 38.604 35.670518655662065 139.74361638295005 38.604 35.67052060542584 139.74360804082755 38.604 35.67054041147968 139.74362401367893 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7058326c-05d3-4b61-8ebc-f1bdf106d23c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670496106846244 139.74363323165974 38.604 35.67049833439069 139.743622679974 38.604 35.670508269247236 139.74363709529612 38.604 35.670496106846244 139.74363323165974 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39b86976-692c-49b6-95bd-5fee110ffe3d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049833439069 139.743622679974 38.604 35.67054006883188 139.74363594404662 38.604 35.67051653679806 139.74363972610757 38.604 35.67049833439069 139.743622679974 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-379a896f-ed07-4946-a21f-4559a998e1dc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054006883188 139.74363594404662 38.604 35.67053783227258 139.74364649574758 38.604 35.67051653679806 139.74363972610757 38.604 35.67054006883188 139.74363594404662 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0060f58f-5cd8-4e6e-a169-3cdd4280bef2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670508269247236 139.74363709529612 38.604 35.67049833439069 139.743622679974 38.604 35.67051653679806 139.74363972610757 38.604 35.670508269247236 139.74363709529612 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab5ad3fa-9f79-4e56-8c61-e2172ec51a2a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670509054821736 139.74366315258595 43.673 35.67053245787541 139.74365562598732 43.673 35.670529862978135 139.74366914953688 43.673 35.670509054821736 139.74366315258595 43.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b35fcf2-f9d4-4223-8ed2-98dee4686a39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670509054821736 139.74366315258595 43.673 35.67051164971835 139.7436496290397 43.673 35.67053245787541 139.74365562598732 43.673 35.670509054821736 139.74366315258595 43.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ea46a3a4-e5e5-45be-bb7d-a3a48efab8eb_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8abc5d0-860d-4d5c-aa90-6e0820d3a116">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057238566912 139.74366365616345 38.604 35.670549954260885 139.74365661162946 38.604 35.67055518163656 139.7436316190886 38.604 35.67057761304623 139.74363866361605 38.604 35.67057238566912 139.74366365616345 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af4d3252-3b90-47b5-8bea-c571fed9d77d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af4d3252-3b90-47b5-8bea-c571fed9d77d_0">
											<gml:posList>35.670549954260885 139.74365661162946 38.604 35.670549954260885 139.74365661162946 41.287 35.67055518163656 139.7436316190886 41.287 35.67055518163656 139.7436316190886 38.604 35.670549954260885 139.74365661162946 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50e729cd-58fb-410e-9a44-da8f3a6ce731">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50e729cd-58fb-410e-9a44-da8f3a6ce731_0">
											<gml:posList>35.67057238566912 139.74366365616345 38.604 35.67057238566912 139.74366365616345 41.287 35.670549954260885 139.74365661162946 41.287 35.670549954260885 139.74365661162946 38.604 35.67057238566912 139.74366365616345 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aab23c69-d778-4480-a65f-6a6fecc36fa6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aab23c69-d778-4480-a65f-6a6fecc36fa6_0">
											<gml:posList>35.67057238566912 139.74366365616345 41.287 35.67057761304623 139.74363866361605 41.287 35.67055518163656 139.7436316190886 41.287 35.670549954260885 139.74365661162946 41.287 35.67057238566912 139.74366365616345 41.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-932f0aa2-8f5a-43e7-8ae3-02b3d9179a3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-932f0aa2-8f5a-43e7-8ae3-02b3d9179a3d_0">
											<gml:posList>35.67055518163656 139.7436316190886 38.604 35.67055518163656 139.7436316190886 41.287 35.67057761304623 139.74363866361605 41.287 35.67057761304623 139.74363866361605 38.604 35.67055518163656 139.7436316190886 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a15b5b82-4fd5-477a-9e1c-09aa81f8bcef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a15b5b82-4fd5-477a-9e1c-09aa81f8bcef_0">
											<gml:posList>35.67057761304623 139.74363866361605 38.604 35.67057761304623 139.74363866361605 41.287 35.67057238566912 139.74366365616345 41.287 35.67057238566912 139.74366365616345 38.604 35.67057761304623 139.74363866361605 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-daa3a4e0-65a7-4eb0-b2e3-da8b99aa0817">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-daa3a4e0-65a7-4eb0-b2e3-da8b99aa0817">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-daa3a4e0-65a7-4eb0-b2e3-da8b99aa0817">
											<gml:posList>35.67059177238405 139.74361281050614 7.35 35.6705762400977 139.74369534364942 7.35 35.670500499870286 139.74367402064343 7.35 35.67050771238764 139.74363976911823 7.35 35.67047409311206 139.74363027379448 7.35 35.67048313413378 139.74358222343395 7.35 35.67059177238405 139.74361281050614 7.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3eca0051-624f-4aa3-8127-1f53afce7704">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3eca0051-624f-4aa3-8127-1f53afce7704">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3eca0051-624f-4aa3-8127-1f53afce7704">
											<gml:posList>35.67050661105951 139.74363755004856 39.1 35.67050771238764 139.74363976911823 39.1 35.670508080641994 139.74363801234816 39.1 35.67050661105951 139.74363755004856 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eee1da37-7237-4c3e-a6a9-409fc477f5a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eee1da37-7237-4c3e-a6a9-409fc477f5a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eee1da37-7237-4c3e-a6a9-409fc477f5a5">
											<gml:posList>35.67047409311206 139.74363027379448 39.1 35.67047591284731 139.74362887992814 39.1 35.67048427152606 139.7435844535081 39.1 35.67048313413378 139.74358222343395 39.1 35.67047409311206 139.74363027379448 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5944691c-fa24-43d0-b6c8-f44379dd89d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5944691c-fa24-43d0-b6c8-f44379dd89d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5944691c-fa24-43d0-b6c8-f44379dd89d7">
											<gml:posList>35.67050771238764 139.74363976911823 39.1 35.67050661105951 139.74363755004856 39.1 35.67047591284731 139.74362887992814 39.1 35.67047409311206 139.74363027379448 39.1 35.67050771238764 139.74363976911823 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d27535ed-0bc2-43dd-96ac-95553ce5dc3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d27535ed-0bc2-43dd-96ac-95553ce5dc3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d27535ed-0bc2-43dd-96ac-95553ce5dc3e">
											<gml:posList>35.670500499870286 139.74367402064343 44.12 35.670501878205016 139.7436729917984 44.12 35.67050908174949 139.7436387955139 44.12 35.670508269247236 139.74363709529612 44.12 35.670500499870286 139.74367402064343 44.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35a065f5-a6e0-4202-ae31-3f380a63129b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35a065f5-a6e0-4202-ae31-3f380a63129b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35a065f5-a6e0-4202-ae31-3f380a63129b">
											<gml:posList>35.670534678083605 139.74368363687276 44.12 35.67053385660938 139.74368199189541 44.12 35.670501878205016 139.7436729917984 44.12 35.670500499870286 139.74367402064343 44.12 35.670534678083605 139.74368363687276 44.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a60f7f5e-5525-49dd-ae6b-cc6144e61ae2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a60f7f5e-5525-49dd-ae6b-cc6144e61ae2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a60f7f5e-5525-49dd-ae6b-cc6144e61ae2">
											<gml:posList>35.67053385660938 139.74368199189541 43.673 35.670540853663454 139.7436489004573 43.673 35.67050908174949 139.7436387955139 43.673 35.670501878205016 139.7436729917984 43.673 35.67053385660938 139.74368199189541 43.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-91654baf-b54b-433c-a4a9-d27329c3c582">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91654baf-b54b-433c-a4a9-d27329c3c582">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91654baf-b54b-433c-a4a9-d27329c3c582">
											<gml:posList>35.670508269247236 139.74363709529612 44.12 35.67050908174949 139.7436387955139 44.12 35.670540853663454 139.7436489004573 44.12 35.67054224102814 139.74364789369372 44.12 35.670508269247236 139.74363709529612 44.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-143cd9ff-5b61-4c83-a74a-fee734dad81e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-143cd9ff-5b61-4c83-a74a-fee734dad81e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-143cd9ff-5b61-4c83-a74a-fee734dad81e">
											<gml:posList>35.67050661105951 139.74363755004856 38.604 35.670508080641994 139.74363801234816 38.604 35.670508269247236 139.74363709529612 38.604 35.67054224102814 139.74364789369372 38.604 35.67053507330575 139.74368178065563 38.604 35.67053652486062 139.74368224297635 38.604 35.670575093685535 139.74369310253493 38.604 35.6705899436353 139.74361420438493 38.604 35.67048427152606 139.7435844535081 38.604 35.67047591284731 139.74362887992814 38.604 35.67050661105951 139.74363755004856 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02c20b33-85c4-4205-8e30-1db8fec18095">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02c20b33-85c4-4205-8e30-1db8fec18095">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02c20b33-85c4-4205-8e30-1db8fec18095">
											<gml:posList>35.67053507330575 139.74368178065563 39.1 35.670534678083605 139.74368363687276 39.1 35.67053652486062 139.74368224297635 39.1 35.67053507330575 139.74368178065563 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89445225-4ba0-4052-b4e8-5480b6cfed74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89445225-4ba0-4052-b4e8-5480b6cfed74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89445225-4ba0-4052-b4e8-5480b6cfed74">
											<gml:posList>35.67048313413378 139.74358222343395 39.1 35.67048427152606 139.7435844535081 39.1 35.6705899436353 139.74361420438493 39.1 35.67059177238405 139.74361281050614 39.1 35.67048313413378 139.74358222343395 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f55101f5-f9ab-41f4-b8b0-922a7bd25adb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f55101f5-f9ab-41f4-b8b0-922a7bd25adb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f55101f5-f9ab-41f4-b8b0-922a7bd25adb">
											<gml:posList>35.67054224102814 139.74364789369372 44.12 35.670540853663454 139.7436489004573 44.12 35.67053385660938 139.74368199189541 44.12 35.670534678083605 139.74368363687276 44.12 35.67054224102814 139.74364789369372 44.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-510a1f12-40bd-4bf1-83c7-d566c7dc24b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-510a1f12-40bd-4bf1-83c7-d566c7dc24b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-510a1f12-40bd-4bf1-83c7-d566c7dc24b2">
											<gml:posList>35.6705762400977 139.74369534364942 39.1 35.670575093685535 139.74369310253493 39.1 35.67053652486062 139.74368224297635 39.1 35.670534678083605 139.74368363687276 39.1 35.6705762400977 139.74369534364942 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c3a70da-d9ca-43ff-a408-26b1f63d2e66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c3a70da-d9ca-43ff-a408-26b1f63d2e66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c3a70da-d9ca-43ff-a408-26b1f63d2e66">
											<gml:posList>35.67059177238405 139.74361281050614 39.1 35.6705899436353 139.74361420438493 39.1 35.670575093685535 139.74369310253493 39.1 35.6705762400977 139.74369534364942 39.1 35.67059177238405 139.74361281050614 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd5c9003-03e7-43c2-bf25-db538be066f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd5c9003-03e7-43c2-bf25-db538be066f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd5c9003-03e7-43c2-bf25-db538be066f5">
											<gml:posList>35.67059177238405 139.74361281050614 7.35 35.67048313413378 139.74358222343395 7.35 35.67048313413378 139.74358222343395 39.1 35.67059177238405 139.74361281050614 39.1 35.67059177238405 139.74361281050614 7.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cb44e34-79b5-42cb-bef2-5a1ba464e3e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cb44e34-79b5-42cb-bef2-5a1ba464e3e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cb44e34-79b5-42cb-bef2-5a1ba464e3e6">
											<gml:posList>35.67048427152606 139.7435844535081 39.1 35.67048427152606 139.7435844535081 38.604 35.6705899436353 139.74361420438493 38.604 35.6705899436353 139.74361420438493 39.1 35.67048427152606 139.7435844535081 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8654817-402a-49a5-998d-33789e58d864">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8654817-402a-49a5-998d-33789e58d864">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8654817-402a-49a5-998d-33789e58d864">
											<gml:posList>35.67048313413378 139.74358222343395 7.35 35.67047409311206 139.74363027379448 7.35 35.67047409311206 139.74363027379448 39.1 35.67048313413378 139.74358222343395 39.1 35.67048313413378 139.74358222343395 7.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85bed3cf-3746-4025-9782-fa0398ad6878">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85bed3cf-3746-4025-9782-fa0398ad6878">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85bed3cf-3746-4025-9782-fa0398ad6878">
											<gml:posList>35.67047591284731 139.74362887992814 39.1 35.67047591284731 139.74362887992814 38.604 35.67048427152606 139.7435844535081 38.604 35.67048427152606 139.7435844535081 39.1 35.67047591284731 139.74362887992814 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93d7a32b-18ce-48c0-ba3c-b31df66ec0b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93d7a32b-18ce-48c0-ba3c-b31df66ec0b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93d7a32b-18ce-48c0-ba3c-b31df66ec0b2">
											<gml:posList>35.67050661105951 139.74363755004856 39.1 35.67050661105951 139.74363755004856 38.604 35.67047591284731 139.74362887992814 38.604 35.67047591284731 139.74362887992814 39.1 35.67050661105951 139.74363755004856 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf4145e1-6023-46cb-a526-d58f684db463">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf4145e1-6023-46cb-a526-d58f684db463">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf4145e1-6023-46cb-a526-d58f684db463">
											<gml:posList>35.67047409311206 139.74363027379448 7.35 35.67050771238764 139.74363976911823 7.35 35.67050771238764 139.74363976911823 39.1 35.67047409311206 139.74363027379448 39.1 35.67047409311206 139.74363027379448 7.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffec49a0-e743-4cbd-9eb8-593505ad4968">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffec49a0-e743-4cbd-9eb8-593505ad4968">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffec49a0-e743-4cbd-9eb8-593505ad4968">
											<gml:posList>35.670508080641994 139.74363801234816 39.1 35.670508080641994 139.74363801234816 38.604 35.67050661105951 139.74363755004856 38.604 35.67050661105951 139.74363755004856 39.1 35.670508080641994 139.74363801234816 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2eb5eaba-cff6-482b-a098-c681ba237267">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eb5eaba-cff6-482b-a098-c681ba237267">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eb5eaba-cff6-482b-a098-c681ba237267">
											<gml:posList>35.670508269247236 139.74363709529612 44.12 35.67054224102814 139.74364789369372 44.12 35.67054224102814 139.74364789369372 38.604 35.670508269247236 139.74363709529612 38.604 35.670508269247236 139.74363709529612 44.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccc992aa-f566-4cf2-95c1-5020f3cb6fc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccc992aa-f566-4cf2-95c1-5020f3cb6fc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccc992aa-f566-4cf2-95c1-5020f3cb6fc1">
											<gml:posList>35.67050908174949 139.7436387955139 44.12 35.67050908174949 139.7436387955139 43.673 35.670540853663454 139.7436489004573 43.673 35.670540853663454 139.7436489004573 44.12 35.67050908174949 139.7436387955139 44.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09b02a52-1507-4887-adc3-808972967b37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09b02a52-1507-4887-adc3-808972967b37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09b02a52-1507-4887-adc3-808972967b37">
											<gml:posList>35.6705899436353 139.74361420438493 39.1 35.6705899436353 139.74361420438493 38.604 35.670575093685535 139.74369310253493 38.604 35.670575093685535 139.74369310253493 39.1 35.6705899436353 139.74361420438493 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72f69af7-0d5e-4e95-8b4e-3ea631b73baf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72f69af7-0d5e-4e95-8b4e-3ea631b73baf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72f69af7-0d5e-4e95-8b4e-3ea631b73baf">
											<gml:posList>35.6705762400977 139.74369534364942 7.35 35.67059177238405 139.74361281050614 7.35 35.67059177238405 139.74361281050614 39.1 35.6705762400977 139.74369534364942 39.1 35.6705762400977 139.74369534364942 7.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab046e23-61f0-4b7f-b5a6-f1a054e964ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab046e23-61f0-4b7f-b5a6-f1a054e964ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab046e23-61f0-4b7f-b5a6-f1a054e964ea">
											<gml:posList>35.67050771238764 139.74363976911823 39.1 35.67050771238764 139.74363976911823 7.35 35.670500499870286 139.74367402064343 7.35 35.670500499870286 139.74367402064343 44.12 35.670508269247236 139.74363709529612 44.12 35.670508269247236 139.74363709529612 38.604 35.670508080641994 139.74363801234816 38.604 35.670508080641994 139.74363801234816 39.1 35.67050771238764 139.74363976911823 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b026e558-6308-452d-a762-614d9ce67549">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b026e558-6308-452d-a762-614d9ce67549">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b026e558-6308-452d-a762-614d9ce67549">
											<gml:posList>35.670501878205016 139.7436729917984 44.12 35.670501878205016 139.7436729917984 43.673 35.67050908174949 139.7436387955139 43.673 35.67050908174949 139.7436387955139 44.12 35.670501878205016 139.7436729917984 44.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a3cf18e-08f8-48d2-99f1-e36b717b3896">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a3cf18e-08f8-48d2-99f1-e36b717b3896">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a3cf18e-08f8-48d2-99f1-e36b717b3896">
											<gml:posList>35.670540853663454 139.7436489004573 44.12 35.670540853663454 139.7436489004573 43.673 35.67053385660938 139.74368199189541 43.673 35.67053385660938 139.74368199189541 44.12 35.670540853663454 139.7436489004573 44.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0785d10c-6f88-4b28-b9ed-e224f8d28bf7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0785d10c-6f88-4b28-b9ed-e224f8d28bf7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0785d10c-6f88-4b28-b9ed-e224f8d28bf7">
											<gml:posList>35.67054224102814 139.74364789369372 38.604 35.67054224102814 139.74364789369372 44.12 35.670534678083605 139.74368363687276 44.12 35.670534678083605 139.74368363687276 39.1 35.67053507330575 139.74368178065563 39.1 35.67053507330575 139.74368178065563 38.604 35.67054224102814 139.74364789369372 38.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ededea3-acb4-41e0-a9f1-dfc19bb73dea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ededea3-acb4-41e0-a9f1-dfc19bb73dea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ededea3-acb4-41e0-a9f1-dfc19bb73dea">
											<gml:posList>35.67053385660938 139.74368199189541 44.12 35.67053385660938 139.74368199189541 43.673 35.670501878205016 139.7436729917984 43.673 35.670501878205016 139.7436729917984 44.12 35.67053385660938 139.74368199189541 44.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7055643c-c205-4fdc-a350-3e3067299f54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7055643c-c205-4fdc-a350-3e3067299f54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7055643c-c205-4fdc-a350-3e3067299f54">
											<gml:posList>35.67053652486062 139.74368224297635 39.1 35.67053652486062 139.74368224297635 38.604 35.67053507330575 139.74368178065563 38.604 35.67053507330575 139.74368178065563 39.1 35.67053652486062 139.74368224297635 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd52111e-d647-406f-a43f-4c4013b0f87c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd52111e-d647-406f-a43f-4c4013b0f87c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd52111e-d647-406f-a43f-4c4013b0f87c">
											<gml:posList>35.6705762400977 139.74369534364942 7.35 35.6705762400977 139.74369534364942 39.1 35.670534678083605 139.74368363687276 39.1 35.670534678083605 139.74368363687276 44.12 35.670500499870286 139.74367402064343 44.12 35.670500499870286 139.74367402064343 7.35 35.6705762400977 139.74369534364942 7.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4c6086b-90b0-4dcc-b91e-1f10aec3d2c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4c6086b-90b0-4dcc-b91e-1f10aec3d2c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4c6086b-90b0-4dcc-b91e-1f10aec3d2c2">
											<gml:posList>35.670575093685535 139.74369310253493 39.1 35.670575093685535 139.74369310253493 38.604 35.67053652486062 139.74368224297635 38.604 35.67053652486062 139.74368224297635 39.1 35.670575093685535 139.74369310253493 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6919</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">94.8229</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.47</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>