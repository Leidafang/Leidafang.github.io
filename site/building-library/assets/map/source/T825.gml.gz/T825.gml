<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ea6296fe-8d13-4b6f-bcd5-fdb0dba6ceec">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">9.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66884800865163 139.7394006942607 0 35.668850002268826 139.73941427856488 0 35.66890024807748 139.73946470018416 0 35.668947781880036 139.73938942085425 0 35.668890772211554 139.73933447829918 0 35.66884800865163 139.7394006942607 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884800865163 139.7394006942607 11.72 35.668890772211554 139.73933447829918 11.72 35.668947781880036 139.73938942085425 11.72 35.66890024807748 139.73946470018416 11.72 35.668850002268826 139.73941427856488 11.72 35.66884800865163 139.7394006942607 11.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884800865163 139.7394006942607 11.72 35.668850002268826 139.73941427856488 11.72 35.668850002268826 139.73941427856488 20.93 35.66884800865163 139.7394006942607 20.93 35.66884800865163 139.7394006942607 11.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668850002268826 139.73941427856488 11.72 35.66890024807748 139.73946470018416 11.72 35.66890024807748 139.73946470018416 20.93 35.668850002268826 139.73941427856488 20.93 35.668850002268826 139.73941427856488 11.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890024807748 139.73946470018416 11.72 35.668947781880036 139.73938942085425 11.72 35.668947781880036 139.73938942085425 20.93 35.66890024807748 139.73946470018416 20.93 35.66890024807748 139.73946470018416 11.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668947781880036 139.73938942085425 11.72 35.668890772211554 139.73933447829918 11.72 35.668890772211554 139.73933447829918 20.93 35.668947781880036 139.73938942085425 20.93 35.668947781880036 139.73938942085425 11.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668890772211554 139.73933447829918 11.72 35.66884800865163 139.7394006942607 11.72 35.66884800865163 139.7394006942607 20.93 35.668890772211554 139.73933447829918 20.93 35.668890772211554 139.73933447829918 11.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884800865163 139.7394006942607 20.93 35.668850002268826 139.73941427856488 20.93 35.66890024807748 139.73946470018416 20.93 35.668947781880036 139.73938942085425 20.93 35.668890772211554 139.73933447829918 20.93 35.66884800865163 139.7394006942607 20.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ac31eab8-4b94-4f04-b407-1f0799e96b84"/>
							<gml:surfaceMember xlink:href="#poly-c40e4789-67e3-4155-a413-9d479fa1577b"/>
							<gml:surfaceMember xlink:href="#poly-a4bfa643-9c2d-4681-9d7c-73ccbadabaab"/>
							<gml:surfaceMember xlink:href="#poly-744bb1c9-c24d-4ec8-83fa-3b4bfc89a75c"/>
							<gml:surfaceMember xlink:href="#poly-8478728f-0c88-4566-8d6c-f5a255c09419"/>
							<gml:surfaceMember xlink:href="#poly-176611cc-436d-4700-93cf-0cf35ce5fdb3"/>
							<gml:surfaceMember xlink:href="#poly-cc6b545c-6dac-483c-9536-0b9729ab5a71"/>
							<gml:surfaceMember xlink:href="#poly-22685521-026c-45cc-b8fb-c69aa9ed0620"/>
							<gml:surfaceMember xlink:href="#poly-a539d155-d390-40a7-8635-3b0822cb19ac"/>
							<gml:surfaceMember xlink:href="#poly-4ce58bbf-5d57-445d-8081-1acd3e2a8b61"/>
							<gml:surfaceMember xlink:href="#poly-f0ac8c0c-8913-4f29-b20e-86f2eb5705cb"/>
							<gml:surfaceMember xlink:href="#poly-6cb77a08-173c-44a6-8f75-a60f624ec158"/>
							<gml:surfaceMember xlink:href="#poly-66cde7f9-6e35-4658-94fd-e359c20ac35e"/>
							<gml:surfaceMember xlink:href="#poly-d335b139-7da6-4020-ab02-140336a6279a"/>
							<gml:surfaceMember xlink:href="#poly-9f41f6a3-b654-4ad6-8ff5-0cdfa04fe6ed"/>
							<gml:surfaceMember xlink:href="#poly-7b67d1b6-e626-4998-9f92-baa72f452d54"/>
							<gml:surfaceMember xlink:href="#poly-27ba0681-aeb2-4565-8372-fac7378b08ca"/>
							<gml:surfaceMember xlink:href="#poly-fc880d89-6012-4c15-8800-69c7d08d58ca"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ac31eab8-4b94-4f04-b407-1f0799e96b84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac31eab8-4b94-4f04-b407-1f0799e96b84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac31eab8-4b94-4f04-b407-1f0799e96b84">
											<gml:posList>35.668848008651594 139.7394006942607 11.72 35.668890772211526 139.73933447829918 11.72 35.668947781880014 139.73938942085425 11.72 35.66890024807746 139.73946470018416 11.72 35.66885000226881 139.73941427856488 11.72 35.668848008651594 139.7394006942607 11.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c40e4789-67e3-4155-a413-9d479fa1577b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c40e4789-67e3-4155-a413-9d479fa1577b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c40e4789-67e3-4155-a413-9d479fa1577b">
											<gml:posList>35.6688987553763 139.73934217908692 21.138 35.668899091539664 139.73934558087788 21.138 35.66894502400776 139.73938984383582 21.138 35.668947781880014 139.73938942085425 21.138 35.6688987553763 139.73934217908692 21.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4bfa643-9c2d-4681-9d7c-73ccbadabaab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4bfa643-9c2d-4681-9d7c-73ccbadabaab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4bfa643-9c2d-4681-9d7c-73ccbadabaab">
											<gml:posList>35.66885881901991 139.73940441516123 21.138 35.6688987553763 139.73934217908692 21.138 35.668890772211526 139.73933447829918 18.449 35.668848008651594 139.7394006942607 18.449 35.66885881901991 139.73940441516123 21.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-744bb1c9-c24d-4ec8-83fa-3b4bfc89a75c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-744bb1c9-c24d-4ec8-83fa-3b4bfc89a75c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-744bb1c9-c24d-4ec8-83fa-3b4bfc89a75c">
											<gml:posList>35.66885881901991 139.73940441516123 21.138 35.66886156791299 139.73940403637536 21.138 35.668899091539664 139.73934558087788 21.138 35.6688987553763 139.73934217908692 21.138 35.66885881901991 139.73940441516123 21.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8478728f-0c88-4566-8d6c-f5a255c09419">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8478728f-0c88-4566-8d6c-f5a255c09419">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8478728f-0c88-4566-8d6c-f5a255c09419">
											<gml:posList>35.66894502400776 139.73938984383582 20.862 35.668899091539664 139.73934558087788 20.862 35.66886156791299 139.73940403637536 20.862 35.66890713200292 139.73944984622537 20.862 35.66894502400776 139.73938984383582 20.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-176611cc-436d-4700-93cf-0cf35ce5fdb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-176611cc-436d-4700-93cf-0cf35ce5fdb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-176611cc-436d-4700-93cf-0cf35ce5fdb3">
											<gml:posList>35.66885881901991 139.73940441516123 21.138 35.668848008651594 139.7394006942607 18.449 35.66885000226881 139.73941427856488 18.449 35.66885881901991 139.73940441516123 21.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc6b545c-6dac-483c-9536-0b9729ab5a71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc6b545c-6dac-483c-9536-0b9729ab5a71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc6b545c-6dac-483c-9536-0b9729ab5a71">
											<gml:posList>35.668947781880014 139.73938942085425 21.138 35.66894502400776 139.73938984383582 21.138 35.66890713200292 139.73944984622537 21.138 35.668907450170245 139.73945329222246 21.138 35.668947781880014 139.73938942085425 21.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22685521-026c-45cc-b8fb-c69aa9ed0620">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22685521-026c-45cc-b8fb-c69aa9ed0620">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22685521-026c-45cc-b8fb-c69aa9ed0620">
											<gml:posList>35.668907450170245 139.73945329222246 21.138 35.66890713200292 139.73944984622537 21.138 35.66886156791299 139.73940403637536 21.138 35.66885881901991 139.73940441516123 21.138 35.668907450170245 139.73945329222246 21.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a539d155-d390-40a7-8635-3b0822cb19ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a539d155-d390-40a7-8635-3b0822cb19ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a539d155-d390-40a7-8635-3b0822cb19ac">
											<gml:posList>35.66890024807746 139.73946470018416 18.449 35.668907450170245 139.73945329222246 21.138 35.66885881901991 139.73940441516123 21.138 35.66885000226881 139.73941427856488 18.449 35.66890024807746 139.73946470018416 18.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ce58bbf-5d57-445d-8081-1acd3e2a8b61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ce58bbf-5d57-445d-8081-1acd3e2a8b61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ce58bbf-5d57-445d-8081-1acd3e2a8b61">
											<gml:posList>35.66886156791299 139.73940403637536 21.138 35.66886156791299 139.73940403637536 20.862 35.668899091539664 139.73934558087788 20.862 35.668899091539664 139.73934558087788 21.138 35.66886156791299 139.73940403637536 21.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0ac8c0c-8913-4f29-b20e-86f2eb5705cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0ac8c0c-8913-4f29-b20e-86f2eb5705cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0ac8c0c-8913-4f29-b20e-86f2eb5705cb">
											<gml:posList>35.668890772211526 139.73933447829918 18.449 35.6688987553763 139.73934217908692 21.138 35.668947781880014 139.73938942085425 21.138 35.668947781880014 139.73938942085425 11.72 35.668890772211526 139.73933447829918 11.72 35.668890772211526 139.73933447829918 18.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6cb77a08-173c-44a6-8f75-a60f624ec158">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cb77a08-173c-44a6-8f75-a60f624ec158">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cb77a08-173c-44a6-8f75-a60f624ec158">
											<gml:posList>35.668890772211526 139.73933447829918 11.72 35.668848008651594 139.7394006942607 11.72 35.668848008651594 139.7394006942607 18.449 35.668890772211526 139.73933447829918 18.449 35.668890772211526 139.73933447829918 11.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66cde7f9-6e35-4658-94fd-e359c20ac35e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66cde7f9-6e35-4658-94fd-e359c20ac35e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66cde7f9-6e35-4658-94fd-e359c20ac35e">
											<gml:posList>35.668899091539664 139.73934558087788 21.138 35.668899091539664 139.73934558087788 20.862 35.66894502400776 139.73938984383582 20.862 35.66894502400776 139.73938984383582 21.138 35.668899091539664 139.73934558087788 21.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d335b139-7da6-4020-ab02-140336a6279a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d335b139-7da6-4020-ab02-140336a6279a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d335b139-7da6-4020-ab02-140336a6279a">
											<gml:posList>35.668848008651594 139.7394006942607 11.72 35.66885000226881 139.73941427856488 11.72 35.66885000226881 139.73941427856488 18.449 35.668848008651594 139.7394006942607 18.449 35.668848008651594 139.7394006942607 11.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f41f6a3-b654-4ad6-8ff5-0cdfa04fe6ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f41f6a3-b654-4ad6-8ff5-0cdfa04fe6ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f41f6a3-b654-4ad6-8ff5-0cdfa04fe6ed">
											<gml:posList>35.66894502400776 139.73938984383582 21.138 35.66894502400776 139.73938984383582 20.862 35.66890713200292 139.73944984622537 20.862 35.66890713200292 139.73944984622537 21.138 35.66894502400776 139.73938984383582 21.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b67d1b6-e626-4998-9f92-baa72f452d54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b67d1b6-e626-4998-9f92-baa72f452d54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b67d1b6-e626-4998-9f92-baa72f452d54">
											<gml:posList>35.66890713200292 139.73944984622537 21.138 35.66890713200292 139.73944984622537 20.862 35.66886156791299 139.73940403637536 20.862 35.66886156791299 139.73940403637536 21.138 35.66890713200292 139.73944984622537 21.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27ba0681-aeb2-4565-8372-fac7378b08ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27ba0681-aeb2-4565-8372-fac7378b08ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27ba0681-aeb2-4565-8372-fac7378b08ca">
											<gml:posList>35.668947781880014 139.73938942085425 21.138 35.668907450170245 139.73945329222246 21.138 35.66890024807746 139.73946470018416 18.449 35.66890024807746 139.73946470018416 11.72 35.668947781880014 139.73938942085425 11.72 35.668947781880014 139.73938942085425 21.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc880d89-6012-4c15-8800-69c7d08d58ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc880d89-6012-4c15-8800-69c7d08d58ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc880d89-6012-4c15-8800-69c7d08d58ca">
											<gml:posList>35.66885000226881 139.73941427856488 11.72 35.66890024807746 139.73946470018416 11.72 35.66890024807746 139.73946470018416 18.449 35.66885000226881 139.73941427856488 18.449 35.66885000226881 139.73941427856488 11.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3225</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">68.7057</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>