<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ecd82ff9-13ce-4a5a-9c73-f5149b219f44">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">32.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669276617416976 139.7477142439415 0 35.66924844026199 139.74770125067286 0 35.66925986236327 139.74766562582914 0 35.66921110839681 139.74764213868218 0 35.66917208433195 139.7477638089258 0 35.66924885353483 139.74780079772333 0 35.669276617416976 139.7477142439415 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669276617416976 139.7477142439415 5.87 35.66924885353483 139.74780079772333 5.87 35.66917208433195 139.7477638089258 5.87 35.66921110839681 139.74764213868218 5.87 35.66925986236327 139.74766562582914 5.87 35.66924844026199 139.74770125067286 5.87 35.669276617416976 139.7477142439415 5.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669276617416976 139.7477142439415 5.87 35.66924844026199 139.74770125067286 5.87 35.66924844026199 139.74770125067286 38.6 35.669276617416976 139.7477142439415 38.6 35.669276617416976 139.7477142439415 5.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924844026199 139.74770125067286 5.87 35.66925986236327 139.74766562582914 5.87 35.66925986236327 139.74766562582914 38.6 35.66924844026199 139.74770125067286 38.6 35.66924844026199 139.74770125067286 5.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925986236327 139.74766562582914 5.87 35.66921110839681 139.74764213868218 5.87 35.66921110839681 139.74764213868218 38.6 35.66925986236327 139.74766562582914 38.6 35.66925986236327 139.74766562582914 5.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66921110839681 139.74764213868218 5.87 35.66917208433195 139.7477638089258 5.87 35.66917208433195 139.7477638089258 38.6 35.66921110839681 139.74764213868218 38.6 35.66921110839681 139.74764213868218 5.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917208433195 139.7477638089258 5.87 35.66924885353483 139.74780079772333 5.87 35.66924885353483 139.74780079772333 38.6 35.66917208433195 139.7477638089258 38.6 35.66917208433195 139.7477638089258 5.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924885353483 139.74780079772333 5.87 35.669276617416976 139.7477142439415 5.87 35.669276617416976 139.7477142439415 38.6 35.66924885353483 139.74780079772333 38.6 35.66924885353483 139.74780079772333 5.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669276617416976 139.7477142439415 38.6 35.66924844026199 139.74770125067286 38.6 35.66925986236327 139.74766562582914 38.6 35.66921110839681 139.74764213868218 38.6 35.66917208433195 139.7477638089258 38.6 35.66924885353483 139.74780079772333 38.6 35.669276617416976 139.7477142439415 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3dfff632-47cf-4c99-b02b-528c6d2f3651"/>
							<gml:surfaceMember xlink:href="#poly-cdaeadf0-59c6-4748-9c1c-0bc7a8a88293"/>
							<gml:surfaceMember xlink:href="#poly-c5c0f8b0-1276-49ac-ade2-93fe6e63d10b"/>
							<gml:surfaceMember xlink:href="#poly-7361c716-ea13-4ddb-8629-ca39fc4332d0"/>
							<gml:surfaceMember xlink:href="#poly-9df6c94d-eb4c-4149-a9f4-f98b3ca4dd2e"/>
							<gml:surfaceMember xlink:href="#poly-b01a4031-4a9f-4b26-a41e-6cc1b75a7ed9"/>
							<gml:surfaceMember xlink:href="#poly-f186b503-2509-4c50-abd7-c20a57ef210c"/>
							<gml:surfaceMember xlink:href="#poly-b671b6c8-6bf5-4f40-8d44-ba62af030385"/>
							<gml:surfaceMember xlink:href="#poly-3650f754-8fd9-43f3-ad9a-c0792e3543a9"/>
							<gml:surfaceMember xlink:href="#poly-9eb7989c-cacf-4d2d-bc10-c71296c6dd96"/>
							<gml:surfaceMember xlink:href="#poly-511adb22-bf10-4c0d-99df-5aa33f3ddbe7"/>
							<gml:surfaceMember xlink:href="#poly-88b6ca3c-ef57-48d6-a35c-5853d04d5abe"/>
							<gml:surfaceMember xlink:href="#poly-9d3356b7-c117-4a54-ad12-a75486e02cf6"/>
							<gml:surfaceMember xlink:href="#poly-9a3305db-bf43-4d25-a7c1-1a4f718bc049"/>
							<gml:surfaceMember xlink:href="#poly-56fc06e5-7239-4a55-abf8-62018e188f4e"/>
							<gml:surfaceMember xlink:href="#poly-6cf840be-9eee-499e-a6a5-9a2a21b7e4a5"/>
							<gml:surfaceMember xlink:href="#poly-b5dc184d-27f4-4d93-acba-50dbf90c4ee1"/>
							<gml:surfaceMember xlink:href="#poly-17bd0d0e-504e-4efc-96e8-c5aef1c5016c"/>
							<gml:surfaceMember xlink:href="#poly-8512dbe1-2066-41a3-89db-26bf99760ffc"/>
							<gml:surfaceMember xlink:href="#poly-c3bc04d4-a71c-4ccb-8934-e358300bd10f"/>
							<gml:surfaceMember xlink:href="#poly-aab19e15-32e7-42b4-83f3-01fbb7ff8817"/>
							<gml:surfaceMember xlink:href="#poly-d13f96c9-3e4b-4017-9f8e-f2f3625c3fc5"/>
							<gml:surfaceMember xlink:href="#poly-000d43e2-ee14-4482-9712-b48894654639"/>
							<gml:surfaceMember xlink:href="#poly-b67afd93-ac05-43cc-af97-b084e5eac9b1"/>
							<gml:surfaceMember xlink:href="#poly-a12aaabf-60b4-41dd-935e-f8fda5f9b1f9"/>
							<gml:surfaceMember xlink:href="#poly-d2f085b3-3c4e-4481-b252-8b6956638718"/>
							<gml:surfaceMember xlink:href="#poly-b25ec6be-f09b-4a01-bedc-2f1bea244f88"/>
							<gml:surfaceMember xlink:href="#poly-1590cd95-2429-4450-a20f-9be28ef81d0f"/>
							<gml:surfaceMember xlink:href="#poly-5c8e3fe7-c3da-4697-8be8-f89262152dc2"/>
							<gml:surfaceMember xlink:href="#poly-8c32ed11-daef-4bf9-abc0-d43230844768"/>
							<gml:surfaceMember xlink:href="#poly-3e695931-07ec-4812-ae00-845c39d74d4e"/>
							<gml:surfaceMember xlink:href="#poly-9d6ecc31-3ad2-485f-af48-2d223719a7c0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ecd82ff9-13ce-4a5a-9c73-f5149b219f44_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c7e7692-d116-4e22-b728-db29e82b61d3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922835815481 139.74771461581082 37.497 35.669211316085736 139.74770601805136 37.497 35.669222766321994 139.74767192860273 37.497 35.66923979937974 139.7476805263658 37.497 35.66922835815481 139.74771461581082 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc3f806c-449a-4463-9b83-25767275b499">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc3f806c-449a-4463-9b83-25767275b499_0">
											<gml:posList>35.669211316085736 139.74770601805136 37.497 35.669211316085736 139.74770601805136 40.873 35.669222766321994 139.74767192860273 40.873 35.669222766321994 139.74767192860273 37.497 35.669211316085736 139.74770601805136 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9dc1ff33-d25f-4791-9fab-ff8cf99261ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9dc1ff33-d25f-4791-9fab-ff8cf99261ea_0">
											<gml:posList>35.66922835815481 139.74771461581082 37.497 35.66922835815481 139.74771461581082 40.873 35.669211316085736 139.74770601805136 40.873 35.669211316085736 139.74770601805136 37.497 35.66922835815481 139.74771461581082 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76b5a9a8-2037-490d-b69f-4d622fa84437">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76b5a9a8-2037-490d-b69f-4d622fa84437_0">
											<gml:posList>35.66922835815481 139.74771461581082 40.873 35.66923979937974 139.7476805263658 40.873 35.669222766321994 139.74767192860273 40.873 35.669211316085736 139.74770601805136 40.873 35.66922835815481 139.74771461581082 40.873</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2a5c82d-5c59-4df1-b103-c88541a18f6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2a5c82d-5c59-4df1-b103-c88541a18f6d_0">
											<gml:posList>35.669222766321994 139.74767192860273 40.873 35.66923979937974 139.7476805263658 40.873 35.66923979937974 139.7476805263658 37.497 35.669222766321994 139.74767192860273 37.497 35.669222766321994 139.74767192860273 40.873</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d935bb4-fd31-47a5-af03-403b2492c50a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d935bb4-fd31-47a5-af03-403b2492c50a_0">
											<gml:posList>35.66923979937974 139.7476805263658 37.497 35.66923979937974 139.7476805263658 40.873 35.66922835815481 139.74771461581082 40.873 35.66922835815481 139.74771461581082 37.497 35.66923979937974 139.7476805263658 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ecd82ff9-13ce-4a5a-9c73-f5149b219f44_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1275cae-5dd4-4992-a8c8-3b2319b6ac6b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669247517715874 139.74777290773545 37.497 35.66923206468501 139.74778067858884 37.497 35.66919533004128 139.74776281206138 37.497 35.66918821985419 139.74773976644727 37.497 35.66921251259165 139.7476647375006 37.497 35.66922737131427 139.74765781781161 37.497 35.66925471048824 139.7476712206627 37.497 35.66925415287879 139.74767296654304 37.497 35.66922831050226 139.74766029113476 37.497 35.66921447031484 139.74766718764297 37.497 35.66919079814894 139.74774028286143 37.497 35.66919694177917 139.747760391246 37.497 35.66923212575627 139.74777782862935 37.497 35.66924654230261 139.7477701914347 37.497 35.66926515110904 139.747713063206 37.497 35.66926676509225 139.74771380157165 37.497 35.669247517715874 139.74777290773545 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a11f929d-a677-491c-824c-1c77e3acdf73">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925415287879 139.74767296654304 38.6 35.66925471048824 139.7476712206627 38.6 35.66925712701552 139.74767241106036 38.6 35.66925656940605 139.74767415694072 38.6 35.66925415287879 139.74767296654304 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90473de9-4ac0-4954-8d95-c581db5f6ed4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66926676509225 139.74771380157165 38.6 35.66926515110904 139.747713063206 38.6 35.669266203429366 139.74770984766525 38.6 35.6692678174126 139.74771058603085 38.6 35.66926676509225 139.74771380157165 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4221c099-9344-4172-b8d9-a4e2e73b4df5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4221c099-9344-4172-b8d9-a4e2e73b4df5_0">
											<gml:posList>35.66921251259165 139.7476647375006 40.096 35.66922737131427 139.74765781781161 40.096 35.66922737131427 139.74765781781161 37.497 35.66921251259165 139.7476647375006 37.497 35.66921251259165 139.7476647375006 40.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7976d8c4-0b0a-485b-9e08-d141f997dd57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7976d8c4-0b0a-485b-9e08-d141f997dd57_0">
											<gml:posList>35.66922831050226 139.74766029113476 37.497 35.66922831050226 139.74766029113476 40.096 35.66921447031484 139.74766718764297 40.096 35.66921447031484 139.74766718764297 37.497 35.66922831050226 139.74766029113476 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4383b1bb-f4f1-4482-86a0-fe604170bccd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4383b1bb-f4f1-4482-86a0-fe604170bccd_0">
											<gml:posList>35.66925471048824 139.7476712206627 38.6 35.66925471048824 139.7476712206627 37.497 35.66922737131427 139.74765781781161 37.497 35.66922737131427 139.74765781781161 40.096 35.66925712701552 139.74767241106036 40.096 35.66925712701552 139.74767241106036 38.6 35.66925471048824 139.7476712206627 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faad78e1-eb69-4bf2-a124-db28f25fcd70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-faad78e1-eb69-4bf2-a124-db28f25fcd70_0">
											<gml:posList>35.66925656940605 139.74767415694072 40.096 35.66922831050226 139.74766029113476 40.096 35.66922831050226 139.74766029113476 37.497 35.66925415287879 139.74767296654304 37.497 35.66925415287879 139.74767296654304 38.6 35.66925656940605 139.74767415694072 38.6 35.66925656940605 139.74767415694072 40.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10206115-4836-4127-ad03-26a655d43210">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10206115-4836-4127-ad03-26a655d43210_0">
											<gml:posList>35.66925415287879 139.74767296654304 37.497 35.66925471048824 139.7476712206627 37.497 35.66925471048824 139.7476712206627 38.6 35.66925415287879 139.74767296654304 38.6 35.66925415287879 139.74767296654304 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09333e00-f19b-4b9a-929d-8f9ecd39c4cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09333e00-f19b-4b9a-929d-8f9ecd39c4cd_0">
											<gml:posList>35.66925712701552 139.74767241106036 38.6 35.66925712701552 139.74767241106036 40.096 35.66925656940605 139.74767415694072 40.096 35.66925656940605 139.74767415694072 38.6 35.66925712701552 139.74767241106036 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e193e497-73b5-4eea-9f64-6668b8a5efe1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e193e497-73b5-4eea-9f64-6668b8a5efe1_0">
											<gml:posList>35.66918821985419 139.74773976644727 40.096 35.66921251259165 139.7476647375006 40.096 35.66921251259165 139.7476647375006 37.497 35.66918821985419 139.74773976644727 37.497 35.66918821985419 139.74773976644727 40.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d1a0ac5-6a34-4782-af06-7d99652ca04b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d1a0ac5-6a34-4782-af06-7d99652ca04b_0">
											<gml:posList>35.66921447031484 139.74766718764297 40.096 35.66919079814894 139.74774028286143 40.096 35.66919079814894 139.74774028286143 37.497 35.66921447031484 139.74766718764297 37.497 35.66921447031484 139.74766718764297 40.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5524d14f-8546-4e87-b7cf-3d362d836e94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5524d14f-8546-4e87-b7cf-3d362d836e94_0">
											<gml:posList>35.669266203429366 139.74770984766525 38.6 35.669266203429366 139.74770984766525 40.096 35.6692678174126 139.74771058603085 40.096 35.6692678174126 139.74771058603085 38.6 35.669266203429366 139.74770984766525 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b07199c4-746e-4d8b-abfa-6e6f0dfd479c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b07199c4-746e-4d8b-abfa-6e6f0dfd479c_0">
											<gml:posList>35.66926676509225 139.74771380157165 37.497 35.66926515110904 139.747713063206 37.497 35.66926515110904 139.747713063206 38.6 35.66926676509225 139.74771380157165 38.6 35.66926676509225 139.74771380157165 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e191ffcc-ff02-4885-8ad1-43147e15f7af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e191ffcc-ff02-4885-8ad1-43147e15f7af_0">
											<gml:posList>35.669266203429366 139.74770984766525 40.096 35.66924654230261 139.7477701914347 40.096 35.66923212575627 139.74777782862935 40.096 35.66919694177917 139.747760391246 40.096 35.66919079814894 139.74774028286143 40.096 35.66921447031484 139.74766718764297 40.096 35.66922831050226 139.74766029113476 40.096 35.66925656940605 139.74767415694072 40.096 35.66925712701552 139.74767241106036 40.096 35.66922737131427 139.74765781781161 40.096 35.66921251259165 139.7476647375006 40.096 35.66918821985419 139.74773976644727 40.096 35.66919533004128 139.74776281206138 40.096 35.66923206468501 139.74778067858884 40.096 35.669247517715874 139.74777290773545 40.096 35.6692678174126 139.74771058603085 40.096 35.669266203429366 139.74770984766525 40.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8880f78f-5f8f-4f7e-b579-a2f4ef4c3ad9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8880f78f-5f8f-4f7e-b579-a2f4ef4c3ad9_0">
											<gml:posList>35.66926515110904 139.747713063206 38.6 35.66926515110904 139.747713063206 37.497 35.66924654230261 139.7477701914347 37.497 35.66924654230261 139.7477701914347 40.096 35.669266203429366 139.74770984766525 40.096 35.669266203429366 139.74770984766525 38.6 35.66926515110904 139.747713063206 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d78dbfd-b146-40c5-9f83-4e89d315e42c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d78dbfd-b146-40c5-9f83-4e89d315e42c_0">
											<gml:posList>35.66926676509225 139.74771380157165 38.6 35.6692678174126 139.74771058603085 38.6 35.6692678174126 139.74771058603085 40.096 35.669247517715874 139.74777290773545 40.096 35.669247517715874 139.74777290773545 37.497 35.66926676509225 139.74771380157165 37.497 35.66926676509225 139.74771380157165 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b44c261-3919-4893-8d1e-2433794fdd54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b44c261-3919-4893-8d1e-2433794fdd54_0">
											<gml:posList>35.66919079814894 139.74774028286143 37.497 35.66919079814894 139.74774028286143 40.096 35.66919694177917 139.747760391246 40.096 35.66919694177917 139.747760391246 37.497 35.66919079814894 139.74774028286143 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71701470-1687-4717-8b88-3fa7797c6633">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71701470-1687-4717-8b88-3fa7797c6633_0">
											<gml:posList>35.66919533004128 139.74776281206138 37.497 35.66919533004128 139.74776281206138 40.096 35.66918821985419 139.74773976644727 40.096 35.66918821985419 139.74773976644727 37.497 35.66919533004128 139.74776281206138 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef03a52c-128f-41be-91fd-034b6c2a1d5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef03a52c-128f-41be-91fd-034b6c2a1d5f_0">
											<gml:posList>35.66919694177917 139.747760391246 37.497 35.66919694177917 139.747760391246 40.096 35.66923212575627 139.74777782862935 40.096 35.66923212575627 139.74777782862935 37.497 35.66919694177917 139.747760391246 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d65973d-d425-4963-8b64-b43148aa5283">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d65973d-d425-4963-8b64-b43148aa5283_0">
											<gml:posList>35.66923206468501 139.74778067858884 37.497 35.66923206468501 139.74778067858884 40.096 35.66919533004128 139.74776281206138 40.096 35.66919533004128 139.74776281206138 37.497 35.66923206468501 139.74778067858884 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d86bf4f1-d1d4-4e92-aef0-93382daf8324">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d86bf4f1-d1d4-4e92-aef0-93382daf8324_0">
											<gml:posList>35.66923212575627 139.74777782862935 40.096 35.66924654230261 139.7477701914347 40.096 35.66924654230261 139.7477701914347 37.497 35.66923212575627 139.74777782862935 37.497 35.66923212575627 139.74777782862935 40.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac1d321b-5de7-4455-92c1-7f92db1bb92b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac1d321b-5de7-4455-92c1-7f92db1bb92b_0">
											<gml:posList>35.669247517715874 139.74777290773545 37.497 35.669247517715874 139.74777290773545 40.096 35.66923206468501 139.74778067858884 40.096 35.66923206468501 139.74778067858884 37.497 35.669247517715874 139.74777290773545 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ecd82ff9-13ce-4a5a-9c73-f5149b219f44_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b0c6ac8-13b2-49f9-ab0b-ad3907a4f10f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927788856564 139.74767652012434 5.87 35.66928151429732 139.74769230114043 5.87 35.669276617416955 139.7477142439415 5.87 35.66924844026197 139.74770125067286 5.87 35.66925986236327 139.74766562582911 5.87 35.66927788856564 139.74767652012434 5.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db59c100-6787-4709-91a4-44941c65ee9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db59c100-6787-4709-91a4-44941c65ee9d_0">
											<gml:posList>35.66927788856564 139.74767652012434 38.6 35.66927788856564 139.74767652012434 5.87 35.66925986236327 139.74766562582911 5.87 35.66925986236327 139.74766562582911 38.6 35.66927788856564 139.74767652012434 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-637a2414-20b5-4cb2-8cbb-2bb9d7a17653">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-637a2414-20b5-4cb2-8cbb-2bb9d7a17653_0">
											<gml:posList>35.66924844026197 139.74770125067286 5.87 35.66924844026197 139.74770125067286 38.6 35.66925986236327 139.74766562582911 38.6 35.66925986236327 139.74766562582911 5.87 35.66924844026197 139.74770125067286 5.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fb9ee89-4379-4916-abdf-07593bb1874e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fb9ee89-4379-4916-abdf-07593bb1874e_0">
											<gml:posList>35.66928151429732 139.74769230114043 38.6 35.66928151429732 139.74769230114043 5.87 35.66927788856564 139.74767652012434 5.87 35.66927788856564 139.74767652012434 38.6 35.66928151429732 139.74769230114043 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-464f80a4-f7f7-4bd1-ab0a-4dee2aac00cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-464f80a4-f7f7-4bd1-ab0a-4dee2aac00cb_0">
											<gml:posList>35.66927788856564 139.74767652012434 38.6 35.66925986236327 139.74766562582911 38.6 35.66924844026197 139.74770125067286 38.6 35.669276617416955 139.7477142439415 38.6 35.66928151429732 139.74769230114043 38.6 35.66927788856564 139.74767652012434 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73a80b49-4d39-47bf-9b28-896fa90057d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73a80b49-4d39-47bf-9b28-896fa90057d1_0">
											<gml:posList>35.669276617416955 139.7477142439415 38.6 35.669276617416955 139.7477142439415 5.87 35.66928151429732 139.74769230114043 5.87 35.66928151429732 139.74769230114043 38.6 35.669276617416955 139.7477142439415 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-112543f2-8f40-4e79-b0f3-2f9b5e96cba6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-112543f2-8f40-4e79-b0f3-2f9b5e96cba6_0">
											<gml:posList>35.669276617416955 139.7477142439415 5.87 35.669276617416955 139.7477142439415 38.6 35.66924844026197 139.74770125067286 38.6 35.66924844026197 139.74770125067286 5.87 35.669276617416955 139.7477142439415 5.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ecd82ff9-13ce-4a5a-9c73-f5149b219f44_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9a12a3f-51d8-4223-8026-4debdab8049c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924463005299 139.74773026181043 37.497 35.66924195873991 139.74773837250223 37.497 35.669199660406136 139.74771739693307 37.497 35.66920233172568 139.74770929729092 37.497 35.66924463005299 139.74773026181043 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fb8303c-59bf-49a4-91ab-1ada923307bc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923902573773 139.74774607476704 37.497 35.66923581447926 139.74775542319753 37.497 35.66919479597974 139.7477342805632 37.497 35.669197998222884 139.74772493214627 37.497 35.66923902573773 139.74774607476704 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7d11691-15b7-418c-a2b3-1ea856bd84f7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919725382993 139.74774288284897 37.497 35.66919725382993 139.74774288284897 40.873 35.66920891237799 139.74774821671568 40.873 35.66920891237799 139.74774821671568 37.497 35.66919725382993 139.74774288284897 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d7532ec-d959-47da-a2ff-69e625f81646">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669206295483605 139.74775680232742 37.497 35.66919463693591 139.74775146845963 37.497 35.66919725382993 139.74774288284897 37.497 35.66920891237799 139.74774821671568 37.497 35.669206295483605 139.74775680232742 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc3a6d75-fa36-4db8-ba52-897a9e194517">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc3a6d75-fa36-4db8-ba52-897a9e194517_0">
											<gml:posList>35.669197998222884 139.74772493214627 37.497 35.669197998222884 139.74772493214627 40.873 35.66923902573773 139.74774607476704 40.873 35.66923902573773 139.74774607476704 37.497 35.669197998222884 139.74772493214627 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-129f915c-2cf1-48e7-8943-b5f577ebb8ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-129f915c-2cf1-48e7-8943-b5f577ebb8ea_0">
											<gml:posList>35.66920233172568 139.74770929729092 37.497 35.669199660406136 139.74771739693307 37.497 35.669199660406136 139.74771739693307 40.873 35.66920233172568 139.74770929729092 40.873 35.66920233172568 139.74770929729092 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0341e19c-a009-48ac-9c23-f2f074aedbef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0341e19c-a009-48ac-9c23-f2f074aedbef_0">
											<gml:posList>35.66920233172568 139.74770929729092 37.497 35.66920233172568 139.74770929729092 40.873 35.66924463005299 139.74773026181043 40.873 35.66924463005299 139.74773026181043 37.497 35.66920233172568 139.74770929729092 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7be4d58-a920-4456-b9b3-03bace606f9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7be4d58-a920-4456-b9b3-03bace606f9f_0">
											<gml:posList>35.669199660406136 139.74771739693307 40.873 35.66924195873991 139.74773837250223 40.873 35.66924463005299 139.74773026181043 40.873 35.66920233172568 139.74770929729092 40.873 35.669199660406136 139.74771739693307 40.873</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c6badcc-566e-43ec-bf35-d4bde62b1f86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c6badcc-566e-43ec-bf35-d4bde62b1f86_0">
											<gml:posList>35.669199660406136 139.74771739693307 37.497 35.66924195873991 139.74773837250223 37.497 35.66924195873991 139.74773837250223 40.873 35.669199660406136 139.74771739693307 40.873 35.669199660406136 139.74771739693307 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c883ecfc-66f4-42f7-a758-6187ff5f37f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c883ecfc-66f4-42f7-a758-6187ff5f37f0_0">
											<gml:posList>35.669197998222884 139.74772493214627 37.497 35.66919479597974 139.7477342805632 37.497 35.66919479597974 139.7477342805632 40.873 35.669197998222884 139.74772493214627 40.873 35.669197998222884 139.74772493214627 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37f81d20-0b2e-4ded-977f-926d4769f47b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37f81d20-0b2e-4ded-977f-926d4769f47b_0">
											<gml:posList>35.66924195873991 139.74773837250223 37.497 35.66924463005299 139.74773026181043 37.497 35.66924463005299 139.74773026181043 40.873 35.66924195873991 139.74773837250223 40.873 35.66924195873991 139.74773837250223 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ad0850b-f684-42e9-ba83-95e17cb659fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ad0850b-f684-42e9-ba83-95e17cb659fd_0">
											<gml:posList>35.66919479597974 139.7477342805632 40.873 35.66923581447926 139.74775542319753 40.873 35.66923902573773 139.74774607476704 40.873 35.669197998222884 139.74772493214627 40.873 35.66919479597974 139.7477342805632 40.873</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b56b2b19-70b5-48de-b626-8d86ee402ddf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b56b2b19-70b5-48de-b626-8d86ee402ddf_0">
											<gml:posList>35.66919479597974 139.7477342805632 37.497 35.66923581447926 139.74775542319753 37.497 35.66923581447926 139.74775542319753 40.873 35.66919479597974 139.7477342805632 40.873 35.66919479597974 139.7477342805632 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57065dd7-a06f-496e-865a-1fea4d46ae61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57065dd7-a06f-496e-865a-1fea4d46ae61_0">
											<gml:posList>35.66919725382993 139.74774288284897 37.497 35.66919463693591 139.74775146845963 37.497 35.66919463693591 139.74775146845963 40.873 35.66919725382993 139.74774288284897 40.873 35.66919725382993 139.74774288284897 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97fdb2e4-662d-4424-a62b-edbe5fecfeec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97fdb2e4-662d-4424-a62b-edbe5fecfeec_0">
											<gml:posList>35.669206295483605 139.74775680232742 40.873 35.66920891237799 139.74774821671568 40.873 35.66919725382993 139.74774288284897 40.873 35.66919463693591 139.74775146845963 40.873 35.669206295483605 139.74775680232742 40.873</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18f55f27-9d91-4f60-bf31-357d0ae92624">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18f55f27-9d91-4f60-bf31-357d0ae92624_0">
											<gml:posList>35.66923581447926 139.74775542319753 37.497 35.66923902573773 139.74774607476704 37.497 35.66923902573773 139.74774607476704 40.873 35.66923581447926 139.74775542319753 40.873 35.66923581447926 139.74775542319753 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-864928d5-aba6-4227-bb00-429df2b21d4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-864928d5-aba6-4227-bb00-429df2b21d4c_0">
											<gml:posList>35.669206295483605 139.74775680232742 37.497 35.66920891237799 139.74774821671568 37.497 35.66920891237799 139.74774821671568 40.873 35.669206295483605 139.74775680232742 40.873 35.669206295483605 139.74775680232742 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fe11873-ca0c-4fe1-af5a-c9c2b9f3af5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fe11873-ca0c-4fe1-af5a-c9c2b9f3af5a_0">
											<gml:posList>35.66919463693591 139.74775146845963 37.497 35.669206295483605 139.74775680232742 37.497 35.669206295483605 139.74775680232742 40.873 35.66919463693591 139.74775146845963 40.873 35.66919463693591 139.74775146845963 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3dfff632-47cf-4c99-b02b-528c6d2f3651">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3dfff632-47cf-4c99-b02b-528c6d2f3651">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3dfff632-47cf-4c99-b02b-528c6d2f3651">
											<gml:posList>35.6692111083968 139.74764213868215 5.87 35.66925986236327 139.74766562582911 5.87 35.66924844026197 139.74770125067286 5.87 35.669276617416955 139.7477142439415 5.87 35.66924885353482 139.74780079772333 5.87 35.669172084331954 139.7477638089258 5.87 35.6692111083968 139.74764213868215 5.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cdaeadf0-59c6-4748-9c1c-0bc7a8a88293">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdaeadf0-59c6-4748-9c1c-0bc7a8a88293">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdaeadf0-59c6-4748-9c1c-0bc7a8a88293">
											<gml:posList>35.669188675279024 139.74777179963948 12.4 35.669178370992 139.7477441953988 12.4 35.669172084331954 139.7477638089258 12.4 35.669188675279024 139.74777179963948 12.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c5c0f8b0-1276-49ac-ade2-93fe6e63d10b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5c0f8b0-1276-49ac-ade2-93fe6e63d10b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5c0f8b0-1276-49ac-ade2-93fe6e63d10b">
											<gml:posList>35.669188675279024 139.74777179963948 38.6 35.669191007699204 139.74776879261236 38.6 35.66918177809418 139.74774407025484 38.6 35.669178370992 139.7477441953988 38.6 35.669188675279024 139.74777179963948 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7361c716-ea13-4ddb-8629-ca39fc4332d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7361c716-ea13-4ddb-8629-ca39fc4332d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7361c716-ea13-4ddb-8629-ca39fc4332d0">
											<gml:posList>35.669178370992 139.7477441953988 38.6 35.66918177809418 139.74774407025484 38.6 35.66920890339174 139.74765952759816 38.6 35.66920651258512 139.7476564814296 38.6 35.669178370992 139.7477441953988 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9df6c94d-eb4c-4149-a9f4-f98b3ca4dd2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9df6c94d-eb4c-4149-a9f4-f98b3ca4dd2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9df6c94d-eb4c-4149-a9f4-f98b3ca4dd2e">
											<gml:posList>35.6692279705809 139.7477907349095 38.6 35.66922801272248 139.7477866146687 38.6 35.669191007699204 139.74776879261236 38.6 35.669188675279024 139.74777179963948 38.6 35.6692279705809 139.7477907349095 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b01a4031-4a9f-4b26-a41e-6cc1b75a7ed9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b01a4031-4a9f-4b26-a41e-6cc1b75a7ed9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b01a4031-4a9f-4b26-a41e-6cc1b75a7ed9">
											<gml:posList>35.6692111083968 139.74764213868215 12.4 35.66920651258512 139.7476564814296 12.4 35.66922478692001 139.74764872963198 12.4 35.6692111083968 139.74764213868215 12.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f186b503-2509-4c50-abd7-c20a57ef210c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f186b503-2509-4c50-abd7-c20a57ef210c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f186b503-2509-4c50-abd7-c20a57ef210c">
											<gml:posList>35.66922478692001 139.74764872963198 38.6 35.66920651258512 139.7476564814296 38.6 35.66920890339174 139.74765952759816 38.6 35.66922472673212 139.74765281675366 38.6 35.66922478692001 139.74764872963198 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b671b6c8-6bf5-4f40-8d44-ba62af030385">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b671b6c8-6bf5-4f40-8d44-ba62af030385">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b671b6c8-6bf5-4f40-8d44-ba62af030385">
											<gml:posList>35.66924436763664 139.7477034752892 37.497 35.66925580772677 139.74766779519786 37.497 35.66922472673212 139.74765281675366 37.497 35.66920890339174 139.74765952759816 37.497 35.66918177809418 139.74774407025484 37.497 35.669191007699204 139.74776879261236 37.497 35.66922801272248 139.7477866146687 37.497 35.6692538376722 139.7477747788293 37.497 35.669272544791404 139.74771646855794 37.497 35.66924436763664 139.7477034752892 37.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3650f754-8fd9-43f3-ad9a-c0792e3543a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3650f754-8fd9-43f3-ad9a-c0792e3543a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3650f754-8fd9-43f3-ad9a-c0792e3543a9">
											<gml:posList>35.6692279705809 139.7477907349095 38.6 35.66925623745815 139.7477777808092 38.6 35.6692538376722 139.7477747788293 38.6 35.66922801272248 139.7477866146687 38.6 35.6692279705809 139.7477907349095 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9eb7989c-cacf-4d2d-bc10-c71296c6dd96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9eb7989c-cacf-4d2d-bc10-c71296c6dd96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9eb7989c-cacf-4d2d-bc10-c71296c6dd96">
											<gml:posList>35.66925623745815 139.7477777808092 12.4 35.6692279705809 139.7477907349095 12.4 35.66924885353482 139.74780079772333 12.4 35.66925623745815 139.7477777808092 12.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-511adb22-bf10-4c0d-99df-5aa33f3ddbe7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-511adb22-bf10-4c0d-99df-5aa33f3ddbe7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-511adb22-bf10-4c0d-99df-5aa33f3ddbe7">
											<gml:posList>35.66922478692001 139.74764872963198 38.6 35.66922472673212 139.74765281675366 38.6 35.66925580772677 139.74766779519786 38.6 35.66925986236327 139.74766562582911 38.6 35.66922478692001 139.74764872963198 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88b6ca3c-ef57-48d6-a35c-5853d04d5abe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88b6ca3c-ef57-48d6-a35c-5853d04d5abe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88b6ca3c-ef57-48d6-a35c-5853d04d5abe">
											<gml:posList>35.66924844026197 139.74770125067286 38.6 35.66925986236327 139.74766562582911 38.6 35.66925580772677 139.74766779519786 38.6 35.66924436763664 139.7477034752892 38.6 35.66924844026197 139.74770125067286 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d3356b7-c117-4a54-ad12-a75486e02cf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d3356b7-c117-4a54-ad12-a75486e02cf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d3356b7-c117-4a54-ad12-a75486e02cf6">
											<gml:posList>35.66924844026197 139.74770125067286 38.6 35.66924436763664 139.7477034752892 38.6 35.669272544791404 139.74771646855794 38.6 35.669276617416955 139.7477142439415 38.6 35.66924844026197 139.74770125067286 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a3305db-bf43-4d25-a7c1-1a4f718bc049">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a3305db-bf43-4d25-a7c1-1a4f718bc049">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a3305db-bf43-4d25-a7c1-1a4f718bc049">
											<gml:posList>35.66925623745815 139.7477777808092 38.6 35.669276617416955 139.7477142439415 38.6 35.669272544791404 139.74771646855794 38.6 35.6692538376722 139.7477747788293 38.6 35.66925623745815 139.7477777808092 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56fc06e5-7239-4a55-abf8-62018e188f4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56fc06e5-7239-4a55-abf8-62018e188f4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56fc06e5-7239-4a55-abf8-62018e188f4e">
											<gml:posList>35.66920651258512 139.7476564814296 12.4 35.66920651258512 139.7476564814296 38.6 35.66922478692001 139.74764872963198 38.6 35.66922478692001 139.74764872963198 12.4 35.66920651258512 139.7476564814296 12.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6cf840be-9eee-499e-a6a5-9a2a21b7e4a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cf840be-9eee-499e-a6a5-9a2a21b7e4a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cf840be-9eee-499e-a6a5-9a2a21b7e4a5">
											<gml:posList>35.66922478692001 139.74764872963198 12.4 35.66922478692001 139.74764872963198 38.6 35.66925986236327 139.74766562582911 38.6 35.66925986236327 139.74766562582911 5.87 35.6692111083968 139.74764213868215 5.87 35.6692111083968 139.74764213868215 12.4 35.66922478692001 139.74764872963198 12.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5dc184d-27f4-4d93-acba-50dbf90c4ee1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5dc184d-27f4-4d93-acba-50dbf90c4ee1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5dc184d-27f4-4d93-acba-50dbf90c4ee1">
											<gml:posList>35.66920890339174 139.74765952759816 38.6 35.66920890339174 139.74765952759816 37.497 35.66922472673212 139.74765281675366 37.497 35.66922472673212 139.74765281675366 38.6 35.66920890339174 139.74765952759816 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17bd0d0e-504e-4efc-96e8-c5aef1c5016c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17bd0d0e-504e-4efc-96e8-c5aef1c5016c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17bd0d0e-504e-4efc-96e8-c5aef1c5016c">
											<gml:posList>35.66922472673212 139.74765281675366 38.6 35.66922472673212 139.74765281675366 37.497 35.66925580772677 139.74766779519786 37.497 35.66925580772677 139.74766779519786 38.6 35.66922472673212 139.74765281675366 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8512dbe1-2066-41a3-89db-26bf99760ffc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8512dbe1-2066-41a3-89db-26bf99760ffc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8512dbe1-2066-41a3-89db-26bf99760ffc">
											<gml:posList>35.66925986236327 139.74766562582911 38.6 35.66924844026197 139.74770125067286 38.6 35.66924844026197 139.74770125067286 5.87 35.66925986236327 139.74766562582911 5.87 35.66925986236327 139.74766562582911 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3bc04d4-a71c-4ccb-8934-e358300bd10f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3bc04d4-a71c-4ccb-8934-e358300bd10f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3bc04d4-a71c-4ccb-8934-e358300bd10f">
											<gml:posList>35.66925580772677 139.74766779519786 38.6 35.66925580772677 139.74766779519786 37.497 35.66924436763664 139.7477034752892 37.497 35.66924436763664 139.7477034752892 38.6 35.66925580772677 139.74766779519786 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aab19e15-32e7-42b4-83f3-01fbb7ff8817">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aab19e15-32e7-42b4-83f3-01fbb7ff8817">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aab19e15-32e7-42b4-83f3-01fbb7ff8817">
											<gml:posList>35.66918177809418 139.74774407025484 38.6 35.66918177809418 139.74774407025484 37.497 35.66920890339174 139.74765952759816 37.497 35.66920890339174 139.74765952759816 38.6 35.66918177809418 139.74774407025484 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d13f96c9-3e4b-4017-9f8e-f2f3625c3fc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d13f96c9-3e4b-4017-9f8e-f2f3625c3fc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d13f96c9-3e4b-4017-9f8e-f2f3625c3fc5">
											<gml:posList>35.66920651258512 139.7476564814296 12.4 35.6692111083968 139.74764213868215 12.4 35.6692111083968 139.74764213868215 5.87 35.669172084331954 139.7477638089258 5.87 35.669172084331954 139.7477638089258 12.4 35.669178370992 139.7477441953988 12.4 35.669178370992 139.7477441953988 38.6 35.66920651258512 139.7476564814296 38.6 35.66920651258512 139.7476564814296 12.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-000d43e2-ee14-4482-9712-b48894654639">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-000d43e2-ee14-4482-9712-b48894654639">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-000d43e2-ee14-4482-9712-b48894654639">
											<gml:posList>35.669276617416955 139.7477142439415 5.87 35.66924844026197 139.74770125067286 5.87 35.66924844026197 139.74770125067286 38.6 35.669276617416955 139.7477142439415 38.6 35.669276617416955 139.7477142439415 5.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b67afd93-ac05-43cc-af97-b084e5eac9b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b67afd93-ac05-43cc-af97-b084e5eac9b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b67afd93-ac05-43cc-af97-b084e5eac9b1">
											<gml:posList>35.66924436763664 139.7477034752892 38.6 35.66924436763664 139.7477034752892 37.497 35.669272544791404 139.74771646855794 37.497 35.669272544791404 139.74771646855794 38.6 35.66924436763664 139.7477034752892 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a12aaabf-60b4-41dd-935e-f8fda5f9b1f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a12aaabf-60b4-41dd-935e-f8fda5f9b1f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a12aaabf-60b4-41dd-935e-f8fda5f9b1f9">
											<gml:posList>35.669272544791404 139.74771646855794 38.6 35.669272544791404 139.74771646855794 37.497 35.6692538376722 139.7477747788293 37.497 35.6692538376722 139.7477747788293 38.6 35.669272544791404 139.74771646855794 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2f085b3-3c4e-4481-b252-8b6956638718">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2f085b3-3c4e-4481-b252-8b6956638718">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2f085b3-3c4e-4481-b252-8b6956638718">
											<gml:posList>35.669191007699204 139.74776879261236 38.6 35.669191007699204 139.74776879261236 37.497 35.66918177809418 139.74774407025484 37.497 35.66918177809418 139.74774407025484 38.6 35.669191007699204 139.74776879261236 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b25ec6be-f09b-4a01-bedc-2f1bea244f88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b25ec6be-f09b-4a01-bedc-2f1bea244f88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b25ec6be-f09b-4a01-bedc-2f1bea244f88">
											<gml:posList>35.669276617416955 139.7477142439415 5.87 35.669276617416955 139.7477142439415 38.6 35.66925623745815 139.7477777808092 38.6 35.66925623745815 139.7477777808092 12.4 35.66924885353482 139.74780079772333 12.4 35.66924885353482 139.74780079772333 5.87 35.669276617416955 139.7477142439415 5.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1590cd95-2429-4450-a20f-9be28ef81d0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1590cd95-2429-4450-a20f-9be28ef81d0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1590cd95-2429-4450-a20f-9be28ef81d0f">
											<gml:posList>35.669188675279024 139.74777179963948 12.4 35.669188675279024 139.74777179963948 38.6 35.669178370992 139.7477441953988 38.6 35.669178370992 139.7477441953988 12.4 35.669188675279024 139.74777179963948 12.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c8e3fe7-c3da-4697-8be8-f89262152dc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c8e3fe7-c3da-4697-8be8-f89262152dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c8e3fe7-c3da-4697-8be8-f89262152dc2">
											<gml:posList>35.66922801272248 139.7477866146687 38.6 35.66922801272248 139.7477866146687 37.497 35.669191007699204 139.74776879261236 37.497 35.669191007699204 139.74776879261236 38.6 35.66922801272248 139.7477866146687 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c32ed11-daef-4bf9-abc0-d43230844768">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c32ed11-daef-4bf9-abc0-d43230844768">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c32ed11-daef-4bf9-abc0-d43230844768">
											<gml:posList>35.6692538376722 139.7477747788293 38.6 35.6692538376722 139.7477747788293 37.497 35.66922801272248 139.7477866146687 37.497 35.66922801272248 139.7477866146687 38.6 35.6692538376722 139.7477747788293 38.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e695931-07ec-4812-ae00-845c39d74d4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e695931-07ec-4812-ae00-845c39d74d4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e695931-07ec-4812-ae00-845c39d74d4e">
											<gml:posList>35.6692279705809 139.7477907349095 12.4 35.6692279705809 139.7477907349095 38.6 35.669188675279024 139.74777179963948 38.6 35.669188675279024 139.74777179963948 12.4 35.669172084331954 139.7477638089258 12.4 35.669172084331954 139.7477638089258 5.87 35.66924885353482 139.74780079772333 5.87 35.66924885353482 139.74780079772333 12.4 35.6692279705809 139.7477907349095 12.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d6ecc31-3ad2-485f-af48-2d223719a7c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d6ecc31-3ad2-485f-af48-2d223719a7c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d6ecc31-3ad2-485f-af48-2d223719a7c0">
											<gml:posList>35.66925623745815 139.7477777808092 12.4 35.66925623745815 139.7477777808092 38.6 35.6692279705809 139.7477907349095 38.6 35.6692279705809 139.7477907349095 12.4 35.66925623745815 139.7477777808092 12.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5727</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">63.0588</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>