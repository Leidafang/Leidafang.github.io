<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ede841c4-b18d-47db-8fe9-361940cd4c95">
			<core:creationDate>2023-08-22</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">30.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66878772803742 139.74784899857553 0 35.66874747918628 139.74798139507996 0 35.66878454934618 139.74799832123313 0 35.66883914966521 139.7480232371336 0 35.668878932881036 139.74789257522522 0 35.66890908808269 139.74790493566414 0 35.668917893254715 139.74790317990096 0 35.66892262202392 139.74789833006105 0 35.668924605298066 139.74788725316844 0 35.66892211061315 139.74787880780076 0 35.66891518244493 139.74787215772517 0 35.66888839684026 139.7478614428816 0 35.6688891333458 139.74785902080131 0 35.66879746461432 139.74781718001228 0 35.66878772803742 139.74784899857553 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66878772803742 139.74784899857553 5.735 35.66879746461432 139.74781718001228 5.735 35.6688891333458 139.74785902080131 5.735 35.66888839684026 139.7478614428816 5.735 35.66891518244493 139.74787215772517 5.735 35.66892211061315 139.74787880780076 5.735 35.668924605298066 139.74788725316844 5.735 35.66892262202392 139.74789833006105 5.735 35.668917893254715 139.74790317990096 5.735 35.66890908808269 139.74790493566414 5.735 35.668878932881036 139.74789257522522 5.735 35.66883914966521 139.7480232371336 5.735 35.66878454934618 139.74799832123313 5.735 35.66874747918628 139.74798139507996 5.735 35.66878772803742 139.74784899857553 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66878772803742 139.74784899857553 5.735 35.66874747918628 139.74798139507996 5.735 35.66874747918628 139.74798139507996 32.463 35.66878772803742 139.74784899857553 32.463 35.66878772803742 139.74784899857553 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66874747918628 139.74798139507996 5.735 35.66878454934618 139.74799832123313 5.735 35.66878454934618 139.74799832123313 32.463 35.66874747918628 139.74798139507996 32.463 35.66874747918628 139.74798139507996 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66878454934618 139.74799832123313 5.735 35.66883914966521 139.7480232371336 5.735 35.66883914966521 139.7480232371336 32.463 35.66878454934618 139.74799832123313 32.463 35.66878454934618 139.74799832123313 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883914966521 139.7480232371336 5.735 35.668878932881036 139.74789257522522 5.735 35.668878932881036 139.74789257522522 32.463 35.66883914966521 139.7480232371336 32.463 35.66883914966521 139.7480232371336 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668878932881036 139.74789257522522 5.735 35.66890908808269 139.74790493566414 5.735 35.66890908808269 139.74790493566414 32.463 35.668878932881036 139.74789257522522 32.463 35.668878932881036 139.74789257522522 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890908808269 139.74790493566414 5.735 35.668917893254715 139.74790317990096 5.735 35.668917893254715 139.74790317990096 32.463 35.66890908808269 139.74790493566414 32.463 35.66890908808269 139.74790493566414 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668917893254715 139.74790317990096 5.735 35.66892262202392 139.74789833006105 5.735 35.66892262202392 139.74789833006105 32.463 35.668917893254715 139.74790317990096 32.463 35.668917893254715 139.74790317990096 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66892262202392 139.74789833006105 5.735 35.668924605298066 139.74788725316844 5.735 35.668924605298066 139.74788725316844 32.463 35.66892262202392 139.74789833006105 32.463 35.66892262202392 139.74789833006105 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668924605298066 139.74788725316844 5.735 35.66892211061315 139.74787880780076 5.735 35.66892211061315 139.74787880780076 32.463 35.668924605298066 139.74788725316844 32.463 35.668924605298066 139.74788725316844 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66892211061315 139.74787880780076 5.735 35.66891518244493 139.74787215772517 5.735 35.66891518244493 139.74787215772517 32.463 35.66892211061315 139.74787880780076 32.463 35.66892211061315 139.74787880780076 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891518244493 139.74787215772517 5.735 35.66888839684026 139.7478614428816 5.735 35.66888839684026 139.7478614428816 32.463 35.66891518244493 139.74787215772517 32.463 35.66891518244493 139.74787215772517 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66888839684026 139.7478614428816 5.735 35.6688891333458 139.74785902080131 5.735 35.6688891333458 139.74785902080131 32.463 35.66888839684026 139.7478614428816 32.463 35.66888839684026 139.7478614428816 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688891333458 139.74785902080131 5.735 35.66879746461432 139.74781718001228 5.735 35.66879746461432 139.74781718001228 32.463 35.6688891333458 139.74785902080131 32.463 35.6688891333458 139.74785902080131 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879746461432 139.74781718001228 5.735 35.66878772803742 139.74784899857553 5.735 35.66878772803742 139.74784899857553 32.463 35.66879746461432 139.74781718001228 32.463 35.66879746461432 139.74781718001228 5.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66878772803742 139.74784899857553 32.463 35.66874747918628 139.74798139507996 32.463 35.66878454934618 139.74799832123313 32.463 35.66883914966521 139.7480232371336 32.463 35.668878932881036 139.74789257522522 32.463 35.66890908808269 139.74790493566414 32.463 35.668917893254715 139.74790317990096 32.463 35.66892262202392 139.74789833006105 32.463 35.668924605298066 139.74788725316844 32.463 35.66892211061315 139.74787880780076 32.463 35.66891518244493 139.74787215772517 32.463 35.66888839684026 139.7478614428816 32.463 35.6688891333458 139.74785902080131 32.463 35.66879746461432 139.74781718001228 32.463 35.66878772803742 139.74784899857553 32.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1014_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1014_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1014_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1014_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1013_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1013_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1013_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1013_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1013_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1013_5"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1013_6"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1013_7"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1013_8"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1008_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1008_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1008_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1008_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1009_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1009_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_p1009_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0159_b_0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gnd_TMmnt0159_b_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_b_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_b_0">
											<gml:posList>35.66887893694927 139.74789256106757 5.80772236 35.668839206826114 139.74802325067608 5.80681432 35.66874758036795 139.74798141908508 5.80228385 35.66879750679817 139.7478171891798 5.80342892 35.668889133333955 139.74785902061964 5.80795943 35.66888839701932 139.74786144268757 5.80794225 35.66891518227701 139.74787215749535 5.80925954 35.66892211040341 139.7478788078106 5.80962774 35.66892460515329 139.7478872526482 5.8098029 35.66892262230789 139.74789833059182 5.80978887 35.66891789294765 139.74790318020783 5.80960357 35.668909133105466 139.74790494556714 5.80920958 35.66887893694927 139.74789256106757 5.80772236</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0159_p1013_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1013_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1013_0">
											<gml:posList>35.66888561441875 139.7478702760595 29.96706297 35.66887936532332 139.7478908321135 29.96691782 35.66887884602482 139.74789254031546 29.96690578 35.66890904206633 139.7479049247682 29.968393 35.66891780187526 139.74790315941556 29.96878699 35.66892253121748 139.7478983098179 29.96897228 35.668924514055355 139.74788723191617 29.96898632 35.66892201931495 139.7478787871106 29.96881116 35.668915091214885 139.74787213682055 29.96844295 35.66888700304018 139.74786090081167 29.96706163 35.66888462597503 139.74786982479193 29.96701399 35.66888561441875 139.7478702760595 29.96706297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0159_p1008_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1008_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1008_0">
											<gml:posList>35.668787728142775 139.74784899829962 32.89738707 35.66874747895749 139.74798139543478 32.89646703 35.6687845623179 139.74799832564128 32.89829839 35.66879781800667 139.74795472114516 32.89859856 35.668852360947575 139.7479796224349 32.90129767 35.668879354277095 139.7478908295932 32.90191755 35.668787728142775 139.74784899829962 32.89738707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0159_p1014_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1014_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1014_0">
											<gml:posList>35.668787728142775 139.74784899829962 32.89738707 35.668879354277095 139.7478908295932 32.90191755 35.66888561441875 139.7478702760595 29.96706297 35.66888462597503 139.74786982479193 29.96701399 35.668887007764766 139.74786090188329 28.71211731 35.66888831081864 139.74786142313292 28.70294807 35.66888904843273 139.74785900136894 28.357143 35.6687974222219 139.74781717007693 28.3526125 35.668787728142775 139.74784899829962 32.89738707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0159_p1009_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1009_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1009_0">
											<gml:posList>35.66878454889756 139.7479983225069 36.47829807 35.66883909157408 139.7480232236998 36.48099716 35.66885234748902 139.74797961931094 36.48129735 35.66879780457877 139.7479547180352 36.47859824 35.66878454889756 139.7479983225069 36.47829807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1013_8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1013_8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1013_8">
											<gml:posList>35.66888700304018 139.74786090081167 29.96706163 35.668887007764766 139.74786090188329 28.71211731 35.66888462597503 139.74786982479193 29.96701399 35.66888700304018 139.74786090081167 29.96706163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1008_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1008_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1008_3">
											<gml:posList>35.66874747895749 139.74798139543478 32.89646703 35.668787728142775 139.74784899829962 32.89738707 35.6687974222219 139.74781717007693 28.3526125 35.66879750679817 139.7478171891798 5.80342892 35.66874758036795 139.74798141908508 5.80228385 35.66874747895749 139.74798139543478 32.89646703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1013_6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1013_6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1013_6">
											<gml:posList>35.66891780187526 139.74790315941556 29.96878699 35.66890904206633 139.7479049247682 29.968393 35.668909133105466 139.74790494556714 5.80920958 35.66891789294765 139.74790318020783 5.80960357 35.66891780187526 139.74790315941556 29.96878699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1014_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1014_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1014_2">
											<gml:posList>35.66888904843273 139.74785900136894 28.357143 35.66888831081864 139.74786142313292 28.70294807 35.66888839701932 139.74786144268757 5.80794225 35.668889133333955 139.74785902061964 5.80795943 35.66888904843273 139.74785900136894 28.357143</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1013_5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1013_5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1013_5">
											<gml:posList>35.66892253121748 139.7478983098179 29.96897228 35.66891780187526 139.74790315941556 29.96878699 35.66891789294765 139.74790318020783 5.80960357 35.66892262230789 139.74789833059182 5.80978887 35.66892253121748 139.7478983098179 29.96897228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1014_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1014_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1014_1">
											<gml:posList>35.6687974222219 139.74781717007693 28.3526125 35.66888904843273 139.74785900136894 28.357143 35.668889133333955 139.74785902061964 5.80795943 35.66879750679817 139.7478171891798 5.80342892 35.6687974222219 139.74781717007693 28.3526125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1013_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1013_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1013_1">
											<gml:posList>35.66888839701932 139.74786144268757 5.80794225 35.66888831081864 139.74786142313292 28.70294807 35.668887007764766 139.74786090188329 28.71211731 35.66888700304018 139.74786090081167 29.96706163 35.668915091214885 139.74787213682055 29.96844295 35.66891518227701 139.74787215749535 5.80925954 35.66888839701932 139.74786144268757 5.80794225</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1009_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1009_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1009_2">
											<gml:posList>35.66879780457877 139.7479547180352 36.47859824 35.66879781800667 139.74795472114516 32.89859856 35.6687845623179 139.74799832564128 32.89829839 35.66878454889756 139.7479983225069 36.47829807 35.66879780457877 139.7479547180352 36.47859824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1013_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1013_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1013_3">
											<gml:posList>35.66892201931495 139.7478787871106 29.96881116 35.668924514055355 139.74788723191617 29.96898632 35.66892460515329 139.7478872526482 5.8098029 35.66892211040341 139.7478788078106 5.80962774 35.66892201931495 139.7478787871106 29.96881116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1013_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1013_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1013_2">
											<gml:posList>35.668915091214885 139.74787213682055 29.96844295 35.66892201931495 139.7478787871106 29.96881116 35.66892211040341 139.7478788078106 5.80962774 35.66891518227701 139.74787215749535 5.80925954 35.668915091214885 139.74787213682055 29.96844295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1008_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1008_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1008_2">
											<gml:posList>35.668839206826114 139.74802325067608 5.80681432 35.66883909157408 139.7480232236998 36.48099716 35.66878454889756 139.7479983225069 36.47829807 35.6687845623179 139.74799832564128 32.89829839 35.66874747895749 139.74798139543478 32.89646703 35.66874758036795 139.74798141908508 5.80228385 35.668839206826114 139.74802325067608 5.80681432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1013_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1013_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1013_4">
											<gml:posList>35.668924514055355 139.74788723191617 29.96898632 35.66892253121748 139.7478983098179 29.96897228 35.66892262230789 139.74789833059182 5.80978887 35.66892460515329 139.7478872526482 5.8098029 35.668924514055355 139.74788723191617 29.96898632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1008_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1008_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1008_1">
											<gml:posList>35.668879354277095 139.7478908295932 32.90191755 35.668852360947575 139.7479796224349 32.90129767 35.66885234748902 139.74797961931094 36.48129735 35.66883909157408 139.7480232236998 36.48099716 35.668839206826114 139.74802325067608 5.80681432 35.66887893694927 139.74789256106757 5.80772236 35.66887884602482 139.74789254031546 29.96690578 35.66887936532332 139.7478908321135 29.96691782 35.668879354277095 139.7478908295932 32.90191755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1013_7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1013_7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1013_7">
											<gml:posList>35.66890904206633 139.7479049247682 29.968393 35.66887884602482 139.74789254031546 29.96690578 35.66887893694927 139.74789256106757 5.80772236 35.668909133105466 139.74790494556714 5.80920958 35.66890904206633 139.7479049247682 29.968393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1014_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1014_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1014_3">
											<gml:posList>35.668879354277095 139.7478908295932 32.90191755 35.66887936532332 139.7478908321135 29.96691782 35.66888561441875 139.7478702760595 29.96706297 35.668879354277095 139.7478908295932 32.90191755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0159_p1009_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0159_p1009_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0159_p1009_1">
											<gml:posList>35.66885234748902 139.74797961931094 36.48129735 35.668852360947575 139.7479796224349 32.90129767 35.66879781800667 139.74795472114516 32.89859856 35.66879780457877 139.7479547180352 36.47859824 35.66885234748902 139.74797961931094 36.48129735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">182.66395</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">9</uro:districtsAndZonesType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2423500000</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>