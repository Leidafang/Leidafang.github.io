<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ee44bc47-ab5d-45e1-a110-e00ccb00dd04">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">28</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671758693550444 139.73994275783778 0 35.67179964762018 139.73998369248 0 35.67185942889453 139.73989359419866 0 35.6717327778714 139.73976703907408 0 35.671649408521375 139.73989295525595 0 35.67173546530568 139.73997780212952 0 35.671758693550444 139.73994275783778 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671758693550444 139.73994275783778 8.96 35.67173546530568 139.73997780212952 8.96 35.671649408521375 139.73989295525595 8.96 35.6717327778714 139.73976703907408 8.96 35.67185942889453 139.73989359419866 8.96 35.67179964762018 139.73998369248 8.96 35.671758693550444 139.73994275783778 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671758693550444 139.73994275783778 8.96 35.67179964762018 139.73998369248 8.96 35.67179964762018 139.73998369248 32.47 35.671758693550444 139.73994275783778 32.47 35.671758693550444 139.73994275783778 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179964762018 139.73998369248 8.96 35.67185942889453 139.73989359419866 8.96 35.67185942889453 139.73989359419866 32.47 35.67179964762018 139.73998369248 32.47 35.67179964762018 139.73998369248 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67185942889453 139.73989359419866 8.96 35.6717327778714 139.73976703907408 8.96 35.6717327778714 139.73976703907408 32.47 35.67185942889453 139.73989359419866 32.47 35.67185942889453 139.73989359419866 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6717327778714 139.73976703907408 8.96 35.671649408521375 139.73989295525595 8.96 35.671649408521375 139.73989295525595 32.47 35.6717327778714 139.73976703907408 32.47 35.6717327778714 139.73976703907408 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671649408521375 139.73989295525595 8.96 35.67173546530568 139.73997780212952 8.96 35.67173546530568 139.73997780212952 32.47 35.671649408521375 139.73989295525595 32.47 35.671649408521375 139.73989295525595 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67173546530568 139.73997780212952 8.96 35.671758693550444 139.73994275783778 8.96 35.671758693550444 139.73994275783778 32.47 35.67173546530568 139.73997780212952 32.47 35.67173546530568 139.73997780212952 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671758693550444 139.73994275783778 32.47 35.67179964762018 139.73998369248 32.47 35.67185942889453 139.73989359419866 32.47 35.6717327778714 139.73976703907408 32.47 35.671649408521375 139.73989295525595 32.47 35.67173546530568 139.73997780212952 32.47 35.671758693550444 139.73994275783778 32.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-975c4418-56dd-4e02-955b-26b4816f1bd5"/>
							<gml:surfaceMember xlink:href="#poly-3e6ac431-2aa8-46c4-892b-bda7b175a2fa"/>
							<gml:surfaceMember xlink:href="#poly-0c249c7e-3640-45e3-8b86-c93a1d538dfe"/>
							<gml:surfaceMember xlink:href="#poly-726b09df-26b2-4950-ac05-73355701a13e"/>
							<gml:surfaceMember xlink:href="#poly-f4cc7453-c476-47ea-a379-684e343d5555"/>
							<gml:surfaceMember xlink:href="#poly-57b0eb1b-84e9-4dcb-8529-106419519bc5"/>
							<gml:surfaceMember xlink:href="#poly-49f0dab4-46ba-44a2-8056-9f9aa7f422c4"/>
							<gml:surfaceMember xlink:href="#poly-ca24e852-ed4f-4394-8ed1-0f7d3f98774f"/>
							<gml:surfaceMember xlink:href="#poly-95337ef0-a63e-4672-aa04-cbb57805740b"/>
							<gml:surfaceMember xlink:href="#poly-d5af1c25-5cb0-4014-a2fb-3975e1216deb"/>
							<gml:surfaceMember xlink:href="#poly-e11721b1-5eac-4393-871c-0f2ba5bf6b04"/>
							<gml:surfaceMember xlink:href="#poly-7745f5b3-1009-457e-849b-fe616ca8b676"/>
							<gml:surfaceMember xlink:href="#poly-7fa4d112-6846-4167-bb62-1c478a0e5491"/>
							<gml:surfaceMember xlink:href="#poly-6bc9586b-0a5c-4eb8-8631-83b0316ea1d1"/>
							<gml:surfaceMember xlink:href="#poly-c507d84c-a271-437d-8b10-99a3c9281167"/>
							<gml:surfaceMember xlink:href="#poly-7d622e5a-69cb-4685-980a-580d8d746dae"/>
							<gml:surfaceMember xlink:href="#poly-e0ceba6b-921b-4763-98ad-b1eb27589236"/>
							<gml:surfaceMember xlink:href="#poly-6b7b0b5d-d8b5-42f8-8d9a-eb9d90fbf438"/>
							<gml:surfaceMember xlink:href="#poly-c58b54fd-3287-4370-bb64-ceec8dcf91f9"/>
							<gml:surfaceMember xlink:href="#poly-495bd18e-b06c-4def-ac1f-657226ef3175"/>
							<gml:surfaceMember xlink:href="#poly-67ff964f-accc-446d-98ec-9a2fc278609a"/>
							<gml:surfaceMember xlink:href="#poly-fc4af94f-60bc-48e7-8eca-f8ced65619dc"/>
							<gml:surfaceMember xlink:href="#poly-f3cdbd69-9728-40e4-94ca-d560cef94e42"/>
							<gml:surfaceMember xlink:href="#poly-682e1614-12da-4089-a37a-0f091aa53e91"/>
							<gml:surfaceMember xlink:href="#poly-86fc2099-f800-4d47-a1c9-62e3909a12e6"/>
							<gml:surfaceMember xlink:href="#poly-47375eef-9e87-4b99-9211-d95d24f15772"/>
							<gml:surfaceMember xlink:href="#poly-61c40bdb-b3c4-4a9f-8d2d-0a79c31a2f9a"/>
							<gml:surfaceMember xlink:href="#poly-48c2d408-c6e6-44cf-86e7-1fe0c36c227a"/>
							<gml:surfaceMember xlink:href="#poly-f152326a-cc1a-48c2-9363-ae350891617f"/>
							<gml:surfaceMember xlink:href="#poly-787e7691-4883-4c54-8c8a-55fff3eb6f28"/>
							<gml:surfaceMember xlink:href="#poly-59d0915d-a6a0-4462-a514-21df34b97488"/>
							<gml:surfaceMember xlink:href="#poly-0c28c7ec-1ada-4db3-8f65-9ce28f9c432f"/>
							<gml:surfaceMember xlink:href="#poly-3fbff841-fc61-489c-a039-f46d76f28a67"/>
							<gml:surfaceMember xlink:href="#poly-939fbcf5-2300-4fb8-8f0f-1cde99ef9565"/>
							<gml:surfaceMember xlink:href="#poly-a8ad21ad-b770-40c8-8b1a-63bb76322d1f"/>
							<gml:surfaceMember xlink:href="#poly-64f83816-19d2-43dc-9779-c1056633d093"/>
							<gml:surfaceMember xlink:href="#poly-a86aa649-236a-45e6-8196-1a17fac5c6d1"/>
							<gml:surfaceMember xlink:href="#poly-778e48b6-5ba1-4dc3-9500-ff9d611a34fc"/>
							<gml:surfaceMember xlink:href="#poly-352047f7-8af5-426b-bf49-d6719c50aebd"/>
							<gml:surfaceMember xlink:href="#poly-0c395553-88fb-4f78-8f0e-7dc51386dd7e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ee44bc47-ab5d-45e1-a110-e00ccb00dd04_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12342118-d00d-48c0-888e-44027904192e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181854067879 139.73989109012106 43.355 35.67182794901745 139.7398769065489 43.355 35.67183917978388 139.73988808352178 43.355 35.671829762438776 139.73990227815156 43.355 35.67181854067879 139.73989109012106 43.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-698f3946-9b14-40f1-a025-e9241c413798">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-698f3946-9b14-40f1-a025-e9241c413798_0">
											<gml:posList>35.67182794901745 139.7398769065489 43.355 35.67182794901745 139.7398769065489 45.923 35.67183917978388 139.73988808352178 45.923 35.67183917978388 139.73988808352178 43.355 35.67182794901745 139.7398769065489 43.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81f70d3d-d185-4737-bcde-808f8ce865cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81f70d3d-d185-4737-bcde-808f8ce865cb_0">
											<gml:posList>35.67181854067879 139.73989109012106 43.355 35.67181854067879 139.73989109012106 45.923 35.67182794901745 139.7398769065489 45.923 35.67182794901745 139.7398769065489 43.355 35.67181854067879 139.73989109012106 43.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59466972-1140-499c-8f65-7c6a002fe616">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59466972-1140-499c-8f65-7c6a002fe616_0">
											<gml:posList>35.67183917978388 139.73988808352178 45.923 35.67182794901745 139.7398769065489 45.923 35.67181854067879 139.73989109012106 45.923 35.671829762438776 139.73990227815156 45.923 35.67183917978388 139.73988808352178 45.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a4df47e-cca9-4d11-b955-a1c81c135e97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a4df47e-cca9-4d11-b955-a1c81c135e97_0">
											<gml:posList>35.67183917978388 139.73988808352178 45.923 35.671829762438776 139.73990227815156 45.923 35.671829762438776 139.73990227815156 43.355 35.67183917978388 139.73988808352178 43.355 35.67183917978388 139.73988808352178 45.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3c7a2ab-fdfa-4710-b51e-1791c7e9d29e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3c7a2ab-fdfa-4710-b51e-1791c7e9d29e_0">
											<gml:posList>35.671829762438776 139.73990227815156 43.355 35.671829762438776 139.73990227815156 45.923 35.67181854067879 139.73989109012106 45.923 35.67181854067879 139.73989109012106 43.355 35.671829762438776 139.73990227815156 43.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-975c4418-56dd-4e02-955b-26b4816f1bd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-975c4418-56dd-4e02-955b-26b4816f1bd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-975c4418-56dd-4e02-955b-26b4816f1bd5">
											<gml:posList>35.671758693550444 139.73994275783775 8.96 35.67173546530565 139.7399778021295 8.96 35.67164940852137 139.73989295525595 8.96 35.671732777871384 139.73976703907408 8.96 35.67185942889453 139.73989359419863 8.96 35.671799647620155 139.73998369248 8.96 35.671758693550444 139.73994275783775 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e6ac431-2aa8-46c4-892b-bda7b175a2fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e6ac431-2aa8-46c4-892b-bda7b175a2fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e6ac431-2aa8-46c4-892b-bda7b175a2fa">
											<gml:posList>35.67185414737731 139.73989427418832 40.574 35.67181342783157 139.73985359335907 40.574 35.67181970668917 139.73986042379545 40.574 35.671853444135685 139.73989405407866 40.574 35.67183858886203 139.73991645152063 40.574 35.6717991107835 139.73997720883602 40.574 35.67185414737731 139.73989427418832 40.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c249c7e-3640-45e3-8b86-c93a1d538dfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c249c7e-3640-45e3-8b86-c93a1d538dfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c249c7e-3640-45e3-8b86-c93a1d538dfe">
											<gml:posList>35.67164940852137 139.73989295525595 24.256 35.67170446142092 139.73994723958705 35.649 35.67173452273137 139.73990143914597 35.649 35.67164940852137 139.73989295525595 24.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-726b09df-26b2-4950-ac05-73355701a13e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-726b09df-26b2-4950-ac05-73355701a13e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-726b09df-26b2-4950-ac05-73355701a13e">
											<gml:posList>35.67164940852137 139.73989295525595 24.256 35.67173452273137 139.73990143914597 35.649 35.67181283685413 139.73984704349925 40.542 35.67164940852137 139.73989295525595 24.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4cc7453-c476-47ea-a379-684e343d5555">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4cc7453-c476-47ea-a379-684e343d5555">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4cc7453-c476-47ea-a379-684e343d5555">
											<gml:posList>35.67164940852137 139.73989295525595 24.256 35.67181283685413 139.73984704349925 40.542 35.671732777871384 139.73976703907408 24.256 35.67164940852137 139.73989295525595 24.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-57b0eb1b-84e9-4dcb-8529-106419519bc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57b0eb1b-84e9-4dcb-8529-106419519bc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57b0eb1b-84e9-4dcb-8529-106419519bc5">
											<gml:posList>35.67175421972922 139.73993887469916 35.649 35.67176156600537 139.7399273667873 35.649 35.67173452273137 139.73990143914597 35.649 35.67170446142092 139.73994723958705 35.649 35.67173546530565 139.7399778021295 35.649 35.671758693550444 139.73994275783775 35.649 35.67175421972922 139.73993887469916 35.649</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-49f0dab4-46ba-44a2-8056-9f9aa7f422c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49f0dab4-46ba-44a2-8056-9f9aa7f422c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49f0dab4-46ba-44a2-8056-9f9aa7f422c4">
											<gml:posList>35.67173452273137 139.73990143914597 35.649 35.67176156600537 139.7399273667873 40.542 35.67181283685413 139.73984704349925 40.542 35.67173452273137 139.73990143914597 35.649</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca24e852-ed4f-4394-8ed1-0f7d3f98774f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca24e852-ed4f-4394-8ed1-0f7d3f98774f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca24e852-ed4f-4394-8ed1-0f7d3f98774f">
											<gml:posList>35.6717991107835 139.73997720883602 40.821 35.67176098019095 139.73993908775284 40.821 35.67175961820238 139.73993790736935 40.821 35.67175421972922 139.73993887469916 40.821 35.671758693550444 139.73994275783775 40.821 35.671799647620155 139.73998369248 40.821 35.6717991107835 139.73997720883602 40.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-95337ef0-a63e-4672-aa04-cbb57805740b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95337ef0-a63e-4672-aa04-cbb57805740b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95337ef0-a63e-4672-aa04-cbb57805740b">
											<gml:posList>35.67175421972922 139.73993887469916 40.821 35.67175961820238 139.73993790736935 40.821 35.67181342783157 139.73985359335907 40.821 35.67181283685413 139.73984704349925 40.821 35.67175421972922 139.73993887469916 40.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5af1c25-5cb0-4014-a2fb-3975e1216deb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5af1c25-5cb0-4014-a2fb-3975e1216deb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5af1c25-5cb0-4014-a2fb-3975e1216deb">
											<gml:posList>35.67176098019095 139.73993908775284 40.574 35.671804842407965 139.73988282124466 40.574 35.67181970668917 139.73986042379545 40.574 35.67181342783157 139.73985359335907 40.574 35.67175961820238 139.73993790736935 40.574 35.67176098019095 139.73993908775284 40.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e11721b1-5eac-4393-871c-0f2ba5bf6b04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e11721b1-5eac-4393-871c-0f2ba5bf6b04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e11721b1-5eac-4393-871c-0f2ba5bf6b04">
											<gml:posList>35.6717991107835 139.73997720883602 40.574 35.67183858886203 139.73991645152063 40.574 35.671804842407965 139.73988282124466 40.574 35.67176098019095 139.73993908775284 40.574 35.6717991107835 139.73997720883602 40.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7745f5b3-1009-457e-849b-fe616ca8b676">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7745f5b3-1009-457e-849b-fe616ca8b676">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7745f5b3-1009-457e-849b-fe616ca8b676">
											<gml:posList>35.67182000684306 139.73986390307968 43.561 35.67181970668917 139.73986042379545 43.561 35.671804842407965 139.73988282124466 43.561 35.671807681464124 139.7398824754953 43.561 35.67182000684306 139.73986390307968 43.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7fa4d112-6846-4167-bb62-1c478a0e5491">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fa4d112-6846-4167-bb62-1c478a0e5491">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fa4d112-6846-4167-bb62-1c478a0e5491">
											<gml:posList>35.671804842407965 139.73988282124466 43.561 35.67183858886203 139.73991645152063 43.561 35.671838297723376 139.7399129722249 43.561 35.671807681464124 139.7398824754953 43.561 35.671804842407965 139.73988282124466 43.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6bc9586b-0a5c-4eb8-8631-83b0316ea1d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bc9586b-0a5c-4eb8-8631-83b0316ea1d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bc9586b-0a5c-4eb8-8631-83b0316ea1d1">
											<gml:posList>35.67182000684306 139.73986390307968 43.355 35.671807681464124 139.7398824754953 43.355 35.671838297723376 139.7399129722249 43.355 35.67185061409323 139.73989439981733 43.355 35.67182000684306 139.73986390307968 43.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c507d84c-a271-437d-8b10-99a3c9281167">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c507d84c-a271-437d-8b10-99a3c9281167">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c507d84c-a271-437d-8b10-99a3c9281167">
											<gml:posList>35.6717991107835 139.73997720883602 40.821 35.671799647620155 139.73998369248 40.821 35.67185942889453 139.73989359419863 40.821 35.67185414737731 139.73989427418832 40.821 35.6717991107835 139.73997720883602 40.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d622e5a-69cb-4685-980a-580d8d746dae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d622e5a-69cb-4685-980a-580d8d746dae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d622e5a-69cb-4685-980a-580d8d746dae">
											<gml:posList>35.67185414737731 139.73989427418832 40.821 35.67185942889453 139.73989359419863 40.821 35.67181283685413 139.73984704349925 40.821 35.67181342783157 139.73985359335907 40.821 35.67185414737731 139.73989427418832 40.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e0ceba6b-921b-4763-98ad-b1eb27589236">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0ceba6b-921b-4763-98ad-b1eb27589236">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0ceba6b-921b-4763-98ad-b1eb27589236">
											<gml:posList>35.67185061409323 139.73989439981733 43.561 35.671853444135685 139.73989405407866 43.561 35.67181970668917 139.73986042379545 43.561 35.67182000684306 139.73986390307968 43.561 35.67185061409323 139.73989439981733 43.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b7b0b5d-d8b5-42f8-8d9a-eb9d90fbf438">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b7b0b5d-d8b5-42f8-8d9a-eb9d90fbf438">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b7b0b5d-d8b5-42f8-8d9a-eb9d90fbf438">
											<gml:posList>35.67183858886203 139.73991645152063 43.561 35.671853444135685 139.73989405407866 43.561 35.67185061409323 139.73989439981733 43.561 35.671838297723376 139.7399129722249 43.561 35.67183858886203 139.73991645152063 43.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c58b54fd-3287-4370-bb64-ceec8dcf91f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c58b54fd-3287-4370-bb64-ceec8dcf91f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c58b54fd-3287-4370-bb64-ceec8dcf91f9">
											<gml:posList>35.67182000684306 139.73986390307968 43.355 35.67185061409323 139.73989439981733 43.355 35.67185061409323 139.73989439981733 43.561 35.67182000684306 139.73986390307968 43.561 35.67182000684306 139.73986390307968 43.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-495bd18e-b06c-4def-ac1f-657226ef3175">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-495bd18e-b06c-4def-ac1f-657226ef3175">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-495bd18e-b06c-4def-ac1f-657226ef3175">
											<gml:posList>35.67175961820238 139.73993790736935 40.574 35.67181342783157 139.73985359335907 40.574 35.67181342783157 139.73985359335907 40.821 35.67175961820238 139.73993790736935 40.821 35.67175961820238 139.73993790736935 40.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67ff964f-accc-446d-98ec-9a2fc278609a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67ff964f-accc-446d-98ec-9a2fc278609a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67ff964f-accc-446d-98ec-9a2fc278609a">
											<gml:posList>35.671838297723376 139.7399129722249 43.355 35.671807681464124 139.7398824754953 43.355 35.671807681464124 139.7398824754953 43.561 35.671838297723376 139.7399129722249 43.561 35.671838297723376 139.7399129722249 43.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc4af94f-60bc-48e7-8eca-f8ced65619dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc4af94f-60bc-48e7-8eca-f8ced65619dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc4af94f-60bc-48e7-8eca-f8ced65619dc">
											<gml:posList>35.67185414737731 139.73989427418832 40.574 35.6717991107835 139.73997720883602 40.574 35.6717991107835 139.73997720883602 40.821 35.67185414737731 139.73989427418832 40.821 35.67185414737731 139.73989427418832 40.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3cdbd69-9728-40e4-94ca-d560cef94e42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3cdbd69-9728-40e4-94ca-d560cef94e42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3cdbd69-9728-40e4-94ca-d560cef94e42">
											<gml:posList>35.67164940852137 139.73989295525595 8.96 35.67164940852137 139.73989295525595 24.256 35.671732777871384 139.73976703907408 24.256 35.671732777871384 139.73976703907408 8.96 35.67164940852137 139.73989295525595 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-682e1614-12da-4089-a37a-0f091aa53e91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-682e1614-12da-4089-a37a-0f091aa53e91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-682e1614-12da-4089-a37a-0f091aa53e91">
											<gml:posList>35.67185942889453 139.73989359419863 40.821 35.67185942889453 139.73989359419863 8.96 35.671732777871384 139.73976703907408 8.96 35.671732777871384 139.73976703907408 24.256 35.67181283685413 139.73984704349925 40.542 35.67181283685413 139.73984704349925 40.821 35.67185942889453 139.73989359419863 40.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86fc2099-f800-4d47-a1c9-62e3909a12e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86fc2099-f800-4d47-a1c9-62e3909a12e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86fc2099-f800-4d47-a1c9-62e3909a12e6">
											<gml:posList>35.67181970668917 139.73986042379545 40.574 35.671804842407965 139.73988282124466 40.574 35.671804842407965 139.73988282124466 43.561 35.67181970668917 139.73986042379545 43.561 35.67181970668917 139.73986042379545 40.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47375eef-9e87-4b99-9211-d95d24f15772">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47375eef-9e87-4b99-9211-d95d24f15772">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47375eef-9e87-4b99-9211-d95d24f15772">
											<gml:posList>35.671807681464124 139.7398824754953 43.355 35.67182000684306 139.73986390307968 43.355 35.67182000684306 139.73986390307968 43.561 35.671807681464124 139.7398824754953 43.561 35.671807681464124 139.7398824754953 43.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61c40bdb-b3c4-4a9f-8d2d-0a79c31a2f9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61c40bdb-b3c4-4a9f-8d2d-0a79c31a2f9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61c40bdb-b3c4-4a9f-8d2d-0a79c31a2f9a">
											<gml:posList>35.67181342783157 139.73985359335907 40.574 35.67185414737731 139.73989427418832 40.574 35.67185414737731 139.73989427418832 40.821 35.67181342783157 139.73985359335907 40.821 35.67181342783157 139.73985359335907 40.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48c2d408-c6e6-44cf-86e7-1fe0c36c227a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48c2d408-c6e6-44cf-86e7-1fe0c36c227a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48c2d408-c6e6-44cf-86e7-1fe0c36c227a">
											<gml:posList>35.671853444135685 139.73989405407866 40.574 35.67181970668917 139.73986042379545 40.574 35.67181970668917 139.73986042379545 43.561 35.671853444135685 139.73989405407866 43.561 35.671853444135685 139.73989405407866 40.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f152326a-cc1a-48c2-9363-ae350891617f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f152326a-cc1a-48c2-9363-ae350891617f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f152326a-cc1a-48c2-9363-ae350891617f">
											<gml:posList>35.67175421972922 139.73993887469916 40.821 35.67181283685413 139.73984704349925 40.821 35.67181283685413 139.73984704349925 40.542 35.67176156600537 139.7399273667873 40.542 35.67176156600537 139.7399273667873 35.649 35.67175421972922 139.73993887469916 35.649 35.67175421972922 139.73993887469916 40.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-787e7691-4883-4c54-8c8a-55fff3eb6f28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-787e7691-4883-4c54-8c8a-55fff3eb6f28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-787e7691-4883-4c54-8c8a-55fff3eb6f28">
											<gml:posList>35.67183858886203 139.73991645152063 43.561 35.671804842407965 139.73988282124466 43.561 35.671804842407965 139.73988282124466 40.574 35.67183858886203 139.73991645152063 40.574 35.67183858886203 139.73991645152063 43.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59d0915d-a6a0-4462-a514-21df34b97488">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59d0915d-a6a0-4462-a514-21df34b97488">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59d0915d-a6a0-4462-a514-21df34b97488">
											<gml:posList>35.67185061409323 139.73989439981733 43.355 35.671838297723376 139.7399129722249 43.355 35.671838297723376 139.7399129722249 43.561 35.67185061409323 139.73989439981733 43.561 35.67185061409323 139.73989439981733 43.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c28c7ec-1ada-4db3-8f65-9ce28f9c432f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c28c7ec-1ada-4db3-8f65-9ce28f9c432f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c28c7ec-1ada-4db3-8f65-9ce28f9c432f">
											<gml:posList>35.67183858886203 139.73991645152063 40.574 35.671853444135685 139.73989405407866 40.574 35.671853444135685 139.73989405407866 43.561 35.67183858886203 139.73991645152063 43.561 35.67183858886203 139.73991645152063 40.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fbff841-fc61-489c-a039-f46d76f28a67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fbff841-fc61-489c-a039-f46d76f28a67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fbff841-fc61-489c-a039-f46d76f28a67">
											<gml:posList>35.67176156600537 139.7399273667873 40.542 35.67173452273137 139.73990143914597 35.649 35.67176156600537 139.7399273667873 35.649 35.67176156600537 139.7399273667873 40.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-939fbcf5-2300-4fb8-8f0f-1cde99ef9565">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-939fbcf5-2300-4fb8-8f0f-1cde99ef9565">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-939fbcf5-2300-4fb8-8f0f-1cde99ef9565">
											<gml:posList>35.67164940852137 139.73989295525595 24.256 35.67164940852137 139.73989295525595 8.96 35.67173546530565 139.7399778021295 8.96 35.67173546530565 139.7399778021295 35.649 35.67170446142092 139.73994723958705 35.649 35.67164940852137 139.73989295525595 24.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8ad21ad-b770-40c8-8b1a-63bb76322d1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8ad21ad-b770-40c8-8b1a-63bb76322d1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8ad21ad-b770-40c8-8b1a-63bb76322d1f">
											<gml:posList>35.67175961820238 139.73993790736935 40.821 35.67176098019095 139.73993908775284 40.821 35.67176098019095 139.73993908775284 40.574 35.67175961820238 139.73993790736935 40.574 35.67175961820238 139.73993790736935 40.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64f83816-19d2-43dc-9779-c1056633d093">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64f83816-19d2-43dc-9779-c1056633d093">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64f83816-19d2-43dc-9779-c1056633d093">
											<gml:posList>35.671799647620155 139.73998369248 40.821 35.671799647620155 139.73998369248 8.96 35.67185942889453 139.73989359419863 8.96 35.67185942889453 139.73989359419863 40.821 35.671799647620155 139.73998369248 40.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a86aa649-236a-45e6-8196-1a17fac5c6d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a86aa649-236a-45e6-8196-1a17fac5c6d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a86aa649-236a-45e6-8196-1a17fac5c6d1">
											<gml:posList>35.67175421972922 139.73993887469916 40.821 35.67175421972922 139.73993887469916 35.649 35.671758693550444 139.73994275783775 35.649 35.671758693550444 139.73994275783775 40.821 35.67175421972922 139.73993887469916 40.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-778e48b6-5ba1-4dc3-9500-ff9d611a34fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-778e48b6-5ba1-4dc3-9500-ff9d611a34fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-778e48b6-5ba1-4dc3-9500-ff9d611a34fc">
											<gml:posList>35.67176098019095 139.73993908775284 40.821 35.6717991107835 139.73997720883602 40.821 35.6717991107835 139.73997720883602 40.574 35.67176098019095 139.73993908775284 40.574 35.67176098019095 139.73993908775284 40.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-352047f7-8af5-426b-bf49-d6719c50aebd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-352047f7-8af5-426b-bf49-d6719c50aebd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-352047f7-8af5-426b-bf49-d6719c50aebd">
											<gml:posList>35.671758693550444 139.73994275783775 8.96 35.671758693550444 139.73994275783775 35.649 35.67173546530565 139.7399778021295 35.649 35.67173546530565 139.7399778021295 8.96 35.671758693550444 139.73994275783775 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c395553-88fb-4f78-8f0e-7dc51386dd7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c395553-88fb-4f78-8f0e-7dc51386dd7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c395553-88fb-4f78-8f0e-7dc51386dd7e">
											<gml:posList>35.671758693550444 139.73994275783775 35.649 35.671758693550444 139.73994275783775 8.96 35.671799647620155 139.73998369248 8.96 35.671799647620155 139.73998369248 40.821 35.671758693550444 139.73994275783775 40.821 35.671758693550444 139.73994275783775 35.649</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8602</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">241.0958</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>