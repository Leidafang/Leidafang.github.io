<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_eece1a08-0d64-4b6f-b4e6-27e712f415d8">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>3</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66947840829788 139.74053638212598 0 35.66930892225295 139.74038336870922 0 35.669129956880624 139.74067872762518 0 35.66929782246118 139.7408348361064 0 35.66947840829788 139.74053638212598 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66947840829788 139.74053638212598 10.03 35.66929782246118 139.7408348361064 10.03 35.669129956880624 139.74067872762518 10.03 35.66930892225295 139.74038336870922 10.03 35.66947840829788 139.74053638212598 10.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66947840829788 139.74053638212598 10.03 35.66930892225295 139.74038336870922 10.03 35.66930892225295 139.74038336870922 13.03 35.66947840829788 139.74053638212598 13.03 35.66947840829788 139.74053638212598 10.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66930892225295 139.74038336870922 10.03 35.669129956880624 139.74067872762518 10.03 35.669129956880624 139.74067872762518 13.03 35.66930892225295 139.74038336870922 13.03 35.66930892225295 139.74038336870922 10.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669129956880624 139.74067872762518 10.03 35.66929782246118 139.7408348361064 10.03 35.66929782246118 139.7408348361064 13.03 35.669129956880624 139.74067872762518 13.03 35.669129956880624 139.74067872762518 10.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929782246118 139.7408348361064 10.03 35.66947840829788 139.74053638212598 10.03 35.66947840829788 139.74053638212598 13.03 35.66929782246118 139.7408348361064 13.03 35.66929782246118 139.7408348361064 10.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66947840829788 139.74053638212598 13.03 35.66930892225295 139.74038336870922 13.03 35.669129956880624 139.74067872762518 13.03 35.66929782246118 139.7408348361064 13.03 35.66947840829788 139.74053638212598 13.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-97006e8d-c958-4d1c-ae9c-cb532b419809"/>
							<gml:surfaceMember xlink:href="#poly-d732b457-20d3-43e5-a5f2-aa12efe5e3de"/>
							<gml:surfaceMember xlink:href="#poly-9c1fda87-d579-44c7-9dfc-a306d664082b"/>
							<gml:surfaceMember xlink:href="#poly-14058314-7540-4f8f-bcd8-1ddc6eaa5ee9"/>
							<gml:surfaceMember xlink:href="#poly-d2c71cf2-d19b-4403-8450-e53a7112144d"/>
							<gml:surfaceMember xlink:href="#poly-3808c890-43d5-4b27-a113-d13769921093"/>
							<gml:surfaceMember xlink:href="#poly-81630bdd-5a53-45b2-a3b4-25581ee10aa3"/>
							<gml:surfaceMember xlink:href="#poly-f25b3033-32b6-4a65-af79-49bb3a26444b"/>
							<gml:surfaceMember xlink:href="#poly-7c3b9a7f-56c0-496b-8381-47078d175536"/>
							<gml:surfaceMember xlink:href="#poly-291f2ce5-c0d4-41ff-ba22-950b6e64a0a3"/>
							<gml:surfaceMember xlink:href="#poly-ce4d0de1-5038-415c-bc61-054887763747"/>
							<gml:surfaceMember xlink:href="#poly-46b31b10-1f15-49c9-92a3-3d23247fb3d2"/>
							<gml:surfaceMember xlink:href="#poly-3214c80a-9eca-4e5c-95a2-4f6702a18f01"/>
							<gml:surfaceMember xlink:href="#poly-79591e52-9758-4d70-ac84-ac9b1c5f96fe"/>
							<gml:surfaceMember xlink:href="#poly-a455f027-5a06-47f8-8858-f46a9a482a73"/>
							<gml:surfaceMember xlink:href="#poly-a196234d-3de8-436e-9832-168aa4e44b2a"/>
							<gml:surfaceMember xlink:href="#poly-c91ef884-5642-4325-a93b-32c767ebfbeb"/>
							<gml:surfaceMember xlink:href="#poly-00c5a0ac-661f-4dd2-a6b9-3444216501f2"/>
							<gml:surfaceMember xlink:href="#poly-1356c0fb-61aa-435d-b416-283818b4660d"/>
							<gml:surfaceMember xlink:href="#poly-2f02c8d9-641c-41ff-a49e-083886aab6d1"/>
							<gml:surfaceMember xlink:href="#poly-ecd7e258-d94d-4c27-9c67-bc835c0b126b"/>
							<gml:surfaceMember xlink:href="#poly-88e33159-c40f-4ea3-b69d-7799325158f6"/>
							<gml:surfaceMember xlink:href="#poly-cac81cf9-ea3f-44ae-ae02-d0bad8a76222"/>
							<gml:surfaceMember xlink:href="#poly-2889b36b-107c-4ea9-bc89-fdc755417144"/>
							<gml:surfaceMember xlink:href="#poly-ecb1ecc0-21bc-4456-9b3c-3b98b1238958"/>
							<gml:surfaceMember xlink:href="#poly-8bcf432f-7014-4522-91e8-8deaa55ea9d4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-97006e8d-c958-4d1c-ae9c-cb532b419809">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97006e8d-c958-4d1c-ae9c-cb532b419809">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97006e8d-c958-4d1c-ae9c-cb532b419809">
											<gml:posList>35.669478408297856 139.74053638212595 10.03 35.66929782246118 139.7408348361064 10.03 35.669129956880596 139.74067872762518 10.03 35.66930892225294 139.74038336870922 10.03 35.669478408297856 139.74053638212595 10.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d732b457-20d3-43e5-a5f2-aa12efe5e3de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d732b457-20d3-43e5-a5f2-aa12efe5e3de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d732b457-20d3-43e5-a5f2-aa12efe5e3de">
											<gml:posList>35.66940782602943 139.74055361844745 10.527 35.66939051653789 139.7405378646131 10.527 35.66937941671125 139.7405561698366 10.527 35.66927298000071 139.74045930817596 10.527 35.66915092700991 139.7406607424503 10.527 35.669141222531934 139.74067675944926 10.527 35.66923916369229 139.74076784288954 10.527 35.66925634957574 139.74074009732652 10.527 35.6692811546944 139.74076266901852 10.527 35.66940782602943 139.74055361844745 10.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9c1fda87-d579-44c7-9dfc-a306d664082b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c1fda87-d579-44c7-9dfc-a306d664082b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c1fda87-d579-44c7-9dfc-a306d664082b">
											<gml:posList>35.66914444158515 139.7406548292423 10.527 35.66915092700991 139.7406607424503 10.527 35.66927298000071 139.74045930817596 10.527 35.669266485561 139.7404534060318 10.527 35.66914444158515 139.7406548292423 10.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14058314-7540-4f8f-bcd8-1ddc6eaa5ee9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14058314-7540-4f8f-bcd8-1ddc6eaa5ee9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14058314-7540-4f8f-bcd8-1ddc6eaa5ee9">
											<gml:posList>35.66931060048357 139.74039721858824 17.141 35.66930892225294 139.74038336870922 17.141 35.669266485561 139.7404534060318 17.141 35.66927298000071 139.74045930817596 17.141 35.66931060048357 139.74039721858824 17.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2c71cf2-d19b-4403-8450-e53a7112144d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2c71cf2-d19b-4403-8450-e53a7112144d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2c71cf2-d19b-4403-8450-e53a7112144d">
											<gml:posList>35.66930892225294 139.74038336870922 17.141 35.66931060048357 139.74039721858824 17.141 35.66946707965556 139.74053848295648 17.141 35.669478408297856 139.74053638212595 17.141 35.66930892225294 139.74038336870922 17.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3808c890-43d5-4b27-a113-d13769921093">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3808c890-43d5-4b27-a113-d13769921093">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3808c890-43d5-4b27-a113-d13769921093">
											<gml:posList>35.66927298000071 139.74045930817596 15.16 35.66937941671125 139.7405561698366 15.16 35.66939051653789 139.7405378646131 15.16 35.66940782602943 139.74055361844745 15.16 35.6692811546944 139.74076266901852 15.16 35.66925634957574 139.74074009732652 15.16 35.66923916369229 139.74076784288954 15.16 35.669296198286844 139.74082088674297 15.16 35.66946707965556 139.74053848295648 15.16 35.66931060048357 139.74039721858824 15.16 35.66927298000071 139.74045930817596 15.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81630bdd-5a53-45b2-a3b4-25581ee10aa3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81630bdd-5a53-45b2-a3b4-25581ee10aa3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81630bdd-5a53-45b2-a3b4-25581ee10aa3">
											<gml:posList>35.66914444158515 139.7406548292423 17.141 35.669129956880596 139.74067872762518 17.141 35.669141222531934 139.74067675944926 17.141 35.66915092700991 139.7406607424503 17.141 35.66914444158515 139.7406548292423 17.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f25b3033-32b6-4a65-af79-49bb3a26444b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f25b3033-32b6-4a65-af79-49bb3a26444b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f25b3033-32b6-4a65-af79-49bb3a26444b">
											<gml:posList>35.669478408297856 139.74053638212595 17.141 35.66946707965556 139.74053848295648 17.141 35.669296198286844 139.74082088674297 17.141 35.66929782246118 139.7408348361064 17.141 35.669478408297856 139.74053638212595 17.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c3b9a7f-56c0-496b-8381-47078d175536">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c3b9a7f-56c0-496b-8381-47078d175536">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c3b9a7f-56c0-496b-8381-47078d175536">
											<gml:posList>35.66929782246118 139.7408348361064 17.141 35.669296198286844 139.74082088674297 17.141 35.669141222531934 139.74067675944926 17.141 35.669129956880596 139.74067872762518 17.141 35.66929782246118 139.7408348361064 17.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-291f2ce5-c0d4-41ff-ba22-950b6e64a0a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-291f2ce5-c0d4-41ff-ba22-950b6e64a0a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-291f2ce5-c0d4-41ff-ba22-950b6e64a0a3">
											<gml:posList>35.66937941671125 139.7405561698366 15.16 35.66937941671125 139.7405561698366 10.527 35.66939051653789 139.7405378646131 10.527 35.66939051653789 139.7405378646131 15.16 35.66937941671125 139.7405561698366 15.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce4d0de1-5038-415c-bc61-054887763747">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce4d0de1-5038-415c-bc61-054887763747">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce4d0de1-5038-415c-bc61-054887763747">
											<gml:posList>35.66927298000071 139.74045930817596 17.141 35.66927298000071 139.74045930817596 15.16 35.66931060048357 139.74039721858824 15.16 35.66931060048357 139.74039721858824 17.141 35.66927298000071 139.74045930817596 17.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46b31b10-1f15-49c9-92a3-3d23247fb3d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46b31b10-1f15-49c9-92a3-3d23247fb3d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46b31b10-1f15-49c9-92a3-3d23247fb3d2">
											<gml:posList>35.669266485561 139.7404534060318 17.141 35.669266485561 139.7404534060318 10.527 35.66927298000071 139.74045930817596 10.527 35.66927298000071 139.74045930817596 15.16 35.66927298000071 139.74045930817596 17.141 35.669266485561 139.7404534060318 17.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3214c80a-9eca-4e5c-95a2-4f6702a18f01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3214c80a-9eca-4e5c-95a2-4f6702a18f01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3214c80a-9eca-4e5c-95a2-4f6702a18f01">
											<gml:posList>35.669478408297856 139.74053638212595 10.03 35.66930892225294 139.74038336870922 10.03 35.66930892225294 139.74038336870922 17.141 35.669478408297856 139.74053638212595 17.141 35.669478408297856 139.74053638212595 10.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79591e52-9758-4d70-ac84-ac9b1c5f96fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79591e52-9758-4d70-ac84-ac9b1c5f96fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79591e52-9758-4d70-ac84-ac9b1c5f96fe">
											<gml:posList>35.66931060048357 139.74039721858824 17.141 35.66931060048357 139.74039721858824 15.16 35.66946707965556 139.74053848295648 15.16 35.66946707965556 139.74053848295648 17.141 35.66931060048357 139.74039721858824 17.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a455f027-5a06-47f8-8858-f46a9a482a73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a455f027-5a06-47f8-8858-f46a9a482a73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a455f027-5a06-47f8-8858-f46a9a482a73">
											<gml:posList>35.66927298000071 139.74045930817596 15.16 35.66927298000071 139.74045930817596 10.527 35.66937941671125 139.7405561698366 10.527 35.66937941671125 139.7405561698366 15.16 35.66927298000071 139.74045930817596 15.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a196234d-3de8-436e-9832-168aa4e44b2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a196234d-3de8-436e-9832-168aa4e44b2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a196234d-3de8-436e-9832-168aa4e44b2a">
											<gml:posList>35.669266485561 139.7404534060318 10.527 35.669266485561 139.7404534060318 17.141 35.66930892225294 139.74038336870922 17.141 35.66930892225294 139.74038336870922 10.03 35.669129956880596 139.74067872762518 10.03 35.669129956880596 139.74067872762518 17.141 35.66914444158515 139.7406548292423 17.141 35.66914444158515 139.7406548292423 10.527 35.669266485561 139.7404534060318 10.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c91ef884-5642-4325-a93b-32c767ebfbeb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c91ef884-5642-4325-a93b-32c767ebfbeb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c91ef884-5642-4325-a93b-32c767ebfbeb">
											<gml:posList>35.66939051653789 139.7405378646131 15.16 35.66939051653789 139.7405378646131 10.527 35.66940782602943 139.74055361844745 10.527 35.66940782602943 139.74055361844745 15.16 35.66939051653789 139.7405378646131 15.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00c5a0ac-661f-4dd2-a6b9-3444216501f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00c5a0ac-661f-4dd2-a6b9-3444216501f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00c5a0ac-661f-4dd2-a6b9-3444216501f2">
											<gml:posList>35.66915092700991 139.7406607424503 17.141 35.66915092700991 139.7406607424503 10.527 35.66914444158515 139.7406548292423 10.527 35.66914444158515 139.7406548292423 17.141 35.66915092700991 139.7406607424503 17.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1356c0fb-61aa-435d-b416-283818b4660d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1356c0fb-61aa-435d-b416-283818b4660d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1356c0fb-61aa-435d-b416-283818b4660d">
											<gml:posList>35.66940782602943 139.74055361844745 15.16 35.66940782602943 139.74055361844745 10.527 35.6692811546944 139.74076266901852 10.527 35.6692811546944 139.74076266901852 15.16 35.66940782602943 139.74055361844745 15.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f02c8d9-641c-41ff-a49e-083886aab6d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f02c8d9-641c-41ff-a49e-083886aab6d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f02c8d9-641c-41ff-a49e-083886aab6d1">
											<gml:posList>35.669141222531934 139.74067675944926 10.527 35.66915092700991 139.7406607424503 10.527 35.66915092700991 139.7406607424503 17.141 35.669141222531934 139.74067675944926 17.141 35.669141222531934 139.74067675944926 10.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecd7e258-d94d-4c27-9c67-bc835c0b126b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecd7e258-d94d-4c27-9c67-bc835c0b126b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecd7e258-d94d-4c27-9c67-bc835c0b126b">
											<gml:posList>35.66946707965556 139.74053848295648 17.141 35.66946707965556 139.74053848295648 15.16 35.669296198286844 139.74082088674297 15.16 35.669296198286844 139.74082088674297 17.141 35.66946707965556 139.74053848295648 17.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88e33159-c40f-4ea3-b69d-7799325158f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88e33159-c40f-4ea3-b69d-7799325158f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88e33159-c40f-4ea3-b69d-7799325158f6">
											<gml:posList>35.66929782246118 139.7408348361064 10.03 35.669478408297856 139.74053638212595 10.03 35.669478408297856 139.74053638212595 17.141 35.66929782246118 139.7408348361064 17.141 35.66929782246118 139.7408348361064 10.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cac81cf9-ea3f-44ae-ae02-d0bad8a76222">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cac81cf9-ea3f-44ae-ae02-d0bad8a76222">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cac81cf9-ea3f-44ae-ae02-d0bad8a76222">
											<gml:posList>35.669141222531934 139.74067675944926 17.141 35.669296198286844 139.74082088674297 17.141 35.669296198286844 139.74082088674297 15.16 35.66923916369229 139.74076784288954 15.16 35.66923916369229 139.74076784288954 10.527 35.669141222531934 139.74067675944926 10.527 35.669141222531934 139.74067675944926 17.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2889b36b-107c-4ea9-bc89-fdc755417144">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2889b36b-107c-4ea9-bc89-fdc755417144">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2889b36b-107c-4ea9-bc89-fdc755417144">
											<gml:posList>35.6692811546944 139.74076266901852 15.16 35.6692811546944 139.74076266901852 10.527 35.66925634957574 139.74074009732652 10.527 35.66925634957574 139.74074009732652 15.16 35.6692811546944 139.74076266901852 15.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecb1ecc0-21bc-4456-9b3c-3b98b1238958">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecb1ecc0-21bc-4456-9b3c-3b98b1238958">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecb1ecc0-21bc-4456-9b3c-3b98b1238958">
											<gml:posList>35.66925634957574 139.74074009732652 15.16 35.66925634957574 139.74074009732652 10.527 35.66923916369229 139.74076784288954 10.527 35.66923916369229 139.74076784288954 15.16 35.66925634957574 139.74074009732652 15.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bcf432f-7014-4522-91e8-8deaa55ea9d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bcf432f-7014-4522-91e8-8deaa55ea9d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bcf432f-7014-4522-91e8-8deaa55ea9d4">
											<gml:posList>35.669129956880596 139.74067872762518 10.03 35.66929782246118 139.7408348361064 10.03 35.66929782246118 139.7408348361064 17.141 35.669129956880596 139.74067872762518 17.141 35.669129956880596 139.74067872762518 10.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5995</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">782.0617</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>