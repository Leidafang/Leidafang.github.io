<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ef42e4c0-3bd2-4dae-a8b1-88dcf5ebeb89">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">15</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66905981977408 139.738764015329 0 35.669036004610426 139.73873994088393 0 35.669022554574155 139.73876092219655 0 35.66898978303979 139.73880989492986 0 35.669050854061545 139.73887112865773 0 35.66911045512713 139.73878213746232 0 35.669073063527684 139.7387443487339 0 35.66905981977408 139.738764015329 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905981977408 139.738764015329 14.798 35.669073063527684 139.7387443487339 14.798 35.66911045512713 139.73878213746232 14.798 35.669050854061545 139.73887112865773 14.798 35.66898978303979 139.73880989492986 14.798 35.669022554574155 139.73876092219655 14.798 35.669036004610426 139.73873994088393 14.798 35.66905981977408 139.738764015329 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905981977408 139.738764015329 14.798 35.669036004610426 139.73873994088393 14.798 35.669036004610426 139.73873994088393 29.83 35.66905981977408 139.738764015329 29.83 35.66905981977408 139.738764015329 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669036004610426 139.73873994088393 14.798 35.669022554574155 139.73876092219655 14.798 35.669022554574155 139.73876092219655 29.83 35.669036004610426 139.73873994088393 29.83 35.669036004610426 139.73873994088393 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669022554574155 139.73876092219655 14.798 35.66898978303979 139.73880989492986 14.798 35.66898978303979 139.73880989492986 29.83 35.669022554574155 139.73876092219655 29.83 35.669022554574155 139.73876092219655 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898978303979 139.73880989492986 14.798 35.669050854061545 139.73887112865773 14.798 35.669050854061545 139.73887112865773 29.83 35.66898978303979 139.73880989492986 29.83 35.66898978303979 139.73880989492986 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669050854061545 139.73887112865773 14.798 35.66911045512713 139.73878213746232 14.798 35.66911045512713 139.73878213746232 29.83 35.669050854061545 139.73887112865773 29.83 35.669050854061545 139.73887112865773 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911045512713 139.73878213746232 14.798 35.669073063527684 139.7387443487339 14.798 35.669073063527684 139.7387443487339 29.83 35.66911045512713 139.73878213746232 29.83 35.66911045512713 139.73878213746232 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669073063527684 139.7387443487339 14.798 35.66905981977408 139.738764015329 14.798 35.66905981977408 139.738764015329 29.83 35.669073063527684 139.7387443487339 29.83 35.669073063527684 139.7387443487339 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905981977408 139.738764015329 29.83 35.669036004610426 139.73873994088393 29.83 35.669022554574155 139.73876092219655 29.83 35.66898978303979 139.73880989492986 29.83 35.669050854061545 139.73887112865773 29.83 35.66911045512713 139.73878213746232 29.83 35.669073063527684 139.7387443487339 29.83 35.66905981977408 139.738764015329 29.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c6fc7010-3647-4e75-925a-1362cc9c760c"/>
							<gml:surfaceMember xlink:href="#poly-2402a505-be17-44cb-b099-73e3c083ce24"/>
							<gml:surfaceMember xlink:href="#poly-73eb09aa-3a80-4939-b24a-4a5b71ee4024"/>
							<gml:surfaceMember xlink:href="#poly-3a3c71ca-dfb7-4d24-8149-5461055d807a"/>
							<gml:surfaceMember xlink:href="#poly-872f6b99-845f-4bd6-ad71-cbd393be72c1"/>
							<gml:surfaceMember xlink:href="#poly-d69d9ee9-7394-4a59-a097-a79a44bd6f40"/>
							<gml:surfaceMember xlink:href="#poly-b638dcd4-2ca8-4ace-ba92-eceee16a258d"/>
							<gml:surfaceMember xlink:href="#poly-8377a948-2d7a-4c47-a4ad-a584541bb6f7"/>
							<gml:surfaceMember xlink:href="#poly-dff0b890-8950-4473-887a-7468ac5ec0df"/>
							<gml:surfaceMember xlink:href="#poly-0077bb6d-43f9-4c4e-80f2-418eb62f0761"/>
							<gml:surfaceMember xlink:href="#poly-7e4a8740-b89e-4b25-b40c-bfa545f07bc6"/>
							<gml:surfaceMember xlink:href="#poly-2c20a640-94a3-4b85-a9e8-24cc420ea729"/>
							<gml:surfaceMember xlink:href="#poly-762f8867-4e21-4aee-b1d1-e182f9ada841"/>
							<gml:surfaceMember xlink:href="#poly-f7a2cf66-bfe5-4a5d-b423-ca611b4d6bff"/>
							<gml:surfaceMember xlink:href="#poly-fdfeb952-f805-413f-a467-c010f4e7874b"/>
							<gml:surfaceMember xlink:href="#poly-5ad3e683-f6fd-473f-b525-75e00936c1a4"/>
							<gml:surfaceMember xlink:href="#poly-35f42036-7ed1-44c2-8739-5fb79aad79ae"/>
							<gml:surfaceMember xlink:href="#poly-c1617ae7-4f1f-4398-94b6-8b15241bff0b"/>
							<gml:surfaceMember xlink:href="#poly-c58a5268-2853-4eb2-88d0-0051408b5274"/>
							<gml:surfaceMember xlink:href="#poly-22d75309-e81a-4e01-b939-3388f37f7c40"/>
							<gml:surfaceMember xlink:href="#poly-01958cd5-61a7-4b1f-8c3f-2a7c25485289"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ef42e4c0-3bd2-4dae-a8b1-88dcf5ebeb89_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b909d1ee-2d39-4182-8033-154d1567adf3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66906704423154 139.7388156140863 32.621 35.669067639848315 139.73881651916258 32.621 35.66906807332208 139.738817556983 32.621 35.66906831757699 139.7388186833951 32.621 35.66906836356464 139.7388198542252 32.621 35.66906821123301 139.73882100319693 32.621 35.66906786956114 139.73882208611536 32.621 35.66906734752807 139.73882305878558 32.621 35.669066672148986 139.73882388803756 32.621 35.6690658704217 139.738824518609 32.621 35.66906498739749 139.7388249283547 32.621 35.66906405010888 139.7388251061967 32.621 35.6690630946021 139.73882504104648 32.621 35.669062183981865 139.7388247438757 32.621 35.66906133626698 139.7388242036171 32.621 35.66906059656939 139.73882347544784 32.621 35.66906000095267 139.73882257037158 32.621 35.66905956747027 139.73882152150517 32.621 35.66905933222911 139.73882039508257 32.621 35.66905928625014 139.73881923529865 32.621 35.669059438581755 139.73881808632703 32.621 35.66905978025358 139.7388170034087 32.621 35.6690603022866 139.73881603073855 32.621 35.66906096865191 139.7388152014972 32.621 35.66906177037916 139.7388145709257 32.621 35.66906265340333 139.7388141611799 32.621 35.66906359970564 139.73881398332716 32.621 35.66906454619872 139.73881404848785 32.621 35.66906546583269 139.7388143456479 32.621 35.6690663045339 139.73881488591707 32.621 35.66906704423154 139.7388156140863 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d77098a-7e2d-40a5-bed1-4fcb082d435d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d77098a-7e2d-40a5-bed1-4fcb082d435d_0">
											<gml:posList>35.66906359970564 139.73881398332716 32.621 35.66906359970564 139.73881398332716 34.782 35.66906454619872 139.73881404848785 34.782 35.66906454619872 139.73881404848785 32.621 35.66906359970564 139.73881398332716 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77ace2d4-d604-40ed-b1ce-18dda816c102">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77ace2d4-d604-40ed-b1ce-18dda816c102_0">
											<gml:posList>35.66906265340333 139.7388141611799 32.621 35.66906265340333 139.7388141611799 34.782 35.66906359970564 139.73881398332716 34.782 35.66906359970564 139.73881398332716 32.621 35.66906265340333 139.7388141611799 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73791d14-ec3e-4d56-afca-b53cb35c430a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73791d14-ec3e-4d56-afca-b53cb35c430a_0">
											<gml:posList>35.66906454619872 139.73881404848785 32.621 35.66906454619872 139.73881404848785 34.782 35.66906546583269 139.7388143456479 34.782 35.66906546583269 139.7388143456479 32.621 35.66906454619872 139.73881404848785 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d59350b2-c6a3-4c27-a12a-2d888f4f72cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d59350b2-c6a3-4c27-a12a-2d888f4f72cb_0">
											<gml:posList>35.66906177037916 139.7388145709257 32.621 35.66906177037916 139.7388145709257 34.782 35.66906265340333 139.7388141611799 34.782 35.66906265340333 139.7388141611799 32.621 35.66906177037916 139.7388145709257 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d809a80e-6eac-4bdf-80a1-772097a9479f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d809a80e-6eac-4bdf-80a1-772097a9479f_0">
											<gml:posList>35.66906546583269 139.7388143456479 32.621 35.66906546583269 139.7388143456479 34.782 35.6690663045339 139.73881488591707 34.782 35.6690663045339 139.73881488591707 32.621 35.66906546583269 139.7388143456479 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f804098f-3820-4b78-ad55-f59285954c8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f804098f-3820-4b78-ad55-f59285954c8c_0">
											<gml:posList>35.66906096865191 139.7388152014972 34.782 35.66906177037916 139.7388145709257 34.782 35.66906177037916 139.7388145709257 32.621 35.66906096865191 139.7388152014972 32.621 35.66906096865191 139.7388152014972 34.782</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-115c8148-54de-4646-8cd1-03812b33c76e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-115c8148-54de-4646-8cd1-03812b33c76e_0">
											<gml:posList>35.6690663045339 139.73881488591707 32.621 35.6690663045339 139.73881488591707 34.782 35.66906704423154 139.7388156140863 34.782 35.66906704423154 139.7388156140863 32.621 35.6690663045339 139.73881488591707 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebca5265-1f9e-4b58-97a6-1b6aec0e283e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebca5265-1f9e-4b58-97a6-1b6aec0e283e_0">
											<gml:posList>35.6690603022866 139.73881603073855 32.621 35.6690603022866 139.73881603073855 34.782 35.66906096865191 139.7388152014972 34.782 35.66906096865191 139.7388152014972 32.621 35.6690603022866 139.73881603073855 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-431b5043-21d5-49c2-bf86-01af3e1052c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-431b5043-21d5-49c2-bf86-01af3e1052c2_0">
											<gml:posList>35.66906704423154 139.7388156140863 34.782 35.669067639848315 139.73881651916258 34.782 35.669067639848315 139.73881651916258 32.621 35.66906704423154 139.7388156140863 32.621 35.66906704423154 139.7388156140863 34.782</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fa01986-0617-4704-b274-769aece92a32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fa01986-0617-4704-b274-769aece92a32_0">
											<gml:posList>35.66905978025358 139.7388170034087 32.621 35.66905978025358 139.7388170034087 34.782 35.6690603022866 139.73881603073855 34.782 35.6690603022866 139.73881603073855 32.621 35.66905978025358 139.7388170034087 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-477728d1-084c-4a36-b9a3-f398d0305316">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-477728d1-084c-4a36-b9a3-f398d0305316_0">
											<gml:posList>35.669067639848315 139.73881651916258 34.782 35.66906807332208 139.738817556983 34.782 35.66906807332208 139.738817556983 32.621 35.669067639848315 139.73881651916258 32.621 35.669067639848315 139.73881651916258 34.782</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcb18645-2163-494c-9af3-e3cfb566ca8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcb18645-2163-494c-9af3-e3cfb566ca8c_0">
											<gml:posList>35.669059438581755 139.73881808632703 32.621 35.669059438581755 139.73881808632703 34.782 35.66905978025358 139.7388170034087 34.782 35.66905978025358 139.7388170034087 32.621 35.669059438581755 139.73881808632703 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-715c9c30-2fe6-455c-90f1-8525e00f34be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-715c9c30-2fe6-455c-90f1-8525e00f34be_0">
											<gml:posList>35.66906807332208 139.738817556983 34.782 35.66906831757699 139.7388186833951 34.782 35.66906831757699 139.7388186833951 32.621 35.66906807332208 139.738817556983 32.621 35.66906807332208 139.738817556983 34.782</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-312411d4-e1cf-4083-9754-36291dba1187">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-312411d4-e1cf-4083-9754-36291dba1187_0">
											<gml:posList>35.66905928625014 139.73881923529865 32.621 35.66905928625014 139.73881923529865 34.782 35.669059438581755 139.73881808632703 34.782 35.669059438581755 139.73881808632703 32.621 35.66905928625014 139.73881923529865 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3097d10-622d-4577-94be-b834c6688421">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3097d10-622d-4577-94be-b834c6688421_0">
											<gml:posList>35.66906831757699 139.7388186833951 32.621 35.66906831757699 139.7388186833951 34.782 35.66906836356464 139.7388198542252 34.782 35.66906836356464 139.7388198542252 32.621 35.66906831757699 139.7388186833951 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0b5c86b-1d70-4538-ae15-7d769982d60f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0b5c86b-1d70-4538-ae15-7d769982d60f_0">
											<gml:posList>35.66906546583269 139.7388143456479 34.782 35.66906454619872 139.73881404848785 34.782 35.66906359970564 139.73881398332716 34.782 35.66906265340333 139.7388141611799 34.782 35.66906177037916 139.7388145709257 34.782 35.66906096865191 139.7388152014972 34.782 35.6690603022866 139.73881603073855 34.782 35.66905978025358 139.7388170034087 34.782 35.669059438581755 139.73881808632703 34.782 35.66905928625014 139.73881923529865 34.782 35.66905933222911 139.73882039508257 34.782 35.66905956747027 139.73882152150517 34.782 35.66906000095267 139.73882257037158 34.782 35.66906059656939 139.73882347544784 34.782 35.66906133626698 139.7388242036171 34.782 35.669062183981865 139.7388247438757 34.782 35.6690630946021 139.73882504104648 34.782 35.66906405010888 139.7388251061967 34.782 35.66906498739749 139.7388249283547 34.782 35.6690658704217 139.738824518609 34.782 35.669066672148986 139.73882388803756 34.782 35.66906734752807 139.73882305878558 34.782 35.66906786956114 139.73882208611536 34.782 35.66906821123301 139.73882100319693 34.782 35.66906836356464 139.7388198542252 34.782 35.66906831757699 139.7388186833951 34.782 35.66906807332208 139.738817556983 34.782 35.669067639848315 139.73881651916258 34.782 35.66906704423154 139.7388156140863 34.782 35.6690663045339 139.73881488591707 34.782 35.66906546583269 139.7388143456479 34.782</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0007efb-7e53-406c-8ea3-b6539b03b92f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0007efb-7e53-406c-8ea3-b6539b03b92f_0">
											<gml:posList>35.66905933222911 139.73882039508257 32.621 35.66905933222911 139.73882039508257 34.782 35.66905928625014 139.73881923529865 34.782 35.66905928625014 139.73881923529865 32.621 35.66905933222911 139.73882039508257 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e0e18ec-f785-4771-bb8d-240ee7c4bb10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e0e18ec-f785-4771-bb8d-240ee7c4bb10_0">
											<gml:posList>35.66906836356464 139.7388198542252 32.621 35.66906836356464 139.7388198542252 34.782 35.66906821123301 139.73882100319693 34.782 35.66906821123301 139.73882100319693 32.621 35.66906836356464 139.7388198542252 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c51cf7c-5909-4de0-bbb8-fd15b771c7e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c51cf7c-5909-4de0-bbb8-fd15b771c7e8_0">
											<gml:posList>35.66905956747027 139.73882152150517 34.782 35.66905933222911 139.73882039508257 34.782 35.66905933222911 139.73882039508257 32.621 35.66905956747027 139.73882152150517 32.621 35.66905956747027 139.73882152150517 34.782</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54da8fd2-3cd5-4ecd-b76d-f1881cce34ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54da8fd2-3cd5-4ecd-b76d-f1881cce34ca_0">
											<gml:posList>35.66906821123301 139.73882100319693 34.782 35.66906786956114 139.73882208611536 34.782 35.66906786956114 139.73882208611536 32.621 35.66906821123301 139.73882100319693 32.621 35.66906821123301 139.73882100319693 34.782</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ccfc3ed-0a8d-4d7f-bb99-63fd8c079c9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ccfc3ed-0a8d-4d7f-bb99-63fd8c079c9f_0">
											<gml:posList>35.66906000095267 139.73882257037158 32.621 35.66906000095267 139.73882257037158 34.782 35.66905956747027 139.73882152150517 34.782 35.66905956747027 139.73882152150517 32.621 35.66906000095267 139.73882257037158 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a336724-874e-4a9b-a53a-159dd1bd7e3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a336724-874e-4a9b-a53a-159dd1bd7e3c_0">
											<gml:posList>35.66906786956114 139.73882208611536 34.782 35.66906734752807 139.73882305878558 34.782 35.66906734752807 139.73882305878558 32.621 35.66906786956114 139.73882208611536 32.621 35.66906786956114 139.73882208611536 34.782</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2440c071-f6e9-46ee-b964-59580c386481">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2440c071-f6e9-46ee-b964-59580c386481_0">
											<gml:posList>35.66906059656939 139.73882347544784 32.621 35.66906059656939 139.73882347544784 34.782 35.66906000095267 139.73882257037158 34.782 35.66906000095267 139.73882257037158 32.621 35.66906059656939 139.73882347544784 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b3c318e-657a-45b5-bfcc-5013242a85ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b3c318e-657a-45b5-bfcc-5013242a85ab_0">
											<gml:posList>35.66906734752807 139.73882305878558 32.621 35.66906734752807 139.73882305878558 34.782 35.669066672148986 139.73882388803756 34.782 35.669066672148986 139.73882388803756 32.621 35.66906734752807 139.73882305878558 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e9f7faf-6e61-4cdf-9082-11fd3ec2a255">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e9f7faf-6e61-4cdf-9082-11fd3ec2a255_0">
											<gml:posList>35.66906133626698 139.7388242036171 32.621 35.66906133626698 139.7388242036171 34.782 35.66906059656939 139.73882347544784 34.782 35.66906059656939 139.73882347544784 32.621 35.66906133626698 139.7388242036171 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc26c742-0cd4-4e1a-bfd4-66418478c4c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc26c742-0cd4-4e1a-bfd4-66418478c4c6_0">
											<gml:posList>35.669066672148986 139.73882388803756 34.782 35.6690658704217 139.738824518609 34.782 35.6690658704217 139.738824518609 32.621 35.669066672148986 139.73882388803756 32.621 35.669066672148986 139.73882388803756 34.782</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45f3f71f-62bb-4025-ac97-8c018732c9c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45f3f71f-62bb-4025-ac97-8c018732c9c7_0">
											<gml:posList>35.669062183981865 139.7388247438757 34.782 35.66906133626698 139.7388242036171 34.782 35.66906133626698 139.7388242036171 32.621 35.669062183981865 139.7388247438757 32.621 35.669062183981865 139.7388247438757 34.782</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-696c080a-8e53-4822-8e02-2050f46c20f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-696c080a-8e53-4822-8e02-2050f46c20f8_0">
											<gml:posList>35.6690658704217 139.738824518609 32.621 35.6690658704217 139.738824518609 34.782 35.66906498739749 139.7388249283547 34.782 35.66906498739749 139.7388249283547 32.621 35.6690658704217 139.738824518609 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a40fefc0-ae8b-4cef-8af7-1d17e343a09c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a40fefc0-ae8b-4cef-8af7-1d17e343a09c_0">
											<gml:posList>35.6690630946021 139.73882504104648 32.621 35.6690630946021 139.73882504104648 34.782 35.669062183981865 139.7388247438757 34.782 35.669062183981865 139.7388247438757 32.621 35.6690630946021 139.73882504104648 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4e747a1-36ea-4e63-92ff-edf76606fca3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4e747a1-36ea-4e63-92ff-edf76606fca3_0">
											<gml:posList>35.66906498739749 139.7388249283547 32.621 35.66906498739749 139.7388249283547 34.782 35.66906405010888 139.7388251061967 34.782 35.66906405010888 139.7388251061967 32.621 35.66906498739749 139.7388249283547 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c9e814c-d3cb-4b9b-8b56-bce217ef79c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c9e814c-d3cb-4b9b-8b56-bce217ef79c0_0">
											<gml:posList>35.66906405010888 139.7388251061967 32.621 35.66906405010888 139.7388251061967 34.782 35.6690630946021 139.73882504104648 34.782 35.6690630946021 139.73882504104648 32.621 35.66906405010888 139.7388251061967 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ef42e4c0-3bd2-4dae-a8b1-88dcf5ebeb89_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8290336f-2c57-413e-aae6-0d1d2e02b16f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907306352768 139.7387443487339 14.798 35.66905981977404 139.738764015329 14.798 35.66903597755189 139.73873991882368 14.798 35.669048842456164 139.73871991024913 14.798 35.66907306352768 139.7387443487339 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e025c73b-589d-4b05-82c1-5f8e2f79cd5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e025c73b-589d-4b05-82c1-5f8e2f79cd5e_0">
											<gml:posList>35.669036004610426 139.7387399408839 25.392 35.669048842456164 139.73871991024913 25.392 35.669048842456164 139.73871991024913 14.798 35.66903597755189 139.73873991882368 14.798 35.669036004610426 139.7387399408839 25.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50ba0f74-75ef-4652-8962-8060f92b1e8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50ba0f74-75ef-4652-8962-8060f92b1e8f_0">
											<gml:posList>35.669036004610426 139.7387399408839 25.392 35.66903597755189 139.73873991882368 14.798 35.66905981977404 139.738764015329 14.798 35.66905981977404 139.738764015329 30.229 35.669036004610426 139.7387399408839 25.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7db466fa-3064-4891-a69d-33d2ed1bace8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7db466fa-3064-4891-a69d-33d2ed1bace8_0">
											<gml:posList>35.66905981977404 139.738764015329 30.229 35.66907306352768 139.7387443487339 30.229 35.669048842456164 139.73871991024913 25.392 35.669036004610426 139.7387399408839 25.392 35.66905981977404 139.738764015329 30.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f090348-ad8e-4979-97d5-ea02fad336b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f090348-ad8e-4979-97d5-ea02fad336b3_0">
											<gml:posList>35.669048842456164 139.73871991024913 14.798 35.669048842456164 139.73871991024913 25.392 35.66907306352768 139.7387443487339 30.229 35.66907306352768 139.7387443487339 14.798 35.669048842456164 139.73871991024913 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dccd8bc6-e63d-4e30-823c-241145ecb99a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dccd8bc6-e63d-4e30-823c-241145ecb99a_0">
											<gml:posList>35.66905981977404 139.738764015329 14.798 35.66907306352768 139.7387443487339 14.798 35.66907306352768 139.7387443487339 30.229 35.66905981977404 139.738764015329 30.229 35.66905981977404 139.738764015329 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ef42e4c0-3bd2-4dae-a8b1-88dcf5ebeb89_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-908639ff-5a7e-445e-b4f8-32609a91bb16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904305837857 139.73886116323607 30.406 35.669018233055674 139.73883627254835 30.406 35.669035312029 139.7388106918049 30.406 35.669060137357114 139.73883558248997 30.406 35.66904305837857 139.73886116323607 30.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd69d7df-0b0b-4a86-ab42-89ddc01d1fcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd69d7df-0b0b-4a86-ab42-89ddc01d1fcc_0">
											<gml:posList>35.669035312029 139.7388106918049 30.406 35.669035312029 139.7388106918049 32.621 35.669060137357114 139.73883558248997 32.621 35.669060137357114 139.73883558248997 30.406 35.669035312029 139.7388106918049 30.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28a65e2c-83cc-4f1a-a5a2-bad646df9120">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28a65e2c-83cc-4f1a-a5a2-bad646df9120_0">
											<gml:posList>35.669035312029 139.7388106918049 30.406 35.669018233055674 139.73883627254835 30.406 35.669018233055674 139.73883627254835 32.621 35.669035312029 139.7388106918049 32.621 35.669035312029 139.7388106918049 30.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77fb86c7-8381-4687-97f4-3a8d6b430a3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77fb86c7-8381-4687-97f4-3a8d6b430a3a_0">
											<gml:posList>35.669035312029 139.7388106918049 32.621 35.669018233055674 139.73883627254835 32.621 35.66904305837857 139.73886116323607 32.621 35.669060137357114 139.73883558248997 32.621 35.669035312029 139.7388106918049 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0ca9a26-e6fc-43b2-897f-427d22e9456e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0ca9a26-e6fc-43b2-897f-427d22e9456e_0">
											<gml:posList>35.66904305837857 139.73886116323607 32.621 35.66904305837857 139.73886116323607 30.406 35.669060137357114 139.73883558248997 30.406 35.669060137357114 139.73883558248997 32.621 35.66904305837857 139.73886116323607 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c33e682-16eb-4c94-a0b7-a58cd835d714">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c33e682-16eb-4c94-a0b7-a58cd835d714_0">
											<gml:posList>35.669018233055674 139.73883627254835 30.406 35.66904305837857 139.73886116323607 30.406 35.66904305837857 139.73886116323607 32.621 35.669018233055674 139.73883627254835 32.621 35.669018233055674 139.73883627254835 30.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c6fc7010-3647-4e75-925a-1362cc9c760c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6fc7010-3647-4e75-925a-1362cc9c760c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6fc7010-3647-4e75-925a-1362cc9c760c">
											<gml:posList>35.66905981977404 139.738764015329 14.798 35.66907306352768 139.7387443487339 14.798 35.66911045512712 139.7387821374623 14.798 35.669050854061545 139.73887112865773 14.798 35.66898978303979 139.73880989492986 14.798 35.66902255457415 139.73876092219655 14.798 35.669036004610426 139.7387399408839 14.798 35.66905981977404 139.738764015329 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2402a505-be17-44cb-b099-73e3c083ce24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2402a505-be17-44cb-b099-73e3c083ce24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2402a505-be17-44cb-b099-73e3c083ce24">
											<gml:posList>35.6690459638038 139.73878459946377 30.229 35.66905981977404 139.738764015329 30.229 35.669036004610426 139.7387399408839 25.071 35.6690459638038 139.73878459946377 30.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73eb09aa-3a80-4939-b24a-4a5b71ee4024">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73eb09aa-3a80-4939-b24a-4a5b71ee4024">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73eb09aa-3a80-4939-b24a-4a5b71ee4024">
											<gml:posList>35.669036004610426 139.7387399408839 25.071 35.66902255457415 139.73876092219655 25.071 35.6690459638038 139.73878459946377 30.229 35.669036004610426 139.7387399408839 25.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a3c71ca-dfb7-4d24-8149-5461055d807a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a3c71ca-dfb7-4d24-8149-5461055d807a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a3c71ca-dfb7-4d24-8149-5461055d807a">
											<gml:posList>35.66907306352768 139.7387443487339 30.229 35.66905981977404 139.738764015329 30.229 35.6690459638038 139.73878459946377 30.229 35.66908344560606 139.73882248750667 30.229 35.66911045512712 139.7387821374623 30.229 35.66907306352768 139.7387443487339 30.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-872f6b99-845f-4bd6-ad71-cbd393be72c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-872f6b99-845f-4bd6-ad71-cbd393be72c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-872f6b99-845f-4bd6-ad71-cbd393be72c1">
											<gml:posList>35.669011956244105 139.7388321266232 30.406 35.669044610661 139.73878322029998 30.406 35.66902255457415 139.73876092219655 25.071 35.66898978303979 139.73880989492986 25.071 35.669011956244105 139.7388321266232 30.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d69d9ee9-7394-4a59-a097-a79a44bd6f40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d69d9ee9-7394-4a59-a097-a79a44bd6f40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d69d9ee9-7394-4a59-a097-a79a44bd6f40">
											<gml:posList>35.669080387525966 139.7388193982088 32.621 35.66905345113589 139.73879215719725 32.621 35.669046671710475 139.7388022392117 32.621 35.66905183166234 139.73880745792238 32.621 35.66904631267442 139.73881564957068 32.621 35.66906808910892 139.73883767187337 32.621 35.669080387525966 139.7388193982088 32.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b638dcd4-2ca8-4ace-ba92-eceee16a258d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b638dcd4-2ca8-4ace-ba92-eceee16a258d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b638dcd4-2ca8-4ace-ba92-eceee16a258d">
											<gml:posList>35.669050854061545 139.73887112865773 30.406 35.66908344560606 139.73882248750667 30.406 35.669080387525966 139.7388193982088 30.406 35.66906808910892 139.73883767187337 30.406 35.66904631267442 139.73881564957068 30.406 35.66905183166234 139.73880745792238 30.406 35.669046671710475 139.7388022392117 30.406 35.66905345113589 139.73879215719725 30.406 35.669044610661 139.73878322029998 30.406 35.669011956244105 139.7388321266232 30.406 35.669050854061545 139.73887112865773 30.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8377a948-2d7a-4c47-a4ad-a584541bb6f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8377a948-2d7a-4c47-a4ad-a584541bb6f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8377a948-2d7a-4c47-a4ad-a584541bb6f7">
											<gml:posList>35.669036004610426 139.7387399408839 14.798 35.66902255457415 139.73876092219655 14.798 35.66902255457415 139.73876092219655 25.071 35.669036004610426 139.7387399408839 25.071 35.669036004610426 139.7387399408839 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dff0b890-8950-4473-887a-7468ac5ec0df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dff0b890-8950-4473-887a-7468ac5ec0df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dff0b890-8950-4473-887a-7468ac5ec0df">
											<gml:posList>35.669036004610426 139.7387399408839 14.798 35.669036004610426 139.7387399408839 25.071 35.66905981977404 139.738764015329 30.229 35.66905981978272 139.73876402637504 27.335 35.66905981977404 139.738764015329 14.798 35.669036004610426 139.7387399408839 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0077bb6d-43f9-4c4e-80f2-418eb62f0761">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0077bb6d-43f9-4c4e-80f2-418eb62f0761">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0077bb6d-43f9-4c4e-80f2-418eb62f0761">
											<gml:posList>35.66905981978272 139.73876402637504 27.335 35.66905981977404 139.738764015329 30.229 35.66907306352768 139.7387443487339 30.229 35.66907306352768 139.7387443487339 14.798 35.66905981977404 139.738764015329 14.798 35.66905981978272 139.73876402637504 27.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e4a8740-b89e-4b25-b40c-bfa545f07bc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e4a8740-b89e-4b25-b40c-bfa545f07bc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e4a8740-b89e-4b25-b40c-bfa545f07bc6">
											<gml:posList>35.66911045512712 139.7387821374623 14.798 35.66907306352768 139.7387443487339 14.798 35.66907306352768 139.7387443487339 30.229 35.66911045512712 139.7387821374623 30.229 35.66911045512712 139.7387821374623 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c20a640-94a3-4b85-a9e8-24cc420ea729">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c20a640-94a3-4b85-a9e8-24cc420ea729">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c20a640-94a3-4b85-a9e8-24cc420ea729">
											<gml:posList>35.6690459638038 139.73878459946377 30.229 35.66902255457415 139.73876092219655 25.071 35.669044610661 139.73878322029998 30.406 35.6690459638038 139.73878459946377 30.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-762f8867-4e21-4aee-b1d1-e182f9ada841">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-762f8867-4e21-4aee-b1d1-e182f9ada841">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-762f8867-4e21-4aee-b1d1-e182f9ada841">
											<gml:posList>35.66902255457415 139.73876092219655 14.798 35.66898978303979 139.73880989492986 14.798 35.66898978303979 139.73880989492986 25.071 35.66902255457415 139.73876092219655 25.071 35.66902255457415 139.73876092219655 14.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7a2cf66-bfe5-4a5d-b423-ca611b4d6bff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7a2cf66-bfe5-4a5d-b423-ca611b4d6bff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7a2cf66-bfe5-4a5d-b423-ca611b4d6bff">
											<gml:posList>35.669046671710475 139.7388022392117 30.406 35.669046671710475 139.7388022392117 32.621 35.66905345113589 139.73879215719725 32.621 35.66905345113589 139.73879215719725 30.406 35.669046671710475 139.7388022392117 30.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fdfeb952-f805-413f-a467-c010f4e7874b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdfeb952-f805-413f-a467-c010f4e7874b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdfeb952-f805-413f-a467-c010f4e7874b">
											<gml:posList>35.66908344560606 139.73882248750667 30.229 35.6690459638038 139.73878459946377 30.229 35.669044610661 139.73878322029998 30.406 35.66905345113589 139.73879215719725 30.406 35.66905345113589 139.73879215719725 32.621 35.669080387525966 139.7388193982088 32.621 35.669080387525966 139.7388193982088 30.406 35.66908344560606 139.73882248750667 30.406 35.66908344560606 139.73882248750667 30.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ad3e683-f6fd-473f-b525-75e00936c1a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ad3e683-f6fd-473f-b525-75e00936c1a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ad3e683-f6fd-473f-b525-75e00936c1a4">
											<gml:posList>35.66905183166234 139.73880745792238 30.406 35.66905183166234 139.73880745792238 32.621 35.669046671710475 139.7388022392117 32.621 35.669046671710475 139.7388022392117 30.406 35.66905183166234 139.73880745792238 30.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35f42036-7ed1-44c2-8739-5fb79aad79ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35f42036-7ed1-44c2-8739-5fb79aad79ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35f42036-7ed1-44c2-8739-5fb79aad79ae">
											<gml:posList>35.66904631267442 139.73881564957068 30.406 35.66904631267442 139.73881564957068 32.621 35.66905183166234 139.73880745792238 32.621 35.66905183166234 139.73880745792238 30.406 35.66904631267442 139.73881564957068 30.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1617ae7-4f1f-4398-94b6-8b15241bff0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1617ae7-4f1f-4398-94b6-8b15241bff0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1617ae7-4f1f-4398-94b6-8b15241bff0b">
											<gml:posList>35.66906808910892 139.73883767187337 30.406 35.66906808910892 139.73883767187337 32.621 35.66904631267442 139.73881564957068 32.621 35.66904631267442 139.73881564957068 30.406 35.66906808910892 139.73883767187337 30.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c58a5268-2853-4eb2-88d0-0051408b5274">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c58a5268-2853-4eb2-88d0-0051408b5274">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c58a5268-2853-4eb2-88d0-0051408b5274">
											<gml:posList>35.669050854061545 139.73887112865773 30.406 35.669050854061545 139.73887112865773 14.798 35.66911045512712 139.7387821374623 14.798 35.66911045512712 139.7387821374623 30.229 35.66908344560606 139.73882248750667 30.229 35.66908344560606 139.73882248750667 30.406 35.669050854061545 139.73887112865773 30.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22d75309-e81a-4e01-b939-3388f37f7c40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22d75309-e81a-4e01-b939-3388f37f7c40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22d75309-e81a-4e01-b939-3388f37f7c40">
											<gml:posList>35.669080387525966 139.7388193982088 30.406 35.669080387525966 139.7388193982088 32.621 35.66906808910892 139.73883767187337 32.621 35.66906808910892 139.73883767187337 30.406 35.669080387525966 139.7388193982088 30.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01958cd5-61a7-4b1f-8c3f-2a7c25485289">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01958cd5-61a7-4b1f-8c3f-2a7c25485289">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01958cd5-61a7-4b1f-8c3f-2a7c25485289">
											<gml:posList>35.66898978303979 139.73880989492986 25.071 35.66898978303979 139.73880989492986 14.798 35.669050854061545 139.73887112865773 14.798 35.669050854061545 139.73887112865773 30.406 35.669011956244105 139.7388321266232 30.406 35.66898978303979 139.73880989492986 25.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-782</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">49.93095</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>