<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ef6bd9bb-e3d9-469f-a6cf-094c2a8e0823">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">11.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66898275320189 139.73881100782378 0 35.668947010324295 139.73886407105607 0 35.66900104541755 139.7389186854354 0 35.669036968420045 139.7388654010579 0 35.66898275320189 139.73881100782378 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898275320189 139.73881100782378 14.491 35.669036968420045 139.7388654010579 14.491 35.66900104541755 139.7389186854354 14.491 35.668947010324295 139.73886407105607 14.491 35.66898275320189 139.73881100782378 14.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898275320189 139.73881100782378 14.491 35.668947010324295 139.73886407105607 14.491 35.668947010324295 139.73886407105607 26.09 35.66898275320189 139.73881100782378 26.09 35.66898275320189 139.73881100782378 14.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668947010324295 139.73886407105607 14.491 35.66900104541755 139.7389186854354 14.491 35.66900104541755 139.7389186854354 26.09 35.668947010324295 139.73886407105607 26.09 35.668947010324295 139.73886407105607 14.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66900104541755 139.7389186854354 14.491 35.669036968420045 139.7388654010579 14.491 35.669036968420045 139.7388654010579 26.09 35.66900104541755 139.7389186854354 26.09 35.66900104541755 139.7389186854354 14.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669036968420045 139.7388654010579 14.491 35.66898275320189 139.73881100782378 14.491 35.66898275320189 139.73881100782378 26.09 35.669036968420045 139.7388654010579 26.09 35.669036968420045 139.7388654010579 14.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898275320189 139.73881100782378 26.09 35.668947010324295 139.73886407105607 26.09 35.66900104541755 139.7389186854354 26.09 35.669036968420045 139.7388654010579 26.09 35.66898275320189 139.73881100782378 26.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9053f7cd-9651-46a8-b29d-7b1f1833486e"/>
							<gml:surfaceMember xlink:href="#poly-fcc8600b-9d4d-4826-94d0-224a99611399"/>
							<gml:surfaceMember xlink:href="#poly-197e1374-7dba-4fcf-b6ce-eb665b149681"/>
							<gml:surfaceMember xlink:href="#poly-1e2fba2a-e583-4eee-81f6-19c4b1fa1015"/>
							<gml:surfaceMember xlink:href="#poly-382a995b-ec78-40ac-8aeb-1c34ac6ece49"/>
							<gml:surfaceMember xlink:href="#poly-25dba635-5669-4abe-bedb-1f6b6dfd31d8"/>
							<gml:surfaceMember xlink:href="#poly-5688a9a6-1a77-4c51-8ef4-311162865e3f"/>
							<gml:surfaceMember xlink:href="#poly-965b4675-f8ea-47f8-b775-17617df87a81"/>
							<gml:surfaceMember xlink:href="#poly-efc76409-9a80-417e-aaaa-5ce977379d0c"/>
							<gml:surfaceMember xlink:href="#poly-366c443b-6851-4225-9a51-5a127e0989cd"/>
							<gml:surfaceMember xlink:href="#poly-52bda38c-c990-43b1-a413-80df9d8ef0c6"/>
							<gml:surfaceMember xlink:href="#poly-00a42d45-9c5a-4c1a-8978-9d1b5e4e31b0"/>
							<gml:surfaceMember xlink:href="#poly-c8702202-90d7-44af-a994-1c546f081b4c"/>
							<gml:surfaceMember xlink:href="#poly-35a511cb-fc42-48d4-8eef-c1419346ea69"/>
							<gml:surfaceMember xlink:href="#poly-c63e7c95-2ba0-422c-a6e1-4337dfd9b7dd"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ef6bd9bb-e3d9-469f-a6cf-094c2a8e0823_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0bc2be7-9817-42b7-b321-c44c56531776">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668997546530434 139.73890520230538 26.543 35.668962762586894 139.73887079059597 26.543 35.668990878992375 139.73882811964987 26.543 35.66902429078195 139.73885988191205 26.543 35.66901172257939 139.73887896223857 26.543 35.66901045967887 139.7388777155203 26.543 35.66902181247574 139.73886048132 26.543 35.66899116119194 139.73883165405897 26.543 35.6689656376617 139.73887040059657 26.543 35.668997553014755 139.73890197684563 26.543 35.669001406297525 139.73889611789082 26.543 35.669002687251286 139.73889739772616 26.543 35.668997546530434 139.73890520230538 26.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97e29b55-d223-4e4c-991a-162ca2d96845">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97e29b55-d223-4e4c-991a-162ca2d96845_0">
											<gml:posList>35.668990878992375 139.73882811964987 26.543 35.668990878992375 139.73882811964987 27.472 35.66902429078195 139.73885988191205 27.472 35.66902429078195 139.73885988191205 26.543 35.668990878992375 139.73882811964987 26.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1554a54-e53f-4531-8286-cafba965837c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1554a54-e53f-4531-8286-cafba965837c_0">
											<gml:posList>35.66902181247574 139.73886048132 26.543 35.66902181247574 139.73886048132 27.472 35.66899116119194 139.73883165405897 27.472 35.66899116119194 139.73883165405897 26.543 35.66902181247574 139.73886048132 26.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c23e2c9f-fd85-4fee-951d-a65d949fefaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c23e2c9f-fd85-4fee-951d-a65d949fefaa_0">
											<gml:posList>35.668962762586894 139.73887079059597 27.472 35.668990878992375 139.73882811964987 27.472 35.668990878992375 139.73882811964987 26.543 35.668962762586894 139.73887079059597 26.543 35.668962762586894 139.73887079059597 27.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8541f33f-6075-4e5e-820e-a822ba50bd8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8541f33f-6075-4e5e-820e-a822ba50bd8f_0">
											<gml:posList>35.66899116119194 139.73883165405897 26.543 35.66899116119194 139.73883165405897 27.472 35.6689656376617 139.73887040059657 27.472 35.6689656376617 139.73887040059657 26.543 35.66899116119194 139.73883165405897 26.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72d65d23-3a7a-4f58-b06c-db1ec17b75f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72d65d23-3a7a-4f58-b06c-db1ec17b75f7_0">
											<gml:posList>35.669001406297525 139.73889611789082 27.472 35.668997553014755 139.73890197684563 27.472 35.6689656376617 139.73887040059657 27.472 35.66899116119194 139.73883165405897 27.472 35.66902181247574 139.73886048132 27.472 35.66901045967887 139.7388777155203 27.472 35.66901172257939 139.73887896223857 27.472 35.66902429078195 139.73885988191205 27.472 35.668990878992375 139.73882811964987 27.472 35.668962762586894 139.73887079059597 27.472 35.668997546530434 139.73890520230538 27.472 35.669002687251286 139.73889739772616 27.472 35.669001406297525 139.73889611789082 27.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dabd13c1-b0f9-43ed-b82c-fbce293f88e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dabd13c1-b0f9-43ed-b82c-fbce293f88e2_0">
											<gml:posList>35.66901045967887 139.7388777155203 26.543 35.66901045967887 139.7388777155203 27.472 35.66902181247574 139.73886048132 27.472 35.66902181247574 139.73886048132 26.543 35.66901045967887 139.7388777155203 26.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdbce19e-711d-414e-b4ce-f6162a0a29b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdbce19e-711d-414e-b4ce-f6162a0a29b5_0">
											<gml:posList>35.66902429078195 139.73885988191205 26.543 35.66902429078195 139.73885988191205 27.472 35.66901172257939 139.73887896223857 27.472 35.66901172257939 139.73887896223857 26.543 35.66902429078195 139.73885988191205 26.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12bf4061-bcde-4635-bde4-2c79c7d05651">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12bf4061-bcde-4635-bde4-2c79c7d05651_0">
											<gml:posList>35.66901172257939 139.73887896223857 26.543 35.66901172257939 139.73887896223857 27.472 35.66901045967887 139.7388777155203 27.472 35.66901045967887 139.7388777155203 26.543 35.66901172257939 139.73887896223857 26.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84f6905d-a003-4cb1-8d94-1bb6b8acdcd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84f6905d-a003-4cb1-8d94-1bb6b8acdcd6_0">
											<gml:posList>35.6689656376617 139.73887040059657 26.543 35.6689656376617 139.73887040059657 27.472 35.668997553014755 139.73890197684563 27.472 35.668997553014755 139.73890197684563 26.543 35.6689656376617 139.73887040059657 26.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc9061ea-3c15-4d40-9d11-ffcbdd7599cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc9061ea-3c15-4d40-9d11-ffcbdd7599cd_0">
											<gml:posList>35.668997546530434 139.73890520230538 26.543 35.668997546530434 139.73890520230538 27.472 35.668962762586894 139.73887079059597 27.472 35.668962762586894 139.73887079059597 26.543 35.668997546530434 139.73890520230538 26.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15b3e185-728b-43c6-8633-f2c17b1e03cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15b3e185-728b-43c6-8633-f2c17b1e03cf_0">
											<gml:posList>35.669001406297525 139.73889611789082 26.543 35.669001406297525 139.73889611789082 27.472 35.669002687251286 139.73889739772616 27.472 35.669002687251286 139.73889739772616 26.543 35.669001406297525 139.73889611789082 26.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2990f94-42df-45d0-847f-91a96d216b03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2990f94-42df-45d0-847f-91a96d216b03_0">
											<gml:posList>35.668997553014755 139.73890197684563 26.543 35.668997553014755 139.73890197684563 27.472 35.669001406297525 139.73889611789082 27.472 35.669001406297525 139.73889611789082 26.543 35.668997553014755 139.73890197684563 26.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30d53a74-2ab6-48cf-967b-e2d9a3c0f51e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30d53a74-2ab6-48cf-967b-e2d9a3c0f51e_0">
											<gml:posList>35.669002687251286 139.73889739772616 26.543 35.669002687251286 139.73889739772616 27.472 35.668997546530434 139.73890520230538 27.472 35.668997546530434 139.73890520230538 26.543 35.669002687251286 139.73889739772616 26.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9053f7cd-9651-46a8-b29d-7b1f1833486e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9053f7cd-9651-46a8-b29d-7b1f1833486e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9053f7cd-9651-46a8-b29d-7b1f1833486e">
											<gml:posList>35.66898275320188 139.73881100782376 14.491 35.66903696842004 139.73886540105786 14.491 35.669001045417545 139.73891868543538 14.491 35.66894701032429 139.73886407105607 14.491 35.66898275320188 139.73881100782376 14.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcc8600b-9d4d-4826-94d0-224a99611399">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcc8600b-9d4d-4826-94d0-224a99611399">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcc8600b-9d4d-4826-94d0-224a99611399">
											<gml:posList>35.66899105237448 139.73881933782152 26.781 35.66898275320188 139.73881100782376 24.838 35.66894701032429 139.73886407105607 24.838 35.668955462891226 139.73887261075012 26.781 35.66899105237448 139.73881933782152 26.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-197e1374-7dba-4fcf-b6ce-eb665b149681">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-197e1374-7dba-4fcf-b6ce-eb665b149681">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-197e1374-7dba-4fcf-b6ce-eb665b149681">
											<gml:posList>35.668955462891226 139.73887261075012 26.781 35.66895744571996 139.7388723654008 26.781 35.66899125258381 139.73882176772045 26.781 35.66899105237448 139.73881933782152 26.781 35.668955462891226 139.73887261075012 26.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e2fba2a-e583-4eee-81f6-19c4b1fa1015">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e2fba2a-e583-4eee-81f6-19c4b1fa1015">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e2fba2a-e583-4eee-81f6-19c4b1fa1015">
											<gml:posList>35.669001045417545 139.73891868543538 26.781 35.66900084520152 139.73891624448984 26.781 35.66895744571996 139.7388723654008 26.781 35.668955462891226 139.73887261075012 26.781 35.669001045417545 139.73891868543538 26.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-382a995b-ec78-40ac-8aeb-1c34ac6ece49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-382a995b-ec78-40ac-8aeb-1c34ac6ece49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-382a995b-ec78-40ac-8aeb-1c34ac6ece49">
											<gml:posList>35.66899105237448 139.73881933782152 26.781 35.66899125258381 139.73882176772045 26.781 35.66903497656896 139.73886563537218 26.781 35.66903696842004 139.73886540105786 26.781 35.66899105237448 139.73881933782152 26.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25dba635-5669-4abe-bedb-1f6b6dfd31d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25dba635-5669-4abe-bedb-1f6b6dfd31d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25dba635-5669-4abe-bedb-1f6b6dfd31d8">
											<gml:posList>35.66903497656896 139.73886563537218 26.543 35.66899125258381 139.73882176772045 26.543 35.66895744571996 139.7388723654008 26.543 35.66900084520152 139.73891624448984 26.543 35.66903497656896 139.73886563537218 26.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5688a9a6-1a77-4c51-8ef4-311162865e3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5688a9a6-1a77-4c51-8ef4-311162865e3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5688a9a6-1a77-4c51-8ef4-311162865e3f">
											<gml:posList>35.66903696842004 139.73886540105786 26.781 35.66903497656896 139.73886563537218 26.781 35.66900084520152 139.73891624448984 26.781 35.669001045417545 139.73891868543538 26.781 35.66903696842004 139.73886540105786 26.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-965b4675-f8ea-47f8-b775-17617df87a81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-965b4675-f8ea-47f8-b775-17617df87a81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-965b4675-f8ea-47f8-b775-17617df87a81">
											<gml:posList>35.66899125258381 139.73882176772045 26.781 35.66899125258381 139.73882176772045 26.543 35.66903497656896 139.73886563537218 26.543 35.66903497656896 139.73886563537218 26.781 35.66899125258381 139.73882176772045 26.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efc76409-9a80-417e-aaaa-5ce977379d0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efc76409-9a80-417e-aaaa-5ce977379d0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efc76409-9a80-417e-aaaa-5ce977379d0c">
											<gml:posList>35.66898275320188 139.73881100782376 14.491 35.66894701032429 139.73886407105607 14.491 35.66894701032429 139.73886407105607 24.838 35.66898275320188 139.73881100782376 24.838 35.66898275320188 139.73881100782376 14.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-366c443b-6851-4225-9a51-5a127e0989cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-366c443b-6851-4225-9a51-5a127e0989cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-366c443b-6851-4225-9a51-5a127e0989cd">
											<gml:posList>35.66898275320188 139.73881100782376 24.838 35.66899105237448 139.73881933782152 26.781 35.66903696842004 139.73886540105786 26.781 35.66903696842004 139.73886540105786 14.491 35.66898275320188 139.73881100782376 14.491 35.66898275320188 139.73881100782376 24.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52bda38c-c990-43b1-a413-80df9d8ef0c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52bda38c-c990-43b1-a413-80df9d8ef0c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52bda38c-c990-43b1-a413-80df9d8ef0c6">
											<gml:posList>35.66895744571996 139.7388723654008 26.781 35.66895744571996 139.7388723654008 26.543 35.66899125258381 139.73882176772045 26.543 35.66899125258381 139.73882176772045 26.781 35.66895744571996 139.7388723654008 26.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00a42d45-9c5a-4c1a-8978-9d1b5e4e31b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00a42d45-9c5a-4c1a-8978-9d1b5e4e31b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00a42d45-9c5a-4c1a-8978-9d1b5e4e31b0">
											<gml:posList>35.66903497656896 139.73886563537218 26.781 35.66903497656896 139.73886563537218 26.543 35.66900084520152 139.73891624448984 26.543 35.66900084520152 139.73891624448984 26.781 35.66903497656896 139.73886563537218 26.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8702202-90d7-44af-a994-1c546f081b4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8702202-90d7-44af-a994-1c546f081b4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8702202-90d7-44af-a994-1c546f081b4c">
											<gml:posList>35.66894701032429 139.73886407105607 24.838 35.66894701032429 139.73886407105607 14.491 35.669001045417545 139.73891868543538 14.491 35.669001045417545 139.73891868543538 26.781 35.668955462891226 139.73887261075012 26.781 35.66894701032429 139.73886407105607 24.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35a511cb-fc42-48d4-8eef-c1419346ea69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35a511cb-fc42-48d4-8eef-c1419346ea69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35a511cb-fc42-48d4-8eef-c1419346ea69">
											<gml:posList>35.669001045417545 139.73891868543538 14.491 35.66903696842004 139.73886540105786 14.491 35.66903696842004 139.73886540105786 26.781 35.669001045417545 139.73891868543538 26.781 35.669001045417545 139.73891868543538 14.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c63e7c95-2ba0-422c-a6e1-4337dfd9b7dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c63e7c95-2ba0-422c-a6e1-4337dfd9b7dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c63e7c95-2ba0-422c-a6e1-4337dfd9b7dd">
											<gml:posList>35.66900084520152 139.73891624448984 26.781 35.66900084520152 139.73891624448984 26.543 35.66895744571996 139.7388723654008 26.543 35.66895744571996 139.7388723654008 26.781 35.66900084520152 139.73891624448984 26.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6101</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">48.5212</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.12</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>