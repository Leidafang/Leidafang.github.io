<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f0f6714d-7389-45fb-9c32-f59204864f30">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">30.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66728787602043 139.73860740965506 0 35.6672860218689 139.73861081396197 0 35.66727166687585 139.73863867745916 0 35.66725092934093 139.73867697574326 0 35.6672493467106 139.73868179359243 0 35.66723643008423 139.73867039850066 0 35.66722914775698 139.73867137913024 0 35.667220201031945 139.73868782587803 0 35.667197201180834 139.7386689646715 0 35.66717575103936 139.7387066120498 0 35.66719869675025 139.73872540705108 0 35.66718404349662 139.7387522767255 0 35.66719998167436 139.73876616461516 0 35.667166408774 139.73882772940686 0 35.667238474817395 139.73888673964387 0 35.66737573644696 139.73863484315626 0 35.66730547415729 139.73857726687217 0 35.66728873287187 139.73860810453036 0 35.66728787602043 139.73860740965506 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66728787602043 139.73860740965506 12.11 35.66728873287187 139.73860810453036 12.11 35.66730547415729 139.73857726687217 12.11 35.66737573644696 139.73863484315626 12.11 35.667238474817395 139.73888673964387 12.11 35.667166408774 139.73882772940686 12.11 35.66719998167436 139.73876616461516 12.11 35.66718404349662 139.7387522767255 12.11 35.66719869675025 139.73872540705108 12.11 35.66717575103936 139.7387066120498 12.11 35.667197201180834 139.7386689646715 12.11 35.667220201031945 139.73868782587803 12.11 35.66722914775698 139.73867137913024 12.11 35.66723643008423 139.73867039850066 12.11 35.6672493467106 139.73868179359243 12.11 35.66725092934093 139.73867697574326 12.11 35.66727166687585 139.73863867745916 12.11 35.6672860218689 139.73861081396197 12.11 35.66728787602043 139.73860740965506 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66728787602043 139.73860740965506 12.11 35.6672860218689 139.73861081396197 12.11 35.6672860218689 139.73861081396197 42.71 35.66728787602043 139.73860740965506 42.71 35.66728787602043 139.73860740965506 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6672860218689 139.73861081396197 12.11 35.66727166687585 139.73863867745916 12.11 35.66727166687585 139.73863867745916 42.71 35.6672860218689 139.73861081396197 42.71 35.6672860218689 139.73861081396197 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66727166687585 139.73863867745916 12.11 35.66725092934093 139.73867697574326 12.11 35.66725092934093 139.73867697574326 42.71 35.66727166687585 139.73863867745916 42.71 35.66727166687585 139.73863867745916 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66725092934093 139.73867697574326 12.11 35.6672493467106 139.73868179359243 12.11 35.6672493467106 139.73868179359243 42.71 35.66725092934093 139.73867697574326 42.71 35.66725092934093 139.73867697574326 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6672493467106 139.73868179359243 12.11 35.66723643008423 139.73867039850066 12.11 35.66723643008423 139.73867039850066 42.71 35.6672493467106 139.73868179359243 42.71 35.6672493467106 139.73868179359243 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66723643008423 139.73867039850066 12.11 35.66722914775698 139.73867137913024 12.11 35.66722914775698 139.73867137913024 42.71 35.66723643008423 139.73867039850066 42.71 35.66723643008423 139.73867039850066 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66722914775698 139.73867137913024 12.11 35.667220201031945 139.73868782587803 12.11 35.667220201031945 139.73868782587803 42.71 35.66722914775698 139.73867137913024 42.71 35.66722914775698 139.73867137913024 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667220201031945 139.73868782587803 12.11 35.667197201180834 139.7386689646715 12.11 35.667197201180834 139.7386689646715 42.71 35.667220201031945 139.73868782587803 42.71 35.667220201031945 139.73868782587803 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667197201180834 139.7386689646715 12.11 35.66717575103936 139.7387066120498 12.11 35.66717575103936 139.7387066120498 42.71 35.667197201180834 139.7386689646715 42.71 35.667197201180834 139.7386689646715 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717575103936 139.7387066120498 12.11 35.66719869675025 139.73872540705108 12.11 35.66719869675025 139.73872540705108 42.71 35.66717575103936 139.7387066120498 42.71 35.66717575103936 139.7387066120498 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66719869675025 139.73872540705108 12.11 35.66718404349662 139.7387522767255 12.11 35.66718404349662 139.7387522767255 42.71 35.66719869675025 139.73872540705108 42.71 35.66719869675025 139.73872540705108 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718404349662 139.7387522767255 12.11 35.66719998167436 139.73876616461516 12.11 35.66719998167436 139.73876616461516 42.71 35.66718404349662 139.7387522767255 42.71 35.66718404349662 139.7387522767255 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66719998167436 139.73876616461516 12.11 35.667166408774 139.73882772940686 12.11 35.667166408774 139.73882772940686 42.71 35.66719998167436 139.73876616461516 42.71 35.66719998167436 139.73876616461516 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667166408774 139.73882772940686 12.11 35.667238474817395 139.73888673964387 12.11 35.667238474817395 139.73888673964387 42.71 35.667166408774 139.73882772940686 42.71 35.667166408774 139.73882772940686 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667238474817395 139.73888673964387 12.11 35.66737573644696 139.73863484315626 12.11 35.66737573644696 139.73863484315626 42.71 35.667238474817395 139.73888673964387 42.71 35.667238474817395 139.73888673964387 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737573644696 139.73863484315626 12.11 35.66730547415729 139.73857726687217 12.11 35.66730547415729 139.73857726687217 42.71 35.66737573644696 139.73863484315626 42.71 35.66737573644696 139.73863484315626 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66730547415729 139.73857726687217 12.11 35.66728873287187 139.73860810453036 12.11 35.66728873287187 139.73860810453036 42.71 35.66730547415729 139.73857726687217 42.71 35.66730547415729 139.73857726687217 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66728873287187 139.73860810453036 12.11 35.66728787602043 139.73860740965506 12.11 35.66728787602043 139.73860740965506 42.71 35.66728873287187 139.73860810453036 42.71 35.66728873287187 139.73860810453036 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66728787602043 139.73860740965506 42.71 35.6672860218689 139.73861081396197 42.71 35.66727166687585 139.73863867745916 42.71 35.66725092934093 139.73867697574326 42.71 35.6672493467106 139.73868179359243 42.71 35.66723643008423 139.73867039850066 42.71 35.66722914775698 139.73867137913024 42.71 35.667220201031945 139.73868782587803 42.71 35.667197201180834 139.7386689646715 42.71 35.66717575103936 139.7387066120498 42.71 35.66719869675025 139.73872540705108 42.71 35.66718404349662 139.7387522767255 42.71 35.66719998167436 139.73876616461516 42.71 35.667166408774 139.73882772940686 42.71 35.667238474817395 139.73888673964387 42.71 35.66737573644696 139.73863484315626 42.71 35.66730547415729 139.73857726687217 42.71 35.66728873287187 139.73860810453036 42.71 35.66728787602043 139.73860740965506 42.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fd4e562d-08a9-4fb9-9f6d-92316ef39332"/>
							<gml:surfaceMember xlink:href="#poly-997bbdcf-8d55-4af2-9a6b-a1517c73cb43"/>
							<gml:surfaceMember xlink:href="#poly-d30cecf4-48ed-4c67-acbc-d867ece8ce6c"/>
							<gml:surfaceMember xlink:href="#poly-e9d590ab-843f-4ead-8777-1ec983c28db9"/>
							<gml:surfaceMember xlink:href="#poly-12c6f02f-2be2-44ab-a00d-a642cea46b4d"/>
							<gml:surfaceMember xlink:href="#poly-cac5d1d8-716c-4166-ba40-c9a5355c4257"/>
							<gml:surfaceMember xlink:href="#poly-27dacf78-b41a-4bba-a402-dbd5c0313f06"/>
							<gml:surfaceMember xlink:href="#poly-d7a4a9a3-3cd1-442e-ab59-7e54d2375073"/>
							<gml:surfaceMember xlink:href="#poly-fd4e15f3-2b98-4fe6-86f4-5c2e56e307e1"/>
							<gml:surfaceMember xlink:href="#poly-992b82d5-50a8-4121-a4b7-d86af5dbad40"/>
							<gml:surfaceMember xlink:href="#poly-78cc4cab-b22a-421e-a3b7-7e90971dd423"/>
							<gml:surfaceMember xlink:href="#poly-6c23467f-bc2b-412f-b3a4-be27fef61c94"/>
							<gml:surfaceMember xlink:href="#poly-adca50ee-95c1-44bb-be07-0d6987cf76ad"/>
							<gml:surfaceMember xlink:href="#poly-de5d477c-8387-4755-a22e-4eff52cae6a8"/>
							<gml:surfaceMember xlink:href="#poly-978a9fbb-c08c-40e8-9d17-a383275505e9"/>
							<gml:surfaceMember xlink:href="#poly-2cbbbbbe-6c67-4c3d-bb63-a5b14f2dc0bc"/>
							<gml:surfaceMember xlink:href="#poly-5e18708b-5d43-4eac-bc0d-dc92f95c44ec"/>
							<gml:surfaceMember xlink:href="#poly-659c8342-dac3-46af-bec8-54eb24c99b92"/>
							<gml:surfaceMember xlink:href="#poly-23f3d1ef-e232-4e67-98df-d114b80b1d6a"/>
							<gml:surfaceMember xlink:href="#poly-411c14e9-99d8-4b3c-bc7b-512ad7d5180e"/>
							<gml:surfaceMember xlink:href="#poly-623bfd9e-d7f4-4e1c-ab2d-f44105577299"/>
							<gml:surfaceMember xlink:href="#poly-ced61312-ec4e-48f3-9cf2-311cf3b6e410"/>
							<gml:surfaceMember xlink:href="#poly-637ba0f1-3fba-438a-81cc-ba601ddcecfd"/>
							<gml:surfaceMember xlink:href="#poly-6af3adfb-d5e0-44ef-90b6-c14f510449db"/>
							<gml:surfaceMember xlink:href="#poly-93849297-d43d-424e-b54b-f06a26d84be9"/>
							<gml:surfaceMember xlink:href="#poly-50d874f1-661d-4be1-a544-ca5394636c98"/>
							<gml:surfaceMember xlink:href="#poly-bf82c3a5-891a-491f-b159-3e2e15c7cc0c"/>
							<gml:surfaceMember xlink:href="#poly-dce6d123-75ca-44cd-abe4-9ba76d7dc234"/>
							<gml:surfaceMember xlink:href="#poly-eee8ac62-97bc-4b9c-a14d-c1a5b9991e92"/>
							<gml:surfaceMember xlink:href="#poly-bce17da0-a29c-4cd8-8d6c-97387d1c3bee"/>
							<gml:surfaceMember xlink:href="#poly-de3b5fff-a76f-488c-9f99-db0823dfb1e3"/>
							<gml:surfaceMember xlink:href="#poly-c59a4814-75f5-4c55-b8c3-a8fd0a45e5ba"/>
							<gml:surfaceMember xlink:href="#poly-349d7d33-3c5a-4926-83f6-130ebdaa3a6c"/>
							<gml:surfaceMember xlink:href="#poly-b3fc0bf4-5401-475f-81bf-c5c453aa2af0"/>
							<gml:surfaceMember xlink:href="#poly-b202b07b-4577-4b3a-94d1-b3aa7835e10a"/>
							<gml:surfaceMember xlink:href="#poly-83154e6c-f00c-4bb1-8dff-26166ee61d3f"/>
							<gml:surfaceMember xlink:href="#poly-020851bc-bfc7-4bc1-be8d-debee888f6b6"/>
							<gml:surfaceMember xlink:href="#poly-20131d7d-62e0-46a9-88fc-cd2cb50c5997"/>
							<gml:surfaceMember xlink:href="#poly-45330ff9-40f0-4597-b5d6-f1c140de20ad"/>
							<gml:surfaceMember xlink:href="#poly-a77fd3e5-322a-428e-98f1-daab37daf1d0"/>
							<gml:surfaceMember xlink:href="#poly-076a708b-d4ba-4d32-b982-8edd335981e9"/>
							<gml:surfaceMember xlink:href="#poly-92fca46d-e4a2-4824-971d-5d6c1e517b06"/>
							<gml:surfaceMember xlink:href="#poly-f7ee4be8-5cff-455e-b21a-491a35fc0b77"/>
							<gml:surfaceMember xlink:href="#poly-129f9399-8d4d-451f-b7df-baaf2babd719"/>
							<gml:surfaceMember xlink:href="#poly-8d38e143-135a-465e-bedc-b8c66ec87920"/>
							<gml:surfaceMember xlink:href="#poly-4a986564-5ac1-4971-bb2a-8f12e7afaa06"/>
							<gml:surfaceMember xlink:href="#poly-ec637c31-8d36-401d-8d44-2e912521e3ac"/>
							<gml:surfaceMember xlink:href="#poly-41837378-55c7-4414-9e33-c25be68a272e"/>
							<gml:surfaceMember xlink:href="#poly-8d140e66-c580-4603-bade-a87224460b3e"/>
							<gml:surfaceMember xlink:href="#poly-d954af8b-23a7-4789-a3a6-3acecf1241b7"/>
							<gml:surfaceMember xlink:href="#poly-2c9f69ac-ec9f-4d8f-961f-07d336aa2662"/>
							<gml:surfaceMember xlink:href="#poly-53272f1c-6f30-475a-947a-96ac387f19f4"/>
							<gml:surfaceMember xlink:href="#poly-cb17879e-01fa-48b2-ae9e-fceb943320d6"/>
							<gml:surfaceMember xlink:href="#poly-34f4b38d-f82a-4951-aaad-175896301050"/>
							<gml:surfaceMember xlink:href="#poly-5005a208-6087-48cd-8fb3-7fe84de6e5d2"/>
							<gml:surfaceMember xlink:href="#poly-c0044eb1-fd46-4eaa-9053-4ba74d2ad7bf"/>
							<gml:surfaceMember xlink:href="#poly-1bf70979-29f0-4b8f-993e-9e79c4cc203c"/>
							<gml:surfaceMember xlink:href="#poly-e55203c9-0a25-4d5d-97f7-ca2f99154b8d"/>
							<gml:surfaceMember xlink:href="#poly-693e27b1-44d0-427e-93ce-b31e835ea84b"/>
							<gml:surfaceMember xlink:href="#poly-d017f21e-7926-485f-8fbd-662f638f53b6"/>
							<gml:surfaceMember xlink:href="#poly-0938e7cd-7417-4f48-8dbf-a2fcfdc661a5"/>
							<gml:surfaceMember xlink:href="#poly-0a7ee088-d8e8-4863-93fc-93cc76112efb"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f0f6714d-7389-45fb-9c32-f59204864f30_BuildingInstallation_1010">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fba9a6db-9fd3-4779-9437-5e2dea581cef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fba9a6db-9fd3-4779-9437-5e2dea581cef_0">
											<gml:posList>35.66721239237811 139.73877610226518 44.4 35.66720755803663 139.73877230820304 43.805 35.66720758507781 139.73877230817115 43.922 35.66721239237811 139.73877610226518 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e778534-5a03-40e7-a047-53836c85040a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e778534-5a03-40e7-a047-53836c85040a_0">
											<gml:posList>35.66722348659121 139.73878542290439 43.492 35.66721805682366 139.73878096679383 44.977 35.66722349560494 139.73878542289373 45.526 35.66722348659121 139.73878542290439 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfc9ab5b-aaf0-48d4-a782-c1c4603befa1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfc9ab5b-aaf0-48d4-a782-c1c4603befa1_0">
											<gml:posList>35.66722348659121 139.73878542290439 43.492 35.66722299050666 139.73878500374798 43.496 35.667218128976835 139.73878102193785 44.952 35.66722348659121 139.73878542290439 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4f2ea24-50fb-40cf-bbad-da37ff1e56a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4f2ea24-50fb-40cf-bbad-da37ff1e56a7_0">
											<gml:posList>35.66721257276541 139.73877624564815 44.385 35.667218128976835 139.73878102193785 44.952 35.66722299050666 139.73878500374798 43.496 35.66721257276541 139.73877624564815 44.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bf8927e-05aa-4b49-bc7f-19f0c6b1051d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bf8927e-05aa-4b49-bc7f-19f0c6b1051d_0">
											<gml:posList>35.667207531030144 139.73877235241818 43.59 35.66722348659121 139.73878542290439 43.492 35.66720754004387 139.73877235240755 43.492 35.667207531030144 139.73877235241818 43.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87d3a383-a287-41c5-9174-2061bedddb01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87d3a383-a287-41c5-9174-2061bedddb01_0">
											<gml:posList>35.667191735615425 139.7388484656992 43.627 35.66717391302337 139.73883387308302 43.925 35.66717392204577 139.7388338841182 43.627 35.667191735615425 139.7388484656992 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-316d463a-b85d-4145-aa0b-a4d305ec56d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-316d463a-b85d-4145-aa0b-a4d305ec56d5_0">
											<gml:posList>35.66725599133801 139.7386837077234 43.627 35.66731333701759 139.73872996627392 43.627 35.66731333701759 139.73872996627392 43.492 35.66725599133801 139.7386837077234 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6eb3596f-8fb0-4082-8c64-760ebdf354b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6eb3596f-8fb0-4082-8c64-760ebdf354b7_0">
											<gml:posList>35.66725597330188 139.73868369669887 43.497 35.66725599133801 139.7386837077234 43.627 35.66731333701759 139.73872996627392 43.492 35.66725597330188 139.73868369669887 43.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02b4ff78-47b6-4740-a9ad-477fa66ba653">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02b4ff78-47b6-4740-a9ad-477fa66ba653_0">
											<gml:posList>35.66723209590906 139.738878838346 43.627 35.66717493012691 139.73883202723283 43.627 35.66717493914064 139.73883202722217 43.492 35.66723209590906 139.738878838346 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f703f382-51bd-4a2c-b1a0-47462ea560a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f703f382-51bd-4a2c-b1a0-47462ea560a5_0">
											<gml:posList>35.66723209590906 139.738878838346 43.495 35.66723209590906 139.738878838346 43.627 35.66717493914064 139.73883202722217 43.492 35.66723209590906 139.738878838346 43.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54fa93a3-d773-4c2a-8f50-a53ac4ee9ebb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54fa93a3-d773-4c2a-8f50-a53ac4ee9ebb_0">
											<gml:posList>35.66728568130768 139.73870502427351 46.787 35.667202459835515 139.7388572455367 46.798 35.66723108782721 139.73888069523213 43.925 35.66728568130768 139.73870502427351 46.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5aa31e76-9b38-423f-8448-61f49055e340">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5aa31e76-9b38-423f-8448-61f49055e340_0">
											<gml:posList>35.66731433610941 139.73872814253212 43.925 35.66728568130768 139.73870502427351 46.787 35.66723108782721 139.73888069523213 43.925 35.66731433610941 139.73872814253212 43.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77f826da-59b8-4062-bdd8-7100e09195d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77f826da-59b8-4062-bdd8-7100e09195d4_0">
											<gml:posList>35.66724864375764 139.73873929900202 45.518 35.66722348659121 139.73878542290439 43.492 35.66722349560494 139.73878542289373 45.526 35.66724864375764 139.73873929900202 45.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d92cb769-9429-4003-9bc6-679621faca8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d92cb769-9429-4003-9bc6-679621faca8d_0">
											<gml:posList>35.66724864375764 139.73873929900202 45.518 35.66724864375764 139.73873929900202 43.492 35.66722348659121 139.73878542290439 43.492 35.66724864375764 139.73873929900202 45.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42da5507-5fed-47da-bfeb-ccd99ed302ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42da5507-5fed-47da-bfeb-ccd99ed302ea_0">
											<gml:posList>35.66725702649273 139.7386818949856 43.916 35.66725699042045 139.73868187293652 43.627 35.66725599133801 139.7386837077234 43.627 35.66725702649273 139.7386818949856 43.916</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70be5968-02d5-4450-93db-7e830df86ada">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70be5968-02d5-4450-93db-7e830df86ada_0">
											<gml:posList>35.66725702649273 139.7386818949856 43.916 35.66725599133801 139.7386837077234 43.627 35.66723275133113 139.73872628367553 43.919 35.66725702649273 139.7386818949856 43.916</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fd4b012-0f0b-4c85-a08e-e7265f8df0a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fd4b012-0f0b-4c85-a08e-e7265f8df0a3_0">
											<gml:posList>35.66725599133801 139.7386837077234 43.627 35.66723271525886 139.73872626162645 43.492 35.66723275133113 139.73872628367553 43.919 35.66725599133801 139.7386837077234 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83f15ff3-f179-41af-b542-a09c4da9c0e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83f15ff3-f179-41af-b542-a09c4da9c0e8_0">
											<gml:posList>35.66725599133801 139.7386837077234 43.627 35.66725597330188 139.73868369669887 43.497 35.66723271525886 139.73872626162645 43.492 35.66725599133801 139.7386837077234 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99c4cb2d-a6fb-4a62-8b05-31a90f50964e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99c4cb2d-a6fb-4a62-8b05-31a90f50964e_0">
											<gml:posList>35.66717391302337 139.73883387308302 43.925 35.667191735615425 139.7388484656992 43.627 35.667202459835515 139.7388572455367 46.798 35.66717391302337 139.73883387308302 43.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8f34323-5a5f-4648-be71-31b541760cb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8f34323-5a5f-4648-be71-31b541760cb6_0">
											<gml:posList>35.667202459835515 139.7388572455367 46.798 35.667191735615425 139.7388484656992 43.627 35.66723108782721 139.73888069523213 43.925 35.667202459835515 139.7388572455367 46.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f29753bb-0a90-43cd-83d0-321d39e50e32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f29753bb-0a90-43cd-83d0-321d39e50e32_0">
											<gml:posList>35.667191735615425 139.7388484656992 43.627 35.66723108781855 139.7388806841863 43.627 35.66723108782721 139.73888069523213 43.925 35.667191735615425 139.7388484656992 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e386abc4-b34c-4720-b679-b08b0a1e4c41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e386abc4-b34c-4720-b679-b08b0a1e4c41_0">
											<gml:posList>35.66717391302337 139.73883387308302 43.925 35.667202459835515 139.7388572455367 46.798 35.66722349560494 139.73878542289373 45.526 35.66717391302337 139.73883387308302 43.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a48506c-b7d5-43a5-8564-55813443d4dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a48506c-b7d5-43a5-8564-55813443d4dd_0">
											<gml:posList>35.66724864375764 139.73873929900202 45.518 35.66725702649273 139.7386818949856 43.916 35.66723275133113 139.73872628367553 43.919 35.66724864375764 139.73873929900202 45.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-037abf91-9830-4670-b5e7-438140262ad9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-037abf91-9830-4670-b5e7-438140262ad9_0">
											<gml:posList>35.66724864375764 139.73873929900202 45.518 35.66728568130768 139.73870502427351 46.787 35.66725702649273 139.7386818949856 43.916 35.66724864375764 139.73873929900202 45.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be3b6a77-54cf-4c48-b67a-248c88ec4abf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be3b6a77-54cf-4c48-b67a-248c88ec4abf_0">
											<gml:posList>35.66728568130768 139.73870502427351 46.787 35.66722349560494 139.73878542289373 45.526 35.667202459835515 139.7388572455367 46.798 35.66728568130768 139.73870502427351 46.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eccc570-2b3f-4aea-886d-203a16837321">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eccc570-2b3f-4aea-886d-203a16837321_0">
											<gml:posList>35.66721239237811 139.73877610226518 44.4 35.66720758507781 139.73877230817115 43.922 35.66717391302337 139.73883387308302 43.925 35.66721239237811 139.73877610226518 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fcf6b5c-b08d-4bdb-ab9b-2774ca475679">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fcf6b5c-b08d-4bdb-ab9b-2774ca475679_0">
											<gml:posList>35.66721239237811 139.73877610226518 44.4 35.66717391302337 139.73883387308302 43.925 35.66721805682366 139.73878096679383 44.977 35.66721239237811 139.73877610226518 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5ed5168-e7ab-4932-8846-cd6bab99f3db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5ed5168-e7ab-4932-8846-cd6bab99f3db_0">
											<gml:posList>35.66717391302337 139.73883387308302 43.925 35.66722349560494 139.73878542289373 45.526 35.66721805682366 139.73878096679383 44.977 35.66717391302337 139.73883387308302 43.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78e55304-9c1f-4cb9-9da1-36956b0731f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78e55304-9c1f-4cb9-9da1-36956b0731f5_0">
											<gml:posList>35.66722349560494 139.73878542289373 45.526 35.66728568130768 139.73870502427351 46.787 35.66724864375764 139.73873929900202 45.518 35.66722349560494 139.73878542289373 45.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-486e3f1d-2602-4255-b6b1-d6423921bf30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-486e3f1d-2602-4255-b6b1-d6423921bf30_0">
											<gml:posList>35.66723275133113 139.73872628367553 43.919 35.66724864375764 139.73873929900202 43.492 35.66724864375764 139.73873929900202 45.518 35.66723275133113 139.73872628367553 43.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-899dc24c-dda7-4181-8c3e-71082d09fd41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-899dc24c-dda7-4181-8c3e-71082d09fd41_0">
											<gml:posList>35.66723275133113 139.73872628367553 43.919 35.66723271525886 139.73872626162645 43.492 35.66724864375764 139.73873929900202 43.492 35.66723275133113 139.73872628367553 43.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfbeeda1-827c-4b34-a0a3-2071e51e0b8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfbeeda1-827c-4b34-a0a3-2071e51e0b8c_0">
											<gml:posList>35.66731333701759 139.73872996627392 43.492 35.66731333701759 139.73872996627392 43.627 35.66723209590906 139.738878838346 43.495 35.66731333701759 139.73872996627392 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a82f284d-0d06-44d4-8a70-095b3a289e22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a82f284d-0d06-44d4-8a70-095b3a289e22_0">
											<gml:posList>35.66723209590906 139.738878838346 43.495 35.66731333701759 139.73872996627392 43.627 35.66723209590906 139.738878838346 43.627 35.66723209590906 139.738878838346 43.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbca17bb-f2f3-47dc-ae20-1ac3c29c6d62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbca17bb-f2f3-47dc-ae20-1ac3c29c6d62_0">
											<gml:posList>35.66723108781855 139.7388806841863 43.627 35.66723209590906 139.738878838346 43.627 35.66723108782721 139.73888069523213 43.925 35.66723108781855 139.7388806841863 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0b00e08-ad81-482c-b6d7-38880b1de757">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0b00e08-ad81-482c-b6d7-38880b1de757_0">
											<gml:posList>35.66731333701759 139.73872996627392 43.627 35.66731433610941 139.73872814253212 43.627 35.66731433610941 139.73872814253212 43.925 35.66731333701759 139.73872996627392 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-196ffcf3-f501-441a-8585-b69a95682ae0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-196ffcf3-f501-441a-8585-b69a95682ae0_0">
											<gml:posList>35.66723108782721 139.73888069523213 43.925 35.66723209590906 139.738878838346 43.627 35.66731433610941 139.73872814253212 43.925 35.66723108782721 139.73888069523213 43.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce172f3e-41fd-4bc5-a41a-56f5889a4641">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce172f3e-41fd-4bc5-a41a-56f5889a4641_0">
											<gml:posList>35.66723209590906 139.738878838346 43.627 35.66731333701759 139.73872996627392 43.627 35.66731433610941 139.73872814253212 43.925 35.66723209590906 139.738878838346 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b528b8d-1ca5-459a-ac48-6a962d9e5d88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b528b8d-1ca5-459a-ac48-6a962d9e5d88_0">
											<gml:posList>35.66717392204577 139.7388338841182 43.627 35.66717391302337 139.73883387308302 43.925 35.66717493012691 139.73883202723283 43.627 35.66717392204577 139.7388338841182 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4138dd78-a06e-4552-ab98-d8ae758c851d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4138dd78-a06e-4552-ab98-d8ae758c851d_0">
											<gml:posList>35.667207531030144 139.73877235241818 43.59 35.66717493914064 139.73883202722217 43.492 35.66717493012691 139.73883202723283 43.627 35.667207531030144 139.73877235241818 43.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7aa4a3bd-c3c8-41bd-8d97-0de8a2cb4a75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7aa4a3bd-c3c8-41bd-8d97-0de8a2cb4a75_0">
											<gml:posList>35.66720754004387 139.73877235240755 43.492 35.66717493914064 139.73883202722217 43.492 35.667207531030144 139.73877235241818 43.59 35.66720754004387 139.73877235240755 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a833b019-44f0-4ca0-9643-a9138bd06026">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a833b019-44f0-4ca0-9643-a9138bd06026_0">
											<gml:posList>35.66717493012691 139.73883202723283 43.627 35.66717391302337 139.73883387308302 43.925 35.66720758507781 139.73877230817115 43.922 35.66717493012691 139.73883202723283 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44680086-d67b-4fd2-a2bc-1f8882c839c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44680086-d67b-4fd2-a2bc-1f8882c839c4_0">
											<gml:posList>35.66720755803663 139.73877230820304 43.805 35.66717493012691 139.73883202723283 43.627 35.66720758507781 139.73877230817115 43.922 35.66720755803663 139.73877230820304 43.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c207d4c-4142-4581-93be-ebe79710453b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c207d4c-4142-4581-93be-ebe79710453b_0">
											<gml:posList>35.667207531030144 139.73877235241818 43.59 35.66717493012691 139.73883202723283 43.627 35.66720755803663 139.73877230820304 43.805 35.667207531030144 139.73877235241818 43.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a922f862-0409-4b3d-b7d0-0280a25caabf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a922f862-0409-4b3d-b7d0-0280a25caabf_0">
											<gml:posList>35.66721257276541 139.73877624564815 44.385 35.66720755803663 139.73877230820304 43.805 35.66721239237811 139.73877610226518 44.4 35.66721257276541 139.73877624564815 44.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-942fbd33-19d2-4f06-b7c9-58c0138e18b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-942fbd33-19d2-4f06-b7c9-58c0138e18b0_0">
											<gml:posList>35.66722348659121 139.73878542290439 43.492 35.667207531030144 139.73877235241818 43.59 35.66722299050666 139.73878500374798 43.496 35.66722348659121 139.73878542290439 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba568e0c-1feb-421e-b025-8372a2ab2b31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba568e0c-1feb-421e-b025-8372a2ab2b31_0">
											<gml:posList>35.66722299050666 139.73878500374798 43.496 35.667207531030144 139.73877235241818 43.59 35.66721257276541 139.73877624564815 44.385 35.66722299050666 139.73878500374798 43.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d09065f-5ddf-44ae-9e5f-1a8ab7f9b759">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d09065f-5ddf-44ae-9e5f-1a8ab7f9b759_0">
											<gml:posList>35.66721257276541 139.73877624564815 44.385 35.667207531030144 139.73877235241818 43.59 35.66720755803663 139.73877230820304 43.805 35.66721257276541 139.73877624564815 44.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50fe7206-05d7-4e80-ac6b-0b951a1e9b5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50fe7206-05d7-4e80-ac6b-0b951a1e9b5b_0">
											<gml:posList>35.66731433610941 139.73872814253212 43.925 35.66731433610941 139.73872814253212 43.627 35.66728568130768 139.73870502427351 46.787 35.66731433610941 139.73872814253212 43.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdd60acf-6323-4304-b9d5-d61771e4d837">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdd60acf-6323-4304-b9d5-d61771e4d837_0">
											<gml:posList>35.66731433610941 139.73872814253212 43.627 35.66725699042045 139.73868187293652 43.627 35.66728568130768 139.73870502427351 46.787 35.66731433610941 139.73872814253212 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cffdfd5-1855-4898-83ee-39b503199fb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cffdfd5-1855-4898-83ee-39b503199fb4_0">
											<gml:posList>35.66725699042045 139.73868187293652 43.627 35.66725702649273 139.7386818949856 43.916 35.66728568130768 139.73870502427351 46.787 35.66725699042045 139.73868187293652 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc58090a-78ec-4d20-bd05-365f8dc0153c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717493012691 139.73883202723283 43.627 35.667191735615425 139.7388484656992 43.627 35.66717392204577 139.7388338841182 43.627 35.66717493012691 139.73883202723283 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac7943fa-0382-4246-bc24-0c3d4f6fec4c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66721257276541 139.73877624564815 44.385 35.66721239237811 139.73877610226518 44.4 35.66721805682366 139.73878096679383 44.977 35.66721257276541 139.73877624564815 44.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a4a80b8-b949-4537-baf3-ec5db0eb413b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66721805682366 139.73878096679383 44.977 35.66722348659121 139.73878542290439 43.492 35.667218128976835 139.73878102193785 44.952 35.66721805682366 139.73878096679383 44.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6f2db6d-d3b5-4032-b527-861ec7b92654">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66721257276541 139.73877624564815 44.385 35.66721805682366 139.73878096679383 44.977 35.667218128976835 139.73878102193785 44.952 35.66721257276541 139.73877624564815 44.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9c7d030-1db3-4a07-8059-3516e9dd9794">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66731333701759 139.73872996627392 43.627 35.66725699042045 139.73868187293652 43.627 35.66731433610941 139.73872814253212 43.627 35.66731333701759 139.73872996627392 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa0480c2-8f59-4c22-a590-a81a31c796f0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66731333701759 139.73872996627392 43.627 35.66725599133801 139.7386837077234 43.627 35.66725699042045 139.73868187293652 43.627 35.66731333701759 139.73872996627392 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3de3702f-ea16-40a2-a206-d3f41e080fed">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717493914064 139.73883202722217 43.492 35.66720754004387 139.73877235240755 43.492 35.66722348659121 139.73878542290439 43.492 35.66717493914064 139.73883202722217 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c3eb743-cd16-4b81-8a89-1663a3ea038e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717493914064 139.73883202722217 43.492 35.66722348659121 139.73878542290439 43.492 35.66723209590906 139.738878838346 43.495 35.66717493914064 139.73883202722217 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0597b262-4ffd-42f0-83bd-643941b57101">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66723271525886 139.73872626162645 43.492 35.66725597330188 139.73868369669887 43.497 35.66724864375764 139.73873929900202 43.492 35.66723271525886 139.73872626162645 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d5b93e7-d31d-4c21-962e-d618cb315626">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66722348659121 139.73878542290439 43.492 35.66731333701759 139.73872996627392 43.492 35.66723209590906 139.738878838346 43.495 35.66722348659121 139.73878542290439 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40df391a-3ca0-4621-b3a9-5736a245b8bc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66724864375764 139.73873929900202 43.492 35.66725597330188 139.73868369669887 43.497 35.66731333701759 139.73872996627392 43.492 35.66724864375764 139.73873929900202 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-089653cd-6b94-4497-a979-ebcbcd994a44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66722348659121 139.73878542290439 43.492 35.66724864375764 139.73873929900202 43.492 35.66731333701759 139.73872996627392 43.492 35.66722348659121 139.73878542290439 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51b43f46-1efd-4508-9483-03ef79acb884">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66723209590906 139.738878838346 43.627 35.667191735615425 139.7388484656992 43.627 35.66717493012691 139.73883202723283 43.627 35.66723209590906 139.738878838346 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac7a29b5-5901-4901-8ffd-d81a3ebf0e7b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66723209590906 139.738878838346 43.627 35.66723108781855 139.7388806841863 43.627 35.667191735615425 139.7388484656992 43.627 35.66723209590906 139.738878838346 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f0f6714d-7389-45fb-9c32-f59204864f30_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e0311de-26ca-4d7a-bb6a-3e058d62703e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66728787602041 139.73860740965506 12.11 35.667286021868875 139.73861081396197 12.11 35.66727166687585 139.73863867745914 12.11 35.667250929340916 139.73867697574323 12.11 35.66724934671056 139.73868179359243 12.11 35.6672364300842 139.73867039850063 12.11 35.66722914775696 139.73867137913024 12.11 35.66727132516926 139.73859387597227 12.11 35.66728787602041 139.73860740965506 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f227509b-48d2-443d-a361-34ed27974e98">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716110587507 139.73873229980813 12.11 35.66717575103936 139.7387066120498 12.11 35.66719868776255 139.73872544019912 12.11 35.66718484457308 139.7387508177325 12.11 35.6671840434966 139.7387522767255 12.11 35.66716110587507 139.73873229980813 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4636ef00-d52e-48bc-a0a7-60d37b935ac1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4636ef00-d52e-48bc-a0a7-60d37b935ac1_0">
											<gml:posList>35.66727132516926 139.73859387597227 12.11 35.66727132516926 139.73859387597227 21.805 35.66728787602041 139.73860740965506 21.805 35.66728787602041 139.73860740965506 12.11 35.66727132516926 139.73859387597227 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92509f06-0258-42f5-99b9-2842f9617677">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92509f06-0258-42f5-99b9-2842f9617677_0">
											<gml:posList>35.66728787602041 139.73860740965506 12.11 35.66728787602041 139.73860740965506 21.805 35.667286021868875 139.73861081396197 21.805 35.667286021868875 139.73861081396197 12.11 35.66728787602041 139.73860740965506 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f66375f0-b356-4408-b200-0a7c88324674">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f66375f0-b356-4408-b200-0a7c88324674_0">
											<gml:posList>35.66728787602041 139.73860740965506 21.805 35.66727132516926 139.73859387597227 21.805 35.66725455682091 139.7386246915541 21.805 35.66727166687585 139.73863867745914 21.805 35.667286021868875 139.73861081396197 21.805 35.66728787602041 139.73860740965506 21.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32733cc1-4cfe-4c5a-bb5c-46122569bcaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32733cc1-4cfe-4c5a-bb5c-46122569bcaf_0">
											<gml:posList>35.66727166687585 139.73863867745914 21.805 35.66727166687585 139.73863867745914 12.11 35.667286021868875 139.73861081396197 12.11 35.667286021868875 139.73861081396197 21.805 35.66727166687585 139.73863867745914 21.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcca2cbd-bf2b-4550-8eba-21748d2be421">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcca2cbd-bf2b-4550-8eba-21748d2be421_0">
											<gml:posList>35.66725455682091 139.7386246915541 21.805 35.66725455682091 139.7386246915541 27.468 35.66727166687585 139.73863867745914 27.468 35.66727166687585 139.73863867745914 21.805 35.66725455682091 139.7386246915541 21.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a617c1f3-970e-432a-b905-5d50e77db23e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a617c1f3-970e-432a-b905-5d50e77db23e_0">
											<gml:posList>35.66725455682091 139.7386246915541 21.805 35.66727132516926 139.73859387597227 21.805 35.66727132516926 139.73859387597227 12.11 35.66722914775696 139.73867137913024 12.11 35.66722914775696 139.73867137913024 27.468 35.66725455682091 139.7386246915541 27.468 35.66725455682091 139.7386246915541 21.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2c6e8bb-c486-408b-a186-10de62545f38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2c6e8bb-c486-408b-a186-10de62545f38_0">
											<gml:posList>35.6672364300842 139.73867039850063 27.468 35.66724934671056 139.73868179359243 27.468 35.667250929340916 139.73867697574323 27.468 35.66727166687585 139.73863867745914 27.468 35.66725455682091 139.7386246915541 27.468 35.66722914775696 139.73867137913024 27.468 35.6672364300842 139.73867039850063 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-430b3ab4-4be2-433a-939f-1dab68d9e20a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-430b3ab4-4be2-433a-939f-1dab68d9e20a_0">
											<gml:posList>35.66727166687585 139.73863867745914 21.805 35.66727166687585 139.73863867745914 27.468 35.667250929340916 139.73867697574323 27.468 35.667250929340916 139.73867697574323 12.11 35.66727166687585 139.73863867745914 12.11 35.66727166687585 139.73863867745914 21.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1957863-68f6-4b3b-95b8-fc7bc945ce22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1957863-68f6-4b3b-95b8-fc7bc945ce22_0">
											<gml:posList>35.6672364300842 139.73867039850063 27.468 35.66722914775696 139.73867137913024 27.468 35.66722914775696 139.73867137913024 12.11 35.6672364300842 139.73867039850063 12.11 35.6672364300842 139.73867039850063 27.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78fd4ba9-cce1-4825-b6bb-0ded0c9424e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78fd4ba9-cce1-4825-b6bb-0ded0c9424e2_0">
											<gml:posList>35.6672364300842 139.73867039850063 12.11 35.66724934671056 139.73868179359243 12.11 35.66724934671056 139.73868179359243 27.468 35.6672364300842 139.73867039850063 27.468 35.6672364300842 139.73867039850063 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3a981b7-7f91-494c-b271-c01ea26d0cdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3a981b7-7f91-494c-b271-c01ea26d0cdf_0">
											<gml:posList>35.667250929340916 139.73867697574323 12.11 35.667250929340916 139.73867697574323 27.468 35.66724934671056 139.73868179359243 27.468 35.66724934671056 139.73868179359243 12.11 35.667250929340916 139.73867697574323 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79f59ae0-3109-48e8-a5f0-4a08d555179c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79f59ae0-3109-48e8-a5f0-4a08d555179c_0">
											<gml:posList>35.66719868776255 139.73872544019912 12.11 35.66717575103936 139.7387066120498 12.11 35.66717575103936 139.7387066120498 43.627 35.66719868776255 139.73872544019912 43.627 35.66719868776255 139.73872544019912 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9319f20d-6b1d-4fa7-9dd6-ab33ddabf114">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9319f20d-6b1d-4fa7-9dd6-ab33ddabf114_0">
											<gml:posList>35.66717575103936 139.7387066120498 12.11 35.66716110587507 139.73873229980813 12.11 35.66716110587507 139.73873229980813 43.627 35.66717575103936 139.7387066120498 43.627 35.66717575103936 139.7387066120498 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2858036-804f-4bd0-a149-bcaceb1c88d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2858036-804f-4bd0-a149-bcaceb1c88d3_0">
											<gml:posList>35.66718484457308 139.7387508177325 43.627 35.66719868776255 139.73872544019912 43.627 35.66717575103936 139.7387066120498 43.627 35.66716110587507 139.73873229980813 43.627 35.6671840434966 139.7387522767255 43.627 35.66718484457308 139.7387508177325 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b914f74-cac3-4b30-8919-861204b76e22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b914f74-cac3-4b30-8919-861204b76e22_0">
											<gml:posList>35.66719868776255 139.73872544019912 12.11 35.66719868776255 139.73872544019912 43.627 35.66718484457308 139.7387508177325 43.627 35.66718484457308 139.7387508177325 12.11 35.66719868776255 139.73872544019912 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa397227-703c-4c14-96a4-d5c8d30a9c9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa397227-703c-4c14-96a4-d5c8d30a9c9c_0">
											<gml:posList>35.66716110587507 139.73873229980813 12.11 35.6671840434966 139.7387522767255 12.11 35.6671840434966 139.7387522767255 43.627 35.66716110587507 139.73873229980813 43.627 35.66716110587507 139.73873229980813 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-865b1af0-24c0-4217-8f3f-c493662cd9bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-865b1af0-24c0-4217-8f3f-c493662cd9bb_0">
											<gml:posList>35.66718484457308 139.7387508177325 12.11 35.66718484457308 139.7387508177325 43.627 35.6671840434966 139.7387522767255 43.627 35.6671840434966 139.7387522767255 12.11 35.66718484457308 139.7387508177325 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f0f6714d-7389-45fb-9c32-f59204864f30_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebd38788-e08f-4b84-878e-495921c33853">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6672278175444 139.73868770642991 43.492 35.667233698019096 139.7386921840944 43.492 35.66722966611974 139.73870014184723 43.492 35.667223785654016 139.7386956752282 43.492 35.6672278175444 139.73868770642991 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24fc9810-2888-41a8-bbfc-81843552e0cb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66724764224896 139.73879543507996 43.492 35.667229694160284 139.7388276658667 43.492 35.667214180354456 139.73881469426274 43.492 35.667232137453446 139.73878246346874 43.492 35.66724764224896 139.73879543507996 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-457a0cc7-dd2c-4b45-abb5-c6463e57a74e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66724279541904 139.73877573503876 43.492 35.667260355304805 139.73874274253086 43.492 35.66726721907188 139.7387482352577 43.492 35.667249659184634 139.73878122776725 43.492 35.66724279541904 139.73877573503876 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a420dab-2a27-4e48-b64d-6357336d5340">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a420dab-2a27-4e48-b64d-6357336d5340_0">
											<gml:posList>35.667233698019096 139.7386921840944 43.492 35.6672278175444 139.73868770642991 43.492 35.6672278175444 139.73868770642991 44.551 35.667233698019096 139.7386921840944 44.551 35.667233698019096 139.7386921840944 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03796f78-21cb-4c7a-9e6d-f46f18917e41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03796f78-21cb-4c7a-9e6d-f46f18917e41_0">
											<gml:posList>35.667223785654016 139.7386956752282 43.492 35.667223785654016 139.7386956752282 44.551 35.6672278175444 139.73868770642991 44.551 35.6672278175444 139.73868770642991 43.492 35.667223785654016 139.7386956752282 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fce0f94-f8ac-4963-bae2-4987efc934fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fce0f94-f8ac-4963-bae2-4987efc934fe_0">
											<gml:posList>35.6672278175444 139.73868770642991 44.551 35.667223785654016 139.7386956752282 44.551 35.66722966611974 139.73870014184723 44.551 35.667233698019096 139.7386921840944 44.551 35.6672278175444 139.73868770642991 44.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dda3fc0-cd6d-4a7b-b428-70afbc6ea103">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dda3fc0-cd6d-4a7b-b428-70afbc6ea103_0">
											<gml:posList>35.66722966611974 139.73870014184723 43.492 35.667233698019096 139.7386921840944 43.492 35.667233698019096 139.7386921840944 44.551 35.66722966611974 139.73870014184723 44.551 35.66722966611974 139.73870014184723 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d488f85-d0eb-4e72-936e-e61d5187c1e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d488f85-d0eb-4e72-936e-e61d5187c1e8_0">
											<gml:posList>35.667223785654016 139.7386956752282 43.492 35.66722966611974 139.73870014184723 43.492 35.66722966611974 139.73870014184723 44.551 35.667223785654016 139.7386956752282 44.551 35.667223785654016 139.7386956752282 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc453392-9325-4d68-a34d-a31c1352d05d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc453392-9325-4d68-a34d-a31c1352d05d_0">
											<gml:posList>35.66726721907188 139.7387482352577 43.492 35.667260355304805 139.73874274253086 43.492 35.667260355304805 139.73874274253086 45.081 35.66726721907188 139.7387482352577 45.081 35.66726721907188 139.7387482352577 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae1a31cb-3e06-4051-9538-0f2d732cb8b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae1a31cb-3e06-4051-9538-0f2d732cb8b8_0">
											<gml:posList>35.667260355304805 139.73874274253086 43.492 35.66724279541904 139.73877573503876 43.492 35.66724279541904 139.73877573503876 45.081 35.667260355304805 139.73874274253086 45.081 35.667260355304805 139.73874274253086 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cb84f99-ddd9-46f2-810e-ddcad171fa3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cb84f99-ddd9-46f2-810e-ddcad171fa3c_0">
											<gml:posList>35.66724279541904 139.73877573503876 45.081 35.667249659184634 139.73878122776725 45.081 35.66726721907188 139.7387482352577 45.081 35.667260355304805 139.73874274253086 45.081 35.66724279541904 139.73877573503876 45.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f30a5e2a-409b-4b10-9996-147ec3b68df0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f30a5e2a-409b-4b10-9996-147ec3b68df0_0">
											<gml:posList>35.66726721907188 139.7387482352577 43.492 35.66726721907188 139.7387482352577 45.081 35.667249659184634 139.73878122776725 45.081 35.667249659184634 139.73878122776725 43.492 35.66726721907188 139.7387482352577 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73f07ed2-2964-47fb-9bb1-bb7735a30ddf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73f07ed2-2964-47fb-9bb1-bb7735a30ddf_0">
											<gml:posList>35.66724279541904 139.73877573503876 43.492 35.667249659184634 139.73878122776725 43.492 35.667249659184634 139.73878122776725 45.081 35.66724279541904 139.73877573503876 45.081 35.66724279541904 139.73877573503876 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ae63f9f-a896-47e7-8e77-8ddc05a411e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ae63f9f-a896-47e7-8e77-8ddc05a411e9_0">
											<gml:posList>35.667232137453446 139.73878246346874 43.492 35.667232137453446 139.73878246346874 45.081 35.66724764224896 139.73879543507996 45.081 35.66724764224896 139.73879543507996 43.492 35.667232137453446 139.73878246346874 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a239d127-a5e4-4ec2-b0f7-147e3e658e5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a239d127-a5e4-4ec2-b0f7-147e3e658e5a_0">
											<gml:posList>35.667232137453446 139.73878246346874 43.492 35.667214180354456 139.73881469426274 43.492 35.667214180354456 139.73881469426274 45.081 35.667232137453446 139.73878246346874 45.081 35.667232137453446 139.73878246346874 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9653fe7e-1f64-436e-a9f5-b662c8e236c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9653fe7e-1f64-436e-a9f5-b662c8e236c5_0">
											<gml:posList>35.667214180354456 139.73881469426274 45.081 35.667229694160284 139.7388276658667 45.081 35.66724764224896 139.73879543507996 45.081 35.667232137453446 139.73878246346874 45.081 35.667214180354456 139.73881469426274 45.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cba53c71-c8c0-4cf2-be52-3eb30f3f71e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cba53c71-c8c0-4cf2-be52-3eb30f3f71e2_0">
											<gml:posList>35.667229694160284 139.7388276658667 43.492 35.66724764224896 139.73879543507996 43.492 35.66724764224896 139.73879543507996 45.081 35.667229694160284 139.7388276658667 45.081 35.667229694160284 139.7388276658667 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68429a25-bd74-4f24-aab2-75ddcb78e40c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68429a25-bd74-4f24-aab2-75ddcb78e40c_0">
											<gml:posList>35.667214180354456 139.73881469426274 43.492 35.667229694160284 139.7388276658667 43.492 35.667229694160284 139.7388276658667 45.081 35.667214180354456 139.73881469426274 45.081 35.667214180354456 139.73881469426274 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fd4e562d-08a9-4fb9-9f6d-92316ef39332">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd4e562d-08a9-4fb9-9f6d-92316ef39332">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd4e562d-08a9-4fb9-9f6d-92316ef39332">
											<gml:posList>35.66727166687585 139.73863867745914 12.11 35.667286021868875 139.73861081396197 12.11 35.66728787602041 139.73860740965506 12.11 35.66728873287188 139.73860810453036 12.11 35.66730547415729 139.73857726687217 12.11 35.66737573644694 139.73863484315626 12.11 35.66723847481738 139.73888673964387 12.11 35.66716640877401 139.73882772940686 12.11 35.66719998167436 139.73876616461516 12.11 35.6671840434966 139.7387522767255 12.11 35.66719869675024 139.73872540705108 12.11 35.66717575103936 139.7387066120498 12.11 35.667197201180805 139.7386689646715 12.11 35.66722020103193 139.73868782587803 12.11 35.66722914775696 139.73867137913024 12.11 35.6672364300842 139.73867039850063 12.11 35.66724934671056 139.73868179359243 12.11 35.667250929340916 139.73867697574323 12.11 35.66727166687585 139.73863867745914 12.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-997bbdcf-8d55-4af2-9a6b-a1517c73cb43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-997bbdcf-8d55-4af2-9a6b-a1517c73cb43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-997bbdcf-8d55-4af2-9a6b-a1517c73cb43">
											<gml:posList>35.66735712289693 139.73866899679268 20.801 35.66737573644694 139.73863484315626 20.801 35.66730547415729 139.73857726687217 20.801 35.66728873287188 139.73860810453036 20.801 35.66728787602041 139.73860740965506 20.801 35.667286021868875 139.73861081396197 20.801 35.66735712289693 139.73866899679268 20.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d30cecf4-48ed-4c67-acbc-d867ece8ce6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d30cecf4-48ed-4c67-acbc-d867ece8ce6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d30cecf4-48ed-4c67-acbc-d867ece8ce6c">
											<gml:posList>35.66727166687585 139.73863867745914 24.648 35.66734219965256 139.7386963860037 24.648 35.66735712289693 139.73866899679268 24.648 35.667286021868875 139.73861081396197 24.648 35.66727166687585 139.73863867745914 24.648</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9d590ab-843f-4ead-8777-1ec983c28db9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9d590ab-843f-4ead-8777-1ec983c28db9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9d590ab-843f-4ead-8777-1ec983c28db9">
											<gml:posList>35.66723018597668 139.73867346556557 43.627 35.66723593612666 139.73867268556975 43.627 35.6672364300842 139.73867039850063 43.627 35.66722914775696 139.73867137913024 43.627 35.66723018597668 139.73867346556557 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-12c6f02f-2be2-44ab-a00d-a642cea46b4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12c6f02f-2be2-44ab-a00d-a642cea46b4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12c6f02f-2be2-44ab-a00d-a642cea46b4d">
											<gml:posList>35.66723593612666 139.73867268556975 43.627 35.66725016065482 139.73868523893 43.627 35.66724934671056 139.73868179359243 43.627 35.6672364300842 139.73867039850063 43.627 35.66723593612666 139.73867268556975 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cac5d1d8-716c-4166-ba40-c9a5355c4257">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cac5d1d8-716c-4166-ba40-c9a5355c4257">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cac5d1d8-716c-4166-ba40-c9a5355c4257">
											<gml:posList>35.66719767229123 139.73867201276187 43.627 35.66722070821413 139.73869089601845 43.627 35.66722020103193 139.73868782587803 43.627 35.667197201180805 139.7386689646715 43.627 35.66719767229123 139.73867201276187 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27dacf78-b41a-4bba-a402-dbd5c0313f06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27dacf78-b41a-4bba-a402-dbd5c0313f06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27dacf78-b41a-4bba-a402-dbd5c0313f06">
											<gml:posList>35.66723018597668 139.73867346556557 43.627 35.66722914775696 139.73867137913024 43.627 35.66722020103193 139.73868782587803 43.627 35.66722070821413 139.73869089601845 43.627 35.66723018597668 139.73867346556557 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d7a4a9a3-3cd1-442e-ab59-7e54d2375073">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7a4a9a3-3cd1-442e-ab59-7e54d2375073">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7a4a9a3-3cd1-442e-ab59-7e54d2375073">
											<gml:posList>35.66725177925339 139.7386803105801 43.627 35.667250929340916 139.73867697574323 43.627 35.66724934671056 139.73868179359243 43.627 35.66725016065482 139.73868523893 43.627 35.66725177925339 139.7386803105801 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fd4e15f3-2b98-4fe6-86f4-5c2e56e307e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd4e15f3-2b98-4fe6-86f4-5c2e56e307e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd4e15f3-2b98-4fe6-86f4-5c2e56e307e1">
											<gml:posList>35.66727166687585 139.73863867745914 27.837 35.667250929340916 139.73867697574323 27.837 35.667267150715105 139.73867271499586 27.837 35.66728845295486 139.73868772322768 27.837 35.667281135498776 139.73870135137585 27.837 35.66732166892931 139.73873406549572 27.837 35.66734219965256 139.7386963860037 27.837 35.66727166687585 139.73863867745914 27.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-992b82d5-50a8-4121-a4b7-d86af5dbad40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-992b82d5-50a8-4121-a4b7-d86af5dbad40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-992b82d5-50a8-4121-a4b7-d86af5dbad40">
											<gml:posList>35.667250929340916 139.73867697574323 40.284 35.667281135498776 139.73870135137585 40.284 35.66728845295486 139.73868772322768 40.284 35.667267150715105 139.73867271499586 40.284 35.667250929340916 139.73867697574323 40.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78cc4cab-b22a-421e-a3b7-7e90971dd423">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78cc4cab-b22a-421e-a3b7-7e90971dd423">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78cc4cab-b22a-421e-a3b7-7e90971dd423">
											<gml:posList>35.66719767229123 139.73867201276187 43.627 35.667197201180805 139.7386689646715 43.627 35.66717575103936 139.7387066120498 43.627 35.66717830146408 139.73870602361177 43.627 35.66719767229123 139.73867201276187 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c23467f-bc2b-412f-b3a4-be27fef61c94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c23467f-bc2b-412f-b3a4-be27fef61c94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c23467f-bc2b-412f-b3a4-be27fef61c94">
											<gml:posList>35.66731915456811 139.73873466493723 43.627 35.66732166892931 139.73873406549572 43.627 35.667250929340916 139.73867697574323 43.627 35.66725177925339 139.7386803105801 43.627 35.66731915456811 139.73873466493723 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-adca50ee-95c1-44bb-be07-0d6987cf76ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adca50ee-95c1-44bb-be07-0d6987cf76ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adca50ee-95c1-44bb-be07-0d6987cf76ad">
											<gml:posList>35.66719869675024 139.73872540705108 43.627 35.667199704838374 139.73872356120955 43.627 35.66717830146408 139.73870602361177 43.627 35.66717575103936 139.7387066120498 43.627 35.66719869675024 139.73872540705108 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de5d477c-8387-4755-a22e-4eff52cae6a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de5d477c-8387-4755-a22e-4eff52cae6a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de5d477c-8387-4755-a22e-4eff52cae6a8">
											<gml:posList>35.6671840434966 139.7387522767255 46.719 35.66720360752604 139.73876913166507 48.921 35.667228764695 139.73872301881488 48.921 35.667208876616385 139.73870673864644 46.719 35.6671840434966 139.7387522767255 46.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-978a9fbb-c08c-40e8-9d17-a383275505e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-978a9fbb-c08c-40e8-9d17-a383275505e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-978a9fbb-c08c-40e8-9d17-a383275505e9">
											<gml:posList>35.667228764695 139.73872301881488 48.921 35.66720360752604 139.73876913166507 48.921 35.66722349560494 139.73878542289373 46.719 35.66724864375764 139.73873929900202 46.719 35.667228764695 139.73872301881488 48.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2cbbbbbe-6c67-4c3d-bb63-a5b14f2dc0bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cbbbbbe-6c67-4c3d-bb63-a5b14f2dc0bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cbbbbbe-6c67-4c3d-bb63-a5b14f2dc0bc">
											<gml:posList>35.66725016065482 139.73868523893 43.492 35.66723593612666 139.73867268556975 43.492 35.66723018597668 139.73867346556557 43.492 35.66722070821413 139.73869089601845 43.492 35.66719767229123 139.73867201276187 43.492 35.66717830146408 139.73870602361177 43.492 35.667199704838374 139.73872356120955 43.492 35.667208876616385 139.73870673864644 43.492 35.66724864375764 139.73873929900202 43.492 35.66722349560494 139.73878542289373 43.492 35.66720148793831 139.73876739997075 43.492 35.667168932132135 139.7388271078672 43.492 35.66723797663657 139.73888364739926 43.492 35.66731915456811 139.73873466493723 43.492 35.66725177925339 139.7386803105801 43.492 35.66725016065482 139.73868523893 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e18708b-5d43-4eac-bc0d-dc92f95c44ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e18708b-5d43-4eac-bc0d-dc92f95c44ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e18708b-5d43-4eac-bc0d-dc92f95c44ec">
											<gml:posList>35.66719998167436 139.73876616461516 43.627 35.66716640877401 139.73882772940686 43.627 35.667168932132135 139.7388271078672 43.627 35.66720148793831 139.73876739997075 43.627 35.66719998167436 139.73876616461516 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-659c8342-dac3-46af-bec8-54eb24c99b92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-659c8342-dac3-46af-bec8-54eb24c99b92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-659c8342-dac3-46af-bec8-54eb24c99b92">
											<gml:posList>35.66723797663657 139.73888364739926 43.627 35.66723847481738 139.73888673964387 43.627 35.66732166892931 139.73873406549572 43.627 35.66731915456811 139.73873466493723 43.627 35.66723797663657 139.73888364739926 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-23f3d1ef-e232-4e67-98df-d114b80b1d6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23f3d1ef-e232-4e67-98df-d114b80b1d6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23f3d1ef-e232-4e67-98df-d114b80b1d6a">
											<gml:posList>35.667168932132135 139.7388271078672 43.627 35.66716640877401 139.73882772940686 43.627 35.66723847481738 139.73888673964387 43.627 35.66723797663657 139.73888364739926 43.627 35.667168932132135 139.7388271078672 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-411c14e9-99d8-4b3c-bc7b-512ad7d5180e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-411c14e9-99d8-4b3c-bc7b-512ad7d5180e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-411c14e9-99d8-4b3c-bc7b-512ad7d5180e">
											<gml:posList>35.66725177925339 139.7386803105801 43.492 35.66725177925339 139.7386803105801 43.627 35.66725016065482 139.73868523893 43.627 35.66725016065482 139.73868523893 43.492 35.66725177925339 139.7386803105801 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-623bfd9e-d7f4-4e1c-ab2d-f44105577299">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-623bfd9e-d7f4-4e1c-ab2d-f44105577299">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-623bfd9e-d7f4-4e1c-ab2d-f44105577299">
											<gml:posList>35.66728873287188 139.73860810453036 20.801 35.66730547415729 139.73857726687217 20.801 35.66730547415729 139.73857726687217 12.11 35.66728873287188 139.73860810453036 12.11 35.66728873287188 139.73860810453036 20.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ced61312-ec4e-48f3-9cf2-311cf3b6e410">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ced61312-ec4e-48f3-9cf2-311cf3b6e410">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ced61312-ec4e-48f3-9cf2-311cf3b6e410">
											<gml:posList>35.66730547415729 139.73857726687217 20.801 35.66737573644694 139.73863484315626 20.801 35.66737573644694 139.73863484315626 12.11 35.66730547415729 139.73857726687217 12.11 35.66730547415729 139.73857726687217 20.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-637ba0f1-3fba-438a-81cc-ba601ddcecfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-637ba0f1-3fba-438a-81cc-ba601ddcecfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-637ba0f1-3fba-438a-81cc-ba601ddcecfd">
											<gml:posList>35.66728787602041 139.73860740965506 20.801 35.66728873287188 139.73860810453036 20.801 35.66728873287188 139.73860810453036 12.11 35.66728787602041 139.73860740965506 12.11 35.66728787602041 139.73860740965506 20.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6af3adfb-d5e0-44ef-90b6-c14f510449db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6af3adfb-d5e0-44ef-90b6-c14f510449db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6af3adfb-d5e0-44ef-90b6-c14f510449db">
											<gml:posList>35.667286021868875 139.73861081396197 20.801 35.66728787602041 139.73860740965506 20.801 35.66728787602041 139.73860740965506 12.11 35.667286021868875 139.73861081396197 12.11 35.667286021868875 139.73861081396197 20.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93849297-d43d-424e-b54b-f06a26d84be9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93849297-d43d-424e-b54b-f06a26d84be9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93849297-d43d-424e-b54b-f06a26d84be9">
											<gml:posList>35.66727166687585 139.73863867745914 24.648 35.667286021868875 139.73861081396197 24.648 35.667286021868875 139.73861081396197 20.801 35.667286021868875 139.73861081396197 12.11 35.66727166687585 139.73863867745914 12.11 35.66727166687585 139.73863867745914 24.648</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50d874f1-661d-4be1-a544-ca5394636c98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50d874f1-661d-4be1-a544-ca5394636c98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50d874f1-661d-4be1-a544-ca5394636c98">
											<gml:posList>35.66735712289693 139.73866899679268 24.648 35.66735712289693 139.73866899679268 20.801 35.667286021868875 139.73861081396197 20.801 35.667286021868875 139.73861081396197 24.648 35.66735712289693 139.73866899679268 24.648</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf82c3a5-891a-491f-b159-3e2e15c7cc0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf82c3a5-891a-491f-b159-3e2e15c7cc0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf82c3a5-891a-491f-b159-3e2e15c7cc0c">
											<gml:posList>35.667250929340916 139.73867697574323 27.837 35.66727166687585 139.73863867745914 27.837 35.66727166687585 139.73863867745914 24.648 35.66727166687585 139.73863867745914 12.11 35.667250929340916 139.73867697574323 12.11 35.667250929340916 139.73867697574323 27.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dce6d123-75ca-44cd-abe4-9ba76d7dc234">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dce6d123-75ca-44cd-abe4-9ba76d7dc234">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dce6d123-75ca-44cd-abe4-9ba76d7dc234">
											<gml:posList>35.66734219965256 139.7386963860037 27.837 35.66734219965256 139.7386963860037 24.648 35.66727166687585 139.73863867745914 24.648 35.66727166687585 139.73863867745914 27.837 35.66734219965256 139.7386963860037 27.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eee8ac62-97bc-4b9c-a14d-c1a5b9991e92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eee8ac62-97bc-4b9c-a14d-c1a5b9991e92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eee8ac62-97bc-4b9c-a14d-c1a5b9991e92">
											<gml:posList>35.66722914775696 139.73867137913024 43.627 35.6672364300842 139.73867039850063 43.627 35.6672364300842 139.73867039850063 12.11 35.66722914775696 139.73867137913024 12.11 35.66722914775696 139.73867137913024 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bce17da0-a29c-4cd8-8d6c-97387d1c3bee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bce17da0-a29c-4cd8-8d6c-97387d1c3bee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bce17da0-a29c-4cd8-8d6c-97387d1c3bee">
											<gml:posList>35.66723593612666 139.73867268556975 43.492 35.66723593612666 139.73867268556975 43.627 35.66723018597668 139.73867346556557 43.627 35.66723018597668 139.73867346556557 43.492 35.66723593612666 139.73867268556975 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de3b5fff-a76f-488c-9f99-db0823dfb1e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de3b5fff-a76f-488c-9f99-db0823dfb1e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de3b5fff-a76f-488c-9f99-db0823dfb1e3">
											<gml:posList>35.667250929340916 139.73867697574323 40.284 35.667267150715105 139.73867271499586 40.284 35.667267150715105 139.73867271499586 27.837 35.667250929340916 139.73867697574323 27.837 35.667250929340916 139.73867697574323 40.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c59a4814-75f5-4c55-b8c3-a8fd0a45e5ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c59a4814-75f5-4c55-b8c3-a8fd0a45e5ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c59a4814-75f5-4c55-b8c3-a8fd0a45e5ba">
											<gml:posList>35.6672364300842 139.73867039850063 43.627 35.66724934671056 139.73868179359243 43.627 35.66724934671056 139.73868179359243 12.11 35.6672364300842 139.73867039850063 12.11 35.6672364300842 139.73867039850063 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-349d7d33-3c5a-4926-83f6-130ebdaa3a6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-349d7d33-3c5a-4926-83f6-130ebdaa3a6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-349d7d33-3c5a-4926-83f6-130ebdaa3a6c">
											<gml:posList>35.667197201180805 139.7386689646715 43.627 35.66722020103193 139.73868782587803 43.627 35.66722020103193 139.73868782587803 12.11 35.667197201180805 139.7386689646715 12.11 35.667197201180805 139.7386689646715 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3fc0bf4-5401-475f-81bf-c5c453aa2af0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3fc0bf4-5401-475f-81bf-c5c453aa2af0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3fc0bf4-5401-475f-81bf-c5c453aa2af0">
											<gml:posList>35.66725016065482 139.73868523893 43.492 35.66725016065482 139.73868523893 43.627 35.66723593612666 139.73867268556975 43.627 35.66723593612666 139.73867268556975 43.492 35.66725016065482 139.73868523893 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b202b07b-4577-4b3a-94d1-b3aa7835e10a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b202b07b-4577-4b3a-94d1-b3aa7835e10a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b202b07b-4577-4b3a-94d1-b3aa7835e10a">
											<gml:posList>35.66724934671056 139.73868179359243 43.627 35.667250929340916 139.73867697574323 43.627 35.667250929340916 139.73867697574323 40.284 35.667250929340916 139.73867697574323 27.837 35.667250929340916 139.73867697574323 12.11 35.66724934671056 139.73868179359243 12.11 35.66724934671056 139.73868179359243 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83154e6c-f00c-4bb1-8dff-26166ee61d3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83154e6c-f00c-4bb1-8dff-26166ee61d3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83154e6c-f00c-4bb1-8dff-26166ee61d3f">
											<gml:posList>35.66722020103193 139.73868782587803 43.627 35.66722914775696 139.73867137913024 43.627 35.66722914775696 139.73867137913024 12.11 35.66722020103193 139.73868782587803 12.11 35.66722020103193 139.73868782587803 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-020851bc-bfc7-4bc1-be8d-debee888f6b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-020851bc-bfc7-4bc1-be8d-debee888f6b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-020851bc-bfc7-4bc1-be8d-debee888f6b6">
											<gml:posList>35.667267150715105 139.73867271499586 40.284 35.66728845295486 139.73868772322768 40.284 35.66728845295486 139.73868772322768 27.837 35.667267150715105 139.73867271499586 27.837 35.667267150715105 139.73867271499586 40.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20131d7d-62e0-46a9-88fc-cd2cb50c5997">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20131d7d-62e0-46a9-88fc-cd2cb50c5997">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20131d7d-62e0-46a9-88fc-cd2cb50c5997">
											<gml:posList>35.66722070821413 139.73869089601845 43.492 35.66722070821413 139.73869089601845 43.627 35.66719767229123 139.73867201276187 43.627 35.66719767229123 139.73867201276187 43.492 35.66722070821413 139.73869089601845 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45330ff9-40f0-4597-b5d6-f1c140de20ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45330ff9-40f0-4597-b5d6-f1c140de20ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45330ff9-40f0-4597-b5d6-f1c140de20ad">
											<gml:posList>35.66723018597668 139.73867346556557 43.492 35.66723018597668 139.73867346556557 43.627 35.66722070821413 139.73869089601845 43.627 35.66722070821413 139.73869089601845 43.492 35.66723018597668 139.73867346556557 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a77fd3e5-322a-428e-98f1-daab37daf1d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a77fd3e5-322a-428e-98f1-daab37daf1d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a77fd3e5-322a-428e-98f1-daab37daf1d0">
											<gml:posList>35.66717575103936 139.7387066120498 43.627 35.667197201180805 139.7386689646715 43.627 35.667197201180805 139.7386689646715 12.11 35.66717575103936 139.7387066120498 12.11 35.66717575103936 139.7387066120498 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-076a708b-d4ba-4d32-b982-8edd335981e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-076a708b-d4ba-4d32-b982-8edd335981e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-076a708b-d4ba-4d32-b982-8edd335981e9">
											<gml:posList>35.66719767229123 139.73867201276187 43.492 35.66719767229123 139.73867201276187 43.627 35.66717830146408 139.73870602361177 43.627 35.66717830146408 139.73870602361177 43.492 35.66719767229123 139.73867201276187 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92fca46d-e4a2-4824-971d-5d6c1e517b06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92fca46d-e4a2-4824-971d-5d6c1e517b06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92fca46d-e4a2-4824-971d-5d6c1e517b06">
											<gml:posList>35.66728845295486 139.73868772322768 40.284 35.667281135498776 139.73870135137585 40.284 35.667281135498776 139.73870135137585 27.837 35.66728845295486 139.73868772322768 27.837 35.66728845295486 139.73868772322768 40.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7ee4be8-5cff-455e-b21a-491a35fc0b77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7ee4be8-5cff-455e-b21a-491a35fc0b77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7ee4be8-5cff-455e-b21a-491a35fc0b77">
											<gml:posList>35.66732166892931 139.73873406549572 43.627 35.66732166892931 139.73873406549572 27.837 35.667281135498776 139.73870135137585 27.837 35.667281135498776 139.73870135137585 40.284 35.667250929340916 139.73867697574323 40.284 35.667250929340916 139.73867697574323 43.627 35.66732166892931 139.73873406549572 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-129f9399-8d4d-451f-b7df-baaf2babd719">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-129f9399-8d4d-451f-b7df-baaf2babd719">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-129f9399-8d4d-451f-b7df-baaf2babd719">
											<gml:posList>35.66731915456811 139.73873466493723 43.492 35.66731915456811 139.73873466493723 43.627 35.66725177925339 139.7386803105801 43.627 35.66725177925339 139.7386803105801 43.492 35.66731915456811 139.73873466493723 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d38e143-135a-465e-bedc-b8c66ec87920">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d38e143-135a-465e-bedc-b8c66ec87920">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d38e143-135a-465e-bedc-b8c66ec87920">
											<gml:posList>35.66717830146408 139.73870602361177 43.492 35.66717830146408 139.73870602361177 43.627 35.667199704838374 139.73872356120955 43.627 35.667199704838374 139.73872356120955 43.492 35.66717830146408 139.73870602361177 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a986564-5ac1-4971-bb2a-8f12e7afaa06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a986564-5ac1-4971-bb2a-8f12e7afaa06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a986564-5ac1-4971-bb2a-8f12e7afaa06">
											<gml:posList>35.66719869675024 139.73872540705108 43.627 35.66717575103936 139.7387066120498 43.627 35.66717575103936 139.7387066120498 12.11 35.66719869675024 139.73872540705108 12.11 35.66719869675024 139.73872540705108 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec637c31-8d36-401d-8d44-2e912521e3ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec637c31-8d36-401d-8d44-2e912521e3ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec637c31-8d36-401d-8d44-2e912521e3ac">
											<gml:posList>35.667208876616385 139.73870673864644 46.719 35.667228764695 139.73872301881488 48.921 35.66724864375764 139.73873929900202 46.719 35.66724864375764 139.73873929900202 43.492 35.667208876616385 139.73870673864644 43.492 35.667208876616385 139.73870673864644 46.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41837378-55c7-4414-9e33-c25be68a272e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41837378-55c7-4414-9e33-c25be68a272e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41837378-55c7-4414-9e33-c25be68a272e">
											<gml:posList>35.667208876616385 139.73870673864644 46.719 35.667208876616385 139.73870673864644 43.492 35.667199704838374 139.73872356120955 43.492 35.667199704838374 139.73872356120955 43.627 35.66719869675024 139.73872540705108 43.627 35.66719869675024 139.73872540705108 12.11 35.6671840434966 139.7387522767255 12.11 35.6671840434966 139.7387522767255 46.719 35.667208876616385 139.73870673864644 46.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d140e66-c580-4603-bade-a87224460b3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d140e66-c580-4603-bade-a87224460b3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d140e66-c580-4603-bade-a87224460b3e">
											<gml:posList>35.6671840434966 139.7387522767255 46.719 35.6671840434966 139.7387522767255 12.11 35.66719998167436 139.73876616461516 12.11 35.6671840434966 139.7387522767255 46.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d954af8b-23a7-4789-a3a6-3acecf1241b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d954af8b-23a7-4789-a3a6-3acecf1241b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d954af8b-23a7-4789-a3a6-3acecf1241b7">
											<gml:posList>35.6671840434966 139.7387522767255 46.719 35.66719998167436 139.73876616461516 12.11 35.66719998167436 139.73876616461516 43.627 35.6671840434966 139.7387522767255 46.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c9f69ac-ec9f-4d8f-961f-07d336aa2662">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c9f69ac-ec9f-4d8f-961f-07d336aa2662">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c9f69ac-ec9f-4d8f-961f-07d336aa2662">
											<gml:posList>35.66720148793831 139.73876739997075 43.627 35.6671840434966 139.7387522767255 46.719 35.66719998167436 139.73876616461516 43.627 35.66720148793831 139.73876739997075 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53272f1c-6f30-475a-947a-96ac387f19f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53272f1c-6f30-475a-947a-96ac387f19f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53272f1c-6f30-475a-947a-96ac387f19f4">
											<gml:posList>35.66735712289693 139.73866899679268 20.801 35.66735712289693 139.73866899679268 24.648 35.66734219965256 139.7386963860037 24.648 35.66734219965256 139.7386963860037 27.837 35.66732166892931 139.73873406549572 27.837 35.66732166892931 139.73873406549572 43.627 35.66723847481738 139.73888673964387 43.627 35.66723847481738 139.73888673964387 12.11 35.66737573644694 139.73863484315626 12.11 35.66737573644694 139.73863484315626 20.801 35.66735712289693 139.73866899679268 20.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb17879e-01fa-48b2-ae9e-fceb943320d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb17879e-01fa-48b2-ae9e-fceb943320d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb17879e-01fa-48b2-ae9e-fceb943320d6">
											<gml:posList>35.66724864375764 139.73873929900202 46.719 35.66722349560494 139.73878542289373 46.719 35.66722349560494 139.73878542289373 43.492 35.66724864375764 139.73873929900202 43.492 35.66724864375764 139.73873929900202 46.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34f4b38d-f82a-4951-aaad-175896301050">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34f4b38d-f82a-4951-aaad-175896301050">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34f4b38d-f82a-4951-aaad-175896301050">
											<gml:posList>35.66722349560494 139.73878542289373 43.492 35.66720360752604 139.73876913166507 48.921 35.6671840434966 139.7387522767255 46.719 35.66722349560494 139.73878542289373 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5005a208-6087-48cd-8fb3-7fe84de6e5d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5005a208-6087-48cd-8fb3-7fe84de6e5d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5005a208-6087-48cd-8fb3-7fe84de6e5d2">
											<gml:posList>35.66720148793831 139.73876739997075 43.627 35.66722349560494 139.73878542289373 43.492 35.6671840434966 139.7387522767255 46.719 35.66720148793831 139.73876739997075 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0044eb1-fd46-4eaa-9053-4ba74d2ad7bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0044eb1-fd46-4eaa-9053-4ba74d2ad7bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0044eb1-fd46-4eaa-9053-4ba74d2ad7bf">
											<gml:posList>35.66720148793831 139.73876739997075 43.627 35.66720148793831 139.73876739997075 43.492 35.66722349560494 139.73878542289373 43.492 35.66720148793831 139.73876739997075 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bf70979-29f0-4b8f-993e-9e79c4cc203c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bf70979-29f0-4b8f-993e-9e79c4cc203c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bf70979-29f0-4b8f-993e-9e79c4cc203c">
											<gml:posList>35.66722349560494 139.73878542289373 43.492 35.66722349560494 139.73878542289373 46.719 35.66720360752604 139.73876913166507 48.921 35.66722349560494 139.73878542289373 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e55203c9-0a25-4d5d-97f7-ca2f99154b8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e55203c9-0a25-4d5d-97f7-ca2f99154b8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e55203c9-0a25-4d5d-97f7-ca2f99154b8d">
											<gml:posList>35.66716640877401 139.73882772940686 43.627 35.66719998167436 139.73876616461516 43.627 35.66719998167436 139.73876616461516 12.11 35.66716640877401 139.73882772940686 12.11 35.66716640877401 139.73882772940686 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-693e27b1-44d0-427e-93ce-b31e835ea84b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-693e27b1-44d0-427e-93ce-b31e835ea84b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-693e27b1-44d0-427e-93ce-b31e835ea84b">
											<gml:posList>35.66720148793831 139.73876739997075 43.492 35.66720148793831 139.73876739997075 43.627 35.667168932132135 139.7388271078672 43.627 35.667168932132135 139.7388271078672 43.492 35.66720148793831 139.73876739997075 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d017f21e-7926-485f-8fbd-662f638f53b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d017f21e-7926-485f-8fbd-662f638f53b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d017f21e-7926-485f-8fbd-662f638f53b6">
											<gml:posList>35.66723797663657 139.73888364739926 43.492 35.66723797663657 139.73888364739926 43.627 35.66731915456811 139.73873466493723 43.627 35.66731915456811 139.73873466493723 43.492 35.66723797663657 139.73888364739926 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0938e7cd-7417-4f48-8dbf-a2fcfdc661a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0938e7cd-7417-4f48-8dbf-a2fcfdc661a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0938e7cd-7417-4f48-8dbf-a2fcfdc661a5">
											<gml:posList>35.667168932132135 139.7388271078672 43.492 35.667168932132135 139.7388271078672 43.627 35.66723797663657 139.73888364739926 43.627 35.66723797663657 139.73888364739926 43.492 35.667168932132135 139.7388271078672 43.492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a7ee088-d8e8-4863-93fc-93cc76112efb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a7ee088-d8e8-4863-93fc-93cc76112efb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a7ee088-d8e8-4863-93fc-93cc76112efb">
											<gml:posList>35.66723847481738 139.73888673964387 43.627 35.66716640877401 139.73882772940686 43.627 35.66716640877401 139.73882772940686 12.11 35.66723847481738 139.73888673964387 12.11 35.66723847481738 139.73888673964387 43.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6540</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">320.86405</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>