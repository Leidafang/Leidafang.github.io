<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f26a2b83-9ba9-47b2-9c45-03a56cdd87fe">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>霞が関三丁目南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">21.8</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67160806190635 139.74755922512693 0 35.67164269898958 139.74759343201606 0 35.67182052746591 139.74732326639347 0 35.67178598044426 139.7472890594488 0 35.67160806190635 139.74755922512693 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67160806190635 139.74755922512693 7.4 35.67178598044426 139.7472890594488 7.4 35.67182052746591 139.74732326639347 7.4 35.67164269898958 139.74759343201606 7.4 35.67160806190635 139.74755922512693 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67160806190635 139.74755922512693 7.4 35.67164269898958 139.74759343201606 7.4 35.67164269898958 139.74759343201606 29.189999999999998 35.67160806190635 139.74755922512693 29.189999999999998 35.67160806190635 139.74755922512693 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67164269898958 139.74759343201606 7.4 35.67182052746591 139.74732326639347 7.4 35.67182052746591 139.74732326639347 29.189999999999998 35.67164269898958 139.74759343201606 29.189999999999998 35.67164269898958 139.74759343201606 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67182052746591 139.74732326639347 7.4 35.67178598044426 139.7472890594488 7.4 35.67178598044426 139.7472890594488 29.189999999999998 35.67182052746591 139.74732326639347 29.189999999999998 35.67182052746591 139.74732326639347 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178598044426 139.7472890594488 7.4 35.67160806190635 139.74755922512693 7.4 35.67160806190635 139.74755922512693 29.189999999999998 35.67178598044426 139.7472890594488 29.189999999999998 35.67178598044426 139.7472890594488 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67160806190635 139.74755922512693 29.189999999999998 35.67164269898958 139.74759343201606 29.189999999999998 35.67182052746591 139.74732326639347 29.189999999999998 35.67178598044426 139.7472890594488 29.189999999999998 35.67160806190635 139.74755922512693 29.189999999999998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7755b0f2-58bb-4bd4-95a8-b54eeb3a9c35"/>
							<gml:surfaceMember xlink:href="#poly-d827303f-390d-4e46-8567-c405b0f4e132"/>
							<gml:surfaceMember xlink:href="#poly-9ef9857b-61d1-4680-bc9e-43d7524fc856"/>
							<gml:surfaceMember xlink:href="#poly-c8089271-f3e3-4f65-a800-a6abdf7d09ab"/>
							<gml:surfaceMember xlink:href="#poly-a89a5377-8da2-4140-89aa-c8fc700802fd"/>
							<gml:surfaceMember xlink:href="#poly-0c3e370f-784e-42de-8eb4-7a41504020f3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7755b0f2-58bb-4bd4-95a8-b54eeb3a9c35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7755b0f2-58bb-4bd4-95a8-b54eeb3a9c35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7755b0f2-58bb-4bd4-95a8-b54eeb3a9c35">
											<gml:posList>35.67160806190635 139.74755922512693 7.4 35.67178598044425 139.7472890594488 7.4 35.67182052746591 139.74732326639344 7.4 35.671642698989544 139.74759343201606 7.4 35.67160806190635 139.74755922512693 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d827303f-390d-4e46-8567-c405b0f4e132">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d827303f-390d-4e46-8567-c405b0f4e132">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d827303f-390d-4e46-8567-c405b0f4e132">
											<gml:posList>35.67178598044425 139.7472890594488 29.3 35.67160806190635 139.74755922512693 29.3 35.671642698989544 139.74759343201606 29.3 35.67182052746591 139.74732326639344 29.3 35.67178598044425 139.7472890594488 29.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ef9857b-61d1-4680-bc9e-43d7524fc856">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ef9857b-61d1-4680-bc9e-43d7524fc856">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ef9857b-61d1-4680-bc9e-43d7524fc856">
											<gml:posList>35.67182052746591 139.74732326639344 7.4 35.67178598044425 139.7472890594488 7.4 35.67178598044425 139.7472890594488 29.3 35.67182052746591 139.74732326639344 29.3 35.67182052746591 139.74732326639344 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8089271-f3e3-4f65-a800-a6abdf7d09ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8089271-f3e3-4f65-a800-a6abdf7d09ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8089271-f3e3-4f65-a800-a6abdf7d09ab">
											<gml:posList>35.67178598044425 139.7472890594488 7.4 35.67160806190635 139.74755922512693 7.4 35.67160806190635 139.74755922512693 29.3 35.67178598044425 139.7472890594488 29.3 35.67178598044425 139.7472890594488 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a89a5377-8da2-4140-89aa-c8fc700802fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a89a5377-8da2-4140-89aa-c8fc700802fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a89a5377-8da2-4140-89aa-c8fc700802fd">
											<gml:posList>35.671642698989544 139.74759343201606 7.4 35.67182052746591 139.74732326639344 7.4 35.67182052746591 139.74732326639344 29.3 35.671642698989544 139.74759343201606 29.3 35.671642698989544 139.74759343201606 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c3e370f-784e-42de-8eb4-7a41504020f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c3e370f-784e-42de-8eb4-7a41504020f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c3e370f-784e-42de-8eb4-7a41504020f3">
											<gml:posList>35.67160806190635 139.74755922512693 7.4 35.671642698989544 139.74759343201606 7.4 35.671642698989544 139.74759343201606 29.3 35.67160806190635 139.74755922512693 29.3 35.67160806190635 139.74755922512693 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-2861</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>