<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f296d635-195a-4e9c-89c8-ff1756fd7500">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">5.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670590981411856 139.73823637288382 0 35.670597857833094 139.7382692826696 0 35.670613808283406 139.73826440338925 0 35.670629642623766 139.7383408249655 0 35.67070642070746 139.73831687398254 0 35.6707018968475 139.7382953390518 0 35.67073677140558 139.73828447233075 0 35.67073496185973 139.73827585835562 0 35.67075523776255 139.73826953791922 0 35.67075315640853 139.7382591568551 0 35.6707622580868 139.73825638448423 0 35.670752938271825 139.73821121612588 0 35.67074942379306 139.7382123249265 0 35.67073539770462 139.7381429707518 0 35.670586526380596 139.73818788496513 0 35.67059503662705 139.73823515298218 0 35.670590981411856 139.73823637288382 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670590981411856 139.73823637288382 17.703 35.67059503662705 139.73823515298218 17.703 35.670586526380596 139.73818788496513 17.703 35.67073539770462 139.7381429707518 17.703 35.67074942379306 139.7382123249265 17.703 35.670752938271825 139.73821121612588 17.703 35.6707622580868 139.73825638448423 17.703 35.67075315640853 139.7382591568551 17.703 35.67075523776255 139.73826953791922 17.703 35.67073496185973 139.73827585835562 17.703 35.67073677140558 139.73828447233075 17.703 35.6707018968475 139.7382953390518 17.703 35.67070642070746 139.73831687398254 17.703 35.670629642623766 139.7383408249655 17.703 35.670613808283406 139.73826440338925 17.703 35.670597857833094 139.7382692826696 17.703 35.670590981411856 139.73823637288382 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670590981411856 139.73823637288382 17.703 35.670597857833094 139.7382692826696 17.703 35.670597857833094 139.7382692826696 23.26 35.670590981411856 139.73823637288382 23.26 35.670590981411856 139.73823637288382 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670597857833094 139.7382692826696 17.703 35.670613808283406 139.73826440338925 17.703 35.670613808283406 139.73826440338925 23.26 35.670597857833094 139.7382692826696 23.26 35.670597857833094 139.7382692826696 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670613808283406 139.73826440338925 17.703 35.670629642623766 139.7383408249655 17.703 35.670629642623766 139.7383408249655 23.26 35.670613808283406 139.73826440338925 23.26 35.670613808283406 139.73826440338925 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670629642623766 139.7383408249655 17.703 35.67070642070746 139.73831687398254 17.703 35.67070642070746 139.73831687398254 23.26 35.670629642623766 139.7383408249655 23.26 35.670629642623766 139.7383408249655 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070642070746 139.73831687398254 17.703 35.6707018968475 139.7382953390518 17.703 35.6707018968475 139.7382953390518 23.26 35.67070642070746 139.73831687398254 23.26 35.67070642070746 139.73831687398254 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6707018968475 139.7382953390518 17.703 35.67073677140558 139.73828447233075 17.703 35.67073677140558 139.73828447233075 23.26 35.6707018968475 139.7382953390518 23.26 35.6707018968475 139.7382953390518 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073677140558 139.73828447233075 17.703 35.67073496185973 139.73827585835562 17.703 35.67073496185973 139.73827585835562 23.26 35.67073677140558 139.73828447233075 23.26 35.67073677140558 139.73828447233075 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073496185973 139.73827585835562 17.703 35.67075523776255 139.73826953791922 17.703 35.67075523776255 139.73826953791922 23.26 35.67073496185973 139.73827585835562 23.26 35.67073496185973 139.73827585835562 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67075523776255 139.73826953791922 17.703 35.67075315640853 139.7382591568551 17.703 35.67075315640853 139.7382591568551 23.26 35.67075523776255 139.73826953791922 23.26 35.67075523776255 139.73826953791922 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67075315640853 139.7382591568551 17.703 35.6707622580868 139.73825638448423 17.703 35.6707622580868 139.73825638448423 23.26 35.67075315640853 139.7382591568551 23.26 35.67075315640853 139.7382591568551 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6707622580868 139.73825638448423 17.703 35.670752938271825 139.73821121612588 17.703 35.670752938271825 139.73821121612588 23.26 35.6707622580868 139.73825638448423 23.26 35.6707622580868 139.73825638448423 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670752938271825 139.73821121612588 17.703 35.67074942379306 139.7382123249265 17.703 35.67074942379306 139.7382123249265 23.26 35.670752938271825 139.73821121612588 23.26 35.670752938271825 139.73821121612588 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67074942379306 139.7382123249265 17.703 35.67073539770462 139.7381429707518 17.703 35.67073539770462 139.7381429707518 23.26 35.67074942379306 139.7382123249265 23.26 35.67074942379306 139.7382123249265 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073539770462 139.7381429707518 17.703 35.670586526380596 139.73818788496513 17.703 35.670586526380596 139.73818788496513 23.26 35.67073539770462 139.7381429707518 23.26 35.67073539770462 139.7381429707518 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670586526380596 139.73818788496513 17.703 35.67059503662705 139.73823515298218 17.703 35.67059503662705 139.73823515298218 23.26 35.670586526380596 139.73818788496513 23.26 35.670586526380596 139.73818788496513 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059503662705 139.73823515298218 17.703 35.670590981411856 139.73823637288382 17.703 35.670590981411856 139.73823637288382 23.26 35.67059503662705 139.73823515298218 23.26 35.67059503662705 139.73823515298218 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670590981411856 139.73823637288382 23.26 35.670597857833094 139.7382692826696 23.26 35.670613808283406 139.73826440338925 23.26 35.670629642623766 139.7383408249655 23.26 35.67070642070746 139.73831687398254 23.26 35.6707018968475 139.7382953390518 23.26 35.67073677140558 139.73828447233075 23.26 35.67073496185973 139.73827585835562 23.26 35.67075523776255 139.73826953791922 23.26 35.67075315640853 139.7382591568551 23.26 35.6707622580868 139.73825638448423 23.26 35.670752938271825 139.73821121612588 23.26 35.67074942379306 139.7382123249265 23.26 35.67073539770462 139.7381429707518 23.26 35.670586526380596 139.73818788496513 23.26 35.67059503662705 139.73823515298218 23.26 35.670590981411856 139.73823637288382 23.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c342cf27-e08e-43ce-9e50-17bd39526727"/>
							<gml:surfaceMember xlink:href="#poly-db704931-6ff5-443e-ac70-5c24a0faee53"/>
							<gml:surfaceMember xlink:href="#poly-997ead7f-48bd-4c4c-9b77-efd6dc8b8b46"/>
							<gml:surfaceMember xlink:href="#poly-11377ef4-84ed-4d6c-abad-dc80302f0002"/>
							<gml:surfaceMember xlink:href="#poly-9158ff87-f70b-45f2-98b1-c556d1ecfd48"/>
							<gml:surfaceMember xlink:href="#poly-1c28f912-c4cc-418e-b22a-99ae647feabb"/>
							<gml:surfaceMember xlink:href="#poly-5e8d7fc2-173b-4e0a-90b8-3a85c69618e3"/>
							<gml:surfaceMember xlink:href="#poly-5e2bfe7f-7d5a-4357-ba44-5fe8a7db6b3b"/>
							<gml:surfaceMember xlink:href="#poly-1823a21b-b9a1-43cd-9ce8-40b15d0cead8"/>
							<gml:surfaceMember xlink:href="#poly-354b24e0-8531-4eb5-a4c5-a7ff9c243b81"/>
							<gml:surfaceMember xlink:href="#poly-50bc61f6-3d63-4d8f-806e-9c50929de969"/>
							<gml:surfaceMember xlink:href="#poly-57030066-d86c-42d4-ab47-33834734713d"/>
							<gml:surfaceMember xlink:href="#poly-335b4eb8-8c9a-48a0-b8a6-04b5caf2001b"/>
							<gml:surfaceMember xlink:href="#poly-71179fff-6ef5-461b-8fbd-79036875ba5e"/>
							<gml:surfaceMember xlink:href="#poly-7ce9edc4-d367-42a2-9733-65524f5650c1"/>
							<gml:surfaceMember xlink:href="#poly-408761fd-ce58-4dc0-931c-1104ad8267c6"/>
							<gml:surfaceMember xlink:href="#poly-c0c69568-d3d0-4648-b95e-ead901b07af5"/>
							<gml:surfaceMember xlink:href="#poly-32e807e3-63a6-4039-a500-6d62cbf66938"/>
							<gml:surfaceMember xlink:href="#poly-bb5462cf-88f7-4498-bda1-e0821c1f4674"/>
							<gml:surfaceMember xlink:href="#poly-d4760542-0ba4-4383-a5f7-77f9376737b5"/>
							<gml:surfaceMember xlink:href="#poly-6f9556f8-997b-41ab-81e7-5d30178aeeae"/>
							<gml:surfaceMember xlink:href="#poly-e29789fe-cfd6-4d25-a04c-8d21bcaa220f"/>
							<gml:surfaceMember xlink:href="#poly-5b7c292f-b28c-4cb1-af43-1c8b2e9f9f67"/>
							<gml:surfaceMember xlink:href="#poly-97aadaa8-2d07-47dd-b9c3-06e69c3be7f9"/>
							<gml:surfaceMember xlink:href="#poly-d71784f6-a1a3-4e69-976a-15a7cd69c6a1"/>
							<gml:surfaceMember xlink:href="#poly-a68553bc-b79c-48cb-9ad7-27d8d9e70533"/>
							<gml:surfaceMember xlink:href="#poly-602cb085-5e6c-4ce8-a517-e9c0a33fc66a"/>
							<gml:surfaceMember xlink:href="#poly-0170b370-cab4-4c0a-b35e-7eafc40dcd13"/>
							<gml:surfaceMember xlink:href="#poly-f9621a23-3d66-44ec-a90e-9789922674b2"/>
							<gml:surfaceMember xlink:href="#poly-45189e73-2399-4c7f-b952-ce03a21d14fb"/>
							<gml:surfaceMember xlink:href="#poly-d52a885c-6dba-429c-b08b-b62282896264"/>
							<gml:surfaceMember xlink:href="#poly-c2148385-c233-430b-bc14-0c8fc02b1b67"/>
							<gml:surfaceMember xlink:href="#poly-657bac9d-ee3c-4147-8da9-fcaf602f0dd3"/>
							<gml:surfaceMember xlink:href="#poly-67ee8adf-07f3-432f-bea9-80448cf02b0f"/>
							<gml:surfaceMember xlink:href="#poly-20a1bc72-f214-4864-be73-fb61ef101bf2"/>
							<gml:surfaceMember xlink:href="#poly-1f43bfd5-8900-4c51-af92-3788447c86e7"/>
							<gml:surfaceMember xlink:href="#poly-14ac72ee-d46e-4d36-9ffc-5fceb3125053"/>
							<gml:surfaceMember xlink:href="#poly-13cd0dfe-a36e-43a6-8ad5-7976ba630270"/>
							<gml:surfaceMember xlink:href="#poly-7fa3891b-ff05-4fe4-9eac-359a92c9248c"/>
							<gml:surfaceMember xlink:href="#poly-4b6122d6-6954-4960-8c30-5f3188b078ff"/>
							<gml:surfaceMember xlink:href="#poly-c91053bf-14fd-44e4-81ff-4e572e02e88d"/>
							<gml:surfaceMember xlink:href="#poly-f3ee3b23-ae59-4bcc-97d2-11e1954d5ec7"/>
							<gml:surfaceMember xlink:href="#poly-8635f0bc-3cb0-4bfa-8505-e5340cc1f855"/>
							<gml:surfaceMember xlink:href="#poly-b0447a3a-6dc5-4914-b9b2-b36ccef44b87"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c342cf27-e08e-43ce-9e50-17bd39526727">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c342cf27-e08e-43ce-9e50-17bd39526727">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c342cf27-e08e-43ce-9e50-17bd39526727">
											<gml:posList>35.670753156408516 139.7382591568551 17.703 35.67075523776254 139.7382695379192 17.703 35.67073496185971 139.73827585835562 17.703 35.67073677140555 139.73828447233072 17.703 35.670701896847476 139.7382953390518 17.703 35.67070642070744 139.73831687398254 17.703 35.67062964262374 139.7383408249655 17.703 35.670613808283385 139.73826440338925 17.703 35.6705978578331 139.7382692826696 17.703 35.670590981411856 139.73823637288382 17.703 35.67059503662704 139.73823515298218 17.703 35.67058652638059 139.73818788496513 17.703 35.67073539770461 139.7381429707518 17.703 35.67074942379303 139.73821232492648 17.703 35.670752938271825 139.73821121612585 17.703 35.6707622580868 139.73825638448423 17.703 35.670753156408516 139.7382591568551 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db704931-6ff5-443e-ac70-5c24a0faee53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db704931-6ff5-443e-ac70-5c24a0faee53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db704931-6ff5-443e-ac70-5c24a0faee53">
											<gml:posList>35.67074942379303 139.73821232492648 25.26 35.67073539770461 139.7381429707518 25.26 35.67072457480104 139.73814624226188 25.26 35.67073896142772 139.73821558495374 25.26 35.67074942379303 139.73821232492648 25.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-997ead7f-48bd-4c4c-9b77-efd6dc8b8b46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-997ead7f-48bd-4c4c-9b77-efd6dc8b8b46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-997ead7f-48bd-4c4c-9b77-efd6dc8b8b46">
											<gml:posList>35.67073896142772 139.73821558495374 27.246 35.67072457480104 139.73814624226188 27.246 35.67071379695724 139.73814950267123 27.246 35.670727814185256 139.73821905567243 27.246 35.67073896142772 139.73821558495374 27.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11377ef4-84ed-4d6c-abad-dc80302f0002">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11377ef4-84ed-4d6c-abad-dc80302f0002">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11377ef4-84ed-4d6c-abad-dc80302f0002">
											<gml:posList>35.67065651509468 139.73824126598868 28.798 35.670727814185256 139.73821905567243 28.798 35.67071379695724 139.73814950267123 28.798 35.6706413168025 139.73817136096577 28.798 35.67065651509468 139.73824126598868 28.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9158ff87-f70b-45f2-98b1-c556d1ecfd48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9158ff87-f70b-45f2-98b1-c556d1ecfd48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9158ff87-f70b-45f2-98b1-c556d1ecfd48">
											<gml:posList>35.670651358602804 139.73821763302976 24.967 35.6706413168025 139.73817136096577 24.967 35.67058652638059 139.73818788496513 24.967 35.67059503662704 139.73823515298218 24.967 35.670651358602804 139.73821763302976 24.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c28f912-c4cc-418e-b22a-99ae647feabb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c28f912-c4cc-418e-b22a-99ae647feabb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c28f912-c4cc-418e-b22a-99ae647feabb">
											<gml:posList>35.67063035370012 139.7382596007255 23.709 35.67065651509468 139.73824126598868 23.298 35.670651358602804 139.73821763302976 22.244 35.67063035370012 139.7382596007255 23.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e8d7fc2-173b-4e0a-90b8-3a85c69618e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e8d7fc2-173b-4e0a-90b8-3a85c69618e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e8d7fc2-173b-4e0a-90b8-3a85c69618e3">
											<gml:posList>35.67063035370012 139.7382596007255 23.709 35.670651358602804 139.73821763302976 22.244 35.670623197615306 139.73822639300906 22.244 35.67063035370012 139.7382596007255 23.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e2bfe7f-7d5a-4357-ba44-5fe8a7db6b3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e2bfe7f-7d5a-4357-ba44-5fe8a7db6b3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e2bfe7f-7d5a-4357-ba44-5fe8a7db6b3b">
											<gml:posList>35.67063035370012 139.7382596007255 23.709 35.67071673954855 139.73823456677712 23.709 35.670714387029506 139.7382232360583 23.298 35.67063035370012 139.7382596007255 23.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1823a21b-b9a1-43cd-9ce8-40b15d0cead8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1823a21b-b9a1-43cd-9ce8-40b15d0cead8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1823a21b-b9a1-43cd-9ce8-40b15d0cead8">
											<gml:posList>35.67063035370012 139.7382596007255 23.709 35.670714387029506 139.7382232360583 23.298 35.67065651509468 139.73824126598868 23.298 35.67063035370012 139.7382596007255 23.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-354b24e0-8531-4eb5-a4c5-a7ff9c243b81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-354b24e0-8531-4eb5-a4c5-a7ff9c243b81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-354b24e0-8531-4eb5-a4c5-a7ff9c243b81">
											<gml:posList>35.67059503662704 139.73823515298218 21.959 35.670590981411856 139.73823637288382 21.959 35.6705978578331 139.7382692826696 21.959 35.670613808283385 139.73826440338925 21.959 35.67063035370012 139.7382596007255 21.959 35.670623197615306 139.73822639300906 21.959 35.67059503662704 139.73823515298218 21.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50bc61f6-3d63-4d8f-806e-9c50929de969">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50bc61f6-3d63-4d8f-806e-9c50929de969">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50bc61f6-3d63-4d8f-806e-9c50929de969">
											<gml:posList>35.67071673954855 139.73823456677712 21.959 35.67072767879261 139.73828731096458 21.959 35.67073677140555 139.73828447233072 21.959 35.67073496185971 139.73827585835562 21.959 35.67075523776254 139.7382695379192 21.959 35.670753156408516 139.7382591568551 21.959 35.6707622580868 139.73825638448423 21.959 35.670752938271825 139.73821121612585 21.959 35.67074942379303 139.73821232492648 21.959 35.670714387029506 139.7382232360583 21.959 35.67071673954855 139.73823456677712 21.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-57030066-d86c-42d4-ab47-33834734713d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57030066-d86c-42d4-ab47-33834734713d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57030066-d86c-42d4-ab47-33834734713d">
											<gml:posList>35.67072767879261 139.73828731096458 22.244 35.67071673954855 139.73823456677712 23.709 35.67063035370012 139.7382596007255 23.709 35.67072767879261 139.73828731096458 22.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-335b4eb8-8c9a-48a0-b8a6-04b5caf2001b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-335b4eb8-8c9a-48a0-b8a6-04b5caf2001b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-335b4eb8-8c9a-48a0-b8a6-04b5caf2001b">
											<gml:posList>35.67063035370012 139.7382596007255 23.709 35.67063475367638 139.73828405200356 22.244 35.67065703308213 139.7382694223863 22.935 35.67063035370012 139.7382596007255 23.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71179fff-6ef5-461b-8fbd-79036875ba5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71179fff-6ef5-461b-8fbd-79036875ba5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71179fff-6ef5-461b-8fbd-79036875ba5e">
											<gml:posList>35.67072767879261 139.73828731096458 22.244 35.67063035370012 139.7382596007255 23.709 35.67065703308213 139.7382694223863 22.935 35.67072767879261 139.73828731096458 22.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7ce9edc4-d367-42a2-9733-65524f5650c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ce9edc4-d367-42a2-9733-65524f5650c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ce9edc4-d367-42a2-9733-65524f5650c1">
											<gml:posList>35.67072767879261 139.73828731096458 22.244 35.67065703308213 139.7382694223863 22.935 35.670701896847476 139.7382953390518 22.244 35.67072767879261 139.73828731096458 22.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-408761fd-ce58-4dc0-931c-1104ad8267c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-408761fd-ce58-4dc0-931c-1104ad8267c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-408761fd-ce58-4dc0-931c-1104ad8267c6">
											<gml:posList>35.67067077116663 139.73832799566858 22.935 35.67065703308213 139.7382694223863 22.935 35.67063475367638 139.73828405200356 22.244 35.67067077116663 139.73832799566858 22.935</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0c69568-d3d0-4648-b95e-ead901b07af5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0c69568-d3d0-4648-b95e-ead901b07af5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0c69568-d3d0-4648-b95e-ead901b07af5">
											<gml:posList>35.67067077116663 139.73832799566858 22.935 35.67070642070744 139.73831687398254 22.244 35.670701896847476 139.7382953390518 22.244 35.67065703308213 139.7382694223863 22.935 35.67067077116663 139.73832799566858 22.935</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32e807e3-63a6-4039-a500-6d62cbf66938">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32e807e3-63a6-4039-a500-6d62cbf66938">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32e807e3-63a6-4039-a500-6d62cbf66938">
											<gml:posList>35.670613808283385 139.73826440338925 21.959 35.67062964262374 139.7383408249655 21.959 35.670644151160246 139.73833630088734 21.959 35.67063035370012 139.7382596007255 21.959 35.670613808283385 139.73826440338925 21.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb5462cf-88f7-4498-bda1-e0821c1f4674">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb5462cf-88f7-4498-bda1-e0821c1f4674">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb5462cf-88f7-4498-bda1-e0821c1f4674">
											<gml:posList>35.67063475367638 139.73828405200356 22.244 35.670644151160246 139.73833630088734 22.244 35.67067077116663 139.73832799566858 22.935 35.67063475367638 139.73828405200356 22.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4760542-0ba4-4383-a5f7-77f9376737b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4760542-0ba4-4383-a5f7-77f9376737b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4760542-0ba4-4383-a5f7-77f9376737b5">
											<gml:posList>35.67073539770461 139.7381429707518 17.703 35.67058652638059 139.73818788496513 17.703 35.67058652638059 139.73818788496513 24.967 35.6706413168025 139.73817136096577 24.967 35.6706413168025 139.73817136096577 28.798 35.67071379695724 139.73814950267123 28.798 35.67071379695724 139.73814950267123 27.246 35.67072457480104 139.73814624226188 27.246 35.67072457480104 139.73814624226188 25.26 35.67073539770461 139.7381429707518 25.26 35.67073539770461 139.7381429707518 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f9556f8-997b-41ab-81e7-5d30178aeeae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f9556f8-997b-41ab-81e7-5d30178aeeae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f9556f8-997b-41ab-81e7-5d30178aeeae">
											<gml:posList>35.67073539770461 139.7381429707518 25.26 35.67074942379303 139.73821232492648 25.26 35.67074942379303 139.73821232492648 21.959 35.67074942379303 139.73821232492648 17.703 35.67073539770461 139.7381429707518 17.703 35.67073539770461 139.7381429707518 25.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e29789fe-cfd6-4d25-a04c-8d21bcaa220f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e29789fe-cfd6-4d25-a04c-8d21bcaa220f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e29789fe-cfd6-4d25-a04c-8d21bcaa220f">
											<gml:posList>35.67072457480104 139.73814624226188 27.246 35.67073896142772 139.73821558495374 27.246 35.67073896142772 139.73821558495374 25.26 35.67072457480104 139.73814624226188 25.26 35.67072457480104 139.73814624226188 27.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b7c292f-b28c-4cb1-af43-1c8b2e9f9f67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b7c292f-b28c-4cb1-af43-1c8b2e9f9f67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b7c292f-b28c-4cb1-af43-1c8b2e9f9f67">
											<gml:posList>35.67071379695724 139.73814950267123 27.246 35.67071379695724 139.73814950267123 28.798 35.670727814185256 139.73821905567243 28.798 35.670727814185256 139.73821905567243 27.246 35.67071379695724 139.73814950267123 27.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97aadaa8-2d07-47dd-b9c3-06e69c3be7f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97aadaa8-2d07-47dd-b9c3-06e69c3be7f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97aadaa8-2d07-47dd-b9c3-06e69c3be7f9">
											<gml:posList>35.67065651509468 139.73824126598868 23.298 35.67065651509468 139.73824126598868 28.798 35.6706413168025 139.73817136096577 28.798 35.6706413168025 139.73817136096577 24.967 35.670651358602804 139.73821763302976 24.967 35.670651358602804 139.73821763302976 22.244 35.67065651509468 139.73824126598868 23.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d71784f6-a1a3-4e69-976a-15a7cd69c6a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d71784f6-a1a3-4e69-976a-15a7cd69c6a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d71784f6-a1a3-4e69-976a-15a7cd69c6a1">
											<gml:posList>35.67058652638059 139.73818788496513 24.967 35.67058652638059 139.73818788496513 17.703 35.67059503662704 139.73823515298218 17.703 35.67059503662704 139.73823515298218 21.959 35.67059503662704 139.73823515298218 24.967 35.67058652638059 139.73818788496513 24.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a68553bc-b79c-48cb-9ad7-27d8d9e70533">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a68553bc-b79c-48cb-9ad7-27d8d9e70533">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a68553bc-b79c-48cb-9ad7-27d8d9e70533">
											<gml:posList>35.670752938271825 139.73821121612585 17.703 35.67074942379303 139.73821232492648 17.703 35.67074942379303 139.73821232492648 21.959 35.670752938271825 139.73821121612585 21.959 35.670752938271825 139.73821121612585 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-602cb085-5e6c-4ce8-a517-e9c0a33fc66a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-602cb085-5e6c-4ce8-a517-e9c0a33fc66a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-602cb085-5e6c-4ce8-a517-e9c0a33fc66a">
											<gml:posList>35.67059503662704 139.73823515298218 24.967 35.67059503662704 139.73823515298218 21.959 35.670623197615306 139.73822639300906 21.959 35.670623197615306 139.73822639300906 22.244 35.670651358602804 139.73821763302976 22.244 35.670651358602804 139.73821763302976 24.967 35.67059503662704 139.73823515298218 24.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0170b370-cab4-4c0a-b35e-7eafc40dcd13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0170b370-cab4-4c0a-b35e-7eafc40dcd13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0170b370-cab4-4c0a-b35e-7eafc40dcd13">
											<gml:posList>35.670727814185256 139.73821905567243 28.798 35.67065651509468 139.73824126598868 28.798 35.67065651509468 139.73824126598868 23.298 35.670714387029506 139.7382232360583 23.298 35.670714387029506 139.7382232360583 21.959 35.67074942379303 139.73821232492648 21.959 35.67074942379303 139.73821232492648 25.26 35.67073896142772 139.73821558495374 25.26 35.67073896142772 139.73821558495374 27.246 35.670727814185256 139.73821905567243 27.246 35.670727814185256 139.73821905567243 28.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9621a23-3d66-44ec-a90e-9789922674b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9621a23-3d66-44ec-a90e-9789922674b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9621a23-3d66-44ec-a90e-9789922674b2">
											<gml:posList>35.67071673954855 139.73823456677712 21.959 35.670714387029506 139.7382232360583 21.959 35.670714387029506 139.7382232360583 23.298 35.67071673954855 139.73823456677712 23.709 35.67071673954855 139.73823456677712 21.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45189e73-2399-4c7f-b952-ce03a21d14fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45189e73-2399-4c7f-b952-ce03a21d14fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45189e73-2399-4c7f-b952-ce03a21d14fb">
											<gml:posList>35.6707622580868 139.73825638448423 17.703 35.670752938271825 139.73821121612585 17.703 35.670752938271825 139.73821121612585 21.959 35.6707622580868 139.73825638448423 21.959 35.6707622580868 139.73825638448423 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d52a885c-6dba-429c-b08b-b62282896264">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d52a885c-6dba-429c-b08b-b62282896264">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d52a885c-6dba-429c-b08b-b62282896264">
											<gml:posList>35.67059503662704 139.73823515298218 17.703 35.670590981411856 139.73823637288382 17.703 35.670590981411856 139.73823637288382 21.959 35.67059503662704 139.73823515298218 21.959 35.67059503662704 139.73823515298218 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2148385-c233-430b-bc14-0c8fc02b1b67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2148385-c233-430b-bc14-0c8fc02b1b67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2148385-c233-430b-bc14-0c8fc02b1b67">
											<gml:posList>35.67063035370012 139.7382596007255 21.959 35.67063035370012 139.7382596007255 23.709 35.670623197615306 139.73822639300906 22.244 35.670623197615306 139.73822639300906 21.959 35.67063035370012 139.7382596007255 21.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-657bac9d-ee3c-4147-8da9-fcaf602f0dd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-657bac9d-ee3c-4147-8da9-fcaf602f0dd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-657bac9d-ee3c-4147-8da9-fcaf602f0dd3">
											<gml:posList>35.670590981411856 139.73823637288382 17.703 35.6705978578331 139.7382692826696 17.703 35.6705978578331 139.7382692826696 21.959 35.670590981411856 139.73823637288382 21.959 35.670590981411856 139.73823637288382 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67ee8adf-07f3-432f-bea9-80448cf02b0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67ee8adf-07f3-432f-bea9-80448cf02b0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67ee8adf-07f3-432f-bea9-80448cf02b0f">
											<gml:posList>35.670753156408516 139.7382591568551 17.703 35.6707622580868 139.73825638448423 17.703 35.6707622580868 139.73825638448423 21.959 35.670753156408516 139.7382591568551 21.959 35.670753156408516 139.7382591568551 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20a1bc72-f214-4864-be73-fb61ef101bf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20a1bc72-f214-4864-be73-fb61ef101bf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20a1bc72-f214-4864-be73-fb61ef101bf2">
											<gml:posList>35.67071673954855 139.73823456677712 21.959 35.67071673954855 139.73823456677712 23.709 35.67072767879261 139.73828731096458 22.244 35.67072767879261 139.73828731096458 21.959 35.67071673954855 139.73823456677712 21.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f43bfd5-8900-4c51-af92-3788447c86e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f43bfd5-8900-4c51-af92-3788447c86e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f43bfd5-8900-4c51-af92-3788447c86e7">
											<gml:posList>35.67075523776254 139.7382695379192 17.703 35.670753156408516 139.7382591568551 17.703 35.670753156408516 139.7382591568551 21.959 35.67075523776254 139.7382695379192 21.959 35.67075523776254 139.7382695379192 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14ac72ee-d46e-4d36-9ffc-5fceb3125053">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14ac72ee-d46e-4d36-9ffc-5fceb3125053">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14ac72ee-d46e-4d36-9ffc-5fceb3125053">
											<gml:posList>35.6705978578331 139.7382692826696 17.703 35.670613808283385 139.73826440338925 17.703 35.670613808283385 139.73826440338925 21.959 35.6705978578331 139.7382692826696 21.959 35.6705978578331 139.7382692826696 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13cd0dfe-a36e-43a6-8ad5-7976ba630270">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13cd0dfe-a36e-43a6-8ad5-7976ba630270">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13cd0dfe-a36e-43a6-8ad5-7976ba630270">
											<gml:posList>35.67073496185971 139.73827585835562 17.703 35.67075523776254 139.7382695379192 17.703 35.67075523776254 139.7382695379192 21.959 35.67073496185971 139.73827585835562 21.959 35.67073496185971 139.73827585835562 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fa3891b-ff05-4fe4-9eac-359a92c9248c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fa3891b-ff05-4fe4-9eac-359a92c9248c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fa3891b-ff05-4fe4-9eac-359a92c9248c">
											<gml:posList>35.67073677140555 139.73828447233072 17.703 35.67073496185971 139.73827585835562 17.703 35.67073496185971 139.73827585835562 21.959 35.67073677140555 139.73828447233072 21.959 35.67073677140555 139.73828447233072 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b6122d6-6954-4960-8c30-5f3188b078ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b6122d6-6954-4960-8c30-5f3188b078ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b6122d6-6954-4960-8c30-5f3188b078ff">
											<gml:posList>35.670701896847476 139.7382953390518 22.244 35.670701896847476 139.7382953390518 17.703 35.67073677140555 139.73828447233072 17.703 35.67073677140555 139.73828447233072 21.959 35.67072767879261 139.73828731096458 21.959 35.67072767879261 139.73828731096458 22.244 35.670701896847476 139.7382953390518 22.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c91053bf-14fd-44e4-81ff-4e572e02e88d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c91053bf-14fd-44e4-81ff-4e572e02e88d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c91053bf-14fd-44e4-81ff-4e572e02e88d">
											<gml:posList>35.67063035370012 139.7382596007255 21.959 35.670644151160246 139.73833630088734 21.959 35.670644151160246 139.73833630088734 22.244 35.67063475367638 139.73828405200356 22.244 35.67063035370012 139.7382596007255 23.709 35.67063035370012 139.7382596007255 21.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3ee3b23-ae59-4bcc-97d2-11e1954d5ec7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3ee3b23-ae59-4bcc-97d2-11e1954d5ec7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3ee3b23-ae59-4bcc-97d2-11e1954d5ec7">
											<gml:posList>35.670613808283385 139.73826440338925 17.703 35.67062964262374 139.7383408249655 17.703 35.67062964262374 139.7383408249655 21.959 35.670613808283385 139.73826440338925 21.959 35.670613808283385 139.73826440338925 17.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8635f0bc-3cb0-4bfa-8505-e5340cc1f855">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8635f0bc-3cb0-4bfa-8505-e5340cc1f855">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8635f0bc-3cb0-4bfa-8505-e5340cc1f855">
											<gml:posList>35.670701896847476 139.7382953390518 22.244 35.67070642070744 139.73831687398254 22.244 35.67070642070744 139.73831687398254 17.703 35.670701896847476 139.7382953390518 17.703 35.670701896847476 139.7382953390518 22.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0447a3a-6dc5-4914-b9b2-b36ccef44b87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0447a3a-6dc5-4914-b9b2-b36ccef44b87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0447a3a-6dc5-4914-b9b2-b36ccef44b87">
											<gml:posList>35.670644151160246 139.73833630088734 21.959 35.67062964262374 139.7383408249655 21.959 35.67062964262374 139.7383408249655 17.703 35.67070642070744 139.73831687398254 17.703 35.67070642070744 139.73831687398254 22.244 35.67067077116663 139.73832799566858 22.935 35.670644151160246 139.73833630088734 22.244 35.670644151160246 139.73833630088734 21.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10841</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">163.82267</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>