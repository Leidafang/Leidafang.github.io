<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f29dc830-fb3e-43b9-9d5b-94fe9675831b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">26.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67301137111929 139.7383458902436 0 35.673020813321685 139.73834058772377 0 35.6730323870539 139.7383750063391 0 35.6731074234723 139.73833710482924 0 35.67305329661818 139.7381666090374 0 35.672966706647244 139.7382070319722 0 35.67301137111929 139.7383458902436 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67301137111929 139.7383458902436 8.468 35.672966706647244 139.7382070319722 8.468 35.67305329661818 139.7381666090374 8.468 35.6731074234723 139.73833710482924 8.468 35.6730323870539 139.7383750063391 8.468 35.673020813321685 139.73834058772377 8.468 35.67301137111929 139.7383458902436 8.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67301137111929 139.7383458902436 8.468 35.673020813321685 139.73834058772377 8.468 35.673020813321685 139.73834058772377 34.64 35.67301137111929 139.7383458902436 34.64 35.67301137111929 139.7383458902436 8.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673020813321685 139.73834058772377 8.468 35.6730323870539 139.7383750063391 8.468 35.6730323870539 139.7383750063391 34.64 35.673020813321685 139.73834058772377 34.64 35.673020813321685 139.73834058772377 8.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6730323870539 139.7383750063391 8.468 35.6731074234723 139.73833710482924 8.468 35.6731074234723 139.73833710482924 34.64 35.6730323870539 139.7383750063391 34.64 35.6730323870539 139.7383750063391 8.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6731074234723 139.73833710482924 8.468 35.67305329661818 139.7381666090374 8.468 35.67305329661818 139.7381666090374 34.64 35.6731074234723 139.73833710482924 34.64 35.6731074234723 139.73833710482924 8.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67305329661818 139.7381666090374 8.468 35.672966706647244 139.7382070319722 8.468 35.672966706647244 139.7382070319722 34.64 35.67305329661818 139.7381666090374 34.64 35.67305329661818 139.7381666090374 8.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672966706647244 139.7382070319722 8.468 35.67301137111929 139.7383458902436 8.468 35.67301137111929 139.7383458902436 34.64 35.672966706647244 139.7382070319722 34.64 35.672966706647244 139.7382070319722 8.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67301137111929 139.7383458902436 34.64 35.673020813321685 139.73834058772377 34.64 35.6730323870539 139.7383750063391 34.64 35.6731074234723 139.73833710482924 34.64 35.67305329661818 139.7381666090374 34.64 35.672966706647244 139.7382070319722 34.64 35.67301137111929 139.7383458902436 34.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-45f6ab90-2490-4cbc-ab82-2acfabfa3238"/>
							<gml:surfaceMember xlink:href="#poly-4911cd8d-2a11-40cf-a376-8be743ab319f"/>
							<gml:surfaceMember xlink:href="#poly-fd0b2b6b-305e-4e70-baa1-bd020f6405f4"/>
							<gml:surfaceMember xlink:href="#poly-fedb18c2-9def-4e45-9202-d62b23e937cc"/>
							<gml:surfaceMember xlink:href="#poly-b70fbbee-6fe6-4b93-bebd-05b35496da7f"/>
							<gml:surfaceMember xlink:href="#poly-04d0c7ea-82c9-4660-8dd9-0b519af36693"/>
							<gml:surfaceMember xlink:href="#poly-0f90f16c-fb11-4280-8981-f10b51cdb523"/>
							<gml:surfaceMember xlink:href="#poly-0d7bcd8d-7ac6-4298-b755-2dfc9bed13eb"/>
							<gml:surfaceMember xlink:href="#poly-3b281d28-5bfb-4a4b-86d7-f2dc1f143c92"/>
							<gml:surfaceMember xlink:href="#poly-79c85535-4c21-4983-95cd-f1769c8adc03"/>
							<gml:surfaceMember xlink:href="#poly-562b1a29-c942-4888-a0e3-a4b5013a1e05"/>
							<gml:surfaceMember xlink:href="#poly-2fa9242a-7ef0-4554-a4ce-deaf51d9d2de"/>
							<gml:surfaceMember xlink:href="#poly-1efda26b-7c2d-4924-b44a-f85cc01c1d43"/>
							<gml:surfaceMember xlink:href="#poly-2635374a-4916-4379-b483-a91dc472dfe4"/>
							<gml:surfaceMember xlink:href="#poly-ff0be199-4af3-4968-8ce0-9bebdd98d2dc"/>
							<gml:surfaceMember xlink:href="#poly-1a769d99-54fc-4792-baed-ada1098e2c3a"/>
							<gml:surfaceMember xlink:href="#poly-744ccdaf-be4e-4ab8-9f92-90e3d0f6e577"/>
							<gml:surfaceMember xlink:href="#poly-c0cd972f-1cba-4fe7-820d-d71b315bdd30"/>
							<gml:surfaceMember xlink:href="#poly-971206ae-bcdc-40fd-975c-af58149cee84"/>
							<gml:surfaceMember xlink:href="#poly-a9a66174-1edc-4254-9759-32c14a2de98c"/>
							<gml:surfaceMember xlink:href="#poly-cacd80d1-64eb-412b-8160-0054ad7ea6e3"/>
							<gml:surfaceMember xlink:href="#poly-79d6c3e9-db28-4eec-8302-569b1f973d62"/>
							<gml:surfaceMember xlink:href="#poly-71eec6cd-1955-4e7e-8aa4-edd1b7e56fa8"/>
							<gml:surfaceMember xlink:href="#poly-38cd5da1-c294-4777-b659-d2d363b513ce"/>
							<gml:surfaceMember xlink:href="#poly-057ebd54-24cd-4958-b984-96d06f41f3e2"/>
							<gml:surfaceMember xlink:href="#poly-46620e8e-cb55-4406-b271-0313b4494edf"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f29dc830-fb3e-43b9-9d5b-94fe9675831b_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b647c70-2c06-41e6-9f72-5ed74128c620">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67301524471403 139.73825160273284 35.986 35.673000326803816 139.7382057106719 35.986 35.67301811304104 139.738197029015 35.986 35.67303303095453 139.73824292108446 35.986 35.67301524471403 139.73825160273284 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f6b9975-1c49-4abb-b144-d398b99f2faf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f6b9975-1c49-4abb-b144-d398b99f2faf_0">
											<gml:posList>35.673000326803816 139.7382057106719 35.986 35.673000326803816 139.7382057106719 38.217 35.67301811304104 139.738197029015 38.217 35.67301811304104 139.738197029015 35.986 35.673000326803816 139.7382057106719 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a643ceb-a200-4017-82fa-a9be5346bc80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a643ceb-a200-4017-82fa-a9be5346bc80_0">
											<gml:posList>35.67301811304104 139.738197029015 35.986 35.67301811304104 139.738197029015 38.217 35.67303303095453 139.73824292108446 38.217 35.67303303095453 139.73824292108446 35.986 35.67301811304104 139.738197029015 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc5503d9-bf44-4cc1-b319-08ad598019d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc5503d9-bf44-4cc1-b319-08ad598019d6_0">
											<gml:posList>35.67301811304104 139.738197029015 38.217 35.673000326803816 139.7382057106719 38.217 35.67301524471403 139.73825160273284 38.217 35.67303303095453 139.73824292108446 38.217 35.67301811304104 139.738197029015 38.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6eddca6-1ec9-43da-9ad1-577d86835eb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6eddca6-1ec9-43da-9ad1-577d86835eb7_0">
											<gml:posList>35.67301524471403 139.73825160273284 35.986 35.67301524471403 139.73825160273284 38.217 35.673000326803816 139.7382057106719 38.217 35.673000326803816 139.7382057106719 35.986 35.67301524471403 139.73825160273284 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df3e41a7-480d-4a85-91f1-ecb87a786f18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df3e41a7-480d-4a85-91f1-ecb87a786f18_0">
											<gml:posList>35.67303303095453 139.73824292108446 35.986 35.67303303095453 139.73824292108446 38.217 35.67301524471403 139.73825160273284 38.217 35.67301524471403 139.73825160273284 35.986 35.67303303095453 139.73824292108446 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f29dc830-fb3e-43b9-9d5b-94fe9675831b_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2965049-129f-4e1d-b0e6-76cb05d455aa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67302236778038 139.73838006651346 8.56 35.67301137111929 139.7383458902436 8.56 35.67302081332167 139.73834058772377 8.56 35.67303238705388 139.7383750063391 8.56 35.67302236778038 139.73838006651346 8.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddec40ed-8af8-4298-aaa2-6414235e8d0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddec40ed-8af8-4298-aaa2-6414235e8d0d_0">
											<gml:posList>35.67302081332167 139.73834058772377 36.634 35.67302081332167 139.73834058772377 8.56 35.67301137111929 139.7383458902436 8.56 35.67301137111929 139.7383458902436 36.634 35.67302081332167 139.73834058772377 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33fe114e-485e-4d30-a563-396ac5cc776e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33fe114e-485e-4d30-a563-396ac5cc776e_0">
											<gml:posList>35.67301137111929 139.7383458902436 36.634 35.67301137111929 139.7383458902436 8.56 35.67302236778038 139.73838006651346 8.56 35.67302236778038 139.73838006651346 36.634 35.67301137111929 139.7383458902436 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf7344d9-5b42-424c-8591-355e184b323a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf7344d9-5b42-424c-8591-355e184b323a_0">
											<gml:posList>35.67302236778038 139.73838006651346 36.634 35.67303238705388 139.7383750063391 36.634 35.67302081332167 139.73834058772377 36.634 35.67301137111929 139.7383458902436 36.634 35.67302236778038 139.73838006651346 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75de67d1-25da-4288-bc6c-f945856dfe56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75de67d1-25da-4288-bc6c-f945856dfe56_0">
											<gml:posList>35.67302081332167 139.73834058772377 8.56 35.67302081332167 139.73834058772377 36.634 35.67303238705388 139.7383750063391 36.634 35.67303238705388 139.7383750063391 8.56 35.67302081332167 139.73834058772377 8.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9af5c78a-ee9f-4802-8755-9588e6590450">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9af5c78a-ee9f-4802-8755-9588e6590450_0">
											<gml:posList>35.67302236778038 139.73838006651346 36.634 35.67302236778038 139.73838006651346 8.56 35.67303238705388 139.7383750063391 8.56 35.67303238705388 139.7383750063391 36.634 35.67302236778038 139.73838006651346 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f29dc830-fb3e-43b9-9d5b-94fe9675831b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2876c9f-7c75-44bb-8d83-6a656fdc5ad5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67296946604063 139.7382085420844 36.634 35.67297523094661 139.7382264528565 36.634 35.67297375326397 139.7382271726396 36.634 35.67296754520231 139.7382073844689 36.634 35.672984115216195 139.73819949961566 36.634 35.672984720653936 139.73820142100877 36.634 35.67296946604063 139.7382085420844 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b98fdf1-1030-4e2c-b1e8-cc6c0e3f932f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672990250986146 139.7382190558966 35.986 35.67297523094661 139.7382264528565 35.986 35.67296946604063 139.7382085420844 35.986 35.672984720653936 139.73820142100877 35.986 35.672990250986146 139.7382190558966 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5522b433-7a63-47bd-a33d-78006439e87b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6729775712581 139.73823374084745 35.986 35.67299469981884 139.73822546870434 35.986 35.67300825368484 139.7382676065319 35.986 35.67299112512122 139.73827587866742 35.986 35.6729775712581 139.73823374084745 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e86d238-c521-4dca-828d-f4d36651e2a0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6729775712581 139.73823374084745 36.634 35.67299112512122 139.73827587866742 36.634 35.672990097949786 139.73827637698318 36.634 35.67297654408683 139.73823423916363 36.634 35.6729775712581 139.73823374084745 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20960eed-e54f-4a67-981d-15a31bf3ee53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6730300889482 139.73827269522658 35.986 35.67302674573529 139.7382623926907 35.986 35.67304151354109 139.73825518382452 35.986 35.6730448657596 139.73826547530467 35.986 35.6730300889482 139.73827269522658 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f66c9357-a657-44ed-9b16-bbe055754208">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673047995133295 139.73826751521975 35.986 35.67305170878026 139.73827892198207 35.986 35.67303350807185 139.73828781400172 35.986 35.673029794425716 139.73827640724156 35.986 35.673047995133295 139.73826751521975 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39f20dc2-ffb6-4de0-9164-1af8eed1eb5a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67301610230495 139.73829890335287 35.986 35.673011665801006 139.73828526603407 35.986 35.67302027960196 139.73828105810492 35.986 35.67302471610636 139.73829469542497 35.986 35.67301610230495 139.73829890335287 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33fc065d-29b5-4b6d-be49-64d31b09b327">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673038899166485 139.7383003565769 35.986 35.67303654991506 139.73829315696204 35.986 35.67304708290577 139.73828801884054 35.986 35.673049423143766 139.73829521846687 35.986 35.673038899166485 139.7383003565769 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d912331b-28c3-4940-9d54-d1c35d97559e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6730303182121 139.73831192151786 35.986 35.67302202877318 139.7383159633604 35.986 35.67301831511229 139.73830453450734 35.986 35.67302659552838 139.73830048162787 35.986 35.6730303182121 139.73831192151786 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33957dc1-c065-4aef-b1f3-44bb9980446c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67307191478504 139.73833251836695 35.986 35.67304219093017 139.73834827293845 35.986 35.67303966143339 139.73834110667536 35.986 35.67306938529606 139.7383253631483 35.986 35.67307191478504 139.73833251836695 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6456d64-120d-459e-b1e9-f40774c0ac5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6456d64-120d-459e-b1e9-f40774c0ac5e_0">
											<gml:posList>35.6730300889482 139.73827269522658 35.986 35.6730448657596 139.73826547530467 35.986 35.6730448657596 139.73826547530467 37.452 35.6730300889482 139.73827269522658 37.452 35.6730300889482 139.73827269522658 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e71f95ff-2882-45f7-a36c-40291337a7e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e71f95ff-2882-45f7-a36c-40291337a7e6_0">
											<gml:posList>35.67297375326397 139.7382271726396 36.634 35.67297375326397 139.7382271726396 36.776 35.67296754520231 139.7382073844689 36.776 35.67296754520231 139.7382073844689 36.634 35.67297375326397 139.7382271726396 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de7d9792-d9c0-4d87-821c-64462bcc6f91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de7d9792-d9c0-4d87-821c-64462bcc6f91_0">
											<gml:posList>35.67296946604063 139.7382085420844 35.986 35.67297523094661 139.7382264528565 35.986 35.67297523094661 139.7382264528565 36.634 35.67296946604063 139.7382085420844 36.634 35.67296946604063 139.7382085420844 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a6425e4-f96d-4d60-bb0e-737866b0791f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a6425e4-f96d-4d60-bb0e-737866b0791f_0">
											<gml:posList>35.672984115216195 139.73819949961566 36.634 35.67296754520231 139.7382073844689 36.634 35.67296754520231 139.7382073844689 36.776 35.672984115216195 139.73819949961566 36.776 35.672984115216195 139.73819949961566 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-171cd8e7-6cea-4a15-a8ce-80cc6fcad7f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-171cd8e7-6cea-4a15-a8ce-80cc6fcad7f8_0">
											<gml:posList>35.67296946604063 139.7382085420844 36.634 35.672984720653936 139.73820142100877 36.634 35.672984720653936 139.73820142100877 35.986 35.67296946604063 139.7382085420844 35.986 35.67296946604063 139.7382085420844 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7295ab12-ee18-4d77-97b5-c2915818b1aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7295ab12-ee18-4d77-97b5-c2915818b1aa_0">
											<gml:posList>35.672990250986146 139.7382190558966 36.776 35.672984115216195 139.73819949961566 36.776 35.67296754520231 139.7382073844689 36.776 35.67297375326397 139.7382271726396 36.776 35.672990250986146 139.7382190558966 36.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc48fa37-6659-4b20-909f-aa3aca4c109a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc48fa37-6659-4b20-909f-aa3aca4c109a_0">
											<gml:posList>35.67297523094661 139.7382264528565 36.634 35.67297523094661 139.7382264528565 35.986 35.672990250986146 139.7382190558966 35.986 35.672990250986146 139.7382190558966 36.776 35.67297375326397 139.7382271726396 36.776 35.67297375326397 139.7382271726396 36.634 35.67297523094661 139.7382264528565 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0f7f5fa-5f68-4a48-9d7d-fc92834e9603">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0f7f5fa-5f68-4a48-9d7d-fc92834e9603_0">
											<gml:posList>35.67297654408683 139.73823423916363 36.634 35.672990097949786 139.73827637698318 36.634 35.672990097949786 139.73827637698318 37.282 35.67297654408683 139.73823423916363 37.282 35.67297654408683 139.73823423916363 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be534488-fe2d-4fac-9db9-e21d06257392">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be534488-fe2d-4fac-9db9-e21d06257392_0">
											<gml:posList>35.67299112512122 139.73827587866742 36.634 35.6729775712581 139.73823374084745 36.634 35.6729775712581 139.73823374084745 35.986 35.67299112512122 139.73827587866742 35.986 35.67299112512122 139.73827587866742 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a48d225-9244-4edd-8a01-67abc1edeaa3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a48d225-9244-4edd-8a01-67abc1edeaa3_0">
											<gml:posList>35.67297654408683 139.73823423916363 37.282 35.67299469981884 139.73822546870434 37.282 35.67299469981884 139.73822546870434 35.986 35.6729775712581 139.73823374084745 35.986 35.6729775712581 139.73823374084745 36.634 35.67297654408683 139.73823423916363 36.634 35.67297654408683 139.73823423916363 37.282</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02e46aa8-451c-4e4e-a4c9-9e9b4bb3b48b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02e46aa8-451c-4e4e-a4c9-9e9b4bb3b48b_0">
											<gml:posList>35.672984115216195 139.73819949961566 36.776 35.672990250986146 139.7382190558966 36.776 35.672990250986146 139.7382190558966 35.986 35.672984720653936 139.73820142100877 35.986 35.672984720653936 139.73820142100877 36.634 35.672984115216195 139.73819949961566 36.634 35.672984115216195 139.73819949961566 36.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb8da634-3a02-4928-896a-bf597a149015">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb8da634-3a02-4928-896a-bf597a149015_0">
											<gml:posList>35.672990097949786 139.73827637698318 37.282 35.67300825368484 139.7382676065319 37.282 35.67299469981884 139.73822546870434 37.282 35.67297654408683 139.73823423916363 37.282 35.672990097949786 139.73827637698318 37.282</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6056e02-b307-49ac-bc94-aed8948a1509">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6056e02-b307-49ac-bc94-aed8948a1509_0">
											<gml:posList>35.67299112512122 139.73827587866742 36.634 35.67299112512122 139.73827587866742 35.986 35.67300825368484 139.7382676065319 35.986 35.67300825368484 139.7382676065319 37.282 35.672990097949786 139.73827637698318 37.282 35.672990097949786 139.73827637698318 36.634 35.67299112512122 139.73827587866742 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b1b1181-8b17-4662-9677-67bca265d3c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b1b1181-8b17-4662-9677-67bca265d3c1_0">
											<gml:posList>35.67299469981884 139.73822546870434 35.986 35.67299469981884 139.73822546870434 37.282 35.67300825368484 139.7382676065319 37.282 35.67300825368484 139.7382676065319 35.986 35.67299469981884 139.73822546870434 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d860aa59-a295-46db-827f-f294f18b1002">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d860aa59-a295-46db-827f-f294f18b1002_0">
											<gml:posList>35.673011665801006 139.73828526603407 35.986 35.67301610230495 139.73829890335287 35.986 35.67301610230495 139.73829890335287 37.326 35.673011665801006 139.73828526603407 37.326 35.673011665801006 139.73828526603407 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63bfb123-93be-466f-a7d5-87346dca3022">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63bfb123-93be-466f-a7d5-87346dca3022_0">
											<gml:posList>35.673011665801006 139.73828526603407 35.986 35.673011665801006 139.73828526603407 37.326 35.67302027960196 139.73828105810492 37.326 35.67302027960196 139.73828105810492 35.986 35.673011665801006 139.73828526603407 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e823971-1da9-41f6-9a63-dc3130450f19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e823971-1da9-41f6-9a63-dc3130450f19_0">
											<gml:posList>35.67301610230495 139.73829890335287 37.326 35.67302471610636 139.73829469542497 37.326 35.67302027960196 139.73828105810492 37.326 35.673011665801006 139.73828526603407 37.326 35.67301610230495 139.73829890335287 37.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35a108ff-6948-494e-b808-b94e9e7c9b42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35a108ff-6948-494e-b808-b94e9e7c9b42_0">
											<gml:posList>35.67301831511229 139.73830453450734 35.986 35.67302202877318 139.7383159633604 35.986 35.67302202877318 139.7383159633604 37.366 35.67301831511229 139.73830453450734 37.366 35.67301831511229 139.73830453450734 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b5a327e-ff08-4307-91d4-cd23f5e0a6b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b5a327e-ff08-4307-91d4-cd23f5e0a6b0_0">
											<gml:posList>35.67302471610636 139.73829469542497 35.986 35.67302471610636 139.73829469542497 37.326 35.67301610230495 139.73829890335287 37.326 35.67301610230495 139.73829890335287 35.986 35.67302471610636 139.73829469542497 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fccaaa37-1061-4fd0-bfc8-e8c179574a7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fccaaa37-1061-4fd0-bfc8-e8c179574a7f_0">
											<gml:posList>35.67301831511229 139.73830453450734 35.986 35.67301831511229 139.73830453450734 37.366 35.67302659552838 139.73830048162787 37.366 35.67302659552838 139.73830048162787 35.986 35.67301831511229 139.73830453450734 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-889375cc-06b2-464e-a986-cf2c1a9a608d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-889375cc-06b2-464e-a986-cf2c1a9a608d_0">
											<gml:posList>35.67302027960196 139.73828105810492 35.986 35.67302027960196 139.73828105810492 37.326 35.67302471610636 139.73829469542497 37.326 35.67302471610636 139.73829469542497 35.986 35.67302027960196 139.73828105810492 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e77a6a88-862b-43b9-9b23-a583549b789f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e77a6a88-862b-43b9-9b23-a583549b789f_0">
											<gml:posList>35.67301831511229 139.73830453450734 37.366 35.67302202877318 139.7383159633604 37.366 35.6730303182121 139.73831192151786 37.366 35.67302659552838 139.73830048162787 37.366 35.67301831511229 139.73830453450734 37.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2228d81f-5495-4c2f-a2bd-923cdff9f0dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2228d81f-5495-4c2f-a2bd-923cdff9f0dd_0">
											<gml:posList>35.67302202877318 139.7383159633604 35.986 35.6730303182121 139.73831192151786 35.986 35.6730303182121 139.73831192151786 37.366 35.67302202877318 139.7383159633604 37.366 35.67302202877318 139.7383159633604 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34ff1b0c-d76e-40c8-b313-6682815e675c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34ff1b0c-d76e-40c8-b313-6682815e675c_0">
											<gml:posList>35.67302674573529 139.7382623926907 35.986 35.6730300889482 139.73827269522658 35.986 35.6730300889482 139.73827269522658 37.452 35.67302674573529 139.7382623926907 37.452 35.67302674573529 139.7382623926907 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3de8321-5bd9-4cd4-b82a-c9f90d6a4472">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3de8321-5bd9-4cd4-b82a-c9f90d6a4472_0">
											<gml:posList>35.6730303182121 139.73831192151786 35.986 35.67302659552838 139.73830048162787 35.986 35.67302659552838 139.73830048162787 37.366 35.6730303182121 139.73831192151786 37.366 35.6730303182121 139.73831192151786 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9e4bdd8-22d1-45a6-874a-715c4cf9d069">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9e4bdd8-22d1-45a6-874a-715c4cf9d069_0">
											<gml:posList>35.673029794425716 139.73827640724156 35.986 35.67303350807185 139.73828781400172 35.986 35.67303350807185 139.73828781400172 37.452 35.673029794425716 139.73827640724156 37.452 35.673029794425716 139.73827640724156 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adb74f2e-f41a-4832-8ba6-04737080c5e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adb74f2e-f41a-4832-8ba6-04737080c5e4_0">
											<gml:posList>35.67304151354109 139.73825518382452 35.986 35.67302674573529 139.7382623926907 35.986 35.67302674573529 139.7382623926907 37.452 35.67304151354109 139.73825518382452 37.452 35.67304151354109 139.73825518382452 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46dba4c0-baed-401a-8c17-50f86c0a1ef6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46dba4c0-baed-401a-8c17-50f86c0a1ef6_0">
											<gml:posList>35.67304151354109 139.73825518382452 37.452 35.67302674573529 139.7382623926907 37.452 35.6730300889482 139.73827269522658 37.452 35.6730448657596 139.73826547530467 37.452 35.67304151354109 139.73825518382452 37.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec070447-edb8-489c-9aa4-90323ee7e816">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec070447-edb8-489c-9aa4-90323ee7e816_0">
											<gml:posList>35.67303654991506 139.73829315696204 35.986 35.673038899166485 139.7383003565769 35.986 35.673038899166485 139.7383003565769 37.485 35.67303654991506 139.73829315696204 37.485 35.67303654991506 139.73829315696204 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f691664a-3afe-4a37-8188-637006703b79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f691664a-3afe-4a37-8188-637006703b79_0">
											<gml:posList>35.673047995133295 139.73826751521975 35.986 35.673029794425716 139.73827640724156 35.986 35.673029794425716 139.73827640724156 37.452 35.673047995133295 139.73826751521975 37.452 35.673047995133295 139.73826751521975 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09cfb9ec-617c-4e19-8d39-d51fc563e487">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09cfb9ec-617c-4e19-8d39-d51fc563e487_0">
											<gml:posList>35.67303350807185 139.73828781400172 37.452 35.67305170878026 139.73827892198207 37.452 35.673047995133295 139.73826751521975 37.452 35.673029794425716 139.73827640724156 37.452 35.67303350807185 139.73828781400172 37.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c286919a-9b51-4a63-bdc0-71287f22f5c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c286919a-9b51-4a63-bdc0-71287f22f5c2_0">
											<gml:posList>35.67303966143339 139.73834110667536 35.986 35.67304219093017 139.73834827293845 35.986 35.67304219093017 139.73834827293845 37.822 35.67303966143339 139.73834110667536 37.822 35.67303966143339 139.73834110667536 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61ef3969-38fa-4819-b6ab-793dda694ca0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61ef3969-38fa-4819-b6ab-793dda694ca0_0">
											<gml:posList>35.67304708290577 139.73828801884054 35.986 35.67303654991506 139.73829315696204 35.986 35.67303654991506 139.73829315696204 37.485 35.67304708290577 139.73828801884054 37.485 35.67304708290577 139.73828801884054 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-322ef034-9d88-4716-b2b6-e368602026a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-322ef034-9d88-4716-b2b6-e368602026a1_0">
											<gml:posList>35.67303350807185 139.73828781400172 35.986 35.67305170878026 139.73827892198207 35.986 35.67305170878026 139.73827892198207 37.452 35.67303350807185 139.73828781400172 37.452 35.67303350807185 139.73828781400172 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5200eb1e-9e31-48db-9299-47009e795d1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5200eb1e-9e31-48db-9299-47009e795d1a_0">
											<gml:posList>35.673038899166485 139.7383003565769 37.485 35.673049423143766 139.73829521846687 37.485 35.67304708290577 139.73828801884054 37.485 35.67303654991506 139.73829315696204 37.485 35.673038899166485 139.7383003565769 37.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c814d5e6-c318-4829-ae35-503aa7e83e25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c814d5e6-c318-4829-ae35-503aa7e83e25_0">
											<gml:posList>35.6730448657596 139.73826547530467 35.986 35.67304151354109 139.73825518382452 35.986 35.67304151354109 139.73825518382452 37.452 35.6730448657596 139.73826547530467 37.452 35.6730448657596 139.73826547530467 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd97a405-91df-4e9e-a51c-2bcd46e57ff4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd97a405-91df-4e9e-a51c-2bcd46e57ff4_0">
											<gml:posList>35.673049423143766 139.73829521846687 35.986 35.673049423143766 139.73829521846687 37.485 35.673038899166485 139.7383003565769 37.485 35.673038899166485 139.7383003565769 35.986 35.673049423143766 139.73829521846687 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bcdfdfd-3953-427c-a9ac-6ad26436b248">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bcdfdfd-3953-427c-a9ac-6ad26436b248_0">
											<gml:posList>35.673049423143766 139.73829521846687 35.986 35.67304708290577 139.73828801884054 35.986 35.67304708290577 139.73828801884054 37.485 35.673049423143766 139.73829521846687 37.485 35.673049423143766 139.73829521846687 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc0bfb3b-1f1c-44e4-a6e6-6f9fb62b90f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc0bfb3b-1f1c-44e4-a6e6-6f9fb62b90f8_0">
											<gml:posList>35.673047995133295 139.73826751521975 35.986 35.673047995133295 139.73826751521975 37.452 35.67305170878026 139.73827892198207 37.452 35.67305170878026 139.73827892198207 35.986 35.673047995133295 139.73826751521975 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b65c864-de46-4f88-a69c-1226e904b626">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b65c864-de46-4f88-a69c-1226e904b626_0">
											<gml:posList>35.67303966143339 139.73834110667536 35.986 35.67303966143339 139.73834110667536 37.822 35.67306938529606 139.7383253631483 37.822 35.67306938529606 139.7383253631483 35.986 35.67303966143339 139.73834110667536 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ddde3fb-8069-44cf-bc01-b72ed84cde2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ddde3fb-8069-44cf-bc01-b72ed84cde2b_0">
											<gml:posList>35.67303966143339 139.73834110667536 37.822 35.67304219093017 139.73834827293845 37.822 35.67307191478504 139.73833251836695 37.822 35.67306938529606 139.7383253631483 37.822 35.67303966143339 139.73834110667536 37.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a241eacc-2199-4dc8-ba2c-e3a6e82c2b40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a241eacc-2199-4dc8-ba2c-e3a6e82c2b40_0">
											<gml:posList>35.67307191478504 139.73833251836695 35.986 35.67307191478504 139.73833251836695 37.822 35.67304219093017 139.73834827293845 37.822 35.67304219093017 139.73834827293845 35.986 35.67307191478504 139.73833251836695 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-538da672-b48d-4b9b-88c8-8829e88ad25e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-538da672-b48d-4b9b-88c8-8829e88ad25e_0">
											<gml:posList>35.67307191478504 139.73833251836695 35.986 35.67306938529606 139.7383253631483 35.986 35.67306938529606 139.7383253631483 37.822 35.67307191478504 139.73833251836695 37.822 35.67307191478504 139.73833251836695 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-45f6ab90-2490-4cbc-ab82-2acfabfa3238">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45f6ab90-2490-4cbc-ab82-2acfabfa3238">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45f6ab90-2490-4cbc-ab82-2acfabfa3238">
											<gml:posList>35.6731074234723 139.7383371048292 8.468 35.67303238705388 139.7383750063391 8.468 35.67302081332167 139.73834058772377 8.468 35.67301137111929 139.7383458902436 8.468 35.672966706647244 139.7382070319722 8.468 35.673053296618164 139.7381666090374 8.468 35.6731074234723 139.7383371048292 8.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4911cd8d-2a11-40cf-a376-8be743ab319f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4911cd8d-2a11-40cf-a376-8be743ab319f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4911cd8d-2a11-40cf-a376-8be743ab319f">
											<gml:posList>35.67301137111929 139.7383458902436 36.634 35.67301252211273 139.73834238710072 36.634 35.67296946604063 139.7382085420844 36.634 35.672966706647244 139.7382070319722 36.634 35.67301137111929 139.7383458902436 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fd0b2b6b-305e-4e70-baa1-bd020f6405f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd0b2b6b-305e-4e70-baa1-bd020f6405f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd0b2b6b-305e-4e70-baa1-bd020f6405f4">
											<gml:posList>35.672966706647244 139.7382070319722 36.634 35.67296946604063 139.7382085420844 36.634 35.673028078710026 139.73818117632996 36.634 35.673029283894444 139.73817781672582 36.634 35.672966706647244 139.7382070319722 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fedb18c2-9def-4e45-9202-d62b23e937cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fedb18c2-9def-4e45-9202-d62b23e937cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fedb18c2-9def-4e45-9202-d62b23e937cc">
											<gml:posList>35.67302081332167 139.73834058772377 36.634 35.673021937282506 139.73833709565906 36.634 35.67301252211273 139.73834238710072 36.634 35.67301137111929 139.7383458902436 36.634 35.67302081332167 139.73834058772377 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b70fbbee-6fe6-4b93-bebd-05b35496da7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b70fbbee-6fe6-4b93-bebd-05b35496da7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b70fbbee-6fe6-4b93-bebd-05b35496da7f">
											<gml:posList>35.673021937282506 139.73833709565906 35.986 35.67302972540717 139.7383602843416 35.986 35.673077982760425 139.7383347205026 35.986 35.673028078710026 139.73818117632996 35.986 35.67296946604063 139.7382085420844 35.986 35.67301252211273 139.73834238710072 35.986 35.673021937282506 139.73833709565906 35.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04d0c7ea-82c9-4660-8dd9-0b519af36693">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04d0c7ea-82c9-4660-8dd9-0b519af36693">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04d0c7ea-82c9-4660-8dd9-0b519af36693">
											<gml:posList>35.67302081332167 139.73834058772377 36.634 35.673028592388384 139.73836372118393 36.634 35.67302972540717 139.7383602843416 36.634 35.673021937282506 139.73833709565906 36.634 35.67302081332167 139.73834058772377 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0f90f16c-fb11-4280-8981-f10b51cdb523">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f90f16c-fb11-4280-8981-f10b51cdb523">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f90f16c-fb11-4280-8981-f10b51cdb523">
											<gml:posList>35.673029283894444 139.73817781672582 36.634 35.673028078710026 139.73818117632996 36.634 35.673077982760425 139.7383347205026 36.634 35.673080724020146 139.73833609808318 36.634 35.673029283894444 139.73817781672582 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d7bcd8d-7ac6-4298-b755-2dfc9bed13eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d7bcd8d-7ac6-4298-b755-2dfc9bed13eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d7bcd8d-7ac6-4298-b755-2dfc9bed13eb">
											<gml:posList>35.673080724020146 139.73833609808318 36.634 35.673077982760425 139.7383347205026 36.634 35.67302972540717 139.7383602843416 36.634 35.673028592388384 139.73836372118393 36.634 35.673080724020146 139.73833609808318 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b281d28-5bfb-4a4b-86d7-f2dc1f143c92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b281d28-5bfb-4a4b-86d7-f2dc1f143c92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b281d28-5bfb-4a4b-86d7-f2dc1f143c92">
											<gml:posList>35.673080724020146 139.73833609808318 35.454 35.673028592388384 139.73836372118393 35.454 35.67303238705388 139.7383750063391 33.082 35.673080724020146 139.73833609808318 35.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79c85535-4c21-4983-95cd-f1769c8adc03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79c85535-4c21-4983-95cd-f1769c8adc03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79c85535-4c21-4983-95cd-f1769c8adc03">
											<gml:posList>35.673053296618164 139.7381666090374 33.082 35.673029283894444 139.73817781672582 35.454 35.673080724020146 139.73833609808318 35.454 35.673053296618164 139.7381666090374 33.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-562b1a29-c942-4888-a0e3-a4b5013a1e05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-562b1a29-c942-4888-a0e3-a4b5013a1e05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-562b1a29-c942-4888-a0e3-a4b5013a1e05">
											<gml:posList>35.67303238705388 139.7383750063391 33.082 35.6731074234723 139.7383371048292 33.082 35.673080724020146 139.73833609808318 35.454 35.67303238705388 139.7383750063391 33.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2fa9242a-7ef0-4554-a4ce-deaf51d9d2de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fa9242a-7ef0-4554-a4ce-deaf51d9d2de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fa9242a-7ef0-4554-a4ce-deaf51d9d2de">
											<gml:posList>35.673080724020146 139.73833609808318 35.454 35.6731074234723 139.7383371048292 33.082 35.673053296618164 139.7381666090374 33.082 35.673080724020146 139.73833609808318 35.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1efda26b-7c2d-4924-b44a-f85cc01c1d43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1efda26b-7c2d-4924-b44a-f85cc01c1d43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1efda26b-7c2d-4924-b44a-f85cc01c1d43">
											<gml:posList>35.67302972540717 139.7383602843416 36.634 35.67302972540717 139.7383602843416 35.986 35.673021937282506 139.73833709565906 35.986 35.673021937282506 139.73833709565906 36.634 35.67302972540717 139.7383602843416 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2635374a-4916-4379-b483-a91dc472dfe4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2635374a-4916-4379-b483-a91dc472dfe4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2635374a-4916-4379-b483-a91dc472dfe4">
											<gml:posList>35.672966706647244 139.7382070319722 8.468 35.67301137111929 139.7383458902436 8.468 35.67301137111929 139.7383458902436 36.634 35.672966706647244 139.7382070319722 36.634 35.672966706647244 139.7382070319722 8.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff0be199-4af3-4968-8ce0-9bebdd98d2dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff0be199-4af3-4968-8ce0-9bebdd98d2dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff0be199-4af3-4968-8ce0-9bebdd98d2dc">
											<gml:posList>35.67301252211273 139.73834238710072 36.634 35.67301252211273 139.73834238710072 35.986 35.67296946604063 139.7382085420844 35.986 35.67296946604063 139.7382085420844 36.634 35.67301252211273 139.73834238710072 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a769d99-54fc-4792-baed-ada1098e2c3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a769d99-54fc-4792-baed-ada1098e2c3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a769d99-54fc-4792-baed-ada1098e2c3a">
											<gml:posList>35.67296946604063 139.7382085420844 36.634 35.67296946604063 139.7382085420844 35.986 35.673028078710026 139.73818117632996 35.986 35.673028078710026 139.73818117632996 36.634 35.67296946604063 139.7382085420844 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-744ccdaf-be4e-4ab8-9f92-90e3d0f6e577">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-744ccdaf-be4e-4ab8-9f92-90e3d0f6e577">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-744ccdaf-be4e-4ab8-9f92-90e3d0f6e577">
											<gml:posList>35.673053296618164 139.7381666090374 8.468 35.672966706647244 139.7382070319722 8.468 35.672966706647244 139.7382070319722 36.634 35.673029283894444 139.73817781672582 36.634 35.673029283894444 139.73817781672582 35.454 35.673053296618164 139.7381666090374 33.082 35.673053296618164 139.7381666090374 8.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0cd972f-1cba-4fe7-820d-d71b315bdd30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0cd972f-1cba-4fe7-820d-d71b315bdd30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0cd972f-1cba-4fe7-820d-d71b315bdd30">
											<gml:posList>35.67301137111929 139.7383458902436 8.468 35.67302081332167 139.73834058772377 8.468 35.67302081332167 139.73834058772377 36.634 35.67301137111929 139.7383458902436 36.634 35.67301137111929 139.7383458902436 8.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-971206ae-bcdc-40fd-975c-af58149cee84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-971206ae-bcdc-40fd-975c-af58149cee84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-971206ae-bcdc-40fd-975c-af58149cee84">
											<gml:posList>35.673021937282506 139.73833709565906 36.634 35.673021937282506 139.73833709565906 35.986 35.67301252211273 139.73834238710072 35.986 35.67301252211273 139.73834238710072 36.634 35.673021937282506 139.73833709565906 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9a66174-1edc-4254-9759-32c14a2de98c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9a66174-1edc-4254-9759-32c14a2de98c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9a66174-1edc-4254-9759-32c14a2de98c">
											<gml:posList>35.673028592388384 139.73836372118393 35.454 35.673028592388384 139.73836372118393 36.634 35.67302081332167 139.73834058772377 36.634 35.67302081332167 139.73834058772377 8.468 35.67303238705388 139.7383750063391 8.468 35.67303238705388 139.7383750063391 33.082 35.673028592388384 139.73836372118393 35.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cacd80d1-64eb-412b-8160-0054ad7ea6e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cacd80d1-64eb-412b-8160-0054ad7ea6e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cacd80d1-64eb-412b-8160-0054ad7ea6e3">
											<gml:posList>35.673028078710026 139.73818117632996 36.634 35.673028078710026 139.73818117632996 35.986 35.673077982760425 139.7383347205026 35.986 35.673077982760425 139.7383347205026 36.634 35.673028078710026 139.73818117632996 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79d6c3e9-db28-4eec-8302-569b1f973d62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79d6c3e9-db28-4eec-8302-569b1f973d62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79d6c3e9-db28-4eec-8302-569b1f973d62">
											<gml:posList>35.673077982760425 139.7383347205026 36.634 35.673077982760425 139.7383347205026 35.986 35.67302972540717 139.7383602843416 35.986 35.67302972540717 139.7383602843416 36.634 35.673077982760425 139.7383347205026 36.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71eec6cd-1955-4e7e-8aa4-edd1b7e56fa8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71eec6cd-1955-4e7e-8aa4-edd1b7e56fa8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71eec6cd-1955-4e7e-8aa4-edd1b7e56fa8">
											<gml:posList>35.673080724020146 139.73833609808318 35.454 35.673080724020146 139.73833609808318 36.634 35.673028592388384 139.73836372118393 36.634 35.673028592388384 139.73836372118393 35.454 35.673080724020146 139.73833609808318 35.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38cd5da1-c294-4777-b659-d2d363b513ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38cd5da1-c294-4777-b659-d2d363b513ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38cd5da1-c294-4777-b659-d2d363b513ce">
											<gml:posList>35.673029283894444 139.73817781672582 35.454 35.673029283894444 139.73817781672582 36.634 35.673080724020146 139.73833609808318 36.634 35.673080724020146 139.73833609808318 35.454 35.673029283894444 139.73817781672582 35.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-057ebd54-24cd-4958-b984-96d06f41f3e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-057ebd54-24cd-4958-b984-96d06f41f3e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-057ebd54-24cd-4958-b984-96d06f41f3e2">
											<gml:posList>35.67303238705388 139.7383750063391 8.468 35.6731074234723 139.7383371048292 8.468 35.6731074234723 139.7383371048292 33.082 35.67303238705388 139.7383750063391 33.082 35.67303238705388 139.7383750063391 8.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46620e8e-cb55-4406-b271-0313b4494edf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46620e8e-cb55-4406-b271-0313b4494edf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46620e8e-cb55-4406-b271-0313b4494edf">
											<gml:posList>35.6731074234723 139.7383371048292 8.468 35.673053296618164 139.7381666090374 8.468 35.673053296618164 139.7381666090374 33.082 35.6731074234723 139.7383371048292 33.082 35.6731074234723 139.7383371048292 8.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4863</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">171.03375</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.1</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>