<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f34e8b93-8831-42df-841e-05d50b3aca95">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">11.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66890058538251 139.7381718694612 0 35.66901474047905 139.73799610144903 0 35.668962239664154 139.73794446829453 0 35.668848265353134 139.7381207883526 0 35.66890058538251 139.7381718694612 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890058538251 139.7381718694612 20.493 35.668848265353134 139.7381207883526 20.493 35.668962239664154 139.73794446829453 20.493 35.66901474047905 139.73799610144903 20.493 35.66890058538251 139.7381718694612 20.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890058538251 139.7381718694612 20.493 35.66901474047905 139.73799610144903 20.493 35.66901474047905 139.73799610144903 31.96 35.66890058538251 139.7381718694612 31.96 35.66890058538251 139.7381718694612 20.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66901474047905 139.73799610144903 20.493 35.668962239664154 139.73794446829453 20.493 35.668962239664154 139.73794446829453 31.96 35.66901474047905 139.73799610144903 31.96 35.66901474047905 139.73799610144903 20.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668962239664154 139.73794446829453 20.493 35.668848265353134 139.7381207883526 20.493 35.668848265353134 139.7381207883526 31.96 35.668962239664154 139.73794446829453 31.96 35.668962239664154 139.73794446829453 20.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668848265353134 139.7381207883526 20.493 35.66890058538251 139.7381718694612 20.493 35.66890058538251 139.7381718694612 31.96 35.668848265353134 139.7381207883526 31.96 35.668848265353134 139.7381207883526 20.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890058538251 139.7381718694612 31.96 35.66901474047905 139.73799610144903 31.96 35.668962239664154 139.73794446829453 31.96 35.668848265353134 139.7381207883526 31.96 35.66890058538251 139.7381718694612 31.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d3e6937b-6bc3-431f-bae8-068b1eca1ac9"/>
							<gml:surfaceMember xlink:href="#poly-568e24c9-a791-4562-9521-00fc4b79f468"/>
							<gml:surfaceMember xlink:href="#poly-4670ddff-cd4a-4576-b71a-3203a0ec16ae"/>
							<gml:surfaceMember xlink:href="#poly-c6ca06b4-6e5e-4688-a76d-55c12e0dc6cb"/>
							<gml:surfaceMember xlink:href="#poly-a5fc541d-a4c7-49f8-ad9d-1419a968a55c"/>
							<gml:surfaceMember xlink:href="#poly-c701f6e6-58a2-4754-bad3-8bf55ebf346f"/>
							<gml:surfaceMember xlink:href="#poly-8012ca9f-a393-4c53-a4c2-c9f49776133e"/>
							<gml:surfaceMember xlink:href="#poly-505fb9db-40b8-44ee-84e5-7a8e5a390d77"/>
							<gml:surfaceMember xlink:href="#poly-dab146de-c527-4b21-a023-5f5952cedb5e"/>
							<gml:surfaceMember xlink:href="#poly-944af487-a0ee-4d84-a817-26b66d2ab212"/>
							<gml:surfaceMember xlink:href="#poly-89f9a4c4-d332-4d2b-a3db-1605df72d7f3"/>
							<gml:surfaceMember xlink:href="#poly-0e33c5dd-55f9-48be-8365-7ad5c58007e9"/>
							<gml:surfaceMember xlink:href="#poly-67731a64-df35-4c27-b827-df04c6e1c613"/>
							<gml:surfaceMember xlink:href="#poly-402b6e3f-b536-419e-9446-cc03e0906213"/>
							<gml:surfaceMember xlink:href="#poly-631354e5-56f7-4f80-8bc4-f00cc2cac8ee"/>
							<gml:surfaceMember xlink:href="#poly-3e8645ed-9e51-4472-948a-6f743061508e"/>
							<gml:surfaceMember xlink:href="#poly-03636acd-96b2-4c70-a1e2-519dad28a2be"/>
							<gml:surfaceMember xlink:href="#poly-21385449-57c0-49d4-94b0-4614b598d0a7"/>
							<gml:surfaceMember xlink:href="#poly-74a435a4-4603-475c-bfad-215c972fb91c"/>
							<gml:surfaceMember xlink:href="#poly-d1212a72-86c4-4f1b-afa2-7f889ed716a6"/>
							<gml:surfaceMember xlink:href="#poly-02fdfebd-27cd-4b8b-9904-18512f1463ce"/>
							<gml:surfaceMember xlink:href="#poly-db88f5ed-77ae-4e61-858e-59db149d2817"/>
							<gml:surfaceMember xlink:href="#poly-018e290e-4a8b-42d2-b41b-9d93baa44777"/>
							<gml:surfaceMember xlink:href="#poly-b807e130-1a32-4598-a624-6bfb6daae019"/>
							<gml:surfaceMember xlink:href="#poly-316be1dc-5170-42ea-8d2f-ebb771221241"/>
							<gml:surfaceMember xlink:href="#poly-8494363e-21ce-423c-b7b7-0591fb315f81"/>
							<gml:surfaceMember xlink:href="#poly-2455f10f-541b-4deb-897d-5520a3ce8c26"/>
							<gml:surfaceMember xlink:href="#poly-66b6b49b-4e7e-421d-acde-e129228d3a64"/>
							<gml:surfaceMember xlink:href="#poly-db886fc5-effd-49cc-a097-3daa1fd9c150"/>
							<gml:surfaceMember xlink:href="#poly-8061376e-6848-4506-8be0-888309c8fba1"/>
							<gml:surfaceMember xlink:href="#poly-866a4dbf-0e8e-4165-a883-2f570ff64e5a"/>
							<gml:surfaceMember xlink:href="#poly-513d3df2-e571-4a2c-9f1b-5f3883a1a0fa"/>
							<gml:surfaceMember xlink:href="#poly-487a8150-97c2-455c-bfd4-831dd353f65b"/>
							<gml:surfaceMember xlink:href="#poly-bde67716-2bd0-4e79-9fa5-2e375103bceb"/>
							<gml:surfaceMember xlink:href="#poly-056c833a-f7ad-457c-b0a6-cdd49b161d1b"/>
							<gml:surfaceMember xlink:href="#poly-ed69da8f-8a88-409c-82d8-0aa8b16c5531"/>
							<gml:surfaceMember xlink:href="#poly-d2ef262b-7932-49ea-a081-981590445d1c"/>
							<gml:surfaceMember xlink:href="#poly-4f5dcb10-046b-49a1-bf63-5dc9a75ad251"/>
							<gml:surfaceMember xlink:href="#poly-c4241cce-7b6e-4aa9-8790-e347181d511c"/>
							<gml:surfaceMember xlink:href="#poly-645d9dcd-152a-4412-811b-241f71ed04f5"/>
							<gml:surfaceMember xlink:href="#poly-fa014719-269c-4a9f-b5c1-170fde7d6ebb"/>
							<gml:surfaceMember xlink:href="#poly-bd310e3c-9101-4df7-8bd3-fb9b450458b0"/>
							<gml:surfaceMember xlink:href="#poly-11637941-e70d-4125-a1ff-2cfa5a8ded65"/>
							<gml:surfaceMember xlink:href="#poly-6278ce0f-eded-4894-afc6-ea0549f26b18"/>
							<gml:surfaceMember xlink:href="#poly-2985c900-dafc-45d4-861e-c9c4f1f81245"/>
							<gml:surfaceMember xlink:href="#poly-a9adae5f-e8d2-48aa-8095-a6b770bbb2cc"/>
							<gml:surfaceMember xlink:href="#poly-911b3172-e391-4c72-aced-5bc1c157e847"/>
							<gml:surfaceMember xlink:href="#poly-bfefbdcc-561b-4bc5-8f0a-41c4ffaedd8c"/>
							<gml:surfaceMember xlink:href="#poly-84a53889-ff1b-4fdb-b9f5-5710f3ef315b"/>
							<gml:surfaceMember xlink:href="#poly-797b1a5a-c538-48d8-8f0b-5447e23d781a"/>
							<gml:surfaceMember xlink:href="#poly-359d9673-fb1b-4317-a11b-593c6f7e209a"/>
							<gml:surfaceMember xlink:href="#poly-51a64159-3a57-4dac-a002-f00574a66c69"/>
							<gml:surfaceMember xlink:href="#poly-ec490a76-bfb4-4fc0-b704-32cf6d9bfb5e"/>
							<gml:surfaceMember xlink:href="#poly-0b4fc1e8-23b7-44f4-8fe2-97781d6f006f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f34e8b93-8831-42df-841e-05d50b3aca95_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-020cada6-35ff-40cd-9803-d073ad573991">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668901793447574 139.7381493451202 33.066 35.668893611861115 139.73814158945635 33.066 35.668905567118486 139.73812264232302 33.066 35.668913757711145 139.73813038692936 33.066 35.668901793447574 139.7381493451202 33.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3f22f36-358c-4aec-be08-658e61fbc3ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3f22f36-358c-4aec-be08-658e61fbc3ff_0">
											<gml:posList>35.668905567118486 139.73812264232302 39.996 35.668913757711145 139.73813038692936 39.996 35.668913757711145 139.73813038692936 33.066 35.668905567118486 139.73812264232302 33.066 35.668905567118486 139.73812264232302 39.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4b43c1e-c7eb-4eef-8a9b-658615c04137">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4b43c1e-c7eb-4eef-8a9b-658615c04137_0">
											<gml:posList>35.668893611861115 139.73814158945635 33.066 35.668893611861115 139.73814158945635 39.996 35.668905567118486 139.73812264232302 39.996 35.668905567118486 139.73812264232302 33.066 35.668893611861115 139.73814158945635 33.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d42768b-f306-48ce-be3c-9235772782dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d42768b-f306-48ce-be3c-9235772782dc_0">
											<gml:posList>35.668905567118486 139.73812264232302 39.996 35.668893611861115 139.73814158945635 39.996 35.668901793447574 139.7381493451202 39.996 35.668913757711145 139.73813038692936 39.996 35.668905567118486 139.73812264232302 39.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b932d39d-ee9d-43ef-97d2-e3f9c4ce67eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b932d39d-ee9d-43ef-97d2-e3f9c4ce67eb_0">
											<gml:posList>35.668913757711145 139.73813038692936 33.066 35.668913757711145 139.73813038692936 39.996 35.668901793447574 139.7381493451202 39.996 35.668901793447574 139.7381493451202 33.066 35.668913757711145 139.73813038692936 33.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b0283ee-2fc8-4904-bed6-2d59fad47a14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b0283ee-2fc8-4904-bed6-2d59fad47a14_0">
											<gml:posList>35.668901793447574 139.7381493451202 39.996 35.668893611861115 139.73814158945635 39.996 35.668893611861115 139.73814158945635 33.066 35.668901793447574 139.7381493451202 33.066 35.668901793447574 139.7381493451202 39.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d3e6937b-6bc3-431f-bae8-068b1eca1ac9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3e6937b-6bc3-431f-bae8-068b1eca1ac9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3e6937b-6bc3-431f-bae8-068b1eca1ac9">
											<gml:posList>35.6689005853825 139.73817186946118 20.493 35.66884826535312 139.73812078835257 20.493 35.66896223966416 139.73794446829453 20.493 35.66901474047905 139.73799610144906 20.493 35.6689005853825 139.73817186946118 20.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-568e24c9-a791-4562-9521-00fc4b79f468">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-568e24c9-a791-4562-9521-00fc4b79f468">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-568e24c9-a791-4562-9521-00fc4b79f468">
											<gml:posList>35.6689005853825 139.73817186946118 33.231 35.66890042165145 139.7381699918261 33.231 35.668881406035915 139.73815143493397 33.231 35.66887988289112 139.73815165766308 33.231 35.6689005853825 139.73817186946118 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4670ddff-cd4a-4576-b71a-3203a0ec16ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4670ddff-cd4a-4576-b71a-3203a0ec16ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4670ddff-cd4a-4576-b71a-3203a0ec16ae">
											<gml:posList>35.6689044963151 139.73803380016693 28.239 35.66884826535312 139.73812078835257 28.239 35.66887988289112 139.73815165766308 33.231 35.6689363663293 139.73806475753324 33.231 35.6689044963151 139.73803380016693 28.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c6ca06b4-6e5e-4688-a76d-55c12e0dc6cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6ca06b4-6e5e-4688-a76d-55c12e0dc6cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6ca06b4-6e5e-4688-a76d-55c12e0dc6cb">
											<gml:posList>35.66890042165145 139.7381699918261 33.066 35.668935320234105 139.73810970519486 33.066 35.66892171687155 139.73809623411302 33.066 35.668881406035915 139.73815143493397 33.066 35.66890042165145 139.7381699918261 33.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a5fc541d-a4c7-49f8-ad9d-1419a968a55c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5fc541d-a4c7-49f8-ad9d-1419a968a55c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5fc541d-a4c7-49f8-ad9d-1419a968a55c">
											<gml:posList>35.6689363663293 139.73806475753324 33.231 35.66887988289112 139.73815165766308 33.231 35.668881406035915 139.73815143493397 33.231 35.66893788948265 139.73806454584835 33.231 35.6689363663293 139.73806475753324 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c701f6e6-58a2-4754-bad3-8bf55ebf346f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c701f6e6-58a2-4754-bad3-8bf55ebf346f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c701f6e6-58a2-4754-bad3-8bf55ebf346f">
											<gml:posList>35.668935320234105 139.73810970519486 36.338 35.66893509275959 139.73810701022634 36.338 35.668923925006844 139.73809594429275 36.338 35.66892171687155 139.73809623411302 36.338 35.668935320234105 139.73810970519486 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8012ca9f-a393-4c53-a4c2-c9f49776133e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8012ca9f-a393-4c53-a4c2-c9f49776133e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8012ca9f-a393-4c53-a4c2-c9f49776133e">
											<gml:posList>35.6689363663293 139.73806475753324 33.231 35.66893788948265 139.73806454584835 33.231 35.66892727211383 139.73805417516795 33.231 35.66892573994677 139.73805438686375 33.231 35.6689363663293 139.73806475753324 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-505fb9db-40b8-44ee-84e5-7a8e5a390d77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-505fb9db-40b8-44ee-84e5-7a8e5a390d77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-505fb9db-40b8-44ee-84e5-7a8e5a390d77">
											<gml:posList>35.668942801735135 139.73806425281418 36.338 35.66892171687155 139.73809623411302 36.338 35.668923925006844 139.73809594429275 36.338 35.668945018892806 139.7380639740283 36.338 35.668942801735135 139.73806425281418 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dab146de-c527-4b21-a023-5f5952cedb5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dab146de-c527-4b21-a023-5f5952cedb5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dab146de-c527-4b21-a023-5f5952cedb5e">
											<gml:posList>35.66896480292556 139.7379942388104 33.231 35.66896223966416 139.73794446829453 28.239 35.6689044963151 139.73803380016693 28.239 35.66892573994677 139.73805438686375 33.231 35.66896480292556 139.7379942388104 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-944af487-a0ee-4d84-a817-26b66d2ab212">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-944af487-a0ee-4d84-a817-26b66d2ab212">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-944af487-a0ee-4d84-a817-26b66d2ab212">
											<gml:posList>35.668881406035915 139.73815143493397 33.066 35.66892171687155 139.73809623411302 33.066 35.668942801735135 139.73806425281418 33.066 35.668931814410286 139.73805338550017 33.066 35.668967006830655 139.73799999118947 33.066 35.66898767347588 139.7380204349803 33.066 35.668955100911894 139.73806987169283 33.066 35.668960107452456 139.73807482542713 33.066 35.668943298986015 139.73810032865939 33.066 35.66894220746924 139.73809924744182 33.066 35.668935320234105 139.73810970519486 33.066 35.66890042165145 139.7381699918261 33.066 35.6689945815995 139.73802498879473 33.066 35.66896497566433 139.73799610538984 33.066 35.66892727211383 139.73805417516795 33.066 35.66893788948265 139.73806454584835 33.066 35.668881406035915 139.73815143493397 33.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89f9a4c4-d332-4d2b-a3db-1605df72d7f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89f9a4c4-d332-4d2b-a3db-1605df72d7f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89f9a4c4-d332-4d2b-a3db-1605df72d7f3">
											<gml:posList>35.668942801735135 139.73806425281418 36.338 35.668945018892806 139.7380639740283 36.338 35.668934022554225 139.73805310672472 36.338 35.668931814410286 139.73805338550017 36.338 35.668942801735135 139.73806425281418 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e33c5dd-55f9-48be-8365-7ad5c58007e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e33c5dd-55f9-48be-8365-7ad5c58007e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e33c5dd-55f9-48be-8365-7ad5c58007e9">
											<gml:posList>35.66894220746924 139.73809924744182 36.338 35.66894197998576 139.73809654142707 36.338 35.66893509275959 139.73810701022634 36.338 35.668935320234105 139.73810970519486 36.338 35.66894220746924 139.73809924744182 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67731a64-df35-4c27-b827-df04c6e1c613">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67731a64-df35-4c27-b827-df04c6e1c613">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67731a64-df35-4c27-b827-df04c6e1c613">
											<gml:posList>35.66894220746924 139.73809924744182 36.338 35.668943298986015 139.73810032865939 36.338 35.66894307151129 139.73809763369061 36.338 35.66894197998576 139.73809654142707 36.338 35.66894220746924 139.73809924744182 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-402b6e3f-b536-419e-9446-cc03e0906213">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-402b6e3f-b536-419e-9446-cc03e0906213">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-402b6e3f-b536-419e-9446-cc03e0906213">
											<gml:posList>35.66892573994677 139.73805438686375 33.231 35.66892727211383 139.73805417516795 33.231 35.66896497566433 139.73799610538984 33.231 35.66896480292556 139.7379942388104 33.231 35.66892573994677 139.73805438686375 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-631354e5-56f7-4f80-8bc4-f00cc2cac8ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-631354e5-56f7-4f80-8bc4-f00cc2cac8ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-631354e5-56f7-4f80-8bc4-f00cc2cac8ee">
											<gml:posList>35.66899611376648 139.73802477709822 33.231 35.6689945815995 139.73802498879473 33.231 35.66890042165145 139.7381699918261 33.231 35.6689005853825 139.73817186946118 33.231 35.66899611376648 139.73802477709822 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e8645ed-9e51-4472-948a-6f743061508e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e8645ed-9e51-4472-948a-6f743061508e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e8645ed-9e51-4472-948a-6f743061508e">
											<gml:posList>35.668931814410286 139.73805338550017 36.338 35.668934022554225 139.73805310672472 36.338 35.66896724333004 139.7380026971941 36.338 35.668967006830655 139.73799999118947 36.338 35.668931814410286 139.73805338550017 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03636acd-96b2-4c70-a1e2-519dad28a2be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03636acd-96b2-4c70-a1e2-519dad28a2be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03636acd-96b2-4c70-a1e2-519dad28a2be">
											<gml:posList>35.668960107452456 139.73807482542713 36.338 35.66895790833094 139.7380751152374 36.338 35.66894307151129 139.73809763369061 36.338 35.668943298986015 139.73810032865939 36.338 35.668960107452456 139.73807482542713 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21385449-57c0-49d4-94b0-4614b598d0a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21385449-57c0-49d4-94b0-4614b598d0a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21385449-57c0-49d4-94b0-4614b598d0a7">
											<gml:posList>35.668945018892806 139.7380639740283 35.94 35.668923925006844 139.73809594429275 35.94 35.66893509275959 139.73810701022634 35.94 35.66894197998576 139.73809654142707 35.94 35.66894307151129 139.73809763369061 35.94 35.66895790833094 139.7380751152374 35.94 35.66895289277667 139.73807016151392 35.94 35.66898547436326 139.73802073583823 35.94 35.66896724333004 139.7380026971941 35.94 35.668934022554225 139.73805310672472 35.94 35.668945018892806 139.7380639740283 35.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74a435a4-4603-475c-bfad-215c972fb91c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74a435a4-4603-475c-bfad-215c972fb91c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74a435a4-4603-475c-bfad-215c972fb91c">
											<gml:posList>35.668955100911894 139.73806987169283 36.338 35.66895289277667 139.73807016151392 36.338 35.66895790833094 139.7380751152374 36.338 35.668960107452456 139.73807482542713 36.338 35.668955100911894 139.73806987169283 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1212a72-86c4-4f1b-afa2-7f889ed716a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1212a72-86c4-4f1b-afa2-7f889ed716a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1212a72-86c4-4f1b-afa2-7f889ed716a6">
											<gml:posList>35.668955100911894 139.73806987169283 36.338 35.66898767347588 139.7380204349803 36.338 35.66898547436326 139.73802073583823 36.338 35.66895289277667 139.73807016151392 36.338 35.668955100911894 139.73806987169283 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02fdfebd-27cd-4b8b-9904-18512f1463ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02fdfebd-27cd-4b8b-9904-18512f1463ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02fdfebd-27cd-4b8b-9904-18512f1463ce">
											<gml:posList>35.668967006830655 139.73799999118947 36.338 35.66896724333004 139.7380026971941 36.338 35.66898547436326 139.73802073583823 36.338 35.66898767347588 139.7380204349803 36.338 35.668967006830655 139.73799999118947 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db88f5ed-77ae-4e61-858e-59db149d2817">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db88f5ed-77ae-4e61-858e-59db149d2817">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db88f5ed-77ae-4e61-858e-59db149d2817">
											<gml:posList>35.66896480292556 139.7379942388104 33.231 35.66896497566433 139.73799610538984 33.231 35.6689945815995 139.73802498879473 33.231 35.66899611376648 139.73802477709822 33.231 35.66896480292556 139.7379942388104 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-018e290e-4a8b-42d2-b41b-9d93baa44777">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-018e290e-4a8b-42d2-b41b-9d93baa44777">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-018e290e-4a8b-42d2-b41b-9d93baa44777">
											<gml:posList>35.66896480292556 139.7379942388104 33.231 35.66899611376648 139.73802477709822 33.231 35.66901474047905 139.73799610144906 28.239 35.66896223966416 139.73794446829453 28.239 35.66896480292556 139.7379942388104 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b807e130-1a32-4598-a624-6bfb6daae019">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b807e130-1a32-4598-a624-6bfb6daae019">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b807e130-1a32-4598-a624-6bfb6daae019">
											<gml:posList>35.66892727211383 139.73805417516795 33.231 35.66892727211383 139.73805417516795 33.066 35.66896497566433 139.73799610538984 33.066 35.66896497566433 139.73799610538984 33.231 35.66892727211383 139.73805417516795 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-316be1dc-5170-42ea-8d2f-ebb771221241">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-316be1dc-5170-42ea-8d2f-ebb771221241">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-316be1dc-5170-42ea-8d2f-ebb771221241">
											<gml:posList>35.66898547436326 139.73802073583823 36.338 35.66898547436326 139.73802073583823 35.94 35.66895289277667 139.73807016151392 35.94 35.66895289277667 139.73807016151392 36.338 35.66898547436326 139.73802073583823 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8494363e-21ce-423c-b7b7-0591fb315f81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8494363e-21ce-423c-b7b7-0591fb315f81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8494363e-21ce-423c-b7b7-0591fb315f81">
											<gml:posList>35.668923925006844 139.73809594429275 36.338 35.668923925006844 139.73809594429275 35.94 35.668945018892806 139.7380639740283 35.94 35.668945018892806 139.7380639740283 36.338 35.668923925006844 139.73809594429275 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2455f10f-541b-4deb-897d-5520a3ce8c26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2455f10f-541b-4deb-897d-5520a3ce8c26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2455f10f-541b-4deb-897d-5520a3ce8c26">
											<gml:posList>35.66894197998576 139.73809654142707 36.338 35.66894197998576 139.73809654142707 35.94 35.66893509275959 139.73810701022634 35.94 35.66893509275959 139.73810701022634 36.338 35.66894197998576 139.73809654142707 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66b6b49b-4e7e-421d-acde-e129228d3a64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66b6b49b-4e7e-421d-acde-e129228d3a64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66b6b49b-4e7e-421d-acde-e129228d3a64">
											<gml:posList>35.668881406035915 139.73815143493397 33.231 35.668881406035915 139.73815143493397 33.066 35.66893788948265 139.73806454584835 33.066 35.66893788948265 139.73806454584835 33.231 35.668881406035915 139.73815143493397 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db886fc5-effd-49cc-a097-3daa1fd9c150">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db886fc5-effd-49cc-a097-3daa1fd9c150">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db886fc5-effd-49cc-a097-3daa1fd9c150">
											<gml:posList>35.66901474047905 139.73799610144906 20.493 35.66896223966416 139.73794446829453 20.493 35.66896223966416 139.73794446829453 28.239 35.66901474047905 139.73799610144906 28.239 35.66901474047905 139.73799610144906 20.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8061376e-6848-4506-8be0-888309c8fba1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8061376e-6848-4506-8be0-888309c8fba1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8061376e-6848-4506-8be0-888309c8fba1">
											<gml:posList>35.668967006830655 139.73799999118947 36.338 35.66898767347588 139.7380204349803 36.338 35.66898767347588 139.7380204349803 33.066 35.668967006830655 139.73799999118947 33.066 35.668967006830655 139.73799999118947 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-866a4dbf-0e8e-4165-a883-2f570ff64e5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-866a4dbf-0e8e-4165-a883-2f570ff64e5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-866a4dbf-0e8e-4165-a883-2f570ff64e5a">
											<gml:posList>35.66896497566433 139.73799610538984 33.231 35.66896497566433 139.73799610538984 33.066 35.6689945815995 139.73802498879473 33.066 35.6689945815995 139.73802498879473 33.231 35.66896497566433 139.73799610538984 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-513d3df2-e571-4a2c-9f1b-5f3883a1a0fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-513d3df2-e571-4a2c-9f1b-5f3883a1a0fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-513d3df2-e571-4a2c-9f1b-5f3883a1a0fa">
											<gml:posList>35.66896724333004 139.7380026971941 36.338 35.66896724333004 139.7380026971941 35.94 35.66898547436326 139.73802073583823 35.94 35.66898547436326 139.73802073583823 36.338 35.66896724333004 139.7380026971941 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-487a8150-97c2-455c-bfd4-831dd353f65b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-487a8150-97c2-455c-bfd4-831dd353f65b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-487a8150-97c2-455c-bfd4-831dd353f65b">
											<gml:posList>35.668931814410286 139.73805338550017 36.338 35.668967006830655 139.73799999118947 36.338 35.668967006830655 139.73799999118947 33.066 35.668931814410286 139.73805338550017 33.066 35.668931814410286 139.73805338550017 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bde67716-2bd0-4e79-9fa5-2e375103bceb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bde67716-2bd0-4e79-9fa5-2e375103bceb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bde67716-2bd0-4e79-9fa5-2e375103bceb">
											<gml:posList>35.668934022554225 139.73805310672472 36.338 35.668934022554225 139.73805310672472 35.94 35.66896724333004 139.7380026971941 35.94 35.66896724333004 139.7380026971941 36.338 35.668934022554225 139.73805310672472 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-056c833a-f7ad-457c-b0a6-cdd49b161d1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-056c833a-f7ad-457c-b0a6-cdd49b161d1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-056c833a-f7ad-457c-b0a6-cdd49b161d1b">
											<gml:posList>35.66896223966416 139.73794446829453 20.493 35.66884826535312 139.73812078835257 20.493 35.66884826535312 139.73812078835257 28.239 35.6689044963151 139.73803380016693 28.239 35.66896223966416 139.73794446829453 28.239 35.66896223966416 139.73794446829453 20.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed69da8f-8a88-409c-82d8-0aa8b16c5531">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed69da8f-8a88-409c-82d8-0aa8b16c5531">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed69da8f-8a88-409c-82d8-0aa8b16c5531">
											<gml:posList>35.66898767347588 139.7380204349803 36.338 35.668955100911894 139.73806987169283 36.338 35.668955100911894 139.73806987169283 33.066 35.66898767347588 139.7380204349803 33.066 35.66898767347588 139.7380204349803 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2ef262b-7932-49ea-a081-981590445d1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2ef262b-7932-49ea-a081-981590445d1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2ef262b-7932-49ea-a081-981590445d1c">
											<gml:posList>35.66892573994677 139.73805438686375 33.231 35.6689044963151 139.73803380016693 28.239 35.6689363663293 139.73806475753324 33.231 35.66892573994677 139.73805438686375 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f5dcb10-046b-49a1-bf63-5dc9a75ad251">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f5dcb10-046b-49a1-bf63-5dc9a75ad251">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f5dcb10-046b-49a1-bf63-5dc9a75ad251">
											<gml:posList>35.668945018892806 139.7380639740283 36.338 35.668945018892806 139.7380639740283 35.94 35.668934022554225 139.73805310672472 35.94 35.668934022554225 139.73805310672472 36.338 35.668945018892806 139.7380639740283 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4241cce-7b6e-4aa9-8790-e347181d511c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4241cce-7b6e-4aa9-8790-e347181d511c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4241cce-7b6e-4aa9-8790-e347181d511c">
											<gml:posList>35.668942801735135 139.73806425281418 36.338 35.668931814410286 139.73805338550017 36.338 35.668931814410286 139.73805338550017 33.066 35.668942801735135 139.73806425281418 33.066 35.668942801735135 139.73806425281418 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-645d9dcd-152a-4412-811b-241f71ed04f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-645d9dcd-152a-4412-811b-241f71ed04f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-645d9dcd-152a-4412-811b-241f71ed04f5">
											<gml:posList>35.66893788948265 139.73806454584835 33.231 35.66893788948265 139.73806454584835 33.066 35.66892727211383 139.73805417516795 33.066 35.66892727211383 139.73805417516795 33.231 35.66893788948265 139.73806454584835 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa014719-269c-4a9f-b5c1-170fde7d6ebb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa014719-269c-4a9f-b5c1-170fde7d6ebb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa014719-269c-4a9f-b5c1-170fde7d6ebb">
											<gml:posList>35.668955100911894 139.73806987169283 36.338 35.668960107452456 139.73807482542713 36.338 35.668960107452456 139.73807482542713 33.066 35.668955100911894 139.73806987169283 33.066 35.668955100911894 139.73806987169283 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd310e3c-9101-4df7-8bd3-fb9b450458b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd310e3c-9101-4df7-8bd3-fb9b450458b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd310e3c-9101-4df7-8bd3-fb9b450458b0">
											<gml:posList>35.66895289277667 139.73807016151392 36.338 35.66895289277667 139.73807016151392 35.94 35.66895790833094 139.7380751152374 35.94 35.66895790833094 139.7380751152374 36.338 35.66895289277667 139.73807016151392 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11637941-e70d-4125-a1ff-2cfa5a8ded65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11637941-e70d-4125-a1ff-2cfa5a8ded65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11637941-e70d-4125-a1ff-2cfa5a8ded65">
											<gml:posList>35.66892171687155 139.73809623411302 36.338 35.668942801735135 139.73806425281418 36.338 35.668942801735135 139.73806425281418 33.066 35.66892171687155 139.73809623411302 33.066 35.66892171687155 139.73809623411302 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6278ce0f-eded-4894-afc6-ea0549f26b18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6278ce0f-eded-4894-afc6-ea0549f26b18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6278ce0f-eded-4894-afc6-ea0549f26b18">
											<gml:posList>35.66901474047905 139.73799610144906 28.239 35.66899611376648 139.73802477709822 33.231 35.6689005853825 139.73817186946118 33.231 35.6689005853825 139.73817186946118 20.493 35.66901474047905 139.73799610144906 20.493 35.66901474047905 139.73799610144906 28.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2985c900-dafc-45d4-861e-c9c4f1f81245">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2985c900-dafc-45d4-861e-c9c4f1f81245">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2985c900-dafc-45d4-861e-c9c4f1f81245">
											<gml:posList>35.66895790833094 139.7380751152374 36.338 35.66895790833094 139.7380751152374 35.94 35.66894307151129 139.73809763369061 35.94 35.66894307151129 139.73809763369061 36.338 35.66895790833094 139.7380751152374 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9adae5f-e8d2-48aa-8095-a6b770bbb2cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9adae5f-e8d2-48aa-8095-a6b770bbb2cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9adae5f-e8d2-48aa-8095-a6b770bbb2cc">
											<gml:posList>35.668960107452456 139.73807482542713 36.338 35.668943298986015 139.73810032865939 36.338 35.668943298986015 139.73810032865939 33.066 35.668960107452456 139.73807482542713 33.066 35.668960107452456 139.73807482542713 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-911b3172-e391-4c72-aced-5bc1c157e847">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-911b3172-e391-4c72-aced-5bc1c157e847">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-911b3172-e391-4c72-aced-5bc1c157e847">
											<gml:posList>35.66894307151129 139.73809763369061 36.338 35.66894307151129 139.73809763369061 35.94 35.66894197998576 139.73809654142707 35.94 35.66894197998576 139.73809654142707 36.338 35.66894307151129 139.73809763369061 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfefbdcc-561b-4bc5-8f0a-41c4ffaedd8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfefbdcc-561b-4bc5-8f0a-41c4ffaedd8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfefbdcc-561b-4bc5-8f0a-41c4ffaedd8c">
											<gml:posList>35.6689945815995 139.73802498879473 33.231 35.6689945815995 139.73802498879473 33.066 35.66890042165145 139.7381699918261 33.066 35.66890042165145 139.7381699918261 33.231 35.6689945815995 139.73802498879473 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84a53889-ff1b-4fdb-b9f5-5710f3ef315b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84a53889-ff1b-4fdb-b9f5-5710f3ef315b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84a53889-ff1b-4fdb-b9f5-5710f3ef315b">
											<gml:posList>35.668943298986015 139.73810032865939 36.338 35.66894220746924 139.73809924744182 36.338 35.66894220746924 139.73809924744182 33.066 35.668943298986015 139.73810032865939 33.066 35.668943298986015 139.73810032865939 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-797b1a5a-c538-48d8-8f0b-5447e23d781a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-797b1a5a-c538-48d8-8f0b-5447e23d781a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-797b1a5a-c538-48d8-8f0b-5447e23d781a">
											<gml:posList>35.66893509275959 139.73810701022634 36.338 35.66893509275959 139.73810701022634 35.94 35.668923925006844 139.73809594429275 35.94 35.668923925006844 139.73809594429275 36.338 35.66893509275959 139.73810701022634 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-359d9673-fb1b-4317-a11b-593c6f7e209a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-359d9673-fb1b-4317-a11b-593c6f7e209a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-359d9673-fb1b-4317-a11b-593c6f7e209a">
											<gml:posList>35.668935320234105 139.73810970519486 36.338 35.66892171687155 139.73809623411302 36.338 35.66892171687155 139.73809623411302 33.066 35.668935320234105 139.73810970519486 33.066 35.668935320234105 139.73810970519486 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51a64159-3a57-4dac-a002-f00574a66c69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51a64159-3a57-4dac-a002-f00574a66c69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51a64159-3a57-4dac-a002-f00574a66c69">
											<gml:posList>35.66894220746924 139.73809924744182 36.338 35.668935320234105 139.73810970519486 36.338 35.668935320234105 139.73810970519486 33.066 35.66894220746924 139.73809924744182 33.066 35.66894220746924 139.73809924744182 36.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec490a76-bfb4-4fc0-b704-32cf6d9bfb5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec490a76-bfb4-4fc0-b704-32cf6d9bfb5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec490a76-bfb4-4fc0-b704-32cf6d9bfb5e">
											<gml:posList>35.6689005853825 139.73817186946118 33.231 35.66887988289112 139.73815165766308 33.231 35.66884826535312 139.73812078835257 28.239 35.66884826535312 139.73812078835257 20.493 35.6689005853825 139.73817186946118 20.493 35.6689005853825 139.73817186946118 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b4fc1e8-23b7-44f4-8fe2-97781d6f006f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b4fc1e8-23b7-44f4-8fe2-97781d6f006f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b4fc1e8-23b7-44f4-8fe2-97781d6f006f">
											<gml:posList>35.66890042165145 139.7381699918261 33.231 35.66890042165145 139.7381699918261 33.066 35.668881406035915 139.73815143493397 33.066 35.668881406035915 139.73815143493397 33.231 35.66890042165145 139.7381699918261 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2060</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">151.5031</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>