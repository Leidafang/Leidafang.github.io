<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f595317f-b804-4b08-912e-b00db332ca63">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66924826620782 139.74304541744542 0 35.669255577440396 139.74304687834456 0 35.66926178009375 139.7430004114399 0 35.669264087963654 139.7430008838224 0 35.66926955565225 139.7429599849755 0 35.66922688723325 139.74295142815532 0 35.66921488525306 139.74304127960863 0 35.66924793456354 139.7430479031922 0 35.66924826620782 139.74304541744542 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924826620782 139.74304541744542 10.088 35.66924793456354 139.7430479031922 10.088 35.66921488525306 139.74304127960863 10.088 35.66922688723325 139.74295142815532 10.088 35.66926955565225 139.7429599849755 10.088 35.669264087963654 139.7430008838224 10.088 35.66926178009375 139.7430004114399 10.088 35.669255577440396 139.74304687834456 10.088 35.66924826620782 139.74304541744542 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924826620782 139.74304541744542 10.088 35.669255577440396 139.74304687834456 10.088 35.669255577440396 139.74304687834456 14.09 35.66924826620782 139.74304541744542 14.09 35.66924826620782 139.74304541744542 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669255577440396 139.74304687834456 10.088 35.66926178009375 139.7430004114399 10.088 35.66926178009375 139.7430004114399 14.09 35.669255577440396 139.74304687834456 14.09 35.669255577440396 139.74304687834456 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66926178009375 139.7430004114399 10.088 35.669264087963654 139.7430008838224 10.088 35.669264087963654 139.7430008838224 14.09 35.66926178009375 139.7430004114399 14.09 35.66926178009375 139.7430004114399 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669264087963654 139.7430008838224 10.088 35.66926955565225 139.7429599849755 10.088 35.66926955565225 139.7429599849755 14.09 35.669264087963654 139.7430008838224 14.09 35.669264087963654 139.7430008838224 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66926955565225 139.7429599849755 10.088 35.66922688723325 139.74295142815532 10.088 35.66922688723325 139.74295142815532 14.09 35.66926955565225 139.7429599849755 14.09 35.66926955565225 139.7429599849755 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922688723325 139.74295142815532 10.088 35.66921488525306 139.74304127960863 10.088 35.66921488525306 139.74304127960863 14.09 35.66922688723325 139.74295142815532 14.09 35.66922688723325 139.74295142815532 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66921488525306 139.74304127960863 10.088 35.66924793456354 139.7430479031922 10.088 35.66924793456354 139.7430479031922 14.09 35.66921488525306 139.74304127960863 14.09 35.66921488525306 139.74304127960863 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924793456354 139.7430479031922 10.088 35.66924826620782 139.74304541744542 10.088 35.66924826620782 139.74304541744542 14.09 35.66924793456354 139.7430479031922 14.09 35.66924793456354 139.7430479031922 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924826620782 139.74304541744542 14.09 35.669255577440396 139.74304687834456 14.09 35.66926178009375 139.7430004114399 14.09 35.669264087963654 139.7430008838224 14.09 35.66926955565225 139.7429599849755 14.09 35.66922688723325 139.74295142815532 14.09 35.66921488525306 139.74304127960863 14.09 35.66924793456354 139.7430479031922 14.09 35.66924826620782 139.74304541744542 14.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1ff14901-ac2b-49e1-9a71-7121d4ffe616"/>
							<gml:surfaceMember xlink:href="#poly-e32b3dde-b26a-46b7-a955-4e5f53f0e533"/>
							<gml:surfaceMember xlink:href="#poly-2ce93744-2f9f-4db1-8aad-519049ae4534"/>
							<gml:surfaceMember xlink:href="#poly-6d4240c8-b52b-440d-80c5-d501c3fba006"/>
							<gml:surfaceMember xlink:href="#poly-c0df0950-eb33-4c62-8677-45b82dda33ce"/>
							<gml:surfaceMember xlink:href="#poly-63880cb3-a6f5-4e19-8c5b-d83f1d98b99c"/>
							<gml:surfaceMember xlink:href="#poly-086ded8c-3aac-4227-88de-59771aa8d97c"/>
							<gml:surfaceMember xlink:href="#poly-e8cf477a-6146-48f7-94c6-eddf584e7778"/>
							<gml:surfaceMember xlink:href="#poly-2a9fadd5-6d7a-4a5b-acca-340956b81c86"/>
							<gml:surfaceMember xlink:href="#poly-062e8476-caf8-4c66-9b08-461c5acb597d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1ff14901-ac2b-49e1-9a71-7121d4ffe616">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ff14901-ac2b-49e1-9a71-7121d4ffe616">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ff14901-ac2b-49e1-9a71-7121d4ffe616">
											<gml:posList>35.66926178009373 139.7430004114399 10.088 35.66925557744039 139.74304687834456 10.088 35.66924826620782 139.74304541744544 10.088 35.66924793456353 139.7430479031922 10.088 35.669214885253055 139.74304127960863 10.088 35.66922688723324 139.7429514281553 10.088 35.66926955565221 139.7429599849755 10.088 35.669264087963654 139.74300088382236 10.088 35.66926178009373 139.7430004114399 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e32b3dde-b26a-46b7-a955-4e5f53f0e533">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e32b3dde-b26a-46b7-a955-4e5f53f0e533">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e32b3dde-b26a-46b7-a955-4e5f53f0e533">
											<gml:posList>35.66924826620782 139.74304541744544 13.973 35.66925557744039 139.74304687834456 13.973 35.66926178009373 139.7430004114399 13.973 35.669264087963654 139.74300088382236 13.973 35.66926955565221 139.7429599849755 13.973 35.66922688723324 139.7429514281553 13.973 35.669214885253055 139.74304127960863 13.973 35.66924793456353 139.7430479031922 13.973 35.66924826620782 139.74304541744544 13.973</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ce93744-2f9f-4db1-8aad-519049ae4534">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ce93744-2f9f-4db1-8aad-519049ae4534">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ce93744-2f9f-4db1-8aad-519049ae4534">
											<gml:posList>35.66926955565221 139.7429599849755 10.088 35.66922688723324 139.7429514281553 10.088 35.66922688723324 139.7429514281553 13.973 35.66926955565221 139.7429599849755 13.973 35.66926955565221 139.7429599849755 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d4240c8-b52b-440d-80c5-d501c3fba006">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d4240c8-b52b-440d-80c5-d501c3fba006">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d4240c8-b52b-440d-80c5-d501c3fba006">
											<gml:posList>35.669264087963654 139.74300088382236 10.088 35.66926955565221 139.7429599849755 10.088 35.66926955565221 139.7429599849755 13.973 35.669264087963654 139.74300088382236 13.973 35.669264087963654 139.74300088382236 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0df0950-eb33-4c62-8677-45b82dda33ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0df0950-eb33-4c62-8677-45b82dda33ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0df0950-eb33-4c62-8677-45b82dda33ce">
											<gml:posList>35.66922688723324 139.7429514281553 10.088 35.669214885253055 139.74304127960863 10.088 35.669214885253055 139.74304127960863 13.973 35.66922688723324 139.7429514281553 13.973 35.66922688723324 139.7429514281553 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63880cb3-a6f5-4e19-8c5b-d83f1d98b99c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63880cb3-a6f5-4e19-8c5b-d83f1d98b99c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63880cb3-a6f5-4e19-8c5b-d83f1d98b99c">
											<gml:posList>35.66926178009373 139.7430004114399 10.088 35.669264087963654 139.74300088382236 10.088 35.669264087963654 139.74300088382236 13.973 35.66926178009373 139.7430004114399 13.973 35.66926178009373 139.7430004114399 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-086ded8c-3aac-4227-88de-59771aa8d97c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-086ded8c-3aac-4227-88de-59771aa8d97c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-086ded8c-3aac-4227-88de-59771aa8d97c">
											<gml:posList>35.66925557744039 139.74304687834456 10.088 35.66926178009373 139.7430004114399 10.088 35.66926178009373 139.7430004114399 13.973 35.66925557744039 139.74304687834456 13.973 35.66925557744039 139.74304687834456 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8cf477a-6146-48f7-94c6-eddf584e7778">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8cf477a-6146-48f7-94c6-eddf584e7778">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8cf477a-6146-48f7-94c6-eddf584e7778">
											<gml:posList>35.669214885253055 139.74304127960863 10.088 35.66924793456353 139.7430479031922 10.088 35.66924793456353 139.7430479031922 13.973 35.669214885253055 139.74304127960863 13.973 35.669214885253055 139.74304127960863 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a9fadd5-6d7a-4a5b-acca-340956b81c86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a9fadd5-6d7a-4a5b-acca-340956b81c86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a9fadd5-6d7a-4a5b-acca-340956b81c86">
											<gml:posList>35.66924826620782 139.74304541744544 10.088 35.66925557744039 139.74304687834456 10.088 35.66925557744039 139.74304687834456 13.973 35.66924826620782 139.74304541744544 13.973 35.66924826620782 139.74304541744544 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-062e8476-caf8-4c66-9b08-461c5acb597d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-062e8476-caf8-4c66-9b08-461c5acb597d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-062e8476-caf8-4c66-9b08-461c5acb597d">
											<gml:posList>35.66924793456353 139.7430479031922 10.088 35.66924826620782 139.74304541744544 10.088 35.66924826620782 139.74304541744544 13.973 35.66924793456353 139.7430479031922 13.973 35.66924793456353 139.7430479031922 10.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3369</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>