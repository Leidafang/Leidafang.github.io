<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f6e5a607-d367-4a37-b2fb-94693601d6b6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">22.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671995585974464 139.73811616704367 0 35.67197556413488 139.7380448305682 0 35.67194288223869 139.7380586001797 0 35.67193614632596 139.7380324611815 0 35.67181618665308 139.7380831302706 0 35.671843484944176 139.73818030669395 0 35.671995585974464 139.73811616704367 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671995585974464 139.73811616704367 10.049 35.671843484944176 139.73818030669395 10.049 35.67181618665308 139.7380831302706 10.049 35.67193614632596 139.7380324611815 10.049 35.67194288223869 139.7380586001797 10.049 35.67197556413488 139.7380448305682 10.049 35.671995585974464 139.73811616704367 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671995585974464 139.73811616704367 10.049 35.67197556413488 139.7380448305682 10.049 35.67197556413488 139.7380448305682 32.75 35.671995585974464 139.73811616704367 32.75 35.671995585974464 139.73811616704367 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67197556413488 139.7380448305682 10.049 35.67194288223869 139.7380586001797 10.049 35.67194288223869 139.7380586001797 32.75 35.67197556413488 139.7380448305682 32.75 35.67197556413488 139.7380448305682 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67194288223869 139.7380586001797 10.049 35.67193614632596 139.7380324611815 10.049 35.67193614632596 139.7380324611815 32.75 35.67194288223869 139.7380586001797 32.75 35.67194288223869 139.7380586001797 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67193614632596 139.7380324611815 10.049 35.67181618665308 139.7380831302706 10.049 35.67181618665308 139.7380831302706 32.75 35.67193614632596 139.7380324611815 32.75 35.67193614632596 139.7380324611815 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181618665308 139.7380831302706 10.049 35.671843484944176 139.73818030669395 10.049 35.671843484944176 139.73818030669395 32.75 35.67181618665308 139.7380831302706 32.75 35.67181618665308 139.7380831302706 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671843484944176 139.73818030669395 10.049 35.671995585974464 139.73811616704367 10.049 35.671995585974464 139.73811616704367 32.75 35.671843484944176 139.73818030669395 32.75 35.671843484944176 139.73818030669395 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671995585974464 139.73811616704367 32.75 35.67197556413488 139.7380448305682 32.75 35.67194288223869 139.7380586001797 32.75 35.67193614632596 139.7380324611815 32.75 35.67181618665308 139.7380831302706 32.75 35.671843484944176 139.73818030669395 32.75 35.671995585974464 139.73811616704367 32.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a8177786-1b9e-44e9-a284-92604ce2902a"/>
							<gml:surfaceMember xlink:href="#poly-398c0275-cbe8-49ae-8819-f19827fa5a23"/>
							<gml:surfaceMember xlink:href="#poly-4f594b32-d63a-4fe6-9d6b-a01da8dbae15"/>
							<gml:surfaceMember xlink:href="#poly-1b146d00-5105-4a37-ae56-84fbf5ab075e"/>
							<gml:surfaceMember xlink:href="#poly-2c3182bc-8cff-44d9-8e2f-72548d6fc8ec"/>
							<gml:surfaceMember xlink:href="#poly-f93424e4-76d4-444a-959c-0c5ffc3c166c"/>
							<gml:surfaceMember xlink:href="#poly-11aed4f2-983a-40e8-bed1-0ef5693b2a73"/>
							<gml:surfaceMember xlink:href="#poly-31bf8ddb-1080-4bdb-b1e4-c957cbb76cb3"/>
							<gml:surfaceMember xlink:href="#poly-87b008a8-892b-4f89-9d07-a093ca778867"/>
							<gml:surfaceMember xlink:href="#poly-1a555815-a055-46e8-bef9-1d93573a40d8"/>
							<gml:surfaceMember xlink:href="#poly-cc6284a5-d0aa-459b-8f39-b9d89cf4c48f"/>
							<gml:surfaceMember xlink:href="#poly-208593c4-df2d-4138-b5d7-e741c7b1344f"/>
							<gml:surfaceMember xlink:href="#poly-2bbdb8f5-63e8-4626-8ae1-ff051a8de5c0"/>
							<gml:surfaceMember xlink:href="#poly-993b1f4a-77c4-46c6-afff-c804868bb867"/>
							<gml:surfaceMember xlink:href="#poly-1f21d3f0-353a-4548-ae50-9de2e722aefc"/>
							<gml:surfaceMember xlink:href="#poly-a2bec6ae-219c-471a-b6c9-a234e9e53fa7"/>
							<gml:surfaceMember xlink:href="#poly-e971c2f3-1e7e-4776-af44-5d89c8bdc6bb"/>
							<gml:surfaceMember xlink:href="#poly-d7878d61-9a6c-4003-a0e6-e32e298d42cb"/>
							<gml:surfaceMember xlink:href="#poly-3ff1658a-2b98-4a4c-9e4c-4306b08350c5"/>
							<gml:surfaceMember xlink:href="#poly-4d592706-de26-460e-adcb-bcb869491940"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f6e5a607-d367-4a37-b2fb-94693601d6b6_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0f34c2b-94b0-4ddb-a793-2426c2fad6ad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67197279810357 139.73808050293525 32.824 35.67197968657515 139.7381058022358 32.824 35.67196143968068 139.7381132692346 32.824 35.671954542196936 139.73808796994985 32.824 35.67197279810357 139.73808050293525 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bff050cc-67bc-4611-b6b3-880a1ff27099">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bff050cc-67bc-4611-b6b3-880a1ff27099_0">
											<gml:posList>35.671954542196936 139.73808796994985 32.824 35.671954542196936 139.73808796994985 35.162 35.67197279810357 139.73808050293525 35.162 35.67197279810357 139.73808050293525 32.824 35.671954542196936 139.73808796994985 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e94f771-6d9e-4aba-9515-6456db0ab5b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e94f771-6d9e-4aba-9515-6456db0ab5b2_0">
											<gml:posList>35.67197279810357 139.73808050293525 32.824 35.67197279810357 139.73808050293525 35.162 35.67197968657515 139.7381058022358 35.162 35.67197968657515 139.7381058022358 32.824 35.67197279810357 139.73808050293525 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b825cea4-6f69-4875-ad29-b8b7c4142c73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b825cea4-6f69-4875-ad29-b8b7c4142c73_0">
											<gml:posList>35.67196143968068 139.7381132692346 35.162 35.67197968657515 139.7381058022358 35.162 35.67197279810357 139.73808050293525 35.162 35.671954542196936 139.73808796994985 35.162 35.67196143968068 139.7381132692346 35.162</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5db9aa1-d7f3-442f-86c9-5b74ac175444">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5db9aa1-d7f3-442f-86c9-5b74ac175444_0">
											<gml:posList>35.67196143968068 139.7381132692346 32.824 35.67196143968068 139.7381132692346 35.162 35.671954542196936 139.73808796994985 35.162 35.671954542196936 139.73808796994985 32.824 35.67196143968068 139.7381132692346 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d32c076-a8cd-49d8-a05e-c9f178c0d0e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d32c076-a8cd-49d8-a05e-c9f178c0d0e3_0">
											<gml:posList>35.67197968657515 139.7381058022358 32.824 35.67197968657515 139.7381058022358 35.162 35.67196143968068 139.7381132692346 35.162 35.67196143968068 139.7381132692346 32.824 35.67197968657515 139.7381058022358 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f6e5a607-d367-4a37-b2fb-94693601d6b6_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23e0d195-560b-4c01-9af8-2c7db6ee1d01">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67196828754462 139.7380188799934 10.049 35.67197556412612 139.73804481952172 10.049 35.671942882238696 139.7380586001797 10.049 35.671936146325955 139.73803246118146 10.049 35.67196828754462 139.7380188799934 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c480cfa6-b271-4867-be97-08a1b42ba170">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c480cfa6-b271-4867-be97-08a1b42ba170_0">
											<gml:posList>35.671936146325955 139.73803246118146 33.415 35.671936146325955 139.73803246118146 10.049 35.671942882238696 139.7380586001797 10.049 35.671942882238696 139.7380586001797 33.415 35.671936146325955 139.73803246118146 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4367b10c-f60c-45f0-b9f8-01a9cc23eb24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4367b10c-f60c-45f0-b9f8-01a9cc23eb24_0">
											<gml:posList>35.67196828754462 139.7380188799934 33.415 35.67196828754462 139.7380188799934 10.049 35.671936146325955 139.73803246118146 10.049 35.671936146325955 139.73803246118146 33.415 35.67196828754462 139.7380188799934 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33daac18-56a5-48d5-ba02-4132f0ef93be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33daac18-56a5-48d5-ba02-4132f0ef93be_0">
											<gml:posList>35.671936146325955 139.73803246118146 33.415 35.671942882238696 139.7380586001797 33.415 35.67197556412612 139.73804481952172 33.415 35.67196828754462 139.7380188799934 33.415 35.671936146325955 139.73803246118146 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-beb654d5-4a53-406e-a44c-27191843290a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-beb654d5-4a53-406e-a44c-27191843290a_0">
											<gml:posList>35.671942882238696 139.7380586001797 33.415 35.671942882238696 139.7380586001797 10.049 35.67197556412612 139.73804481952172 10.049 35.67197556412612 139.73804481952172 33.415 35.671942882238696 139.7380586001797 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e23210d1-68fd-4f82-a6e5-57e6c5043d71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e23210d1-68fd-4f82-a6e5-57e6c5043d71_0">
											<gml:posList>35.67197556412612 139.73804481952172 33.415 35.67197556412612 139.73804481952172 10.049 35.67196828754462 139.7380188799934 10.049 35.67196828754462 139.7380188799934 33.415 35.67197556412612 139.73804481952172 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f6e5a607-d367-4a37-b2fb-94693601d6b6_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b37f0c47-a9b2-4658-8831-d01e7def2e24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6719450874808 139.73810023172263 32.824 35.671936698416026 139.73810366609436 32.824 35.67193407685378 139.73809408086944 32.824 35.671942474931996 139.73809064648609 32.824 35.6719450874808 139.73810023172263 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee7626e1-43d3-4e63-b1e6-175ee4ced0b5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67190640862411 139.7381104293726 32.824 35.67190437387151 139.7381020033333 32.824 35.671924162347445 139.73809483276074 32.824 35.67192619710054 139.7381032588019 32.824 35.67190640862411 139.7381104293726 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-340748c4-78e6-41e3-9832-774d8423be2a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671901587664244 139.73811218044057 32.824 35.67189329740932 139.73811518387964 32.824 35.67189126265705 139.7381067578416 32.824 35.67189955291177 139.73810375440175 32.824 35.671901587664244 139.73811218044057 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a90f62b2-7e77-4067-9245-e525908425a0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671926766670325 139.73812821210626 32.824 35.67190686107517 139.7381354601352 32.824 35.67190472689392 139.73812668072625 32.824 35.6719246324798 139.73811942164892 32.824 35.671926766670325 139.73812821210626 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9beabfd-1b8a-4763-8f72-ee565eff5fe9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6718769912408 139.7381375612918 32.824 35.67189780695113 139.73812996974488 32.824 35.671899769312546 139.73813804238316 32.824 35.671878944588016 139.73814563393887 32.824 35.6718769912408 139.7381375612918 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fb24a97-ae57-4795-bf23-058bec468d38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fb24a97-ae57-4795-bf23-058bec468d38_0">
											<gml:posList>35.6718769912408 139.7381375612918 32.824 35.671878944588016 139.73814563393887 32.824 35.671878944588016 139.73814563393887 34.754 35.6718769912408 139.7381375612918 34.754 35.6718769912408 139.7381375612918 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1398c517-9b3a-41a0-99ac-7af5efd62f10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1398c517-9b3a-41a0-99ac-7af5efd62f10_0">
											<gml:posList>35.6718769912408 139.7381375612918 32.824 35.6718769912408 139.7381375612918 34.754 35.67189780695113 139.73812996974488 34.754 35.67189780695113 139.73812996974488 32.824 35.6718769912408 139.7381375612918 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d954eb0a-05d8-48c3-931f-cd674c14eff9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d954eb0a-05d8-48c3-931f-cd674c14eff9_0">
											<gml:posList>35.6718769912408 139.7381375612918 34.754 35.671878944588016 139.73814563393887 34.754 35.671899769312546 139.73813804238316 34.754 35.67189780695113 139.73812996974488 34.754 35.6718769912408 139.7381375612918 34.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35a9a104-e3ea-4f6f-b57d-99b007718878">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35a9a104-e3ea-4f6f-b57d-99b007718878_0">
											<gml:posList>35.671878944588016 139.73814563393887 32.824 35.671899769312546 139.73813804238316 32.824 35.671899769312546 139.73813804238316 34.754 35.671878944588016 139.73814563393887 34.754 35.671878944588016 139.73814563393887 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8c203df-6584-4cc0-952a-a91336a3ff93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8c203df-6584-4cc0-952a-a91336a3ff93_0">
											<gml:posList>35.67189126265705 139.7381067578416 32.824 35.67189329740932 139.73811518387964 32.824 35.67189329740932 139.73811518387964 34.754 35.67189126265705 139.7381067578416 34.754 35.67189126265705 139.7381067578416 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f0cbbc0-3f05-4e5b-91ad-4053754e29ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f0cbbc0-3f05-4e5b-91ad-4053754e29ec_0">
											<gml:posList>35.67189955291177 139.73810375440175 32.824 35.67189126265705 139.7381067578416 32.824 35.67189126265705 139.7381067578416 34.754 35.67189955291177 139.73810375440175 34.754 35.67189955291177 139.73810375440175 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8e8a97e-7810-4674-9aa1-5f13bf1200e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8e8a97e-7810-4674-9aa1-5f13bf1200e6_0">
											<gml:posList>35.67189126265705 139.7381067578416 34.754 35.67189329740932 139.73811518387964 34.754 35.671901587664244 139.73811218044057 34.754 35.67189955291177 139.73810375440175 34.754 35.67189126265705 139.7381067578416 34.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09feb5ae-448e-467a-89cc-db6e0ab5bbe2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09feb5ae-448e-467a-89cc-db6e0ab5bbe2_0">
											<gml:posList>35.67189329740932 139.73811518387964 32.824 35.671901587664244 139.73811218044057 32.824 35.671901587664244 139.73811218044057 34.754 35.67189329740932 139.73811518387964 34.754 35.67189329740932 139.73811518387964 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2a31f8e-2ddf-4126-bb2b-6f8747936eca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2a31f8e-2ddf-4126-bb2b-6f8747936eca_0">
											<gml:posList>35.671899769312546 139.73813804238316 32.824 35.67189780695113 139.73812996974488 32.824 35.67189780695113 139.73812996974488 34.754 35.671899769312546 139.73813804238316 34.754 35.671899769312546 139.73813804238316 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3ae6177-15b4-4a9f-9fa9-5b9335cb34b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3ae6177-15b4-4a9f-9fa9-5b9335cb34b3_0">
											<gml:posList>35.67189955291177 139.73810375440175 32.824 35.67189955291177 139.73810375440175 34.754 35.671901587664244 139.73811218044057 34.754 35.671901587664244 139.73811218044057 32.824 35.67189955291177 139.73810375440175 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9529983-26fd-4543-99d9-4d13f6a212d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9529983-26fd-4543-99d9-4d13f6a212d8_0">
											<gml:posList>35.67190437387151 139.7381020033333 32.824 35.67190640862411 139.7381104293726 32.824 35.67190640862411 139.7381104293726 34.754 35.67190437387151 139.7381020033333 34.754 35.67190437387151 139.7381020033333 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aaf2fe20-64ec-4d98-bc4c-b5aee37692e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aaf2fe20-64ec-4d98-bc4c-b5aee37692e7_0">
											<gml:posList>35.67190472689392 139.73812668072625 32.824 35.67190686107517 139.7381354601352 32.824 35.67190686107517 139.7381354601352 34.754 35.67190472689392 139.73812668072625 34.754 35.67190472689392 139.73812668072625 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2969315c-24fc-492c-b1b0-001170651887">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2969315c-24fc-492c-b1b0-001170651887_0">
											<gml:posList>35.67190437387151 139.7381020033333 32.824 35.67190437387151 139.7381020033333 34.754 35.671924162347445 139.73809483276074 34.754 35.671924162347445 139.73809483276074 32.824 35.67190437387151 139.7381020033333 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f6bdde0-6c4b-4bd5-a650-e266836c411c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f6bdde0-6c4b-4bd5-a650-e266836c411c_0">
											<gml:posList>35.67190472689392 139.73812668072625 32.824 35.67190472689392 139.73812668072625 34.754 35.6719246324798 139.73811942164892 34.754 35.6719246324798 139.73811942164892 32.824 35.67190472689392 139.73812668072625 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bef4d2b-1daa-4619-893e-855f1683bce2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bef4d2b-1daa-4619-893e-855f1683bce2_0">
											<gml:posList>35.671924162347445 139.73809483276074 34.754 35.67190437387151 139.7381020033333 34.754 35.67190640862411 139.7381104293726 34.754 35.67192619710054 139.7381032588019 34.754 35.671924162347445 139.73809483276074 34.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-654393e0-d910-47de-b133-06b5ef7b148a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-654393e0-d910-47de-b133-06b5ef7b148a_0">
											<gml:posList>35.67190472689392 139.73812668072625 34.754 35.67190686107517 139.7381354601352 34.754 35.671926766670325 139.73812821210626 34.754 35.6719246324798 139.73811942164892 34.754 35.67190472689392 139.73812668072625 34.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1907a153-5443-4e3d-bf29-1e32a2c6a43d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1907a153-5443-4e3d-bf29-1e32a2c6a43d_0">
											<gml:posList>35.67190640862411 139.7381104293726 32.824 35.67192619710054 139.7381032588019 32.824 35.67192619710054 139.7381032588019 34.754 35.67190640862411 139.7381104293726 34.754 35.67190640862411 139.7381104293726 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30f5a494-8234-4296-9cd1-644ec82594ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30f5a494-8234-4296-9cd1-644ec82594ab_0">
											<gml:posList>35.67190686107517 139.7381354601352 32.824 35.671926766670325 139.73812821210626 32.824 35.671926766670325 139.73812821210626 34.754 35.67190686107517 139.7381354601352 34.754 35.67190686107517 139.7381354601352 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76afb41a-8b73-4e9c-b731-fa68eb915fcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76afb41a-8b73-4e9c-b731-fa68eb915fcb_0">
											<gml:posList>35.671924162347445 139.73809483276074 34.754 35.67192619710054 139.7381032588019 34.754 35.67192619710054 139.7381032588019 32.824 35.671924162347445 139.73809483276074 32.824 35.671924162347445 139.73809483276074 34.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57eb18ea-1085-4239-a91c-55627d88c4bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57eb18ea-1085-4239-a91c-55627d88c4bb_0">
											<gml:posList>35.6719246324798 139.73811942164892 32.824 35.6719246324798 139.73811942164892 34.754 35.671926766670325 139.73812821210626 34.754 35.671926766670325 139.73812821210626 32.824 35.6719246324798 139.73811942164892 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d081610a-cb8b-411c-bfd9-e0b901d4d112">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d081610a-cb8b-411c-bfd9-e0b901d4d112_0">
											<gml:posList>35.67193407685378 139.73809408086944 32.824 35.671936698416026 139.73810366609436 32.824 35.671936698416026 139.73810366609436 33.697 35.67193407685378 139.73809408086944 33.697 35.67193407685378 139.73809408086944 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bae17d98-a8f8-4724-bf53-4730eb55df9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bae17d98-a8f8-4724-bf53-4730eb55df9a_0">
											<gml:posList>35.671942474931996 139.73809064648609 32.824 35.67193407685378 139.73809408086944 32.824 35.67193407685378 139.73809408086944 33.697 35.671942474931996 139.73809064648609 33.697 35.671942474931996 139.73809064648609 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4161993e-2521-4857-ab23-efe2f4728029">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4161993e-2521-4857-ab23-efe2f4728029_0">
											<gml:posList>35.67193407685378 139.73809408086944 33.697 35.671936698416026 139.73810366609436 33.697 35.6719450874808 139.73810023172263 33.697 35.671942474931996 139.73809064648609 33.697 35.67193407685378 139.73809408086944 33.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fa63c3a-517b-4e27-8fee-453ffa571c41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fa63c3a-517b-4e27-8fee-453ffa571c41_0">
											<gml:posList>35.671936698416026 139.73810366609436 32.824 35.6719450874808 139.73810023172263 32.824 35.6719450874808 139.73810023172263 33.697 35.671936698416026 139.73810366609436 33.697 35.671936698416026 139.73810366609436 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9206a114-890c-44f7-8b3f-8cbbcd2c992f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9206a114-890c-44f7-8b3f-8cbbcd2c992f_0">
											<gml:posList>35.6719450874808 139.73810023172263 32.824 35.671942474931996 139.73809064648609 32.824 35.671942474931996 139.73809064648609 33.697 35.6719450874808 139.73810023172263 33.697 35.6719450874808 139.73810023172263 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a8177786-1b9e-44e9-a284-92604ce2902a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8177786-1b9e-44e9-a284-92604ce2902a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8177786-1b9e-44e9-a284-92604ce2902a">
											<gml:posList>35.671843484944155 139.73818030669392 10.049 35.671816186653075 139.7380831302706 10.049 35.671936146325955 139.73803246118146 10.049 35.671942882238696 139.7380586001797 10.049 35.67197556413486 139.7380448305682 10.049 35.67199558597447 139.73811616704367 10.049 35.671843484944155 139.73818030669392 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-398c0275-cbe8-49ae-8819-f19827fa5a23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-398c0275-cbe8-49ae-8819-f19827fa5a23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-398c0275-cbe8-49ae-8819-f19827fa5a23">
											<gml:posList>35.671843484944155 139.73818030669392 33.415 35.67184565293826 139.73817484716906 33.415 35.67182063252287 139.73808578718499 33.415 35.671816186653075 139.7380831302706 33.415 35.671843484944155 139.73818030669392 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f594b32-d63a-4fe6-9d6b-a01da8dbae15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f594b32-d63a-4fe6-9d6b-a01da8dbae15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f594b32-d63a-4fe6-9d6b-a01da8dbae15">
											<gml:posList>35.671816186653075 139.7380831302706 33.415 35.67182063252287 139.73808578718499 33.415 35.67193387920492 139.73803794292712 33.415 35.671936146325955 139.73803246118146 33.415 35.671816186653075 139.7380831302706 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b146d00-5105-4a37-ae56-84fbf5ab075e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b146d00-5105-4a37-ae56-84fbf5ab075e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b146d00-5105-4a37-ae56-84fbf5ab075e">
											<gml:posList>35.67184565293826 139.73817484716906 32.824 35.671991131083004 139.73811349908607 32.824 35.671973387124254 139.73805027906965 32.824 35.67194061512521 139.7380640929715 32.824 35.67193387920492 139.73803794292712 32.824 35.67182063252287 139.73808578718499 32.824 35.67184565293826 139.73817484716906 32.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c3182bc-8cff-44d9-8e2f-72548d6fc8ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c3182bc-8cff-44d9-8e2f-72548d6fc8ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c3182bc-8cff-44d9-8e2f-72548d6fc8ec">
											<gml:posList>35.67199558597447 139.73811616704367 33.415 35.671991131083004 139.73811349908607 33.415 35.67184565293826 139.73817484716906 33.415 35.671843484944155 139.73818030669392 33.415 35.67199558597447 139.73811616704367 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f93424e4-76d4-444a-959c-0c5ffc3c166c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f93424e4-76d4-444a-959c-0c5ffc3c166c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f93424e4-76d4-444a-959c-0c5ffc3c166c">
											<gml:posList>35.671942882238696 139.7380586001797 33.415 35.671936146325955 139.73803246118146 33.415 35.67193387920492 139.73803794292712 33.415 35.67194061512521 139.7380640929715 33.415 35.671942882238696 139.7380586001797 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11aed4f2-983a-40e8-bed1-0ef5693b2a73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11aed4f2-983a-40e8-bed1-0ef5693b2a73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11aed4f2-983a-40e8-bed1-0ef5693b2a73">
											<gml:posList>35.671942882238696 139.7380586001797 33.415 35.67194061512521 139.7380640929715 33.415 35.671973387124254 139.73805027906965 33.415 35.67197556413486 139.7380448305682 33.415 35.671942882238696 139.7380586001797 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31bf8ddb-1080-4bdb-b1e4-c957cbb76cb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31bf8ddb-1080-4bdb-b1e4-c957cbb76cb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31bf8ddb-1080-4bdb-b1e4-c957cbb76cb3">
											<gml:posList>35.67197556413486 139.7380448305682 33.415 35.671973387124254 139.73805027906965 33.415 35.671991131083004 139.73811349908607 33.415 35.67199558597447 139.73811616704367 33.415 35.67197556413486 139.7380448305682 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87b008a8-892b-4f89-9d07-a093ca778867">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87b008a8-892b-4f89-9d07-a093ca778867">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87b008a8-892b-4f89-9d07-a093ca778867">
											<gml:posList>35.671816186653075 139.7380831302706 10.049 35.671843484944155 139.73818030669392 10.049 35.671843484944155 139.73818030669392 33.415 35.671816186653075 139.7380831302706 33.415 35.671816186653075 139.7380831302706 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a555815-a055-46e8-bef9-1d93573a40d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a555815-a055-46e8-bef9-1d93573a40d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a555815-a055-46e8-bef9-1d93573a40d8">
											<gml:posList>35.67184565293826 139.73817484716906 33.415 35.67184565293826 139.73817484716906 32.824 35.67182063252287 139.73808578718499 32.824 35.67182063252287 139.73808578718499 33.415 35.67184565293826 139.73817484716906 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc6284a5-d0aa-459b-8f39-b9d89cf4c48f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc6284a5-d0aa-459b-8f39-b9d89cf4c48f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc6284a5-d0aa-459b-8f39-b9d89cf4c48f">
											<gml:posList>35.671936146325955 139.73803246118146 10.049 35.671816186653075 139.7380831302706 10.049 35.671816186653075 139.7380831302706 33.415 35.671936146325955 139.73803246118146 33.415 35.671936146325955 139.73803246118146 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-208593c4-df2d-4138-b5d7-e741c7b1344f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-208593c4-df2d-4138-b5d7-e741c7b1344f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-208593c4-df2d-4138-b5d7-e741c7b1344f">
											<gml:posList>35.67182063252287 139.73808578718499 33.415 35.67182063252287 139.73808578718499 32.824 35.67193387920492 139.73803794292712 32.824 35.67193387920492 139.73803794292712 33.415 35.67182063252287 139.73808578718499 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2bbdb8f5-63e8-4626-8ae1-ff051a8de5c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bbdb8f5-63e8-4626-8ae1-ff051a8de5c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bbdb8f5-63e8-4626-8ae1-ff051a8de5c0">
											<gml:posList>35.671991131083004 139.73811349908607 33.415 35.671991131083004 139.73811349908607 32.824 35.67184565293826 139.73817484716906 32.824 35.67184565293826 139.73817484716906 33.415 35.671991131083004 139.73811349908607 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-993b1f4a-77c4-46c6-afff-c804868bb867">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-993b1f4a-77c4-46c6-afff-c804868bb867">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-993b1f4a-77c4-46c6-afff-c804868bb867">
											<gml:posList>35.671843484944155 139.73818030669392 10.049 35.67199558597447 139.73811616704367 10.049 35.67199558597447 139.73811616704367 33.415 35.671843484944155 139.73818030669392 33.415 35.671843484944155 139.73818030669392 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f21d3f0-353a-4548-ae50-9de2e722aefc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f21d3f0-353a-4548-ae50-9de2e722aefc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f21d3f0-353a-4548-ae50-9de2e722aefc">
											<gml:posList>35.67193387920492 139.73803794292712 33.415 35.67193387920492 139.73803794292712 32.824 35.67194061512521 139.7380640929715 32.824 35.67194061512521 139.7380640929715 33.415 35.67193387920492 139.73803794292712 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2bec6ae-219c-471a-b6c9-a234e9e53fa7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2bec6ae-219c-471a-b6c9-a234e9e53fa7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2bec6ae-219c-471a-b6c9-a234e9e53fa7">
											<gml:posList>35.671942882238696 139.7380586001797 10.049 35.671936146325955 139.73803246118146 10.049 35.671936146325955 139.73803246118146 33.415 35.671942882238696 139.7380586001797 33.415 35.671942882238696 139.7380586001797 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e971c2f3-1e7e-4776-af44-5d89c8bdc6bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e971c2f3-1e7e-4776-af44-5d89c8bdc6bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e971c2f3-1e7e-4776-af44-5d89c8bdc6bb">
											<gml:posList>35.67194061512521 139.7380640929715 33.415 35.67194061512521 139.7380640929715 32.824 35.671973387124254 139.73805027906965 32.824 35.671973387124254 139.73805027906965 33.415 35.67194061512521 139.7380640929715 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7878d61-9a6c-4003-a0e6-e32e298d42cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7878d61-9a6c-4003-a0e6-e32e298d42cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7878d61-9a6c-4003-a0e6-e32e298d42cb">
											<gml:posList>35.67197556413486 139.7380448305682 10.049 35.671942882238696 139.7380586001797 10.049 35.671942882238696 139.7380586001797 33.415 35.67197556413486 139.7380448305682 33.415 35.67197556413486 139.7380448305682 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ff1658a-2b98-4a4c-9e4c-4306b08350c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ff1658a-2b98-4a4c-9e4c-4306b08350c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ff1658a-2b98-4a4c-9e4c-4306b08350c5">
											<gml:posList>35.671973387124254 139.73805027906965 33.415 35.671973387124254 139.73805027906965 32.824 35.671991131083004 139.73811349908607 32.824 35.671991131083004 139.73811349908607 33.415 35.671973387124254 139.73805027906965 33.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d592706-de26-460e-adcb-bcb869491940">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d592706-de26-460e-adcb-bcb869491940">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d592706-de26-460e-adcb-bcb869491940">
											<gml:posList>35.67199558597447 139.73811616704367 10.049 35.67197556413486 139.7380448305682 10.049 35.67197556413486 139.7380448305682 33.415 35.67199558597447 139.73811616704367 33.415 35.67199558597447 139.73811616704367 10.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5645</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">175.9777</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>