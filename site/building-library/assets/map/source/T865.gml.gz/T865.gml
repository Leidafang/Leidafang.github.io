<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f871c325-a18c-4d50-9b82-75e59c63d08c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>虎ノ門二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:measuredHeight uom="m">5.8</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6696527985921 139.74518120081188 0 35.669533654874996 139.74532879781484 0 35.66958456530174 139.7453916718545 0 35.669704493232366 139.7452439966663 0 35.6696527985921 139.74518120081188 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6696527985921 139.74518120081188 7.6 35.669704493232366 139.7452439966663 7.6 35.66958456530174 139.7453916718545 7.6 35.669533654874996 139.74532879781484 7.6 35.6696527985921 139.74518120081188 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6696527985921 139.74518120081188 7.6 35.669533654874996 139.74532879781484 7.6 35.669533654874996 139.74532879781484 13.42 35.6696527985921 139.74518120081188 13.42 35.6696527985921 139.74518120081188 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669533654874996 139.74532879781484 7.6 35.66958456530174 139.7453916718545 7.6 35.66958456530174 139.7453916718545 13.42 35.669533654874996 139.74532879781484 13.42 35.669533654874996 139.74532879781484 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66958456530174 139.7453916718545 7.6 35.669704493232366 139.7452439966663 7.6 35.669704493232366 139.7452439966663 13.42 35.66958456530174 139.7453916718545 13.42 35.66958456530174 139.7453916718545 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669704493232366 139.7452439966663 7.6 35.6696527985921 139.74518120081188 7.6 35.6696527985921 139.74518120081188 13.42 35.669704493232366 139.7452439966663 13.42 35.669704493232366 139.7452439966663 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6696527985921 139.74518120081188 13.42 35.669533654874996 139.74532879781484 13.42 35.66958456530174 139.7453916718545 13.42 35.669704493232366 139.7452439966663 13.42 35.6696527985921 139.74518120081188 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8f69476b-457b-4367-91f8-26bc1b5157ca"/>
							<gml:surfaceMember xlink:href="#poly-31b0866a-36a1-4870-ab8c-53a23fc882a4"/>
							<gml:surfaceMember xlink:href="#poly-2f4d2e7e-b2e8-4d00-8d94-6339356ea256"/>
							<gml:surfaceMember xlink:href="#poly-b9bb4500-178e-419e-9dd8-72d2a549770a"/>
							<gml:surfaceMember xlink:href="#poly-4ff511e2-a227-4847-a1fd-ecbf6c20c49b"/>
							<gml:surfaceMember xlink:href="#poly-34094ee0-c7a1-41d4-adfa-947d2cddae69"/>
							<gml:surfaceMember xlink:href="#poly-cb4fda7c-a60a-48f9-a2d4-874e7d005ab1"/>
							<gml:surfaceMember xlink:href="#poly-a0f748c3-5bd7-4ee4-aa39-202d45f849ba"/>
							<gml:surfaceMember xlink:href="#poly-1817da3f-7889-461e-9a0c-98d05d2c215e"/>
							<gml:surfaceMember xlink:href="#poly-5db500c7-91c0-452c-bfa5-4a593b780906"/>
							<gml:surfaceMember xlink:href="#poly-cd4bf236-4320-4d6a-8b43-37b32d99e04c"/>
							<gml:surfaceMember xlink:href="#poly-31481968-9e05-4fe7-a832-b04b187cf00c"/>
							<gml:surfaceMember xlink:href="#poly-2afda1d8-08d3-4168-8405-8d06d7f2393b"/>
							<gml:surfaceMember xlink:href="#poly-631f6160-9822-4955-a370-fa4af4980dd4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8f69476b-457b-4367-91f8-26bc1b5157ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f69476b-457b-4367-91f8-26bc1b5157ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f69476b-457b-4367-91f8-26bc1b5157ca">
											<gml:posList>35.6696527985921 139.74518120081188 7.6 35.669704493232366 139.74524399666626 7.6 35.669584565301726 139.7453916718545 7.6 35.669533654875 139.74532879781484 7.6 35.6696527985921 139.74518120081188 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31b0866a-36a1-4870-ab8c-53a23fc882a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31b0866a-36a1-4870-ab8c-53a23fc882a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31b0866a-36a1-4870-ab8c-53a23fc882a4">
											<gml:posList>35.6696527985921 139.74518120081188 13.6 35.66965280139 139.74518502278005 13.6 35.6697013744997 139.74524402218498 13.6 35.669704493232366 139.74524399666626 13.6 35.6696527985921 139.74518120081188 13.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2f4d2e7e-b2e8-4d00-8d94-6339356ea256">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f4d2e7e-b2e8-4d00-8d94-6339356ea256">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f4d2e7e-b2e8-4d00-8d94-6339356ea256">
											<gml:posList>35.669533654875 139.74532879781484 13.6 35.66953674658274 139.7453287944214 13.6 35.66965280139 139.74518502278005 13.6 35.6696527985921 139.74518120081188 13.6 35.669533654875 139.74532879781484 13.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9bb4500-178e-419e-9dd8-72d2a549770a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9bb4500-178e-419e-9dd8-72d2a549770a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9bb4500-178e-419e-9dd8-72d2a549770a">
											<gml:posList>35.6697013744997 139.74524402218498 13.36 35.66965280139 139.74518502278005 13.36 35.66953674658274 139.7453287944214 13.36 35.66958457151604 139.7453878388335 13.36 35.6697013744997 139.74524402218498 13.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ff511e2-a227-4847-a1fd-ecbf6c20c49b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ff511e2-a227-4847-a1fd-ecbf6c20c49b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ff511e2-a227-4847-a1fd-ecbf6c20c49b">
											<gml:posList>35.669704493232366 139.74524399666626 13.6 35.6697013744997 139.74524402218498 13.6 35.66958457151604 139.7453878388335 13.6 35.669584565301726 139.7453916718545 13.6 35.669704493232366 139.74524399666626 13.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-34094ee0-c7a1-41d4-adfa-947d2cddae69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34094ee0-c7a1-41d4-adfa-947d2cddae69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34094ee0-c7a1-41d4-adfa-947d2cddae69">
											<gml:posList>35.669584565301726 139.7453916718545 13.6 35.66958457151604 139.7453878388335 13.6 35.66953674658274 139.7453287944214 13.6 35.669533654875 139.74532879781484 13.6 35.669584565301726 139.7453916718545 13.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb4fda7c-a60a-48f9-a2d4-874e7d005ab1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb4fda7c-a60a-48f9-a2d4-874e7d005ab1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb4fda7c-a60a-48f9-a2d4-874e7d005ab1">
											<gml:posList>35.66953674658274 139.7453287944214 13.6 35.66953674658274 139.7453287944214 13.36 35.66965280139 139.74518502278005 13.36 35.66965280139 139.74518502278005 13.6 35.66953674658274 139.7453287944214 13.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0f748c3-5bd7-4ee4-aa39-202d45f849ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0f748c3-5bd7-4ee4-aa39-202d45f849ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0f748c3-5bd7-4ee4-aa39-202d45f849ba">
											<gml:posList>35.6697013744997 139.74524402218498 13.6 35.6697013744997 139.74524402218498 13.36 35.66958457151604 139.7453878388335 13.36 35.66958457151604 139.7453878388335 13.6 35.6697013744997 139.74524402218498 13.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1817da3f-7889-461e-9a0c-98d05d2c215e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1817da3f-7889-461e-9a0c-98d05d2c215e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1817da3f-7889-461e-9a0c-98d05d2c215e">
											<gml:posList>35.669704493232366 139.74524399666626 7.6 35.6696527985921 139.74518120081188 7.6 35.6696527985921 139.74518120081188 13.6 35.669704493232366 139.74524399666626 13.6 35.669704493232366 139.74524399666626 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5db500c7-91c0-452c-bfa5-4a593b780906">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5db500c7-91c0-452c-bfa5-4a593b780906">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5db500c7-91c0-452c-bfa5-4a593b780906">
											<gml:posList>35.66965280139 139.74518502278005 13.6 35.66965280139 139.74518502278005 13.36 35.6697013744997 139.74524402218498 13.36 35.6697013744997 139.74524402218498 13.6 35.66965280139 139.74518502278005 13.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd4bf236-4320-4d6a-8b43-37b32d99e04c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd4bf236-4320-4d6a-8b43-37b32d99e04c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd4bf236-4320-4d6a-8b43-37b32d99e04c">
											<gml:posList>35.669584565301726 139.7453916718545 7.6 35.669704493232366 139.74524399666626 7.6 35.669704493232366 139.74524399666626 13.6 35.669584565301726 139.7453916718545 13.6 35.669584565301726 139.7453916718545 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31481968-9e05-4fe7-a832-b04b187cf00c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31481968-9e05-4fe7-a832-b04b187cf00c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31481968-9e05-4fe7-a832-b04b187cf00c">
											<gml:posList>35.6696527985921 139.74518120081188 7.6 35.669533654875 139.74532879781484 7.6 35.669533654875 139.74532879781484 13.6 35.6696527985921 139.74518120081188 13.6 35.6696527985921 139.74518120081188 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2afda1d8-08d3-4168-8405-8d06d7f2393b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2afda1d8-08d3-4168-8405-8d06d7f2393b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2afda1d8-08d3-4168-8405-8d06d7f2393b">
											<gml:posList>35.66958457151604 139.7453878388335 13.6 35.66958457151604 139.7453878388335 13.36 35.66953674658274 139.7453287944214 13.36 35.66953674658274 139.7453287944214 13.6 35.66958457151604 139.7453878388335 13.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-631f6160-9822-4955-a370-fa4af4980dd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-631f6160-9822-4955-a370-fa4af4980dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-631f6160-9822-4955-a370-fa4af4980dd4">
											<gml:posList>35.669533654875 139.74532879781484 7.6 35.669584565301726 139.7453916718545 7.6 35.669584565301726 139.7453916718545 13.6 35.669533654875 139.74532879781484 13.6 35.669533654875 139.74532879781484 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8965</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>