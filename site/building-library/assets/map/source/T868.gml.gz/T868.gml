<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f8a7b37e-35b8-4225-b46b-8d951b571653">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">4.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667805530307376 139.74228235607526 0 35.66781470526336 139.74225716099087 0 35.66778021432014 139.7421798788564 0 35.66773052827881 139.74215298335596 0 35.6677195455152 139.74218337205062 0 35.66769697729847 139.7422458069831 0 35.667724480445266 139.74226068769718 0 35.66770352213921 139.7423184815104 0 35.66779865602173 139.74237006835872 0 35.66782627039817 139.7422935993506 0 35.667805530307376 139.74228235607526 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667805530307376 139.74228235607526 28.709 35.66782627039817 139.7422935993506 28.709 35.66779865602173 139.74237006835872 28.709 35.66770352213921 139.7423184815104 28.709 35.667724480445266 139.74226068769718 28.709 35.66769697729847 139.7422458069831 28.709 35.6677195455152 139.74218337205062 28.709 35.66773052827881 139.74215298335596 28.709 35.66778021432014 139.7421798788564 28.709 35.66781470526336 139.74225716099087 28.709 35.667805530307376 139.74228235607526 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667805530307376 139.74228235607526 28.709 35.66781470526336 139.74225716099087 28.709 35.66781470526336 139.74225716099087 33.4 35.667805530307376 139.74228235607526 33.4 35.667805530307376 139.74228235607526 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66781470526336 139.74225716099087 28.709 35.66778021432014 139.7421798788564 28.709 35.66778021432014 139.7421798788564 33.4 35.66781470526336 139.74225716099087 33.4 35.66781470526336 139.74225716099087 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66778021432014 139.7421798788564 28.709 35.66773052827881 139.74215298335596 28.709 35.66773052827881 139.74215298335596 33.4 35.66778021432014 139.7421798788564 33.4 35.66778021432014 139.7421798788564 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66773052827881 139.74215298335596 28.709 35.6677195455152 139.74218337205062 28.709 35.6677195455152 139.74218337205062 33.4 35.66773052827881 139.74215298335596 33.4 35.66773052827881 139.74215298335596 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6677195455152 139.74218337205062 28.709 35.66769697729847 139.7422458069831 28.709 35.66769697729847 139.7422458069831 33.4 35.6677195455152 139.74218337205062 33.4 35.6677195455152 139.74218337205062 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66769697729847 139.7422458069831 28.709 35.667724480445266 139.74226068769718 28.709 35.667724480445266 139.74226068769718 33.4 35.66769697729847 139.7422458069831 33.4 35.66769697729847 139.7422458069831 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667724480445266 139.74226068769718 28.709 35.66770352213921 139.7423184815104 28.709 35.66770352213921 139.7423184815104 33.4 35.667724480445266 139.74226068769718 33.4 35.667724480445266 139.74226068769718 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66770352213921 139.7423184815104 28.709 35.66779865602173 139.74237006835872 28.709 35.66779865602173 139.74237006835872 33.4 35.66770352213921 139.7423184815104 33.4 35.66770352213921 139.7423184815104 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66779865602173 139.74237006835872 28.709 35.66782627039817 139.7422935993506 28.709 35.66782627039817 139.7422935993506 33.4 35.66779865602173 139.74237006835872 33.4 35.66779865602173 139.74237006835872 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66782627039817 139.7422935993506 28.709 35.667805530307376 139.74228235607526 28.709 35.667805530307376 139.74228235607526 33.4 35.66782627039817 139.7422935993506 33.4 35.66782627039817 139.7422935993506 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667805530307376 139.74228235607526 33.4 35.66781470526336 139.74225716099087 33.4 35.66778021432014 139.7421798788564 33.4 35.66773052827881 139.74215298335596 33.4 35.6677195455152 139.74218337205062 33.4 35.66769697729847 139.7422458069831 33.4 35.667724480445266 139.74226068769718 33.4 35.66770352213921 139.7423184815104 33.4 35.66779865602173 139.74237006835872 33.4 35.66782627039817 139.7422935993506 33.4 35.667805530307376 139.74228235607526 33.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c3a8eaed-60f4-4f4d-ab71-82313bc5bb25"/>
							<gml:surfaceMember xlink:href="#poly-7443bf1c-7e2b-4d26-9b6b-85d74111ea61"/>
							<gml:surfaceMember xlink:href="#poly-4e0354c6-cc5d-4cdd-8759-e75168c6bb82"/>
							<gml:surfaceMember xlink:href="#poly-9bba6d73-c074-4b35-9273-ee0d09c97dcf"/>
							<gml:surfaceMember xlink:href="#poly-f96a481a-b0ca-4765-b817-c318d04d0996"/>
							<gml:surfaceMember xlink:href="#poly-14e83cfb-48d8-451e-8f45-08efd9075211"/>
							<gml:surfaceMember xlink:href="#poly-7086eb94-8b9c-480a-9b78-3aec05eb0d77"/>
							<gml:surfaceMember xlink:href="#poly-6a5978ce-8e77-4e6b-b915-8170f9f9b098"/>
							<gml:surfaceMember xlink:href="#poly-a2224941-ff4a-45b1-adf4-2b9a1edbc1f1"/>
							<gml:surfaceMember xlink:href="#poly-c94d5536-b9f3-4cfe-aae9-e816aebd510e"/>
							<gml:surfaceMember xlink:href="#poly-aabf24f7-5c32-454b-bb66-865476e6e6c5"/>
							<gml:surfaceMember xlink:href="#poly-07095660-88d2-4946-a814-80bbf90c16d5"/>
							<gml:surfaceMember xlink:href="#poly-79fd6268-2d49-4f5e-aacc-3d3589863c0a"/>
							<gml:surfaceMember xlink:href="#poly-5002baae-5759-49e9-886d-fdb5ad8eccc1"/>
							<gml:surfaceMember xlink:href="#poly-848fbc35-0a50-4fd3-85b8-ca1d20e9fa02"/>
							<gml:surfaceMember xlink:href="#poly-c6bae02b-4a31-4ca6-a762-963524130f3e"/>
							<gml:surfaceMember xlink:href="#poly-c998490f-b54f-43b1-9905-795086cebc9c"/>
							<gml:surfaceMember xlink:href="#poly-79e8ac1b-4c83-45c8-8ad3-587c260874c3"/>
							<gml:surfaceMember xlink:href="#poly-55f1680d-3d63-49d9-9ccd-ccf40539669c"/>
							<gml:surfaceMember xlink:href="#poly-d2f275e4-5ffa-4938-89b3-cb0b2d2af0ef"/>
							<gml:surfaceMember xlink:href="#poly-865febc8-059a-4279-898d-f9851ac5c4d9"/>
							<gml:surfaceMember xlink:href="#poly-21c1d4ab-5545-43f8-ac66-5d2cfb8b642c"/>
							<gml:surfaceMember xlink:href="#poly-97258a7b-d7a6-4a3f-a789-55b5476a569e"/>
							<gml:surfaceMember xlink:href="#poly-5e7d24a3-d4c9-4fdf-8a95-8565111e3dd4"/>
							<gml:surfaceMember xlink:href="#poly-bff3e9d5-c1ca-4b14-a0d1-733693977261"/>
							<gml:surfaceMember xlink:href="#poly-8be618aa-2032-4f8a-bd25-e887cfdd375b"/>
							<gml:surfaceMember xlink:href="#poly-50de1645-97b4-4150-8fb9-c7ff273b2318"/>
							<gml:surfaceMember xlink:href="#poly-6c6e2876-97c3-441b-b77b-e025fe123878"/>
							<gml:surfaceMember xlink:href="#poly-8e01284e-4413-4fa0-83dd-7fad1af915fe"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c3a8eaed-60f4-4f4d-ab71-82313bc5bb25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3a8eaed-60f4-4f4d-ab71-82313bc5bb25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3a8eaed-60f4-4f4d-ab71-82313bc5bb25">
											<gml:posList>35.667826270398166 139.7422935993506 28.709 35.66779865602171 139.74237006835872 28.709 35.667703522139185 139.7423184815104 28.709 35.667724480445266 139.74226068769718 28.709 35.667696977298455 139.7422458069831 28.709 35.66771954551519 139.74218337205062 28.709 35.66777315419283 139.74221247228863 28.709 35.66775736824388 139.74225629826006 28.709 35.667805530307376 139.74228235607524 28.709 35.667826270398166 139.7422935993506 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7443bf1c-7e2b-4d26-9b6b-85d74111ea61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7443bf1c-7e2b-4d26-9b6b-85d74111ea61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7443bf1c-7e2b-4d26-9b6b-85d74111ea61">
											<gml:posList>35.66777315419283 139.74221247228863 28.25 35.66771954551519 139.74218337205062 28.25 35.66773052827881 139.74215298335596 28.25 35.667780214320125 139.7421798788564 28.25 35.66781470526338 139.74225716099087 28.25 35.667805530307376 139.74228235607524 28.25 35.66775736824388 139.74225629826006 28.25 35.66777315419283 139.74221247228863 28.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e0354c6-cc5d-4cdd-8759-e75168c6bb82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e0354c6-cc5d-4cdd-8759-e75168c6bb82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e0354c6-cc5d-4cdd-8759-e75168c6bb82">
											<gml:posList>35.66771954551519 139.74218337205062 34.079 35.667696977298455 139.7422458069831 34.079 35.6677178952446 139.74221810221366 35.462 35.66771954551519 139.74218337205062 34.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9bba6d73-c074-4b35-9273-ee0d09c97dcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bba6d73-c074-4b35-9273-ee0d09c97dcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bba6d73-c074-4b35-9273-ee0d09c97dcf">
											<gml:posList>35.667732016559974 139.74229728523324 35.824 35.667724480445266 139.74226068769718 32.5 35.667703522139185 139.7423184815104 32.5 35.667732016559974 139.74229728523324 35.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f96a481a-b0ca-4765-b817-c318d04d0996">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f96a481a-b0ca-4765-b817-c318d04d0996">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f96a481a-b0ca-4765-b817-c318d04d0996">
											<gml:posList>35.667744613966484 139.7422326745282 35.462 35.6677178952446 139.74221810221366 35.462 35.667696977298455 139.7422458069831 34.079 35.66775061311937 139.74227506186648 34.079 35.667744613966484 139.7422326745282 35.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14e83cfb-48d8-451e-8f45-08efd9075211">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14e83cfb-48d8-451e-8f45-08efd9075211">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14e83cfb-48d8-451e-8f45-08efd9075211">
											<gml:posList>35.66775061311937 139.74227506186648 32.5 35.667724480445266 139.74226068769718 32.5 35.667732016559974 139.74229728523324 35.824 35.66775061311937 139.74227506186648 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7086eb94-8b9c-480a-9b78-3aec05eb0d77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7086eb94-8b9c-480a-9b78-3aec05eb0d77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7086eb94-8b9c-480a-9b78-3aec05eb0d77">
											<gml:posList>35.667744613966484 139.7422326745282 35.462 35.66777315419283 139.74221247228863 34.079 35.66771954551519 139.74218337205062 34.079 35.6677178952446 139.74221810221366 35.462 35.667744613966484 139.7422326745282 35.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a5978ce-8e77-4e6b-b915-8170f9f9b098">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a5978ce-8e77-4e6b-b915-8170f9f9b098">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a5978ce-8e77-4e6b-b915-8170f9f9b098">
											<gml:posList>35.667732016559974 139.74229728523324 35.824 35.667703522139185 139.7423184815104 32.5 35.66779865602171 139.74237006835872 32.5 35.667732016559974 139.74229728523324 35.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2224941-ff4a-45b1-adf4-2b9a1edbc1f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2224941-ff4a-45b1-adf4-2b9a1edbc1f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2224941-ff4a-45b1-adf4-2b9a1edbc1f1">
											<gml:posList>35.66775061311937 139.74227506186648 34.079 35.66777315419283 139.74221247228863 34.079 35.667744613966484 139.7422326745282 35.462 35.66775061311937 139.74227506186648 34.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c94d5536-b9f3-4cfe-aae9-e816aebd510e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c94d5536-b9f3-4cfe-aae9-e816aebd510e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c94d5536-b9f3-4cfe-aae9-e816aebd510e">
											<gml:posList>35.66779865602171 139.74237006835872 32.5 35.667793197583975 139.74232749259386 35.824 35.667732016559974 139.74229728523324 35.824 35.66779865602171 139.74237006835872 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aabf24f7-5c32-454b-bb66-865476e6e6c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aabf24f7-5c32-454b-bb66-865476e6e6c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aabf24f7-5c32-454b-bb66-865476e6e6c5">
											<gml:posList>35.66773052827881 139.74215298335596 31.5 35.66771954551519 139.74218337205062 31.5 35.66777315419283 139.74221247228863 31.5 35.66775736824388 139.74225629826006 31.5 35.667805530307376 139.74228235607524 31.5 35.66781470526338 139.74225716099087 31.5 35.667780214320125 139.7421798788564 31.5 35.66773052827881 139.74215298335596 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-07095660-88d2-4946-a814-80bbf90c16d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07095660-88d2-4946-a814-80bbf90c16d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07095660-88d2-4946-a814-80bbf90c16d5">
											<gml:posList>35.667732016559974 139.74229728523324 35.824 35.667793197583975 139.74232749259386 35.824 35.667826270398166 139.7422935993506 32.5 35.667732016559974 139.74229728523324 35.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79fd6268-2d49-4f5e-aacc-3d3589863c0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79fd6268-2d49-4f5e-aacc-3d3589863c0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79fd6268-2d49-4f5e-aacc-3d3589863c0a">
											<gml:posList>35.66775061311937 139.74227506186648 32.5 35.667732016559974 139.74229728523324 35.824 35.667826270398166 139.7422935993506 32.5 35.66775061311937 139.74227506186648 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5002baae-5759-49e9-886d-fdb5ad8eccc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5002baae-5759-49e9-886d-fdb5ad8eccc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5002baae-5759-49e9-886d-fdb5ad8eccc1">
											<gml:posList>35.66775061311937 139.74227506186648 32.5 35.667826270398166 139.7422935993506 32.5 35.66775736824388 139.74225629826006 32.5 35.66775061311937 139.74227506186648 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-848fbc35-0a50-4fd3-85b8-ca1d20e9fa02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-848fbc35-0a50-4fd3-85b8-ca1d20e9fa02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-848fbc35-0a50-4fd3-85b8-ca1d20e9fa02">
											<gml:posList>35.66779865602171 139.74237006835872 32.5 35.667826270398166 139.7422935993506 32.5 35.667793197583975 139.74232749259386 35.824 35.66779865602171 139.74237006835872 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6bae02b-4a31-4ca6-a762-963524130f3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6bae02b-4a31-4ca6-a762-963524130f3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6bae02b-4a31-4ca6-a762-963524130f3e">
											<gml:posList>35.667780214320125 139.7421798788564 28.25 35.66773052827881 139.74215298335596 28.25 35.66773052827881 139.74215298335596 31.5 35.667780214320125 139.7421798788564 31.5 35.667780214320125 139.7421798788564 28.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c998490f-b54f-43b1-9905-795086cebc9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c998490f-b54f-43b1-9905-795086cebc9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c998490f-b54f-43b1-9905-795086cebc9c">
											<gml:posList>35.66771954551519 139.74218337205062 28.25 35.66777315419283 139.74221247228863 28.25 35.66777315419283 139.74221247228863 28.709 35.66771954551519 139.74218337205062 28.709 35.66771954551519 139.74218337205062 28.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79e8ac1b-4c83-45c8-8ad3-587c260874c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79e8ac1b-4c83-45c8-8ad3-587c260874c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79e8ac1b-4c83-45c8-8ad3-587c260874c3">
											<gml:posList>35.66771954551519 139.74218337205062 34.079 35.66777315419283 139.74221247228863 34.079 35.66777315419283 139.74221247228863 31.5 35.66771954551519 139.74218337205062 31.5 35.66771954551519 139.74218337205062 34.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55f1680d-3d63-49d9-9ccd-ccf40539669c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55f1680d-3d63-49d9-9ccd-ccf40539669c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55f1680d-3d63-49d9-9ccd-ccf40539669c">
											<gml:posList>35.667696977298455 139.7422458069831 34.079 35.66771954551519 139.74218337205062 34.079 35.66771954551519 139.74218337205062 31.5 35.66773052827881 139.74215298335596 31.5 35.66773052827881 139.74215298335596 28.25 35.66771954551519 139.74218337205062 28.25 35.66771954551519 139.74218337205062 28.709 35.667696977298455 139.7422458069831 28.709 35.667696977298455 139.7422458069831 34.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2f275e4-5ffa-4938-89b3-cb0b2d2af0ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2f275e4-5ffa-4938-89b3-cb0b2d2af0ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2f275e4-5ffa-4938-89b3-cb0b2d2af0ef">
											<gml:posList>35.66781470526338 139.74225716099087 28.25 35.667780214320125 139.7421798788564 28.25 35.667780214320125 139.7421798788564 31.5 35.66781470526338 139.74225716099087 31.5 35.66781470526338 139.74225716099087 28.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-865febc8-059a-4279-898d-f9851ac5c4d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-865febc8-059a-4279-898d-f9851ac5c4d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-865febc8-059a-4279-898d-f9851ac5c4d9">
											<gml:posList>35.66777315419283 139.74221247228863 28.25 35.66775736824388 139.74225629826006 28.25 35.66775736824388 139.74225629826006 28.709 35.66777315419283 139.74221247228863 28.709 35.66777315419283 139.74221247228863 28.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21c1d4ab-5545-43f8-ac66-5d2cfb8b642c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21c1d4ab-5545-43f8-ac66-5d2cfb8b642c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21c1d4ab-5545-43f8-ac66-5d2cfb8b642c">
											<gml:posList>35.66775061311937 139.74227506186648 34.079 35.66775061311937 139.74227506186648 32.5 35.66775736824388 139.74225629826006 32.5 35.66775736824388 139.74225629826006 31.5 35.66777315419283 139.74221247228863 31.5 35.66777315419283 139.74221247228863 34.079 35.66775061311937 139.74227506186648 34.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97258a7b-d7a6-4a3f-a789-55b5476a569e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97258a7b-d7a6-4a3f-a789-55b5476a569e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97258a7b-d7a6-4a3f-a789-55b5476a569e">
											<gml:posList>35.667696977298455 139.7422458069831 34.079 35.667696977298455 139.7422458069831 28.709 35.667724480445266 139.74226068769718 28.709 35.667724480445266 139.74226068769718 32.5 35.66775061311937 139.74227506186648 32.5 35.66775061311937 139.74227506186648 34.079 35.667696977298455 139.7422458069831 34.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e7d24a3-d4c9-4fdf-8a95-8565111e3dd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e7d24a3-d4c9-4fdf-8a95-8565111e3dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e7d24a3-d4c9-4fdf-8a95-8565111e3dd4">
											<gml:posList>35.66775736824388 139.74225629826006 28.709 35.66775736824388 139.74225629826006 28.25 35.667805530307376 139.74228235607524 28.25 35.667805530307376 139.74228235607524 28.709 35.66775736824388 139.74225629826006 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bff3e9d5-c1ca-4b14-a0d1-733693977261">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bff3e9d5-c1ca-4b14-a0d1-733693977261">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bff3e9d5-c1ca-4b14-a0d1-733693977261">
											<gml:posList>35.667826270398166 139.7422935993506 32.5 35.667826270398166 139.7422935993506 28.709 35.667805530307376 139.74228235607524 28.709 35.667805530307376 139.74228235607524 31.5 35.66775736824388 139.74225629826006 31.5 35.66775736824388 139.74225629826006 32.5 35.667826270398166 139.7422935993506 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8be618aa-2032-4f8a-bd25-e887cfdd375b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8be618aa-2032-4f8a-bd25-e887cfdd375b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8be618aa-2032-4f8a-bd25-e887cfdd375b">
											<gml:posList>35.667724480445266 139.74226068769718 28.709 35.667703522139185 139.7423184815104 28.709 35.667703522139185 139.7423184815104 32.5 35.667724480445266 139.74226068769718 32.5 35.667724480445266 139.74226068769718 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50de1645-97b4-4150-8fb9-c7ff273b2318">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50de1645-97b4-4150-8fb9-c7ff273b2318">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50de1645-97b4-4150-8fb9-c7ff273b2318">
											<gml:posList>35.667703522139185 139.7423184815104 28.709 35.66779865602171 139.74237006835872 28.709 35.66779865602171 139.74237006835872 32.5 35.667703522139185 139.7423184815104 32.5 35.667703522139185 139.7423184815104 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c6e2876-97c3-441b-b77b-e025fe123878">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c6e2876-97c3-441b-b77b-e025fe123878">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c6e2876-97c3-441b-b77b-e025fe123878">
											<gml:posList>35.66781470526338 139.74225716099087 28.25 35.66781470526338 139.74225716099087 31.5 35.667805530307376 139.74228235607524 31.5 35.667805530307376 139.74228235607524 28.709 35.667805530307376 139.74228235607524 28.25 35.66781470526338 139.74225716099087 28.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e01284e-4413-4fa0-83dd-7fad1af915fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e01284e-4413-4fa0-83dd-7fad1af915fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e01284e-4413-4fa0-83dd-7fad1af915fe">
											<gml:posList>35.66779865602171 139.74237006835872 28.709 35.667826270398166 139.7422935993506 28.709 35.667826270398166 139.7422935993506 32.5 35.66779865602171 139.74237006835872 32.5 35.66779865602171 139.74237006835872 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3679</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">168.9119</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.12</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">22</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>