<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f91cf2e9-c0b9-46a8-8203-7d83bb0492ce">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67073863371884 139.73752934446932 0 35.67070311340806 139.7374762320999 0 35.67068990983526 139.73748949240164 0 35.670701271931016 139.7375068436082 0 35.6706782782619 139.7375299468112 0 35.67068846688091 139.73754517853303 0 35.67073863371884 139.73752934446932 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073863371884 139.73752934446932 13.62 35.67068846688091 139.73754517853303 13.62 35.6706782782619 139.7375299468112 13.62 35.670701271931016 139.7375068436082 13.62 35.67068990983526 139.73748949240164 13.62 35.67070311340806 139.7374762320999 13.62 35.67073863371884 139.73752934446932 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073863371884 139.73752934446932 13.62 35.67070311340806 139.7374762320999 13.62 35.67070311340806 139.7374762320999 16.619999999999997 35.67073863371884 139.73752934446932 16.619999999999997 35.67073863371884 139.73752934446932 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070311340806 139.7374762320999 13.62 35.67068990983526 139.73748949240164 13.62 35.67068990983526 139.73748949240164 16.619999999999997 35.67070311340806 139.7374762320999 16.619999999999997 35.67070311340806 139.7374762320999 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068990983526 139.73748949240164 13.62 35.670701271931016 139.7375068436082 13.62 35.670701271931016 139.7375068436082 16.619999999999997 35.67068990983526 139.73748949240164 16.619999999999997 35.67068990983526 139.73748949240164 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670701271931016 139.7375068436082 13.62 35.6706782782619 139.7375299468112 13.62 35.6706782782619 139.7375299468112 16.619999999999997 35.670701271931016 139.7375068436082 16.619999999999997 35.670701271931016 139.7375068436082 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6706782782619 139.7375299468112 13.62 35.67068846688091 139.73754517853303 13.62 35.67068846688091 139.73754517853303 16.619999999999997 35.6706782782619 139.7375299468112 16.619999999999997 35.6706782782619 139.7375299468112 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068846688091 139.73754517853303 13.62 35.67073863371884 139.73752934446932 13.62 35.67073863371884 139.73752934446932 16.619999999999997 35.67068846688091 139.73754517853303 16.619999999999997 35.67068846688091 139.73754517853303 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073863371884 139.73752934446932 16.619999999999997 35.67070311340806 139.7374762320999 16.619999999999997 35.67068990983526 139.73748949240164 16.619999999999997 35.670701271931016 139.7375068436082 16.619999999999997 35.6706782782619 139.7375299468112 16.619999999999997 35.67068846688091 139.73754517853303 16.619999999999997 35.67073863371884 139.73752934446932 16.619999999999997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b2b74446-2231-4da5-bda3-d498e244dcba"/>
							<gml:surfaceMember xlink:href="#poly-a1b1dbde-d0ee-4b40-a1a6-7ed4b26634e2"/>
							<gml:surfaceMember xlink:href="#poly-fb027f12-021f-4428-b70a-ca0dbe3c9d06"/>
							<gml:surfaceMember xlink:href="#poly-23e05af8-f0ac-4fcc-b6c5-b3d271a0d855"/>
							<gml:surfaceMember xlink:href="#poly-39059c66-28e4-4adc-a2a1-e08ef05b549a"/>
							<gml:surfaceMember xlink:href="#poly-ac401742-d752-489a-80ac-c85f740802f0"/>
							<gml:surfaceMember xlink:href="#poly-835aa966-acd1-4ad5-b0e5-df6421f915e6"/>
							<gml:surfaceMember xlink:href="#poly-e4740de9-e8d6-45a3-a6ba-17ce3bfa1a1d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b2b74446-2231-4da5-bda3-d498e244dcba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2b74446-2231-4da5-bda3-d498e244dcba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2b74446-2231-4da5-bda3-d498e244dcba">
											<gml:posList>35.67073863371883 139.73752934446932 13.62 35.67068846688092 139.737545178533 13.62 35.67067827826191 139.7375299468112 13.62 35.670701271931 139.7375068436082 13.62 35.67068990983526 139.73748949240164 13.62 35.67070311340805 139.7374762320999 13.62 35.67073863371883 139.73752934446932 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a1b1dbde-d0ee-4b40-a1a6-7ed4b26634e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1b1dbde-d0ee-4b40-a1a6-7ed4b26634e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1b1dbde-d0ee-4b40-a1a6-7ed4b26634e2">
											<gml:posList>35.67073863371883 139.73752934446932 16.911 35.67070311340805 139.7374762320999 16.911 35.67068990983526 139.73748949240164 16.911 35.670701271931 139.7375068436082 16.911 35.67067827826191 139.7375299468112 16.911 35.67068846688092 139.737545178533 16.911 35.67073863371883 139.73752934446932 16.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb027f12-021f-4428-b70a-ca0dbe3c9d06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb027f12-021f-4428-b70a-ca0dbe3c9d06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb027f12-021f-4428-b70a-ca0dbe3c9d06">
											<gml:posList>35.67067827826191 139.7375299468112 13.62 35.67068846688092 139.737545178533 13.62 35.67068846688092 139.737545178533 16.911 35.67067827826191 139.7375299468112 16.911 35.67067827826191 139.7375299468112 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23e05af8-f0ac-4fcc-b6c5-b3d271a0d855">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23e05af8-f0ac-4fcc-b6c5-b3d271a0d855">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23e05af8-f0ac-4fcc-b6c5-b3d271a0d855">
											<gml:posList>35.670701271931 139.7375068436082 13.62 35.67067827826191 139.7375299468112 13.62 35.67067827826191 139.7375299468112 16.911 35.670701271931 139.7375068436082 16.911 35.670701271931 139.7375068436082 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39059c66-28e4-4adc-a2a1-e08ef05b549a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39059c66-28e4-4adc-a2a1-e08ef05b549a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39059c66-28e4-4adc-a2a1-e08ef05b549a">
											<gml:posList>35.67068990983526 139.73748949240164 13.62 35.670701271931 139.7375068436082 13.62 35.670701271931 139.7375068436082 16.911 35.67068990983526 139.73748949240164 16.911 35.67068990983526 139.73748949240164 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac401742-d752-489a-80ac-c85f740802f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac401742-d752-489a-80ac-c85f740802f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac401742-d752-489a-80ac-c85f740802f0">
											<gml:posList>35.67070311340805 139.7374762320999 13.62 35.67068990983526 139.73748949240164 13.62 35.67068990983526 139.73748949240164 16.911 35.67070311340805 139.7374762320999 16.911 35.67070311340805 139.7374762320999 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-835aa966-acd1-4ad5-b0e5-df6421f915e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-835aa966-acd1-4ad5-b0e5-df6421f915e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-835aa966-acd1-4ad5-b0e5-df6421f915e6">
											<gml:posList>35.67068846688092 139.737545178533 13.62 35.67073863371883 139.73752934446932 13.62 35.67073863371883 139.73752934446932 16.911 35.67068846688092 139.737545178533 16.911 35.67068846688092 139.737545178533 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4740de9-e8d6-45a3-a6ba-17ce3bfa1a1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4740de9-e8d6-45a3-a6ba-17ce3bfa1a1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4740de9-e8d6-45a3-a6ba-17ce3bfa1a1d">
											<gml:posList>35.67073863371883 139.73752934446932 13.62 35.67070311340805 139.7374762320999 13.62 35.67070311340805 139.7374762320999 16.911 35.67073863371883 139.73752934446932 16.911 35.67073863371883 139.73752934446932 13.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8485</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>