<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f98f123a-5ac1-40ec-93a4-9001f59dbde7">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">6</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671285570464505 139.74521486451226 0 35.671279625611106 139.7452206151657 0 35.67127476337405 139.74522769019455 0 35.67134716086023 139.74525124991683 0 35.67134589255515 139.74524252465977 0 35.67134318205386 139.74523380098776 0 35.67133912014023 139.74522596251282 0 35.67133397730687 139.74521911940187 0 35.671327934070995 139.74521360284834 0 35.67132108073162 139.74520963368056 0 35.6713144991782 139.74520754210081 0 35.6713070172226 139.74520677707764 0 35.67129944642333 139.7452077795741 0 35.67129223738557 139.74521043863055 0 35.671285570464505 139.74521486451226 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671285570464505 139.74521486451226 7.95 35.67129223738557 139.74521043863055 7.95 35.67129944642333 139.7452077795741 7.95 35.6713070172226 139.74520677707764 7.95 35.6713144991782 139.74520754210081 7.95 35.67132108073162 139.74520963368056 7.95 35.671327934070995 139.74521360284834 7.95 35.67133397730687 139.74521911940187 7.95 35.67133912014023 139.74522596251282 7.95 35.67134318205386 139.74523380098776 7.95 35.67134589255515 139.74524252465977 7.95 35.67134716086023 139.74525124991683 7.95 35.67127476337405 139.74522769019455 7.95 35.671279625611106 139.7452206151657 7.95 35.671285570464505 139.74521486451226 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671285570464505 139.74521486451226 7.95 35.671279625611106 139.7452206151657 7.95 35.671279625611106 139.7452206151657 13.9 35.671285570464505 139.74521486451226 13.9 35.671285570464505 139.74521486451226 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671279625611106 139.7452206151657 7.95 35.67127476337405 139.74522769019455 7.95 35.67127476337405 139.74522769019455 13.9 35.671279625611106 139.7452206151657 13.9 35.671279625611106 139.7452206151657 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67127476337405 139.74522769019455 7.95 35.67134716086023 139.74525124991683 7.95 35.67134716086023 139.74525124991683 13.9 35.67127476337405 139.74522769019455 13.9 35.67127476337405 139.74522769019455 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67134716086023 139.74525124991683 7.95 35.67134589255515 139.74524252465977 7.95 35.67134589255515 139.74524252465977 13.9 35.67134716086023 139.74525124991683 13.9 35.67134716086023 139.74525124991683 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67134589255515 139.74524252465977 7.95 35.67134318205386 139.74523380098776 7.95 35.67134318205386 139.74523380098776 13.9 35.67134589255515 139.74524252465977 13.9 35.67134589255515 139.74524252465977 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67134318205386 139.74523380098776 7.95 35.67133912014023 139.74522596251282 7.95 35.67133912014023 139.74522596251282 13.9 35.67134318205386 139.74523380098776 13.9 35.67134318205386 139.74523380098776 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67133912014023 139.74522596251282 7.95 35.67133397730687 139.74521911940187 7.95 35.67133397730687 139.74521911940187 13.9 35.67133912014023 139.74522596251282 13.9 35.67133912014023 139.74522596251282 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67133397730687 139.74521911940187 7.95 35.671327934070995 139.74521360284834 7.95 35.671327934070995 139.74521360284834 13.9 35.67133397730687 139.74521911940187 13.9 35.67133397730687 139.74521911940187 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671327934070995 139.74521360284834 7.95 35.67132108073162 139.74520963368056 7.95 35.67132108073162 139.74520963368056 13.9 35.671327934070995 139.74521360284834 13.9 35.671327934070995 139.74521360284834 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67132108073162 139.74520963368056 7.95 35.6713144991782 139.74520754210081 7.95 35.6713144991782 139.74520754210081 13.9 35.67132108073162 139.74520963368056 13.9 35.67132108073162 139.74520963368056 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6713144991782 139.74520754210081 7.95 35.6713070172226 139.74520677707764 7.95 35.6713070172226 139.74520677707764 13.9 35.6713144991782 139.74520754210081 13.9 35.6713144991782 139.74520754210081 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6713070172226 139.74520677707764 7.95 35.67129944642333 139.7452077795741 7.95 35.67129944642333 139.7452077795741 13.9 35.6713070172226 139.74520677707764 13.9 35.6713070172226 139.74520677707764 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67129944642333 139.7452077795741 7.95 35.67129223738557 139.74521043863055 7.95 35.67129223738557 139.74521043863055 13.9 35.67129944642333 139.7452077795741 13.9 35.67129944642333 139.7452077795741 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67129223738557 139.74521043863055 7.95 35.671285570464505 139.74521486451226 7.95 35.671285570464505 139.74521486451226 13.9 35.67129223738557 139.74521043863055 13.9 35.67129223738557 139.74521043863055 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671285570464505 139.74521486451226 13.9 35.671279625611106 139.7452206151657 13.9 35.67127476337405 139.74522769019455 13.9 35.67134716086023 139.74525124991683 13.9 35.67134589255515 139.74524252465977 13.9 35.67134318205386 139.74523380098776 13.9 35.67133912014023 139.74522596251282 13.9 35.67133397730687 139.74521911940187 13.9 35.671327934070995 139.74521360284834 13.9 35.67132108073162 139.74520963368056 13.9 35.6713144991782 139.74520754210081 13.9 35.6713070172226 139.74520677707764 13.9 35.67129944642333 139.7452077795741 13.9 35.67129223738557 139.74521043863055 13.9 35.671285570464505 139.74521486451226 13.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b1f9edc1-c276-493e-b665-c6da9fe11b8b"/>
							<gml:surfaceMember xlink:href="#poly-5c5ae1c2-6db1-4c0a-a399-1fb09dca9f07"/>
							<gml:surfaceMember xlink:href="#poly-9724e6a4-a5ca-4a1a-919a-de4ad8d6ce39"/>
							<gml:surfaceMember xlink:href="#poly-6ed69530-c783-428a-9759-490f791228cd"/>
							<gml:surfaceMember xlink:href="#poly-dd557b38-9dde-494c-b446-95849c770f04"/>
							<gml:surfaceMember xlink:href="#poly-0c2244f8-d22a-47f3-943e-03883e5f01b3"/>
							<gml:surfaceMember xlink:href="#poly-c4a53b1a-f5cd-47d6-826d-f6b77e3b83cd"/>
							<gml:surfaceMember xlink:href="#poly-76f36515-4caa-4da2-b66a-13efbcc22342"/>
							<gml:surfaceMember xlink:href="#poly-63166332-e9f0-471f-a21d-28e41d5ef30e"/>
							<gml:surfaceMember xlink:href="#poly-d80ec326-9add-4d2e-91bd-382ab778e35a"/>
							<gml:surfaceMember xlink:href="#poly-1dcb9956-88e9-4ea0-8677-41876db555c0"/>
							<gml:surfaceMember xlink:href="#poly-37e8fbb9-28a2-4412-b01e-f5d42ff86690"/>
							<gml:surfaceMember xlink:href="#poly-55eb6206-9955-479e-bc28-579c1a8544cb"/>
							<gml:surfaceMember xlink:href="#poly-8ddc3b9a-8832-4f52-95d2-0422d78f455a"/>
							<gml:surfaceMember xlink:href="#poly-3d4e0b3c-b14e-4950-819c-03547fcd1756"/>
							<gml:surfaceMember xlink:href="#poly-eefb6318-436d-42bd-b255-8e65f86161be"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b1f9edc1-c276-493e-b665-c6da9fe11b8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1f9edc1-c276-493e-b665-c6da9fe11b8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1f9edc1-c276-493e-b665-c6da9fe11b8b">
											<gml:posList>35.671285570464505 139.74521486451226 7.95 35.67129223738555 139.74521043863055 7.95 35.671299446423305 139.74520777957406 7.95 35.671307017222595 139.7452067770776 7.95 35.67131449917817 139.74520754210081 7.95 35.67132108073162 139.74520963368056 7.95 35.67132793407097 139.74521360284834 7.95 35.67133397730688 139.74521911940187 7.95 35.671339120140225 139.74522596251282 7.95 35.671343182053874 139.74523380098776 7.95 35.67134589255515 139.74524252465977 7.95 35.6713471608602 139.74525124991683 7.95 35.67127476337402 139.74522769019455 7.95 35.67127962561109 139.7452206151657 7.95 35.671285570464505 139.74521486451226 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c5ae1c2-6db1-4c0a-a399-1fb09dca9f07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c5ae1c2-6db1-4c0a-a399-1fb09dca9f07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c5ae1c2-6db1-4c0a-a399-1fb09dca9f07">
											<gml:posList>35.671339120140225 139.74522596251282 15 35.67133397730688 139.74521911940187 15 35.67132793407097 139.74521360284834 15 35.67132108073162 139.74520963368056 15 35.67131449917817 139.74520754210081 15 35.671307017222595 139.7452067770776 15 35.671299446423305 139.74520777957406 15 35.67129223738555 139.74521043863055 15 35.671285570464505 139.74521486451226 15 35.67127962561109 139.7452206151657 15 35.67127476337402 139.74522769019455 15 35.6713471608602 139.74525124991683 15 35.67134589255515 139.74524252465977 15 35.671343182053874 139.74523380098776 15 35.671339120140225 139.74522596251282 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9724e6a4-a5ca-4a1a-919a-de4ad8d6ce39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9724e6a4-a5ca-4a1a-919a-de4ad8d6ce39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9724e6a4-a5ca-4a1a-919a-de4ad8d6ce39">
											<gml:posList>35.67131449917817 139.74520754210081 7.95 35.671307017222595 139.7452067770776 7.95 35.671307017222595 139.7452067770776 15 35.67131449917817 139.74520754210081 15 35.67131449917817 139.74520754210081 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ed69530-c783-428a-9759-490f791228cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ed69530-c783-428a-9759-490f791228cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ed69530-c783-428a-9759-490f791228cd">
											<gml:posList>35.671307017222595 139.7452067770776 7.95 35.671299446423305 139.74520777957406 7.95 35.671299446423305 139.74520777957406 15 35.671307017222595 139.7452067770776 15 35.671307017222595 139.7452067770776 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd557b38-9dde-494c-b446-95849c770f04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd557b38-9dde-494c-b446-95849c770f04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd557b38-9dde-494c-b446-95849c770f04">
											<gml:posList>35.67132108073162 139.74520963368056 7.95 35.67131449917817 139.74520754210081 7.95 35.67131449917817 139.74520754210081 15 35.67132108073162 139.74520963368056 15 35.67132108073162 139.74520963368056 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c2244f8-d22a-47f3-943e-03883e5f01b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c2244f8-d22a-47f3-943e-03883e5f01b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c2244f8-d22a-47f3-943e-03883e5f01b3">
											<gml:posList>35.671299446423305 139.74520777957406 7.95 35.67129223738555 139.74521043863055 7.95 35.67129223738555 139.74521043863055 15 35.671299446423305 139.74520777957406 15 35.671299446423305 139.74520777957406 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4a53b1a-f5cd-47d6-826d-f6b77e3b83cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4a53b1a-f5cd-47d6-826d-f6b77e3b83cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4a53b1a-f5cd-47d6-826d-f6b77e3b83cd">
											<gml:posList>35.67132793407097 139.74521360284834 7.95 35.67132108073162 139.74520963368056 7.95 35.67132108073162 139.74520963368056 15 35.67132793407097 139.74521360284834 15 35.67132793407097 139.74521360284834 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76f36515-4caa-4da2-b66a-13efbcc22342">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76f36515-4caa-4da2-b66a-13efbcc22342">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76f36515-4caa-4da2-b66a-13efbcc22342">
											<gml:posList>35.67129223738555 139.74521043863055 7.95 35.671285570464505 139.74521486451226 7.95 35.671285570464505 139.74521486451226 15 35.67129223738555 139.74521043863055 15 35.67129223738555 139.74521043863055 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63166332-e9f0-471f-a21d-28e41d5ef30e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63166332-e9f0-471f-a21d-28e41d5ef30e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63166332-e9f0-471f-a21d-28e41d5ef30e">
											<gml:posList>35.67133397730688 139.74521911940187 7.95 35.67132793407097 139.74521360284834 7.95 35.67132793407097 139.74521360284834 15 35.67133397730688 139.74521911940187 15 35.67133397730688 139.74521911940187 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d80ec326-9add-4d2e-91bd-382ab778e35a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d80ec326-9add-4d2e-91bd-382ab778e35a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d80ec326-9add-4d2e-91bd-382ab778e35a">
											<gml:posList>35.671285570464505 139.74521486451226 7.95 35.67127962561109 139.7452206151657 7.95 35.67127962561109 139.7452206151657 15 35.671285570464505 139.74521486451226 15 35.671285570464505 139.74521486451226 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1dcb9956-88e9-4ea0-8677-41876db555c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1dcb9956-88e9-4ea0-8677-41876db555c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1dcb9956-88e9-4ea0-8677-41876db555c0">
											<gml:posList>35.671339120140225 139.74522596251282 7.95 35.67133397730688 139.74521911940187 7.95 35.67133397730688 139.74521911940187 15 35.671339120140225 139.74522596251282 15 35.671339120140225 139.74522596251282 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37e8fbb9-28a2-4412-b01e-f5d42ff86690">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37e8fbb9-28a2-4412-b01e-f5d42ff86690">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37e8fbb9-28a2-4412-b01e-f5d42ff86690">
											<gml:posList>35.67127962561109 139.7452206151657 7.95 35.67127476337402 139.74522769019455 7.95 35.67127476337402 139.74522769019455 15 35.67127962561109 139.7452206151657 15 35.67127962561109 139.7452206151657 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55eb6206-9955-479e-bc28-579c1a8544cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55eb6206-9955-479e-bc28-579c1a8544cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55eb6206-9955-479e-bc28-579c1a8544cb">
											<gml:posList>35.671343182053874 139.74523380098776 7.95 35.671339120140225 139.74522596251282 7.95 35.671339120140225 139.74522596251282 15 35.671343182053874 139.74523380098776 15 35.671343182053874 139.74523380098776 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ddc3b9a-8832-4f52-95d2-0422d78f455a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ddc3b9a-8832-4f52-95d2-0422d78f455a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ddc3b9a-8832-4f52-95d2-0422d78f455a">
											<gml:posList>35.67134589255515 139.74524252465977 7.95 35.671343182053874 139.74523380098776 7.95 35.671343182053874 139.74523380098776 15 35.67134589255515 139.74524252465977 15 35.67134589255515 139.74524252465977 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d4e0b3c-b14e-4950-819c-03547fcd1756">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d4e0b3c-b14e-4950-819c-03547fcd1756">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d4e0b3c-b14e-4950-819c-03547fcd1756">
											<gml:posList>35.67127476337402 139.74522769019455 7.95 35.6713471608602 139.74525124991683 7.95 35.6713471608602 139.74525124991683 15 35.67127476337402 139.74522769019455 15 35.67127476337402 139.74522769019455 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eefb6318-436d-42bd-b255-8e65f86161be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eefb6318-436d-42bd-b255-8e65f86161be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eefb6318-436d-42bd-b255-8e65f86161be">
											<gml:posList>35.6713471608602 139.74525124991683 7.95 35.67134589255515 139.74524252465977 7.95 35.67134589255515 139.74524252465977 15 35.6713471608602 139.74525124991683 15 35.6713471608602 139.74525124991683 7.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-67</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>