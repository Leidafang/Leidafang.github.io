<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f9ab3ce6-7812-4138-9dc8-23eed6b57c11">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">32.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>16</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67273858242856 139.73894541331626 0 35.67269385476228 139.7388859580598 0 35.672649321353795 139.73893629451902 0 35.67269404898695 139.73899573872407 0 35.67273858242856 139.73894541331626 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67273858242856 139.73894541331626 9.13 35.67269404898695 139.73899573872407 9.13 35.672649321353795 139.73893629451902 9.13 35.67269385476228 139.7388859580598 9.13 35.67273858242856 139.73894541331626 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67273858242856 139.73894541331626 9.13 35.67269385476228 139.7388859580598 9.13 35.67269385476228 139.7388859580598 41.47 35.67273858242856 139.73894541331626 41.47 35.67273858242856 139.73894541331626 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67269385476228 139.7388859580598 9.13 35.672649321353795 139.73893629451902 9.13 35.672649321353795 139.73893629451902 41.47 35.67269385476228 139.7388859580598 41.47 35.67269385476228 139.7388859580598 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672649321353795 139.73893629451902 9.13 35.67269404898695 139.73899573872407 9.13 35.67269404898695 139.73899573872407 41.47 35.672649321353795 139.73893629451902 41.47 35.672649321353795 139.73893629451902 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67269404898695 139.73899573872407 9.13 35.67273858242856 139.73894541331626 9.13 35.67273858242856 139.73894541331626 41.47 35.67269404898695 139.73899573872407 41.47 35.67269404898695 139.73899573872407 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67273858242856 139.73894541331626 41.47 35.67269385476228 139.7388859580598 41.47 35.672649321353795 139.73893629451902 41.47 35.67269404898695 139.73899573872407 41.47 35.67273858242856 139.73894541331626 41.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-96a6a0d7-d4dc-437a-a0c6-aaa0dbbaf3f3"/>
							<gml:surfaceMember xlink:href="#poly-740baad1-c010-4459-adc3-bf46ec9191be"/>
							<gml:surfaceMember xlink:href="#poly-9b27cc13-04b6-4637-a080-9bd9074a11be"/>
							<gml:surfaceMember xlink:href="#poly-43bb23c0-da20-469a-8edd-6c41b7f0e491"/>
							<gml:surfaceMember xlink:href="#poly-f6b8392b-75ac-4f1f-b92a-1a3dbdb0befa"/>
							<gml:surfaceMember xlink:href="#poly-3b4cba49-3a34-43cb-968b-3f52d03de3cf"/>
							<gml:surfaceMember xlink:href="#poly-96013ea8-d1eb-420f-a8f7-d83d64bae3b0"/>
							<gml:surfaceMember xlink:href="#poly-cc8487e4-d007-40c1-9a3c-3614934d2043"/>
							<gml:surfaceMember xlink:href="#poly-c7980a32-84d8-4e83-8a58-7bcdc2247d61"/>
							<gml:surfaceMember xlink:href="#poly-62a3d93f-c3c3-4430-ad50-b32e13e76964"/>
							<gml:surfaceMember xlink:href="#poly-64fd2ab2-d92f-4e16-a3fa-578922736a2a"/>
							<gml:surfaceMember xlink:href="#poly-d15ef147-a62c-4758-bea9-590b5026ecca"/>
							<gml:surfaceMember xlink:href="#poly-d804b6aa-309d-49bb-8b97-03d7afe9f3e2"/>
							<gml:surfaceMember xlink:href="#poly-ed0b58e8-3fbb-43ad-ac0a-4ada923d3354"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f9ab3ce6-7812-4138-9dc8-23eed6b57c11_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afc0017c-95ab-4d50-ab58-d90f17aec7d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afc0017c-95ab-4d50-ab58-d90f17aec7d2_0">
											<gml:posList>35.67272431981436 139.73893021896438 9.13 35.67269463399705 139.73889112694036 9.1 35.67272431981436 139.73893021896438 9.1 35.67272431981436 139.73893021896438 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0594696-3ca4-46de-bec1-8c1d9663c146">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0594696-3ca4-46de-bec1-8c1d9663c146_0">
											<gml:posList>35.67272431981436 139.73893021896438 9.13 35.67269463399705 139.73889112694036 9.13 35.67269463399705 139.73889112694036 9.1 35.67272431981436 139.73893021896438 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e938af0-c124-402e-a9c7-e3312b2f8f56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e938af0-c124-402e-a9c7-e3312b2f8f56_0">
											<gml:posList>35.67269463399705 139.73889112694036 42.998 35.67272431981436 139.73893021896438 41.915 35.67272431981436 139.73893021896438 42.998 35.67269463399705 139.73889112694036 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b3b82aa-6576-40f7-b5e8-e0a6f39f4d14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b3b82aa-6576-40f7-b5e8-e0a6f39f4d14_0">
											<gml:posList>35.67269463399705 139.73889112694036 42.998 35.67269463399705 139.73889112694036 41.915 35.67272431981436 139.73893021896438 41.915 35.67269463399705 139.73889112694036 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e445fd2b-58d2-45b1-ac5f-cea20905c298">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e445fd2b-58d2-45b1-ac5f-cea20905c298_0">
											<gml:posList>35.67267472245894 139.73891384006237 9.13 35.67267306387403 139.73891376468967 9.13 35.672704355779814 139.73895496471755 9.13 35.67267472245894 139.73891384006237 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba12a06f-47ff-4a25-bdba-62ef82792d40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba12a06f-47ff-4a25-bdba-62ef82792d40_0">
											<gml:posList>35.672704355779814 139.73895496471755 9.13 35.672725978399235 139.73893029433745 9.13 35.67270441728269 139.7389529320745 9.13 35.672704355779814 139.73895496471755 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51ccabf3-3331-42b0-8c9d-d8015a89035e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51ccabf3-3331-42b0-8c9d-d8015a89035e_0">
											<gml:posList>35.67269468648512 139.73888909430815 9.13 35.67267306387403 139.73891376468967 9.13 35.67267472245894 139.73891384006237 9.13 35.67269468648512 139.73888909430815 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68f26ba4-9c0a-44df-95ca-3eaea574403f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68f26ba4-9c0a-44df-95ca-3eaea574403f_0">
											<gml:posList>35.672725978399235 139.73893029433745 9.13 35.67269468648512 139.73888909430815 9.13 35.67269463399705 139.73889112694036 9.13 35.672725978399235 139.73893029433745 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-894c5622-2b6c-434c-818b-e15f6a9fc4cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-894c5622-2b6c-434c-818b-e15f6a9fc4cf_0">
											<gml:posList>35.67270441728269 139.7389529320745 9.13 35.672725978399235 139.73893029433745 9.13 35.67272431981436 139.73893021896438 9.13 35.67270441728269 139.7389529320745 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3acc3606-2a49-4ddf-9c71-36790a250f65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3acc3606-2a49-4ddf-9c71-36790a250f65_0">
											<gml:posList>35.67267472245894 139.73891384006237 9.13 35.672704355779814 139.73895496471755 9.13 35.67270441728269 139.7389529320745 9.13 35.67267472245894 139.73891384006237 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a88c50a-ed92-4cf4-babe-9f2886ebfbe1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a88c50a-ed92-4cf4-babe-9f2886ebfbe1_0">
											<gml:posList>35.67269463399705 139.73889112694036 9.13 35.67269468648512 139.73888909430815 9.13 35.67267472245894 139.73891384006237 9.13 35.67269463399705 139.73889112694036 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6b34f36-9ff1-4e12-a75f-8f6ab754ad6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6b34f36-9ff1-4e12-a75f-8f6ab754ad6e_0">
											<gml:posList>35.67269463399705 139.73889112694036 9.13 35.67272431981436 139.73893021896438 9.13 35.672725978399235 139.73893029433745 9.13 35.67269463399705 139.73889112694036 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-974671a2-b93f-4465-a7d3-9a3178f83354">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-974671a2-b93f-4465-a7d3-9a3178f83354_0">
											<gml:posList>35.672722950950245 139.73893177814435 41.459 35.672723744997576 139.73893284872779 41.915 35.672723744997576 139.73893284872779 41.459 35.672722950950245 139.73893177814435 41.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4831241b-776c-409c-9a62-7c66a530c037">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4831241b-776c-409c-9a62-7c66a530c037_0">
											<gml:posList>35.672722950950245 139.73893177814435 41.459 35.672722950950245 139.73893177814435 41.915 35.672723744997576 139.73893284872779 41.915 35.672722950950245 139.73893177814435 41.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2f27cc3-5f4e-430b-84c6-e089a34bee5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2f27cc3-5f4e-430b-84c6-e089a34bee5f_0">
											<gml:posList>35.67267472245894 139.73891384006237 9.13 35.67270441728269 139.7389529320745 9.1 35.67267472245894 139.73891384006237 9.1 35.67267472245894 139.73891384006237 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77e4d0e1-a12c-4a7e-b566-2ef61d91a424">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77e4d0e1-a12c-4a7e-b566-2ef61d91a424_0">
											<gml:posList>35.67267472245894 139.73891384006237 9.13 35.67270441728269 139.7389529320745 9.13 35.67270441728269 139.7389529320745 9.1 35.67267472245894 139.73891384006237 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3705d15e-83ac-4fa1-aa20-38e4a6cbf045">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3705d15e-83ac-4fa1-aa20-38e4a6cbf045_0">
											<gml:posList>35.67267486681703 139.73891401663755 41.459 35.67267486681703 139.73891401663755 41.915 35.67270441728269 139.7389529320745 41.459 35.67267486681703 139.73891401663755 41.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89f86d56-6718-4488-9f4e-9687b5a9a4a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89f86d56-6718-4488-9f4e-9687b5a9a4a9_0">
											<gml:posList>35.67270441728269 139.7389529320745 41.459 35.67267486681703 139.73891401663755 41.915 35.67270441728269 139.7389529320745 42.998 35.67270441728269 139.7389529320745 41.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-573be5d0-919b-4367-b46b-8c148d61db4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-573be5d0-919b-4367-b46b-8c148d61db4d_0">
											<gml:posList>35.67270441728269 139.7389529320745 42.998 35.67267486681703 139.73891401663755 41.915 35.67267472245894 139.73891384006237 42.998 35.67270441728269 139.7389529320745 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-785aa803-5404-4c5b-8e17-5ecfa87480f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-785aa803-5404-4c5b-8e17-5ecfa87480f8_0">
											<gml:posList>35.67267486681703 139.73891401663755 41.915 35.67267472245894 139.73891384006237 41.915 35.67267472245894 139.73891384006237 42.998 35.67267486681703 139.73891401663755 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e79129bf-3b23-4545-8aea-a5a901230e98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e79129bf-3b23-4545-8aea-a5a901230e98_0">
											<gml:posList>35.67267486681703 139.73891401663755 41.459 35.672674002270945 139.73891500080097 41.915 35.67267486681703 139.73891401663755 41.915 35.67267486681703 139.73891401663755 41.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38f6c675-53f0-4b2b-a2fe-25f5fa41edd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38f6c675-53f0-4b2b-a2fe-25f5fa41edd0_0">
											<gml:posList>35.67267486681703 139.73891401663755 41.459 35.672674002270945 139.73891500080097 41.459 35.672674002270945 139.73891500080097 41.915 35.67267486681703 139.73891401663755 41.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7443c7c2-8af2-4df6-aef7-f649b307f8e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7443c7c2-8af2-4df6-aef7-f649b307f8e3_0">
											<gml:posList>35.67269468648512 139.73888909430815 9.1 35.67267306387403 139.73891376468967 9.13 35.67269468648512 139.73888909430815 9.13 35.67269468648512 139.73888909430815 9.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8b56c56-6b25-4b3b-a000-954828432733">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8b56c56-6b25-4b3b-a000-954828432733_0">
											<gml:posList>35.67269468648512 139.73888909430815 9.1 35.67267306387403 139.73891376468967 9.1 35.67267306387403 139.73891376468967 9.13 35.67269468648512 139.73888909430815 9.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbb21750-6385-46c4-8f49-7e734b1dbcb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbb21750-6385-46c4-8f49-7e734b1dbcb6_0">
											<gml:posList>35.67267306387403 139.73891376468967 41.915 35.67269468648512 139.73888909430815 42.998 35.67269468648512 139.73888909430815 41.915 35.67267306387403 139.73891376468967 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1ccd2db-6aab-45d8-a437-83247a211353">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1ccd2db-6aab-45d8-a437-83247a211353_0">
											<gml:posList>35.67267306387403 139.73891376468967 41.915 35.67267306387403 139.73891376468967 42.998 35.67269468648512 139.73888909430815 42.998 35.67267306387403 139.73891376468967 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9c1c0a3-80c3-4cd4-8837-8814656f5aa5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9c1c0a3-80c3-4cd4-8837-8814656f5aa5_0">
											<gml:posList>35.67269463399705 139.73889112694036 9.1 35.67267472245894 139.73891384006237 9.13 35.67267472245894 139.73891384006237 9.1 35.67269463399705 139.73889112694036 9.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40c44631-5490-46f4-8af0-567c95b14472">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40c44631-5490-46f4-8af0-567c95b14472_0">
											<gml:posList>35.67269463399705 139.73889112694036 9.1 35.67269463399705 139.73889112694036 9.13 35.67267472245894 139.73891384006237 9.13 35.67269463399705 139.73889112694036 9.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f1bb5a7-6be0-4d9c-9100-86a716fca658">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f1bb5a7-6be0-4d9c-9100-86a716fca658_0">
											<gml:posList>35.67267472245894 139.73891384006237 42.998 35.67269463399705 139.73889112694036 41.915 35.67269463399705 139.73889112694036 42.998 35.67267472245894 139.73891384006237 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-552e1083-c293-48f1-9708-77e9f8feb02f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-552e1083-c293-48f1-9708-77e9f8feb02f_0">
											<gml:posList>35.67267472245894 139.73891384006237 42.998 35.67267472245894 139.73891384006237 41.915 35.67269463399705 139.73889112694036 41.915 35.67267472245894 139.73891384006237 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ad0a6c6-0736-4b87-a013-7d87dcf6c225">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ad0a6c6-0736-4b87-a013-7d87dcf6c225_0">
											<gml:posList>35.67267306387403 139.73891376468967 9.13 35.672704355779814 139.73895496471755 9.1 35.672704355779814 139.73895496471755 9.13 35.67267306387403 139.73891376468967 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bffefe42-5d44-498e-8497-07271aa8bb07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bffefe42-5d44-498e-8497-07271aa8bb07_0">
											<gml:posList>35.67267306387403 139.73891376468967 9.13 35.67267306387403 139.73891376468967 9.1 35.672704355779814 139.73895496471755 9.1 35.67267306387403 139.73891376468967 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-742667b0-1c32-407f-bac0-e42d4c91dcd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-742667b0-1c32-407f-bac0-e42d4c91dcd0_0">
											<gml:posList>35.67267306387403 139.73891376468967 41.915 35.672674002270945 139.73891500080097 41.915 35.67267306387403 139.73891376468967 42.998 35.67267306387403 139.73891376468967 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce29f5ba-9341-45f8-9cb2-d14601993a86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce29f5ba-9341-45f8-9cb2-d14601993a86_0">
											<gml:posList>35.67267306387403 139.73891376468967 42.998 35.672674002270945 139.73891500080097 41.915 35.672704355779814 139.73895496471755 42.998 35.67267306387403 139.73891376468967 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80e9450f-dd8b-44cc-8a8c-64cefae67119">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80e9450f-dd8b-44cc-8a8c-64cefae67119_0">
											<gml:posList>35.672704355779814 139.73895496471755 42.998 35.672674002270945 139.73891500080097 41.915 35.672704355779814 139.73895496471755 41.459 35.672704355779814 139.73895496471755 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d36e7f74-5fa3-4ab0-ab56-18cd87e3d116">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d36e7f74-5fa3-4ab0-ab56-18cd87e3d116_0">
											<gml:posList>35.672674002270945 139.73891500080097 41.915 35.672674002270945 139.73891500080097 41.459 35.672704355779814 139.73895496471755 41.459 35.672674002270945 139.73891500080097 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efb30794-94c0-463b-a64f-5a8d9a4a2be2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efb30794-94c0-463b-a64f-5a8d9a4a2be2_0">
											<gml:posList>35.67267472245894 139.73891384006237 42.998 35.67267306387403 139.73891376468967 42.998 35.672704355779814 139.73895496471755 42.998 35.67267472245894 139.73891384006237 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60e3f79c-2d30-47ea-9659-db82b149af85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60e3f79c-2d30-47ea-9659-db82b149af85_0">
											<gml:posList>35.672704355779814 139.73895496471755 42.998 35.672725978399235 139.73893029433745 42.998 35.67270441728269 139.7389529320745 42.998 35.672704355779814 139.73895496471755 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-592de16e-b16f-4dad-a779-e91dc71c6e0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-592de16e-b16f-4dad-a779-e91dc71c6e0e_0">
											<gml:posList>35.67269468648512 139.73888909430815 42.998 35.67267306387403 139.73891376468967 42.998 35.67267472245894 139.73891384006237 42.998 35.67269468648512 139.73888909430815 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab9efdb1-c3af-4e56-8d49-ef8ff024d98b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab9efdb1-c3af-4e56-8d49-ef8ff024d98b_0">
											<gml:posList>35.672725978399235 139.73893029433745 42.998 35.67269468648512 139.73888909430815 42.998 35.67269463399705 139.73889112694036 42.998 35.672725978399235 139.73893029433745 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-426bd925-5aff-4361-94e7-45f3c5eefeea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-426bd925-5aff-4361-94e7-45f3c5eefeea_0">
											<gml:posList>35.67270441728269 139.7389529320745 42.998 35.672725978399235 139.73893029433745 42.998 35.67272431981436 139.73893021896438 42.998 35.67270441728269 139.7389529320745 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0a9358d-f3f3-425e-80f6-1ca945b48739">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0a9358d-f3f3-425e-80f6-1ca945b48739_0">
											<gml:posList>35.67267472245894 139.73891384006237 42.998 35.672704355779814 139.73895496471755 42.998 35.67270441728269 139.7389529320745 42.998 35.67267472245894 139.73891384006237 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-986d0544-6879-4837-ab70-6f8846243103">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-986d0544-6879-4837-ab70-6f8846243103_0">
											<gml:posList>35.67269463399705 139.73889112694036 42.998 35.67269468648512 139.73888909430815 42.998 35.67267472245894 139.73891384006237 42.998 35.67269463399705 139.73889112694036 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c7bf4a0-a5ce-4484-b6c7-b3325ca3f4dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c7bf4a0-a5ce-4484-b6c7-b3325ca3f4dd_0">
											<gml:posList>35.67269463399705 139.73889112694036 42.998 35.67272431981436 139.73893021896438 42.998 35.672725978399235 139.73893029433745 42.998 35.67269463399705 139.73889112694036 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c33c9e01-79b8-4e71-95fa-10af7d1c77cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c33c9e01-79b8-4e71-95fa-10af7d1c77cd_0">
											<gml:posList>35.672725978399235 139.73893029433745 9.13 35.67269468648512 139.73888909430815 9.1 35.67269468648512 139.73888909430815 9.13 35.672725978399235 139.73893029433745 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb9d1625-8829-423b-9f44-8578c27af608">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb9d1625-8829-423b-9f44-8578c27af608_0">
											<gml:posList>35.672725978399235 139.73893029433745 9.13 35.672725978399235 139.73893029433745 9.1 35.67269468648512 139.73888909430815 9.1 35.672725978399235 139.73893029433745 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd47c96c-a2a1-4295-8672-f34a0fe9ae37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd47c96c-a2a1-4295-8672-f34a0fe9ae37_0">
											<gml:posList>35.67269468648512 139.73888909430815 41.915 35.672725978399235 139.73893029433745 42.998 35.672725978399235 139.73893029433745 41.915 35.67269468648512 139.73888909430815 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ef13c33-cdeb-4c64-adce-8c0c411ef552">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ef13c33-cdeb-4c64-adce-8c0c411ef552_0">
											<gml:posList>35.67269468648512 139.73888909430815 41.915 35.67269468648512 139.73888909430815 42.998 35.672725978399235 139.73893029433745 42.998 35.67269468648512 139.73888909430815 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abea3776-66e8-46b5-beca-e3f25616d2cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abea3776-66e8-46b5-beca-e3f25616d2cd_0">
											<gml:posList>35.67272431981436 139.73893021896438 41.915 35.672722950950245 139.73893177814435 41.915 35.67272431981436 139.73893021896438 42.998 35.67272431981436 139.73893021896438 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d133e3c-2b2c-43d7-b4f5-a0d7bc5e3143">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d133e3c-2b2c-43d7-b4f5-a0d7bc5e3143_0">
											<gml:posList>35.67272431981436 139.73893021896438 42.998 35.672722950950245 139.73893177814435 41.915 35.67270441728269 139.7389529320745 42.998 35.67272431981436 139.73893021896438 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e0249e9-c02c-4baa-83d2-c3ed826ccc33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e0249e9-c02c-4baa-83d2-c3ed826ccc33_0">
											<gml:posList>35.67270441728269 139.7389529320745 42.998 35.672722950950245 139.73893177814435 41.915 35.67270441728269 139.7389529320745 41.459 35.67270441728269 139.7389529320745 42.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29826df8-140f-4b8e-a083-5c51526d3afd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29826df8-140f-4b8e-a083-5c51526d3afd_0">
											<gml:posList>35.672722950950245 139.73893177814435 41.915 35.672722950950245 139.73893177814435 41.459 35.67270441728269 139.7389529320745 41.459 35.672722950950245 139.73893177814435 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d19765a0-a4e2-4677-a4cd-77d196208f30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d19765a0-a4e2-4677-a4cd-77d196208f30_0">
											<gml:posList>35.67270441728269 139.7389529320745 9.13 35.67272431981436 139.73893021896438 9.1 35.67270441728269 139.7389529320745 9.1 35.67270441728269 139.7389529320745 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9dec126b-15ad-47e7-8d02-b9adc97292be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9dec126b-15ad-47e7-8d02-b9adc97292be_0">
											<gml:posList>35.67270441728269 139.7389529320745 9.13 35.67272431981436 139.73893021896438 9.13 35.67272431981436 139.73893021896438 9.1 35.67270441728269 139.7389529320745 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f3520d3-159b-4078-a7f8-916b191a34c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f3520d3-159b-4078-a7f8-916b191a34c5_0">
											<gml:posList>35.672725978399235 139.73893029433745 41.915 35.672725978399235 139.73893029433745 42.998 35.672723744997576 139.73893284872779 41.915 35.672725978399235 139.73893029433745 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c9126ae-038c-4e29-b906-c94840ed96ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c9126ae-038c-4e29-b906-c94840ed96ef_0">
											<gml:posList>35.672723744997576 139.73893284872779 41.459 35.672723744997576 139.73893284872779 41.915 35.672704355779814 139.73895496471755 41.459 35.672723744997576 139.73893284872779 41.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7b32942-a8e6-47f0-b8a9-e374ef3c9764">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7b32942-a8e6-47f0-b8a9-e374ef3c9764_0">
											<gml:posList>35.672704355779814 139.73895496471755 41.459 35.672723744997576 139.73893284872779 41.915 35.672704355779814 139.73895496471755 42.998 35.672704355779814 139.73895496471755 41.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d163b44b-0571-4d17-8bbf-e2c4963b5d09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d163b44b-0571-4d17-8bbf-e2c4963b5d09_0">
											<gml:posList>35.672723744997576 139.73893284872779 41.915 35.672725978399235 139.73893029433745 42.998 35.672704355779814 139.73895496471755 42.998 35.672723744997576 139.73893284872779 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6152ee40-513a-4e34-ab4b-b7dbe181e87f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6152ee40-513a-4e34-ab4b-b7dbe181e87f_0">
											<gml:posList>35.672704355779814 139.73895496471755 9.13 35.672725978399235 139.73893029433745 9.1 35.672725978399235 139.73893029433745 9.13 35.672704355779814 139.73895496471755 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-033f56dd-c198-4b9c-a92d-0912366acd3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-033f56dd-c198-4b9c-a92d-0912366acd3e_0">
											<gml:posList>35.672704355779814 139.73895496471755 9.13 35.672704355779814 139.73895496471755 9.1 35.672725978399235 139.73893029433745 9.1 35.672704355779814 139.73895496471755 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6be58609-9069-4c4d-971a-a9794f7ef8af">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672725978399235 139.73893029433745 41.915 35.672723744997576 139.73893284872779 41.915 35.67272431981436 139.73893021896438 41.915 35.672725978399235 139.73893029433745 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c31f3fd-4537-4158-90ce-bf3929c0a26d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672725978399235 139.73893029433745 41.915 35.67269463399705 139.73889112694036 41.915 35.67269468648512 139.73888909430815 41.915 35.672725978399235 139.73893029433745 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba096a0b-fecd-4e40-a3b0-adf0d73dd4fc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67269468648512 139.73888909430815 41.915 35.67267472245894 139.73891384006237 41.915 35.67267306387403 139.73891376468967 41.915 35.67269468648512 139.73888909430815 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25d334fd-5775-4233-afcd-29176f0d9f1b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67272431981436 139.73893021896438 41.915 35.672723744997576 139.73893284872779 41.915 35.672722950950245 139.73893177814435 41.915 35.67272431981436 139.73893021896438 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-886ad0e9-d61b-4325-9357-bced32ffa56a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67267472245894 139.73891384006237 41.915 35.672674002270945 139.73891500080097 41.915 35.67267306387403 139.73891376468967 41.915 35.67267472245894 139.73891384006237 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e67aeb6-cb7a-496d-b6f3-8c1f2756628f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67267486681703 139.73891401663755 41.915 35.672674002270945 139.73891500080097 41.915 35.67267472245894 139.73891384006237 41.915 35.67267486681703 139.73891401663755 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbf8e17f-2d4a-42bc-b54f-263033a480a8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67269463399705 139.73889112694036 41.915 35.67267472245894 139.73891384006237 41.915 35.67269468648512 139.73888909430815 41.915 35.67269463399705 139.73889112694036 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27e2b788-1de3-4324-9455-1ee18a0cfdcd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672725978399235 139.73893029433745 41.915 35.67272431981436 139.73893021896438 41.915 35.67269463399705 139.73889112694036 41.915 35.672725978399235 139.73893029433745 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7873b46c-3623-42d8-b822-73adb03c729f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67269468648512 139.73888909430815 9.1 35.672725978399235 139.73893029433745 9.1 35.67269463399705 139.73889112694036 9.1 35.67269468648512 139.73888909430815 9.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e240074-75d8-4994-b25a-5679e80a9f01">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672725978399235 139.73893029433745 9.1 35.672704355779814 139.73895496471755 9.1 35.67270441728269 139.7389529320745 9.1 35.672725978399235 139.73893029433745 9.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-732a7f22-c16a-4f36-9f2d-0ab110f7a497">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67267472245894 139.73891384006237 9.1 35.67267306387403 139.73891376468967 9.1 35.67269468648512 139.73888909430815 9.1 35.67267472245894 139.73891384006237 9.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dda9dd3-48e8-4713-9129-0c006255a99f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672704355779814 139.73895496471755 9.1 35.67267306387403 139.73891376468967 9.1 35.67267472245894 139.73891384006237 9.1 35.672704355779814 139.73895496471755 9.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bde61667-92d3-4f0d-af0b-90f3bcdb3ae4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67269463399705 139.73889112694036 9.1 35.672725978399235 139.73893029433745 9.1 35.67272431981436 139.73893021896438 9.1 35.67269463399705 139.73889112694036 9.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a4eb06e-7f3c-486b-ac60-bdb86546a9c3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67267472245894 139.73891384006237 9.1 35.67269468648512 139.73888909430815 9.1 35.67269463399705 139.73889112694036 9.1 35.67267472245894 139.73891384006237 9.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27498355-932d-4f0b-8f4f-dd7af9fc17c5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67272431981436 139.73893021896438 9.1 35.672725978399235 139.73893029433745 9.1 35.67270441728269 139.7389529320745 9.1 35.67272431981436 139.73893021896438 9.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55126d6d-0bf6-48a5-8797-a3304edd296b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672704355779814 139.73895496471755 9.1 35.67267472245894 139.73891384006237 9.1 35.67270441728269 139.7389529320745 9.1 35.672704355779814 139.73895496471755 9.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d1e38aa-a544-4d39-9d6e-f4d55730f0f3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672722950950245 139.73893177814435 41.459 35.672723744997576 139.73893284872779 41.459 35.67270441728269 139.7389529320745 41.459 35.672722950950245 139.73893177814435 41.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-baff1020-adff-4a81-bb13-0c33ff5e6eae">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67267486681703 139.73891401663755 41.459 35.67270441728269 139.7389529320745 41.459 35.672674002270945 139.73891500080097 41.459 35.67267486681703 139.73891401663755 41.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24df72d7-034d-4c7c-8e51-a69ba688612a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672674002270945 139.73891500080097 41.459 35.67270441728269 139.7389529320745 41.459 35.672704355779814 139.73895496471755 41.459 35.672674002270945 139.73891500080097 41.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cf662ac-f535-4c4d-9079-a7cce5f9dc91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67270441728269 139.7389529320745 41.459 35.672723744997576 139.73893284872779 41.459 35.672704355779814 139.73895496471755 41.459 35.67270441728269 139.7389529320745 41.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-96a6a0d7-d4dc-437a-a0c6-aaa0dbbaf3f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96a6a0d7-d4dc-437a-a0c6-aaa0dbbaf3f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96a6a0d7-d4dc-437a-a0c6-aaa0dbbaf3f3">
											<gml:posList>35.672738582428536 139.73894541331623 9.13 35.67269404898691 139.73899573872407 9.13 35.672649321353795 139.73893629451902 9.13 35.672693854762244 139.73888595805977 9.13 35.672738582428536 139.73894541331623 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-740baad1-c010-4459-adc3-bf46ec9191be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-740baad1-c010-4459-adc3-bf46ec9191be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-740baad1-c010-4459-adc3-bf46ec9191be">
											<gml:posList>35.672649321353795 139.73893629451902 41.915 35.672654919098406 139.73893657513884 41.915 35.67269362577749 139.73889280720792 41.915 35.672693854762244 139.73888595805977 41.915 35.672649321353795 139.73893629451902 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b27cc13-04b6-4637-a080-9bd9074a11be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b27cc13-04b6-4637-a080-9bd9074a11be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b27cc13-04b6-4637-a080-9bd9074a11be">
											<gml:posList>35.67269404898691 139.73899573872407 41.915 35.67269426895515 139.7389888785402 41.915 35.672654919098406 139.73893657513884 41.915 35.672649321353795 139.73893629451902 41.915 35.67269404898691 139.73899573872407 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43bb23c0-da20-469a-8edd-6c41b7f0e491">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43bb23c0-da20-469a-8edd-6c41b7f0e491">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43bb23c0-da20-469a-8edd-6c41b7f0e491">
											<gml:posList>35.67273298467538 139.73894512164892 41.459 35.67269362577749 139.73889280720792 41.459 35.672654919098406 139.73893657513884 41.459 35.67269426895515 139.7389888785402 41.459 35.67273298467538 139.73894512164892 41.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6b8392b-75ac-4f1f-b92a-1a3dbdb0befa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6b8392b-75ac-4f1f-b92a-1a3dbdb0befa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6b8392b-75ac-4f1f-b92a-1a3dbdb0befa">
											<gml:posList>35.672693854762244 139.73888595805977 41.915 35.67269362577749 139.73889280720792 41.915 35.67273298467538 139.73894512164892 41.915 35.672738582428536 139.73894541331623 41.915 35.672693854762244 139.73888595805977 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b4cba49-3a34-43cb-968b-3f52d03de3cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b4cba49-3a34-43cb-968b-3f52d03de3cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b4cba49-3a34-43cb-968b-3f52d03de3cf">
											<gml:posList>35.672738582428536 139.73894541331623 41.915 35.67273298467538 139.73894512164892 41.915 35.67269426895515 139.7389888785402 41.915 35.67269404898691 139.73899573872407 41.915 35.672738582428536 139.73894541331623 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96013ea8-d1eb-420f-a8f7-d83d64bae3b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96013ea8-d1eb-420f-a8f7-d83d64bae3b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96013ea8-d1eb-420f-a8f7-d83d64bae3b0">
											<gml:posList>35.67269362577749 139.73889280720792 41.915 35.67269362577749 139.73889280720792 41.459 35.67273298467538 139.73894512164892 41.459 35.67273298467538 139.73894512164892 41.915 35.67269362577749 139.73889280720792 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc8487e4-d007-40c1-9a3c-3614934d2043">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc8487e4-d007-40c1-9a3c-3614934d2043">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc8487e4-d007-40c1-9a3c-3614934d2043">
											<gml:posList>35.67269426895515 139.7389888785402 41.915 35.67269426895515 139.7389888785402 41.459 35.672654919098406 139.73893657513884 41.459 35.672654919098406 139.73893657513884 41.915 35.67269426895515 139.7389888785402 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7980a32-84d8-4e83-8a58-7bcdc2247d61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7980a32-84d8-4e83-8a58-7bcdc2247d61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7980a32-84d8-4e83-8a58-7bcdc2247d61">
											<gml:posList>35.672693854762244 139.73888595805977 9.13 35.672649321353795 139.73893629451902 9.13 35.672649321353795 139.73893629451902 41.915 35.672693854762244 139.73888595805977 41.915 35.672693854762244 139.73888595805977 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62a3d93f-c3c3-4430-ad50-b32e13e76964">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62a3d93f-c3c3-4430-ad50-b32e13e76964">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62a3d93f-c3c3-4430-ad50-b32e13e76964">
											<gml:posList>35.672654919098406 139.73893657513884 41.915 35.672654919098406 139.73893657513884 41.459 35.67269362577749 139.73889280720792 41.459 35.67269362577749 139.73889280720792 41.915 35.672654919098406 139.73893657513884 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64fd2ab2-d92f-4e16-a3fa-578922736a2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64fd2ab2-d92f-4e16-a3fa-578922736a2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64fd2ab2-d92f-4e16-a3fa-578922736a2a">
											<gml:posList>35.672738582428536 139.73894541331623 9.13 35.672693854762244 139.73888595805977 9.13 35.672693854762244 139.73888595805977 41.915 35.672738582428536 139.73894541331623 41.915 35.672738582428536 139.73894541331623 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d15ef147-a62c-4758-bea9-590b5026ecca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d15ef147-a62c-4758-bea9-590b5026ecca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d15ef147-a62c-4758-bea9-590b5026ecca">
											<gml:posList>35.672649321353795 139.73893629451902 9.13 35.67269404898691 139.73899573872407 9.13 35.67269404898691 139.73899573872407 41.915 35.672649321353795 139.73893629451902 41.915 35.672649321353795 139.73893629451902 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d804b6aa-309d-49bb-8b97-03d7afe9f3e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d804b6aa-309d-49bb-8b97-03d7afe9f3e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d804b6aa-309d-49bb-8b97-03d7afe9f3e2">
											<gml:posList>35.67273298467538 139.73894512164892 41.915 35.67273298467538 139.73894512164892 41.459 35.67269426895515 139.7389888785402 41.459 35.67269426895515 139.7389888785402 41.915 35.67273298467538 139.73894512164892 41.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed0b58e8-3fbb-43ad-ac0a-4ada923d3354">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed0b58e8-3fbb-43ad-ac0a-4ada923d3354">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed0b58e8-3fbb-43ad-ac0a-4ada923d3354">
											<gml:posList>35.67269404898691 139.73899573872407 9.13 35.672738582428536 139.73894541331623 9.13 35.672738582428536 139.73894541331623 41.915 35.67269404898691 139.73899573872407 41.915 35.67269404898691 139.73899573872407 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7723</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">922.78442</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>