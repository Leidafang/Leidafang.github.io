<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f9c8716b-159a-4ba9-ba3a-cd6f5c9e70be">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">25.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668174894217834 139.74213822877033 0 35.66802044477078 139.74255693488823 0 35.66811278387544 139.7426079730874 0 35.66813428272593 139.74254962614495 0 35.66815000013837 139.74255821314676 0 35.66817393324333 139.74248867385327 0 35.66817882059973 139.74249120888607 0 35.668188048455775 139.7424643898925 0 35.66818316110716 139.74246186590696 0 35.66822881465535 139.7423292294714 0 35.66823370201506 139.74233176449624 0 35.668241796594245 139.74230823845008 0 35.66823690924236 139.74230571447237 0 35.66825747844567 139.74224593243898 0 35.66824960637931 139.74224186542003 0 35.66826771247864 139.74219092293566 0 35.668174894217834 139.74213822877033 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668174894217834 139.74213822877033 27.29 35.66826771247864 139.74219092293566 27.29 35.66824960637931 139.74224186542003 27.29 35.66825747844567 139.74224593243898 27.29 35.66823690924236 139.74230571447237 27.29 35.668241796594245 139.74230823845008 27.29 35.66823370201506 139.74233176449624 27.29 35.66822881465535 139.7423292294714 27.29 35.66818316110716 139.74246186590696 27.29 35.668188048455775 139.7424643898925 27.29 35.66817882059973 139.74249120888607 27.29 35.66817393324333 139.74248867385327 27.29 35.66815000013837 139.74255821314676 27.29 35.66813428272593 139.74254962614495 27.29 35.66811278387544 139.7426079730874 27.29 35.66802044477078 139.74255693488823 27.29 35.668174894217834 139.74213822877033 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668174894217834 139.74213822877033 27.29 35.66802044477078 139.74255693488823 27.29 35.66802044477078 139.74255693488823 52.65 35.668174894217834 139.74213822877033 52.65 35.668174894217834 139.74213822877033 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66802044477078 139.74255693488823 27.29 35.66811278387544 139.7426079730874 27.29 35.66811278387544 139.7426079730874 52.65 35.66802044477078 139.74255693488823 52.65 35.66802044477078 139.74255693488823 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66811278387544 139.7426079730874 27.29 35.66813428272593 139.74254962614495 27.29 35.66813428272593 139.74254962614495 52.65 35.66811278387544 139.7426079730874 52.65 35.66811278387544 139.7426079730874 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66813428272593 139.74254962614495 27.29 35.66815000013837 139.74255821314676 27.29 35.66815000013837 139.74255821314676 52.65 35.66813428272593 139.74254962614495 52.65 35.66813428272593 139.74254962614495 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66815000013837 139.74255821314676 27.29 35.66817393324333 139.74248867385327 27.29 35.66817393324333 139.74248867385327 52.65 35.66815000013837 139.74255821314676 52.65 35.66815000013837 139.74255821314676 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66817393324333 139.74248867385327 27.29 35.66817882059973 139.74249120888607 27.29 35.66817882059973 139.74249120888607 52.65 35.66817393324333 139.74248867385327 52.65 35.66817393324333 139.74248867385327 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66817882059973 139.74249120888607 27.29 35.668188048455775 139.7424643898925 27.29 35.668188048455775 139.7424643898925 52.65 35.66817882059973 139.74249120888607 52.65 35.66817882059973 139.74249120888607 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668188048455775 139.7424643898925 27.29 35.66818316110716 139.74246186590696 27.29 35.66818316110716 139.74246186590696 52.65 35.668188048455775 139.7424643898925 52.65 35.668188048455775 139.7424643898925 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66818316110716 139.74246186590696 27.29 35.66822881465535 139.7423292294714 27.29 35.66822881465535 139.7423292294714 52.65 35.66818316110716 139.74246186590696 52.65 35.66818316110716 139.74246186590696 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66822881465535 139.7423292294714 27.29 35.66823370201506 139.74233176449624 27.29 35.66823370201506 139.74233176449624 52.65 35.66822881465535 139.7423292294714 52.65 35.66822881465535 139.7423292294714 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66823370201506 139.74233176449624 27.29 35.668241796594245 139.74230823845008 27.29 35.668241796594245 139.74230823845008 52.65 35.66823370201506 139.74233176449624 52.65 35.66823370201506 139.74233176449624 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668241796594245 139.74230823845008 27.29 35.66823690924236 139.74230571447237 27.29 35.66823690924236 139.74230571447237 52.65 35.668241796594245 139.74230823845008 52.65 35.668241796594245 139.74230823845008 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66823690924236 139.74230571447237 27.29 35.66825747844567 139.74224593243898 27.29 35.66825747844567 139.74224593243898 52.65 35.66823690924236 139.74230571447237 52.65 35.66823690924236 139.74230571447237 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66825747844567 139.74224593243898 27.29 35.66824960637931 139.74224186542003 27.29 35.66824960637931 139.74224186542003 52.65 35.66825747844567 139.74224593243898 52.65 35.66825747844567 139.74224593243898 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66824960637931 139.74224186542003 27.29 35.66826771247864 139.74219092293566 27.29 35.66826771247864 139.74219092293566 52.65 35.66824960637931 139.74224186542003 52.65 35.66824960637931 139.74224186542003 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66826771247864 139.74219092293566 27.29 35.668174894217834 139.74213822877033 27.29 35.668174894217834 139.74213822877033 52.65 35.66826771247864 139.74219092293566 52.65 35.66826771247864 139.74219092293566 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668174894217834 139.74213822877033 52.65 35.66802044477078 139.74255693488823 52.65 35.66811278387544 139.7426079730874 52.65 35.66813428272593 139.74254962614495 52.65 35.66815000013837 139.74255821314676 52.65 35.66817393324333 139.74248867385327 52.65 35.66817882059973 139.74249120888607 52.65 35.668188048455775 139.7424643898925 52.65 35.66818316110716 139.74246186590696 52.65 35.66822881465535 139.7423292294714 52.65 35.66823370201506 139.74233176449624 52.65 35.668241796594245 139.74230823845008 52.65 35.66823690924236 139.74230571447237 52.65 35.66825747844567 139.74224593243898 52.65 35.66824960637931 139.74224186542003 52.65 35.66826771247864 139.74219092293566 52.65 35.668174894217834 139.74213822877033 52.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4fd9e58e-88fc-40a6-8bd8-85fe027ff68c"/>
							<gml:surfaceMember xlink:href="#poly-a4908794-e0ea-42bd-af77-3dc839d1705f"/>
							<gml:surfaceMember xlink:href="#poly-388fe347-4f92-4c29-9613-9c8e4bce1a68"/>
							<gml:surfaceMember xlink:href="#poly-2b98139f-6591-48f2-a2e4-42f1f41e7a65"/>
							<gml:surfaceMember xlink:href="#poly-a00b55c5-ef62-4406-850b-fa2eac7af3f7"/>
							<gml:surfaceMember xlink:href="#poly-6631e8f5-db84-404a-934a-be937d20ccc7"/>
							<gml:surfaceMember xlink:href="#poly-b43c038d-018a-4620-a080-5ccb0fe416db"/>
							<gml:surfaceMember xlink:href="#poly-f9125cca-fee6-459d-bf7c-16b0aae13fa4"/>
							<gml:surfaceMember xlink:href="#poly-92314f5e-0037-4ff2-80cc-f96167729b1b"/>
							<gml:surfaceMember xlink:href="#poly-729c3155-ed66-4669-a83a-3ea04be00340"/>
							<gml:surfaceMember xlink:href="#poly-2dbf88d6-5bf5-41d1-9f74-d45178e8f746"/>
							<gml:surfaceMember xlink:href="#poly-28bcb914-0974-4cdb-8662-89c5c6899ce5"/>
							<gml:surfaceMember xlink:href="#poly-b3350aec-43fb-4124-9c3e-67004b8a2449"/>
							<gml:surfaceMember xlink:href="#poly-aab57c35-f23b-41d1-9d1c-82448b6390de"/>
							<gml:surfaceMember xlink:href="#poly-8dde7e0d-4f1c-493d-bd40-09430132086e"/>
							<gml:surfaceMember xlink:href="#poly-ecde8032-ea06-4ab7-ac22-fe37d14327c9"/>
							<gml:surfaceMember xlink:href="#poly-8fc5ca93-6474-481c-8d77-b266ef8b8de1"/>
							<gml:surfaceMember xlink:href="#poly-cf559ada-2e70-446c-a9ba-631e066a6010"/>
							<gml:surfaceMember xlink:href="#poly-e7382643-bad3-41e7-8308-089acc38d07b"/>
							<gml:surfaceMember xlink:href="#poly-7094c283-2c65-4e29-98c6-db2ba16c5f23"/>
							<gml:surfaceMember xlink:href="#poly-1d458f96-85c1-4e78-ad1b-e605d370efe2"/>
							<gml:surfaceMember xlink:href="#poly-9cb4df2b-abf0-4cd2-ba1a-436666a699bc"/>
							<gml:surfaceMember xlink:href="#poly-682fc201-258a-4bfa-99cf-0fd2d8bc5a7a"/>
							<gml:surfaceMember xlink:href="#poly-7a3feb0f-868f-4e1b-a6bf-c4ea08f2794d"/>
							<gml:surfaceMember xlink:href="#poly-fc5119da-cc76-43a1-9638-9d85061f6a0d"/>
							<gml:surfaceMember xlink:href="#poly-7f7380c2-11e9-4d5e-839c-9fa7a7bcbf43"/>
							<gml:surfaceMember xlink:href="#poly-d6a12b94-a523-4267-8fee-2ea35f6067cb"/>
							<gml:surfaceMember xlink:href="#poly-ac996bbb-027d-496f-a024-ea25411a92e6"/>
							<gml:surfaceMember xlink:href="#poly-9e5e473c-4222-4318-94e9-7fdc3beeb6e9"/>
							<gml:surfaceMember xlink:href="#poly-b055b373-9572-4c8f-ad88-b20662d61daa"/>
							<gml:surfaceMember xlink:href="#poly-c206a9af-9ded-49c0-8c08-d432b0bb9a43"/>
							<gml:surfaceMember xlink:href="#poly-c4b1d85c-5a2e-459d-b11a-732ac4bc4fa0"/>
							<gml:surfaceMember xlink:href="#poly-18c5e613-3ee7-4496-b656-d6e8b45d6082"/>
							<gml:surfaceMember xlink:href="#poly-8c494f92-b96f-4540-83da-b85dff950480"/>
							<gml:surfaceMember xlink:href="#poly-a364881f-ca69-43d9-a48e-4c9cfc83f77c"/>
							<gml:surfaceMember xlink:href="#poly-7a642b98-5e00-4d8c-8baf-f0e06623d7be"/>
							<gml:surfaceMember xlink:href="#poly-ea11b95f-4cca-444b-8484-b6f8bb75bfa0"/>
							<gml:surfaceMember xlink:href="#poly-e88c5983-f483-4ee0-a48c-fc4adb88df9e"/>
							<gml:surfaceMember xlink:href="#poly-8f3cc54f-8572-45ef-b4ef-a52f37b45641"/>
							<gml:surfaceMember xlink:href="#poly-d8a38a5a-67d7-417e-be20-0abc63ab0acc"/>
							<gml:surfaceMember xlink:href="#poly-9a51e5d9-c21c-4ff3-801d-60ac69f204cc"/>
							<gml:surfaceMember xlink:href="#poly-763e80ac-8c59-43b6-aadc-bd41ad30c6be"/>
							<gml:surfaceMember xlink:href="#poly-d728d0d7-5553-4c0a-9994-a966443cea69"/>
							<gml:surfaceMember xlink:href="#poly-b29d1aea-b331-486c-9102-2b11c3b7dac0"/>
							<gml:surfaceMember xlink:href="#poly-22786cb8-5de8-47e4-be40-6fd178a4bbd0"/>
							<gml:surfaceMember xlink:href="#poly-84a2b15a-d6e2-4299-a7a4-09522c7b829b"/>
							<gml:surfaceMember xlink:href="#poly-a2f602ea-3020-44a3-90b7-7f69479d7c5d"/>
							<gml:surfaceMember xlink:href="#poly-b7414b6c-5167-4a4e-ba06-9c887051f339"/>
							<gml:surfaceMember xlink:href="#poly-7f43d11a-c95f-4dd3-8dbf-7e41658ce458"/>
							<gml:surfaceMember xlink:href="#poly-391dce04-e137-432c-9391-aa02e2d7770c"/>
							<gml:surfaceMember xlink:href="#poly-a7b80eb0-f1a0-4636-88d0-80ba0a1de860"/>
							<gml:surfaceMember xlink:href="#poly-694e9c3b-7839-406d-8c49-230f58097df2"/>
							<gml:surfaceMember xlink:href="#poly-59d26a1d-b397-4d13-af05-73b2f2db986c"/>
							<gml:surfaceMember xlink:href="#poly-ab92efa1-ddac-4c60-8376-d62b59091c1b"/>
							<gml:surfaceMember xlink:href="#poly-55bca707-d132-491d-b8f0-afb45a893c21"/>
							<gml:surfaceMember xlink:href="#poly-8ca2ced9-da25-4773-9be6-dcba8f70108c"/>
							<gml:surfaceMember xlink:href="#poly-bd0464d5-6cda-44d0-97a0-77c636ab0f15"/>
							<gml:surfaceMember xlink:href="#poly-dd5ea1a6-0720-4d33-8f5f-1539e183e42f"/>
							<gml:surfaceMember xlink:href="#poly-57a60350-b5b8-4c2f-a983-d0b662b50e33"/>
							<gml:surfaceMember xlink:href="#poly-b1ed7b98-1ac0-458a-9bb1-51a2696428f7"/>
							<gml:surfaceMember xlink:href="#poly-46e487d0-1bb8-471c-84fc-60211ad2848b"/>
							<gml:surfaceMember xlink:href="#poly-dbc38a4f-2f4c-4c79-92e7-14eadbd2f168"/>
							<gml:surfaceMember xlink:href="#poly-172e3cae-f899-4a49-9107-c6641356a95d"/>
							<gml:surfaceMember xlink:href="#poly-9d9bd150-2e6d-41bd-bd1c-6745585bd324"/>
							<gml:surfaceMember xlink:href="#poly-70d3cd72-3a9b-4425-8ae4-b7244822bf4a"/>
							<gml:surfaceMember xlink:href="#poly-dba1cdd8-5a82-4d87-8a2a-3b673e476ec4"/>
							<gml:surfaceMember xlink:href="#poly-a883c18c-a67e-44ce-8698-b807b83c31d9"/>
							<gml:surfaceMember xlink:href="#poly-9d6d5361-2b61-4858-a033-e71fd12c4e55"/>
							<gml:surfaceMember xlink:href="#poly-28b49079-ee94-4c98-8f0e-8b6a2412d733"/>
							<gml:surfaceMember xlink:href="#poly-cc7334fe-08a2-4f0e-bc60-8b6ce4bf1c99"/>
							<gml:surfaceMember xlink:href="#poly-f383c640-f27b-4856-a538-d2958820bb3c"/>
							<gml:surfaceMember xlink:href="#poly-b1af6e78-55c0-4f5f-acb2-abfa5bd0b1f3"/>
							<gml:surfaceMember xlink:href="#poly-99cca6c6-cc0f-4769-9489-3bcf964a5531"/>
							<gml:surfaceMember xlink:href="#poly-219edce2-8e5e-4f5c-9d33-f3b7c6a6033d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f9c8716b-159a-4ba9-ba3a-cd6f5c9e70be_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-176a9334-0582-431b-8a18-f5e0c505ac35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66809749773403 139.74246604998754 52.3 35.66807311428056 139.74245238065177 52.3 35.66815192412476 139.7422413136328 52.3 35.66817051833307 139.74225174198276 52.3 35.66817034743153 139.74225221715295 52.3 35.66816972672093 139.74225385265936 52.3 35.66815308030494 139.74224451564567 52.3 35.66807614151716 139.74245055464021 52.3 35.66809858620271 139.74246314367045 52.3 35.66809749773403 139.74246604998754 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f403f4be-7fcc-442d-ab46-c31a6a0f4a3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f403f4be-7fcc-442d-ab46-c31a6a0f4a3e_0">
											<gml:posList>35.66815192412476 139.7422413136328 53.942 35.66817051833307 139.74225174198276 53.942 35.66817051833307 139.74225174198276 52.3 35.66815192412476 139.7422413136328 52.3 35.66815192412476 139.7422413136328 53.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c8213c0-bd0f-4434-8b74-1f87f074eb58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c8213c0-bd0f-4434-8b74-1f87f074eb58_0">
											<gml:posList>35.66815308030494 139.74224451564567 53.942 35.66815308030494 139.74224451564567 52.3 35.66816972672093 139.74225385265936 52.3 35.66816972672093 139.74225385265936 53.942 35.66815308030494 139.74224451564567 53.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-755d26ae-8b27-4dce-9276-11293ffcf44f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-755d26ae-8b27-4dce-9276-11293ffcf44f_0">
											<gml:posList>35.66817051833307 139.74225174198276 52.3 35.66817051833307 139.74225174198276 53.942 35.66817034743153 139.74225221715295 53.942 35.66817034743153 139.74225221715295 52.3 35.66817051833307 139.74225174198276 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de443d30-302b-4b49-a531-ef75e0505f34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de443d30-302b-4b49-a531-ef75e0505f34_0">
											<gml:posList>35.66817034743153 139.74225221715295 53.942 35.66816972672093 139.74225385265936 53.942 35.66816972672093 139.74225385265936 52.3 35.66817034743153 139.74225221715295 52.3 35.66817034743153 139.74225221715295 53.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e8f23f2-e961-43e7-937a-fad40befd198">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e8f23f2-e961-43e7-937a-fad40befd198_0">
											<gml:posList>35.66809749773403 139.74246604998754 53.942 35.66807311428056 139.74245238065177 53.942 35.66807311428056 139.74245238065177 52.3 35.66809749773403 139.74246604998754 52.3 35.66809749773403 139.74246604998754 53.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f01c08ca-a332-4848-b122-7303e70d3a7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f01c08ca-a332-4848-b122-7303e70d3a7b_0">
											<gml:posList>35.66807614151716 139.74245055464021 52.3 35.66807614151716 139.74245055464021 53.942 35.66809858620271 139.74246314367045 53.942 35.66809858620271 139.74246314367045 52.3 35.66807614151716 139.74245055464021 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddc94185-73d7-444c-90e9-640a5d4f5026">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddc94185-73d7-444c-90e9-640a5d4f5026_0">
											<gml:posList>35.66809749773403 139.74246604998754 52.3 35.66809858620271 139.74246314367045 52.3 35.66809858620271 139.74246314367045 53.942 35.66809749773403 139.74246604998754 53.942 35.66809749773403 139.74246604998754 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2697df9-deb7-4d6a-a8c0-1a0250cfc76a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2697df9-deb7-4d6a-a8c0-1a0250cfc76a_0">
											<gml:posList>35.66807311428056 139.74245238065177 52.3 35.66807311428056 139.74245238065177 53.942 35.66815192412476 139.7422413136328 53.942 35.66815192412476 139.7422413136328 52.3 35.66807311428056 139.74245238065177 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e854c12-bfc5-4fed-8a01-b6c06b94db5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e854c12-bfc5-4fed-8a01-b6c06b94db5c_0">
											<gml:posList>35.66815308030494 139.74224451564567 52.3 35.66815308030494 139.74224451564567 53.942 35.66807614151716 139.74245055464021 53.942 35.66807614151716 139.74245055464021 52.3 35.66815308030494 139.74224451564567 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-682bbc45-39b7-4ac0-bbb6-eb4e5ada6794">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-682bbc45-39b7-4ac0-bbb6-eb4e5ada6794_0">
											<gml:posList>35.66807614151716 139.74245055464021 53.942 35.66815308030494 139.74224451564567 53.942 35.66816972672093 139.74225385265936 53.942 35.66817034743153 139.74225221715295 53.942 35.66817051833307 139.74225174198276 53.942 35.66815192412476 139.7422413136328 53.942 35.66807311428056 139.74245238065177 53.942 35.66809749773403 139.74246604998754 53.942 35.66809858620271 139.74246314367045 53.942 35.66807614151716 139.74245055464021 53.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4fd9e58e-88fc-40a6-8bd8-85fe027ff68c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fd9e58e-88fc-40a6-8bd8-85fe027ff68c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fd9e58e-88fc-40a6-8bd8-85fe027ff68c">
											<gml:posList>35.66802044477076 139.7425569348882 27.29 35.66817489421781 139.74213822877033 27.29 35.66826771247864 139.74219092293566 27.29 35.66824960637929 139.74224186542003 27.29 35.66825747844567 139.74224593243898 27.29 35.66823690924237 139.74230571447237 27.29 35.6682417965942 139.74230823845008 27.29 35.66823370201504 139.74233176449624 27.29 35.66822881465533 139.74232922947144 27.29 35.66818316110713 139.74246186590693 27.29 35.66818804845575 139.74246438989246 27.29 35.66817882059971 139.7424912088861 27.29 35.66817393324331 139.74248867385325 27.29 35.66815000013835 139.74255821314676 27.29 35.66813428272594 139.74254962614495 27.29 35.66811278387545 139.7426079730874 27.29 35.66802044477076 139.7425569348882 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4908794-e0ea-42bd-af77-3dc839d1705f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4908794-e0ea-42bd-af77-3dc839d1705f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4908794-e0ea-42bd-af77-3dc839d1705f">
											<gml:posList>35.66802364352793 139.74255545111166 53.3 35.66802044477076 139.7425569348882 53.3 35.66811278387545 139.7426079730874 53.3 35.66811157308158 139.74260405314612 53.3 35.66802364352793 139.74255545111166 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-388fe347-4f92-4c29-9613-9c8e4bce1a68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-388fe347-4f92-4c29-9613-9c8e4bce1a68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-388fe347-4f92-4c29-9613-9c8e4bce1a68">
											<gml:posList>35.66817609601309 139.74214214871785 53.3 35.66817489421781 139.74213822877033 53.3 35.66802044477076 139.7425569348882 53.3 35.66802364352793 139.74255545111166 53.3 35.66817609601309 139.74214214871785 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b98139f-6591-48f2-a2e4-42f1f41e7a65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b98139f-6591-48f2-a2e4-42f1f41e7a65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b98139f-6591-48f2-a2e4-42f1f41e7a65">
											<gml:posList>35.66811157308158 139.74260405314612 53.3 35.66811278387545 139.7426079730874 53.3 35.66813428272594 139.74254962614495 53.3 35.66813308991599 139.74254565095342 53.3 35.66811157308158 139.74260405314612 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a00b55c5-ef62-4406-850b-fa2eac7af3f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a00b55c5-ef62-4406-850b-fa2eac7af3f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a00b55c5-ef62-4406-850b-fa2eac7af3f7">
											<gml:posList>35.66811540811219 139.74241839956477 56.595 35.66809601343646 139.742469984026 56.595 35.668151444431174 139.74250122544223 56.595 35.66811540811219 139.74241839956477 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6631e8f5-db84-404a-934a-be937d20ccc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6631e8f5-db84-404a-934a-be937d20ccc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6631e8f5-db84-404a-934a-be937d20ccc7">
											<gml:posList>35.66811540811219 139.74241839956477 56.595 35.668151444431174 139.74250122544223 56.595 35.668124858533965 139.7424237350889 56.595 35.66811540811219 139.74241839956477 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b43c038d-018a-4620-a080-5ccb0fe416db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b43c038d-018a-4620-a080-5ccb0fe416db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b43c038d-018a-4620-a080-5ccb0fe416db">
											<gml:posList>35.668151444431174 139.74250122544223 56.595 35.66814583641814 139.74236792924833 56.595 35.668124858533965 139.7424237350889 56.595 35.668151444431174 139.74250122544223 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9125cca-fee6-459d-bf7c-16b0aae13fa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9125cca-fee6-459d-bf7c-16b0aae13fa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9125cca-fee6-459d-bf7c-16b0aae13fa4">
											<gml:posList>35.668163924023425 139.74248340522703 52.3 35.66815927997079 139.74248078155188 52.3 35.66815154367383 139.7425013468353 52.3 35.66809601343646 139.742469984026 52.3 35.66811540811219 139.74241839956477 52.3 35.668124858533965 139.7424237350889 52.3 35.66814583641814 139.74236792924833 52.3 35.66813016386056 139.7423590771306 52.3 35.66817444043855 139.74224132119133 52.3 35.66819601951869 139.7422535024611 52.3 35.66819500301452 139.74225620987556 52.3 35.66823376960627 139.74227809208082 52.3 35.668246452728184 139.74224339334592 52.3 35.668264558811465 139.742192428772 52.3 35.66817609601309 139.74214214871785 52.3 35.66802364352793 139.74255545111166 52.3 35.66811157308158 139.74260405314612 52.3 35.66813308991599 139.74254565095342 52.3 35.66814088116521 139.74255013783397 52.3 35.668163924023425 139.74248340522703 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92314f5e-0037-4ff2-80cc-f96167729b1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92314f5e-0037-4ff2-80cc-f96167729b1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92314f5e-0037-4ff2-80cc-f96167729b1b">
											<gml:posList>35.66817444043855 139.74224132119133 56.595 35.66813016386056 139.7423590771306 56.595 35.66814583641814 139.74236792924833 56.595 35.66817444043855 139.74224132119133 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-729c3155-ed66-4669-a83a-3ea04be00340">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-729c3155-ed66-4669-a83a-3ea04be00340">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-729c3155-ed66-4669-a83a-3ea04be00340">
											<gml:posList>35.66814088116521 139.74255013783397 53.3 35.66813308991599 139.74254565095342 53.3 35.66813428272594 139.74254962614495 53.3 35.66815000013835 139.74255821314676 53.3 35.66817393324331 139.74248867385325 53.3 35.668163924023425 139.74248340522703 53.3 35.66814088116521 139.74255013783397 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2dbf88d6-5bf5-41d1-9f74-d45178e8f746">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dbf88d6-5bf5-41d1-9f74-d45178e8f746">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dbf88d6-5bf5-41d1-9f74-d45178e8f746">
											<gml:posList>35.668151444431174 139.74250122544223 56.595 35.66815927997079 139.74248078155188 56.595 35.668155465539314 139.74247863191295 56.595 35.668151444431174 139.74250122544223 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28bcb914-0974-4cdb-8662-89c5c6899ce5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28bcb914-0974-4cdb-8662-89c5c6899ce5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28bcb914-0974-4cdb-8662-89c5c6899ce5">
											<gml:posList>35.668155465539314 139.74247863191295 56.595 35.66819500301452 139.74225620987556 56.595 35.66814583641814 139.74236792924833 56.595 35.668151444431174 139.74250122544223 56.595 35.668155465539314 139.74247863191295 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b3350aec-43fb-4124-9c3e-67004b8a2449">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3350aec-43fb-4124-9c3e-67004b8a2449">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3350aec-43fb-4124-9c3e-67004b8a2449">
											<gml:posList>35.66819500301452 139.74225620987556 56.595 35.66817444043855 139.74224132119133 56.595 35.66814583641814 139.74236792924833 56.595 35.66819500301452 139.74225620987556 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aab57c35-f23b-41d1-9d1c-82448b6390de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aab57c35-f23b-41d1-9d1c-82448b6390de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aab57c35-f23b-41d1-9d1c-82448b6390de">
											<gml:posList>35.66816911196098 139.7424542490737 56.947 35.66815927997079 139.74248078155188 56.947 35.66817882059971 139.7424912088861 56.947 35.66818804846408 139.74246440093842 56.947 35.66816911196098 139.7424542490737 56.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8dde7e0d-4f1c-493d-bd40-09430132086e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dde7e0d-4f1c-493d-bd40-09430132086e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dde7e0d-4f1c-493d-bd40-09430132086e">
											<gml:posList>35.66816911196098 139.7424542490737 56.595 35.66819500301452 139.74225620987556 56.595 35.668155465539314 139.74247863191295 56.595 35.66815927997079 139.74248078155188 56.595 35.66816911196098 139.7424542490737 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ecde8032-ea06-4ab7-ac22-fe37d14327c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecde8032-ea06-4ab7-ac22-fe37d14327c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecde8032-ea06-4ab7-ac22-fe37d14327c9">
											<gml:posList>35.66819500301452 139.74225620987556 56.595 35.66819601951869 139.7422535024611 56.595 35.66817444043855 139.74224132119133 56.595 35.66819500301452 139.74225620987556 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fc5ca93-6474-481c-8d77-b266ef8b8de1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fc5ca93-6474-481c-8d77-b266ef8b8de1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fc5ca93-6474-481c-8d77-b266ef8b8de1">
											<gml:posList>35.66816911196098 139.7424542490737 53.3 35.66818316110713 139.74246186590693 53.3 35.66822881465533 139.74232922947144 53.3 35.66821827348516 139.74232378472993 53.3 35.66816911196098 139.7424542490737 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf559ada-2e70-446c-a9ba-631e066a6010">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf559ada-2e70-446c-a9ba-631e066a6010">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf559ada-2e70-446c-a9ba-631e066a6010">
											<gml:posList>35.66819500301452 139.74225620987556 56.595 35.66816911196098 139.7424542490737 56.595 35.66821827348516 139.74232378472993 56.594 35.66822700828789 139.7423005893395 56.594 35.66823518537105 139.74227889682848 56.595 35.66819500301452 139.74225620987556 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e7382643-bad3-41e7-8308-089acc38d07b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7382643-bad3-41e7-8308-089acc38d07b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7382643-bad3-41e7-8308-089acc38d07b">
											<gml:posList>35.668264558811465 139.742192428772 53.3 35.66826771247864 139.74219092293566 53.3 35.66817489421781 139.74213822877033 53.3 35.66817609601309 139.74214214871785 53.3 35.668264558811465 139.742192428772 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7094c283-2c65-4e29-98c6-db2ba16c5f23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7094c283-2c65-4e29-98c6-db2ba16c5f23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7094c283-2c65-4e29-98c6-db2ba16c5f23">
											<gml:posList>35.66821827348516 139.74232378472993 56.947 35.66823370200669 139.7423317534503 56.947 35.6682417965942 139.74230823845008 56.947 35.66822700829624 139.74230060038545 56.947 35.66821827348516 139.74232378472993 56.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d458f96-85c1-4e78-ad1b-e605d370efe2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d458f96-85c1-4e78-ad1b-e605d370efe2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d458f96-85c1-4e78-ad1b-e605d370efe2">
											<gml:posList>35.66823518537105 139.74227889682848 53.3 35.66822700828789 139.7423005893395 53.3 35.66823690924237 139.74230571447237 53.3 35.66823518537105 139.74227889682848 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9cb4df2b-abf0-4cd2-ba1a-436666a699bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cb4df2b-abf0-4cd2-ba1a-436666a699bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cb4df2b-abf0-4cd2-ba1a-436666a699bc">
											<gml:posList>35.668246452728184 139.74224339334592 53.3 35.66823376960627 139.74227809208082 53.3 35.66824960637929 139.74224186542003 53.3 35.668246452728184 139.74224339334592 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-682fc201-258a-4bfa-99cf-0fd2d8bc5a7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-682fc201-258a-4bfa-99cf-0fd2d8bc5a7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-682fc201-258a-4bfa-99cf-0fd2d8bc5a7a">
											<gml:posList>35.66823376960627 139.74227809208082 53.3 35.66823518537105 139.74227889682848 53.3 35.66824960637929 139.74224186542003 53.3 35.66823376960627 139.74227809208082 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a3feb0f-868f-4e1b-a6bf-c4ea08f2794d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a3feb0f-868f-4e1b-a6bf-c4ea08f2794d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a3feb0f-868f-4e1b-a6bf-c4ea08f2794d">
											<gml:posList>35.66824960637929 139.74224186542003 53.3 35.66823518537105 139.74227889682848 53.3 35.66823690924237 139.74230571447237 53.3 35.66824960637929 139.74224186542003 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc5119da-cc76-43a1-9638-9d85061f6a0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc5119da-cc76-43a1-9638-9d85061f6a0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc5119da-cc76-43a1-9638-9d85061f6a0d">
											<gml:posList>35.66824960637929 139.74224186542003 53.3 35.66823690924237 139.74230571447237 53.3 35.66825747844567 139.74224593243898 53.3 35.66824960637929 139.74224186542003 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f7380c2-11e9-4d5e-839c-9fa7a7bcbf43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f7380c2-11e9-4d5e-839c-9fa7a7bcbf43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f7380c2-11e9-4d5e-839c-9fa7a7bcbf43">
											<gml:posList>35.66824960637929 139.74224186542003 53.3 35.66826771247864 139.74219092293566 53.3 35.668264558811465 139.742192428772 53.3 35.668246452728184 139.74224339334592 53.3 35.66824960637929 139.74224186542003 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6a12b94-a523-4267-8fee-2ea35f6067cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6a12b94-a523-4267-8fee-2ea35f6067cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6a12b94-a523-4267-8fee-2ea35f6067cb">
											<gml:posList>35.66813308991599 139.74254565095342 52.3 35.66811157308158 139.74260405314612 52.3 35.66811157308158 139.74260405314612 53.3 35.66813308991599 139.74254565095342 53.3 35.66813308991599 139.74254565095342 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac996bbb-027d-496f-a024-ea25411a92e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac996bbb-027d-496f-a024-ea25411a92e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac996bbb-027d-496f-a024-ea25411a92e6">
											<gml:posList>35.66814088116521 139.74255013783397 53.3 35.668163924023425 139.74248340522703 53.3 35.668163924023425 139.74248340522703 52.3 35.66814088116521 139.74255013783397 52.3 35.66814088116521 139.74255013783397 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e5e473c-4222-4318-94e9-7fdc3beeb6e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e5e473c-4222-4318-94e9-7fdc3beeb6e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e5e473c-4222-4318-94e9-7fdc3beeb6e9">
											<gml:posList>35.66817489421781 139.74213822877033 53.3 35.66826771247864 139.74219092293566 53.3 35.66826771247864 139.74219092293566 27.29 35.66817489421781 139.74213822877033 27.29 35.66817489421781 139.74213822877033 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b055b373-9572-4c8f-ad88-b20662d61daa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b055b373-9572-4c8f-ad88-b20662d61daa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b055b373-9572-4c8f-ad88-b20662d61daa">
											<gml:posList>35.66817609601309 139.74214214871785 52.3 35.668264558811465 139.742192428772 52.3 35.668264558811465 139.742192428772 53.3 35.66817609601309 139.74214214871785 53.3 35.66817609601309 139.74214214871785 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c206a9af-9ded-49c0-8c08-d432b0bb9a43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c206a9af-9ded-49c0-8c08-d432b0bb9a43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c206a9af-9ded-49c0-8c08-d432b0bb9a43">
											<gml:posList>35.66826771247864 139.74219092293566 27.29 35.66826771247864 139.74219092293566 53.3 35.66824960637929 139.74224186542003 53.3 35.66824960637929 139.74224186542003 27.29 35.66826771247864 139.74219092293566 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4b1d85c-5a2e-459d-b11a-732ac4bc4fa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4b1d85c-5a2e-459d-b11a-732ac4bc4fa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4b1d85c-5a2e-459d-b11a-732ac4bc4fa0">
											<gml:posList>35.668246452728184 139.74224339334592 53.3 35.668264558811465 139.742192428772 53.3 35.668264558811465 139.742192428772 52.3 35.668246452728184 139.74224339334592 52.3 35.668246452728184 139.74224339334592 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18c5e613-3ee7-4496-b656-d6e8b45d6082">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18c5e613-3ee7-4496-b656-d6e8b45d6082">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18c5e613-3ee7-4496-b656-d6e8b45d6082">
											<gml:posList>35.66824960637929 139.74224186542003 27.29 35.66824960637929 139.74224186542003 53.3 35.66825747844567 139.74224593243898 53.3 35.66825747844567 139.74224593243898 27.29 35.66824960637929 139.74224186542003 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c494f92-b96f-4540-83da-b85dff950480">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c494f92-b96f-4540-83da-b85dff950480">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c494f92-b96f-4540-83da-b85dff950480">
											<gml:posList>35.66819601951869 139.7422535024611 52.3 35.66817444043855 139.74224132119133 52.3 35.66817444043855 139.74224132119133 56.595 35.66819601951869 139.7422535024611 56.595 35.66819601951869 139.7422535024611 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a364881f-ca69-43d9-a48e-4c9cfc83f77c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a364881f-ca69-43d9-a48e-4c9cfc83f77c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a364881f-ca69-43d9-a48e-4c9cfc83f77c">
											<gml:posList>35.66819500301452 139.74225620987556 56.595 35.66819500301452 139.74225620987556 52.3 35.66819601951869 139.7422535024611 52.3 35.66819601951869 139.7422535024611 56.595 35.66819500301452 139.74225620987556 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a642b98-5e00-4d8c-8baf-f0e06623d7be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a642b98-5e00-4d8c-8baf-f0e06623d7be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a642b98-5e00-4d8c-8baf-f0e06623d7be">
											<gml:posList>35.668246452728184 139.74224339334592 52.3 35.66823376960627 139.74227809208082 52.3 35.66823376960627 139.74227809208082 53.3 35.668246452728184 139.74224339334592 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea11b95f-4cca-444b-8484-b6f8bb75bfa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea11b95f-4cca-444b-8484-b6f8bb75bfa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea11b95f-4cca-444b-8484-b6f8bb75bfa0">
											<gml:posList>35.668246452728184 139.74224339334592 53.3 35.668246452728184 139.74224339334592 52.3 35.66823376960627 139.74227809208082 53.3 35.668246452728184 139.74224339334592 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e88c5983-f483-4ee0-a48c-fc4adb88df9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e88c5983-f483-4ee0-a48c-fc4adb88df9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e88c5983-f483-4ee0-a48c-fc4adb88df9e">
											<gml:posList>35.66823376960627 139.74227809208082 53.3 35.66823376960627 139.74227809208082 52.3 35.66819500301452 139.74225620987556 52.3 35.66819500301452 139.74225620987556 56.595 35.66823376960627 139.74227809208082 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f3cc54f-8572-45ef-b4ef-a52f37b45641">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f3cc54f-8572-45ef-b4ef-a52f37b45641">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f3cc54f-8572-45ef-b4ef-a52f37b45641">
											<gml:posList>35.66823518537105 139.74227889682848 53.3 35.66823376960627 139.74227809208082 53.3 35.66819500301452 139.74225620987556 56.595 35.66823518537105 139.74227889682848 56.595 35.66823518537105 139.74227889682848 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8a38a5a-67d7-417e-be20-0abc63ab0acc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8a38a5a-67d7-417e-be20-0abc63ab0acc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8a38a5a-67d7-417e-be20-0abc63ab0acc">
											<gml:posList>35.66823690924237 139.74230571447237 53.3 35.66823690924237 139.74230571447237 27.29 35.66825747844567 139.74224593243898 27.29 35.66825747844567 139.74224593243898 53.3 35.66823690924237 139.74230571447237 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a51e5d9-c21c-4ff3-801d-60ac69f204cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a51e5d9-c21c-4ff3-801d-60ac69f204cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a51e5d9-c21c-4ff3-801d-60ac69f204cc">
											<gml:posList>35.66822700828789 139.7423005893395 56.594 35.66822700828789 139.7423005893395 53.3 35.66823518537105 139.74227889682848 53.3 35.66822700828789 139.7423005893395 56.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-763e80ac-8c59-43b6-aadc-bd41ad30c6be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-763e80ac-8c59-43b6-aadc-bd41ad30c6be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-763e80ac-8c59-43b6-aadc-bd41ad30c6be">
											<gml:posList>35.66822700828789 139.7423005893395 56.594 35.66823518537105 139.74227889682848 53.3 35.66823518537105 139.74227889682848 56.595 35.66822700828789 139.7423005893395 56.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d728d0d7-5553-4c0a-9994-a966443cea69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d728d0d7-5553-4c0a-9994-a966443cea69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d728d0d7-5553-4c0a-9994-a966443cea69">
											<gml:posList>35.66817444043855 139.74224132119133 56.595 35.66817444043855 139.74224132119133 52.3 35.66813016386056 139.7423590771306 52.3 35.66813016386056 139.7423590771306 56.595 35.66817444043855 139.74224132119133 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b29d1aea-b331-486c-9102-2b11c3b7dac0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b29d1aea-b331-486c-9102-2b11c3b7dac0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b29d1aea-b331-486c-9102-2b11c3b7dac0">
											<gml:posList>35.6682417965942 139.74230823845008 27.29 35.66823690924237 139.74230571447237 27.29 35.66823690924237 139.74230571447237 53.3 35.66822700828789 139.7423005893395 53.3 35.66822700828789 139.7423005893395 56.594 35.66822700829624 139.74230060038545 56.947 35.6682417965942 139.74230823845008 56.947 35.6682417965942 139.74230823845008 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22786cb8-5de8-47e4-be40-6fd178a4bbd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22786cb8-5de8-47e4-be40-6fd178a4bbd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22786cb8-5de8-47e4-be40-6fd178a4bbd0">
											<gml:posList>35.66821827348516 139.74232378472993 56.594 35.66821827348516 139.74232378472993 56.947 35.66822700829624 139.74230060038545 56.947 35.66822700828789 139.7423005893395 56.594 35.66821827348516 139.74232378472993 56.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84a2b15a-d6e2-4299-a7a4-09522c7b829b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84a2b15a-d6e2-4299-a7a4-09522c7b829b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84a2b15a-d6e2-4299-a7a4-09522c7b829b">
											<gml:posList>35.6682417965942 139.74230823845008 56.947 35.66823370200669 139.7423317534503 56.947 35.66823370201504 139.74233176449624 27.29 35.6682417965942 139.74230823845008 27.29 35.6682417965942 139.74230823845008 56.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2f602ea-3020-44a3-90b7-7f69479d7c5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2f602ea-3020-44a3-90b7-7f69479d7c5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2f602ea-3020-44a3-90b7-7f69479d7c5d">
											<gml:posList>35.66822881465533 139.74232922947144 53.3 35.66822881465533 139.74232922947144 27.29 35.66823370201504 139.74233176449624 27.29 35.66823370200669 139.7423317534503 56.947 35.66821827348516 139.74232378472993 56.947 35.66821827348516 139.74232378472993 56.594 35.66821827348516 139.74232378472993 53.3 35.66822881465533 139.74232922947144 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7414b6c-5167-4a4e-ba06-9c887051f339">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7414b6c-5167-4a4e-ba06-9c887051f339">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7414b6c-5167-4a4e-ba06-9c887051f339">
											<gml:posList>35.66802044477076 139.7425569348882 53.3 35.66817489421781 139.74213822877033 53.3 35.66817489421781 139.74213822877033 27.29 35.66802044477076 139.7425569348882 27.29 35.66802044477076 139.7425569348882 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f43d11a-c95f-4dd3-8dbf-7e41658ce458">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f43d11a-c95f-4dd3-8dbf-7e41658ce458">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f43d11a-c95f-4dd3-8dbf-7e41658ce458">
											<gml:posList>35.66802364352793 139.74255545111166 52.3 35.66817609601309 139.74214214871785 52.3 35.66817609601309 139.74214214871785 53.3 35.66802364352793 139.74255545111166 53.3 35.66802364352793 139.74255545111166 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-391dce04-e137-432c-9391-aa02e2d7770c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-391dce04-e137-432c-9391-aa02e2d7770c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-391dce04-e137-432c-9391-aa02e2d7770c">
											<gml:posList>35.66814583641814 139.74236792924833 56.595 35.66813016386056 139.7423590771306 56.595 35.66813016386056 139.7423590771306 52.3 35.66814583641814 139.74236792924833 52.3 35.66814583641814 139.74236792924833 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7b80eb0-f1a0-4636-88d0-80ba0a1de860">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7b80eb0-f1a0-4636-88d0-80ba0a1de860">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7b80eb0-f1a0-4636-88d0-80ba0a1de860">
											<gml:posList>35.66821827348516 139.74232378472993 56.594 35.66816911196098 139.7424542490737 56.595 35.66816911196098 139.7424542490737 53.3 35.66821827348516 139.74232378472993 53.3 35.66821827348516 139.74232378472993 56.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-694e9c3b-7839-406d-8c49-230f58097df2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-694e9c3b-7839-406d-8c49-230f58097df2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-694e9c3b-7839-406d-8c49-230f58097df2">
											<gml:posList>35.66822881465533 139.74232922947144 27.29 35.66822881465533 139.74232922947144 53.3 35.66818316110713 139.74246186590693 53.3 35.66818316110713 139.74246186590693 27.29 35.66822881465533 139.74232922947144 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59d26a1d-b397-4d13-af05-73b2f2db986c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59d26a1d-b397-4d13-af05-73b2f2db986c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59d26a1d-b397-4d13-af05-73b2f2db986c">
											<gml:posList>35.668124858533965 139.7424237350889 52.3 35.668124858533965 139.7424237350889 56.595 35.66814583641814 139.74236792924833 56.595 35.66814583641814 139.74236792924833 52.3 35.668124858533965 139.7424237350889 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab92efa1-ddac-4c60-8376-d62b59091c1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab92efa1-ddac-4c60-8376-d62b59091c1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab92efa1-ddac-4c60-8376-d62b59091c1b">
											<gml:posList>35.66811540811219 139.74241839956477 56.595 35.668124858533965 139.7424237350889 56.595 35.668124858533965 139.7424237350889 52.3 35.66811540811219 139.74241839956477 52.3 35.66811540811219 139.74241839956477 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55bca707-d132-491d-b8f0-afb45a893c21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55bca707-d132-491d-b8f0-afb45a893c21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55bca707-d132-491d-b8f0-afb45a893c21">
											<gml:posList>35.66809601343646 139.742469984026 56.595 35.66811540811219 139.74241839956477 56.595 35.66811540811219 139.74241839956477 52.3 35.66809601343646 139.742469984026 52.3 35.66809601343646 139.742469984026 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ca2ced9-da25-4773-9be6-dcba8f70108c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ca2ced9-da25-4773-9be6-dcba8f70108c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ca2ced9-da25-4773-9be6-dcba8f70108c">
											<gml:posList>35.66816911196098 139.7424542490737 56.947 35.66818316110713 139.74246186590693 53.3 35.66816911196098 139.7424542490737 53.3 35.66816911196098 139.7424542490737 56.595 35.66816911196098 139.7424542490737 56.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd0464d5-6cda-44d0-97a0-77c636ab0f15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd0464d5-6cda-44d0-97a0-77c636ab0f15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd0464d5-6cda-44d0-97a0-77c636ab0f15">
											<gml:posList>35.66818316110713 139.74246186590693 53.3 35.66816911196098 139.7424542490737 56.947 35.66818804846408 139.74246440093842 56.947 35.66818316110713 139.74246186590693 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd5ea1a6-0720-4d33-8f5f-1539e183e42f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd5ea1a6-0720-4d33-8f5f-1539e183e42f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd5ea1a6-0720-4d33-8f5f-1539e183e42f">
											<gml:posList>35.66818804845575 139.74246438989246 27.29 35.66818316110713 139.74246186590693 27.29 35.66818316110713 139.74246186590693 53.3 35.66818804845575 139.74246438989246 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57a60350-b5b8-4c2f-a983-d0b662b50e33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57a60350-b5b8-4c2f-a983-d0b662b50e33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57a60350-b5b8-4c2f-a983-d0b662b50e33">
											<gml:posList>35.66818804845575 139.74246438989246 27.29 35.66818316110713 139.74246186590693 53.3 35.66818804846408 139.74246440093842 56.947 35.66818804845575 139.74246438989246 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1ed7b98-1ac0-458a-9bb1-51a2696428f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1ed7b98-1ac0-458a-9bb1-51a2696428f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1ed7b98-1ac0-458a-9bb1-51a2696428f7">
											<gml:posList>35.66816911196098 139.7424542490737 56.947 35.66816911196098 139.7424542490737 56.595 35.66815927997079 139.74248078155188 56.595 35.66815927997079 139.74248078155188 56.947 35.66816911196098 139.7424542490737 56.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46e487d0-1bb8-471c-84fc-60211ad2848b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46e487d0-1bb8-471c-84fc-60211ad2848b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46e487d0-1bb8-471c-84fc-60211ad2848b">
											<gml:posList>35.66817882059971 139.7424912088861 56.947 35.66817882059971 139.7424912088861 27.29 35.66818804845575 139.74246438989246 27.29 35.66818804846408 139.74246440093842 56.947 35.66817882059971 139.7424912088861 56.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbc38a4f-2f4c-4c79-92e7-14eadbd2f168">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbc38a4f-2f4c-4c79-92e7-14eadbd2f168">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbc38a4f-2f4c-4c79-92e7-14eadbd2f168">
											<gml:posList>35.66815927997079 139.74248078155188 52.3 35.668163924023425 139.74248340522703 52.3 35.668163924023425 139.74248340522703 53.3 35.66815927997079 139.74248078155188 56.595 35.66815927997079 139.74248078155188 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-172e3cae-f899-4a49-9107-c6641356a95d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-172e3cae-f899-4a49-9107-c6641356a95d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-172e3cae-f899-4a49-9107-c6641356a95d">
											<gml:posList>35.66815927997079 139.74248078155188 56.947 35.66815927997079 139.74248078155188 56.595 35.668163924023425 139.74248340522703 53.3 35.66815927997079 139.74248078155188 56.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d9bd150-2e6d-41bd-bd1c-6745585bd324">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d9bd150-2e6d-41bd-bd1c-6745585bd324">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d9bd150-2e6d-41bd-bd1c-6745585bd324">
											<gml:posList>35.668163924023425 139.74248340522703 53.3 35.66817393324331 139.74248867385325 53.3 35.66815927997079 139.74248078155188 56.947 35.668163924023425 139.74248340522703 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70d3cd72-3a9b-4425-8ae4-b7244822bf4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70d3cd72-3a9b-4425-8ae4-b7244822bf4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70d3cd72-3a9b-4425-8ae4-b7244822bf4a">
											<gml:posList>35.668151444431174 139.74250122544223 56.595 35.66809601343646 139.742469984026 56.595 35.66809601343646 139.742469984026 52.3 35.66815154367383 139.7425013468353 52.3 35.668151444431174 139.74250122544223 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dba1cdd8-5a82-4d87-8a2a-3b673e476ec4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dba1cdd8-5a82-4d87-8a2a-3b673e476ec4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dba1cdd8-5a82-4d87-8a2a-3b673e476ec4">
											<gml:posList>35.66815927997079 139.74248078155188 56.947 35.66817393324331 139.74248867385325 53.3 35.66817882059971 139.7424912088861 56.947 35.66815927997079 139.74248078155188 56.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a883c18c-a67e-44ce-8698-b807b83c31d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a883c18c-a67e-44ce-8698-b807b83c31d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a883c18c-a67e-44ce-8698-b807b83c31d9">
											<gml:posList>35.66817393324331 139.74248867385325 53.3 35.66817393324331 139.74248867385325 27.29 35.66817882059971 139.7424912088861 27.29 35.66817882059971 139.7424912088861 56.947 35.66817393324331 139.74248867385325 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d6d5361-2b61-4858-a033-e71fd12c4e55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d6d5361-2b61-4858-a033-e71fd12c4e55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d6d5361-2b61-4858-a033-e71fd12c4e55">
											<gml:posList>35.66815927997079 139.74248078155188 56.595 35.668151444431174 139.74250122544223 56.595 35.66815154367383 139.7425013468353 52.3 35.66815927997079 139.74248078155188 52.3 35.66815927997079 139.74248078155188 56.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28b49079-ee94-4c98-8f0e-8b6a2412d733">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28b49079-ee94-4c98-8f0e-8b6a2412d733">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28b49079-ee94-4c98-8f0e-8b6a2412d733">
											<gml:posList>35.66815000013835 139.74255821314676 53.3 35.66815000013835 139.74255821314676 27.29 35.66817393324331 139.74248867385325 27.29 35.66817393324331 139.74248867385325 53.3 35.66815000013835 139.74255821314676 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc7334fe-08a2-4f0e-bc60-8b6ce4bf1c99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc7334fe-08a2-4f0e-bc60-8b6ce4bf1c99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc7334fe-08a2-4f0e-bc60-8b6ce4bf1c99">
											<gml:posList>35.66814088116521 139.74255013783397 52.3 35.66813308991599 139.74254565095342 52.3 35.66813308991599 139.74254565095342 53.3 35.66814088116521 139.74255013783397 53.3 35.66814088116521 139.74255013783397 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f383c640-f27b-4856-a538-d2958820bb3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f383c640-f27b-4856-a538-d2958820bb3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f383c640-f27b-4856-a538-d2958820bb3c">
											<gml:posList>35.66813428272594 139.74254962614495 27.29 35.66815000013835 139.74255821314676 27.29 35.66815000013835 139.74255821314676 53.3 35.66813428272594 139.74254962614495 53.3 35.66813428272594 139.74254962614495 27.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1af6e78-55c0-4f5f-acb2-abfa5bd0b1f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1af6e78-55c0-4f5f-acb2-abfa5bd0b1f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1af6e78-55c0-4f5f-acb2-abfa5bd0b1f3">
											<gml:posList>35.66813428272594 139.74254962614495 53.3 35.66811278387545 139.7426079730874 53.3 35.66811278387545 139.7426079730874 27.29 35.66813428272594 139.74254962614495 27.29 35.66813428272594 139.74254962614495 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99cca6c6-cc0f-4769-9489-3bcf964a5531">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99cca6c6-cc0f-4769-9489-3bcf964a5531">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99cca6c6-cc0f-4769-9489-3bcf964a5531">
											<gml:posList>35.66811157308158 139.74260405314612 52.3 35.66802364352793 139.74255545111166 52.3 35.66802364352793 139.74255545111166 53.3 35.66811157308158 139.74260405314612 53.3 35.66811157308158 139.74260405314612 52.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-219edce2-8e5e-4f5c-9d33-f3b7c6a6033d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-219edce2-8e5e-4f5c-9d33-f3b7c6a6033d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-219edce2-8e5e-4f5c-9d33-f3b7c6a6033d">
											<gml:posList>35.66811278387545 139.7426079730874 53.3 35.66802044477076 139.7425569348882 53.3 35.66802044477076 139.7425569348882 27.29 35.66811278387545 139.7426079730874 27.29 35.66811278387545 139.7426079730874 53.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8828</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">470.8597</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>