<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f9d680b3-dd78-4c6a-91b6-62db9ae782d7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66890048897254 139.738175338037 0 35.668994309641874 139.7382739012206 0 35.66903239473632 139.73821945415656 0 35.669108587915346 139.73829949206717 0 35.66913410404373 139.7382630207817 0 35.66909784777551 139.73822493269347 0 35.669120914906436 139.73819195485828 0 35.66907588096265 139.73814464270558 0 35.66909549071478 139.7381166176071 0 35.66900675789929 139.73802340577936 0 35.66890048897254 139.738175338037 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890048897254 139.738175338037 18.08 35.66900675789929 139.73802340577936 18.08 35.66909549071478 139.7381166176071 18.08 35.66907588096265 139.73814464270558 18.08 35.669120914906436 139.73819195485828 18.08 35.66909784777551 139.73822493269347 18.08 35.66913410404373 139.7382630207817 18.08 35.669108587915346 139.73829949206717 18.08 35.66903239473632 139.73821945415656 18.08 35.668994309641874 139.7382739012206 18.08 35.66890048897254 139.738175338037 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890048897254 139.738175338037 18.08 35.668994309641874 139.7382739012206 18.08 35.668994309641874 139.7382739012206 34.32 35.66890048897254 139.738175338037 34.32 35.66890048897254 139.738175338037 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668994309641874 139.7382739012206 18.08 35.66903239473632 139.73821945415656 18.08 35.66903239473632 139.73821945415656 34.32 35.668994309641874 139.7382739012206 34.32 35.668994309641874 139.7382739012206 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903239473632 139.73821945415656 18.08 35.669108587915346 139.73829949206717 18.08 35.669108587915346 139.73829949206717 34.32 35.66903239473632 139.73821945415656 34.32 35.66903239473632 139.73821945415656 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669108587915346 139.73829949206717 18.08 35.66913410404373 139.7382630207817 18.08 35.66913410404373 139.7382630207817 34.32 35.669108587915346 139.73829949206717 34.32 35.669108587915346 139.73829949206717 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913410404373 139.7382630207817 18.08 35.66909784777551 139.73822493269347 18.08 35.66909784777551 139.73822493269347 34.32 35.66913410404373 139.7382630207817 34.32 35.66913410404373 139.7382630207817 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909784777551 139.73822493269347 18.08 35.669120914906436 139.73819195485828 18.08 35.669120914906436 139.73819195485828 34.32 35.66909784777551 139.73822493269347 34.32 35.66909784777551 139.73822493269347 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669120914906436 139.73819195485828 18.08 35.66907588096265 139.73814464270558 18.08 35.66907588096265 139.73814464270558 34.32 35.669120914906436 139.73819195485828 34.32 35.669120914906436 139.73819195485828 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907588096265 139.73814464270558 18.08 35.66909549071478 139.7381166176071 18.08 35.66909549071478 139.7381166176071 34.32 35.66907588096265 139.73814464270558 34.32 35.66907588096265 139.73814464270558 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909549071478 139.7381166176071 18.08 35.66900675789929 139.73802340577936 18.08 35.66900675789929 139.73802340577936 34.32 35.66909549071478 139.7381166176071 34.32 35.66909549071478 139.7381166176071 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66900675789929 139.73802340577936 18.08 35.66890048897254 139.738175338037 18.08 35.66890048897254 139.738175338037 34.32 35.66900675789929 139.73802340577936 34.32 35.66900675789929 139.73802340577936 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890048897254 139.738175338037 34.32 35.668994309641874 139.7382739012206 34.32 35.66903239473632 139.73821945415656 34.32 35.669108587915346 139.73829949206717 34.32 35.66913410404373 139.7382630207817 34.32 35.66909784777551 139.73822493269347 34.32 35.669120914906436 139.73819195485828 34.32 35.66907588096265 139.73814464270558 34.32 35.66909549071478 139.7381166176071 34.32 35.66900675789929 139.73802340577936 34.32 35.66890048897254 139.738175338037 34.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-bbc9fc1f-8dd7-4645-a458-c977423ddcfc"/>
							<gml:surfaceMember xlink:href="#poly-00841113-7bda-472b-80db-e70d797cee1e"/>
							<gml:surfaceMember xlink:href="#poly-d5b7aa64-070c-41b3-a8ac-9faa3ebc9bec"/>
							<gml:surfaceMember xlink:href="#poly-2dca1be6-18fc-4eaf-bcf1-89b1905993eb"/>
							<gml:surfaceMember xlink:href="#poly-c680f8da-7e62-483b-bffa-2e6c575872bb"/>
							<gml:surfaceMember xlink:href="#poly-188acbda-754c-41e5-81e3-b32af21cfb33"/>
							<gml:surfaceMember xlink:href="#poly-b6dc5b57-0d1a-4791-ad70-0bc15a8db68c"/>
							<gml:surfaceMember xlink:href="#poly-1c59091c-67f8-4e84-a7b4-6fe80d999053"/>
							<gml:surfaceMember xlink:href="#poly-1a3cefcb-515f-404a-b7de-f0ed2fb5196f"/>
							<gml:surfaceMember xlink:href="#poly-af42b6b5-6447-427d-8a10-f2469e6c3147"/>
							<gml:surfaceMember xlink:href="#poly-d554c387-c23c-4c9a-bab8-e067a0868530"/>
							<gml:surfaceMember xlink:href="#poly-7bdbf1f3-6c97-4696-8345-9c174912bc5c"/>
							<gml:surfaceMember xlink:href="#poly-b97a28ba-2ac5-496c-a6c2-a13cc9d70c2e"/>
							<gml:surfaceMember xlink:href="#poly-9468a82d-9c15-4cfa-8ae9-a4bd312a8e33"/>
							<gml:surfaceMember xlink:href="#poly-d491d70f-80b0-4d17-bab8-40e74fd5eb9e"/>
							<gml:surfaceMember xlink:href="#poly-a2dbd523-8535-4e8a-99f5-77752ff6e5b3"/>
							<gml:surfaceMember xlink:href="#poly-30e600d0-9cdd-4adc-ad57-5a140c588af8"/>
							<gml:surfaceMember xlink:href="#poly-5eee71aa-08ff-4ade-9a8d-0dfb5c5bb496"/>
							<gml:surfaceMember xlink:href="#poly-7e9f4e97-117e-47fd-8844-4e5e480ecee2"/>
							<gml:surfaceMember xlink:href="#poly-970dd128-be97-4fde-b7bb-10300d4aafc6"/>
							<gml:surfaceMember xlink:href="#poly-3e7a20ff-a549-4ea4-8bd4-cdd54250c1b1"/>
							<gml:surfaceMember xlink:href="#poly-adf4d8c0-36a7-469d-a4be-e141eef68dde"/>
							<gml:surfaceMember xlink:href="#poly-b6f0e9f9-5297-4d66-a40f-aa7308e8d65a"/>
							<gml:surfaceMember xlink:href="#poly-9ba1d379-5140-4868-b933-af09cda83150"/>
							<gml:surfaceMember xlink:href="#poly-8ecc447a-1c1d-4566-966c-1ea4dc40a7c8"/>
							<gml:surfaceMember xlink:href="#poly-f4e7c82d-a292-4844-bfd4-03f611310eca"/>
							<gml:surfaceMember xlink:href="#poly-2b8fd59c-b9a6-4c4b-b705-b41aaf2b616f"/>
							<gml:surfaceMember xlink:href="#poly-b843aa5d-0d17-45bd-8fa7-973470dbcffb"/>
							<gml:surfaceMember xlink:href="#poly-0232cf71-8544-406b-9243-18c34bd63c61"/>
							<gml:surfaceMember xlink:href="#poly-69982db7-25a4-4aff-92be-933f0cf833c7"/>
							<gml:surfaceMember xlink:href="#poly-07c37b17-769a-4c33-a63e-e4cfca40bec0"/>
							<gml:surfaceMember xlink:href="#poly-a717e8e9-7bfe-45f3-a1fe-63ae8127c69a"/>
							<gml:surfaceMember xlink:href="#poly-0bd0d159-9118-4ddc-bd0f-2f88a3e78211"/>
							<gml:surfaceMember xlink:href="#poly-c1b61ff3-6798-44f8-9ffc-781e5ecbf9fe"/>
							<gml:surfaceMember xlink:href="#poly-29bff509-fc1f-4691-b5f5-b8bdf6faf032"/>
							<gml:surfaceMember xlink:href="#poly-56b92714-395e-4dc9-9286-4e6be81dd5ab"/>
							<gml:surfaceMember xlink:href="#poly-0b4492c3-b263-486b-9334-c04e6be20ee5"/>
							<gml:surfaceMember xlink:href="#poly-dc5288f9-85b9-402f-96d9-1005ff789600"/>
							<gml:surfaceMember xlink:href="#poly-1bed98a3-9b54-48ca-9e1e-4d43bca09383"/>
							<gml:surfaceMember xlink:href="#poly-a11043cc-b609-45ce-a1b5-4344ed41a3cb"/>
							<gml:surfaceMember xlink:href="#poly-379e862d-f317-4c28-8dc0-1dac610f5673"/>
							<gml:surfaceMember xlink:href="#poly-0956954e-acb5-45c0-b773-04b950ec6d4e"/>
							<gml:surfaceMember xlink:href="#poly-644e4c34-e8d9-4031-a9ef-4f3b6c47d1c6"/>
							<gml:surfaceMember xlink:href="#poly-5d1b1b31-69d2-48ef-9c8e-fc21cdfe8aee"/>
							<gml:surfaceMember xlink:href="#poly-851ea406-36cb-4323-b5c5-881a104229ed"/>
							<gml:surfaceMember xlink:href="#poly-203935da-5688-4433-a157-9e868edd77f6"/>
							<gml:surfaceMember xlink:href="#poly-d40f219b-e93d-4c2a-8882-b4e584dcd455"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f9d680b3-dd78-4c6a-91b6-62db9ae782d7_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6013c73-58c4-42ce-af71-55a6eaf0b938">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909784777552 139.73822493269347 18.75 35.669120914906415 139.73819195485828 18.75 35.669133463425304 139.73820514004296 18.75 35.66911129841346 139.73823906677288 18.75 35.66909784777552 139.73822493269347 18.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f25ca0d-f37e-4a79-b605-1d9413b4b03d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911129841346 139.73823906677288 18.75 35.669133463425304 139.73820514004296 18.75 35.669157559097805 139.73823045118772 18.75 35.66913410404371 139.73826302078166 18.75 35.66911129841346 139.73823906677288 18.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-960f4763-5112-4e28-8b0a-1b216ed8f29a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-960f4763-5112-4e28-8b0a-1b216ed8f29a_0">
											<gml:posList>35.66911129841346 139.73823906677288 18.75 35.66911129841346 139.73823906677288 24.537 35.66911129841346 139.73823906677288 30.323 35.66909784777552 139.73822493269347 30.323 35.66909784777552 139.73822493269347 18.75 35.66911129841346 139.73823906677288 18.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9be6736d-cd7c-498f-9509-80b5266aea5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9be6736d-cd7c-498f-9509-80b5266aea5b_0">
											<gml:posList>35.66909784777552 139.73822493269347 30.323 35.669120914906415 139.73819195485828 30.323 35.669120914906415 139.73819195485828 18.75 35.66909784777552 139.73822493269347 18.75 35.66909784777552 139.73822493269347 30.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06f051d7-bc05-42e8-88ae-698d2169a3de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06f051d7-bc05-42e8-88ae-698d2169a3de_0">
											<gml:posList>35.669133463425304 139.73820514004296 30.323 35.669120914906415 139.73819195485828 30.323 35.66909784777552 139.73822493269347 30.323 35.66911129841346 139.73823906677288 30.323 35.669133463425304 139.73820514004296 30.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29466165-52a8-4261-b616-fdce99d2e113">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29466165-52a8-4261-b616-fdce99d2e113_0">
											<gml:posList>35.669133463425304 139.73820514004296 24.537 35.669133463425304 139.73820514004296 30.323 35.66911129841346 139.73823906677288 30.323 35.66911129841346 139.73823906677288 24.537 35.669133463425304 139.73820514004296 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f43e4f81-e441-4b48-9ab3-6cc4c8455ef8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f43e4f81-e441-4b48-9ab3-6cc4c8455ef8_0">
											<gml:posList>35.66911129841346 139.73823906677288 24.537 35.66911129841346 139.73823906677288 18.75 35.66913410404371 139.73826302078166 18.75 35.66913410404371 139.73826302078166 24.537 35.66911129841346 139.73823906677288 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53bde7a4-2623-40af-a119-96d4a4e554c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53bde7a4-2623-40af-a119-96d4a4e554c5_0">
											<gml:posList>35.669120914906415 139.73819195485828 18.75 35.669120914906415 139.73819195485828 30.323 35.669133463425304 139.73820514004296 30.323 35.669133463425304 139.73820514004296 24.537 35.669133463425304 139.73820514004296 18.75 35.669120914906415 139.73819195485828 18.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60c2a47c-fabd-40e2-bedd-5340f44565a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60c2a47c-fabd-40e2-bedd-5340f44565a1_0">
											<gml:posList>35.669133463425304 139.73820514004296 24.537 35.66911129841346 139.73823906677288 24.537 35.66913410404371 139.73826302078166 24.537 35.669157559097805 139.73823045118772 24.537 35.669133463425304 139.73820514004296 24.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d066776-aa3f-486b-afb5-782b96f6ef43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d066776-aa3f-486b-afb5-782b96f6ef43_0">
											<gml:posList>35.669133463425304 139.73820514004296 18.75 35.669133463425304 139.73820514004296 24.537 35.669157559097805 139.73823045118772 24.537 35.669157559097805 139.73823045118772 18.75 35.669133463425304 139.73820514004296 18.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aaf112c6-ca20-4693-b911-73c32980db0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aaf112c6-ca20-4693-b911-73c32980db0c_0">
											<gml:posList>35.669157559097805 139.73823045118772 18.75 35.669157559097805 139.73823045118772 24.537 35.66913410404371 139.73826302078166 24.537 35.66913410404371 139.73826302078166 18.75 35.669157559097805 139.73823045118772 18.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f9d680b3-dd78-4c6a-91b6-62db9ae782d7_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b16e7ee-a1a0-47b1-b3e4-3d72817f1563">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66897623938172 139.73823111913885 35.137 35.66898918590963 139.73821185048735 35.137 35.66900794041419 139.7382307832948 35.137 35.6689949938833 139.73825005194774 35.137 35.66897623938172 139.73823111913885 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ee2f105-4dd8-4cee-91f1-1c89c01f31df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ee2f105-4dd8-4cee-91f1-1c89c01f31df_0">
											<gml:posList>35.66898918590963 139.73821185048735 35.137 35.66898918590963 139.73821185048735 37.084 35.66900794041419 139.7382307832948 37.084 35.66900794041419 139.7382307832948 35.137 35.66898918590963 139.73821185048735 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e154c62-49be-476c-9cb9-c47b1918d08d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e154c62-49be-476c-9cb9-c47b1918d08d_0">
											<gml:posList>35.66897623938172 139.73823111913885 35.137 35.66897623938172 139.73823111913885 37.084 35.66898918590963 139.73821185048735 37.084 35.66898918590963 139.73821185048735 35.137 35.66897623938172 139.73823111913885 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-154f3d1e-f8b6-45a8-9e73-fd215c00c6a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-154f3d1e-f8b6-45a8-9e73-fd215c00c6a4_0">
											<gml:posList>35.66897623938172 139.73823111913885 37.084 35.6689949938833 139.73825005194774 37.084 35.66900794041419 139.7382307832948 37.084 35.66898918590963 139.73821185048735 37.084 35.66897623938172 139.73823111913885 37.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0adf285-495a-4c52-9d82-1a7834d8722b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0adf285-495a-4c52-9d82-1a7834d8722b_0">
											<gml:posList>35.66900794041419 139.7382307832948 37.084 35.6689949938833 139.73825005194774 37.084 35.6689949938833 139.73825005194774 35.137 35.66900794041419 139.7382307832948 35.137 35.66900794041419 139.7382307832948 37.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f59cc9ed-89e1-49c1-a8ed-9018edfc43a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f59cc9ed-89e1-49c1-a8ed-9018edfc43a3_0">
											<gml:posList>35.6689949938833 139.73825005194774 35.137 35.6689949938833 139.73825005194774 37.084 35.66897623938172 139.73823111913885 37.084 35.66897623938172 139.73823111913885 35.137 35.6689949938833 139.73825005194774 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f9d680b3-dd78-4c6a-91b6-62db9ae782d7_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0774a13-5681-4829-bf65-88d4346b693f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668936108346685 139.73814886254252 35.137 35.66894507576449 139.73813588382103 35.137 35.66896637418562 139.7381573873136 35.137 35.66895741577925 139.73817036602546 35.137 35.668936108346685 139.73814886254252 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe2367e7-8664-422b-8008-e7090a81502e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893477176284 139.73815703821364 35.137 35.668923401318516 139.73817462598953 35.137 35.66891825052751 139.7381696282382 35.137 35.66892962097113 139.73815204046278 35.137 35.66893477176284 139.73815703821364 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-820e803d-f6b8-43d4-95d2-21288aad290f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895827580473 139.73818648121113 35.137 35.66894376999591 139.7381716414718 35.137 35.66894830764888 139.73816497531107 35.137 35.66896281345851 139.73817981505 35.137 35.66895827580473 139.73818648121113 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9c85f65-c760-47b8-992e-23d83b73cdbe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895496834579 139.73819862475895 35.137 35.668950656095156 139.7382053679734 35.137 35.668936710291604 139.73819198564755 35.137 35.66894101352778 139.73818524244427 35.137 35.66895496834579 139.73819862475895 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6d0220e-6201-4710-80b5-691cd460dcba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66896615057251 139.7381937954073 35.137 35.66897148105911 139.73818665332433 35.137 35.668984373086495 139.73820108628166 35.137 35.6689790516215 139.7382082394002 35.137 35.66896615057251 139.7381937954073 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcadf4fb-9212-4b16-bdc2-f3e1a621aa09">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66897396567338 139.7382168613651 35.137 35.66896965342174 139.73822360458013 35.137 35.668955382873115 139.7382099022974 35.137 35.668959686110284 139.7382031590935 35.137 35.66897396567338 139.7382168613651 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d277ff8d-4357-4150-9a3e-032c61ef8a0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d277ff8d-4357-4150-9a3e-032c61ef8a0b_0">
											<gml:posList>35.66894507576449 139.73813588382103 35.266 35.66894507576449 139.73813588382103 35.137 35.668936108346685 139.73814886254252 35.137 35.668936108346685 139.73814886254252 35.266 35.66894507576449 139.73813588382103 35.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9f34ac5-1130-49db-9bbc-0815edf9dbb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9f34ac5-1130-49db-9bbc-0815edf9dbb9_0">
											<gml:posList>35.66894507576449 139.73813588382103 35.266 35.66896637418562 139.7381573873136 35.266 35.66896637418562 139.7381573873136 35.137 35.66894507576449 139.73813588382103 35.137 35.66894507576449 139.73813588382103 35.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b990fd3-2671-4eea-b162-44539148ab8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b990fd3-2671-4eea-b162-44539148ab8a_0">
											<gml:posList>35.66896637418562 139.7381573873136 35.266 35.66894507576449 139.73813588382103 35.266 35.668936108346685 139.73814886254252 35.266 35.66895741577925 139.73817036602546 35.266 35.66896637418562 139.7381573873136 35.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38099f41-9407-4522-a153-283088952db2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38099f41-9407-4522-a153-283088952db2_0">
											<gml:posList>35.66893477176284 139.73815703821364 35.137 35.66892962097113 139.73815204046278 35.137 35.66892962097113 139.73815204046278 36.003 35.66893477176284 139.73815703821364 36.003 35.66893477176284 139.73815703821364 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22fa604b-ad26-4708-8c33-ffe781f32ecf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22fa604b-ad26-4708-8c33-ffe781f32ecf_0">
											<gml:posList>35.668936108346685 139.73814886254252 35.137 35.66895741577925 139.73817036602546 35.137 35.66895741577925 139.73817036602546 35.266 35.668936108346685 139.73814886254252 35.266 35.668936108346685 139.73814886254252 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4148c6a-2622-4c55-ba34-e0b994195ce6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4148c6a-2622-4c55-ba34-e0b994195ce6_0">
											<gml:posList>35.66892962097113 139.73815204046278 35.137 35.66891825052751 139.7381696282382 35.137 35.66891825052751 139.7381696282382 36.003 35.66892962097113 139.73815204046278 36.003 35.66892962097113 139.73815204046278 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bc41a79-548f-4bf2-87da-6dfa7af5581a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bc41a79-548f-4bf2-87da-6dfa7af5581a_0">
											<gml:posList>35.66891825052751 139.7381696282382 36.003 35.668923401318516 139.73817462598953 36.003 35.66893477176284 139.73815703821364 36.003 35.66892962097113 139.73815204046278 36.003 35.66891825052751 139.7381696282382 36.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3a3ce80-3740-46a7-b348-7398bad25d90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3a3ce80-3740-46a7-b348-7398bad25d90_0">
											<gml:posList>35.66896637418562 139.7381573873136 35.266 35.66895741577925 139.73817036602546 35.266 35.66895741577925 139.73817036602546 35.137 35.66896637418562 139.7381573873136 35.137 35.66896637418562 139.7381573873136 35.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf602118-e3ff-4f11-a020-ac293b8199c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf602118-e3ff-4f11-a020-ac293b8199c3_0">
											<gml:posList>35.66893477176284 139.73815703821364 35.137 35.66893477176284 139.73815703821364 36.003 35.668923401318516 139.73817462598953 36.003 35.668923401318516 139.73817462598953 35.137 35.66893477176284 139.73815703821364 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9208cbda-e8d8-4ebf-ab4a-7d1c6b09faed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9208cbda-e8d8-4ebf-ab4a-7d1c6b09faed_0">
											<gml:posList>35.66894376999591 139.7381716414718 35.137 35.66894376999591 139.7381716414718 36.232 35.66894830764888 139.73816497531107 36.232 35.66894830764888 139.73816497531107 35.137 35.66894376999591 139.7381716414718 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e24eca68-96f5-4b64-a0a1-0b04b6a65921">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e24eca68-96f5-4b64-a0a1-0b04b6a65921_0">
											<gml:posList>35.66891825052751 139.7381696282382 35.137 35.668923401318516 139.73817462598953 35.137 35.668923401318516 139.73817462598953 36.003 35.66891825052751 139.7381696282382 36.003 35.66891825052751 139.7381696282382 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7794deb-6816-4536-95c0-834db52fcd42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7794deb-6816-4536-95c0-834db52fcd42_0">
											<gml:posList>35.66894830764888 139.73816497531107 36.232 35.66896281345851 139.73817981505 36.232 35.66896281345851 139.73817981505 35.137 35.66894830764888 139.73816497531107 35.137 35.66894830764888 139.73816497531107 36.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d80fc34-e8ca-4d58-87bc-cf13b4361b88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d80fc34-e8ca-4d58-87bc-cf13b4361b88_0">
											<gml:posList>35.66894830764888 139.73816497531107 36.232 35.66894376999591 139.7381716414718 36.232 35.66895827580473 139.73818648121113 36.232 35.66896281345851 139.73817981505 36.232 35.66894830764888 139.73816497531107 36.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-502b3518-3d66-4676-806f-e9de72718872">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-502b3518-3d66-4676-806f-e9de72718872_0">
											<gml:posList>35.66894376999591 139.7381716414718 35.137 35.66895827580473 139.73818648121113 35.137 35.66895827580473 139.73818648121113 36.232 35.66894376999591 139.7381716414718 36.232 35.66894376999591 139.7381716414718 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae79bbf1-9034-493d-9760-8241c6958e2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae79bbf1-9034-493d-9760-8241c6958e2a_0">
											<gml:posList>35.66895827580473 139.73818648121113 35.137 35.66896281345851 139.73817981505 35.137 35.66896281345851 139.73817981505 36.232 35.66895827580473 139.73818648121113 36.232 35.66895827580473 139.73818648121113 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bf9a95b-748b-4171-bf29-99e857cbcb22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bf9a95b-748b-4171-bf29-99e857cbcb22_0">
											<gml:posList>35.66894101352778 139.73818524244427 35.137 35.668936710291604 139.73819198564755 35.137 35.668936710291604 139.73819198564755 36.079 35.66894101352778 139.73818524244427 36.079 35.66894101352778 139.73818524244427 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-064f86a9-055e-4553-8196-487b414bcdbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-064f86a9-055e-4553-8196-487b414bcdbf_0">
											<gml:posList>35.66897148105911 139.73818665332433 35.137 35.66896615057251 139.7381937954073 35.137 35.66896615057251 139.7381937954073 36.232 35.66897148105911 139.73818665332433 36.232 35.66897148105911 139.73818665332433 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8c513f4-ec2d-4915-9bd4-4a8d135d107f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8c513f4-ec2d-4915-9bd4-4a8d135d107f_0">
											<gml:posList>35.66895496834579 139.73819862475895 35.137 35.66894101352778 139.73818524244427 35.137 35.66894101352778 139.73818524244427 36.079 35.66895496834579 139.73819862475895 36.079 35.66895496834579 139.73819862475895 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7a41511-dc76-4e18-8f53-e4bbed4a2a79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7a41511-dc76-4e18-8f53-e4bbed4a2a79_0">
											<gml:posList>35.668984373086495 139.73820108628166 35.137 35.66897148105911 139.73818665332433 35.137 35.66897148105911 139.73818665332433 36.232 35.668984373086495 139.73820108628166 36.232 35.668984373086495 139.73820108628166 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e858f3a-02e3-472d-858c-a93de56c56b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e858f3a-02e3-472d-858c-a93de56c56b8_0">
											<gml:posList>35.668936710291604 139.73819198564755 36.079 35.668950656095156 139.7382053679734 36.079 35.66895496834579 139.73819862475895 36.079 35.66894101352778 139.73818524244427 36.079 35.668936710291604 139.73819198564755 36.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b11224ca-56b8-4d06-b4a9-9c61fb0fa9a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b11224ca-56b8-4d06-b4a9-9c61fb0fa9a3_0">
											<gml:posList>35.66896615057251 139.7381937954073 36.232 35.6689790516215 139.7382082394002 36.232 35.668984373086495 139.73820108628166 36.232 35.66897148105911 139.73818665332433 36.232 35.66896615057251 139.7381937954073 36.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1cb74d6-e19c-493d-ac68-57bf0664fb7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1cb74d6-e19c-493d-ac68-57bf0664fb7d_0">
											<gml:posList>35.668936710291604 139.73819198564755 35.137 35.668950656095156 139.7382053679734 35.137 35.668950656095156 139.7382053679734 36.079 35.668936710291604 139.73819198564755 36.079 35.668936710291604 139.73819198564755 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c881fc0-0f25-4543-b9f0-3585ff42ecca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c881fc0-0f25-4543-b9f0-3585ff42ecca_0">
											<gml:posList>35.66896615057251 139.7381937954073 35.137 35.6689790516215 139.7382082394002 35.137 35.6689790516215 139.7382082394002 36.232 35.66896615057251 139.7381937954073 36.232 35.66896615057251 139.7381937954073 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6757bc75-980c-41a2-9d1b-b0c83d36494c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6757bc75-980c-41a2-9d1b-b0c83d36494c_0">
											<gml:posList>35.668950656095156 139.7382053679734 35.137 35.66895496834579 139.73819862475895 35.137 35.66895496834579 139.73819862475895 36.079 35.668950656095156 139.7382053679734 36.079 35.668950656095156 139.7382053679734 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-029910a1-5807-42ae-a2ca-fe4043229c08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-029910a1-5807-42ae-a2ca-fe4043229c08_0">
											<gml:posList>35.6689790516215 139.7382082394002 35.137 35.668984373086495 139.73820108628166 35.137 35.668984373086495 139.73820108628166 36.232 35.6689790516215 139.7382082394002 36.232 35.6689790516215 139.7382082394002 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be6456bf-06f2-43a5-b5ea-ec0638c8a259">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be6456bf-06f2-43a5-b5ea-ec0638c8a259_0">
											<gml:posList>35.668959686110284 139.7382031590935 35.137 35.668955382873115 139.7382099022974 35.137 35.668955382873115 139.7382099022974 36.193 35.668959686110284 139.7382031590935 36.193 35.668959686110284 139.7382031590935 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48cd9b20-1b44-4438-9017-74e2797d34cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48cd9b20-1b44-4438-9017-74e2797d34cb_0">
											<gml:posList>35.668959686110284 139.7382031590935 35.137 35.668959686110284 139.7382031590935 36.193 35.66897396567338 139.7382168613651 36.193 35.66897396567338 139.7382168613651 35.137 35.668959686110284 139.7382031590935 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e03f90a0-676f-41f5-8d3c-1e332979acd2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e03f90a0-676f-41f5-8d3c-1e332979acd2_0">
											<gml:posList>35.668955382873115 139.7382099022974 36.193 35.66896965342174 139.73822360458013 36.193 35.66897396567338 139.7382168613651 36.193 35.668959686110284 139.7382031590935 36.193 35.668955382873115 139.7382099022974 36.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2ee54d5-8b07-4c6d-bb04-1d0502690aeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2ee54d5-8b07-4c6d-bb04-1d0502690aeb_0">
											<gml:posList>35.66896965342174 139.73822360458013 35.137 35.66896965342174 139.73822360458013 36.193 35.668955382873115 139.7382099022974 36.193 35.668955382873115 139.7382099022974 35.137 35.66896965342174 139.73822360458013 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-194df515-e3b2-4dfb-9e89-db259eb8cca5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-194df515-e3b2-4dfb-9e89-db259eb8cca5_0">
											<gml:posList>35.66896965342174 139.73822360458013 35.137 35.66897396567338 139.7382168613651 35.137 35.66897396567338 139.7382168613651 36.193 35.66896965342174 139.73822360458013 36.193 35.66896965342174 139.73822360458013 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-bbc9fc1f-8dd7-4645-a458-c977423ddcfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbc9fc1f-8dd7-4645-a458-c977423ddcfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbc9fc1f-8dd7-4645-a458-c977423ddcfc">
											<gml:posList>35.66909784777552 139.73822493269347 18.08 35.66913410404371 139.73826302078166 18.08 35.66910858791532 139.73829949206717 18.08 35.66903239473631 139.73821945415656 18.08 35.66899430964187 139.73827390122057 18.08 35.66890048897254 139.738175338037 18.08 35.6690067578993 139.73802340577936 18.08 35.669095490714774 139.7381166176071 18.08 35.66907588096265 139.73814464270558 18.08 35.669120914906415 139.73819195485828 18.08 35.66909784777552 139.73822493269347 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00841113-7bda-472b-80db-e70d797cee1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00841113-7bda-472b-80db-e70d797cee1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00841113-7bda-472b-80db-e70d797cee1e">
											<gml:posList>35.669017107670264 139.73808289866352 34.694 35.669000028030595 139.73810744122633 35.132 35.66899265430701 139.73811821989992 35.324 35.669017107670264 139.73808289866352 34.694</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5b7aa64-070c-41b3-a8ac-9faa3ebc9bec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5b7aa64-070c-41b3-a8ac-9faa3ebc9bec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5b7aa64-070c-41b3-a8ac-9faa3ebc9bec">
											<gml:posList>35.66890048897254 139.738175338037 36.957 35.668904373608385 139.73817497995302 36.957 35.66893732660891 139.73812784044333 36.957 35.668936989389294 139.73812314626807 36.957 35.66890048897254 139.738175338037 36.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2dca1be6-18fc-4eaf-bcf1-89b1905993eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dca1be6-18fc-4eaf-bcf1-89b1905993eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dca1be6-18fc-4eaf-bcf1-89b1905993eb">
											<gml:posList>35.66899430964187 139.73827390122057 36.957 35.66899399941679 139.73826914073297 36.957 35.668904373608385 139.73817497995302 36.957 35.66890048897254 139.738175338037 36.957 35.66899430964187 139.73827390122057 36.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c680f8da-7e62-483b-bffa-2e6c575872bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c680f8da-7e62-483b-bffa-2e6c575872bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c680f8da-7e62-483b-bffa-2e6c575872bb">
											<gml:posList>35.66899399941679 139.73826914073297 35.137 35.669028483102856 139.73821986750136 35.137 35.66893732660891 139.73812784044333 35.137 35.668904373608385 139.73817497995302 35.137 35.66899399941679 139.73826914073297 35.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-188acbda-754c-41e5-81e3-b32af21cfb33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-188acbda-754c-41e5-81e3-b32af21cfb33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-188acbda-754c-41e5-81e3-b32af21cfb33">
											<gml:posList>35.668969714165 139.7381521806525 38.237 35.66899993789336 139.73810744133337 38.237 35.66897144064854 139.73807853448685 38.237 35.668941216930776 139.73812327380088 38.237 35.668969714165 139.7381521806525 38.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6dc5b57-0d1a-4791-ad70-0bc15a8db68c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6dc5b57-0d1a-4791-ad70-0bc15a8db68c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6dc5b57-0d1a-4791-ad70-0bc15a8db68c">
											<gml:posList>35.668936989389294 139.73812314626807 34.535 35.66896811160801 139.7381545685048 34.535 35.668969714165 139.7381521806525 34.535 35.668941216930776 139.73812327380088 34.535 35.66897144064854 139.73807853448685 34.535 35.66899993789336 139.73810744133337 34.535 35.669017107670264 139.73808289866352 34.535 35.66898714816856 139.73805143086952 34.535 35.668936989389294 139.73812314626807 34.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c59091c-67f8-4e84-a7b4-6fe80d999053">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c59091c-67f8-4e84-a7b4-6fe80d999053">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c59091c-67f8-4e84-a7b4-6fe80d999053">
											<gml:posList>35.668936989389294 139.73812314626807 36.957 35.66893732660891 139.73812784044333 36.957 35.669028483102856 139.73821986750136 36.957 35.66903239473631 139.73821945415656 36.957 35.668936989389294 139.73812314626807 36.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a3cefcb-515f-404a-b7de-f0ed2fb5196f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a3cefcb-515f-404a-b7de-f0ed2fb5196f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a3cefcb-515f-404a-b7de-f0ed2fb5196f">
											<gml:posList>35.66900704083938 139.73802784596322 32.106 35.6690067578993 139.73802340577936 32.106 35.66898714816856 139.73805143086952 32.106 35.668989105781165 139.7380534941579 32.106 35.66900704083938 139.73802784596322 32.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af42b6b5-6447-427d-8a10-f2469e6c3147">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af42b6b5-6447-427d-8a10-f2469e6c3147">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af42b6b5-6447-427d-8a10-f2469e6c3147">
											<gml:posList>35.66899265430701 139.73811821989992 35.324 35.66896811160801 139.7381545685048 34.694 35.66903239473631 139.73821945415656 34.694 35.66899265430701 139.73811821989992 35.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d554c387-c23c-4c9a-bab8-e067a0868530">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d554c387-c23c-4c9a-bab8-e067a0868530">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d554c387-c23c-4c9a-bab8-e067a0868530">
											<gml:posList>35.66903239473631 139.73821945415656 36.957 35.669028483102856 139.73821986750136 36.957 35.66899399941679 139.73826914073297 36.957 35.66899430964187 139.73827390122057 36.957 35.66903239473631 139.73821945415656 36.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7bdbf1f3-6c97-4696-8345-9c174912bc5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bdbf1f3-6c97-4696-8345-9c174912bc5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bdbf1f3-6c97-4696-8345-9c174912bc5c">
											<gml:posList>35.66899265430701 139.73811821989992 35.324 35.66903239473631 139.73821945415656 34.694 35.669072331658505 139.73826140397455 34.694 35.66899265430701 139.73811821989992 35.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b97a28ba-2ac5-496c-a6c2-a13cc9d70c2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b97a28ba-2ac5-496c-a6c2-a13cc9d70c2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b97a28ba-2ac5-496c-a6c2-a13cc9d70c2e">
											<gml:posList>35.6690918584373 139.73811694225685 31.755 35.66900704083938 139.73802784596322 31.755 35.668989105781165 139.7380534941579 31.755 35.669073923360365 139.73814259045884 31.755 35.6690918584373 139.73811694225685 31.755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9468a82d-9c15-4cfa-8ae9-a4bd312a8e33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9468a82d-9c15-4cfa-8ae9-a4bd312a8e33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9468a82d-9c15-4cfa-8ae9-a4bd312a8e33">
											<gml:posList>35.66899265430701 139.73811821989992 35.324 35.669072331658505 139.73826140397455 34.694 35.66909784777552 139.73822493269347 35.324 35.66899265430701 139.73811821989992 35.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d491d70f-80b0-4d17-bab8-40e74fd5eb9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d491d70f-80b0-4d17-bab8-40e74fd5eb9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d491d70f-80b0-4d17-bab8-40e74fd5eb9e">
											<gml:posList>35.6690067578993 139.73802340577936 32.106 35.66900704083938 139.73802784596322 32.106 35.6690918584373 139.73811694225685 32.106 35.669095490714774 139.7381166176071 32.106 35.6690067578993 139.73802340577936 32.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2dbd523-8535-4e8a-99f5-77752ff6e5b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2dbd523-8535-4e8a-99f5-77752ff6e5b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2dbd523-8535-4e8a-99f5-77752ff6e5b3">
											<gml:posList>35.66899265430701 139.73811821989992 35.324 35.66909784777552 139.73822493269347 35.324 35.669120914906415 139.73819195485828 34.694 35.66899265430701 139.73811821989992 35.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-30e600d0-9cdd-4adc-ad57-5a140c588af8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30e600d0-9cdd-4adc-ad57-5a140c588af8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30e600d0-9cdd-4adc-ad57-5a140c588af8">
											<gml:posList>35.669017107670264 139.73808289866352 34.694 35.66899265430701 139.73811821989992 35.324 35.669120914906415 139.73819195485828 34.694 35.669017107670264 139.73808289866352 34.694</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5eee71aa-08ff-4ade-9a8d-0dfb5c5bb496">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5eee71aa-08ff-4ade-9a8d-0dfb5c5bb496">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5eee71aa-08ff-4ade-9a8d-0dfb5c5bb496">
											<gml:posList>35.6690918584373 139.73811694225685 32.106 35.669073923360365 139.73814259045884 32.106 35.66907588096265 139.73814464270558 32.106 35.669095490714774 139.7381166176071 32.106 35.6690918584373 139.73811694225685 32.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e9f4e97-117e-47fd-8844-4e5e480ecee2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e9f4e97-117e-47fd-8844-4e5e480ecee2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e9f4e97-117e-47fd-8844-4e5e480ecee2">
											<gml:posList>35.669085782292214 139.7382755380556 34.535 35.66911129841346 139.73823906677288 34.535 35.66909784777552 139.73822493269347 34.535 35.669072331658505 139.73826140397455 34.535 35.669085782292214 139.7382755380556 34.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-970dd128-be97-4fde-b7bb-10300d4aafc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-970dd128-be97-4fde-b7bb-10300d4aafc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-970dd128-be97-4fde-b7bb-10300d4aafc6">
											<gml:posList>35.669085782292214 139.7382755380556 25.856 35.66910858791532 139.73829949206717 25.856 35.66913410404371 139.73826302078166 25.856 35.66911129841346 139.73823906677288 25.856 35.669085782292214 139.7382755380556 25.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e7a20ff-a549-4ea4-8bd4-cdd54250c1b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e7a20ff-a549-4ea4-8bd4-cdd54250c1b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e7a20ff-a549-4ea4-8bd4-cdd54250c1b1">
											<gml:posList>35.66899265430701 139.73811821989992 35.324 35.668969714165 139.7381521806525 34.694 35.66896811160801 139.7381545685048 34.694 35.66899265430701 139.73811821989992 35.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adf4d8c0-36a7-469d-a4be-e141eef68dde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adf4d8c0-36a7-469d-a4be-e141eef68dde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adf4d8c0-36a7-469d-a4be-e141eef68dde">
											<gml:posList>35.66893732660891 139.73812784044333 36.957 35.66893732660891 139.73812784044333 35.137 35.669028483102856 139.73821986750136 35.137 35.669028483102856 139.73821986750136 36.957 35.66893732660891 139.73812784044333 36.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6f0e9f9-5297-4d66-a40f-aa7308e8d65a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6f0e9f9-5297-4d66-a40f-aa7308e8d65a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6f0e9f9-5297-4d66-a40f-aa7308e8d65a">
											<gml:posList>35.66899399941679 139.73826914073297 36.957 35.66899399941679 139.73826914073297 35.137 35.668904373608385 139.73817497995302 35.137 35.668904373608385 139.73817497995302 36.957 35.66899399941679 139.73826914073297 36.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ba1d379-5140-4868-b933-af09cda83150">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ba1d379-5140-4868-b933-af09cda83150">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ba1d379-5140-4868-b933-af09cda83150">
											<gml:posList>35.668989105781165 139.7380534941579 32.106 35.668989105781165 139.7380534941579 31.755 35.66900704083938 139.73802784596322 31.755 35.66900704083938 139.73802784596322 32.106 35.668989105781165 139.7380534941579 32.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ecc447a-1c1d-4566-966c-1ea4dc40a7c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ecc447a-1c1d-4566-966c-1ea4dc40a7c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ecc447a-1c1d-4566-966c-1ea4dc40a7c8">
											<gml:posList>35.669095490714774 139.7381166176071 18.08 35.6690067578993 139.73802340577936 18.08 35.6690067578993 139.73802340577936 32.106 35.669095490714774 139.7381166176071 32.106 35.669095490714774 139.7381166176071 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4e7c82d-a292-4844-bfd4-03f611310eca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4e7c82d-a292-4844-bfd4-03f611310eca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4e7c82d-a292-4844-bfd4-03f611310eca">
											<gml:posList>35.66900704083938 139.73802784596322 32.106 35.66900704083938 139.73802784596322 31.755 35.6690918584373 139.73811694225685 31.755 35.6690918584373 139.73811694225685 32.106 35.66900704083938 139.73802784596322 32.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b8fd59c-b9a6-4c4b-b705-b41aaf2b616f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b8fd59c-b9a6-4c4b-b705-b41aaf2b616f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b8fd59c-b9a6-4c4b-b705-b41aaf2b616f">
											<gml:posList>35.669000028030595 139.73810744122633 35.132 35.66899993789336 139.73810744133337 34.535 35.66897144064854 139.73807853448685 34.535 35.66897144064854 139.73807853448685 38.237 35.66899993789336 139.73810744133337 38.237 35.669000028030595 139.73810744122633 35.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b843aa5d-0d17-45bd-8fa7-973470dbcffb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b843aa5d-0d17-45bd-8fa7-973470dbcffb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b843aa5d-0d17-45bd-8fa7-973470dbcffb">
											<gml:posList>35.66899993789336 139.73810744133337 34.535 35.669000028030595 139.73810744122633 35.132 35.669017107670264 139.73808289866352 34.694 35.669017107670264 139.73808289866352 34.535 35.66899993789336 139.73810744133337 34.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0232cf71-8544-406b-9243-18c34bd63c61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0232cf71-8544-406b-9243-18c34bd63c61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0232cf71-8544-406b-9243-18c34bd63c61">
											<gml:posList>35.6690067578993 139.73802340577936 18.08 35.66890048897254 139.738175338037 18.08 35.66890048897254 139.738175338037 36.957 35.668936989389294 139.73812314626807 36.957 35.668936989389294 139.73812314626807 34.535 35.66898714816856 139.73805143086952 34.535 35.66898714816856 139.73805143086952 32.106 35.6690067578993 139.73802340577936 32.106 35.6690067578993 139.73802340577936 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69982db7-25a4-4aff-92be-933f0cf833c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69982db7-25a4-4aff-92be-933f0cf833c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69982db7-25a4-4aff-92be-933f0cf833c7">
											<gml:posList>35.668941216930776 139.73812327380088 34.535 35.668941216930776 139.73812327380088 38.237 35.66897144064854 139.73807853448685 38.237 35.66897144064854 139.73807853448685 34.535 35.668941216930776 139.73812327380088 34.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07c37b17-769a-4c33-a63e-e4cfca40bec0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07c37b17-769a-4c33-a63e-e4cfca40bec0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07c37b17-769a-4c33-a63e-e4cfca40bec0">
											<gml:posList>35.669073923360365 139.73814259045884 32.106 35.669073923360365 139.73814259045884 31.755 35.668989105781165 139.7380534941579 31.755 35.668989105781165 139.7380534941579 32.106 35.66898714816856 139.73805143086952 32.106 35.66898714816856 139.73805143086952 34.535 35.669017107670264 139.73808289866352 34.535 35.669017107670264 139.73808289866352 34.694 35.669120914906415 139.73819195485828 34.694 35.669120914906415 139.73819195485828 18.08 35.66907588096265 139.73814464270558 18.08 35.66907588096265 139.73814464270558 32.106 35.669073923360365 139.73814259045884 32.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a717e8e9-7bfe-45f3-a1fe-63ae8127c69a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a717e8e9-7bfe-45f3-a1fe-63ae8127c69a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a717e8e9-7bfe-45f3-a1fe-63ae8127c69a">
											<gml:posList>35.66899993789336 139.73810744133337 38.237 35.668969714165 139.7381521806525 38.237 35.668969714165 139.7381521806525 34.694 35.66899265430701 139.73811821989992 35.324 35.669000028030595 139.73810744122633 35.132 35.66899993789336 139.73810744133337 38.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bd0d159-9118-4ddc-bd0f-2f88a3e78211">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bd0d159-9118-4ddc-bd0f-2f88a3e78211">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bd0d159-9118-4ddc-bd0f-2f88a3e78211">
											<gml:posList>35.6690918584373 139.73811694225685 32.106 35.6690918584373 139.73811694225685 31.755 35.669073923360365 139.73814259045884 31.755 35.669073923360365 139.73814259045884 32.106 35.6690918584373 139.73811694225685 32.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1b61ff3-6798-44f8-9ffc-781e5ecbf9fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1b61ff3-6798-44f8-9ffc-781e5ecbf9fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1b61ff3-6798-44f8-9ffc-781e5ecbf9fe">
											<gml:posList>35.66907588096265 139.73814464270558 18.08 35.669095490714774 139.7381166176071 18.08 35.669095490714774 139.7381166176071 32.106 35.66907588096265 139.73814464270558 32.106 35.66907588096265 139.73814464270558 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29bff509-fc1f-4691-b5f5-b8bdf6faf032">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29bff509-fc1f-4691-b5f5-b8bdf6faf032">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29bff509-fc1f-4691-b5f5-b8bdf6faf032">
											<gml:posList>35.668941216930776 139.73812327380088 34.535 35.668969714165 139.7381521806525 34.535 35.668969714165 139.7381521806525 34.694 35.668969714165 139.7381521806525 38.237 35.668941216930776 139.73812327380088 38.237 35.668941216930776 139.73812327380088 34.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56b92714-395e-4dc9-9286-4e6be81dd5ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56b92714-395e-4dc9-9286-4e6be81dd5ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56b92714-395e-4dc9-9286-4e6be81dd5ab">
											<gml:posList>35.668904373608385 139.73817497995302 36.957 35.668904373608385 139.73817497995302 35.137 35.66893732660891 139.73812784044333 35.137 35.66893732660891 139.73812784044333 36.957 35.668904373608385 139.73817497995302 36.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b4492c3-b263-486b-9334-c04e6be20ee5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b4492c3-b263-486b-9334-c04e6be20ee5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b4492c3-b263-486b-9334-c04e6be20ee5">
											<gml:posList>35.66896811160801 139.7381545685048 34.535 35.66896811160801 139.7381545685048 34.694 35.668969714165 139.7381521806525 34.694 35.668969714165 139.7381521806525 34.535 35.66896811160801 139.7381545685048 34.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc5288f9-85b9-402f-96d9-1005ff789600">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc5288f9-85b9-402f-96d9-1005ff789600">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc5288f9-85b9-402f-96d9-1005ff789600">
											<gml:posList>35.66903239473631 139.73821945415656 36.957 35.66903239473631 139.73821945415656 34.694 35.66896811160801 139.7381545685048 34.694 35.66896811160801 139.7381545685048 34.535 35.668936989389294 139.73812314626807 34.535 35.668936989389294 139.73812314626807 36.957 35.66903239473631 139.73821945415656 36.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bed98a3-9b54-48ca-9e1e-4d43bca09383">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bed98a3-9b54-48ca-9e1e-4d43bca09383">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bed98a3-9b54-48ca-9e1e-4d43bca09383">
											<gml:posList>35.669120914906415 139.73819195485828 18.08 35.669120914906415 139.73819195485828 34.694 35.66909784777552 139.73822493269347 35.324 35.66909784777552 139.73822493269347 34.535 35.66909784777552 139.73822493269347 18.08 35.669120914906415 139.73819195485828 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a11043cc-b609-45ce-a1b5-4344ed41a3cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a11043cc-b609-45ce-a1b5-4344ed41a3cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a11043cc-b609-45ce-a1b5-4344ed41a3cb">
											<gml:posList>35.66890048897254 139.738175338037 18.08 35.66899430964187 139.73827390122057 18.08 35.66899430964187 139.73827390122057 36.957 35.66890048897254 139.738175338037 36.957 35.66890048897254 139.738175338037 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-379e862d-f317-4c28-8dc0-1dac610f5673">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-379e862d-f317-4c28-8dc0-1dac610f5673">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-379e862d-f317-4c28-8dc0-1dac610f5673">
											<gml:posList>35.66909784777552 139.73822493269347 34.535 35.66909784777552 139.73822493269347 35.324 35.669072331658505 139.73826140397455 34.694 35.669072331658505 139.73826140397455 34.535 35.66909784777552 139.73822493269347 34.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0956954e-acb5-45c0-b773-04b950ec6d4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0956954e-acb5-45c0-b773-04b950ec6d4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0956954e-acb5-45c0-b773-04b950ec6d4e">
											<gml:posList>35.66909784777552 139.73822493269347 18.08 35.66909784777552 139.73822493269347 34.535 35.66911129841346 139.73823906677288 34.535 35.66911129841346 139.73823906677288 25.856 35.66913410404371 139.73826302078166 25.856 35.66913410404371 139.73826302078166 18.08 35.66909784777552 139.73822493269347 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-644e4c34-e8d9-4031-a9ef-4f3b6c47d1c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-644e4c34-e8d9-4031-a9ef-4f3b6c47d1c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-644e4c34-e8d9-4031-a9ef-4f3b6c47d1c6">
											<gml:posList>35.669028483102856 139.73821986750136 36.957 35.669028483102856 139.73821986750136 35.137 35.66899399941679 139.73826914073297 35.137 35.66899399941679 139.73826914073297 36.957 35.669028483102856 139.73821986750136 36.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d1b1b31-69d2-48ef-9c8e-fc21cdfe8aee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d1b1b31-69d2-48ef-9c8e-fc21cdfe8aee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d1b1b31-69d2-48ef-9c8e-fc21cdfe8aee">
											<gml:posList>35.66899430964187 139.73827390122057 36.957 35.66899430964187 139.73827390122057 18.08 35.66903239473631 139.73821945415656 18.08 35.66903239473631 139.73821945415656 34.694 35.66903239473631 139.73821945415656 36.957 35.66899430964187 139.73827390122057 36.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-851ea406-36cb-4323-b5c5-881a104229ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-851ea406-36cb-4323-b5c5-881a104229ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-851ea406-36cb-4323-b5c5-881a104229ed">
											<gml:posList>35.66911129841346 139.73823906677288 25.856 35.66911129841346 139.73823906677288 34.535 35.669085782292214 139.7382755380556 34.535 35.669085782292214 139.7382755380556 25.856 35.66911129841346 139.73823906677288 25.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-203935da-5688-4433-a157-9e868edd77f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-203935da-5688-4433-a157-9e868edd77f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-203935da-5688-4433-a157-9e868edd77f6">
											<gml:posList>35.669085782292214 139.7382755380556 25.856 35.669085782292214 139.7382755380556 34.535 35.669072331658505 139.73826140397455 34.535 35.669072331658505 139.73826140397455 34.694 35.66903239473631 139.73821945415656 34.694 35.66903239473631 139.73821945415656 18.08 35.66910858791532 139.73829949206717 18.08 35.66910858791532 139.73829949206717 25.856 35.669085782292214 139.7382755380556 25.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d40f219b-e93d-4c2a-8882-b4e584dcd455">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d40f219b-e93d-4c2a-8882-b4e584dcd455">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d40f219b-e93d-4c2a-8882-b4e584dcd455">
											<gml:posList>35.66910858791532 139.73829949206717 18.08 35.66913410404371 139.73826302078166 18.08 35.66913410404371 139.73826302078166 25.856 35.66910858791532 139.73829949206717 25.856 35.66910858791532 139.73829949206717 18.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-152</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">303.29108</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>