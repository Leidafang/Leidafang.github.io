<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_fa0608fb-2bd9-4c08-8d14-e8d27e3f75c0">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">48.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669062925188896 139.74166069096128 0 35.6690279444983 139.7417694243162 0 35.669025486727584 139.74185635971693 0 35.66904135457587 139.7418612018868 0 35.66915493925707 139.74187653683464 0 35.669153955968696 139.74188736312502 0 35.6692111088561 139.74189503021148 0 35.669207176612446 139.7419395504707 0 35.669227369451995 139.7419422889792 0 35.66923067635543 139.74190517030982 0 35.66925636815485 139.7419086757677 0 35.6692580666714 139.74189011637458 0 35.66931215463963 139.74189745558456 0 35.66933530413986 139.74163961284688 0 35.669311505467604 139.7416364366902 0 35.66931320394219 139.74161787727869 0 35.66926488541407 139.74161141534572 0 35.66926417087871 139.74162003212567 0 35.66914661970781 139.74160414975395 0 35.66914813899712 139.74158702657664 0 35.66910667173869 139.74158166144377 0 35.66910425831424 139.74160828526735 0 35.669092719652475 139.74160686247657 0 35.669062925188896 139.74166069096128 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669062925188896 139.74166069096128 9.93 35.669092719652475 139.74160686247657 9.93 35.66910425831424 139.74160828526735 9.93 35.66910667173869 139.74158166144377 9.93 35.66914813899712 139.74158702657664 9.93 35.66914661970781 139.74160414975395 9.93 35.66926417087871 139.74162003212567 9.93 35.66926488541407 139.74161141534572 9.93 35.66931320394219 139.74161787727869 9.93 35.669311505467604 139.7416364366902 9.93 35.66933530413986 139.74163961284688 9.93 35.66931215463963 139.74189745558456 9.93 35.6692580666714 139.74189011637458 9.93 35.66925636815485 139.7419086757677 9.93 35.66923067635543 139.74190517030982 9.93 35.669227369451995 139.7419422889792 9.93 35.669207176612446 139.7419395504707 9.93 35.6692111088561 139.74189503021148 9.93 35.669153955968696 139.74188736312502 9.93 35.66915493925707 139.74187653683464 9.93 35.66904135457587 139.7418612018868 9.93 35.669025486727584 139.74185635971693 9.93 35.6690279444983 139.7417694243162 9.93 35.669062925188896 139.74166069096128 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669062925188896 139.74166069096128 9.93 35.6690279444983 139.7417694243162 9.93 35.6690279444983 139.7417694243162 57.42 35.669062925188896 139.74166069096128 57.42 35.669062925188896 139.74166069096128 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690279444983 139.7417694243162 9.93 35.669025486727584 139.74185635971693 9.93 35.669025486727584 139.74185635971693 57.42 35.6690279444983 139.7417694243162 57.42 35.6690279444983 139.7417694243162 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669025486727584 139.74185635971693 9.93 35.66904135457587 139.7418612018868 9.93 35.66904135457587 139.7418612018868 57.42 35.669025486727584 139.74185635971693 57.42 35.669025486727584 139.74185635971693 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904135457587 139.7418612018868 9.93 35.66915493925707 139.74187653683464 9.93 35.66915493925707 139.74187653683464 57.42 35.66904135457587 139.7418612018868 57.42 35.66904135457587 139.7418612018868 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66915493925707 139.74187653683464 9.93 35.669153955968696 139.74188736312502 9.93 35.669153955968696 139.74188736312502 57.42 35.66915493925707 139.74187653683464 57.42 35.66915493925707 139.74187653683464 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669153955968696 139.74188736312502 9.93 35.6692111088561 139.74189503021148 9.93 35.6692111088561 139.74189503021148 57.42 35.669153955968696 139.74188736312502 57.42 35.669153955968696 139.74188736312502 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6692111088561 139.74189503021148 9.93 35.669207176612446 139.7419395504707 9.93 35.669207176612446 139.7419395504707 57.42 35.6692111088561 139.74189503021148 57.42 35.6692111088561 139.74189503021148 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669207176612446 139.7419395504707 9.93 35.669227369451995 139.7419422889792 9.93 35.669227369451995 139.7419422889792 57.42 35.669207176612446 139.7419395504707 57.42 35.669207176612446 139.7419395504707 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669227369451995 139.7419422889792 9.93 35.66923067635543 139.74190517030982 9.93 35.66923067635543 139.74190517030982 57.42 35.669227369451995 139.7419422889792 57.42 35.669227369451995 139.7419422889792 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923067635543 139.74190517030982 9.93 35.66925636815485 139.7419086757677 9.93 35.66925636815485 139.7419086757677 57.42 35.66923067635543 139.74190517030982 57.42 35.66923067635543 139.74190517030982 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925636815485 139.7419086757677 9.93 35.6692580666714 139.74189011637458 9.93 35.6692580666714 139.74189011637458 57.42 35.66925636815485 139.7419086757677 57.42 35.66925636815485 139.7419086757677 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6692580666714 139.74189011637458 9.93 35.66931215463963 139.74189745558456 9.93 35.66931215463963 139.74189745558456 57.42 35.6692580666714 139.74189011637458 57.42 35.6692580666714 139.74189011637458 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931215463963 139.74189745558456 9.93 35.66933530413986 139.74163961284688 9.93 35.66933530413986 139.74163961284688 57.42 35.66931215463963 139.74189745558456 57.42 35.66931215463963 139.74189745558456 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66933530413986 139.74163961284688 9.93 35.669311505467604 139.7416364366902 9.93 35.669311505467604 139.7416364366902 57.42 35.66933530413986 139.74163961284688 57.42 35.66933530413986 139.74163961284688 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669311505467604 139.7416364366902 9.93 35.66931320394219 139.74161787727869 9.93 35.66931320394219 139.74161787727869 57.42 35.669311505467604 139.7416364366902 57.42 35.669311505467604 139.7416364366902 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931320394219 139.74161787727869 9.93 35.66926488541407 139.74161141534572 9.93 35.66926488541407 139.74161141534572 57.42 35.66931320394219 139.74161787727869 57.42 35.66931320394219 139.74161787727869 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66926488541407 139.74161141534572 9.93 35.66926417087871 139.74162003212567 9.93 35.66926417087871 139.74162003212567 57.42 35.66926488541407 139.74161141534572 57.42 35.66926488541407 139.74161141534572 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66926417087871 139.74162003212567 9.93 35.66914661970781 139.74160414975395 9.93 35.66914661970781 139.74160414975395 57.42 35.66926417087871 139.74162003212567 57.42 35.66926417087871 139.74162003212567 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914661970781 139.74160414975395 9.93 35.66914813899712 139.74158702657664 9.93 35.66914813899712 139.74158702657664 57.42 35.66914661970781 139.74160414975395 57.42 35.66914661970781 139.74160414975395 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914813899712 139.74158702657664 9.93 35.66910667173869 139.74158166144377 9.93 35.66910667173869 139.74158166144377 57.42 35.66914813899712 139.74158702657664 57.42 35.66914813899712 139.74158702657664 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910667173869 139.74158166144377 9.93 35.66910425831424 139.74160828526735 9.93 35.66910425831424 139.74160828526735 57.42 35.66910667173869 139.74158166144377 57.42 35.66910667173869 139.74158166144377 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910425831424 139.74160828526735 9.93 35.669092719652475 139.74160686247657 9.93 35.669092719652475 139.74160686247657 57.42 35.66910425831424 139.74160828526735 57.42 35.66910425831424 139.74160828526735 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669092719652475 139.74160686247657 9.93 35.669062925188896 139.74166069096128 9.93 35.669062925188896 139.74166069096128 57.42 35.669092719652475 139.74160686247657 57.42 35.669092719652475 139.74160686247657 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669062925188896 139.74166069096128 57.42 35.6690279444983 139.7417694243162 57.42 35.669025486727584 139.74185635971693 57.42 35.66904135457587 139.7418612018868 57.42 35.66915493925707 139.74187653683464 57.42 35.669153955968696 139.74188736312502 57.42 35.6692111088561 139.74189503021148 57.42 35.669207176612446 139.7419395504707 57.42 35.669227369451995 139.7419422889792 57.42 35.66923067635543 139.74190517030982 57.42 35.66925636815485 139.7419086757677 57.42 35.6692580666714 139.74189011637458 57.42 35.66931215463963 139.74189745558456 57.42 35.66933530413986 139.74163961284688 57.42 35.669311505467604 139.7416364366902 57.42 35.66931320394219 139.74161787727869 57.42 35.66926488541407 139.74161141534572 57.42 35.66926417087871 139.74162003212567 57.42 35.66914661970781 139.74160414975395 57.42 35.66914813899712 139.74158702657664 57.42 35.66910667173869 139.74158166144377 57.42 35.66910425831424 139.74160828526735 57.42 35.669092719652475 139.74160686247657 57.42 35.669062925188896 139.74166069096128 57.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-de230d8b-e0a8-4ebe-bf50-0208daeb65a9"/>
							<gml:surfaceMember xlink:href="#poly-47fbe693-4067-46a3-be83-561cf193a35f"/>
							<gml:surfaceMember xlink:href="#poly-6c7d9340-b9bf-4a20-8f91-44f649761d74"/>
							<gml:surfaceMember xlink:href="#poly-dbdb338b-0741-4fd1-bb22-894c1f2f1286"/>
							<gml:surfaceMember xlink:href="#poly-cc39dd61-ad1e-45a3-b7c2-78cc088df2e1"/>
							<gml:surfaceMember xlink:href="#poly-ccd3ec43-c37a-4e6e-8a07-f45b6e71af42"/>
							<gml:surfaceMember xlink:href="#poly-4f6b05b6-274c-4755-b693-486b5bb4aa93"/>
							<gml:surfaceMember xlink:href="#poly-457c9860-3a28-4026-b6de-6dbc4b916ab3"/>
							<gml:surfaceMember xlink:href="#poly-75d1168c-5fd3-4280-a81f-ba2e6395f669"/>
							<gml:surfaceMember xlink:href="#poly-fa924ad1-41be-41de-936d-880e4e1baa16"/>
							<gml:surfaceMember xlink:href="#poly-ba29ad4f-9692-41d0-8a53-c860f6b8728a"/>
							<gml:surfaceMember xlink:href="#poly-e86973ce-9a86-4427-8d72-01ccec5057cb"/>
							<gml:surfaceMember xlink:href="#poly-a7de2128-25bc-468f-9c56-71d369f945d7"/>
							<gml:surfaceMember xlink:href="#poly-9ebde336-d0e9-4628-a6d1-8f90b3b53bda"/>
							<gml:surfaceMember xlink:href="#poly-3695f0e8-9ccd-44a7-8e96-ba7432dda80a"/>
							<gml:surfaceMember xlink:href="#poly-124ea431-ce1e-497a-83f0-aecfb19735dc"/>
							<gml:surfaceMember xlink:href="#poly-1a0f630a-5f49-4cf8-8ff5-3eaa5399afe1"/>
							<gml:surfaceMember xlink:href="#poly-f9e94b20-d934-47cd-b9be-9f16350ffb81"/>
							<gml:surfaceMember xlink:href="#poly-78cb9dee-34fd-4d2f-b0db-c9e1c763ea3f"/>
							<gml:surfaceMember xlink:href="#poly-199608f1-a09e-4d7e-80ff-87ed886ea81e"/>
							<gml:surfaceMember xlink:href="#poly-57f4ce28-012b-4d61-b8af-8f60e3547fdb"/>
							<gml:surfaceMember xlink:href="#poly-be8dc0b1-ce4c-4360-8f5d-a507e87ab981"/>
							<gml:surfaceMember xlink:href="#poly-39393a0a-50ad-4d38-a7d0-a0da277bf03a"/>
							<gml:surfaceMember xlink:href="#poly-c93e56e9-58a3-4852-81ac-277e60c03ee3"/>
							<gml:surfaceMember xlink:href="#poly-8a304d9e-baa7-472a-bf45-91bb0746b0d9"/>
							<gml:surfaceMember xlink:href="#poly-78215963-dd2d-48aa-b406-f822f5d223f4"/>
							<gml:surfaceMember xlink:href="#poly-6a769f46-f1df-4596-8f5a-d71a542d62f9"/>
							<gml:surfaceMember xlink:href="#poly-6105ccf0-0bb5-4c54-bc71-c9a3399d4806"/>
							<gml:surfaceMember xlink:href="#poly-ac551440-0c05-49c9-aead-422fcca8b9ae"/>
							<gml:surfaceMember xlink:href="#poly-cf59fdbf-95bd-4f69-8418-7402a337950a"/>
							<gml:surfaceMember xlink:href="#poly-a147fe95-6c34-4bc6-9064-650d86522e0c"/>
							<gml:surfaceMember xlink:href="#poly-8331295b-0ada-4055-a612-2e13bf37aad1"/>
							<gml:surfaceMember xlink:href="#poly-82e5f3d4-1d8f-4a7f-9644-257dc887cd9d"/>
							<gml:surfaceMember xlink:href="#poly-10200f83-c12e-4971-80f9-515296fff88c"/>
							<gml:surfaceMember xlink:href="#poly-cae0cc47-d5c5-47c1-911e-804c0ce5ac88"/>
							<gml:surfaceMember xlink:href="#poly-5f949e30-448e-4773-adb4-0c4b817ba08a"/>
							<gml:surfaceMember xlink:href="#poly-f47124d5-9b7e-477a-91a6-50cbc721898a"/>
							<gml:surfaceMember xlink:href="#poly-7a06a6e5-31d7-4411-87fc-65bb7476c41b"/>
							<gml:surfaceMember xlink:href="#poly-e7416c96-a83c-424b-b3ad-1203504472bf"/>
							<gml:surfaceMember xlink:href="#poly-9114cf33-f8f1-4945-850d-ac6ce978d023"/>
							<gml:surfaceMember xlink:href="#poly-dda83f79-b5fc-4784-9c5c-3f733c96b287"/>
							<gml:surfaceMember xlink:href="#poly-ae966b75-914c-40f3-955a-794bbaacc3b0"/>
							<gml:surfaceMember xlink:href="#poly-a9f38bf8-e9cf-47a2-aec9-e8a1cabd1bac"/>
							<gml:surfaceMember xlink:href="#poly-6ebde8cf-41f0-4117-9c1e-1c09b2985561"/>
							<gml:surfaceMember xlink:href="#poly-b7894b93-3843-4e7c-b9b5-1035d289c312"/>
							<gml:surfaceMember xlink:href="#poly-7a387e62-e950-4e46-a984-996dfced8ee3"/>
							<gml:surfaceMember xlink:href="#poly-cdb8ea97-86ba-411b-a658-388ebd7b87b5"/>
							<gml:surfaceMember xlink:href="#poly-e33a5b2f-1999-475f-b2f6-5962f4b9b7d6"/>
							<gml:surfaceMember xlink:href="#poly-3e75946b-ca5a-4e57-bb17-476adede04ce"/>
							<gml:surfaceMember xlink:href="#poly-4e9f5e6e-170a-455f-9428-f23ebe38149e"/>
							<gml:surfaceMember xlink:href="#poly-6d94939c-091f-4e8c-b548-5d004024819d"/>
							<gml:surfaceMember xlink:href="#poly-b846a689-60a3-47a8-9683-4d663ba587f9"/>
							<gml:surfaceMember xlink:href="#poly-e96a3e30-a77b-4179-90ae-e113e1f0914e"/>
							<gml:surfaceMember xlink:href="#poly-d946b4f5-aefc-4808-ab13-54310b9c130c"/>
							<gml:surfaceMember xlink:href="#poly-a9cf02fb-12fa-425e-abaf-1e96bcaf60c1"/>
							<gml:surfaceMember xlink:href="#poly-7f607d2e-8ada-4ad8-9844-4b404463eff8"/>
							<gml:surfaceMember xlink:href="#poly-e2e2f505-6548-401e-abf7-39e408a727d1"/>
							<gml:surfaceMember xlink:href="#poly-35be615e-0828-4aa2-93bd-963d6656e105"/>
							<gml:surfaceMember xlink:href="#poly-e93c2623-162b-4c72-8056-d803d8392daa"/>
							<gml:surfaceMember xlink:href="#poly-239da7e3-a68b-4147-8cd8-c9cadd1417b8"/>
							<gml:surfaceMember xlink:href="#poly-4c54789f-7a92-4b88-9ccb-de1baa24549d"/>
							<gml:surfaceMember xlink:href="#poly-6e8f7509-7374-4cc6-8b17-4783f9f1b1f8"/>
							<gml:surfaceMember xlink:href="#poly-3b910275-956a-4173-a909-266abae3c512"/>
							<gml:surfaceMember xlink:href="#poly-4c6ccb8e-03fa-49eb-a846-7d4460412fed"/>
							<gml:surfaceMember xlink:href="#poly-705eb767-54d4-40f6-ad10-b89f7924ef7a"/>
							<gml:surfaceMember xlink:href="#poly-860c145d-b39c-45e3-b5b8-1046e471782e"/>
							<gml:surfaceMember xlink:href="#poly-faf7bcec-932b-479a-9357-70b60eb6383a"/>
							<gml:surfaceMember xlink:href="#poly-4618cd59-bcc2-4e45-8bd1-8bc1198045bc"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_fa0608fb-2bd9-4c08-8d14-e8d27e3f75c0_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87e77a8b-c9fc-49c2-97fb-5cfa192890b7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910821901741 139.74163677963398 55.602 35.66910597913723 139.74166641883895 55.602 35.6691102429991 139.74166689999203 55.602 35.669108663528014 139.7416878672659 55.602 35.66908709180947 139.74168542864575 55.602 35.669088644491254 139.74166479279052 55.602 35.66909418841141 139.74166541607906 55.602 35.66909644606645 139.7416354454756 55.602 35.66910821901741 139.74163677963398 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7543ee1d-acf2-4aa0-a7e2-8c1298cc61d0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925513131751 139.7416571352845 55.602 35.66927406183809 139.7416593449536 55.602 35.669272267737355 139.74168254382943 55.602 35.6692533372172 139.7416803341549 55.602 35.66925513131751 139.7416571352845 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b312798e-6fdc-407b-bb0d-68d3c9a4036b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923000760396 139.7416657689229 55.608 35.66924414264632 139.7416677521075 55.608 35.66924255119375 139.7416848201558 55.608 35.66922840713793 139.7416828369785 55.608 35.66923000760396 139.7416657689229 55.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21eec5cd-8610-4bbf-af0c-f5c6997efa13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669202255672815 139.74169122876643 55.602 35.669192312576016 139.7416899808759 55.602 35.669193277314704 139.7416784918333 55.602 35.669203220411624 139.7416797397225 55.602 35.669202255672815 139.74169122876643 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d2dba64-086f-4786-bc2e-e77a73634c56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669206917333554 139.74168143659568 55.602 35.66921688747159 139.74168268445453 55.602 35.66921588701387 139.7416946153852 55.602 35.66920591686755 139.7416933564788 55.602 35.669206917333554 139.74168143659568 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88351bf1-70bb-4425-9091-366b88348452">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66928425109606 139.74165241843983 55.602 35.66927849334262 139.74172613570067 55.602 35.66906457643894 139.74169849979947 55.602 35.669065121619106 139.74169237964898 55.602 35.66927371098425 139.74171945826973 55.602 35.669279004544826 139.74165168434965 55.602 35.66928425109606 139.74165241843983 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22ad9f20-184f-4b55-8d06-8ef1e60181ca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669227736606814 139.74169006189487 55.598 35.66922840713793 139.7416828369785 55.598 35.66925918330654 139.74168715396533 55.598 35.66925828027613 139.74169682033934 55.598 35.66924467711127 139.7416949249102 55.598 35.66924191672583 139.7416920560783 55.598 35.669227736606814 139.74169006189487 55.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1905d855-0187-4bde-ab4a-b168f3a6b07f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669250352591206 139.74171444793544 55.602 35.66925115458922 139.74170230735072 55.602 35.66927150011248 139.74170431658342 55.602 35.66927067135043 139.7417168217233 55.602 35.669250352591206 139.74171444793544 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e579ac13-2370-40bf-860f-2bf4acd5fd6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e579ac13-2370-40bf-860f-2bf4acd5fd6e_0">
											<gml:posList>35.66922840713793 139.7416828369785 55.608 35.66924255119375 139.7416848201558 55.608 35.66924255119375 139.7416848201558 59.648 35.66922840713793 139.7416828369785 59.648 35.66922840713793 139.7416828369785 55.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6d939a1-395e-425d-8a70-9f96afd0ce64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6d939a1-395e-425d-8a70-9f96afd0ce64_0">
											<gml:posList>35.66924467711127 139.7416949249102 60.625 35.66924191672583 139.7416920560783 60.625 35.66924191672583 139.7416920560783 55.598 35.66924467711127 139.7416949249102 55.598 35.66924467711127 139.7416949249102 60.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdca79c9-ae34-4aea-b6cf-b5f762cbb1c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdca79c9-ae34-4aea-b6cf-b5f762cbb1c2_0">
											<gml:posList>35.66925828027613 139.74169682033934 60.625 35.66924467711127 139.7416949249102 60.625 35.66924467711127 139.7416949249102 55.598 35.66925828027613 139.74169682033934 55.598 35.66925828027613 139.74169682033934 60.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c03a5f4-ef56-4939-a1df-64a4bab97e94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c03a5f4-ef56-4939-a1df-64a4bab97e94_0">
											<gml:posList>35.66927067135043 139.7417168217233 55.602 35.66927150011248 139.74170431658342 55.602 35.66927150011248 139.74170431658342 60.501 35.66927067135043 139.7417168217233 60.501 35.66927067135043 139.7417168217233 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e99c0bf-3d5a-4c31-b55c-351c5cf6351c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e99c0bf-3d5a-4c31-b55c-351c5cf6351c_0">
											<gml:posList>35.669250352591206 139.74171444793544 55.602 35.66927067135043 139.7417168217233 55.602 35.66927067135043 139.7417168217233 60.501 35.669250352591206 139.74171444793544 60.501 35.669250352591206 139.74171444793544 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc40523a-1383-4dfe-9f10-889b5a9c861d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc40523a-1383-4dfe-9f10-889b5a9c861d_0">
											<gml:posList>35.66909644606645 139.7416354454756 55.602 35.66909644606645 139.7416354454756 60.694 35.66910821901741 139.74163677963398 60.694 35.66910821901741 139.74163677963398 55.602 35.66909644606645 139.7416354454756 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3256a18f-e7c2-44cc-be5b-b0cb3659e0fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3256a18f-e7c2-44cc-be5b-b0cb3659e0fb_0">
											<gml:posList>35.66909644606645 139.7416354454756 55.602 35.66909418841141 139.74166541607906 55.602 35.66909418841141 139.74166541607906 60.694 35.66909644606645 139.7416354454756 60.694 35.66909644606645 139.7416354454756 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17333a17-84fa-4ef4-9894-bea59f22a8eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17333a17-84fa-4ef4-9894-bea59f22a8eb_0">
											<gml:posList>35.66910597913723 139.74166641883895 55.602 35.66910821901741 139.74163677963398 55.602 35.66910821901741 139.74163677963398 60.694 35.66910597913723 139.74166641883895 60.694 35.66910597913723 139.74166641883895 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f21feda-b90a-4b93-a443-3dd8c8365b22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f21feda-b90a-4b93-a443-3dd8c8365b22_0">
											<gml:posList>35.66928425109606 139.74165241843983 55.602 35.669279004544826 139.74165168434965 55.602 35.669279004544826 139.74165168434965 60.755 35.66928425109606 139.74165241843983 60.755 35.66928425109606 139.74165241843983 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e4c57e4-8e69-48a4-96de-8eefb69fc561">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e4c57e4-8e69-48a4-96de-8eefb69fc561_0">
											<gml:posList>35.66927406183809 139.7416593449536 55.602 35.66925513131751 139.7416571352845 55.602 35.66925513131751 139.7416571352845 61.145 35.66927406183809 139.7416593449536 61.145 35.66927406183809 139.7416593449536 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06a827d7-cfc1-4bdd-b1a7-de33a4248b42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06a827d7-cfc1-4bdd-b1a7-de33a4248b42_0">
											<gml:posList>35.66909418841141 139.74166541607906 60.694 35.669088644491254 139.74166479279052 60.694 35.66908709180947 139.74168542864575 60.694 35.669108663528014 139.7416878672659 60.694 35.6691102429991 139.74166689999203 60.694 35.66910597913723 139.74166641883895 60.694 35.66910821901741 139.74163677963398 60.694 35.66909644606645 139.7416354454756 60.694 35.66909418841141 139.74166541607906 60.694</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de287815-9f9c-496a-9af8-f8f4e68fcb4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de287815-9f9c-496a-9af8-f8f4e68fcb4a_0">
											<gml:posList>35.66909418841141 139.74166541607906 55.602 35.669088644491254 139.74166479279052 55.602 35.669088644491254 139.74166479279052 60.694 35.66909418841141 139.74166541607906 60.694 35.66909418841141 139.74166541607906 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-129a5f15-853f-40df-99ba-d64f3fce8643">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-129a5f15-853f-40df-99ba-d64f3fce8643_0">
											<gml:posList>35.6691102429991 139.74166689999203 55.602 35.66910597913723 139.74166641883895 55.602 35.66910597913723 139.74166641883895 60.694 35.6691102429991 139.74166689999203 60.694 35.6691102429991 139.74166689999203 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e3a9826-25f7-4b09-806e-9eecd8ae50dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e3a9826-25f7-4b09-806e-9eecd8ae50dd_0">
											<gml:posList>35.66924414264632 139.7416677521075 55.608 35.66923000760396 139.7416657689229 55.608 35.66923000760396 139.7416657689229 59.648 35.66924414264632 139.7416677521075 59.648 35.66924414264632 139.7416677521075 55.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91ae068e-cabd-46a9-8a1c-6c795ee00dec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91ae068e-cabd-46a9-8a1c-6c795ee00dec_0">
											<gml:posList>35.66925513131751 139.7416571352845 55.602 35.6692533372172 139.7416803341549 55.602 35.6692533372172 139.7416803341549 61.145 35.66925513131751 139.7416571352845 61.145 35.66925513131751 139.7416571352845 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-902a4d08-82f5-4b06-a9db-16d5c5130e93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-902a4d08-82f5-4b06-a9db-16d5c5130e93_0">
											<gml:posList>35.669272267737355 139.74168254382943 61.145 35.66927406183809 139.7416593449536 61.145 35.66925513131751 139.7416571352845 61.145 35.6692533372172 139.7416803341549 61.145 35.669272267737355 139.74168254382943 61.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d0f0c16-f019-42c2-975f-1a8205f5c577">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d0f0c16-f019-42c2-975f-1a8205f5c577_0">
											<gml:posList>35.669272267737355 139.74168254382943 55.602 35.66927406183809 139.7416593449536 55.602 35.66927406183809 139.7416593449536 61.145 35.669272267737355 139.74168254382943 61.145 35.669272267737355 139.74168254382943 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5ddf691-571b-4c45-8775-e235715a0595">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5ddf691-571b-4c45-8775-e235715a0595_0">
											<gml:posList>35.66923000760396 139.7416657689229 55.608 35.66922840713793 139.7416828369785 55.608 35.66922840713793 139.7416828369785 59.648 35.66923000760396 139.7416657689229 59.648 35.66923000760396 139.7416657689229 55.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97541e76-85a4-40ce-bd8f-5a36e4319b6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97541e76-85a4-40ce-bd8f-5a36e4319b6e_0">
											<gml:posList>35.669088644491254 139.74166479279052 55.602 35.66908709180947 139.74168542864575 55.602 35.66908709180947 139.74168542864575 60.694 35.669088644491254 139.74166479279052 60.694 35.669088644491254 139.74166479279052 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc09f7ea-30a7-49f2-8f81-4f5afb754c77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc09f7ea-30a7-49f2-8f81-4f5afb754c77_0">
											<gml:posList>35.66924414264632 139.7416677521075 59.648 35.66923000760396 139.7416657689229 59.648 35.66922840713793 139.7416828369785 59.648 35.66924255119375 139.7416848201558 59.648 35.66924414264632 139.7416677521075 59.648</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bc28cb3-aaed-4861-ae97-52941eb2bc2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bc28cb3-aaed-4861-ae97-52941eb2bc2f_0">
											<gml:posList>35.66924255119375 139.7416848201558 55.608 35.66924414264632 139.7416677521075 55.608 35.66924414264632 139.7416677521075 59.648 35.66924255119375 139.7416848201558 59.648 35.66924255119375 139.7416848201558 55.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d984b1cd-5d2d-4962-9826-301754dd7763">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d984b1cd-5d2d-4962-9826-301754dd7763_0">
											<gml:posList>35.6691102429991 139.74166689999203 55.602 35.6691102429991 139.74166689999203 60.694 35.669108663528014 139.7416878672659 60.694 35.669108663528014 139.7416878672659 55.602 35.6691102429991 139.74166689999203 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96276cf0-3b14-4bf2-b90d-038d6c0b4fd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96276cf0-3b14-4bf2-b90d-038d6c0b4fd1_0">
											<gml:posList>35.669203220411624 139.7416797397225 55.602 35.669193277314704 139.7416784918333 55.602 35.669193277314704 139.7416784918333 68.121 35.669203220411624 139.7416797397225 68.121 35.669203220411624 139.7416797397225 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2248d1f6-c1d1-41ff-a28e-cf765260813e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2248d1f6-c1d1-41ff-a28e-cf765260813e_0">
											<gml:posList>35.6692533372172 139.7416803341549 55.602 35.669272267737355 139.74168254382943 55.602 35.669272267737355 139.74168254382943 61.145 35.6692533372172 139.7416803341549 61.145 35.6692533372172 139.7416803341549 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-756afcb9-5400-46ec-a988-f6376e19f8c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-756afcb9-5400-46ec-a988-f6376e19f8c7_0">
											<gml:posList>35.66921688747159 139.74168268445453 55.602 35.669206917333554 139.74168143659568 55.602 35.669206917333554 139.74168143659568 67.592 35.66921688747159 139.74168268445453 67.592 35.66921688747159 139.74168268445453 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b6f00d1-a2b8-453b-bc8d-248f96f7114b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b6f00d1-a2b8-453b-bc8d-248f96f7114b_0">
											<gml:posList>35.669193277314704 139.7416784918333 55.602 35.669192312576016 139.7416899808759 55.602 35.669192312576016 139.7416899808759 68.121 35.669193277314704 139.7416784918333 68.121 35.669193277314704 139.7416784918333 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0252385b-4ede-44f4-9333-f11736db691c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0252385b-4ede-44f4-9333-f11736db691c_0">
											<gml:posList>35.669193277314704 139.7416784918333 68.121 35.669192312576016 139.7416899808759 68.121 35.669202255672815 139.74169122876643 68.121 35.669203220411624 139.7416797397225 68.121 35.669193277314704 139.7416784918333 68.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d334026d-0657-4c1e-8f6c-07470c626567">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d334026d-0657-4c1e-8f6c-07470c626567_0">
											<gml:posList>35.66922840713793 139.7416828369785 60.625 35.66925918330654 139.74168715396533 60.625 35.66925918330654 139.74168715396533 55.598 35.66922840713793 139.7416828369785 55.598 35.66922840713793 139.7416828369785 60.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adf233dc-8d2b-49b7-a525-a2060b2d148f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adf233dc-8d2b-49b7-a525-a2060b2d148f_0">
											<gml:posList>35.669202255672815 139.74169122876643 55.602 35.669203220411624 139.7416797397225 55.602 35.669203220411624 139.7416797397225 68.121 35.669202255672815 139.74169122876643 68.121 35.669202255672815 139.74169122876643 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1611590a-73d8-479f-abf4-a6df6c2f3029">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1611590a-73d8-479f-abf4-a6df6c2f3029_0">
											<gml:posList>35.669279004544826 139.74165168434965 55.602 35.66927371098425 139.74171945826973 55.602 35.66927371098425 139.74171945826973 60.755 35.669279004544826 139.74165168434965 60.755 35.669279004544826 139.74165168434965 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faa88868-62d7-4950-b7f5-7787b1c2cac1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-faa88868-62d7-4950-b7f5-7787b1c2cac1_0">
											<gml:posList>35.669227736606814 139.74169006189487 60.625 35.66922840713793 139.7416828369785 60.625 35.66922840713793 139.7416828369785 55.598 35.669227736606814 139.74169006189487 55.598 35.669227736606814 139.74169006189487 60.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14b4862a-2304-4ff4-94c7-b12baf148cee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14b4862a-2304-4ff4-94c7-b12baf148cee_0">
											<gml:posList>35.66908709180947 139.74168542864575 55.602 35.669108663528014 139.7416878672659 55.602 35.669108663528014 139.7416878672659 60.694 35.66908709180947 139.74168542864575 60.694 35.66908709180947 139.74168542864575 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ffb9147-ef59-47f0-865e-4610c4f8761d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ffb9147-ef59-47f0-865e-4610c4f8761d_0">
											<gml:posList>35.669206917333554 139.74168143659568 55.602 35.66920591686755 139.7416933564788 55.602 35.66920591686755 139.7416933564788 67.592 35.669206917333554 139.74168143659568 67.592 35.669206917333554 139.74168143659568 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-544a507d-4840-4fd1-8b52-6ff195f1b65b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-544a507d-4840-4fd1-8b52-6ff195f1b65b_0">
											<gml:posList>35.66921588701387 139.7416946153852 67.592 35.66921688747159 139.74168268445453 67.592 35.669206917333554 139.74168143659568 67.592 35.66920591686755 139.7416933564788 67.592 35.66921588701387 139.7416946153852 67.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-003c49ce-27d8-48e4-90c8-11c3a2cdd204">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-003c49ce-27d8-48e4-90c8-11c3a2cdd204_0">
											<gml:posList>35.66921688747159 139.74168268445453 55.602 35.66921688747159 139.74168268445453 67.592 35.66921588701387 139.7416946153852 67.592 35.66921588701387 139.7416946153852 55.602 35.66921688747159 139.74168268445453 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06e2df49-5344-4ffb-9680-af5f1be0cdc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06e2df49-5344-4ffb-9680-af5f1be0cdc1_0">
											<gml:posList>35.66927371098425 139.74171945826973 60.755 35.669065121619106 139.74169237964898 60.755 35.66906457643894 139.74169849979947 60.755 35.66927849334262 139.74172613570067 60.755 35.66928425109606 139.74165241843983 60.755 35.669279004544826 139.74165168434965 60.755 35.66927371098425 139.74171945826973 60.755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-913b41da-8cd8-45fc-94e2-c4d36ba4905a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-913b41da-8cd8-45fc-94e2-c4d36ba4905a_0">
											<gml:posList>35.66928425109606 139.74165241843983 55.602 35.66928425109606 139.74165241843983 60.755 35.66927849334262 139.74172613570067 60.755 35.66927849334262 139.74172613570067 55.602 35.66928425109606 139.74165241843983 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a465e62-8942-4256-98ad-8232d57e8c55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a465e62-8942-4256-98ad-8232d57e8c55_0">
											<gml:posList>35.66924467711127 139.7416949249102 60.625 35.66925828027613 139.74169682033934 60.625 35.66925918330654 139.74168715396533 60.625 35.66922840713793 139.7416828369785 60.625 35.669227736606814 139.74169006189487 60.625 35.66924191672583 139.7416920560783 60.625 35.66924467711127 139.7416949249102 60.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f5bf2e8-ca37-4d2c-8115-c049af24f47e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f5bf2e8-ca37-4d2c-8115-c049af24f47e_0">
											<gml:posList>35.669192312576016 139.7416899808759 55.602 35.669202255672815 139.74169122876643 55.602 35.669202255672815 139.74169122876643 68.121 35.669192312576016 139.7416899808759 68.121 35.669192312576016 139.7416899808759 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47169fd4-4935-4a1f-98bd-5a7dc00e16d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47169fd4-4935-4a1f-98bd-5a7dc00e16d0_0">
											<gml:posList>35.66924191672583 139.7416920560783 60.625 35.669227736606814 139.74169006189487 60.625 35.669227736606814 139.74169006189487 55.598 35.66924191672583 139.7416920560783 55.598 35.66924191672583 139.7416920560783 60.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62eef99e-291a-4ffa-b58d-7a35fc40e4f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62eef99e-291a-4ffa-b58d-7a35fc40e4f0_0">
											<gml:posList>35.66925918330654 139.74168715396533 60.625 35.66925828027613 139.74169682033934 60.625 35.66925828027613 139.74169682033934 55.598 35.66925918330654 139.74168715396533 55.598 35.66925918330654 139.74168715396533 60.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-312805bb-fd7e-4a10-9d36-21d5cd66bb3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-312805bb-fd7e-4a10-9d36-21d5cd66bb3d_0">
											<gml:posList>35.66920591686755 139.7416933564788 55.602 35.66921588701387 139.7416946153852 55.602 35.66921588701387 139.7416946153852 67.592 35.66920591686755 139.7416933564788 67.592 35.66920591686755 139.7416933564788 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cc8a060-fe2e-4f30-aa26-c9101a078756">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cc8a060-fe2e-4f30-aa26-c9101a078756_0">
											<gml:posList>35.66906457643894 139.74169849979947 55.602 35.66906457643894 139.74169849979947 60.755 35.669065121619106 139.74169237964898 60.755 35.669065121619106 139.74169237964898 55.602 35.66906457643894 139.74169849979947 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62d21c65-6757-4412-a083-01abef3fd82d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62d21c65-6757-4412-a083-01abef3fd82d_0">
											<gml:posList>35.66925115458922 139.74170230735072 55.602 35.66925115458922 139.74170230735072 60.501 35.66927150011248 139.74170431658342 60.501 35.66927150011248 139.74170431658342 55.602 35.66925115458922 139.74170230735072 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94d465af-5ced-423a-bb97-fb14b36f7321">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94d465af-5ced-423a-bb97-fb14b36f7321_0">
											<gml:posList>35.669065121619106 139.74169237964898 55.602 35.669065121619106 139.74169237964898 60.755 35.66927371098425 139.74171945826973 60.755 35.66927371098425 139.74171945826973 55.602 35.669065121619106 139.74169237964898 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76683184-8f4b-41c0-b377-ce79488adf29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76683184-8f4b-41c0-b377-ce79488adf29_0">
											<gml:posList>35.66925115458922 139.74170230735072 55.602 35.669250352591206 139.74171444793544 55.602 35.669250352591206 139.74171444793544 60.501 35.66925115458922 139.74170230735072 60.501 35.66925115458922 139.74170230735072 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a48ee72-3a79-4273-9bab-7e3fd790c65e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a48ee72-3a79-4273-9bab-7e3fd790c65e_0">
											<gml:posList>35.669250352591206 139.74171444793544 60.501 35.66927067135043 139.7417168217233 60.501 35.66927150011248 139.74170431658342 60.501 35.66925115458922 139.74170230735072 60.501 35.669250352591206 139.74171444793544 60.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84d967d2-82db-4da9-a8d3-288d8042b838">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84d967d2-82db-4da9-a8d3-288d8042b838_0">
											<gml:posList>35.66906457643894 139.74169849979947 55.602 35.66927849334262 139.74172613570067 55.602 35.66927849334262 139.74172613570067 60.755 35.66906457643894 139.74169849979947 60.755 35.66906457643894 139.74169849979947 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-de230d8b-e0a8-4ebe-bf50-0208daeb65a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de230d8b-e0a8-4ebe-bf50-0208daeb65a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de230d8b-e0a8-4ebe-bf50-0208daeb65a9">
											<gml:posList>35.66931150546759 139.7416364366902 9.93 35.66933530413984 139.74163961284688 9.93 35.66931215463963 139.74189745558456 9.93 35.66925806667139 139.74189011637458 9.93 35.66925636815482 139.74190867576766 9.93 35.669230676355426 139.74190517030982 9.93 35.66922736945199 139.7419422889792 9.93 35.66920717661246 139.74193955047068 9.93 35.6692111088561 139.74189503021148 9.93 35.6691539559687 139.74188736312502 9.93 35.66915493925706 139.7418765368346 9.93 35.66904135457587 139.7418612018868 9.93 35.66902548672759 139.74185635971696 9.93 35.669027944498296 139.7417694243162 9.93 35.66906292518889 139.74166069096128 9.93 35.669092719652475 139.74160686247654 9.93 35.66910425831423 139.74160828526735 9.93 35.66910667173867 139.74158166144375 9.93 35.66914813899708 139.74158702657664 9.93 35.669146619707774 139.74160414975395 9.93 35.66926417087871 139.74162003212564 9.93 35.66926488541407 139.74161141534572 9.93 35.66931320394216 139.74161787727869 9.93 35.66931150546759 139.7416364366902 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47fbe693-4067-46a3-be83-561cf193a35f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47fbe693-4067-46a3-be83-561cf193a35f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47fbe693-4067-46a3-be83-561cf193a35f">
											<gml:posList>35.669027944498296 139.7417694243162 16.5 35.66902548672759 139.74185635971696 16.5 35.66904135457587 139.7418612018868 16.5 35.66905670240616 139.74168002871104 16.5 35.669027944498296 139.7417694243162 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c7d9340-b9bf-4a20-8f91-44f649761d74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c7d9340-b9bf-4a20-8f91-44f649761d74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c7d9340-b9bf-4a20-8f91-44f649761d74">
											<gml:posList>35.66905670240616 139.74168002871104 57.9 35.669058658804865 139.7416805787786 57.9 35.66906468375666 139.74166185983498 57.9 35.66909370410903 139.74160943508753 57.9 35.66910601802681 139.74161095640662 57.9 35.669108431460245 139.7415843436286 57.9 35.66910667173867 139.74158166144375 57.9 35.66910425831423 139.74160828526735 57.9 35.669092719652475 139.74160686247654 57.9 35.66906292518889 139.74166069096128 57.9 35.66905670240616 139.74168002871104 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbdb338b-0741-4fd1-bb22-894c1f2f1286">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbdb338b-0741-4fd1-bb22-894c1f2f1286">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbdb338b-0741-4fd1-bb22-894c1f2f1286">
											<gml:posList>35.66910601802681 139.74161095640662 55.602 35.66909370410903 139.74160943508753 55.602 35.66906468375666 139.74166185983498 55.602 35.669058658804865 139.7416805787786 55.602 35.6690435432664 139.74185903435912 55.602 35.66912178399569 139.74169507640988 55.602 35.66912966077475 139.74161059797817 55.602 35.669108431460245 139.7415843436286 55.602 35.66910601802681 139.74161095640662 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc39dd61-ad1e-45a3-b7c2-78cc088df2e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc39dd61-ad1e-45a3-b7c2-78cc088df2e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc39dd61-ad1e-45a3-b7c2-78cc088df2e1">
											<gml:posList>35.66912966077475 139.74161059797817 66.421 35.66912178399569 139.74169507640988 66.421 35.6691249364624 139.74169200199486 66.421 35.66913216954353 139.74161447228502 66.421 35.66912966077475 139.74161059797817 66.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ccd3ec43-c37a-4e6e-8a07-f45b6e71af42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccd3ec43-c37a-4e6e-8a07-f45b6e71af42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccd3ec43-c37a-4e6e-8a07-f45b6e71af42">
											<gml:posList>35.66910667173867 139.74158166144375 57.9 35.669108431460245 139.7415843436286 57.9 35.66914595031993 139.74158920516064 57.9 35.66914813899708 139.74158702657664 57.9 35.66910667173867 139.74158166144375 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f6b05b6-274c-4755-b693-486b5bb4aa93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f6b05b6-274c-4755-b693-486b5bb4aa93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f6b05b6-274c-4755-b693-486b5bb4aa93">
											<gml:posList>35.669146619707774 139.74160414975395 57.9 35.66914813899708 139.74158702657664 57.9 35.66914595031993 139.74158920516064 57.9 35.669144421999746 139.74160630625562 57.9 35.669146619707774 139.74160414975395 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-457c9860-3a28-4026-b6de-6dbc4b916ab3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-457c9860-3a28-4026-b6de-6dbc4b916ab3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-457c9860-3a28-4026-b6de-6dbc4b916ab3">
											<gml:posList>35.6692234039533 139.74170578544746 66.421 35.6691249364624 139.74169200199486 66.421 35.66912178399569 139.74169507640988 66.421 35.669225912719 139.74170965976185 66.421 35.6692234039533 139.74170578544746 66.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-75d1168c-5fd3-4280-a81f-ba2e6395f669">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75d1168c-5fd3-4280-a81f-ba2e6395f669">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75d1168c-5fd3-4280-a81f-ba2e6395f669">
											<gml:posList>35.66915493925706 139.7418765368346 57.9 35.6691539559687 139.74188736312502 57.9 35.6692111088561 139.74189503021148 57.9 35.66920717661246 139.74193955047068 57.9 35.66922736945199 139.7419422889792 57.9 35.669230676355426 139.74190517030982 57.9 35.66925636815482 139.74190867576766 57.9 35.66925806667139 139.74189011637458 57.9 35.66931215463963 139.74189745558456 57.9 35.669310385902946 139.74189476235023 57.9 35.669258272141576 139.74188768599714 57.9 35.66915515374072 139.74187410644998 57.9 35.6690435432664 139.74185903435912 57.9 35.669058658804865 139.7416805787786 57.9 35.66905670240616 139.74168002871104 57.9 35.66904135457587 139.7418612018868 57.9 35.66915493925706 139.7418765368346 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa924ad1-41be-41de-936d-880e4e1baa16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa924ad1-41be-41de-936d-880e4e1baa16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa924ad1-41be-41de-936d-880e4e1baa16">
											<gml:posList>35.6690435432664 139.74185903435912 55.602 35.66915515374072 139.74187410644998 55.602 35.669258272141576 139.74188768599714 55.602 35.669310385902946 139.74189476235023 55.602 35.669225912719 139.74170965976185 55.602 35.66912178399569 139.74169507640988 55.602 35.6690435432664 139.74185903435912 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba29ad4f-9692-41d0-8a53-c860f6b8728a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba29ad4f-9692-41d0-8a53-c860f6b8728a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba29ad4f-9692-41d0-8a53-c860f6b8728a">
											<gml:posList>35.6692234039533 139.74170578544746 65.198 35.66923063704304 139.74162825564363 65.198 35.66913216954353 139.74161447228502 65.198 35.6691249364624 139.74169200199486 65.198 35.6692234039533 139.74170578544746 65.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e86973ce-9a86-4427-8d72-01ccec5057cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e86973ce-9a86-4427-8d72-01ccec5057cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e86973ce-9a86-4427-8d72-01ccec5057cb">
											<gml:posList>35.66912966077475 139.74161059797817 66.421 35.66913216954353 139.74161447228502 66.421 35.66923063704304 139.74162825564363 66.421 35.66923378950799 139.74162518122182 66.421 35.66912966077475 139.74161059797817 66.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7de2128-25bc-468f-9c56-71d369f945d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7de2128-25bc-468f-9c56-71d369f945d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7de2128-25bc-468f-9c56-71d369f945d7">
											<gml:posList>35.66926417087871 139.74162003212564 57.9 35.669146619707774 139.74160414975395 57.9 35.669144421999746 139.74160630625562 57.9 35.669265939621546 139.74162272535239 57.9 35.66926417087871 139.74162003212564 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ebde336-d0e9-4628-a6d1-8f90b3b53bda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ebde336-d0e9-4628-a6d1-8f90b3b53bda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ebde336-d0e9-4628-a6d1-8f90b3b53bda">
											<gml:posList>35.669225912719 139.74170965976185 55.602 35.669310385902946 139.74189476235023 55.602 35.66933310643125 139.74164176935264 55.602 35.669309298745326 139.74163859320572 55.602 35.66931099722023 139.74162003379473 55.602 35.66926665414868 139.74161409752622 55.602 35.669265939621546 139.74162272535239 55.602 35.669144421999746 139.74160630625562 55.602 35.66914595031993 139.74158920516064 55.602 35.669108431460245 139.7415843436286 55.602 35.66912966077475 139.74161059797817 55.602 35.66923378950799 139.74162518122182 55.602 35.669225912719 139.74170965976185 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3695f0e8-9ccd-44a7-8e96-ba7432dda80a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3695f0e8-9ccd-44a7-8e96-ba7432dda80a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3695f0e8-9ccd-44a7-8e96-ba7432dda80a">
											<gml:posList>35.669225912719 139.74170965976185 66.421 35.66923378950799 139.74162518122182 66.421 35.66923063704304 139.74162825564363 66.421 35.6692234039533 139.74170578544746 66.421 35.669225912719 139.74170965976185 66.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-124ea431-ce1e-497a-83f0-aecfb19735dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-124ea431-ce1e-497a-83f0-aecfb19735dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-124ea431-ce1e-497a-83f0-aecfb19735dc">
											<gml:posList>35.66926417087871 139.74162003212564 57.9 35.669265939621546 139.74162272535239 57.9 35.66926665414868 139.74161409752622 57.9 35.66926488541407 139.74161141534572 57.9 35.66926417087871 139.74162003212564 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a0f630a-5f49-4cf8-8ff5-3eaa5399afe1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a0f630a-5f49-4cf8-8ff5-3eaa5399afe1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a0f630a-5f49-4cf8-8ff5-3eaa5399afe1">
											<gml:posList>35.66926488541407 139.74161141534572 57.9 35.66926665414868 139.74161409752622 57.9 35.66931099722023 139.74162003379473 57.9 35.66931320394216 139.74161787727869 57.9 35.66926488541407 139.74161141534572 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9e94b20-d934-47cd-b9be-9f16350ffb81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9e94b20-d934-47cd-b9be-9f16350ffb81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9e94b20-d934-47cd-b9be-9f16350ffb81">
											<gml:posList>35.66931150546759 139.7416364366902 57.9 35.66931320394216 139.74161787727869 57.9 35.66931099722023 139.74162003379473 57.9 35.669309298745326 139.74163859320572 57.9 35.66931150546759 139.7416364366902 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78cb9dee-34fd-4d2f-b0db-c9e1c763ea3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78cb9dee-34fd-4d2f-b0db-c9e1c763ea3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78cb9dee-34fd-4d2f-b0db-c9e1c763ea3f">
											<gml:posList>35.66931150546759 139.7416364366902 57.9 35.669309298745326 139.74163859320572 57.9 35.66933310643125 139.74164176935264 57.9 35.66933530413984 139.74163961284688 57.9 35.66931150546759 139.7416364366902 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-199608f1-a09e-4d7e-80ff-87ed886ea81e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-199608f1-a09e-4d7e-80ff-87ed886ea81e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-199608f1-a09e-4d7e-80ff-87ed886ea81e">
											<gml:posList>35.66933530413984 139.74163961284688 57.9 35.66933310643125 139.74164176935264 57.9 35.669310385902946 139.74189476235023 57.9 35.66931215463963 139.74189745558456 57.9 35.66933530413984 139.74163961284688 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57f4ce28-012b-4d61-b8af-8f60e3547fdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57f4ce28-012b-4d61-b8af-8f60e3547fdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57f4ce28-012b-4d61-b8af-8f60e3547fdb">
											<gml:posList>35.66910667173867 139.74158166144375 57.9 35.66914813899708 139.74158702657664 57.9 35.66914813899708 139.74158702657664 9.93 35.66910667173867 139.74158166144375 9.93 35.66910667173867 139.74158166144375 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be8dc0b1-ce4c-4360-8f5d-a507e87ab981">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be8dc0b1-ce4c-4360-8f5d-a507e87ab981">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be8dc0b1-ce4c-4360-8f5d-a507e87ab981">
											<gml:posList>35.66914595031993 139.74158920516064 55.602 35.66914595031993 139.74158920516064 57.9 35.669108431460245 139.7415843436286 57.9 35.669108431460245 139.7415843436286 55.602 35.66914595031993 139.74158920516064 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39393a0a-50ad-4d38-a7d0-a0da277bf03a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39393a0a-50ad-4d38-a7d0-a0da277bf03a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39393a0a-50ad-4d38-a7d0-a0da277bf03a">
											<gml:posList>35.66910667173867 139.74158166144375 57.9 35.66910667173867 139.74158166144375 9.93 35.66910425831423 139.74160828526735 9.93 35.66910425831423 139.74160828526735 57.9 35.66910667173867 139.74158166144375 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c93e56e9-58a3-4852-81ac-277e60c03ee3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c93e56e9-58a3-4852-81ac-277e60c03ee3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c93e56e9-58a3-4852-81ac-277e60c03ee3">
											<gml:posList>35.669146619707774 139.74160414975395 57.9 35.669146619707774 139.74160414975395 9.93 35.66914813899708 139.74158702657664 9.93 35.66914813899708 139.74158702657664 57.9 35.669146619707774 139.74160414975395 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a304d9e-baa7-472a-bf45-91bb0746b0d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a304d9e-baa7-472a-bf45-91bb0746b0d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a304d9e-baa7-472a-bf45-91bb0746b0d9">
											<gml:posList>35.66910601802681 139.74161095640662 57.9 35.66910601802681 139.74161095640662 55.602 35.669108431460245 139.7415843436286 55.602 35.669108431460245 139.7415843436286 57.9 35.66910601802681 139.74161095640662 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78215963-dd2d-48aa-b406-f822f5d223f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78215963-dd2d-48aa-b406-f822f5d223f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78215963-dd2d-48aa-b406-f822f5d223f4">
											<gml:posList>35.66914595031993 139.74158920516064 57.9 35.66914595031993 139.74158920516064 55.602 35.669144421999746 139.74160630625562 55.602 35.669144421999746 139.74160630625562 57.9 35.66914595031993 139.74158920516064 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a769f46-f1df-4596-8f5a-d71a542d62f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a769f46-f1df-4596-8f5a-d71a542d62f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a769f46-f1df-4596-8f5a-d71a542d62f9">
											<gml:posList>35.669092719652475 139.74160686247654 57.9 35.66910425831423 139.74160828526735 57.9 35.66910425831423 139.74160828526735 9.93 35.669092719652475 139.74160686247654 9.93 35.669092719652475 139.74160686247654 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6105ccf0-0bb5-4c54-bc71-c9a3399d4806">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6105ccf0-0bb5-4c54-bc71-c9a3399d4806">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6105ccf0-0bb5-4c54-bc71-c9a3399d4806">
											<gml:posList>35.66910601802681 139.74161095640662 55.602 35.66910601802681 139.74161095640662 57.9 35.66909370410903 139.74160943508753 57.9 35.66909370410903 139.74160943508753 55.602 35.66910601802681 139.74161095640662 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac551440-0c05-49c9-aead-422fcca8b9ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac551440-0c05-49c9-aead-422fcca8b9ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac551440-0c05-49c9-aead-422fcca8b9ae">
											<gml:posList>35.669146619707774 139.74160414975395 57.9 35.66926417087871 139.74162003212564 57.9 35.66926417087871 139.74162003212564 9.93 35.669146619707774 139.74160414975395 9.93 35.669146619707774 139.74160414975395 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf59fdbf-95bd-4f69-8418-7402a337950a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf59fdbf-95bd-4f69-8418-7402a337950a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf59fdbf-95bd-4f69-8418-7402a337950a">
											<gml:posList>35.669265939621546 139.74162272535239 55.602 35.669265939621546 139.74162272535239 57.9 35.669144421999746 139.74160630625562 57.9 35.669144421999746 139.74160630625562 55.602 35.669265939621546 139.74162272535239 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a147fe95-6c34-4bc6-9064-650d86522e0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a147fe95-6c34-4bc6-9064-650d86522e0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a147fe95-6c34-4bc6-9064-650d86522e0c">
											<gml:posList>35.66926488541407 139.74161141534572 57.9 35.66931320394216 139.74161787727869 57.9 35.66931320394216 139.74161787727869 9.93 35.66926488541407 139.74161141534572 9.93 35.66926488541407 139.74161141534572 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8331295b-0ada-4055-a612-2e13bf37aad1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8331295b-0ada-4055-a612-2e13bf37aad1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8331295b-0ada-4055-a612-2e13bf37aad1">
											<gml:posList>35.66926488541407 139.74161141534572 57.9 35.66926488541407 139.74161141534572 9.93 35.66926417087871 139.74162003212564 9.93 35.66926417087871 139.74162003212564 57.9 35.66926488541407 139.74161141534572 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82e5f3d4-1d8f-4a7f-9644-257dc887cd9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82e5f3d4-1d8f-4a7f-9644-257dc887cd9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82e5f3d4-1d8f-4a7f-9644-257dc887cd9d">
											<gml:posList>35.66931099722023 139.74162003379473 55.602 35.66931099722023 139.74162003379473 57.9 35.66926665414868 139.74161409752622 57.9 35.66926665414868 139.74161409752622 55.602 35.66931099722023 139.74162003379473 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10200f83-c12e-4971-80f9-515296fff88c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10200f83-c12e-4971-80f9-515296fff88c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10200f83-c12e-4971-80f9-515296fff88c">
											<gml:posList>35.66923378950799 139.74162518122182 55.602 35.66912966077475 139.74161059797817 55.602 35.66912966077475 139.74161059797817 66.421 35.66923378950799 139.74162518122182 66.421 35.66923378950799 139.74162518122182 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cae0cc47-d5c5-47c1-911e-804c0ce5ac88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cae0cc47-d5c5-47c1-911e-804c0ce5ac88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cae0cc47-d5c5-47c1-911e-804c0ce5ac88">
											<gml:posList>35.66926665414868 139.74161409752622 55.602 35.66926665414868 139.74161409752622 57.9 35.669265939621546 139.74162272535239 57.9 35.669265939621546 139.74162272535239 55.602 35.66926665414868 139.74161409752622 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f949e30-448e-4773-adb4-0c4b817ba08a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f949e30-448e-4773-adb4-0c4b817ba08a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f949e30-448e-4773-adb4-0c4b817ba08a">
											<gml:posList>35.66923063704304 139.74162825564363 65.198 35.66923063704304 139.74162825564363 66.421 35.66913216954353 139.74161447228502 66.421 35.66913216954353 139.74161447228502 65.198 35.66923063704304 139.74162825564363 65.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f47124d5-9b7e-477a-91a6-50cbc721898a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f47124d5-9b7e-477a-91a6-50cbc721898a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f47124d5-9b7e-477a-91a6-50cbc721898a">
											<gml:posList>35.66931320394216 139.74161787727869 57.9 35.66931150546759 139.7416364366902 57.9 35.66931150546759 139.7416364366902 9.93 35.66931320394216 139.74161787727869 9.93 35.66931320394216 139.74161787727869 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a06a6e5-31d7-4411-87fc-65bb7476c41b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a06a6e5-31d7-4411-87fc-65bb7476c41b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a06a6e5-31d7-4411-87fc-65bb7476c41b">
											<gml:posList>35.66931099722023 139.74162003379473 57.9 35.66931099722023 139.74162003379473 55.602 35.669309298745326 139.74163859320572 55.602 35.669309298745326 139.74163859320572 57.9 35.66931099722023 139.74162003379473 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7416c96-a83c-424b-b3ad-1203504472bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7416c96-a83c-424b-b3ad-1203504472bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7416c96-a83c-424b-b3ad-1203504472bf">
											<gml:posList>35.669092719652475 139.74160686247654 9.93 35.66906292518889 139.74166069096128 9.93 35.66906292518889 139.74166069096128 57.9 35.669092719652475 139.74160686247654 57.9 35.669092719652475 139.74160686247654 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9114cf33-f8f1-4945-850d-ac6ce978d023">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9114cf33-f8f1-4945-850d-ac6ce978d023">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9114cf33-f8f1-4945-850d-ac6ce978d023">
											<gml:posList>35.66909370410903 139.74160943508753 55.602 35.66909370410903 139.74160943508753 57.9 35.66906468375666 139.74166185983498 57.9 35.66906468375666 139.74166185983498 55.602 35.66909370410903 139.74160943508753 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dda83f79-b5fc-4784-9c5c-3f733c96b287">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dda83f79-b5fc-4784-9c5c-3f733c96b287">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dda83f79-b5fc-4784-9c5c-3f733c96b287">
											<gml:posList>35.66933530413984 139.74163961284688 57.9 35.66933530413984 139.74163961284688 9.93 35.66931150546759 139.7416364366902 9.93 35.66931150546759 139.7416364366902 57.9 35.66933530413984 139.74163961284688 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae966b75-914c-40f3-955a-794bbaacc3b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae966b75-914c-40f3-955a-794bbaacc3b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae966b75-914c-40f3-955a-794bbaacc3b0">
											<gml:posList>35.66933310643125 139.74164176935264 55.602 35.66933310643125 139.74164176935264 57.9 35.669309298745326 139.74163859320572 57.9 35.669309298745326 139.74163859320572 55.602 35.66933310643125 139.74164176935264 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9f38bf8-e9cf-47a2-aec9-e8a1cabd1bac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9f38bf8-e9cf-47a2-aec9-e8a1cabd1bac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9f38bf8-e9cf-47a2-aec9-e8a1cabd1bac">
											<gml:posList>35.66912966077475 139.74161059797817 66.421 35.66912966077475 139.74161059797817 55.602 35.66912178399569 139.74169507640988 55.602 35.66912178399569 139.74169507640988 66.421 35.66912966077475 139.74161059797817 66.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ebde8cf-41f0-4117-9c1e-1c09b2985561">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ebde8cf-41f0-4117-9c1e-1c09b2985561">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ebde8cf-41f0-4117-9c1e-1c09b2985561">
											<gml:posList>35.66913216954353 139.74161447228502 65.198 35.66913216954353 139.74161447228502 66.421 35.6691249364624 139.74169200199486 66.421 35.6691249364624 139.74169200199486 65.198 35.66913216954353 139.74161447228502 65.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7894b93-3843-4e7c-b9b5-1035d289c312">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7894b93-3843-4e7c-b9b5-1035d289c312">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7894b93-3843-4e7c-b9b5-1035d289c312">
											<gml:posList>35.6692234039533 139.74170578544746 65.198 35.6692234039533 139.74170578544746 66.421 35.66923063704304 139.74162825564363 66.421 35.66923063704304 139.74162825564363 65.198 35.6692234039533 139.74170578544746 65.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a387e62-e950-4e46-a984-996dfced8ee3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a387e62-e950-4e46-a984-996dfced8ee3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a387e62-e950-4e46-a984-996dfced8ee3">
											<gml:posList>35.66923378950799 139.74162518122182 55.602 35.66923378950799 139.74162518122182 66.421 35.669225912719 139.74170965976185 66.421 35.669225912719 139.74170965976185 55.602 35.66923378950799 139.74162518122182 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdb8ea97-86ba-411b-a658-388ebd7b87b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdb8ea97-86ba-411b-a658-388ebd7b87b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdb8ea97-86ba-411b-a658-388ebd7b87b5">
											<gml:posList>35.669058658804865 139.7416805787786 57.9 35.669058658804865 139.7416805787786 55.602 35.66906468375666 139.74166185983498 55.602 35.66906468375666 139.74166185983498 57.9 35.669058658804865 139.7416805787786 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e33a5b2f-1999-475f-b2f6-5962f4b9b7d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e33a5b2f-1999-475f-b2f6-5962f4b9b7d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e33a5b2f-1999-475f-b2f6-5962f4b9b7d6">
											<gml:posList>35.6691249364624 139.74169200199486 65.198 35.6691249364624 139.74169200199486 66.421 35.6692234039533 139.74170578544746 66.421 35.6692234039533 139.74170578544746 65.198 35.6691249364624 139.74169200199486 65.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e75946b-ca5a-4e57-bb17-476adede04ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e75946b-ca5a-4e57-bb17-476adede04ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e75946b-ca5a-4e57-bb17-476adede04ce">
											<gml:posList>35.66912178399569 139.74169507640988 55.602 35.669225912719 139.74170965976185 55.602 35.669225912719 139.74170965976185 66.421 35.66912178399569 139.74169507640988 66.421 35.66912178399569 139.74169507640988 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e9f5e6e-170a-455f-9428-f23ebe38149e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e9f5e6e-170a-455f-9428-f23ebe38149e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e9f5e6e-170a-455f-9428-f23ebe38149e">
											<gml:posList>35.66905670240616 139.74168002871104 16.5 35.66905670240616 139.74168002871104 57.9 35.66906292518889 139.74166069096128 57.9 35.66906292518889 139.74166069096128 9.93 35.669027944498296 139.7417694243162 9.93 35.669027944498296 139.7417694243162 16.5 35.66905670240616 139.74168002871104 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d94939c-091f-4e8c-b548-5d004024819d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d94939c-091f-4e8c-b548-5d004024819d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d94939c-091f-4e8c-b548-5d004024819d">
											<gml:posList>35.669310385902946 139.74189476235023 55.602 35.669310385902946 139.74189476235023 57.9 35.66933310643125 139.74164176935264 57.9 35.66933310643125 139.74164176935264 55.602 35.669310385902946 139.74189476235023 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b846a689-60a3-47a8-9683-4d663ba587f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b846a689-60a3-47a8-9683-4d663ba587f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b846a689-60a3-47a8-9683-4d663ba587f9">
											<gml:posList>35.66933530413984 139.74163961284688 57.9 35.66931215463963 139.74189745558456 57.9 35.66931215463963 139.74189745558456 9.93 35.66933530413984 139.74163961284688 9.93 35.66933530413984 139.74163961284688 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e96a3e30-a77b-4179-90ae-e113e1f0914e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e96a3e30-a77b-4179-90ae-e113e1f0914e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e96a3e30-a77b-4179-90ae-e113e1f0914e">
											<gml:posList>35.6690435432664 139.74185903435912 57.9 35.6690435432664 139.74185903435912 55.602 35.669058658804865 139.7416805787786 55.602 35.669058658804865 139.7416805787786 57.9 35.6690435432664 139.74185903435912 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d946b4f5-aefc-4808-ab13-54310b9c130c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d946b4f5-aefc-4808-ab13-54310b9c130c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d946b4f5-aefc-4808-ab13-54310b9c130c">
											<gml:posList>35.66904135457587 139.7418612018868 57.9 35.66905670240616 139.74168002871104 57.9 35.66905670240616 139.74168002871104 16.5 35.66904135457587 139.7418612018868 16.5 35.66904135457587 139.7418612018868 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9cf02fb-12fa-425e-abaf-1e96bcaf60c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9cf02fb-12fa-425e-abaf-1e96bcaf60c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9cf02fb-12fa-425e-abaf-1e96bcaf60c1">
											<gml:posList>35.669027944498296 139.7417694243162 9.93 35.66902548672759 139.74185635971696 9.93 35.66902548672759 139.74185635971696 16.5 35.669027944498296 139.7417694243162 16.5 35.669027944498296 139.7417694243162 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f607d2e-8ada-4ad8-9844-4b404463eff8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f607d2e-8ada-4ad8-9844-4b404463eff8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f607d2e-8ada-4ad8-9844-4b404463eff8">
											<gml:posList>35.66902548672759 139.74185635971696 9.93 35.66904135457587 139.7418612018868 9.93 35.66904135457587 139.7418612018868 16.5 35.66902548672759 139.74185635971696 16.5 35.66902548672759 139.74185635971696 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2e2f505-6548-401e-abf7-39e408a727d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2e2f505-6548-401e-abf7-39e408a727d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2e2f505-6548-401e-abf7-39e408a727d1">
											<gml:posList>35.6690435432664 139.74185903435912 55.602 35.6690435432664 139.74185903435912 57.9 35.66915515374072 139.74187410644998 57.9 35.66915515374072 139.74187410644998 55.602 35.6690435432664 139.74185903435912 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35be615e-0828-4aa2-93bd-963d6656e105">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35be615e-0828-4aa2-93bd-963d6656e105">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35be615e-0828-4aa2-93bd-963d6656e105">
											<gml:posList>35.66904135457587 139.7418612018868 16.5 35.66904135457587 139.7418612018868 9.93 35.66915493925706 139.7418765368346 9.93 35.66915493925706 139.7418765368346 57.9 35.66904135457587 139.7418612018868 57.9 35.66904135457587 139.7418612018868 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e93c2623-162b-4c72-8056-d803d8392daa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e93c2623-162b-4c72-8056-d803d8392daa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e93c2623-162b-4c72-8056-d803d8392daa">
											<gml:posList>35.66915515374072 139.74187410644998 55.602 35.66915515374072 139.74187410644998 57.9 35.669258272141576 139.74188768599714 57.9 35.669258272141576 139.74188768599714 55.602 35.66915515374072 139.74187410644998 55.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-239da7e3-a68b-4147-8cd8-c9cadd1417b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-239da7e3-a68b-4147-8cd8-c9cadd1417b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-239da7e3-a68b-4147-8cd8-c9cadd1417b8">
											<gml:posList>35.6691539559687 139.74188736312502 57.9 35.66915493925706 139.7418765368346 57.9 35.66915493925706 139.7418765368346 9.93 35.6691539559687 139.74188736312502 9.93 35.6691539559687 139.74188736312502 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c54789f-7a92-4b88-9ccb-de1baa24549d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c54789f-7a92-4b88-9ccb-de1baa24549d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c54789f-7a92-4b88-9ccb-de1baa24549d">
											<gml:posList>35.6692111088561 139.74189503021148 57.9 35.6691539559687 139.74188736312502 57.9 35.6691539559687 139.74188736312502 9.93 35.6692111088561 139.74189503021148 9.93 35.6692111088561 139.74189503021148 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e8f7509-7374-4cc6-8b17-4783f9f1b1f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e8f7509-7374-4cc6-8b17-4783f9f1b1f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e8f7509-7374-4cc6-8b17-4783f9f1b1f8">
											<gml:posList>35.669310385902946 139.74189476235023 57.9 35.669310385902946 139.74189476235023 55.602 35.669258272141576 139.74188768599714 55.602 35.669258272141576 139.74188768599714 57.9 35.669310385902946 139.74189476235023 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b910275-956a-4173-a909-266abae3c512">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b910275-956a-4173-a909-266abae3c512">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b910275-956a-4173-a909-266abae3c512">
											<gml:posList>35.66931215463963 139.74189745558456 57.9 35.66925806667139 139.74189011637458 57.9 35.66925806667139 139.74189011637458 9.93 35.66931215463963 139.74189745558456 9.93 35.66931215463963 139.74189745558456 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c6ccb8e-03fa-49eb-a846-7d4460412fed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c6ccb8e-03fa-49eb-a846-7d4460412fed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c6ccb8e-03fa-49eb-a846-7d4460412fed">
											<gml:posList>35.66925806667139 139.74189011637458 57.9 35.66925636815482 139.74190867576766 57.9 35.66925636815482 139.74190867576766 9.93 35.66925806667139 139.74189011637458 9.93 35.66925806667139 139.74189011637458 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-705eb767-54d4-40f6-ad10-b89f7924ef7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-705eb767-54d4-40f6-ad10-b89f7924ef7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-705eb767-54d4-40f6-ad10-b89f7924ef7a">
											<gml:posList>35.66925636815482 139.74190867576766 57.9 35.669230676355426 139.74190517030982 57.9 35.669230676355426 139.74190517030982 9.93 35.66925636815482 139.74190867576766 9.93 35.66925636815482 139.74190867576766 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-860c145d-b39c-45e3-b5b8-1046e471782e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-860c145d-b39c-45e3-b5b8-1046e471782e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-860c145d-b39c-45e3-b5b8-1046e471782e">
											<gml:posList>35.66920717661246 139.74193955047068 57.9 35.6692111088561 139.74189503021148 57.9 35.6692111088561 139.74189503021148 9.93 35.66920717661246 139.74193955047068 9.93 35.66920717661246 139.74193955047068 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-faf7bcec-932b-479a-9357-70b60eb6383a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faf7bcec-932b-479a-9357-70b60eb6383a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faf7bcec-932b-479a-9357-70b60eb6383a">
											<gml:posList>35.669230676355426 139.74190517030982 57.9 35.66922736945199 139.7419422889792 57.9 35.66922736945199 139.7419422889792 9.93 35.669230676355426 139.74190517030982 9.93 35.669230676355426 139.74190517030982 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4618cd59-bcc2-4e45-8bd1-8bc1198045bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4618cd59-bcc2-4e45-8bd1-8bc1198045bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4618cd59-bcc2-4e45-8bd1-8bc1198045bc">
											<gml:posList>35.66922736945199 139.7419422889792 57.9 35.66920717661246 139.74193955047068 57.9 35.66920717661246 139.74193955047068 9.93 35.66922736945199 139.7419422889792 9.93 35.66922736945199 139.7419422889792 57.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5221</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">775.40205</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>