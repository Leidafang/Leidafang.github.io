<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_fb3a7fdd-8fb6-4e00-a55b-e27f98cb74ba">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">6.8</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671415899791114 139.73877414955254 0 35.67145138850999 139.7387647955755 0 35.67144895296518 139.73875097939373 0 35.67146518330937 139.73874667424005 0 35.671457251774314 139.73870148169723 0 35.671405541713774 139.73871511875814 0 35.671415899791114 139.73877414955254 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671415899791114 139.73877414955254 15.23 35.671405541713774 139.73871511875814 15.23 35.671457251774314 139.73870148169723 15.23 35.67146518330937 139.73874667424005 15.23 35.67144895296518 139.73875097939373 15.23 35.67145138850999 139.7387647955755 15.23 35.671415899791114 139.73877414955254 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671415899791114 139.73877414955254 15.23 35.67145138850999 139.7387647955755 15.23 35.67145138850999 139.7387647955755 22.01 35.671415899791114 139.73877414955254 22.01 35.671415899791114 139.73877414955254 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145138850999 139.7387647955755 15.23 35.67144895296518 139.73875097939373 15.23 35.67144895296518 139.73875097939373 22.01 35.67145138850999 139.7387647955755 22.01 35.67145138850999 139.7387647955755 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67144895296518 139.73875097939373 15.23 35.67146518330937 139.73874667424005 15.23 35.67146518330937 139.73874667424005 22.01 35.67144895296518 139.73875097939373 22.01 35.67144895296518 139.73875097939373 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67146518330937 139.73874667424005 15.23 35.671457251774314 139.73870148169723 15.23 35.671457251774314 139.73870148169723 22.01 35.67146518330937 139.73874667424005 22.01 35.67146518330937 139.73874667424005 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671457251774314 139.73870148169723 15.23 35.671405541713774 139.73871511875814 15.23 35.671405541713774 139.73871511875814 22.01 35.671457251774314 139.73870148169723 22.01 35.671457251774314 139.73870148169723 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671405541713774 139.73871511875814 15.23 35.671415899791114 139.73877414955254 15.23 35.671415899791114 139.73877414955254 22.01 35.671405541713774 139.73871511875814 22.01 35.671405541713774 139.73871511875814 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671415899791114 139.73877414955254 22.01 35.67145138850999 139.7387647955755 22.01 35.67144895296518 139.73875097939373 22.01 35.67146518330937 139.73874667424005 22.01 35.671457251774314 139.73870148169723 22.01 35.671405541713774 139.73871511875814 22.01 35.671415899791114 139.73877414955254 22.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b5360af0-dfd6-4f0b-9218-ffd0c4fabe82"/>
							<gml:surfaceMember xlink:href="#poly-73b2e3dd-30f6-4d15-8ec4-7d19b0e0ff80"/>
							<gml:surfaceMember xlink:href="#poly-e30870e4-7cd3-4a12-806b-27430cdb55fb"/>
							<gml:surfaceMember xlink:href="#poly-d1de0662-cc09-4a1c-873b-dabeba40f507"/>
							<gml:surfaceMember xlink:href="#poly-d3bf6ed9-06df-4302-917f-bbf8d4742080"/>
							<gml:surfaceMember xlink:href="#poly-c9a2e083-dc34-42c6-bffb-259a34271af3"/>
							<gml:surfaceMember xlink:href="#poly-0b7a03f6-86ef-49f2-9230-a4b96c6eda64"/>
							<gml:surfaceMember xlink:href="#poly-84f33c29-79ad-4d0a-8a88-8cf3d63e98f9"/>
							<gml:surfaceMember xlink:href="#poly-cbdc8785-0e86-431c-9782-511eb1e8bcaf"/>
							<gml:surfaceMember xlink:href="#poly-dcba48ec-f3a4-4978-a16c-dd1d21c67682"/>
							<gml:surfaceMember xlink:href="#poly-55f37e98-3a40-453e-b3cc-57894fea31e6"/>
							<gml:surfaceMember xlink:href="#poly-16b352fa-c9fa-4f98-b6c6-c8361efcdf52"/>
							<gml:surfaceMember xlink:href="#poly-e6dc914d-1e13-4008-850a-7adb2a19dd2c"/>
							<gml:surfaceMember xlink:href="#poly-143a621a-aaab-42e9-acb9-9d244760fa9c"/>
							<gml:surfaceMember xlink:href="#poly-689388a3-ca7a-4061-9ea6-a7fa2eb0a4ef"/>
							<gml:surfaceMember xlink:href="#poly-5ec5b076-b829-4dee-baa7-d14683d723bb"/>
							<gml:surfaceMember xlink:href="#poly-d6e9e7ea-be42-46c5-87a9-ea5b617694e2"/>
							<gml:surfaceMember xlink:href="#poly-3184f3a1-afb4-4618-8476-dcd097e28d74"/>
							<gml:surfaceMember xlink:href="#poly-34739a14-15ad-44b3-892e-7e104f0e8ed7"/>
							<gml:surfaceMember xlink:href="#poly-d1721123-77fe-4026-a2e5-7febf95f05a6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b5360af0-dfd6-4f0b-9218-ffd0c4fabe82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5360af0-dfd6-4f0b-9218-ffd0c4fabe82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5360af0-dfd6-4f0b-9218-ffd0c4fabe82">
											<gml:posList>35.67140554171378 139.73871511875814 15.23 35.67145725177431 139.73870148169723 15.23 35.67146518330936 139.73874667424005 15.23 35.67144895296518 139.73875097939373 15.23 35.671451388509986 139.73876479557546 15.23 35.67141589979111 139.7387741495525 15.23 35.67140554171378 139.73871511875814 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73b2e3dd-30f6-4d15-8ec4-7d19b0e0ff80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73b2e3dd-30f6-4d15-8ec4-7d19b0e0ff80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73b2e3dd-30f6-4d15-8ec4-7d19b0e0ff80">
											<gml:posList>35.67141589979111 139.7387741495525 22.912 35.67141860888718 139.73876900978027 22.912 35.67140973569789 139.7387184277289 22.912 35.67140554171378 139.73871511875814 22.912 35.67141589979111 139.7387741495525 22.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e30870e4-7cd3-4a12-806b-27430cdb55fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e30870e4-7cd3-4a12-806b-27430cdb55fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e30870e4-7cd3-4a12-806b-27430cdb55fb">
											<gml:posList>35.67140554171378 139.73871511875814 22.912 35.67140973569789 139.7387184277289 22.912 35.67145455168617 139.7387066104172 22.912 35.67145725177431 139.73870148169723 22.912 35.67140554171378 139.73871511875814 22.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1de0662-cc09-4a1c-873b-dabeba40f507">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1de0662-cc09-4a1c-873b-dabeba40f507">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1de0662-cc09-4a1c-873b-dabeba40f507">
											<gml:posList>35.671451388509986 139.73876479557546 22.912 35.67144720353221 139.7387614755435 22.912 35.67141860888718 139.73876900978027 22.912 35.67141589979111 139.7387741495525 22.912 35.671451388509986 139.73876479557546 22.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3bf6ed9-06df-4302-917f-bbf8d4742080">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3bf6ed9-06df-4302-917f-bbf8d4742080">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3bf6ed9-06df-4302-917f-bbf8d4742080">
											<gml:posList>35.67141860888718 139.73876900978027 22.524 35.67144720353221 139.7387614755435 22.524 35.671444767987026 139.7387476593626 22.524 35.67146099833109 139.73874335420848 22.524 35.67145455168617 139.7387066104172 22.524 35.67140973569789 139.7387184277289 22.524 35.67141860888718 139.73876900978027 22.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9a2e083-dc34-42c6-bffb-259a34271af3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9a2e083-dc34-42c6-bffb-259a34271af3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9a2e083-dc34-42c6-bffb-259a34271af3">
											<gml:posList>35.67144895296518 139.73875097939373 22.912 35.671444767987026 139.7387476593626 22.912 35.67144720353221 139.7387614755435 22.912 35.671451388509986 139.73876479557546 22.912 35.67144895296518 139.73875097939373 22.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b7a03f6-86ef-49f2-9230-a4b96c6eda64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b7a03f6-86ef-49f2-9230-a4b96c6eda64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b7a03f6-86ef-49f2-9230-a4b96c6eda64">
											<gml:posList>35.67144895296518 139.73875097939373 22.912 35.67146518330936 139.73874667424005 22.912 35.67146099833109 139.73874335420848 22.912 35.671444767987026 139.7387476593626 22.912 35.67144895296518 139.73875097939373 22.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84f33c29-79ad-4d0a-8a88-8cf3d63e98f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84f33c29-79ad-4d0a-8a88-8cf3d63e98f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84f33c29-79ad-4d0a-8a88-8cf3d63e98f9">
											<gml:posList>35.67145725177431 139.73870148169723 22.912 35.67145455168617 139.7387066104172 22.912 35.67146099833109 139.73874335420848 22.912 35.67146518330936 139.73874667424005 22.912 35.67145725177431 139.73870148169723 22.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbdc8785-0e86-431c-9782-511eb1e8bcaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbdc8785-0e86-431c-9782-511eb1e8bcaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbdc8785-0e86-431c-9782-511eb1e8bcaf">
											<gml:posList>35.67145725177431 139.73870148169723 15.23 35.67140554171378 139.73871511875814 15.23 35.67140554171378 139.73871511875814 22.912 35.67145725177431 139.73870148169723 22.912 35.67145725177431 139.73870148169723 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcba48ec-f3a4-4978-a16c-dd1d21c67682">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcba48ec-f3a4-4978-a16c-dd1d21c67682">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcba48ec-f3a4-4978-a16c-dd1d21c67682">
											<gml:posList>35.67140973569789 139.7387184277289 22.912 35.67140973569789 139.7387184277289 22.524 35.67145455168617 139.7387066104172 22.524 35.67145455168617 139.7387066104172 22.912 35.67140973569789 139.7387184277289 22.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55f37e98-3a40-453e-b3cc-57894fea31e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55f37e98-3a40-453e-b3cc-57894fea31e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55f37e98-3a40-453e-b3cc-57894fea31e6">
											<gml:posList>35.67146518330936 139.73874667424005 15.23 35.67145725177431 139.73870148169723 15.23 35.67145725177431 139.73870148169723 22.912 35.67146518330936 139.73874667424005 22.912 35.67146518330936 139.73874667424005 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16b352fa-c9fa-4f98-b6c6-c8361efcdf52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16b352fa-c9fa-4f98-b6c6-c8361efcdf52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16b352fa-c9fa-4f98-b6c6-c8361efcdf52">
											<gml:posList>35.67145455168617 139.7387066104172 22.912 35.67145455168617 139.7387066104172 22.524 35.67146099833109 139.73874335420848 22.524 35.67146099833109 139.73874335420848 22.912 35.67145455168617 139.7387066104172 22.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6dc914d-1e13-4008-850a-7adb2a19dd2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6dc914d-1e13-4008-850a-7adb2a19dd2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6dc914d-1e13-4008-850a-7adb2a19dd2c">
											<gml:posList>35.67141860888718 139.73876900978027 22.912 35.67141860888718 139.73876900978027 22.524 35.67140973569789 139.7387184277289 22.524 35.67140973569789 139.7387184277289 22.912 35.67141860888718 139.73876900978027 22.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-143a621a-aaab-42e9-acb9-9d244760fa9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-143a621a-aaab-42e9-acb9-9d244760fa9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-143a621a-aaab-42e9-acb9-9d244760fa9c">
											<gml:posList>35.67140554171378 139.73871511875814 15.23 35.67141589979111 139.7387741495525 15.23 35.67141589979111 139.7387741495525 22.912 35.67140554171378 139.73871511875814 22.912 35.67140554171378 139.73871511875814 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-689388a3-ca7a-4061-9ea6-a7fa2eb0a4ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-689388a3-ca7a-4061-9ea6-a7fa2eb0a4ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-689388a3-ca7a-4061-9ea6-a7fa2eb0a4ef">
											<gml:posList>35.67146099833109 139.73874335420848 22.912 35.67146099833109 139.73874335420848 22.524 35.671444767987026 139.7387476593626 22.524 35.671444767987026 139.7387476593626 22.912 35.67146099833109 139.73874335420848 22.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ec5b076-b829-4dee-baa7-d14683d723bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ec5b076-b829-4dee-baa7-d14683d723bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ec5b076-b829-4dee-baa7-d14683d723bb">
											<gml:posList>35.67144895296518 139.73875097939373 15.23 35.67146518330936 139.73874667424005 15.23 35.67146518330936 139.73874667424005 22.912 35.67144895296518 139.73875097939373 22.912 35.67144895296518 139.73875097939373 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6e9e7ea-be42-46c5-87a9-ea5b617694e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6e9e7ea-be42-46c5-87a9-ea5b617694e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6e9e7ea-be42-46c5-87a9-ea5b617694e2">
											<gml:posList>35.671444767987026 139.7387476593626 22.912 35.671444767987026 139.7387476593626 22.524 35.67144720353221 139.7387614755435 22.524 35.67144720353221 139.7387614755435 22.912 35.671444767987026 139.7387476593626 22.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3184f3a1-afb4-4618-8476-dcd097e28d74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3184f3a1-afb4-4618-8476-dcd097e28d74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3184f3a1-afb4-4618-8476-dcd097e28d74">
											<gml:posList>35.671451388509986 139.73876479557546 15.23 35.67144895296518 139.73875097939373 15.23 35.67144895296518 139.73875097939373 22.912 35.671451388509986 139.73876479557546 22.912 35.671451388509986 139.73876479557546 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34739a14-15ad-44b3-892e-7e104f0e8ed7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34739a14-15ad-44b3-892e-7e104f0e8ed7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34739a14-15ad-44b3-892e-7e104f0e8ed7">
											<gml:posList>35.67144720353221 139.7387614755435 22.912 35.67144720353221 139.7387614755435 22.524 35.67141860888718 139.73876900978027 22.524 35.67141860888718 139.73876900978027 22.912 35.67144720353221 139.7387614755435 22.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1721123-77fe-4026-a2e5-7febf95f05a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1721123-77fe-4026-a2e5-7febf95f05a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1721123-77fe-4026-a2e5-7febf95f05a6">
											<gml:posList>35.67141589979111 139.7387741495525 15.23 35.671451388509986 139.73876479557546 15.23 35.671451388509986 139.73876479557546 22.912 35.67141589979111 139.7387741495525 22.912 35.67141589979111 139.7387741495525 15.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4205</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>