<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_fb6c60b3-817b-40f5-941b-8dbe182bba9b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">17.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67234572310259 139.73828586776204 0 35.67233364611404 139.73828764952444 0 35.67231832898199 139.7382955107169 0 35.67229320136599 139.73832172076288 0 35.67226246536766 139.73832275137477 0 35.67225246885503 139.73833380973863 0 35.672249058804745 139.7383530347185 0 35.672268128709355 139.7384176342644 0 35.67231056869706 139.73839902585723 0 35.67234852484257 139.73852402763652 0 35.67247917696083 139.73846444269907 0 35.67246191583464 139.73840746294695 0 35.6724681330365 139.73840458348334 0 35.672420416832296 139.7382477791101 0 35.67235707306384 139.73827657521957 0 35.67236023614963 139.73828706567463 0 35.67234572310259 139.73828586776204 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67234572310259 139.73828586776204 9.419 35.67236023614963 139.73828706567463 9.419 35.67235707306384 139.73827657521957 9.419 35.672420416832296 139.7382477791101 9.419 35.6724681330365 139.73840458348334 9.419 35.67246191583464 139.73840746294695 9.419 35.67247917696083 139.73846444269907 9.419 35.67234852484257 139.73852402763652 9.419 35.67231056869706 139.73839902585723 9.419 35.672268128709355 139.7384176342644 9.419 35.672249058804745 139.7383530347185 9.419 35.67225246885503 139.73833380973863 9.419 35.67226246536766 139.73832275137477 9.419 35.67229320136599 139.73832172076288 9.419 35.67231832898199 139.7382955107169 9.419 35.67233364611404 139.73828764952444 9.419 35.67234572310259 139.73828586776204 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67234572310259 139.73828586776204 9.419 35.67233364611404 139.73828764952444 9.419 35.67233364611404 139.73828764952444 26.67 35.67234572310259 139.73828586776204 26.67 35.67234572310259 139.73828586776204 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67233364611404 139.73828764952444 9.419 35.67231832898199 139.7382955107169 9.419 35.67231832898199 139.7382955107169 26.67 35.67233364611404 139.73828764952444 26.67 35.67233364611404 139.73828764952444 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67231832898199 139.7382955107169 9.419 35.67229320136599 139.73832172076288 9.419 35.67229320136599 139.73832172076288 26.67 35.67231832898199 139.7382955107169 26.67 35.67231832898199 139.7382955107169 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67229320136599 139.73832172076288 9.419 35.67226246536766 139.73832275137477 9.419 35.67226246536766 139.73832275137477 26.67 35.67229320136599 139.73832172076288 26.67 35.67229320136599 139.73832172076288 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67226246536766 139.73832275137477 9.419 35.67225246885503 139.73833380973863 9.419 35.67225246885503 139.73833380973863 26.67 35.67226246536766 139.73832275137477 26.67 35.67226246536766 139.73832275137477 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67225246885503 139.73833380973863 9.419 35.672249058804745 139.7383530347185 9.419 35.672249058804745 139.7383530347185 26.67 35.67225246885503 139.73833380973863 26.67 35.67225246885503 139.73833380973863 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672249058804745 139.7383530347185 9.419 35.672268128709355 139.7384176342644 9.419 35.672268128709355 139.7384176342644 26.67 35.672249058804745 139.7383530347185 26.67 35.672249058804745 139.7383530347185 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672268128709355 139.7384176342644 9.419 35.67231056869706 139.73839902585723 9.419 35.67231056869706 139.73839902585723 26.67 35.672268128709355 139.7384176342644 26.67 35.672268128709355 139.7384176342644 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67231056869706 139.73839902585723 9.419 35.67234852484257 139.73852402763652 9.419 35.67234852484257 139.73852402763652 26.67 35.67231056869706 139.73839902585723 26.67 35.67231056869706 139.73839902585723 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67234852484257 139.73852402763652 9.419 35.67247917696083 139.73846444269907 9.419 35.67247917696083 139.73846444269907 26.67 35.67234852484257 139.73852402763652 26.67 35.67234852484257 139.73852402763652 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67247917696083 139.73846444269907 9.419 35.67246191583464 139.73840746294695 9.419 35.67246191583464 139.73840746294695 26.67 35.67247917696083 139.73846444269907 26.67 35.67247917696083 139.73846444269907 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67246191583464 139.73840746294695 9.419 35.6724681330365 139.73840458348334 9.419 35.6724681330365 139.73840458348334 26.67 35.67246191583464 139.73840746294695 26.67 35.67246191583464 139.73840746294695 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6724681330365 139.73840458348334 9.419 35.672420416832296 139.7382477791101 9.419 35.672420416832296 139.7382477791101 26.67 35.6724681330365 139.73840458348334 26.67 35.6724681330365 139.73840458348334 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672420416832296 139.7382477791101 9.419 35.67235707306384 139.73827657521957 9.419 35.67235707306384 139.73827657521957 26.67 35.672420416832296 139.7382477791101 26.67 35.672420416832296 139.7382477791101 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67235707306384 139.73827657521957 9.419 35.67236023614963 139.73828706567463 9.419 35.67236023614963 139.73828706567463 26.67 35.67235707306384 139.73827657521957 26.67 35.67235707306384 139.73827657521957 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67236023614963 139.73828706567463 9.419 35.67234572310259 139.73828586776204 9.419 35.67234572310259 139.73828586776204 26.67 35.67236023614963 139.73828706567463 26.67 35.67236023614963 139.73828706567463 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67234572310259 139.73828586776204 26.67 35.67233364611404 139.73828764952444 26.67 35.67231832898199 139.7382955107169 26.67 35.67229320136599 139.73832172076288 26.67 35.67226246536766 139.73832275137477 26.67 35.67225246885503 139.73833380973863 26.67 35.672249058804745 139.7383530347185 26.67 35.672268128709355 139.7384176342644 26.67 35.67231056869706 139.73839902585723 26.67 35.67234852484257 139.73852402763652 26.67 35.67247917696083 139.73846444269907 26.67 35.67246191583464 139.73840746294695 26.67 35.6724681330365 139.73840458348334 26.67 35.672420416832296 139.7382477791101 26.67 35.67235707306384 139.73827657521957 26.67 35.67236023614963 139.73828706567463 26.67 35.67234572310259 139.73828586776204 26.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-00b9a1ac-5a78-47d5-b20c-1c4744d650ef"/>
							<gml:surfaceMember xlink:href="#poly-bdac9daa-68c1-4954-a596-0a6ee46e8ef7"/>
							<gml:surfaceMember xlink:href="#poly-b8f83d44-865d-4da2-8845-a718b5b74df8"/>
							<gml:surfaceMember xlink:href="#poly-ce1f8b37-d5de-42eb-8886-d2344c956cdf"/>
							<gml:surfaceMember xlink:href="#poly-1c8581e9-db54-4b7b-a71a-4c2463a2d5bf"/>
							<gml:surfaceMember xlink:href="#poly-37a41179-944e-4521-aff7-d26d7957b16c"/>
							<gml:surfaceMember xlink:href="#poly-e465089a-8ab3-46d9-ab38-6c348769a987"/>
							<gml:surfaceMember xlink:href="#poly-a80f4804-31d0-4d93-8f1d-24f9c3da3b2b"/>
							<gml:surfaceMember xlink:href="#poly-69f4d67e-c7f0-48bc-a68a-e244f8e3b312"/>
							<gml:surfaceMember xlink:href="#poly-ab734058-561e-437a-9737-ab97c2fa1f28"/>
							<gml:surfaceMember xlink:href="#poly-d9fdad54-8614-4333-88bd-c8e3e0ef954f"/>
							<gml:surfaceMember xlink:href="#poly-b47ea414-8179-4bb8-90ce-0dd452df0a46"/>
							<gml:surfaceMember xlink:href="#poly-c0189ce5-bb3e-4d11-b3e1-43b69b60c590"/>
							<gml:surfaceMember xlink:href="#poly-6696511f-8f14-4461-9d54-1ea745d14447"/>
							<gml:surfaceMember xlink:href="#poly-1f72e294-e048-4a54-a603-700e774ca1f5"/>
							<gml:surfaceMember xlink:href="#poly-d7eb165c-d46d-48e1-83f9-2e584ba6ebf9"/>
							<gml:surfaceMember xlink:href="#poly-3dff4f71-af5d-44bb-8bdc-16d175f71763"/>
							<gml:surfaceMember xlink:href="#poly-699978ae-2daa-4393-9597-7313eca43297"/>
							<gml:surfaceMember xlink:href="#poly-e5d57787-2749-4b12-af17-fd9b1dc63e4a"/>
							<gml:surfaceMember xlink:href="#poly-e708e39a-d270-457a-b36d-a6ff17786938"/>
							<gml:surfaceMember xlink:href="#poly-4f59f449-dac4-4f80-a65a-106082802c11"/>
							<gml:surfaceMember xlink:href="#poly-ba0ae4c6-6847-43b4-83bf-ef24e6bfe158"/>
							<gml:surfaceMember xlink:href="#poly-54941120-cf96-4d69-828e-34c3eab9e200"/>
							<gml:surfaceMember xlink:href="#poly-91939def-67bf-4798-ba0b-005787048908"/>
							<gml:surfaceMember xlink:href="#poly-1ee86e7f-91aa-41c6-9b71-4b6a89d58171"/>
							<gml:surfaceMember xlink:href="#poly-743bac54-ffd8-484f-91b2-8eee2848d75d"/>
							<gml:surfaceMember xlink:href="#poly-e7ae60eb-2a51-49be-9f8c-4820ce333ed2"/>
							<gml:surfaceMember xlink:href="#poly-f9434d1b-dd5d-45e4-80a5-d1b4b52d58e8"/>
							<gml:surfaceMember xlink:href="#poly-8b60c96c-7875-462d-9987-5d961c0e929e"/>
							<gml:surfaceMember xlink:href="#poly-de4e5354-bf73-4646-a0fb-43ff2e1c4ad9"/>
							<gml:surfaceMember xlink:href="#poly-5c41436e-912a-4956-8d27-5420b60f9546"/>
							<gml:surfaceMember xlink:href="#poly-fd66cafe-82dd-4cac-98d9-0642f11729de"/>
							<gml:surfaceMember xlink:href="#poly-32b8077e-d735-461f-95cb-588ad113bf1d"/>
							<gml:surfaceMember xlink:href="#poly-4d5b4d2e-bd47-49b2-81ca-2775c04d70e2"/>
							<gml:surfaceMember xlink:href="#poly-c92da59a-f72b-4714-9ba2-e8b95ec37659"/>
							<gml:surfaceMember xlink:href="#poly-63bf696a-f54a-4f3c-a16c-20abdcd5f21f"/>
							<gml:surfaceMember xlink:href="#poly-e6a44e75-c3c8-4bf2-b54d-f9633eea4d4d"/>
							<gml:surfaceMember xlink:href="#poly-ed07a5fc-1e33-49d0-9120-df9b5f5f3644"/>
							<gml:surfaceMember xlink:href="#poly-71079961-cfc8-4dcf-b7bc-bc9301e327ff"/>
							<gml:surfaceMember xlink:href="#poly-65ab214e-ac03-4a63-93b5-c4ea436e7e61"/>
							<gml:surfaceMember xlink:href="#poly-223bca19-912f-477d-92a2-ae793efde4d6"/>
							<gml:surfaceMember xlink:href="#poly-0a34174a-cd67-40ae-846b-d3ac6519b19b"/>
							<gml:surfaceMember xlink:href="#poly-08bc43cd-08fe-4844-8603-9614eb4b2265"/>
							<gml:surfaceMember xlink:href="#poly-a90a3391-aeb0-4663-8f40-ac764db047ac"/>
							<gml:surfaceMember xlink:href="#poly-9a7b072d-3d56-4e7b-811c-c85023b5eb2f"/>
							<gml:surfaceMember xlink:href="#poly-0000ce61-8fcb-457d-a18d-b326829b04f8"/>
							<gml:surfaceMember xlink:href="#poly-3f6081ad-0ef8-4e66-84f0-ac6e6d9e575e"/>
							<gml:surfaceMember xlink:href="#poly-6ec58a1f-e101-40bc-aae6-580f65329d7e"/>
							<gml:surfaceMember xlink:href="#poly-64058448-25b6-4600-bafb-8659cb3bf571"/>
							<gml:surfaceMember xlink:href="#poly-880fe6a4-f6b7-48e5-b942-186a1c0809a4"/>
							<gml:surfaceMember xlink:href="#poly-f9920446-3d1c-4611-9bb7-99167b31f0c1"/>
							<gml:surfaceMember xlink:href="#poly-704b3f29-fe4f-4f54-af5c-40bd8777ceac"/>
							<gml:surfaceMember xlink:href="#poly-6ceb78d2-52e3-4b23-8042-4197f2965af4"/>
							<gml:surfaceMember xlink:href="#poly-72034a14-ef8d-4781-b965-703db2cffbe1"/>
							<gml:surfaceMember xlink:href="#poly-cbce7081-3696-4b2d-b376-1f74084a3f98"/>
							<gml:surfaceMember xlink:href="#poly-660f6bae-6856-4e67-a1aa-43c841ea7c6b"/>
							<gml:surfaceMember xlink:href="#poly-da38c059-9205-4832-bbc1-68ea421119cd"/>
							<gml:surfaceMember xlink:href="#poly-655c23c5-27d2-4d29-adaa-37da74ced8fb"/>
							<gml:surfaceMember xlink:href="#poly-8ef822e6-f0de-4225-b29b-0798f9942473"/>
							<gml:surfaceMember xlink:href="#poly-16277296-f94f-4eae-986b-fa6ef9aa0f04"/>
							<gml:surfaceMember xlink:href="#poly-ec1b27db-b92b-4746-91c8-456b2945e732"/>
							<gml:surfaceMember xlink:href="#poly-76d5e7b5-d26f-4679-8402-03b10ad19e88"/>
							<gml:surfaceMember xlink:href="#poly-d1de8bb7-bbc1-4480-993f-5e8be844876e"/>
							<gml:surfaceMember xlink:href="#poly-f142d8af-e1d7-43d6-ac43-eda7160ea9b4"/>
							<gml:surfaceMember xlink:href="#poly-732c9097-ba07-4187-9d7a-130595335108"/>
							<gml:surfaceMember xlink:href="#poly-ace60a44-3e2c-4a7e-b1ed-1f557f2ed0ae"/>
							<gml:surfaceMember xlink:href="#poly-0e3603ac-8d52-4d6b-9b78-06f12c3ea1d8"/>
							<gml:surfaceMember xlink:href="#poly-637e433b-f3a4-4289-9437-54d35d4c2643"/>
							<gml:surfaceMember xlink:href="#poly-0a7deba8-854d-49d8-a2e2-86933cde9bf2"/>
							<gml:surfaceMember xlink:href="#poly-7f6f0c9d-198a-4ffe-a094-0c2a72d7c251"/>
							<gml:surfaceMember xlink:href="#poly-afe408da-72ad-4c96-bd12-279b721eabe5"/>
							<gml:surfaceMember xlink:href="#poly-6ba5e657-1806-4636-bd21-ae583ebe6c1d"/>
							<gml:surfaceMember xlink:href="#poly-fd2ad5f2-933b-40d3-88b4-97cd931269fa"/>
							<gml:surfaceMember xlink:href="#poly-9db09ff3-83db-4776-bc29-538df8d16a6a"/>
							<gml:surfaceMember xlink:href="#poly-4cb1a70c-db7b-4867-bafc-15144e06f71e"/>
							<gml:surfaceMember xlink:href="#poly-86eb6fb2-d2f5-443e-be94-21811f5848b0"/>
							<gml:surfaceMember xlink:href="#poly-ee91fe61-47d5-4bd0-bd5c-c9add39a2646"/>
							<gml:surfaceMember xlink:href="#poly-338b5d52-7970-456d-8f20-ad901ac3a3bf"/>
							<gml:surfaceMember xlink:href="#poly-1e0c6f63-123e-4825-acee-cb623ca83737"/>
							<gml:surfaceMember xlink:href="#poly-d366e69c-d2fc-49e6-a5f3-d419b5a5e4ec"/>
							<gml:surfaceMember xlink:href="#poly-7d0a1f46-52eb-429a-8510-06ed256041fb"/>
							<gml:surfaceMember xlink:href="#poly-06e14357-1e17-4a04-9e35-8ad3996c63c6"/>
							<gml:surfaceMember xlink:href="#poly-d557ad78-8115-4129-8e41-745830a068dd"/>
							<gml:surfaceMember xlink:href="#poly-872a2422-fc0a-4a0c-b3bf-38489cf391bc"/>
							<gml:surfaceMember xlink:href="#poly-00bd1809-2ac9-4583-b387-8d38d623b39e"/>
							<gml:surfaceMember xlink:href="#poly-50cd2e7f-d8dc-4f09-8844-7b18a1b94f79"/>
							<gml:surfaceMember xlink:href="#poly-3c5a0e4d-9b75-40dd-bbdc-7421516aa325"/>
							<gml:surfaceMember xlink:href="#poly-c3982ebd-95a3-472c-948d-ec1a9c2cb9c1"/>
							<gml:surfaceMember xlink:href="#poly-eeb043d8-3a7b-4095-9fa6-e5fa1ebef3a8"/>
							<gml:surfaceMember xlink:href="#poly-186692ca-f6aa-449e-a1c2-89fdc54fd581"/>
							<gml:surfaceMember xlink:href="#poly-7952424b-51f7-4e38-b69d-c713f271d102"/>
							<gml:surfaceMember xlink:href="#poly-6791a884-b185-4ab8-acdf-b279a42c5cbb"/>
							<gml:surfaceMember xlink:href="#poly-37d82746-59af-4162-b9bc-24a8448a48cd"/>
							<gml:surfaceMember xlink:href="#poly-ead4d8fd-7147-45e6-8c71-d4e5dd17a7d2"/>
							<gml:surfaceMember xlink:href="#poly-3bed225e-a0af-435a-96f0-bbf8842888a5"/>
							<gml:surfaceMember xlink:href="#poly-449bcd95-655d-4d63-85e2-6956f41cc0c5"/>
							<gml:surfaceMember xlink:href="#poly-0e2aca3a-155c-4c07-958e-48b61f618138"/>
							<gml:surfaceMember xlink:href="#poly-04abb7c7-6cb1-4c8b-8e71-fd1715f53394"/>
							<gml:surfaceMember xlink:href="#poly-c2d847dc-81e5-418d-a634-fd3b559b9a8c"/>
							<gml:surfaceMember xlink:href="#poly-089dc592-83ac-47ff-a447-6123d3c0a892"/>
							<gml:surfaceMember xlink:href="#poly-4a1ff3c0-391e-43ce-88df-6104ad2d54f3"/>
							<gml:surfaceMember xlink:href="#poly-b8c983d8-2feb-4091-9ef2-f79c1ba323cb"/>
							<gml:surfaceMember xlink:href="#poly-6c196b7e-118c-409a-9267-7121bbf49dcd"/>
							<gml:surfaceMember xlink:href="#poly-4fe186c1-2f40-48a6-ad7e-9b90cb6567eb"/>
							<gml:surfaceMember xlink:href="#poly-db8a0ee9-df5f-468d-9560-e2e7508da9f6"/>
							<gml:surfaceMember xlink:href="#poly-2e558f45-cdb1-40e9-861c-cabbad520d28"/>
							<gml:surfaceMember xlink:href="#poly-3c568ca2-4840-4bfc-94a4-9fa12f3502b4"/>
							<gml:surfaceMember xlink:href="#poly-75b1c2b2-8423-4772-8f67-7609d5c9fdfe"/>
							<gml:surfaceMember xlink:href="#poly-82f050a3-79f0-439b-9ee7-2aabe2cea2ac"/>
							<gml:surfaceMember xlink:href="#poly-b24601c6-1b68-4ca3-a6a3-6e7e70cb845d"/>
							<gml:surfaceMember xlink:href="#poly-a56cbd8a-a733-46c5-9069-9be3a51a42f6"/>
							<gml:surfaceMember xlink:href="#poly-fa6b4f23-faed-4e22-926b-85a1492badf1"/>
							<gml:surfaceMember xlink:href="#poly-b7e68017-6943-49a7-8c89-f27da6aa9ecd"/>
							<gml:surfaceMember xlink:href="#poly-ed3858b9-10ed-49b1-8b4f-77878ba0f2eb"/>
							<gml:surfaceMember xlink:href="#poly-367aebb2-74ab-40f7-9712-202139c0f8c9"/>
							<gml:surfaceMember xlink:href="#poly-703b9c92-0acc-4143-8f53-1c947e57b52f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_fb6c60b3-817b-40f5-941b-8dbe182bba9b_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2f698ad-8308-46d7-9a8f-324362a59a24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67227572133593 139.7384100915486 26.72 35.67227264008104 139.7384004847244 26.72 35.67226773847275 139.7384028434371 26.72 35.6722558200917 139.73836571915712 26.72 35.67226009998787 139.73836365943495 26.72 35.67225645851065 139.73835231897485 26.72 35.67226809981809 139.73834670459792 26.72 35.67227334067979 139.73836305828482 26.72 35.672316049519374 139.73834248324738 26.72 35.67232944077618 139.7383842122094 26.72 35.67227572133593 139.7384100915486 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ba7d190-f4c2-4dd0-af32-44a040d20edc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ba7d190-f4c2-4dd0-af32-44a040d20edc_0">
											<gml:posList>35.67225645851065 139.73835231897485 26.72 35.67225645851065 139.73835231897485 28.577 35.67226809981809 139.73834670459792 28.577 35.67226809981809 139.73834670459792 26.72 35.67225645851065 139.73835231897485 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2a74a3f-d962-4ed4-97f9-a1faf46489c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2a74a3f-d962-4ed4-97f9-a1faf46489c5_0">
											<gml:posList>35.67227334067979 139.73836305828482 28.577 35.672316049519374 139.73834248324738 28.577 35.672316049519374 139.73834248324738 26.72 35.67227334067979 139.73836305828482 26.72 35.67227334067979 139.73836305828482 28.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6944d117-eed4-4fcf-ac70-c1efdc6647ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6944d117-eed4-4fcf-ac70-c1efdc6647ed_0">
											<gml:posList>35.67226809981809 139.73834670459792 26.72 35.67226809981809 139.73834670459792 28.577 35.67227334067979 139.73836305828482 28.577 35.67227334067979 139.73836305828482 26.72 35.67226809981809 139.73834670459792 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbf41a6e-cbc4-4bc4-ac20-43339b5b3e89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbf41a6e-cbc4-4bc4-ac20-43339b5b3e89_0">
											<gml:posList>35.67226009998787 139.73836365943495 26.72 35.67226009998787 139.73836365943495 28.577 35.67225645851065 139.73835231897485 28.577 35.67225645851065 139.73835231897485 26.72 35.67226009998787 139.73836365943495 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bb1806b-3d12-4451-9811-6e0310b11d58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bb1806b-3d12-4451-9811-6e0310b11d58_0">
											<gml:posList>35.672316049519374 139.73834248324738 26.72 35.672316049519374 139.73834248324738 28.577 35.67232944077618 139.7383842122094 28.577 35.67232944077618 139.7383842122094 26.72 35.672316049519374 139.73834248324738 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ad8e3a8-ccd8-4b9e-8d78-f1cfe5c12330">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ad8e3a8-ccd8-4b9e-8d78-f1cfe5c12330_0">
											<gml:posList>35.6722558200917 139.73836571915712 28.577 35.67226009998787 139.73836365943495 28.577 35.67226009998787 139.73836365943495 26.72 35.6722558200917 139.73836571915712 26.72 35.6722558200917 139.73836571915712 28.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75efda9c-f53c-448f-a7da-7628bb4bd574">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75efda9c-f53c-448f-a7da-7628bb4bd574_0">
											<gml:posList>35.672316049519374 139.73834248324738 28.577 35.67227334067979 139.73836305828482 28.577 35.67226809981809 139.73834670459792 28.577 35.67225645851065 139.73835231897485 28.577 35.67226009998787 139.73836365943495 28.577 35.6722558200917 139.73836571915712 28.577 35.67226773847275 139.7384028434371 28.577 35.67227264008104 139.7384004847244 28.577 35.67227572133593 139.7384100915486 28.577 35.67232944077618 139.7383842122094 28.577 35.672316049519374 139.73834248324738 28.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81352248-8b68-4b00-a01b-e237e550bf00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81352248-8b68-4b00-a01b-e237e550bf00_0">
											<gml:posList>35.67226773847275 139.7384028434371 26.72 35.67226773847275 139.7384028434371 28.577 35.6722558200917 139.73836571915712 28.577 35.6722558200917 139.73836571915712 26.72 35.67226773847275 139.7384028434371 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c0e4d11-231c-4e17-8ce6-4629da40eff5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c0e4d11-231c-4e17-8ce6-4629da40eff5_0">
											<gml:posList>35.67232944077618 139.7383842122094 26.72 35.67232944077618 139.7383842122094 28.577 35.67227572133593 139.7384100915486 28.577 35.67227572133593 139.7384100915486 26.72 35.67232944077618 139.7383842122094 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b9e542c-8ef1-4abf-9715-168802ed7136">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b9e542c-8ef1-4abf-9715-168802ed7136_0">
											<gml:posList>35.67227264008104 139.7384004847244 26.72 35.67227264008104 139.7384004847244 28.577 35.67226773847275 139.7384028434371 28.577 35.67226773847275 139.7384028434371 26.72 35.67227264008104 139.7384004847244 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-229c9a84-7eb8-4337-81ae-5b2653dea34e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-229c9a84-7eb8-4337-81ae-5b2653dea34e_0">
											<gml:posList>35.67227572133593 139.7384100915486 28.577 35.67227264008104 139.7384004847244 28.577 35.67227264008104 139.7384004847244 26.72 35.67227572133593 139.7384100915486 26.72 35.67227572133593 139.7384100915486 28.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_fb6c60b3-817b-40f5-941b-8dbe182bba9b_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcbc4d69-49b0-4de1-80bb-4b1fc2e3a711">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672438177922174 139.73841284862672 27.193 35.67242900529996 139.7384171013588 27.193 35.672412558261264 139.7383637660461 27.193 35.67242173089031 139.73835952435536 27.193 35.672438177922174 139.73841284862672 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b85c30b-8363-4ad4-b160-3fdc6331d1c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b85c30b-8363-4ad4-b160-3fdc6331d1c9_0">
											<gml:posList>35.67242173089031 139.73835952435536 27.545 35.67242173089031 139.73835952435536 27.193 35.672412558261264 139.7383637660461 27.193 35.672412558261264 139.7383637660461 27.545 35.67242173089031 139.73835952435536 27.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59e6d881-6cd3-486a-9f8c-9f4fdfa12b45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59e6d881-6cd3-486a-9f8c-9f4fdfa12b45_0">
											<gml:posList>35.672412558261264 139.7383637660461 27.545 35.672412558261264 139.7383637660461 27.193 35.67242900529996 139.7384171013588 27.193 35.67242900529996 139.7384171013588 27.545 35.672412558261264 139.7383637660461 27.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48389b9f-1a86-485d-b742-2c2556a99ced">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48389b9f-1a86-485d-b742-2c2556a99ced_0">
											<gml:posList>35.67242173089031 139.73835952435536 27.545 35.672412558261264 139.7383637660461 27.545 35.67242900529996 139.7384171013588 27.545 35.672438177922174 139.73841284862672 27.545 35.67242173089031 139.73835952435536 27.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddb67cce-4d21-464f-8ce6-5f226a759305">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddb67cce-4d21-464f-8ce6-5f226a759305_0">
											<gml:posList>35.672438177922174 139.73841284862672 27.545 35.672438177922174 139.73841284862672 27.193 35.67242173089031 139.73835952435536 27.193 35.67242173089031 139.73835952435536 27.545 35.672438177922174 139.73841284862672 27.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fce100ae-76a2-4551-aa0c-2057e7c0f756">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fce100ae-76a2-4551-aa0c-2057e7c0f756_0">
											<gml:posList>35.67242900529996 139.7384171013588 27.545 35.67242900529996 139.7384171013588 27.193 35.672438177922174 139.73841284862672 27.193 35.672438177922174 139.73841284862672 27.545 35.67242900529996 139.7384171013588 27.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_fb6c60b3-817b-40f5-941b-8dbe182bba9b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a5c6017-4489-497f-8967-dcd29288f29a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672325867782625 139.7383568431463 26.72 35.67232306664592 139.73834811970846 26.72 35.67234043850851 139.7383397479506 26.72 35.67234323964581 139.73834847139005 26.72 35.672325867782625 139.7383568431463 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0eda6b29-7dad-45c1-a786-49b69ef29272">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67243407310599 139.73837402489082 30.913 35.67242715089303 139.73835158651804 30.913 35.67243897258776 139.73834611552027 30.913 35.67244588578801 139.73836855390658 30.913 35.67243407310599 139.73837402489082 30.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbf5c399-2b16-4e11-a5e7-383b35764573">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67236365755756 139.7383736332937 26.72 35.6723698692852 139.7383981050541 26.72 35.6723591101269 139.73840220501137 26.72 35.67235001801011 139.73840567334142 26.72 35.67234767616728 139.73839643016842 26.72 35.67234380628399 139.73838120158646 26.72 35.67236365755756 139.7383736332937 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a854d3e-8be3-4be8-96d1-12e947e83e70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67240168527512 139.7383949743486 27.193 35.67241667925227 139.7383888036702 27.193 35.67242246471953 139.7384099619905 27.193 35.67240746171889 139.73841612162954 27.193 35.67240168527512 139.7383949743486 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79b4e188-05a1-4112-9fda-f891eaa6de93">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67232351876415 139.73840708553385 26.72 35.672326790212196 139.73841784097803 26.72 35.67232009541335 139.73842088669883 26.72 35.672316832979284 139.7384101312447 26.72 35.67232351876415 139.73840708553385 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acb80fe3-fb2f-494a-b733-8b2b9e06bf4b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67231756346378 139.73842203853502 27.02 35.672314292024815 139.7384112941384 27.02 35.672316832979284 139.7384101312447 27.02 35.67232009541335 139.73842088669883 27.02 35.67231756346378 139.73842203853502 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9039471-4007-4ce6-bb13-714ec515ea71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672422944933665 139.73845886445753 26.72 35.672417622117166 139.7384414393165 26.72 35.672426443361914 139.73843738584148 26.72 35.672431766178995 139.7384548109842 26.72 35.672422944933665 139.73845886445753 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2590197-64e7-43cc-a749-0b96d954f310">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672398407768526 139.73849090635977 26.72 35.67239282274074 139.73847244315775 26.72 35.67241783588698 139.73846106876502 26.72 35.672423429930205 139.73847953196136 26.72 35.672398407768526 139.73849090635977 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cca3b48-20be-4b40-8ba0-2366dfb5b988">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67239080039743 139.73847973626457 26.72 35.67236282192711 139.73849135717927 26.72 35.672357651356414 139.73847267256437 26.72 35.672385629824944 139.7384610516439 26.72 35.67239080039743 139.73847973626457 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2992e367-41ce-4f70-bbe8-ada3bf05ed9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2992e367-41ce-4f70-bbe8-ada3bf05ed9a_0">
											<gml:posList>35.672316832979284 139.7384101312447 26.72 35.672316832979284 139.7384101312447 27.02 35.672314292024815 139.7384112941384 27.02 35.672314292024815 139.7384112941384 28.902 35.67232351876415 139.73840708553385 28.902 35.67232351876415 139.73840708553385 26.72 35.672316832979284 139.7384101312447 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-697ff757-b9c9-41df-b1bf-09feeed5057f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-697ff757-b9c9-41df-b1bf-09feeed5057f_0">
											<gml:posList>35.672326790212196 139.73841784097803 28.902 35.67232351876415 139.73840708553385 28.902 35.672314292024815 139.7384112941384 28.902 35.67231755445006 139.73842203854568 28.902 35.672326790212196 139.73841784097803 28.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1423e92-ea96-44a0-b159-14aa294f378a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1423e92-ea96-44a0-b159-14aa294f378a_0">
											<gml:posList>35.67231755445006 139.73842203854568 28.902 35.67231756346378 139.73842203853502 27.02 35.67232009541335 139.73842088669883 27.02 35.67232009541335 139.73842088669883 26.72 35.672326790212196 139.73841784097803 26.72 35.672326790212196 139.73841784097803 28.902 35.67231755445006 139.73842203854568 28.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d86dc6a1-facf-4f64-b4ba-fa6327a5de29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d86dc6a1-facf-4f64-b4ba-fa6327a5de29_0">
											<gml:posList>35.67232306664592 139.73834811970846 26.72 35.672325867782625 139.7383568431463 26.72 35.672325867782625 139.7383568431463 27.105 35.67232306664592 139.73834811970846 27.105 35.67232306664592 139.73834811970846 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1523fa9-023d-42b6-86f3-88b7e33b056b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1523fa9-023d-42b6-86f3-88b7e33b056b_0">
											<gml:posList>35.672326790212196 139.73841784097803 26.72 35.67232351876415 139.73840708553385 26.72 35.67232351876415 139.73840708553385 28.902 35.672326790212196 139.73841784097803 28.902 35.672326790212196 139.73841784097803 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cce474b3-46dc-4a9f-8702-190c580cdadd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cce474b3-46dc-4a9f-8702-190c580cdadd_0">
											<gml:posList>35.67232306664592 139.73834811970846 26.72 35.67232306664592 139.73834811970846 27.105 35.67234043850851 139.7383397479506 27.105 35.67234043850851 139.7383397479506 26.72 35.67232306664592 139.73834811970846 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2b74b0b-7e4e-42bf-9766-ef67ef32fcff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2b74b0b-7e4e-42bf-9766-ef67ef32fcff_0">
											<gml:posList>35.672325867782625 139.7383568431463 27.105 35.67234323964581 139.73834847139005 27.105 35.67234043850851 139.7383397479506 27.105 35.67232306664592 139.73834811970846 27.105 35.672325867782625 139.7383568431463 27.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2d842c1-e100-4fc0-a66d-1c1198d84030">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2d842c1-e100-4fc0-a66d-1c1198d84030_0">
											<gml:posList>35.672325867782625 139.7383568431463 26.72 35.67234323964581 139.73834847139005 26.72 35.67234323964581 139.73834847139005 27.105 35.672325867782625 139.7383568431463 27.105 35.672325867782625 139.7383568431463 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83827d3b-87ba-4731-87fc-f127e8cca58f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83827d3b-87ba-4731-87fc-f127e8cca58f_0">
											<gml:posList>35.67234043850851 139.7383397479506 26.72 35.67234043850851 139.7383397479506 27.105 35.67234323964581 139.73834847139005 27.105 35.67234323964581 139.73834847139005 26.72 35.67234043850851 139.7383397479506 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-122d5b1d-137f-44ee-beb2-c0bafe0ccd6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-122d5b1d-137f-44ee-beb2-c0bafe0ccd6b_0">
											<gml:posList>35.67234767616728 139.73839643016842 26.72 35.67234767616728 139.73839643016842 26.783 35.67234380628399 139.73838120158646 26.783 35.67234380628399 139.73838120158646 26.72 35.67234767616728 139.73839643016842 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd099aa1-da88-4598-8e0e-a4e3d444fb6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd099aa1-da88-4598-8e0e-a4e3d444fb6c_0">
											<gml:posList>35.67235001801011 139.73840567334142 26.72 35.67235001801011 139.73840567334142 27.518 35.67234767616728 139.73839643016842 27.518 35.67234767616728 139.73839643016842 26.783 35.67234767616728 139.73839643016842 26.72 35.67235001801011 139.73840567334142 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c4557db-c5c7-4aef-bd72-fc968ffdfb0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c4557db-c5c7-4aef-bd72-fc968ffdfb0c_0">
											<gml:posList>35.67234767616728 139.73839643016842 26.783 35.67234767616728 139.73839643016842 27.518 35.67235675927008 139.7383929618481 27.518 35.67235675927008 139.7383929618481 26.783 35.67234767616728 139.73839643016842 26.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50d402e6-8ca1-4d93-a7c6-eeb7137908bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50d402e6-8ca1-4d93-a7c6-eeb7137908bd_0">
											<gml:posList>35.67234767616728 139.73839643016842 27.518 35.67235001801011 139.73840567334142 27.518 35.6723591101269 139.73840220501137 27.518 35.67235675927008 139.7383929618481 27.518 35.67234767616728 139.73839643016842 27.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edb99abb-69db-4580-bd58-fabf58b65070">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edb99abb-69db-4580-bd58-fabf58b65070_0">
											<gml:posList>35.67234380628399 139.73838120158646 26.72 35.67234380628399 139.73838120158646 26.783 35.67236365755756 139.7383736332937 26.783 35.67236365755756 139.7383736332937 26.72 35.67234380628399 139.73838120158646 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbb521cb-d2e4-492c-870c-1274a8bdba23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbb521cb-d2e4-492c-870c-1274a8bdba23_0">
											<gml:posList>35.6723591101269 139.73840220501137 26.783 35.6723591101269 139.73840220501137 27.518 35.67235001801011 139.73840567334142 27.518 35.67235001801011 139.73840567334142 26.72 35.6723591101269 139.73840220501137 26.72 35.6723591101269 139.73840220501137 26.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc4818d3-305b-4816-b2fb-e3235b2326f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc4818d3-305b-4816-b2fb-e3235b2326f8_0">
											<gml:posList>35.67235675927008 139.7383929618481 26.783 35.6723591101269 139.73840220501137 26.783 35.6723698692852 139.7383981050541 26.783 35.67236365755756 139.7383736332937 26.783 35.67234380628399 139.73838120158646 26.783 35.67234767616728 139.73839643016842 26.783 35.67235675927008 139.7383929618481 26.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07d7ab47-3eea-4a52-b6e9-763556cea698">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07d7ab47-3eea-4a52-b6e9-763556cea698_0">
											<gml:posList>35.67235675927008 139.7383929618481 26.783 35.67235675927008 139.7383929618481 27.518 35.6723591101269 139.73840220501137 27.518 35.6723591101269 139.73840220501137 26.783 35.67235675927008 139.7383929618481 26.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40586b6c-7071-4c10-aeec-3c516ba31f90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40586b6c-7071-4c10-aeec-3c516ba31f90_0">
											<gml:posList>35.67236282192711 139.73849135717927 26.72 35.67236282192711 139.73849135717927 27.762 35.672357651356414 139.73847267256437 27.762 35.672357651356414 139.73847267256437 26.72 35.67236282192711 139.73849135717927 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21b06f5f-365a-4ae2-b5ec-dc355a8bf0c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21b06f5f-365a-4ae2-b5ec-dc355a8bf0c6_0">
											<gml:posList>35.6723591101269 139.73840220501137 26.72 35.6723698692852 139.7383981050541 26.72 35.6723698692852 139.7383981050541 26.783 35.6723591101269 139.73840220501137 26.783 35.6723591101269 139.73840220501137 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f89f262-3119-4133-bfa7-1bba67b9fe2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f89f262-3119-4133-bfa7-1bba67b9fe2d_0">
											<gml:posList>35.6723698692852 139.7383981050541 26.72 35.67236365755756 139.7383736332937 26.72 35.67236365755756 139.7383736332937 26.783 35.6723698692852 139.7383981050541 26.783 35.6723698692852 139.7383981050541 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de3fea77-4700-437d-b0e8-9ecc9541c194">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de3fea77-4700-437d-b0e8-9ecc9541c194_0">
											<gml:posList>35.672385629824944 139.7384610516439 26.72 35.672357651356414 139.73847267256437 26.72 35.672357651356414 139.73847267256437 27.762 35.672385629824944 139.7384610516439 27.762 35.672385629824944 139.7384610516439 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a66ffe4-6477-406f-8919-532138e2a1b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a66ffe4-6477-406f-8919-532138e2a1b6_0">
											<gml:posList>35.672357651356414 139.73847267256437 27.762 35.67236282192711 139.73849135717927 27.762 35.67239080039743 139.73847973626457 27.762 35.672385629824944 139.7384610516439 27.762 35.672357651356414 139.73847267256437 27.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0cb1c7e-0583-4eb7-b5e0-89632ef8a8bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0cb1c7e-0583-4eb7-b5e0-89632ef8a8bc_0">
											<gml:posList>35.67236282192711 139.73849135717927 26.72 35.67239080039743 139.73847973626457 26.72 35.67239080039743 139.73847973626457 27.762 35.67236282192711 139.73849135717927 27.762 35.67236282192711 139.73849135717927 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f7618d3-91cf-476b-b328-f2b39cf34d56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f7618d3-91cf-476b-b328-f2b39cf34d56_0">
											<gml:posList>35.67239080039743 139.73847973626457 26.72 35.672385629824944 139.7384610516439 26.72 35.672385629824944 139.7384610516439 27.762 35.67239080039743 139.73847973626457 27.762 35.67239080039743 139.73847973626457 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d133ee0-2feb-4157-9659-7f275b695df4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d133ee0-2feb-4157-9659-7f275b695df4_0">
											<gml:posList>35.672398407768526 139.73849090635977 26.72 35.672398407768526 139.73849090635977 27.6 35.67239282274074 139.73847244315775 27.6 35.67239282274074 139.73847244315775 26.72 35.672398407768526 139.73849090635977 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13882ba4-2595-4b7f-a0ce-0608b6e63594">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13882ba4-2595-4b7f-a0ce-0608b6e63594_0">
											<gml:posList>35.67240168527512 139.7383949743486 27.193 35.67240746171889 139.73841612162954 27.193 35.67240746171889 139.73841612162954 28.954 35.67240168527512 139.7383949743486 28.954 35.67240168527512 139.7383949743486 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3174b2de-68cc-4117-b2a0-c6755d58b1eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3174b2de-68cc-4117-b2a0-c6755d58b1eb_0">
											<gml:posList>35.67239282274074 139.73847244315775 26.72 35.67239282274074 139.73847244315775 27.6 35.67241783588698 139.73846106876502 27.6 35.67241783588698 139.73846106876502 26.72 35.67239282274074 139.73847244315775 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c426d4dd-3771-4b00-8877-4f98252e0dea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c426d4dd-3771-4b00-8877-4f98252e0dea_0">
											<gml:posList>35.672398407768526 139.73849090635977 27.6 35.672423429930205 139.73847953196136 27.6 35.67241783588698 139.73846106876502 27.6 35.67239282274074 139.73847244315775 27.6 35.672398407768526 139.73849090635977 27.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6ed311f-2088-483d-ab2f-b32926e355f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6ed311f-2088-483d-ab2f-b32926e355f1_0">
											<gml:posList>35.67240168527512 139.7383949743486 27.193 35.67240168527512 139.7383949743486 28.954 35.67241667925227 139.7383888036702 28.954 35.67241667925227 139.7383888036702 27.193 35.67240168527512 139.7383949743486 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53951fca-6b96-408a-a5e2-130b138ae48a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53951fca-6b96-408a-a5e2-130b138ae48a_0">
											<gml:posList>35.672423429930205 139.73847953196136 26.72 35.672423429930205 139.73847953196136 27.6 35.672398407768526 139.73849090635977 27.6 35.672398407768526 139.73849090635977 26.72 35.672423429930205 139.73847953196136 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f126916d-768b-41b7-8100-1f881087b27a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f126916d-768b-41b7-8100-1f881087b27a_0">
											<gml:posList>35.67240168527512 139.7383949743486 28.954 35.67240746171889 139.73841612162954 28.954 35.67242246471953 139.7384099619905 28.954 35.67241667925227 139.7383888036702 28.954 35.67240168527512 139.7383949743486 28.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ab56f4a-f29d-4575-9ece-43cfd9662447">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ab56f4a-f29d-4575-9ece-43cfd9662447_0">
											<gml:posList>35.67240746171889 139.73841612162954 27.193 35.67242246471953 139.7384099619905 27.193 35.67242246471953 139.7384099619905 28.954 35.67240746171889 139.73841612162954 28.954 35.67240746171889 139.73841612162954 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-780359fb-1580-46af-865d-9bec6976a00c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-780359fb-1580-46af-865d-9bec6976a00c_0">
											<gml:posList>35.67242246471953 139.7384099619905 27.193 35.67241667925227 139.7383888036702 27.193 35.67241667925227 139.7383888036702 28.954 35.67242246471953 139.7384099619905 28.954 35.67242246471953 139.7384099619905 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b33b62f6-60e5-4a60-88fd-04711b00049a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b33b62f6-60e5-4a60-88fd-04711b00049a_0">
											<gml:posList>35.672422944933665 139.73845886445753 26.72 35.672422944933665 139.73845886445753 27.737 35.672417622117166 139.7384414393165 27.737 35.672417622117166 139.7384414393165 26.72 35.672422944933665 139.73845886445753 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a8f15b1-990e-4cf7-b6e3-0ac48ff1e16b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a8f15b1-990e-4cf7-b6e3-0ac48ff1e16b_0">
											<gml:posList>35.67241783588698 139.73846106876502 26.72 35.67241783588698 139.73846106876502 27.6 35.672423429930205 139.73847953196136 27.6 35.672423429930205 139.73847953196136 26.72 35.67241783588698 139.73846106876502 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1000aed0-7099-418c-8f68-b59872d90116">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1000aed0-7099-418c-8f68-b59872d90116_0">
											<gml:posList>35.672417622117166 139.7384414393165 26.72 35.672417622117166 139.7384414393165 27.737 35.672426443361914 139.73843738584148 27.737 35.672426443361914 139.73843738584148 26.72 35.672417622117166 139.7384414393165 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc80c413-5574-4214-b873-f9d67959b932">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc80c413-5574-4214-b873-f9d67959b932_0">
											<gml:posList>35.672426443361914 139.73843738584148 27.737 35.672417622117166 139.7384414393165 27.737 35.672422944933665 139.73845886445753 27.737 35.672431766178995 139.7384548109842 27.737 35.672426443361914 139.73843738584148 27.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72e53720-db4d-4b07-9bc5-421470a56799">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72e53720-db4d-4b07-9bc5-421470a56799_0">
											<gml:posList>35.672431766178995 139.7384548109842 26.72 35.672431766178995 139.7384548109842 27.737 35.672422944933665 139.73845886445753 27.737 35.672422944933665 139.73845886445753 26.72 35.672431766178995 139.7384548109842 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6365c11f-6afc-4e04-b8d3-9e5cb17651c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6365c11f-6afc-4e04-b8d3-9e5cb17651c3_0">
											<gml:posList>35.672426443361914 139.73843738584148 27.737 35.672431766178995 139.7384548109842 27.737 35.672431766178995 139.7384548109842 26.72 35.672426443361914 139.73843738584148 26.72 35.672426443361914 139.73843738584148 27.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a82ed0f2-ae5f-46ad-930b-59254db43faf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a82ed0f2-ae5f-46ad-930b-59254db43faf_0">
											<gml:posList>35.67242715089303 139.73835158651804 30.913 35.67243407310599 139.73837402489082 30.913 35.67243407310599 139.73837402489082 32.736 35.67242715089303 139.73835158651804 32.736 35.67242715089303 139.73835158651804 30.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5576762d-c8b7-4114-8f7d-b31c46dbcd62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5576762d-c8b7-4114-8f7d-b31c46dbcd62_0">
											<gml:posList>35.67243897258776 139.73834611552027 30.913 35.67242715089303 139.73835158651804 30.913 35.67242715089303 139.73835158651804 32.736 35.67243897258776 139.73834611552027 32.736 35.67243897258776 139.73834611552027 30.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-883af896-dc77-4fac-a03c-b23f3bf44a91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-883af896-dc77-4fac-a03c-b23f3bf44a91_0">
											<gml:posList>35.67243897258776 139.73834611552027 32.736 35.67242715089303 139.73835158651804 32.736 35.67243407310599 139.73837402489082 32.736 35.67244588578801 139.73836855390658 32.736 35.67243897258776 139.73834611552027 32.736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ce9841a-2f1e-427a-8d80-5f1700d57f70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ce9841a-2f1e-427a-8d80-5f1700d57f70_0">
											<gml:posList>35.67244588578801 139.73836855390658 30.913 35.67244588578801 139.73836855390658 32.736 35.67243407310599 139.73837402489082 32.736 35.67243407310599 139.73837402489082 30.913 35.67244588578801 139.73836855390658 30.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fca557e1-59f1-47f5-b552-528bd8190ec3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fca557e1-59f1-47f5-b552-528bd8190ec3_0">
											<gml:posList>35.67244588578801 139.73836855390658 30.913 35.67243897258776 139.73834611552027 30.913 35.67243897258776 139.73834611552027 32.736 35.67244588578801 139.73836855390658 32.736 35.67244588578801 139.73836855390658 30.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-969c4d7e-fccb-45c2-a81e-356a90ab87e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-969c4d7e-fccb-45c2-a81e-356a90ab87e0_0">
											<gml:posList>35.672314292024815 139.7384112941384 27.02 35.67231756346378 139.73842203853502 27.02 35.67231755445006 139.73842203854568 28.902 35.672314292024815 139.7384112941384 28.902 35.672314292024815 139.7384112941384 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9995e97-5654-4200-aba3-f0cb5a305c80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9995e97-5654-4200-aba3-f0cb5a305c80_0">
											<gml:posList>35.67232009541335 139.73842088669883 27.02 35.672316832979284 139.7384101312447 27.02 35.672316832979284 139.7384101312447 26.72 35.67232009541335 139.73842088669883 26.72 35.67232009541335 139.73842088669883 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_fb6c60b3-817b-40f5-941b-8dbe182bba9b_BuildingInstallation_1051">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63af8e09-ff87-44d3-9232-62655568cb03">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67225253761674 139.73836384513743 27.02 35.67224955511697 139.73835374110755 27.02 35.67225144392001 139.7383485690999 27.02 35.67225291184917 139.73834691038317 27.02 35.6722518709109 139.7383528104566 27.02 35.672254898601324 139.73836306908444 27.02 35.67225253761674 139.73836384513743 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f3b936b-28ba-4c03-be0b-609af4ad4772">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672254898601324 139.73836306908444 26.72 35.6722518709109 139.7383528104566 26.72 35.67225291184917 139.73834691038317 26.72 35.672261530309775 139.73833717923594 26.72 35.67226538667394 139.73833526361875 26.72 35.672286431372804 139.7383322782144 26.72 35.672294244245414 139.73832970616306 26.72 35.672318708056075 139.73830756202776 26.72 35.672330160055765 139.73830192577125 26.72 35.67234297523666 139.7382989611574 26.72 35.67235204434593 139.73830060738663 26.72 35.67235517432091 139.73830340949544 26.72 35.67236522498135 139.73833812788098 26.72 35.6723624136073 139.73833928005152 26.72 35.67235267142748 139.73830711305007 26.72 35.67235152588311 139.73830609812703 26.72 35.67234704515801 139.73830495459887 26.72 35.672342871710136 139.73830483803388 26.72 35.67233047986877 139.73830741551654 26.72 35.6723216325373 139.7383126731033 26.72 35.6722957079977 139.73833417827038 26.72 35.67229070679536 139.73833597373317 26.72 35.67226519298228 139.73834110745676 26.72 35.672263373361304 139.73834256775322 26.72 35.672255665251065 139.73835225363553 26.72 35.672255225835606 139.73835511520417 26.72 35.67225697120789 139.73836237069867 26.72 35.672254898601324 139.73836306908444 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96f73b8a-c961-4fc6-8de2-3a7b46651fbd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67241928254838 139.73826102525703 27.193 35.67236355273613 139.73828647627647 27.193 35.67237563545413 139.7383262184283 27.193 35.67237308552165 139.7383274255223 27.193 35.672359547802166 139.73828287985506 27.193 35.672419764788515 139.7382553246704 27.193 35.6724255666759 139.73827441725922 27.193 35.672423629423946 139.73827530327947 27.193 35.67241928254838 139.73826102525703 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ca3aff7-5d6d-4779-aaad-caa3594c8624">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67243332962029 139.73829994766007 29.448 35.67243139236817 139.73830083367977 29.447 35.672423629423946 139.73827530327947 27.247 35.6724255666759 139.73827441725922 27.247 35.67243332962029 139.73829994766007 29.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96d81180-d2ff-4f17-8ae1-672436c1abf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96d81180-d2ff-4f17-8ae1-672436c1abf4_0">
											<gml:posList>35.6724255666759 139.73827441725922 27.247 35.672423629423946 139.73827530327947 27.247 35.672423629423946 139.73827530327947 27.193 35.6724255666759 139.73827441725922 27.193 35.6724255666759 139.73827441725922 27.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7066576-38cd-49aa-aa12-45ed24126d69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7066576-38cd-49aa-aa12-45ed24126d69_0">
											<gml:posList>35.67243332962029 139.73829994766007 29.448 35.67243332962029 139.73829994766007 29.483 35.67243139236817 139.73830083367977 29.483 35.67243139236817 139.73830083367977 29.447 35.67243332962029 139.73829994766007 29.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0de45c66-1999-454e-8ad6-d040ef30773b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0de45c66-1999-454e-8ad6-d040ef30773b_0">
											<gml:posList>35.672419764788515 139.7382553246704 27.193 35.672359547802166 139.73828287985506 27.193 35.672359547802166 139.73828287985506 29.483 35.672419764788515 139.7382553246704 29.483 35.672419764788515 139.7382553246704 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63694011-4f94-419e-b342-33b173253cbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63694011-4f94-419e-b342-33b173253cbd_0">
											<gml:posList>35.67241928254838 139.73826102525703 27.193 35.67241928254838 139.73826102525703 29.483 35.67236355273613 139.73828647627647 29.483 35.67236355273613 139.73828647627647 27.193 35.67241928254838 139.73826102525703 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-166ca0f5-dbde-463a-a820-6405597ff1cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-166ca0f5-dbde-463a-a820-6405597ff1cd_0">
											<gml:posList>35.6724255666759 139.73827441725922 27.247 35.6724255666759 139.73827441725922 27.193 35.672419764788515 139.7382553246704 27.193 35.672419764788515 139.7382553246704 29.483 35.67243332962029 139.73829994766007 29.483 35.67243332962029 139.73829994766007 29.448 35.6724255666759 139.73827441725922 27.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbe83632-eeaf-4b3d-a08e-637be7d62c4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbe83632-eeaf-4b3d-a08e-637be7d62c4f_0">
											<gml:posList>35.672423629423946 139.73827530327947 27.247 35.67243139236817 139.73830083367977 29.447 35.67243139236817 139.73830083367977 29.483 35.67241928254838 139.73826102525703 29.483 35.67241928254838 139.73826102525703 27.193 35.672423629423946 139.73827530327947 27.193 35.672423629423946 139.73827530327947 27.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58787d3a-4c62-4182-90c0-5ee551cf5441">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58787d3a-4c62-4182-90c0-5ee551cf5441_0">
											<gml:posList>35.672419764788515 139.7382553246704 29.483 35.672359547802166 139.73828287985506 29.483 35.67237308552165 139.7383274255223 29.483 35.67237563545413 139.7383262184283 29.483 35.67236355273613 139.73828647627647 29.483 35.67241928254838 139.73826102525703 29.483 35.67243139236817 139.73830083367977 29.483 35.67243332962029 139.73829994766007 29.483 35.672419764788515 139.7382553246704 29.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c170520-bfb1-43d7-8a01-ee84b80a07a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c170520-bfb1-43d7-8a01-ee84b80a07a6_0">
											<gml:posList>35.67234297523666 139.7382989611574 26.72 35.67234297523666 139.7382989611574 30.193 35.67235204434593 139.73830060738663 30.193 35.67235204434593 139.73830060738663 26.72 35.67234297523666 139.7382989611574 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bb31bac-fbd8-405e-9531-7cdc1139fe7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bb31bac-fbd8-405e-9531-7cdc1139fe7a_0">
											<gml:posList>35.672330160055765 139.73830192577125 26.72 35.672330160055765 139.73830192577125 30.193 35.67234297523666 139.7382989611574 30.193 35.67234297523666 139.7382989611574 26.72 35.672330160055765 139.73830192577125 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1abe19a2-798f-4b2d-8c43-4b17d85f4cec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1abe19a2-798f-4b2d-8c43-4b17d85f4cec_0">
											<gml:posList>35.67235204434593 139.73830060738663 26.72 35.67235204434593 139.73830060738663 30.193 35.67235517432091 139.73830340949544 30.193 35.67235517432091 139.73830340949544 26.72 35.67235204434593 139.73830060738663 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1efc1d8-ead1-40e1-989d-4813344e23f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1efc1d8-ead1-40e1-989d-4813344e23f6_0">
											<gml:posList>35.672318708056075 139.73830756202776 26.72 35.672318708056075 139.73830756202776 30.193 35.672330160055765 139.73830192577125 30.193 35.672330160055765 139.73830192577125 26.72 35.672318708056075 139.73830756202776 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d4fdf37-a6f7-40a4-a7d6-36a084245500">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d4fdf37-a6f7-40a4-a7d6-36a084245500_0">
											<gml:posList>35.672342871710136 139.73830483803388 26.72 35.67234704515801 139.73830495459887 26.72 35.67234704515801 139.73830495459887 30.193 35.672342871710136 139.73830483803388 30.193 35.672342871710136 139.73830483803388 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8768b2f3-3587-43d2-86c3-776d991c7ab1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8768b2f3-3587-43d2-86c3-776d991c7ab1_0">
											<gml:posList>35.67237308552165 139.7383274255223 27.193 35.67237308552165 139.7383274255223 29.483 35.672359547802166 139.73828287985506 29.483 35.672359547802166 139.73828287985506 27.193 35.67237308552165 139.7383274255223 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bd0fd86-1f8c-4c7e-8348-9b531af66697">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bd0fd86-1f8c-4c7e-8348-9b531af66697_0">
											<gml:posList>35.67234704515801 139.73830495459887 26.72 35.67235152588311 139.73830609812703 26.72 35.67235152588311 139.73830609812703 30.193 35.67234704515801 139.73830495459887 30.193 35.67234704515801 139.73830495459887 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10cf0aeb-0ea3-4604-8e47-ff1266d24ea0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10cf0aeb-0ea3-4604-8e47-ff1266d24ea0_0">
											<gml:posList>35.672342871710136 139.73830483803388 26.72 35.672342871710136 139.73830483803388 30.193 35.67233047986877 139.73830741551654 30.193 35.67233047986877 139.73830741551654 26.72 35.672342871710136 139.73830483803388 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5517b0ba-0c42-42b3-913f-177e0753e098">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5517b0ba-0c42-42b3-913f-177e0753e098_0">
											<gml:posList>35.67236355273613 139.73828647627647 29.483 35.67237563545413 139.7383262184283 29.483 35.67237563545413 139.7383262184283 27.193 35.67236355273613 139.73828647627647 27.193 35.67236355273613 139.73828647627647 29.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c671f0b2-386d-42a1-b5a9-c770f61519f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c671f0b2-386d-42a1-b5a9-c770f61519f2_0">
											<gml:posList>35.67235152588311 139.73830609812703 26.72 35.67235267142748 139.73830711305007 26.72 35.67235267142748 139.73830711305007 30.193 35.67235152588311 139.73830609812703 30.193 35.67235152588311 139.73830609812703 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f6dac4b-aaa1-4074-a3a1-668a3042ba03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f6dac4b-aaa1-4074-a3a1-668a3042ba03_0">
											<gml:posList>35.6723216325373 139.7383126731033 26.72 35.67233047986877 139.73830741551654 26.72 35.67233047986877 139.73830741551654 30.193 35.6723216325373 139.7383126731033 30.193 35.6723216325373 139.7383126731033 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d835230-37a0-4daa-884f-c094a9e42374">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d835230-37a0-4daa-884f-c094a9e42374_0">
											<gml:posList>35.672294244245414 139.73832970616306 26.72 35.672294244245414 139.73832970616306 30.193 35.672318708056075 139.73830756202776 30.193 35.672318708056075 139.73830756202776 26.72 35.672294244245414 139.73832970616306 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-615b8c67-1e98-4cbd-a126-609e3f494622">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-615b8c67-1e98-4cbd-a126-609e3f494622_0">
											<gml:posList>35.67235517432091 139.73830340949544 26.72 35.67235517432091 139.73830340949544 30.193 35.67236522498135 139.73833812788098 30.193 35.67236522498135 139.73833812788098 26.72 35.67235517432091 139.73830340949544 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdc7c032-5e3f-4a9b-9193-a5c57cf6f681">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdc7c032-5e3f-4a9b-9193-a5c57cf6f681_0">
											<gml:posList>35.67235267142748 139.73830711305007 26.72 35.6723624136073 139.73833928005152 26.72 35.6723624136073 139.73833928005152 30.193 35.67235267142748 139.73830711305007 30.193 35.67235267142748 139.73830711305007 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c20dc06-5ff6-4604-8596-bb1904468c42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c20dc06-5ff6-4604-8596-bb1904468c42_0">
											<gml:posList>35.6722957079977 139.73833417827038 26.72 35.6723216325373 139.7383126731033 26.72 35.6723216325373 139.7383126731033 30.193 35.6722957079977 139.73833417827038 30.193 35.6722957079977 139.73833417827038 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b6381d4-c0ae-4104-96fb-ad6c71ae7cb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b6381d4-c0ae-4104-96fb-ad6c71ae7cb7_0">
											<gml:posList>35.67237563545413 139.7383262184283 27.193 35.67237563545413 139.7383262184283 29.483 35.67237308552165 139.7383274255223 29.483 35.67237308552165 139.7383274255223 27.193 35.67237563545413 139.7383262184283 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07dad2f2-a163-46d9-8c82-2ded4f341b21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07dad2f2-a163-46d9-8c82-2ded4f341b21_0">
											<gml:posList>35.672286431372804 139.7383322782144 26.72 35.672286431372804 139.7383322782144 30.193 35.672294244245414 139.73832970616306 30.193 35.672294244245414 139.73832970616306 26.72 35.672286431372804 139.7383322782144 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7f6df57-a303-4216-9c85-e30a4b6f9048">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7f6df57-a303-4216-9c85-e30a4b6f9048_0">
											<gml:posList>35.672255225835606 139.73835511520417 30.193 35.672255665251065 139.73835225363553 30.193 35.672263373361304 139.73834256775322 30.193 35.67226519298228 139.73834110745676 30.193 35.67229070679536 139.73833597373317 30.193 35.6722957079977 139.73833417827038 30.193 35.6723216325373 139.7383126731033 30.193 35.67233047986877 139.73830741551654 30.193 35.672342871710136 139.73830483803388 30.193 35.67234704515801 139.73830495459887 30.193 35.67235152588311 139.73830609812703 30.193 35.67235267142748 139.73830711305007 30.193 35.6723624136073 139.73833928005152 30.193 35.67236522498135 139.73833812788098 30.193 35.67235517432091 139.73830340949544 30.193 35.67235204434593 139.73830060738663 30.193 35.67234297523666 139.7382989611574 30.193 35.672330160055765 139.73830192577125 30.193 35.672318708056075 139.73830756202776 30.193 35.672294244245414 139.73832970616306 30.193 35.672286431372804 139.7383322782144 30.193 35.67226538667394 139.73833526361875 30.193 35.672261530309775 139.73833717923594 30.193 35.67225144392001 139.7383485690999 30.193 35.67224955511697 139.73835374110755 30.193 35.67225253761674 139.73836384513743 30.193 35.67225697120789 139.73836237069867 30.193 35.672255225835606 139.73835511520417 30.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad6ba63a-1a37-455c-80c9-e112e62e2194">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad6ba63a-1a37-455c-80c9-e112e62e2194_0">
											<gml:posList>35.67226538667394 139.73833526361875 30.193 35.672286431372804 139.7383322782144 30.193 35.672286431372804 139.7383322782144 26.72 35.67226538667394 139.73833526361875 26.72 35.67226538667394 139.73833526361875 30.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91665afa-cebd-4ab6-b956-f7c66701abb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91665afa-cebd-4ab6-b956-f7c66701abb0_0">
											<gml:posList>35.6722957079977 139.73833417827038 26.72 35.6722957079977 139.73833417827038 30.193 35.67229070679536 139.73833597373317 30.193 35.67229070679536 139.73833597373317 26.72 35.6722957079977 139.73833417827038 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a9287ff-0cc4-4bdd-9858-ba140a4a07bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a9287ff-0cc4-4bdd-9858-ba140a4a07bf_0">
											<gml:posList>35.67226538667394 139.73833526361875 26.72 35.672261530309775 139.73833717923594 26.72 35.672261530309775 139.73833717923594 30.193 35.67226538667394 139.73833526361875 30.193 35.67226538667394 139.73833526361875 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1636003-d93d-4ca8-9999-1d26ca7e6006">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1636003-d93d-4ca8-9999-1d26ca7e6006_0">
											<gml:posList>35.67226519298228 139.73834110745676 26.72 35.67229070679536 139.73833597373317 26.72 35.67229070679536 139.73833597373317 30.193 35.67226519298228 139.73834110745676 30.193 35.67226519298228 139.73834110745676 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c04c154-062f-42f7-8c3a-4906d07d5913">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c04c154-062f-42f7-8c3a-4906d07d5913_0">
											<gml:posList>35.67236522498135 139.73833812788098 26.72 35.67236522498135 139.73833812788098 30.193 35.6723624136073 139.73833928005152 30.193 35.6723624136073 139.73833928005152 26.72 35.67236522498135 139.73833812788098 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efd29375-7855-4dd5-b6dd-c9b25005b302">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efd29375-7855-4dd5-b6dd-c9b25005b302_0">
											<gml:posList>35.672263373361304 139.73834256775322 26.72 35.67226519298228 139.73834110745676 26.72 35.67226519298228 139.73834110745676 30.193 35.672263373361304 139.73834256775322 30.193 35.672263373361304 139.73834256775322 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18c2b2c7-399b-4008-bd83-0e4f387c5409">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18c2b2c7-399b-4008-bd83-0e4f387c5409_0">
											<gml:posList>35.67225291184917 139.73834691038317 27.02 35.67225144392001 139.7383485690999 27.02 35.67225144392001 139.7383485690999 30.193 35.672261530309775 139.73833717923594 30.193 35.672261530309775 139.73833717923594 26.72 35.67225291184917 139.73834691038317 26.72 35.67225291184917 139.73834691038317 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de7f033b-7c1c-48f7-80b9-abf66cf62500">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de7f033b-7c1c-48f7-80b9-abf66cf62500_0">
											<gml:posList>35.672255665251065 139.73835225363553 26.72 35.672263373361304 139.73834256775322 26.72 35.672263373361304 139.73834256775322 30.193 35.672255665251065 139.73835225363553 30.193 35.672255665251065 139.73835225363553 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27e5b165-0b28-4fe1-b876-b56a06d4d51f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27e5b165-0b28-4fe1-b876-b56a06d4d51f_0">
											<gml:posList>35.67225291184917 139.73834691038317 27.02 35.67225291184917 139.73834691038317 26.72 35.6722518709109 139.7383528104566 26.72 35.6722518709109 139.7383528104566 27.02 35.67225291184917 139.73834691038317 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ef5c59e-5ab0-4439-a3dc-af87dd5d35af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ef5c59e-5ab0-4439-a3dc-af87dd5d35af_0">
											<gml:posList>35.67225144392001 139.7383485690999 30.193 35.67225144392001 139.7383485690999 27.02 35.67224955511697 139.73835374110755 27.02 35.67224955511697 139.73835374110755 30.193 35.67225144392001 139.7383485690999 30.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28670904-b1ee-45de-8412-477f5c6c01e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28670904-b1ee-45de-8412-477f5c6c01e0_0">
											<gml:posList>35.672255225835606 139.73835511520417 26.72 35.672255665251065 139.73835225363553 26.72 35.672255665251065 139.73835225363553 30.193 35.672255225835606 139.73835511520417 30.193 35.672255225835606 139.73835511520417 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eedd56d1-1463-4539-ba0d-b2ca221d4d60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eedd56d1-1463-4539-ba0d-b2ca221d4d60_0">
											<gml:posList>35.672254898601324 139.73836306908444 26.72 35.672254898601324 139.73836306908444 27.02 35.6722518709109 139.7383528104566 27.02 35.6722518709109 139.7383528104566 26.72 35.672254898601324 139.73836306908444 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e435eaeb-2f1e-44a5-8086-6e76d5126fd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e435eaeb-2f1e-44a5-8086-6e76d5126fd8_0">
											<gml:posList>35.67225697120789 139.73836237069867 26.72 35.672255225835606 139.73835511520417 26.72 35.672255225835606 139.73835511520417 30.193 35.67225697120789 139.73836237069867 30.193 35.67225697120789 139.73836237069867 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d77dbfcc-1cc2-4e4e-aa48-dea35377190a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d77dbfcc-1cc2-4e4e-aa48-dea35377190a_0">
											<gml:posList>35.67225253761674 139.73836384513743 27.02 35.67225253761674 139.73836384513743 30.193 35.67224955511697 139.73835374110755 30.193 35.67224955511697 139.73835374110755 27.02 35.67225253761674 139.73836384513743 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb05e8ba-c987-4075-ab53-46ba72f64e87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb05e8ba-c987-4075-ab53-46ba72f64e87_0">
											<gml:posList>35.672254898601324 139.73836306908444 27.02 35.672254898601324 139.73836306908444 26.72 35.67225697120789 139.73836237069867 26.72 35.67225697120789 139.73836237069867 30.193 35.67225253761674 139.73836384513743 30.193 35.67225253761674 139.73836384513743 27.02 35.672254898601324 139.73836306908444 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-00b9a1ac-5a78-47d5-b20c-1c4744d650ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00b9a1ac-5a78-47d5-b20c-1c4744d650ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00b9a1ac-5a78-47d5-b20c-1c4744d650ef">
											<gml:posList>35.672293201365996 139.73832172076288 9.419 35.672318328981966 139.7382955107169 9.419 35.672333646114005 139.73828764952444 9.419 35.672345723102595 139.73828586776202 9.419 35.67236023614962 139.73828706567463 9.419 35.67235707306383 139.73827657521957 9.419 35.67242041683229 139.7382477791101 9.419 35.67246813303651 139.73840458348332 9.419 35.67246191583463 139.73840746294692 9.419 35.672479176960785 139.73846444269904 9.419 35.67234852484257 139.73852402763652 9.419 35.67231056869704 139.73839902585723 9.419 35.672268128709355 139.7384176342644 9.419 35.67224905880474 139.73835303471847 9.419 35.67225246885502 139.73833380973863 9.419 35.67226246536766 139.73832275137474 9.419 35.672293201365996 139.73832172076288 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdac9daa-68c1-4954-a596-0a6ee46e8ef7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdac9daa-68c1-4954-a596-0a6ee46e8ef7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdac9daa-68c1-4954-a596-0a6ee46e8ef7">
											<gml:posList>35.67225246885502 139.73833380973863 27.02 35.67224905880474 139.73835303471847 27.02 35.6722518709109 139.7383528104566 27.02 35.67225492196368 139.7383355521816 27.02 35.67225246885502 139.73833380973863 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8f83d44-865d-4da2-8845-a718b5b74df8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8f83d44-865d-4da2-8845-a718b5b74df8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8f83d44-865d-4da2-8845-a718b5b74df8">
											<gml:posList>35.67226246536766 139.73832275137474 27.02 35.67225246885502 139.73833380973863 27.02 35.67225492196368 139.7383355521816 27.02 35.672263540588965 139.73832603091657 27.02 35.67226246536766 139.73832275137474 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce1f8b37-d5de-42eb-8886-d2344c956cdf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce1f8b37-d5de-42eb-8886-d2344c956cdf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce1f8b37-d5de-42eb-8886-d2344c956cdf">
											<gml:posList>35.67224905880474 139.73835303471847 27.02 35.672268128709355 139.7384176342644 27.02 35.67226975685747 139.73841340151986 27.02 35.6722518709109 139.7383528104566 27.02 35.67224905880474 139.73835303471847 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c8581e9-db54-4b7b-a71a-4c2463a2d5bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c8581e9-db54-4b7b-a71a-4c2463a2d5bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c8581e9-db54-4b7b-a71a-4c2463a2d5bf">
											<gml:posList>35.672293201365996 139.73832172076288 27.02 35.67226246536766 139.73832275137474 27.02 35.672263540588965 139.73832603091657 27.02 35.67229423151871 139.73832500035937 27.02 35.672293201365996 139.73832172076288 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37a41179-944e-4521-aff7-d26d7957b16c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37a41179-944e-4521-aff7-d26d7957b16c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37a41179-944e-4521-aff7-d26d7957b16c">
											<gml:posList>35.672268128709355 139.7384176342644 27.02 35.67231056869704 139.73839902585723 27.02 35.672312169812045 139.7383948041886 27.02 35.67226975685747 139.73841340151986 27.02 35.672268128709355 139.7384176342644 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e465089a-8ab3-46d9-ab38-6c348769a987">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e465089a-8ab3-46d9-ab38-6c348769a987">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e465089a-8ab3-46d9-ab38-6c348769a987">
											<gml:posList>35.672318328981966 139.7382955107169 27.02 35.672293201365996 139.73832172076288 27.02 35.67229423151871 139.73832500035937 27.02 35.67231976442146 139.73829837006565 27.02 35.672318328981966 139.7382955107169 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a80f4804-31d0-4d93-8f1d-24f9c3da3b2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a80f4804-31d0-4d93-8f1d-24f9c3da3b2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a80f4804-31d0-4d93-8f1d-24f9c3da3b2b">
											<gml:posList>35.67231056869704 139.73839902585723 27.02 35.67231756347249 139.73842204958154 27.02 35.67232009542206 139.73842089774533 27.02 35.672312169812045 139.7383948041886 27.02 35.67231056869704 139.73839902585723 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69f4d67e-c7f0-48bc-a68a-e244f8e3b312">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69f4d67e-c7f0-48bc-a68a-e244f8e3b312">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69f4d67e-c7f0-48bc-a68a-e244f8e3b312">
											<gml:posList>35.672345797836925 139.738289192679 26.72 35.672334342725165 139.7382908853314 26.72 35.67231976442146 139.73829837006565 26.72 35.67229423151871 139.73832500035937 26.72 35.672263540588965 139.73832603091657 26.72 35.67225492196368 139.7383355521816 26.72 35.6722518709109 139.7383528104566 26.72 35.67226975685747 139.73841340151986 26.72 35.672312169812045 139.7383948041886 26.72 35.67232009542206 139.73842089774533 26.72 35.67234178365951 139.73841099647203 26.72 35.67235345141786 139.73841606406185 26.72 35.67238778186184 139.73840102222147 26.72 35.67236126639919 139.73829046678514 26.72 35.672345797836925 139.738289192679 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab734058-561e-437a-9737-ab97c2fa1f28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab734058-561e-437a-9737-ab97c2fa1f28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab734058-561e-437a-9737-ab97c2fa1f28">
											<gml:posList>35.672333646114005 139.73828764952444 27.02 35.672318328981966 139.7382955107169 27.02 35.67231976442146 139.73829837006565 27.02 35.672334342725165 139.7382908853314 27.02 35.672333646114005 139.73828764952444 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d9fdad54-8614-4333-88bd-c8e3e0ef954f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9fdad54-8614-4333-88bd-c8e3e0ef954f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9fdad54-8614-4333-88bd-c8e3e0ef954f">
											<gml:posList>35.67234178365951 139.73841099647203 32.094 35.67231756347249 139.73842204958154 32.094 35.67232443173808 139.7384446757846 32.094 35.67234865192716 139.738433622681 32.094 35.67234178365951 139.73841099647203 32.094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b47ea414-8179-4bb8-90ce-0dd452df0a46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b47ea414-8179-4bb8-90ce-0dd452df0a46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b47ea414-8179-4bb8-90ce-0dd452df0a46">
											<gml:posList>35.67234865192716 139.738433622681 29.57 35.67232443173808 139.7384446757846 29.57 35.6723291310757 139.73846015745454 29.57 35.67235335126618 139.73844910435494 29.57 35.67234865192716 139.738433622681 29.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0189ce5-bb3e-4d11-b3e1-43b69b60c590">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0189ce5-bb3e-4d11-b3e1-43b69b60c590">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0189ce5-bb3e-4d11-b3e1-43b69b60c590">
											<gml:posList>35.67235011691342 139.73851976179293 27.02 35.67233166302561 139.73845900561938 27.02 35.6723291310757 139.73846015745454 27.02 35.67234852484257 139.73852402763652 27.02 35.67235011691342 139.73851976179293 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6696511f-8f14-4461-9d54-1ea745d14447">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6696511f-8f14-4461-9d54-1ea745d14447">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6696511f-8f14-4461-9d54-1ea745d14447">
											<gml:posList>35.672345723102595 139.73828586776202 27.02 35.672333646114005 139.73828764952444 27.02 35.672334342725165 139.7382908853314 27.02 35.672345797836925 139.738289192679 27.02 35.672345723102595 139.73828586776202 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f72e294-e048-4a54-a603-700e774ca1f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f72e294-e048-4a54-a603-700e774ca1f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f72e294-e048-4a54-a603-700e774ca1f5">
											<gml:posList>35.67235011691342 139.73851976179293 26.72 35.67237297300997 139.73844765612947 26.72 35.672369872516896 139.7384479470089 26.72 35.67236673514198 139.7384471885113 26.72 35.67236399343056 139.73844523651994 26.72 35.67236208962936 139.73844281958262 26.72 35.67236045596983 139.73844005988317 26.72 35.67235345141786 139.73841606406185 26.72 35.67234178365951 139.73841099647203 26.72 35.67235335126618 139.73844910435494 26.72 35.67233166302561 139.73845900561938 26.72 35.67235011691342 139.73851976179293 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d7eb165c-d46d-48e1-83f9-2e584ba6ebf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7eb165c-d46d-48e1-83f9-2e584ba6ebf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7eb165c-d46d-48e1-83f9-2e584ba6ebf9">
											<gml:posList>35.67236023614962 139.73828706567463 27.02 35.672345723102595 139.73828586776202 27.02 35.672345797836925 139.738289192679 27.02 35.67236126639919 139.73829046678514 27.02 35.67236023614962 139.73828706567463 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3dff4f71-af5d-44bb-8bdc-16d175f71763">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3dff4f71-af5d-44bb-8bdc-16d175f71763">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3dff4f71-af5d-44bb-8bdc-16d175f71763">
											<gml:posList>35.67236272628663 139.73843861010025 28.295 35.67235668883207 139.7384179491859 28.295 35.67235345141786 139.73841606406185 28.295 35.67236045596983 139.73844005988317 28.295 35.67236272628663 139.73843861010025 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-699978ae-2daa-4393-9597-7313eca43297">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-699978ae-2daa-4393-9597-7313eca43297">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-699978ae-2daa-4393-9597-7313eca43297">
											<gml:posList>35.67236402600331 139.73844081786837 28.295 35.67236272628663 139.73843861010025 28.295 35.67236045596983 139.73844005988317 28.295 35.67236208962936 139.73844281958262 28.295 35.67236402600331 139.73844081786837 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5d57787-2749-4b12-af17-fd9b1dc63e4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5d57787-2749-4b12-af17-fd9b1dc63e4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5d57787-2749-4b12-af17-fd9b1dc63e4a">
											<gml:posList>35.67236399343056 139.73844523651994 28.295 35.67236556889016 139.73844277127847 28.295 35.67236402600331 139.73844081786837 28.295 35.67236208962936 139.73844281958262 28.295 35.67236399343056 139.73844523651994 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e708e39a-d270-457a-b36d-a6ff17786938">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e708e39a-d270-457a-b36d-a6ff17786938">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e708e39a-d270-457a-b36d-a6ff17786938">
											<gml:posList>35.67236399343056 139.73844523651994 28.295 35.672367652225795 139.7384442490481 28.295 35.67236556889016 139.73844277127847 28.295 35.67236399343056 139.73844523651994 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f59f449-dac4-4f80-a65a-106082802c11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f59f449-dac4-4f80-a65a-106082802c11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f59f449-dac4-4f80-a65a-106082802c11">
											<gml:posList>35.672367652225795 139.7384442490481 28.295 35.67236399343056 139.73844523651994 28.295 35.67236673514198 139.7384471885113 28.295 35.672367652225795 139.7384442490481 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba0ae4c6-6847-43b4-83bf-ef24e6bfe158">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba0ae4c6-6847-43b4-83bf-ef24e6bfe158">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba0ae4c6-6847-43b4-83bf-ef24e6bfe158">
											<gml:posList>35.672367652225795 139.7384442490481 28.295 35.67236673514198 139.7384471885113 28.295 35.672369872516896 139.7384479470089 28.295 35.672370014272886 139.73844482067216 28.295 35.672367652225795 139.7384442490481 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54941120-cf96-4d69-828e-34c3eab9e200">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54941120-cf96-4d69-828e-34c3eab9e200">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54941120-cf96-4d69-828e-34c3eab9e200">
											<gml:posList>35.67235668883207 139.7384179491859 28.295 35.672386243651104 139.73840500079572 28.295 35.67238778186184 139.73840102222147 28.295 35.67235345141786 139.73841606406185 28.295 35.67235668883207 139.7384179491859 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-91939def-67bf-4798-ba0b-005787048908">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91939def-67bf-4798-ba0b-005787048908">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91939def-67bf-4798-ba0b-005787048908">
											<gml:posList>35.67237242076181 139.73844459689323 28.295 35.672370014272886 139.73844482067216 28.295 35.672369872516896 139.7384479470089 28.295 35.67237297300997 139.73844765612947 28.295 35.67237242076181 139.73844459689323 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ee86e7f-91aa-41c6-9b71-4b6a89d58171">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ee86e7f-91aa-41c6-9b71-4b6a89d58171">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ee86e7f-91aa-41c6-9b71-4b6a89d58171">
											<gml:posList>35.67237242076181 139.73844459689323 28.036 35.67239491125686 139.73843473885637 28.036 35.672386243651104 139.73840500079572 28.036 35.67235668883207 139.7384179491859 28.036 35.67236272628663 139.73843861010025 28.036 35.67236402600331 139.73844081786837 28.036 35.67236556889016 139.73844277127847 28.036 35.672367652225795 139.7384442490481 28.036 35.672370014272886 139.73844482067216 28.036 35.67237242076181 139.73844459689323 28.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-743bac54-ffd8-484f-91b2-8eee2848d75d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-743bac54-ffd8-484f-91b2-8eee2848d75d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-743bac54-ffd8-484f-91b2-8eee2848d75d">
											<gml:posList>35.67239491125686 139.73843473885637 28.295 35.67237242076181 139.73844459689323 28.295 35.67237297300997 139.73844765612947 28.295 35.67239815767577 139.73843661292494 28.295 35.67239491125686 139.73843473885637 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e7ae60eb-2a51-49be-9f8c-4820ce333ed2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7ae60eb-2a51-49be-9f8c-4820ce333ed2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7ae60eb-2a51-49be-9f8c-4820ce333ed2">
											<gml:posList>35.672386243651104 139.73840500079572 28.295 35.67239491125686 139.73843473885637 28.295 35.67239815767577 139.73843661292494 28.295 35.67238778186184 139.73840102222147 28.295 35.672386243651104 139.73840500079572 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9434d1b-dd5d-45e4-80a5-d1b4b52d58e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9434d1b-dd5d-45e4-80a5-d1b4b52d58e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9434d1b-dd5d-45e4-80a5-d1b4b52d58e8">
											<gml:posList>35.67235707306383 139.73827657521957 27.193 35.672404699006634 139.73843326912763 27.193 35.67243962380065 139.73841751960254 27.193 35.672412811491974 139.73833055984903 27.193 35.67239949035583 139.73828633425205 27.193 35.67242816169386 139.73827323220237 27.193 35.67242041683229 139.7382477791101 27.193 35.67235707306383 139.73827657521957 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b60c96c-7875-462d-9987-5d961c0e929e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b60c96c-7875-462d-9987-5d961c0e929e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b60c96c-7875-462d-9987-5d961c0e929e">
											<gml:posList>35.67235011691342 139.73851976179293 26.72 35.67247569612473 139.738462491579 26.72 35.67239815767577 139.73843661292494 26.72 35.67237297300997 139.73844765612947 26.72 35.67235011691342 139.73851976179293 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de4e5354-bf73-4646-a0fb-43ff2e1c4ad9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de4e5354-bf73-4646-a0fb-43ff2e1c4ad9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de4e5354-bf73-4646-a0fb-43ff2e1c4ad9">
											<gml:posList>35.67247569612473 139.738462491579 27.02 35.67235011691342 139.73851976179293 27.02 35.67234852484257 139.73852402763652 27.02 35.672479176960785 139.73846444269904 27.02 35.67247569612473 139.738462491579 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c41436e-912a-4956-8d27-5420b60f9546">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c41436e-912a-4956-8d27-5420b60f9546">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c41436e-912a-4956-8d27-5420b60f9546">
											<gml:posList>35.67242816169386 139.73827323220237 27.247 35.67239949035583 139.73828633425205 27.247 35.672412811491974 139.73833055984903 31.044 35.67242816169386 139.73827323220237 27.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fd66cafe-82dd-4cac-98d9-0642f11729de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd66cafe-82dd-4cac-98d9-0642f11729de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd66cafe-82dd-4cac-98d9-0642f11729de">
											<gml:posList>35.67239815767577 139.73843661292494 26.72 35.67247569612473 139.738462491579 26.72 35.672459383876564 139.73840860373906 26.72 35.672404699006634 139.73843326912763 26.72 35.67236126639919 139.73829046678514 26.72 35.67238778186184 139.73840102222147 26.72 35.67239815767577 139.73843661292494 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32b8077e-d735-461f-95cb-588ad113bf1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32b8077e-d735-461f-95cb-588ad113bf1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32b8077e-d735-461f-95cb-588ad113bf1d">
											<gml:posList>35.672412811491974 139.73833055984903 31.266 35.672415796340324 139.73833221329295 31.266 35.67243712403877 139.73832233450418 31.266 35.672438455184015 139.73831867652095 31.266 35.672412811491974 139.73833055984903 31.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d5b4d2e-bd47-49b2-81ca-2775c04d70e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d5b4d2e-bd47-49b2-81ca-2775c04d70e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d5b4d2e-bd47-49b2-81ca-2775c04d70e2">
											<gml:posList>35.67242816169386 139.73827323220237 27.247 35.672412811491974 139.73833055984903 31.044 35.672438455184015 139.73831867652095 31.044 35.67242816169386 139.73827323220237 27.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c92da59a-f72b-4714-9ba2-e8b95ec37659">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c92da59a-f72b-4714-9ba2-e8b95ec37659">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c92da59a-f72b-4714-9ba2-e8b95ec37659">
											<gml:posList>35.67243962380065 139.73841751960254 31.266 35.67244097299364 139.73841388369252 31.266 35.672415796340324 139.73833221329295 31.266 35.672412811491974 139.73833055984903 31.266 35.67243962380065 139.73841751960254 31.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63bf696a-f54a-4f3c-a16c-20abdcd5f21f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63bf696a-f54a-4f3c-a16c-20abdcd5f21f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63bf696a-f54a-4f3c-a16c-20abdcd5f21f">
											<gml:posList>35.67242816169386 139.73827323220237 27.247 35.672438455184015 139.73831867652095 31.044 35.67244159092966 139.73831736931254 31.044 35.67242816169386 139.73827323220237 27.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6a44e75-c3c8-4bf2-b54d-f9633eea4d4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6a44e75-c3c8-4bf2-b54d-f9633eea4d4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6a44e75-c3c8-4bf2-b54d-f9633eea4d4d">
											<gml:posList>35.672415796340324 139.73833221329295 30.913 35.67244097299364 139.73841388369252 30.913 35.67246236395151 139.73840420368526 30.913 35.67243712403877 139.73832233450418 30.913 35.672415796340324 139.73833221329295 30.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed07a5fc-1e33-49d0-9120-df9b5f5f3644">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed07a5fc-1e33-49d0-9120-df9b5f5f3644">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed07a5fc-1e33-49d0-9120-df9b5f5f3644">
											<gml:posList>35.67246236395151 139.73840420368526 31.266 35.67246534881625 139.738405879226 31.266 35.672438455184015 139.73831867652095 31.266 35.67243712403877 139.73832233450418 31.266 35.67246236395151 139.73840420368526 31.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71079961-cfc8-4dcf-b7bc-bc9301e327ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71079961-cfc8-4dcf-b7bc-bc9301e327ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71079961-cfc8-4dcf-b7bc-bc9301e327ff">
											<gml:posList>35.67244097299364 139.73841388369252 31.266 35.67243962380065 139.73841751960254 31.266 35.67246534881625 139.738405879226 31.266 35.67246236395151 139.73840420368526 31.266 35.67244097299364 139.73841388369252 31.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65ab214e-ac03-4a63-93b5-c4ea436e7e61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65ab214e-ac03-4a63-93b5-c4ea436e7e61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65ab214e-ac03-4a63-93b5-c4ea436e7e61">
											<gml:posList>35.67244159092966 139.73831736931254 27.193 35.672438455184015 139.73831867652095 27.193 35.67246534881625 139.738405879226 27.193 35.67246813303651 139.73840458348332 27.193 35.67244159092966 139.73831736931254 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-223bca19-912f-477d-92a2-ae793efde4d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-223bca19-912f-477d-92a2-ae793efde4d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-223bca19-912f-477d-92a2-ae793efde4d6">
											<gml:posList>35.67247569612473 139.738462491579 27.02 35.672479176960785 139.73846444269904 27.02 35.67246191583463 139.73840746294692 27.02 35.672459383876564 139.73840860373906 27.02 35.67247569612473 139.738462491579 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a34174a-cd67-40ae-846b-d3ac6519b19b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a34174a-cd67-40ae-846b-d3ac6519b19b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a34174a-cd67-40ae-846b-d3ac6519b19b">
											<gml:posList>35.67246236395151 139.73840420368526 31.266 35.67243712403877 139.73832233450418 31.266 35.67243712403877 139.73832233450418 30.913 35.67246236395151 139.73840420368526 30.913 35.67246236395151 139.73840420368526 31.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08bc43cd-08fe-4844-8603-9614eb4b2265">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08bc43cd-08fe-4844-8603-9614eb4b2265">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08bc43cd-08fe-4844-8603-9614eb4b2265">
											<gml:posList>35.67244097299364 139.73841388369252 30.913 35.672415796340324 139.73833221329295 30.913 35.672415796340324 139.73833221329295 31.266 35.67244097299364 139.73841388369252 31.266 35.67244097299364 139.73841388369252 30.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a90a3391-aeb0-4663-8f40-ac764db047ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a90a3391-aeb0-4663-8f40-ac764db047ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a90a3391-aeb0-4663-8f40-ac764db047ac">
											<gml:posList>35.67225246885502 139.73833380973863 27.02 35.67225246885502 139.73833380973863 9.419 35.67224905880474 139.73835303471847 9.419 35.67224905880474 139.73835303471847 27.02 35.67225246885502 139.73833380973863 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a7b072d-3d56-4e7b-811c-c85023b5eb2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a7b072d-3d56-4e7b-811c-c85023b5eb2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a7b072d-3d56-4e7b-811c-c85023b5eb2f">
											<gml:posList>35.67225492196368 139.7383355521816 26.72 35.67225492196368 139.7383355521816 27.02 35.6722518709109 139.7383528104566 27.02 35.6722518709109 139.7383528104566 26.72 35.67225492196368 139.7383355521816 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0000ce61-8fcb-457d-a18d-b326829b04f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0000ce61-8fcb-457d-a18d-b326829b04f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0000ce61-8fcb-457d-a18d-b326829b04f8">
											<gml:posList>35.67226246536766 139.73832275137474 27.02 35.67226246536766 139.73832275137474 9.419 35.67225246885502 139.73833380973863 9.419 35.67225246885502 139.73833380973863 27.02 35.67226246536766 139.73832275137474 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f6081ad-0ef8-4e66-84f0-ac6e6d9e575e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f6081ad-0ef8-4e66-84f0-ac6e6d9e575e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f6081ad-0ef8-4e66-84f0-ac6e6d9e575e">
											<gml:posList>35.67224905880474 139.73835303471847 27.02 35.67224905880474 139.73835303471847 9.419 35.672268128709355 139.7384176342644 9.419 35.672268128709355 139.7384176342644 27.02 35.67224905880474 139.73835303471847 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ec58a1f-e101-40bc-aae6-580f65329d7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ec58a1f-e101-40bc-aae6-580f65329d7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ec58a1f-e101-40bc-aae6-580f65329d7e">
											<gml:posList>35.672263540588965 139.73832603091657 26.72 35.672263540588965 139.73832603091657 27.02 35.67225492196368 139.7383355521816 27.02 35.67225492196368 139.7383355521816 26.72 35.672263540588965 139.73832603091657 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64058448-25b6-4600-bafb-8659cb3bf571">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64058448-25b6-4600-bafb-8659cb3bf571">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64058448-25b6-4600-bafb-8659cb3bf571">
											<gml:posList>35.6722518709109 139.7383528104566 26.72 35.6722518709109 139.7383528104566 27.02 35.67226975685747 139.73841340151986 27.02 35.67226975685747 139.73841340151986 26.72 35.6722518709109 139.7383528104566 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-880fe6a4-f6b7-48e5-b942-186a1c0809a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-880fe6a4-f6b7-48e5-b942-186a1c0809a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-880fe6a4-f6b7-48e5-b942-186a1c0809a4">
											<gml:posList>35.672293201365996 139.73832172076288 27.02 35.672293201365996 139.73832172076288 9.419 35.67226246536766 139.73832275137474 9.419 35.67226246536766 139.73832275137474 27.02 35.672293201365996 139.73832172076288 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9920446-3d1c-4611-9bb7-99167b31f0c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9920446-3d1c-4611-9bb7-99167b31f0c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9920446-3d1c-4611-9bb7-99167b31f0c1">
											<gml:posList>35.67229423151871 139.73832500035937 26.72 35.67229423151871 139.73832500035937 27.02 35.672263540588965 139.73832603091657 27.02 35.672263540588965 139.73832603091657 26.72 35.67229423151871 139.73832500035937 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-704b3f29-fe4f-4f54-af5c-40bd8777ceac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-704b3f29-fe4f-4f54-af5c-40bd8777ceac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-704b3f29-fe4f-4f54-af5c-40bd8777ceac">
											<gml:posList>35.672268128709355 139.7384176342644 27.02 35.672268128709355 139.7384176342644 9.419 35.67231056869704 139.73839902585723 9.419 35.67231056869704 139.73839902585723 27.02 35.672268128709355 139.7384176342644 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ceb78d2-52e3-4b23-8042-4197f2965af4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ceb78d2-52e3-4b23-8042-4197f2965af4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ceb78d2-52e3-4b23-8042-4197f2965af4">
											<gml:posList>35.67226975685747 139.73841340151986 26.72 35.67226975685747 139.73841340151986 27.02 35.672312169812045 139.7383948041886 27.02 35.672312169812045 139.7383948041886 26.72 35.67226975685747 139.73841340151986 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72034a14-ef8d-4781-b965-703db2cffbe1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72034a14-ef8d-4781-b965-703db2cffbe1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72034a14-ef8d-4781-b965-703db2cffbe1">
											<gml:posList>35.672318328981966 139.7382955107169 27.02 35.672318328981966 139.7382955107169 9.419 35.672293201365996 139.73832172076288 9.419 35.672293201365996 139.73832172076288 27.02 35.672318328981966 139.7382955107169 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbce7081-3696-4b2d-b376-1f74084a3f98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbce7081-3696-4b2d-b376-1f74084a3f98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbce7081-3696-4b2d-b376-1f74084a3f98">
											<gml:posList>35.67231976442146 139.73829837006565 26.72 35.67231976442146 139.73829837006565 27.02 35.67229423151871 139.73832500035937 27.02 35.67229423151871 139.73832500035937 26.72 35.67231976442146 139.73829837006565 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-660f6bae-6856-4e67-a1aa-43c841ea7c6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-660f6bae-6856-4e67-a1aa-43c841ea7c6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-660f6bae-6856-4e67-a1aa-43c841ea7c6b">
											<gml:posList>35.672312169812045 139.7383948041886 26.72 35.672312169812045 139.7383948041886 27.02 35.67232009542206 139.73842089774533 27.02 35.67232009542206 139.73842089774533 26.72 35.672312169812045 139.7383948041886 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da38c059-9205-4832-bbc1-68ea421119cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da38c059-9205-4832-bbc1-68ea421119cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da38c059-9205-4832-bbc1-68ea421119cd">
											<gml:posList>35.672333646114005 139.73828764952444 27.02 35.672333646114005 139.73828764952444 9.419 35.672318328981966 139.7382955107169 9.419 35.672318328981966 139.7382955107169 27.02 35.672333646114005 139.73828764952444 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-655c23c5-27d2-4d29-adaa-37da74ced8fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-655c23c5-27d2-4d29-adaa-37da74ced8fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-655c23c5-27d2-4d29-adaa-37da74ced8fb">
											<gml:posList>35.672334342725165 139.7382908853314 26.72 35.672334342725165 139.7382908853314 27.02 35.67231976442146 139.73829837006565 27.02 35.67231976442146 139.73829837006565 26.72 35.672334342725165 139.7382908853314 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ef822e6-f0de-4225-b29b-0798f9942473">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ef822e6-f0de-4225-b29b-0798f9942473">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ef822e6-f0de-4225-b29b-0798f9942473">
											<gml:posList>35.67234852484257 139.73852402763652 9.419 35.67234852484257 139.73852402763652 27.02 35.6723291310757 139.73846015745454 27.02 35.6723291310757 139.73846015745454 29.57 35.67232443173808 139.7384446757846 29.57 35.67232443173808 139.7384446757846 32.094 35.67231756347249 139.73842204958154 32.094 35.67231756347249 139.73842204958154 27.02 35.67231056869704 139.73839902585723 27.02 35.67231056869704 139.73839902585723 9.419 35.67234852484257 139.73852402763652 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16277296-f94f-4eae-986b-fa6ef9aa0f04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16277296-f94f-4eae-986b-fa6ef9aa0f04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16277296-f94f-4eae-986b-fa6ef9aa0f04">
											<gml:posList>35.67232009542206 139.73842089774533 27.02 35.67231756347249 139.73842204958154 27.02 35.67231756347249 139.73842204958154 32.094 35.67234178365951 139.73841099647203 32.094 35.67234178365951 139.73841099647203 26.72 35.67232009542206 139.73842089774533 26.72 35.67232009542206 139.73842089774533 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec1b27db-b92b-4746-91c8-456b2945e732">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec1b27db-b92b-4746-91c8-456b2945e732">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec1b27db-b92b-4746-91c8-456b2945e732">
											<gml:posList>35.67234865192716 139.738433622681 32.094 35.67232443173808 139.7384446757846 32.094 35.67232443173808 139.7384446757846 29.57 35.67234865192716 139.738433622681 29.57 35.67234865192716 139.738433622681 32.094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76d5e7b5-d26f-4679-8402-03b10ad19e88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76d5e7b5-d26f-4679-8402-03b10ad19e88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76d5e7b5-d26f-4679-8402-03b10ad19e88">
											<gml:posList>35.672333646114005 139.73828764952444 9.419 35.672333646114005 139.73828764952444 27.02 35.672345723102595 139.73828586776202 27.02 35.672345723102595 139.73828586776202 9.419 35.672333646114005 139.73828764952444 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1de8bb7-bbc1-4480-993f-5e8be844876e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1de8bb7-bbc1-4480-993f-5e8be844876e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1de8bb7-bbc1-4480-993f-5e8be844876e">
											<gml:posList>35.672345797836925 139.738289192679 26.72 35.672345797836925 139.738289192679 27.02 35.672334342725165 139.7382908853314 27.02 35.672334342725165 139.7382908853314 26.72 35.672345797836925 139.738289192679 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f142d8af-e1d7-43d6-ac43-eda7160ea9b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f142d8af-e1d7-43d6-ac43-eda7160ea9b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f142d8af-e1d7-43d6-ac43-eda7160ea9b4">
											<gml:posList>35.67233166302561 139.73845900561938 26.72 35.67233166302561 139.73845900561938 27.02 35.67235011691342 139.73851976179293 27.02 35.67235011691342 139.73851976179293 26.72 35.67233166302561 139.73845900561938 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-732c9097-ba07-4187-9d7a-130595335108">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-732c9097-ba07-4187-9d7a-130595335108">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-732c9097-ba07-4187-9d7a-130595335108">
											<gml:posList>35.67235335126618 139.73844910435494 26.72 35.67235335126618 139.73844910435494 29.57 35.6723291310757 139.73846015745454 29.57 35.6723291310757 139.73846015745454 27.02 35.67233166302561 139.73845900561938 27.02 35.67233166302561 139.73845900561938 26.72 35.67235335126618 139.73844910435494 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ace60a44-3e2c-4a7e-b1ed-1f557f2ed0ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ace60a44-3e2c-4a7e-b1ed-1f557f2ed0ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ace60a44-3e2c-4a7e-b1ed-1f557f2ed0ae">
											<gml:posList>35.67234865192716 139.738433622681 29.57 35.67235335126618 139.73844910435494 29.57 35.67235335126618 139.73844910435494 26.72 35.67234178365951 139.73841099647203 26.72 35.67234178365951 139.73841099647203 32.094 35.67234865192716 139.738433622681 32.094 35.67234865192716 139.738433622681 29.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e3603ac-8d52-4d6b-9b78-06f12c3ea1d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e3603ac-8d52-4d6b-9b78-06f12c3ea1d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e3603ac-8d52-4d6b-9b78-06f12c3ea1d8">
											<gml:posList>35.67236023614962 139.73828706567463 27.02 35.67236023614962 139.73828706567463 9.419 35.672345723102595 139.73828586776202 9.419 35.672345723102595 139.73828586776202 27.02 35.67236023614962 139.73828706567463 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-637e433b-f3a4-4289-9437-54d35d4c2643">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-637e433b-f3a4-4289-9437-54d35d4c2643">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-637e433b-f3a4-4289-9437-54d35d4c2643">
											<gml:posList>35.67236126639919 139.73829046678514 26.72 35.67236126639919 139.73829046678514 27.02 35.672345797836925 139.738289192679 27.02 35.672345797836925 139.738289192679 26.72 35.67236126639919 139.73829046678514 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a7deba8-854d-49d8-a2e2-86933cde9bf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a7deba8-854d-49d8-a2e2-86933cde9bf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a7deba8-854d-49d8-a2e2-86933cde9bf2">
											<gml:posList>35.67236045596983 139.73844005988317 28.295 35.67235345141786 139.73841606406185 28.295 35.67235345141786 139.73841606406185 26.72 35.67236045596983 139.73844005988317 26.72 35.67236045596983 139.73844005988317 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f6f0c9d-198a-4ffe-a094-0c2a72d7c251">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f6f0c9d-198a-4ffe-a094-0c2a72d7c251">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f6f0c9d-198a-4ffe-a094-0c2a72d7c251">
											<gml:posList>35.67235707306383 139.73827657521957 27.193 35.67235707306383 139.73827657521957 9.419 35.67236023614962 139.73828706567463 27.02 35.67235707306383 139.73827657521957 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afe408da-72ad-4c96-bd12-279b721eabe5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afe408da-72ad-4c96-bd12-279b721eabe5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afe408da-72ad-4c96-bd12-279b721eabe5">
											<gml:posList>35.67235707306383 139.73827657521957 9.419 35.67236023614962 139.73828706567463 9.419 35.67236023614962 139.73828706567463 27.02 35.67235707306383 139.73827657521957 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ba5e657-1806-4636-bd21-ae583ebe6c1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ba5e657-1806-4636-bd21-ae583ebe6c1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ba5e657-1806-4636-bd21-ae583ebe6c1d">
											<gml:posList>35.67235707306383 139.73827657521957 27.193 35.67236023614962 139.73828706567463 27.02 35.67236126639919 139.73829046678514 27.02 35.67235707306383 139.73827657521957 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd2ad5f2-933b-40d3-88b4-97cd931269fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd2ad5f2-933b-40d3-88b4-97cd931269fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd2ad5f2-933b-40d3-88b4-97cd931269fa">
											<gml:posList>35.67236272628663 139.73843861010025 28.036 35.67235668883207 139.7384179491859 28.036 35.67235668883207 139.7384179491859 28.295 35.67236272628663 139.73843861010025 28.295 35.67236272628663 139.73843861010025 28.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9db09ff3-83db-4776-bc29-538df8d16a6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9db09ff3-83db-4776-bc29-538df8d16a6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9db09ff3-83db-4776-bc29-538df8d16a6a">
											<gml:posList>35.67236208962936 139.73844281958262 28.295 35.67236045596983 139.73844005988317 28.295 35.67236045596983 139.73844005988317 26.72 35.67236208962936 139.73844281958262 26.72 35.67236208962936 139.73844281958262 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cb1a70c-db7b-4867-bafc-15144e06f71e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cb1a70c-db7b-4867-bafc-15144e06f71e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cb1a70c-db7b-4867-bafc-15144e06f71e">
											<gml:posList>35.67236399343056 139.73844523651994 28.295 35.67236208962936 139.73844281958262 28.295 35.67236208962936 139.73844281958262 26.72 35.67236399343056 139.73844523651994 26.72 35.67236399343056 139.73844523651994 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86eb6fb2-d2f5-443e-be94-21811f5848b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86eb6fb2-d2f5-443e-be94-21811f5848b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86eb6fb2-d2f5-443e-be94-21811f5848b0">
											<gml:posList>35.67236402600331 139.73844081786837 28.036 35.67236272628663 139.73843861010025 28.036 35.67236272628663 139.73843861010025 28.295 35.67236402600331 139.73844081786837 28.295 35.67236402600331 139.73844081786837 28.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee91fe61-47d5-4bd0-bd5c-c9add39a2646">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee91fe61-47d5-4bd0-bd5c-c9add39a2646">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee91fe61-47d5-4bd0-bd5c-c9add39a2646">
											<gml:posList>35.67236556889016 139.73844277127847 28.036 35.67236402600331 139.73844081786837 28.036 35.67236402600331 139.73844081786837 28.295 35.67236556889016 139.73844277127847 28.295 35.67236556889016 139.73844277127847 28.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-338b5d52-7970-456d-8f20-ad901ac3a3bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-338b5d52-7970-456d-8f20-ad901ac3a3bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-338b5d52-7970-456d-8f20-ad901ac3a3bf">
											<gml:posList>35.67236673514198 139.7384471885113 28.295 35.67236399343056 139.73844523651994 28.295 35.67236399343056 139.73844523651994 26.72 35.67236673514198 139.7384471885113 26.72 35.67236673514198 139.7384471885113 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e0c6f63-123e-4825-acee-cb623ca83737">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e0c6f63-123e-4825-acee-cb623ca83737">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e0c6f63-123e-4825-acee-cb623ca83737">
											<gml:posList>35.672367652225795 139.7384442490481 28.036 35.67236556889016 139.73844277127847 28.036 35.67236556889016 139.73844277127847 28.295 35.672367652225795 139.7384442490481 28.295 35.672367652225795 139.7384442490481 28.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d366e69c-d2fc-49e6-a5f3-d419b5a5e4ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d366e69c-d2fc-49e6-a5f3-d419b5a5e4ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d366e69c-d2fc-49e6-a5f3-d419b5a5e4ec">
											<gml:posList>35.672369872516896 139.7384479470089 28.295 35.67236673514198 139.7384471885113 28.295 35.67236673514198 139.7384471885113 26.72 35.672369872516896 139.7384479470089 26.72 35.672369872516896 139.7384479470089 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d0a1f46-52eb-429a-8510-06ed256041fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d0a1f46-52eb-429a-8510-06ed256041fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d0a1f46-52eb-429a-8510-06ed256041fb">
											<gml:posList>35.672370014272886 139.73844482067216 28.036 35.672367652225795 139.7384442490481 28.036 35.672367652225795 139.7384442490481 28.295 35.672370014272886 139.73844482067216 28.295 35.672370014272886 139.73844482067216 28.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06e14357-1e17-4a04-9e35-8ad3996c63c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06e14357-1e17-4a04-9e35-8ad3996c63c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06e14357-1e17-4a04-9e35-8ad3996c63c6">
											<gml:posList>35.67235345141786 139.73841606406185 28.295 35.67238778186184 139.73840102222147 28.295 35.67238778186184 139.73840102222147 26.72 35.67235345141786 139.73841606406185 26.72 35.67235345141786 139.73841606406185 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d557ad78-8115-4129-8e41-745830a068dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d557ad78-8115-4129-8e41-745830a068dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d557ad78-8115-4129-8e41-745830a068dd">
											<gml:posList>35.67237242076181 139.73844459689323 28.036 35.672370014272886 139.73844482067216 28.036 35.672370014272886 139.73844482067216 28.295 35.67237242076181 139.73844459689323 28.295 35.67237242076181 139.73844459689323 28.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-872a2422-fc0a-4a0c-b3bf-38489cf391bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-872a2422-fc0a-4a0c-b3bf-38489cf391bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-872a2422-fc0a-4a0c-b3bf-38489cf391bc">
											<gml:posList>35.67237297300997 139.73844765612947 28.295 35.672369872516896 139.7384479470089 28.295 35.672369872516896 139.7384479470089 26.72 35.67237297300997 139.73844765612947 26.72 35.67237297300997 139.73844765612947 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00bd1809-2ac9-4583-b387-8d38d623b39e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00bd1809-2ac9-4583-b387-8d38d623b39e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00bd1809-2ac9-4583-b387-8d38d623b39e">
											<gml:posList>35.67235668883207 139.7384179491859 28.036 35.672386243651104 139.73840500079572 28.036 35.672386243651104 139.73840500079572 28.295 35.67235668883207 139.7384179491859 28.295 35.67235668883207 139.7384179491859 28.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50cd2e7f-d8dc-4f09-8844-7b18a1b94f79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50cd2e7f-d8dc-4f09-8844-7b18a1b94f79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50cd2e7f-d8dc-4f09-8844-7b18a1b94f79">
											<gml:posList>35.672404699006634 139.73843326912763 26.72 35.67235707306383 139.73827657521957 27.193 35.67236126639919 139.73829046678514 27.02 35.672404699006634 139.73843326912763 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c5a0e4d-9b75-40dd-bbdc-7421516aa325">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c5a0e4d-9b75-40dd-bbdc-7421516aa325">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c5a0e4d-9b75-40dd-bbdc-7421516aa325">
											<gml:posList>35.672404699006634 139.73843326912763 26.72 35.672404699006634 139.73843326912763 27.193 35.67235707306383 139.73827657521957 27.193 35.672404699006634 139.73843326912763 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3982ebd-95a3-472c-948d-ec1a9c2cb9c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3982ebd-95a3-472c-948d-ec1a9c2cb9c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3982ebd-95a3-472c-948d-ec1a9c2cb9c1">
											<gml:posList>35.672404699006634 139.73843326912763 26.72 35.67236126639919 139.73829046678514 27.02 35.67236126639919 139.73829046678514 26.72 35.672404699006634 139.73843326912763 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eeb043d8-3a7b-4095-9fa6-e5fa1ebef3a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eeb043d8-3a7b-4095-9fa6-e5fa1ebef3a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eeb043d8-3a7b-4095-9fa6-e5fa1ebef3a8">
											<gml:posList>35.67239491125686 139.73843473885637 28.036 35.67237242076181 139.73844459689323 28.036 35.67237242076181 139.73844459689323 28.295 35.67239491125686 139.73843473885637 28.295 35.67239491125686 139.73843473885637 28.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-186692ca-f6aa-449e-a1c2-89fdc54fd581">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-186692ca-f6aa-449e-a1c2-89fdc54fd581">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-186692ca-f6aa-449e-a1c2-89fdc54fd581">
											<gml:posList>35.67239815767577 139.73843661292494 28.295 35.67237297300997 139.73844765612947 28.295 35.67237297300997 139.73844765612947 26.72 35.67239815767577 139.73843661292494 26.72 35.67239815767577 139.73843661292494 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7952424b-51f7-4e38-b69d-c713f271d102">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7952424b-51f7-4e38-b69d-c713f271d102">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7952424b-51f7-4e38-b69d-c713f271d102">
											<gml:posList>35.67235707306383 139.73827657521957 9.419 35.67235707306383 139.73827657521957 27.193 35.67242041683229 139.7382477791101 27.193 35.67242041683229 139.7382477791101 9.419 35.67235707306383 139.73827657521957 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6791a884-b185-4ab8-acdf-b279a42c5cbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6791a884-b185-4ab8-acdf-b279a42c5cbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6791a884-b185-4ab8-acdf-b279a42c5cbb">
											<gml:posList>35.672386243651104 139.73840500079572 28.036 35.67239491125686 139.73843473885637 28.036 35.67239491125686 139.73843473885637 28.295 35.672386243651104 139.73840500079572 28.295 35.672386243651104 139.73840500079572 28.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37d82746-59af-4162-b9bc-24a8448a48cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37d82746-59af-4162-b9bc-24a8448a48cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37d82746-59af-4162-b9bc-24a8448a48cd">
											<gml:posList>35.67238778186184 139.73840102222147 28.295 35.67239815767577 139.73843661292494 28.295 35.67239815767577 139.73843661292494 26.72 35.67238778186184 139.73840102222147 26.72 35.67238778186184 139.73840102222147 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ead4d8fd-7147-45e6-8c71-d4e5dd17a7d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ead4d8fd-7147-45e6-8c71-d4e5dd17a7d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ead4d8fd-7147-45e6-8c71-d4e5dd17a7d2">
											<gml:posList>35.672412811491974 139.73833055984903 27.193 35.672412811491974 139.73833055984903 31.044 35.67239949035583 139.73828633425205 27.247 35.67239949035583 139.73828633425205 27.193 35.672412811491974 139.73833055984903 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bed225e-a0af-435a-96f0-bbf8842888a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bed225e-a0af-435a-96f0-bbf8842888a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bed225e-a0af-435a-96f0-bbf8842888a5">
											<gml:posList>35.67235011691342 139.73851976179293 26.72 35.67235011691342 139.73851976179293 27.02 35.67247569612473 139.738462491579 27.02 35.67247569612473 139.738462491579 26.72 35.67235011691342 139.73851976179293 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-449bcd95-655d-4d63-85e2-6956f41cc0c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-449bcd95-655d-4d63-85e2-6956f41cc0c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-449bcd95-655d-4d63-85e2-6956f41cc0c5">
											<gml:posList>35.67234852484257 139.73852402763652 9.419 35.672479176960785 139.73846444269904 9.419 35.672479176960785 139.73846444269904 27.02 35.67234852484257 139.73852402763652 27.02 35.67234852484257 139.73852402763652 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e2aca3a-155c-4c07-958e-48b61f618138">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e2aca3a-155c-4c07-958e-48b61f618138">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e2aca3a-155c-4c07-958e-48b61f618138">
											<gml:posList>35.67242816169386 139.73827323220237 27.193 35.67239949035583 139.73828633425205 27.193 35.67239949035583 139.73828633425205 27.247 35.67242816169386 139.73827323220237 27.247 35.67242816169386 139.73827323220237 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04abb7c7-6cb1-4c8b-8e71-fd1715f53394">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04abb7c7-6cb1-4c8b-8e71-fd1715f53394">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04abb7c7-6cb1-4c8b-8e71-fd1715f53394">
											<gml:posList>35.67243962380065 139.73841751960254 27.193 35.672404699006634 139.73843326912763 27.193 35.672404699006634 139.73843326912763 26.72 35.67243962380065 139.73841751960254 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2d847dc-81e5-418d-a634-fd3b559b9a8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2d847dc-81e5-418d-a634-fd3b559b9a8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2d847dc-81e5-418d-a634-fd3b559b9a8c">
											<gml:posList>35.672438455184015 139.73831867652095 31.044 35.672412811491974 139.73833055984903 31.044 35.672412811491974 139.73833055984903 31.266 35.672438455184015 139.73831867652095 31.266 35.672438455184015 139.73831867652095 31.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-089dc592-83ac-47ff-a447-6123d3c0a892">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-089dc592-83ac-47ff-a447-6123d3c0a892">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-089dc592-83ac-47ff-a447-6123d3c0a892">
											<gml:posList>35.672412811491974 139.73833055984903 31.044 35.672412811491974 139.73833055984903 27.193 35.67243962380065 139.73841751960254 27.193 35.67243962380065 139.73841751960254 31.266 35.672412811491974 139.73833055984903 31.266 35.672412811491974 139.73833055984903 31.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a1ff3c0-391e-43ce-88df-6104ad2d54f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a1ff3c0-391e-43ce-88df-6104ad2d54f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a1ff3c0-391e-43ce-88df-6104ad2d54f3">
											<gml:posList>35.672415796340324 139.73833221329295 30.913 35.67243712403877 139.73832233450418 30.913 35.67243712403877 139.73832233450418 31.266 35.672415796340324 139.73833221329295 31.266 35.672415796340324 139.73833221329295 30.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8c983d8-2feb-4091-9ef2-f79c1ba323cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8c983d8-2feb-4091-9ef2-f79c1ba323cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8c983d8-2feb-4091-9ef2-f79c1ba323cb">
											<gml:posList>35.67243962380065 139.73841751960254 27.193 35.672404699006634 139.73843326912763 26.72 35.672459383876564 139.73840860373906 27.02 35.67243962380065 139.73841751960254 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c196b7e-118c-409a-9267-7121bbf49dcd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c196b7e-118c-409a-9267-7121bbf49dcd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c196b7e-118c-409a-9267-7121bbf49dcd">
											<gml:posList>35.672404699006634 139.73843326912763 26.72 35.672459383876564 139.73840860373906 26.72 35.672459383876564 139.73840860373906 27.02 35.672404699006634 139.73843326912763 26.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fe186c1-2f40-48a6-ad7e-9b90cb6567eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fe186c1-2f40-48a6-ad7e-9b90cb6567eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fe186c1-2f40-48a6-ad7e-9b90cb6567eb">
											<gml:posList>35.67244159092966 139.73831736931254 31.044 35.672438455184015 139.73831867652095 31.044 35.672438455184015 139.73831867652095 27.193 35.67244159092966 139.73831736931254 27.193 35.67244159092966 139.73831736931254 31.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db8a0ee9-df5f-468d-9560-e2e7508da9f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db8a0ee9-df5f-468d-9560-e2e7508da9f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db8a0ee9-df5f-468d-9560-e2e7508da9f6">
											<gml:posList>35.67242816169386 139.73827323220237 27.193 35.67242816169386 139.73827323220237 27.247 35.67244159092966 139.73831736931254 31.044 35.67244159092966 139.73831736931254 27.193 35.67246813303651 139.73840458348332 27.193 35.67246813303651 139.73840458348332 9.419 35.67242041683229 139.7382477791101 9.419 35.67242041683229 139.7382477791101 27.193 35.67242816169386 139.73827323220237 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e558f45-cdb1-40e9-861c-cabbad520d28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e558f45-cdb1-40e9-861c-cabbad520d28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e558f45-cdb1-40e9-861c-cabbad520d28">
											<gml:posList>35.67244097299364 139.73841388369252 31.266 35.67246236395151 139.73840420368526 31.266 35.67246236395151 139.73840420368526 30.913 35.67244097299364 139.73841388369252 30.913 35.67244097299364 139.73841388369252 31.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c568ca2-4840-4bfc-94a4-9fa12f3502b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c568ca2-4840-4bfc-94a4-9fa12f3502b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c568ca2-4840-4bfc-94a4-9fa12f3502b4">
											<gml:posList>35.67246534881625 139.738405879226 31.266 35.67246534881625 139.738405879226 27.193 35.672438455184015 139.73831867652095 27.193 35.672438455184015 139.73831867652095 31.044 35.672438455184015 139.73831867652095 31.266 35.67246534881625 139.738405879226 31.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75b1c2b2-8423-4772-8f67-7609d5c9fdfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75b1c2b2-8423-4772-8f67-7609d5c9fdfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75b1c2b2-8423-4772-8f67-7609d5c9fdfe">
											<gml:posList>35.67246534881625 139.738405879226 27.193 35.67243962380065 139.73841751960254 27.193 35.672459383876564 139.73840860373906 27.02 35.67246534881625 139.738405879226 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82f050a3-79f0-439b-9ee7-2aabe2cea2ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82f050a3-79f0-439b-9ee7-2aabe2cea2ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82f050a3-79f0-439b-9ee7-2aabe2cea2ac">
											<gml:posList>35.67246534881625 139.738405879226 27.193 35.67246534881625 139.738405879226 31.266 35.67243962380065 139.73841751960254 31.266 35.67246534881625 139.738405879226 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b24601c6-1b68-4ca3-a6a3-6e7e70cb845d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b24601c6-1b68-4ca3-a6a3-6e7e70cb845d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b24601c6-1b68-4ca3-a6a3-6e7e70cb845d">
											<gml:posList>35.67246534881625 139.738405879226 27.193 35.67243962380065 139.73841751960254 31.266 35.67243962380065 139.73841751960254 27.193 35.67246534881625 139.738405879226 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a56cbd8a-a733-46c5-9069-9be3a51a42f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a56cbd8a-a733-46c5-9069-9be3a51a42f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a56cbd8a-a733-46c5-9069-9be3a51a42f6">
											<gml:posList>35.67246534881625 139.738405879226 27.193 35.672459383876564 139.73840860373906 27.02 35.67246191583463 139.73840746294692 27.02 35.67246534881625 139.738405879226 27.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa6b4f23-faed-4e22-926b-85a1492badf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa6b4f23-faed-4e22-926b-85a1492badf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa6b4f23-faed-4e22-926b-85a1492badf1">
											<gml:posList>35.67246813303651 139.73840458348332 9.419 35.67246191583463 139.73840746294692 27.02 35.67246191583463 139.73840746294692 9.419 35.67246813303651 139.73840458348332 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7e68017-6943-49a7-8c89-f27da6aa9ecd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7e68017-6943-49a7-8c89-f27da6aa9ecd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7e68017-6943-49a7-8c89-f27da6aa9ecd">
											<gml:posList>35.67246813303651 139.73840458348332 9.419 35.67246534881625 139.738405879226 27.193 35.67246191583463 139.73840746294692 27.02 35.67246813303651 139.73840458348332 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed3858b9-10ed-49b1-8b4f-77878ba0f2eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed3858b9-10ed-49b1-8b4f-77878ba0f2eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed3858b9-10ed-49b1-8b4f-77878ba0f2eb">
											<gml:posList>35.67246813303651 139.73840458348332 9.419 35.67246813303651 139.73840458348332 27.193 35.67246534881625 139.738405879226 27.193 35.67246813303651 139.73840458348332 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-367aebb2-74ab-40f7-9712-202139c0f8c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-367aebb2-74ab-40f7-9712-202139c0f8c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-367aebb2-74ab-40f7-9712-202139c0f8c9">
											<gml:posList>35.67247569612473 139.738462491579 27.02 35.672459383876564 139.73840860373906 27.02 35.672459383876564 139.73840860373906 26.72 35.67247569612473 139.738462491579 26.72 35.67247569612473 139.738462491579 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-703b9c92-0acc-4143-8f53-1c947e57b52f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-703b9c92-0acc-4143-8f53-1c947e57b52f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-703b9c92-0acc-4143-8f53-1c947e57b52f">
											<gml:posList>35.672479176960785 139.73846444269904 27.02 35.672479176960785 139.73846444269904 9.419 35.67246191583463 139.73840746294692 9.419 35.67246191583463 139.73840746294692 27.02 35.672479176960785 139.73846444269904 27.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-755</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">250.27446</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>