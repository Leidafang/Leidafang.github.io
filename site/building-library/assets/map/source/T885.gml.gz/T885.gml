<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_fc011232-9322-4fc3-aa1c-62b20eebfba4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">13.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669056876779514 139.74917921060708 0 35.669080085703435 139.74911268883963 0 35.66898270306378 139.74906363612635 0 35.66896003522184 139.74913048864087 0 35.669056876779514 139.74917921060708 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669056876779514 139.74917921060708 6.134 35.66896003522184 139.74913048864087 6.134 35.66898270306378 139.74906363612635 6.134 35.669080085703435 139.74911268883963 6.134 35.669056876779514 139.74917921060708 6.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669056876779514 139.74917921060708 6.134 35.669080085703435 139.74911268883963 6.134 35.669080085703435 139.74911268883963 19.2 35.669056876779514 139.74917921060708 19.2 35.669056876779514 139.74917921060708 6.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669080085703435 139.74911268883963 6.134 35.66898270306378 139.74906363612635 6.134 35.66898270306378 139.74906363612635 19.2 35.669080085703435 139.74911268883963 19.2 35.669080085703435 139.74911268883963 6.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898270306378 139.74906363612635 6.134 35.66896003522184 139.74913048864087 6.134 35.66896003522184 139.74913048864087 19.2 35.66898270306378 139.74906363612635 19.2 35.66898270306378 139.74906363612635 6.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66896003522184 139.74913048864087 6.134 35.669056876779514 139.74917921060708 6.134 35.669056876779514 139.74917921060708 19.2 35.66896003522184 139.74913048864087 19.2 35.66896003522184 139.74913048864087 6.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669056876779514 139.74917921060708 19.2 35.669080085703435 139.74911268883963 19.2 35.66898270306378 139.74906363612635 19.2 35.66896003522184 139.74913048864087 19.2 35.669056876779514 139.74917921060708 19.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-494401be-7981-4a4c-aab0-2adbf7086953"/>
							<gml:surfaceMember xlink:href="#poly-f05bac3b-578a-4012-bb2e-dc21a3983734"/>
							<gml:surfaceMember xlink:href="#poly-361d67e2-32ff-4f99-9340-df9030f1920e"/>
							<gml:surfaceMember xlink:href="#poly-5beab71c-9b6c-4e2a-82a2-5283ba89e053"/>
							<gml:surfaceMember xlink:href="#poly-79867223-a61e-444a-add9-c3d6bb048e95"/>
							<gml:surfaceMember xlink:href="#poly-7deed08b-d8d2-4d6f-bfda-781d13d968c0"/>
							<gml:surfaceMember xlink:href="#poly-68e60ad6-3d54-4ce0-a0db-ce14d5224ff4"/>
							<gml:surfaceMember xlink:href="#poly-0922f68c-5c87-48df-922d-a49e7f77001e"/>
							<gml:surfaceMember xlink:href="#poly-142dd867-77d7-4067-8dfd-4bd8fc37427c"/>
							<gml:surfaceMember xlink:href="#poly-1a926881-e6bd-44ff-9af8-cd47767b4eb0"/>
							<gml:surfaceMember xlink:href="#poly-6c6d383d-ed81-4922-be1b-7fcfb6d0e01c"/>
							<gml:surfaceMember xlink:href="#poly-20cb074f-067b-47bd-97d7-fb063dac1437"/>
							<gml:surfaceMember xlink:href="#poly-c82d4055-dfc0-4bed-a4cc-a5ed6de65525"/>
							<gml:surfaceMember xlink:href="#poly-556b0a82-54b6-4fdb-8272-fb059c9afd68"/>
							<gml:surfaceMember xlink:href="#poly-6a9548a2-d783-419b-9c29-e8fd2e59af55"/>
							<gml:surfaceMember xlink:href="#poly-07d51028-7284-4d14-8538-c01c636a74d0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-494401be-7981-4a4c-aab0-2adbf7086953">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-494401be-7981-4a4c-aab0-2adbf7086953">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-494401be-7981-4a4c-aab0-2adbf7086953">
											<gml:posList>35.66905687677953 139.74917921060708 6.134 35.66896003522184 139.74913048864084 6.134 35.66898270306377 139.74906363612632 6.134 35.669080085703435 139.74911268883963 6.134 35.66905687677953 139.74917921060708 6.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f05bac3b-578a-4012-bb2e-dc21a3983734">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f05bac3b-578a-4012-bb2e-dc21a3983734">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f05bac3b-578a-4012-bb2e-dc21a3983734">
											<gml:posList>35.66896901240352 139.74910400179357 21.4 35.66897280585357 139.74910209788524 21.4 35.6689842746989 139.74906827382313 21.4 35.66898270306377 139.74906363612632 21.4 35.66896901240352 139.74910400179357 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-361d67e2-32ff-4f99-9340-df9030f1920e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-361d67e2-32ff-4f99-9340-df9030f1920e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-361d67e2-32ff-4f99-9340-df9030f1920e">
											<gml:posList>35.66896901240352 139.74910400179357 18.1 35.66896003522184 139.74913048864084 18.1 35.66905687677953 139.74917921060708 18.1 35.66906589947283 139.7491533422659 18.1 35.66896901240352 139.74910400179357 18.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5beab71c-9b6c-4e2a-82a2-5283ba89e053">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5beab71c-9b6c-4e2a-82a2-5283ba89e053">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5beab71c-9b6c-4e2a-82a2-5283ba89e053">
											<gml:posList>35.66906589947283 139.7491533422659 21.4 35.669064354882174 139.74914870453435 21.4 35.66897280585357 139.74910209788524 21.4 35.66896901240352 139.74910400179357 21.4 35.66906589947283 139.7491533422659 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79867223-a61e-444a-add9-c3d6bb048e95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79867223-a61e-444a-add9-c3d6bb048e95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79867223-a61e-444a-add9-c3d6bb048e95">
											<gml:posList>35.669076256198395 139.74911459278792 20.87 35.6689842746989 139.74906827382313 20.87 35.66897280585357 139.74910209788524 20.87 35.669064354882174 139.74914870453435 20.87 35.669076256198395 139.74911459278792 20.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7deed08b-d8d2-4d6f-bfda-781d13d968c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7deed08b-d8d2-4d6f-bfda-781d13d968c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7deed08b-d8d2-4d6f-bfda-781d13d968c0">
											<gml:posList>35.66898270306377 139.74906363612632 21.4 35.6689842746989 139.74906827382313 21.4 35.669076256198395 139.74911459278792 21.4 35.669080085703435 139.74911268883963 21.4 35.66898270306377 139.74906363612632 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68e60ad6-3d54-4ce0-a0db-ce14d5224ff4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68e60ad6-3d54-4ce0-a0db-ce14d5224ff4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68e60ad6-3d54-4ce0-a0db-ce14d5224ff4">
											<gml:posList>35.669080085703435 139.74911268883963 21.4 35.669076256198395 139.74911459278792 21.4 35.669064354882174 139.74914870453435 21.4 35.66906589947283 139.7491533422659 21.4 35.669080085703435 139.74911268883963 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0922f68c-5c87-48df-922d-a49e7f77001e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0922f68c-5c87-48df-922d-a49e7f77001e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0922f68c-5c87-48df-922d-a49e7f77001e">
											<gml:posList>35.669080085703435 139.74911268883963 6.134 35.66898270306377 139.74906363612632 6.134 35.66898270306377 139.74906363612632 21.4 35.669080085703435 139.74911268883963 21.4 35.669080085703435 139.74911268883963 6.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-142dd867-77d7-4067-8dfd-4bd8fc37427c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-142dd867-77d7-4067-8dfd-4bd8fc37427c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-142dd867-77d7-4067-8dfd-4bd8fc37427c">
											<gml:posList>35.6689842746989 139.74906827382313 21.4 35.6689842746989 139.74906827382313 20.87 35.669076256198395 139.74911459278792 20.87 35.669076256198395 139.74911459278792 21.4 35.6689842746989 139.74906827382313 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a926881-e6bd-44ff-9af8-cd47767b4eb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a926881-e6bd-44ff-9af8-cd47767b4eb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a926881-e6bd-44ff-9af8-cd47767b4eb0">
											<gml:posList>35.66896901240352 139.74910400179357 18.1 35.66896901240352 139.74910400179357 21.4 35.66898270306377 139.74906363612632 21.4 35.66898270306377 139.74906363612632 6.134 35.66896003522184 139.74913048864084 6.134 35.66896003522184 139.74913048864084 18.1 35.66896901240352 139.74910400179357 18.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c6d383d-ed81-4922-be1b-7fcfb6d0e01c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c6d383d-ed81-4922-be1b-7fcfb6d0e01c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c6d383d-ed81-4922-be1b-7fcfb6d0e01c">
											<gml:posList>35.66897280585357 139.74910209788524 21.4 35.66897280585357 139.74910209788524 20.87 35.6689842746989 139.74906827382313 20.87 35.6689842746989 139.74906827382313 21.4 35.66897280585357 139.74910209788524 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20cb074f-067b-47bd-97d7-fb063dac1437">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20cb074f-067b-47bd-97d7-fb063dac1437">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20cb074f-067b-47bd-97d7-fb063dac1437">
											<gml:posList>35.66896003522184 139.74913048864084 6.134 35.66905687677953 139.74917921060708 6.134 35.66905687677953 139.74917921060708 18.1 35.66896003522184 139.74913048864084 18.1 35.66896003522184 139.74913048864084 6.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c82d4055-dfc0-4bed-a4cc-a5ed6de65525">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c82d4055-dfc0-4bed-a4cc-a5ed6de65525">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c82d4055-dfc0-4bed-a4cc-a5ed6de65525">
											<gml:posList>35.66906589947283 139.7491533422659 18.1 35.66906589947283 139.7491533422659 21.4 35.66896901240352 139.74910400179357 21.4 35.66896901240352 139.74910400179357 18.1 35.66906589947283 139.7491533422659 18.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-556b0a82-54b6-4fdb-8272-fb059c9afd68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-556b0a82-54b6-4fdb-8272-fb059c9afd68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-556b0a82-54b6-4fdb-8272-fb059c9afd68">
											<gml:posList>35.669080085703435 139.74911268883963 6.134 35.669080085703435 139.74911268883963 21.4 35.66906589947283 139.7491533422659 21.4 35.66906589947283 139.7491533422659 18.1 35.66905687677953 139.74917921060708 18.1 35.66905687677953 139.74917921060708 6.134 35.669080085703435 139.74911268883963 6.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a9548a2-d783-419b-9c29-e8fd2e59af55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a9548a2-d783-419b-9c29-e8fd2e59af55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a9548a2-d783-419b-9c29-e8fd2e59af55">
											<gml:posList>35.669076256198395 139.74911459278792 21.4 35.669076256198395 139.74911459278792 20.87 35.669064354882174 139.74914870453435 20.87 35.669064354882174 139.74914870453435 21.4 35.669076256198395 139.74911459278792 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07d51028-7284-4d14-8538-c01c636a74d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07d51028-7284-4d14-8538-c01c636a74d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07d51028-7284-4d14-8538-c01c636a74d0">
											<gml:posList>35.669064354882174 139.74914870453435 21.4 35.669064354882174 139.74914870453435 20.87 35.66897280585357 139.74910209788524 20.87 35.66897280585357 139.74910209788524 21.4 35.669064354882174 139.74914870453435 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1223</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">76.3062</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>