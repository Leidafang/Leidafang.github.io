<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_fc2a75c5-fa3d-4ed0-9a9d-c6ce864868a6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">14.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67063210992116 139.73770001548667 0 35.670600118402966 139.73770911160287 0 35.67059930164128 139.73770215341472 0 35.67052964258999 139.73772366628333 0 35.67053498497732 139.7377542581096 0 35.670469920547134 139.73777278294622 0 35.6704863943934 139.7378595870237 0 35.67065338098637 139.7378118891016 0 35.67063210992116 139.73770001548667 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063210992116 139.73770001548667 14.92 35.67065338098637 139.7378118891016 14.92 35.6704863943934 139.7378595870237 14.92 35.670469920547134 139.73777278294622 14.92 35.67053498497732 139.7377542581096 14.92 35.67052964258999 139.73772366628333 14.92 35.67059930164128 139.73770215341472 14.92 35.670600118402966 139.73770911160287 14.92 35.67063210992116 139.73770001548667 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063210992116 139.73770001548667 14.92 35.670600118402966 139.73770911160287 14.92 35.670600118402966 139.73770911160287 29 35.67063210992116 139.73770001548667 29 35.67063210992116 139.73770001548667 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670600118402966 139.73770911160287 14.92 35.67059930164128 139.73770215341472 14.92 35.67059930164128 139.73770215341472 29 35.670600118402966 139.73770911160287 29 35.670600118402966 139.73770911160287 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059930164128 139.73770215341472 14.92 35.67052964258999 139.73772366628333 14.92 35.67052964258999 139.73772366628333 29 35.67059930164128 139.73770215341472 29 35.67059930164128 139.73770215341472 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052964258999 139.73772366628333 14.92 35.67053498497732 139.7377542581096 14.92 35.67053498497732 139.7377542581096 29 35.67052964258999 139.73772366628333 29 35.67052964258999 139.73772366628333 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67053498497732 139.7377542581096 14.92 35.670469920547134 139.73777278294622 14.92 35.670469920547134 139.73777278294622 29 35.67053498497732 139.7377542581096 29 35.67053498497732 139.7377542581096 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670469920547134 139.73777278294622 14.92 35.6704863943934 139.7378595870237 14.92 35.6704863943934 139.7378595870237 29 35.670469920547134 139.73777278294622 29 35.670469920547134 139.73777278294622 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6704863943934 139.7378595870237 14.92 35.67065338098637 139.7378118891016 14.92 35.67065338098637 139.7378118891016 29 35.6704863943934 139.7378595870237 29 35.6704863943934 139.7378595870237 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67065338098637 139.7378118891016 14.92 35.67063210992116 139.73770001548667 14.92 35.67063210992116 139.73770001548667 29 35.67065338098637 139.7378118891016 29 35.67065338098637 139.7378118891016 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063210992116 139.73770001548667 29 35.670600118402966 139.73770911160287 29 35.67059930164128 139.73770215341472 29 35.67052964258999 139.73772366628333 29 35.67053498497732 139.7377542581096 29 35.670469920547134 139.73777278294622 29 35.6704863943934 139.7378595870237 29 35.67065338098637 139.7378118891016 29 35.67063210992116 139.73770001548667 29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0c16f425-e257-43f1-8cb3-cc3b4e1568d3"/>
							<gml:surfaceMember xlink:href="#poly-4d67e22d-b500-42af-b8cb-30f12bad5547"/>
							<gml:surfaceMember xlink:href="#poly-2e2dd4c4-a2c2-4c5b-9101-ee542be50b8e"/>
							<gml:surfaceMember xlink:href="#poly-54adb3a3-7e9f-4c21-b2b7-37baa82ad387"/>
							<gml:surfaceMember xlink:href="#poly-898d3be3-0012-4380-be59-6afcc149727d"/>
							<gml:surfaceMember xlink:href="#poly-4c77f96d-19db-473f-94bb-6be93a68c317"/>
							<gml:surfaceMember xlink:href="#poly-866cc3e7-12d8-4c6f-9e3e-0e57b85aadbb"/>
							<gml:surfaceMember xlink:href="#poly-b26d73dc-2e5a-4631-afb3-c49a8b9e5b54"/>
							<gml:surfaceMember xlink:href="#poly-9f1dbd11-7c39-4fa3-b043-090563424323"/>
							<gml:surfaceMember xlink:href="#poly-3615f434-1a00-4e76-a672-9b6166a6c5dd"/>
							<gml:surfaceMember xlink:href="#poly-aeaf008b-dfd5-48d2-ba4f-c1183cfd9e34"/>
							<gml:surfaceMember xlink:href="#poly-ff273124-e5c6-4dd4-b2ec-c9859e9253a6"/>
							<gml:surfaceMember xlink:href="#poly-5e6e155e-5601-4625-acbe-8df94d1186a7"/>
							<gml:surfaceMember xlink:href="#poly-bcc2477d-aee1-4356-af6b-0bd7801aff03"/>
							<gml:surfaceMember xlink:href="#poly-561c272f-8c4e-4482-afeb-a56fc038d7ee"/>
							<gml:surfaceMember xlink:href="#poly-2b7c4c60-62b7-4f59-960a-115075ee4ded"/>
							<gml:surfaceMember xlink:href="#poly-c7c4b1ed-462d-42a6-bc73-330ae94470e6"/>
							<gml:surfaceMember xlink:href="#poly-4cc334e0-8e85-4744-b3b1-abd940583a9c"/>
							<gml:surfaceMember xlink:href="#poly-20499c0a-9f11-4508-928d-150b425d8d5f"/>
							<gml:surfaceMember xlink:href="#poly-a8562eea-2dd3-43eb-97cf-9c3f24572c26"/>
							<gml:surfaceMember xlink:href="#poly-238c8972-23da-44af-9ccf-bf5bc0b08182"/>
							<gml:surfaceMember xlink:href="#poly-265f01c2-cc29-4aeb-9c0a-890437a20f4a"/>
							<gml:surfaceMember xlink:href="#poly-e2d15c3c-e641-4b5f-bfe4-c6d87dbb1a13"/>
							<gml:surfaceMember xlink:href="#poly-542cca10-3594-4989-b6aa-ef3d8ea42a77"/>
							<gml:surfaceMember xlink:href="#poly-99e8fe0b-0534-4660-9821-db4baa6e87dd"/>
							<gml:surfaceMember xlink:href="#poly-2dffe22b-9356-46ed-8bcf-0a06ff6dde74"/>
							<gml:surfaceMember xlink:href="#poly-9b7c2421-de35-41b8-91b9-022575327a4d"/>
							<gml:surfaceMember xlink:href="#poly-7e93f388-67a9-47fe-b5c6-213a7bd2b361"/>
							<gml:surfaceMember xlink:href="#poly-a7e5e3ef-bb16-4c5e-86aa-8ef3cbb760be"/>
							<gml:surfaceMember xlink:href="#poly-f8093884-8832-4001-8dd8-7acd5a7dadc5"/>
							<gml:surfaceMember xlink:href="#poly-a5f733d0-4efe-4eed-aad7-8170825cf06f"/>
							<gml:surfaceMember xlink:href="#poly-0de8cd77-f9f9-440e-87aa-ed4eede1691e"/>
							<gml:surfaceMember xlink:href="#poly-a4881165-e8a3-4e2b-aca9-3549f329a185"/>
							<gml:surfaceMember xlink:href="#poly-d09f3e54-dd3d-48b0-866e-0c8678322ea0"/>
							<gml:surfaceMember xlink:href="#poly-c0ddf7dd-ad96-478c-97a1-aa8babd52c6b"/>
							<gml:surfaceMember xlink:href="#poly-a0f20e49-e8d2-45c3-a1c2-3c0f7f68d92b"/>
							<gml:surfaceMember xlink:href="#poly-c3b9af3e-c8e4-4748-b34f-84c0fc0a1bbb"/>
							<gml:surfaceMember xlink:href="#poly-45d25bab-d109-45e7-98aa-c488f3f18dd6"/>
							<gml:surfaceMember xlink:href="#poly-c04ee1b0-eba2-4940-a675-988f16c98ff3"/>
							<gml:surfaceMember xlink:href="#poly-e1b46b45-ca7c-4645-b7bc-225f5cef989b"/>
							<gml:surfaceMember xlink:href="#poly-c7dfec3b-48d6-4657-82df-e26206ac99f3"/>
							<gml:surfaceMember xlink:href="#poly-3451aa1e-f69d-484b-a3e9-15c1bf02ac68"/>
							<gml:surfaceMember xlink:href="#poly-b7ac1abf-b9bb-471e-8f88-e4c3d39c223f"/>
							<gml:surfaceMember xlink:href="#poly-8e55a90e-fc8a-4fa4-af1f-362d15fc4ca9"/>
							<gml:surfaceMember xlink:href="#poly-8a21a411-8e21-497d-9f29-18069b5ddc97"/>
							<gml:surfaceMember xlink:href="#poly-95471efa-a799-45d0-8e8c-eaf09d55ee1f"/>
							<gml:surfaceMember xlink:href="#poly-0ad6f413-9259-4bfb-86a8-6611392a3da6"/>
							<gml:surfaceMember xlink:href="#poly-a915f98c-d499-4c76-b45f-c35508bc8af8"/>
							<gml:surfaceMember xlink:href="#poly-978aa08b-49ec-4f84-b03e-3d64e6b09ade"/>
							<gml:surfaceMember xlink:href="#poly-f7ca0912-0d2b-4fba-85fa-16a7f3709398"/>
							<gml:surfaceMember xlink:href="#poly-d7ed366d-8169-4a58-80b2-4e5675cb1c6b"/>
							<gml:surfaceMember xlink:href="#poly-00b9e72f-be9c-4641-a70d-356d5087bfea"/>
							<gml:surfaceMember xlink:href="#poly-a160ddb8-6133-4dbe-af4d-41df31d4b5a8"/>
							<gml:surfaceMember xlink:href="#poly-c1d9b696-e3e8-439d-ae6b-8cbf51e4a815"/>
							<gml:surfaceMember xlink:href="#poly-4486b694-4648-4b3c-9183-8b6e1195a6c4"/>
							<gml:surfaceMember xlink:href="#poly-d991a5a3-1848-4b68-9372-87a3325525ac"/>
							<gml:surfaceMember xlink:href="#poly-949be492-649b-45f2-98ea-b27939051565"/>
							<gml:surfaceMember xlink:href="#poly-e715762d-c17a-42b9-a6da-82d1059ce457"/>
							<gml:surfaceMember xlink:href="#poly-9d2ecf54-ce93-4ea2-8001-5fa18ca0e0f3"/>
							<gml:surfaceMember xlink:href="#poly-f39bf35a-2a55-4587-94dd-2f218b76d202"/>
							<gml:surfaceMember xlink:href="#poly-e3394d20-5e70-4550-90c9-3fdaa23cca0b"/>
							<gml:surfaceMember xlink:href="#poly-8966d591-c29f-4b0d-a77b-4f048db10225"/>
							<gml:surfaceMember xlink:href="#poly-edf08d89-9c25-4254-bb83-817ca39bde6c"/>
							<gml:surfaceMember xlink:href="#poly-1769bed8-90ed-4f40-bd4c-2e84be47aaca"/>
							<gml:surfaceMember xlink:href="#poly-e26c0be6-a6b9-4d7e-a425-47e39cafa948"/>
							<gml:surfaceMember xlink:href="#poly-3b78f363-b1bb-4c46-b944-f93690b967ee"/>
							<gml:surfaceMember xlink:href="#poly-edeff638-a560-4e53-a769-1d0b1098984a"/>
							<gml:surfaceMember xlink:href="#poly-100e95bf-0a09-4d64-9641-a1dd9f8c54db"/>
							<gml:surfaceMember xlink:href="#poly-05f0d63a-e8e6-4997-a4bd-b0f2bda2c957"/>
							<gml:surfaceMember xlink:href="#poly-dc19e322-5b95-4ea6-af60-3f2390719be8"/>
							<gml:surfaceMember xlink:href="#poly-5171aac9-d452-4041-bbd1-a6b1427e6689"/>
							<gml:surfaceMember xlink:href="#poly-0deebbfd-f8cf-4bd8-88c2-4a679021d15b"/>
							<gml:surfaceMember xlink:href="#poly-415dab60-c994-4851-b6f8-cb0ca95bb727"/>
							<gml:surfaceMember xlink:href="#poly-10da2871-f5cf-4797-a3e0-d089c881d2a5"/>
							<gml:surfaceMember xlink:href="#poly-ee89db9c-840d-4c5f-8e89-68963585feb3"/>
							<gml:surfaceMember xlink:href="#poly-1f61a0ed-3ca1-4d6e-b5d5-0079db27e335"/>
							<gml:surfaceMember xlink:href="#poly-e872334a-fb82-44c8-88c3-740a4bd77971"/>
							<gml:surfaceMember xlink:href="#poly-13f92d9d-395d-40f7-a3bf-13ee525f465a"/>
							<gml:surfaceMember xlink:href="#poly-5ef7f19d-544f-4a31-ab49-080e7adadff8"/>
							<gml:surfaceMember xlink:href="#poly-a77ddf31-1f5a-4220-999d-5eb0b917a2bd"/>
							<gml:surfaceMember xlink:href="#poly-c4aedb86-9bb0-4307-9334-def0e4959c20"/>
							<gml:surfaceMember xlink:href="#poly-5363eac9-c4c0-484e-97e2-55ae74bc7805"/>
							<gml:surfaceMember xlink:href="#poly-b8cb9887-f855-4acf-904d-5cc9c7a4d7f4"/>
							<gml:surfaceMember xlink:href="#poly-d1170282-64f4-41b9-bd36-55e7633c4848"/>
							<gml:surfaceMember xlink:href="#poly-5f0296e5-9839-4047-b695-f3ba4266a309"/>
							<gml:surfaceMember xlink:href="#poly-0f858dec-4294-4a31-b908-18e9862a4e9e"/>
							<gml:surfaceMember xlink:href="#poly-a8c7e82b-9a6f-48af-8e76-5dd6d0e5059f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_fc2a75c5-fa3d-4ed0-9a9d-c6ce864868a6_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6370d7e-e3ff-48ab-a33a-6d13b875b10a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060785552712 139.73779281116472 29.204 35.67060189961156 139.73776145784544 29.204 35.670611812469645 139.73775862922494 29.204 35.67061777739966 139.73778998253718 29.204 35.67060785552712 139.73779281116472 29.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c8935ef-dd58-48ab-8c43-40c5e1999dcf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050514777095 139.7378429290002 35.991 35.67049591974331 139.73784549168028 35.991 35.670492235363106 139.73782557963509 35.991 35.67050145436784 139.73782300591733 35.991 35.67050514777095 139.7378429290002 35.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c4531a2-b8ef-46d1-93b5-4ed261f83023">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c4531a2-b8ef-46d1-93b5-4ed261f83023_0">
											<gml:posList>35.670611812469645 139.73775862922494 29.204 35.67060189961156 139.73776145784544 29.204 35.67060189961156 139.73776145784544 31.153 35.670611812469645 139.73775862922494 31.153 35.670611812469645 139.73775862922494 29.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f183fc37-dfbd-4b45-bbfa-33aea8c70157">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f183fc37-dfbd-4b45-bbfa-33aea8c70157_0">
											<gml:posList>35.67061777739966 139.73778998253718 29.204 35.670611812469645 139.73775862922494 29.204 35.670611812469645 139.73775862922494 31.153 35.67061777739966 139.73778998253718 31.153 35.67061777739966 139.73778998253718 29.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9074efff-9a7f-494f-8d6f-04431e9c1d61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9074efff-9a7f-494f-8d6f-04431e9c1d61_0">
											<gml:posList>35.670611812469645 139.73775862922494 31.153 35.67060189961156 139.73776145784544 31.153 35.67060785552712 139.73779281116472 31.153 35.67061777739966 139.73778998253718 31.153 35.670611812469645 139.73775862922494 31.153</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7007d6d-7818-4964-a8c2-9023b0e21a48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7007d6d-7818-4964-a8c2-9023b0e21a48_0">
											<gml:posList>35.67060785552712 139.73779281116472 31.153 35.67060189961156 139.73776145784544 31.153 35.67060189961156 139.73776145784544 29.204 35.67060785552712 139.73779281116472 29.204 35.67060785552712 139.73779281116472 31.153</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12634627-9138-4ffc-8618-1d49528af530">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12634627-9138-4ffc-8618-1d49528af530_0">
											<gml:posList>35.67061777739966 139.73778998253718 29.204 35.67061777739966 139.73778998253718 31.153 35.67060785552712 139.73779281116472 31.153 35.67060785552712 139.73779281116472 29.204 35.67061777739966 139.73778998253718 29.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30c7338c-4c82-48eb-a37f-0da889c22b8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30c7338c-4c82-48eb-a37f-0da889c22b8d_0">
											<gml:posList>35.670492235363106 139.73782557963509 35.991 35.670492235363106 139.73782557963509 39.019 35.67050145436784 139.73782300591733 39.019 35.67050145436784 139.73782300591733 35.991 35.670492235363106 139.73782557963509 35.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9246807e-c8dd-4b82-af89-6dfbe2c9702f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9246807e-c8dd-4b82-af89-6dfbe2c9702f_0">
											<gml:posList>35.67050514777095 139.7378429290002 35.991 35.67050145436784 139.73782300591733 35.991 35.67050145436784 139.73782300591733 39.019 35.67050514777095 139.7378429290002 39.019 35.67050514777095 139.7378429290002 35.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5edc8053-c26a-4b00-af9b-51b1ce4bbcdc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5edc8053-c26a-4b00-af9b-51b1ce4bbcdc_0">
											<gml:posList>35.67050514777095 139.7378429290002 39.019 35.67050145436784 139.73782300591733 39.019 35.670492235363106 139.73782557963509 39.019 35.67049591974331 139.73784549168028 39.019 35.67050514777095 139.7378429290002 39.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-207b0571-db6d-4fd2-9880-b0986bb91fcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-207b0571-db6d-4fd2-9880-b0986bb91fcb_0">
											<gml:posList>35.670492235363106 139.73782557963509 35.991 35.67049591974331 139.73784549168028 35.991 35.67049591974331 139.73784549168028 39.019 35.670492235363106 139.73782557963509 39.019 35.670492235363106 139.73782557963509 35.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7805b68-a3f8-41a6-95da-32039883664f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7805b68-a3f8-41a6-95da-32039883664f_0">
											<gml:posList>35.67049591974331 139.73784549168028 35.991 35.67050514777095 139.7378429290002 35.991 35.67050514777095 139.7378429290002 39.019 35.67049591974331 139.73784549168028 39.019 35.67049591974331 139.73784549168028 35.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_fc2a75c5-fa3d-4ed0-9a9d-c6ce864868a6_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24d70a04-3369-4d34-ae16-8db40f4c300d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670560868345646 139.7377945682834 32.305 35.67059612207522 139.73778450729102 32.305 35.67060129957131 139.73781178545624 32.305 35.6705660458307 139.73782183539103 32.305 35.670560868345646 139.7377945682834 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f199bd2-1434-4a23-aee6-8ae83599046e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f199bd2-1434-4a23-aee6-8ae83599046e_0">
											<gml:posList>35.670560868345646 139.7377945682834 34.532 35.67059612207522 139.73778450729102 34.532 35.67059612207522 139.73778450729102 32.305 35.670560868345646 139.7377945682834 32.305 35.670560868345646 139.7377945682834 34.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cac20d23-ec6e-4322-be74-cfa8296332ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cac20d23-ec6e-4322-be74-cfa8296332ab_0">
											<gml:posList>35.67059612207522 139.73778450729102 32.305 35.67059612207522 139.73778450729102 34.532 35.67060129957131 139.73781178545624 34.532 35.67060129957131 139.73781178545624 32.305 35.67059612207522 139.73778450729102 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3c828dd-093d-45ce-9975-d5adc3e33bbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3c828dd-093d-45ce-9975-d5adc3e33bbc_0">
											<gml:posList>35.67060129957131 139.73781178545624 34.532 35.67059612207522 139.73778450729102 34.532 35.670560868345646 139.7377945682834 34.532 35.6705660458307 139.73782183539103 34.532 35.67060129957131 139.73781178545624 34.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bd5ffbb-8c4e-41c1-bc89-210bf399135e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bd5ffbb-8c4e-41c1-bc89-210bf399135e_0">
											<gml:posList>35.6705660458307 139.73782183539103 32.305 35.6705660458307 139.73782183539103 34.532 35.670560868345646 139.7377945682834 34.532 35.670560868345646 139.7377945682834 32.305 35.6705660458307 139.73782183539103 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5403d5e-2291-4422-b3c6-9fa035e21ed8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5403d5e-2291-4422-b3c6-9fa035e21ed8_0">
											<gml:posList>35.67060129957131 139.73781178545624 32.305 35.67060129957131 139.73781178545624 34.532 35.6705660458307 139.73782183539103 34.532 35.6705660458307 139.73782183539103 32.305 35.67060129957131 139.73781178545624 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0c16f425-e257-43f1-8cb3-cc3b4e1568d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c16f425-e257-43f1-8cb3-cc3b4e1568d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c16f425-e257-43f1-8cb3-cc3b4e1568d3">
											<gml:posList>35.67060011840296 139.73770911160287 14.92 35.670632109921144 139.73770001548667 14.92 35.670653380986366 139.7378118891016 14.92 35.67048639439341 139.7378595870237 14.92 35.67046992054713 139.73777278294622 14.92 35.67053498497732 139.7377542581096 14.92 35.67052964258998 139.7377236662833 14.92 35.67059930164128 139.7377021534147 14.92 35.67060011840296 139.73770911160287 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d67e22d-b500-42af-b8cb-30f12bad5547">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d67e22d-b500-42af-b8cb-30f12bad5547">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d67e22d-b500-42af-b8cb-30f12bad5547">
											<gml:posList>35.67060011840296 139.73770911160287 19.791 35.67059930164128 139.7377021534147 19.791 35.67059753752226 139.73770539208158 19.791 35.67059819889254 139.7377096330678 19.791 35.67060011840296 139.73770911160287 19.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e2dd4c4-a2c2-4c5b-9101-ee542be50b8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e2dd4c4-a2c2-4c5b-9101-ee542be50b8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e2dd4c4-a2c2-4c5b-9101-ee542be50b8e">
											<gml:posList>35.67057396624933 139.7377162786943 26.473 35.670577312392595 139.73771885953477 26.473 35.670630021983705 139.73770410510576 26.473 35.670632109921144 139.73770001548667 26.473 35.67057396624933 139.7377162786943 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54adb3a3-7e9f-4c21-b2b7-37baa82ad387">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54adb3a3-7e9f-4c21-b2b7-37baa82ad387">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54adb3a3-7e9f-4c21-b2b7-37baa82ad387">
											<gml:posList>35.670546494135976 139.73771846548186 19.791 35.670549100601455 139.7377203512878 19.791 35.67059753752226 139.73770539208158 19.791 35.67059930164128 139.7377021534147 19.791 35.670546494135976 139.73771846548186 19.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-898d3be3-0012-4380-be59-6afcc149727d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-898d3be3-0012-4380-be59-6afcc149727d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-898d3be3-0012-4380-be59-6afcc149727d">
											<gml:posList>35.670546494135976 139.73771846548186 18.788 35.67052964258998 139.7377236662833 18.788 35.670533060860436 139.7377262691292 18.788 35.67054722694021 139.73772185581657 18.788 35.670546494135976 139.73771846548186 18.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c77f96d-19db-473f-94bb-6be93a68c317">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c77f96d-19db-473f-94bb-6be93a68c317">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c77f96d-19db-473f-94bb-6be93a68c317">
											<gml:posList>35.67057396624933 139.7377162786943 19.517 35.67059819889254 139.7377096330678 19.517 35.67059753752226 139.73770539208158 19.517 35.670549100601455 139.7377203512878 19.517 35.670555026347444 139.73774775004998 19.517 35.6705783748936 139.73774015550802 19.517 35.67057396624933 139.7377162786943 19.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-866cc3e7-12d8-4c6f-9e3e-0e57b85aadbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-866cc3e7-12d8-4c6f-9e3e-0e57b85aadbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-866cc3e7-12d8-4c6f-9e3e-0e57b85aadbb">
											<gml:posList>35.6705783748936 139.73774015550802 26.473 35.67058119544309 139.73773921321074 26.473 35.670577312392595 139.73771885953477 26.473 35.67057396624933 139.7377162786943 26.473 35.6705783748936 139.73774015550802 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b26d73dc-2e5a-4631-afb3-c49a8b9e5b54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b26d73dc-2e5a-4631-afb3-c49a8b9e5b54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b26d73dc-2e5a-4631-afb3-c49a8b9e5b54">
											<gml:posList>35.67055297174501 139.7377484152764 19.791 35.670555026347444 139.73774775004998 19.791 35.670549100601455 139.7377203512878 19.791 35.670546494135976 139.73771846548186 19.791 35.67055297174501 139.7377484152764 19.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f1dbd11-7c39-4fa3-b043-090563424323">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f1dbd11-7c39-4fa3-b043-090563424323">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f1dbd11-7c39-4fa3-b043-090563424323">
											<gml:posList>35.6705783748936 139.73774015550802 29.559 35.67058239731102 139.73774304483936 29.559 35.670612756506344 139.7377328902411 29.559 35.6706152042306 139.73772783916726 29.559 35.6705783748936 139.73774015550802 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3615f434-1a00-4e76-a672-9b6166a6c5dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3615f434-1a00-4e76-a672-9b6166a6c5dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3615f434-1a00-4e76-a672-9b6166a6c5dd">
											<gml:posList>35.67055297174501 139.7377484152764 18.412 35.67054722694021 139.73772185581657 18.412 35.670533060860436 139.7377262691292 18.412 35.67053792269656 139.73775330462735 18.412 35.67055297174501 139.7377484152764 18.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aeaf008b-dfd5-48d2-ba4f-c1183cfd9e34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aeaf008b-dfd5-48d2-ba4f-c1183cfd9e34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aeaf008b-dfd5-48d2-ba4f-c1183cfd9e34">
											<gml:posList>35.67053498497732 139.7377542581096 18.788 35.67053792269656 139.73775330462735 18.788 35.670533060860436 139.7377262691292 18.788 35.67052964258998 139.7377236662833 18.788 35.67053498497732 139.7377542581096 18.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff273124-e5c6-4dd4-b2ec-c9859e9253a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff273124-e5c6-4dd4-b2ec-c9859e9253a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff273124-e5c6-4dd4-b2ec-c9859e9253a6">
											<gml:posList>35.67053498497732 139.7377542581096 26.473 35.67053570896849 139.7377579025191 26.473 35.67057913497514 139.7377438440615 26.473 35.6705783748936 139.73774015550802 26.473 35.67053498497732 139.7377542581096 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e6e155e-5601-4625-acbe-8df94d1186a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e6e155e-5601-4625-acbe-8df94d1186a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e6e155e-5601-4625-acbe-8df94d1186a7">
											<gml:posList>35.6705815600261 139.73775564965098 29.559 35.67058560960706 139.73775869359886 29.559 35.67058239731102 139.73774304483936 29.559 35.6705783748936 139.73774015550802 29.559 35.6705815600261 139.73775564965098 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bcc2477d-aee1-4356-af6b-0bd7801aff03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcc2477d-aee1-4356-af6b-0bd7801aff03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcc2477d-aee1-4356-af6b-0bd7801aff03">
											<gml:posList>35.6706152042306 139.73772783916726 25.845 35.670631705088944 139.73781456603646 25.845 35.67065003487142 139.73780934139364 25.845 35.670630021983705 139.73770410510576 25.845 35.670577312392595 139.73771885953477 25.845 35.67058119544309 139.73773921321074 25.845 35.6706152042306 139.73772783916726 25.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-561c272f-8c4e-4482-afeb-a56fc038d7ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-561c272f-8c4e-4482-afeb-a56fc038d7ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-561c272f-8c4e-4482-afeb-a56fc038d7ee">
											<gml:posList>35.6705815600261 139.73775564965098 29.559 35.670531058474424 139.73777000373929 29.559 35.67053499091173 139.73777309201074 29.559 35.67058560960706 139.73775869359886 29.559 35.6705815600261 139.73775564965098 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b7c4c60-62b7-4f59-960a-115075ee4ded">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b7c4c60-62b7-4f59-960a-115075ee4ded">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b7c4c60-62b7-4f59-960a-115075ee4ded">
											<gml:posList>35.67053498497732 139.7377542581096 26.473 35.67046992054713 139.73777278294622 26.473 35.67047359135856 139.7377755843242 26.473 35.67053570896849 139.7377579025191 26.473 35.67053498497732 139.7377542581096 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c7c4b1ed-462d-42a6-bc73-330ae94470e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7c4b1ed-462d-42a6-bc73-330ae94470e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7c4b1ed-462d-42a6-bc73-330ae94470e6">
											<gml:posList>35.670531058474424 139.73777000373929 26.091 35.6705815600261 139.73775564965098 26.091 35.67057913497514 139.7377438440615 26.091 35.67053570896849 139.7377579025191 26.091 35.67047359135856 139.7377755843242 26.091 35.67047773677025 139.73779716380022 26.091 35.67053285156302 139.7377805507997 26.091 35.670531058474424 139.73777000373929 26.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4cc334e0-8e85-4744-b3b1-abd940583a9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cc334e0-8e85-4744-b3b1-abd940583a9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cc334e0-8e85-4744-b3b1-abd940583a9c">
											<gml:posList>35.67055109827231 139.73778422955846 32.631 35.67055171377359 139.73778746538582 32.631 35.67059963921021 139.7377640343253 32.631 35.670601537554674 139.7377595583152 32.631 35.67055109827231 139.73778422955846 32.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20499c0a-9f11-4508-928d-150b425d8d5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20499c0a-9f11-4508-928d-150b425d8d5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20499c0a-9f11-4508-928d-150b425d8d5f">
											<gml:posList>35.67053677493375 139.73778357280483 29.204 35.670478722359604 139.7378010619601 29.204 35.670482206654526 139.73781872079942 29.204 35.670601537554674 139.7377595583152 29.204 35.6706128971671 139.7378192720708 29.204 35.67062835221232 139.73781485723455 29.204 35.670612756506344 139.7377328902411 29.204 35.67058239731102 139.73774304483936 29.204 35.67058560960706 139.73775869359886 29.204 35.67053499091173 139.73777309201074 29.204 35.67053677493375 139.73778357280483 29.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a8562eea-2dd3-43eb-97cf-9c3f24572c26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8562eea-2dd3-43eb-97cf-9c3f24572c26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8562eea-2dd3-43eb-97cf-9c3f24572c26">
											<gml:posList>35.67053285156302 139.7377805507997 29.559 35.67053677493375 139.73778357280483 29.559 35.67053499091173 139.73777309201074 29.559 35.670531058474424 139.73777000373929 29.559 35.67053285156302 139.7377805507997 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-238c8972-23da-44af-9ccf-bf5bc0b08182">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-238c8972-23da-44af-9ccf-bf5bc0b08182">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-238c8972-23da-44af-9ccf-bf5bc0b08182">
											<gml:posList>35.670474726905795 139.73779807318098 26.473 35.67047773677025 139.73779716380022 26.473 35.67047359135856 139.7377755843242 26.473 35.67046992054713 139.73777278294622 26.473 35.670474726905795 139.73779807318098 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-265f01c2-cc29-4aeb-9c0a-890437a20f4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-265f01c2-cc29-4aeb-9c0a-890437a20f4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-265f01c2-cc29-4aeb-9c0a-890437a20f4a">
											<gml:posList>35.67053285156302 139.7377805507997 29.559 35.670474726905795 139.73779807318098 29.559 35.670478722359604 139.7378010619601 29.559 35.67053677493375 139.73778357280483 29.559 35.67053285156302 139.7377805507997 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2d15c3c-e641-4b5f-bfe4-c6d87dbb1a13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2d15c3c-e641-4b5f-bfe4-c6d87dbb1a13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2d15c3c-e641-4b5f-bfe4-c6d87dbb1a13">
											<gml:posList>35.67061364845155 139.73782323679438 32.631 35.670601537554674 139.7377595583152 32.631 35.67059963921021 139.7377640343253 32.631 35.67061042860777 139.73782078835342 32.631 35.67061364845155 139.73782323679438 32.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-542cca10-3594-4989-b6aa-ef3d8ea42a77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-542cca10-3594-4989-b6aa-ef3d8ea42a77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-542cca10-3594-4989-b6aa-ef3d8ea42a77">
											<gml:posList>35.67061042860777 139.73782078835342 32.305 35.67059963921021 139.7377640343253 32.305 35.67055171377359 139.73778746538582 32.305 35.670560756188266 139.73783498677037 32.305 35.67061042860777 139.73782078835342 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99e8fe0b-0534-4660-9821-db4baa6e87dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99e8fe0b-0534-4660-9821-db4baa6e87dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99e8fe0b-0534-4660-9821-db4baa6e87dd">
											<gml:posList>35.67047894496648 139.7378203374409 36.888 35.67048423868482 139.73782368920175 36.888 35.670547877399 139.73779184428537 36.888 35.67055109827231 139.73778422955846 36.888 35.67047894496648 139.7378203374409 36.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2dffe22b-9356-46ed-8bcf-0a06ff6dde74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dffe22b-9356-46ed-8bcf-0a06ff6dde74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dffe22b-9356-46ed-8bcf-0a06ff6dde74">
											<gml:posList>35.67047894496648 139.7378203374409 29.559 35.670482206654526 139.73781872079942 29.559 35.670478722359604 139.7378010619601 29.559 35.670474726905795 139.73779807318098 29.559 35.67047894496648 139.7378203374409 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b7c2421-de35-41b8-91b9-022575327a4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b7c2421-de35-41b8-91b9-022575327a4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b7c2421-de35-41b8-91b9-022575327a4d">
											<gml:posList>35.67056136263941 139.73783817842414 36.888 35.67055109827231 139.73778422955846 36.888 35.670547877399 139.73779184428537 36.888 35.67055590603502 139.73783402047442 36.888 35.67056136263941 139.73783817842414 36.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e93f388-67a9-47fe-b5c6-213a7bd2b361">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e93f388-67a9-47fe-b5c6-213a7bd2b361">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e93f388-67a9-47fe-b5c6-213a7bd2b361">
											<gml:posList>35.67055590603502 139.73783402047442 35.991 35.670547877399 139.73779184428537 35.991 35.67048423868482 139.73782368920175 35.991 35.67048978726752 139.7378528999876 35.991 35.67055590603502 139.73783402047442 35.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7e5e3ef-bb16-4c5e-86aa-8ef3cbb760be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7e5e3ef-bb16-4c5e-86aa-8ef3cbb760be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7e5e3ef-bb16-4c5e-86aa-8ef3cbb760be">
											<gml:posList>35.67056136263941 139.73783817842414 32.631 35.67061364845155 139.73782323679438 32.631 35.67061042860777 139.73782078835342 32.631 35.670560756188266 139.73783498677037 32.631 35.67056136263941 139.73783817842414 32.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8093884-8832-4001-8dd8-7acd5a7dadc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8093884-8832-4001-8dd8-7acd5a7dadc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8093884-8832-4001-8dd8-7acd5a7dadc5">
											<gml:posList>35.67047894496648 139.7378203374409 36.888 35.67048639439341 139.7378595870237 36.888 35.67048978726752 139.7378528999876 36.888 35.67048423868482 139.73782368920175 36.888 35.67047894496648 139.7378203374409 36.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a5f733d0-4efe-4eed-aad7-8170825cf06f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5f733d0-4efe-4eed-aad7-8170825cf06f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5f733d0-4efe-4eed-aad7-8170825cf06f">
											<gml:posList>35.67056136263941 139.73783817842414 36.888 35.67055590603502 139.73783402047442 36.888 35.67048978726752 139.7378528999876 36.888 35.67048639439341 139.7378595870237 36.888 35.67056136263941 139.73783817842414 36.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0de8cd77-f9f9-440e-87aa-ed4eede1691e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0de8cd77-f9f9-440e-87aa-ed4eede1691e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0de8cd77-f9f9-440e-87aa-ed4eede1691e">
											<gml:posList>35.670632109921144 139.73770001548667 26.473 35.670630021983705 139.73770410510576 26.473 35.67065003487142 139.73780934139364 26.473 35.670653380986366 139.7378118891016 26.473 35.670632109921144 139.73770001548667 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4881165-e8a3-4e2b-aca9-3549f329a185">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4881165-e8a3-4e2b-aca9-3549f329a185">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4881165-e8a3-4e2b-aca9-3549f329a185">
											<gml:posList>35.6706152042306 139.73772783916726 29.559 35.670612756506344 139.7377328902411 29.559 35.67062835221232 139.73781485723455 29.559 35.670632338695704 139.7378179012624 29.559 35.6706152042306 139.73772783916726 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d09f3e54-dd3d-48b0-866e-0c8678322ea0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d09f3e54-dd3d-48b0-866e-0c8678322ea0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d09f3e54-dd3d-48b0-866e-0c8678322ea0">
											<gml:posList>35.670632338695704 139.7378179012624 26.473 35.670653380986366 139.7378118891016 26.473 35.67065003487142 139.73780934139364 26.473 35.670631705088944 139.73781456603646 26.473 35.670632338695704 139.7378179012624 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0ddf7dd-ad96-478c-97a1-aa8babd52c6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0ddf7dd-ad96-478c-97a1-aa8babd52c6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0ddf7dd-ad96-478c-97a1-aa8babd52c6b">
											<gml:posList>35.67061364845155 139.73782323679438 29.559 35.670632338695704 139.7378179012624 29.559 35.67062835221232 139.73781485723455 29.559 35.6706128971671 139.7378192720708 29.559 35.67061364845155 139.73782323679438 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0f20e49-e8d2-45c3-a1c2-3c0f7f68d92b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0f20e49-e8d2-45c3-a1c2-3c0f7f68d92b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0f20e49-e8d2-45c3-a1c2-3c0f7f68d92b">
											<gml:posList>35.67061042860777 139.73782078835342 32.631 35.67061042860777 139.73782078835342 32.305 35.670560756188266 139.73783498677037 32.305 35.670560756188266 139.73783498677037 32.631 35.67061042860777 139.73782078835342 32.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3b9af3e-c8e4-4748-b34f-84c0fc0a1bbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3b9af3e-c8e4-4748-b34f-84c0fc0a1bbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3b9af3e-c8e4-4748-b34f-84c0fc0a1bbb">
											<gml:posList>35.67047773677025 139.73779716380022 26.473 35.67047773677025 139.73779716380022 26.091 35.67047359135856 139.7377755843242 26.091 35.67047359135856 139.7377755843242 26.473 35.67047773677025 139.73779716380022 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45d25bab-d109-45e7-98aa-c488f3f18dd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45d25bab-d109-45e7-98aa-c488f3f18dd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45d25bab-d109-45e7-98aa-c488f3f18dd6">
											<gml:posList>35.67047894496648 139.7378203374409 29.559 35.670474726905795 139.73779807318098 29.559 35.670474726905795 139.73779807318098 26.473 35.67046992054713 139.73777278294622 26.473 35.67046992054713 139.73777278294622 14.92 35.67048639439341 139.7378595870237 14.92 35.67048639439341 139.7378595870237 36.888 35.67047894496648 139.7378203374409 36.888 35.67047894496648 139.7378203374409 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c04ee1b0-eba2-4940-a675-988f16c98ff3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c04ee1b0-eba2-4940-a675-988f16c98ff3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c04ee1b0-eba2-4940-a675-988f16c98ff3">
											<gml:posList>35.670482206654526 139.73781872079942 29.559 35.670482206654526 139.73781872079942 29.204 35.670478722359604 139.7378010619601 29.204 35.670478722359604 139.7378010619601 29.559 35.670482206654526 139.73781872079942 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1b46b45-ca7c-4645-b7bc-225f5cef989b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1b46b45-ca7c-4645-b7bc-225f5cef989b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1b46b45-ca7c-4645-b7bc-225f5cef989b">
											<gml:posList>35.67047894496648 139.7378203374409 36.888 35.670482206654526 139.73781872079942 29.559 35.67047894496648 139.7378203374409 29.559 35.67047894496648 139.7378203374409 36.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7dfec3b-48d6-4657-82df-e26206ac99f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7dfec3b-48d6-4657-82df-e26206ac99f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7dfec3b-48d6-4657-82df-e26206ac99f3">
											<gml:posList>35.67048978726752 139.7378528999876 36.888 35.67048978726752 139.7378528999876 35.991 35.67048423868482 139.73782368920175 35.991 35.67048423868482 139.73782368920175 36.888 35.67048978726752 139.7378528999876 36.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3451aa1e-f69d-484b-a3e9-15c1bf02ac68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3451aa1e-f69d-484b-a3e9-15c1bf02ac68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3451aa1e-f69d-484b-a3e9-15c1bf02ac68">
											<gml:posList>35.67046992054713 139.73777278294622 14.92 35.67046992054713 139.73777278294622 26.473 35.67053498497732 139.7377542581096 26.473 35.67053498497732 139.7377542581096 18.788 35.67053498497732 139.7377542581096 14.92 35.67046992054713 139.73777278294622 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7ac1abf-b9bb-471e-8f88-e4c3d39c223f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7ac1abf-b9bb-471e-8f88-e4c3d39c223f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7ac1abf-b9bb-471e-8f88-e4c3d39c223f">
											<gml:posList>35.67047773677025 139.73779716380022 26.473 35.670474726905795 139.73779807318098 26.473 35.670474726905795 139.73779807318098 29.559 35.67053285156302 139.7377805507997 29.559 35.67053285156302 139.7377805507997 26.091 35.67047773677025 139.73779716380022 26.091 35.67047773677025 139.73779716380022 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e55a90e-fc8a-4fa4-af1f-362d15fc4ca9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e55a90e-fc8a-4fa4-af1f-362d15fc4ca9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e55a90e-fc8a-4fa4-af1f-362d15fc4ca9">
											<gml:posList>35.67047359135856 139.7377755843242 26.473 35.67047359135856 139.7377755843242 26.091 35.67053570896849 139.7377579025191 26.091 35.67053570896849 139.7377579025191 26.473 35.67047359135856 139.7377755843242 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a21a411-8e21-497d-9f29-18069b5ddc97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a21a411-8e21-497d-9f29-18069b5ddc97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a21a411-8e21-497d-9f29-18069b5ddc97">
											<gml:posList>35.670478722359604 139.7378010619601 29.559 35.670478722359604 139.7378010619601 29.204 35.67053677493375 139.73778357280483 29.204 35.67053677493375 139.73778357280483 29.559 35.670478722359604 139.7378010619601 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95471efa-a799-45d0-8e8c-eaf09d55ee1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95471efa-a799-45d0-8e8c-eaf09d55ee1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95471efa-a799-45d0-8e8c-eaf09d55ee1f">
											<gml:posList>35.67047894496648 139.7378203374409 36.888 35.67055109827231 139.73778422955846 32.631 35.670482206654526 139.73781872079942 29.559 35.67047894496648 139.7378203374409 36.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ad6f413-9259-4bfb-86a8-6611392a3da6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ad6f413-9259-4bfb-86a8-6611392a3da6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ad6f413-9259-4bfb-86a8-6611392a3da6">
											<gml:posList>35.67047894496648 139.7378203374409 36.888 35.67055109827231 139.73778422955846 36.888 35.67055109827231 139.73778422955846 32.631 35.67047894496648 139.7378203374409 36.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a915f98c-d499-4c76-b45f-c35508bc8af8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a915f98c-d499-4c76-b45f-c35508bc8af8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a915f98c-d499-4c76-b45f-c35508bc8af8">
											<gml:posList>35.67048423868482 139.73782368920175 36.888 35.67048423868482 139.73782368920175 35.991 35.670547877399 139.73779184428537 35.991 35.670547877399 139.73779184428537 36.888 35.67048423868482 139.73782368920175 36.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-978aa08b-49ec-4f84-b03e-3d64e6b09ade">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-978aa08b-49ec-4f84-b03e-3d64e6b09ade">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-978aa08b-49ec-4f84-b03e-3d64e6b09ade">
											<gml:posList>35.67055109827231 139.73778422955846 32.631 35.670482206654526 139.73781872079942 29.204 35.670482206654526 139.73781872079942 29.559 35.67055109827231 139.73778422955846 32.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7ca0912-0d2b-4fba-85fa-16a7f3709398">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7ca0912-0d2b-4fba-85fa-16a7f3709398">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7ca0912-0d2b-4fba-85fa-16a7f3709398">
											<gml:posList>35.67055590603502 139.73783402047442 36.888 35.67055590603502 139.73783402047442 35.991 35.67048978726752 139.7378528999876 35.991 35.67048978726752 139.7378528999876 36.888 35.67055590603502 139.73783402047442 36.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7ed366d-8169-4a58-80b2-4e5675cb1c6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7ed366d-8169-4a58-80b2-4e5675cb1c6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7ed366d-8169-4a58-80b2-4e5675cb1c6b">
											<gml:posList>35.670531058474424 139.73777000373929 26.091 35.67053285156302 139.7377805507997 26.091 35.67053285156302 139.7377805507997 29.559 35.670531058474424 139.73777000373929 29.559 35.670531058474424 139.73777000373929 26.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00b9e72f-be9c-4641-a70d-356d5087bfea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00b9e72f-be9c-4641-a70d-356d5087bfea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00b9e72f-be9c-4641-a70d-356d5087bfea">
											<gml:posList>35.67052964258998 139.7377236662833 14.92 35.67053498497732 139.7377542581096 14.92 35.67053498497732 139.7377542581096 18.788 35.67052964258998 139.7377236662833 18.788 35.67052964258998 139.7377236662833 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a160ddb8-6133-4dbe-af4d-41df31d4b5a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a160ddb8-6133-4dbe-af4d-41df31d4b5a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a160ddb8-6133-4dbe-af4d-41df31d4b5a8">
											<gml:posList>35.67053792269656 139.73775330462735 18.788 35.67053792269656 139.73775330462735 18.412 35.670533060860436 139.7377262691292 18.412 35.670533060860436 139.7377262691292 18.788 35.67053792269656 139.73775330462735 18.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1d9b696-e3e8-439d-ae6b-8cbf51e4a815">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1d9b696-e3e8-439d-ae6b-8cbf51e4a815">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1d9b696-e3e8-439d-ae6b-8cbf51e4a815">
											<gml:posList>35.67053677493375 139.73778357280483 29.559 35.67053677493375 139.73778357280483 29.204 35.67053499091173 139.73777309201074 29.204 35.67053499091173 139.73777309201074 29.559 35.67053677493375 139.73778357280483 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4486b694-4648-4b3c-9183-8b6e1195a6c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4486b694-4648-4b3c-9183-8b6e1195a6c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4486b694-4648-4b3c-9183-8b6e1195a6c4">
											<gml:posList>35.670533060860436 139.7377262691292 18.788 35.670533060860436 139.7377262691292 18.412 35.67054722694021 139.73772185581657 18.412 35.67054722694021 139.73772185581657 18.788 35.670533060860436 139.7377262691292 18.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d991a5a3-1848-4b68-9372-87a3325525ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d991a5a3-1848-4b68-9372-87a3325525ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d991a5a3-1848-4b68-9372-87a3325525ac">
											<gml:posList>35.670601537554674 139.7377595583152 32.631 35.670601537554674 139.7377595583152 29.204 35.670482206654526 139.73781872079942 29.204 35.670601537554674 139.7377595583152 32.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-949be492-649b-45f2-98ea-b27939051565">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-949be492-649b-45f2-98ea-b27939051565">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-949be492-649b-45f2-98ea-b27939051565">
											<gml:posList>35.67055109827231 139.73778422955846 32.631 35.670601537554674 139.7377595583152 32.631 35.670482206654526 139.73781872079942 29.204 35.67055109827231 139.73778422955846 32.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e715762d-c17a-42b9-a6da-82d1059ce457">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e715762d-c17a-42b9-a6da-82d1059ce457">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e715762d-c17a-42b9-a6da-82d1059ce457">
											<gml:posList>35.670546494135976 139.73771846548186 19.791 35.670546494135976 139.73771846548186 18.788 35.67054722694021 139.73772185581657 18.788 35.67054722694021 139.73772185581657 18.412 35.67055297174501 139.7377484152764 18.412 35.67055297174501 139.7377484152764 19.791 35.670546494135976 139.73771846548186 19.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d2ecf54-ce93-4ea2-8001-5fa18ca0e0f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d2ecf54-ce93-4ea2-8001-5fa18ca0e0f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d2ecf54-ce93-4ea2-8001-5fa18ca0e0f3">
											<gml:posList>35.670547877399 139.73779184428537 36.888 35.670547877399 139.73779184428537 35.991 35.67055590603502 139.73783402047442 35.991 35.67055590603502 139.73783402047442 36.888 35.670547877399 139.73779184428537 36.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f39bf35a-2a55-4587-94dd-2f218b76d202">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f39bf35a-2a55-4587-94dd-2f218b76d202">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f39bf35a-2a55-4587-94dd-2f218b76d202">
											<gml:posList>35.670555026347444 139.73774775004998 19.791 35.670555026347444 139.73774775004998 19.517 35.670549100601455 139.7377203512878 19.517 35.670549100601455 139.7377203512878 19.791 35.670555026347444 139.73774775004998 19.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3394d20-5e70-4550-90c9-3fdaa23cca0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3394d20-5e70-4550-90c9-3fdaa23cca0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3394d20-5e70-4550-90c9-3fdaa23cca0b">
											<gml:posList>35.67055109827231 139.73778422955846 36.888 35.67056136263941 139.73783817842414 36.888 35.67056136263941 139.73783817842414 32.631 35.670560756188266 139.73783498677037 32.631 35.670560756188266 139.73783498677037 32.305 35.67055171377359 139.73778746538582 32.305 35.67055171377359 139.73778746538582 32.631 35.67055109827231 139.73778422955846 32.631 35.67055109827231 139.73778422955846 36.888</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8966d591-c29f-4b0d-a77b-4f048db10225">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8966d591-c29f-4b0d-a77b-4f048db10225">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8966d591-c29f-4b0d-a77b-4f048db10225">
											<gml:posList>35.670531058474424 139.73777000373929 29.559 35.6705815600261 139.73775564965098 29.559 35.6705815600261 139.73775564965098 26.091 35.670531058474424 139.73777000373929 26.091 35.670531058474424 139.73777000373929 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edf08d89-9c25-4254-bb83-817ca39bde6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edf08d89-9c25-4254-bb83-817ca39bde6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edf08d89-9c25-4254-bb83-817ca39bde6c">
											<gml:posList>35.6705783748936 139.73774015550802 26.473 35.6705783748936 139.73774015550802 19.517 35.670555026347444 139.73774775004998 19.517 35.670555026347444 139.73774775004998 19.791 35.67055297174501 139.7377484152764 19.791 35.67055297174501 139.7377484152764 18.412 35.67053792269656 139.73775330462735 18.412 35.67053792269656 139.73775330462735 18.788 35.67053498497732 139.7377542581096 18.788 35.67053498497732 139.7377542581096 26.473 35.6705783748936 139.73774015550802 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1769bed8-90ed-4f40-bd4c-2e84be47aaca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1769bed8-90ed-4f40-bd4c-2e84be47aaca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1769bed8-90ed-4f40-bd4c-2e84be47aaca">
											<gml:posList>35.67053570896849 139.7377579025191 26.473 35.67053570896849 139.7377579025191 26.091 35.67057913497514 139.7377438440615 26.091 35.67057913497514 139.7377438440615 26.473 35.67053570896849 139.7377579025191 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e26c0be6-a6b9-4d7e-a425-47e39cafa948">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e26c0be6-a6b9-4d7e-a425-47e39cafa948">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e26c0be6-a6b9-4d7e-a425-47e39cafa948">
											<gml:posList>35.67053499091173 139.73777309201074 29.559 35.67053499091173 139.73777309201074 29.204 35.67058560960706 139.73775869359886 29.204 35.67058560960706 139.73775869359886 29.559 35.67053499091173 139.73777309201074 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b78f363-b1bb-4c46-b944-f93690b967ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b78f363-b1bb-4c46-b944-f93690b967ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b78f363-b1bb-4c46-b944-f93690b967ee">
											<gml:posList>35.670546494135976 139.73771846548186 18.788 35.670546494135976 139.73771846548186 19.791 35.67059930164128 139.7377021534147 19.791 35.67059930164128 139.7377021534147 14.92 35.67052964258998 139.7377236662833 14.92 35.67052964258998 139.7377236662833 18.788 35.670546494135976 139.73771846548186 18.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edeff638-a560-4e53-a769-1d0b1098984a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edeff638-a560-4e53-a769-1d0b1098984a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edeff638-a560-4e53-a769-1d0b1098984a">
											<gml:posList>35.67061364845155 139.73782323679438 29.559 35.67061364845155 139.73782323679438 32.631 35.67056136263941 139.73783817842414 32.631 35.67056136263941 139.73783817842414 36.888 35.67048639439341 139.7378595870237 36.888 35.67048639439341 139.7378595870237 14.92 35.670653380986366 139.7378118891016 14.92 35.670653380986366 139.7378118891016 26.473 35.670632338695704 139.7378179012624 26.473 35.670632338695704 139.7378179012624 29.559 35.67061364845155 139.73782323679438 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-100e95bf-0a09-4d64-9641-a1dd9f8c54db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-100e95bf-0a09-4d64-9641-a1dd9f8c54db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-100e95bf-0a09-4d64-9641-a1dd9f8c54db">
											<gml:posList>35.670549100601455 139.7377203512878 19.791 35.670549100601455 139.7377203512878 19.517 35.67059753752226 139.73770539208158 19.517 35.67059753752226 139.73770539208158 19.791 35.670549100601455 139.7377203512878 19.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05f0d63a-e8e6-4997-a4bd-b0f2bda2c957">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05f0d63a-e8e6-4997-a4bd-b0f2bda2c957">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05f0d63a-e8e6-4997-a4bd-b0f2bda2c957">
											<gml:posList>35.67055171377359 139.73778746538582 32.631 35.67055171377359 139.73778746538582 32.305 35.67059963921021 139.7377640343253 32.305 35.67059963921021 139.7377640343253 32.631 35.67055171377359 139.73778746538582 32.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc19e322-5b95-4ea6-af60-3f2390719be8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc19e322-5b95-4ea6-af60-3f2390719be8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc19e322-5b95-4ea6-af60-3f2390719be8">
											<gml:posList>35.67057396624933 139.7377162786943 19.517 35.6705783748936 139.73774015550802 19.517 35.6705783748936 139.73774015550802 26.473 35.67057396624933 139.7377162786943 26.473 35.67057396624933 139.7377162786943 19.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5171aac9-d452-4041-bbd1-a6b1427e6689">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5171aac9-d452-4041-bbd1-a6b1427e6689">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5171aac9-d452-4041-bbd1-a6b1427e6689">
											<gml:posList>35.67058119544309 139.73773921321074 26.473 35.67058119544309 139.73773921321074 25.845 35.670577312392595 139.73771885953477 25.845 35.670577312392595 139.73771885953477 26.473 35.67058119544309 139.73773921321074 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0deebbfd-f8cf-4bd8-88c2-4a679021d15b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0deebbfd-f8cf-4bd8-88c2-4a679021d15b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0deebbfd-f8cf-4bd8-88c2-4a679021d15b">
											<gml:posList>35.6705783748936 139.73774015550802 29.559 35.6705783748936 139.73774015550802 26.473 35.67057913497514 139.7377438440615 26.473 35.67057913497514 139.7377438440615 26.091 35.6705815600261 139.73775564965098 26.091 35.6705815600261 139.73775564965098 29.559 35.6705783748936 139.73774015550802 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-415dab60-c994-4851-b6f8-cb0ca95bb727">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-415dab60-c994-4851-b6f8-cb0ca95bb727">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-415dab60-c994-4851-b6f8-cb0ca95bb727">
											<gml:posList>35.67058560960706 139.73775869359886 29.559 35.67058560960706 139.73775869359886 29.204 35.67058239731102 139.73774304483936 29.204 35.67058239731102 139.73774304483936 29.559 35.67058560960706 139.73775869359886 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10da2871-f5cf-4797-a3e0-d089c881d2a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10da2871-f5cf-4797-a3e0-d089c881d2a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10da2871-f5cf-4797-a3e0-d089c881d2a5">
											<gml:posList>35.67058119544309 139.73773921321074 26.473 35.6705783748936 139.73774015550802 26.473 35.6705783748936 139.73774015550802 29.559 35.6706152042306 139.73772783916726 29.559 35.6706152042306 139.73772783916726 25.845 35.67058119544309 139.73773921321074 25.845 35.67058119544309 139.73773921321074 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee89db9c-840d-4c5f-8e89-68963585feb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee89db9c-840d-4c5f-8e89-68963585feb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee89db9c-840d-4c5f-8e89-68963585feb3">
											<gml:posList>35.67058239731102 139.73774304483936 29.559 35.67058239731102 139.73774304483936 29.204 35.670612756506344 139.7377328902411 29.204 35.670612756506344 139.7377328902411 29.559 35.67058239731102 139.73774304483936 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f61a0ed-3ca1-4d6e-b5d5-0079db27e335">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f61a0ed-3ca1-4d6e-b5d5-0079db27e335">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f61a0ed-3ca1-4d6e-b5d5-0079db27e335">
											<gml:posList>35.67059753752226 139.73770539208158 19.791 35.67059753752226 139.73770539208158 19.517 35.67059819889254 139.7377096330678 19.517 35.67059819889254 139.7377096330678 19.791 35.67059753752226 139.73770539208158 19.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e872334a-fb82-44c8-88c3-740a4bd77971">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e872334a-fb82-44c8-88c3-740a4bd77971">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e872334a-fb82-44c8-88c3-740a4bd77971">
											<gml:posList>35.67060011840296 139.73770911160287 14.92 35.67059930164128 139.7377021534147 14.92 35.67059930164128 139.7377021534147 19.791 35.67060011840296 139.73770911160287 19.791 35.67060011840296 139.73770911160287 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13f92d9d-395d-40f7-a3bf-13ee525f465a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13f92d9d-395d-40f7-a3bf-13ee525f465a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13f92d9d-395d-40f7-a3bf-13ee525f465a">
											<gml:posList>35.670632109921144 139.73770001548667 26.473 35.670632109921144 139.73770001548667 14.92 35.67060011840296 139.73770911160287 14.92 35.67060011840296 139.73770911160287 19.791 35.67059819889254 139.7377096330678 19.791 35.67059819889254 139.7377096330678 19.517 35.67057396624933 139.7377162786943 19.517 35.67057396624933 139.7377162786943 26.473 35.670632109921144 139.73770001548667 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ef7f19d-544f-4a31-ab49-080e7adadff8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ef7f19d-544f-4a31-ab49-080e7adadff8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ef7f19d-544f-4a31-ab49-080e7adadff8">
											<gml:posList>35.670577312392595 139.73771885953477 26.473 35.670577312392595 139.73771885953477 25.845 35.670630021983705 139.73770410510576 25.845 35.670630021983705 139.73770410510576 26.473 35.670577312392595 139.73771885953477 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a77ddf31-1f5a-4220-999d-5eb0b917a2bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a77ddf31-1f5a-4220-999d-5eb0b917a2bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a77ddf31-1f5a-4220-999d-5eb0b917a2bd">
											<gml:posList>35.67059963921021 139.7377640343253 32.631 35.67059963921021 139.7377640343253 32.305 35.67061042860777 139.73782078835342 32.305 35.67061042860777 139.73782078835342 32.631 35.67059963921021 139.7377640343253 32.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4aedb86-9bb0-4307-9334-def0e4959c20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4aedb86-9bb0-4307-9334-def0e4959c20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4aedb86-9bb0-4307-9334-def0e4959c20">
											<gml:posList>35.670601537554674 139.7377595583152 29.204 35.670601537554674 139.7377595583152 32.631 35.67061364845155 139.73782323679438 32.631 35.67061364845155 139.73782323679438 29.559 35.6706128971671 139.7378192720708 29.559 35.6706128971671 139.7378192720708 29.204 35.670601537554674 139.7377595583152 29.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5363eac9-c4c0-484e-97e2-55ae74bc7805">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5363eac9-c4c0-484e-97e2-55ae74bc7805">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5363eac9-c4c0-484e-97e2-55ae74bc7805">
											<gml:posList>35.670612756506344 139.7377328902411 29.559 35.670612756506344 139.7377328902411 29.204 35.67062835221232 139.73781485723455 29.204 35.67062835221232 139.73781485723455 29.559 35.670612756506344 139.7377328902411 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8cb9887-f855-4acf-904d-5cc9c7a4d7f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8cb9887-f855-4acf-904d-5cc9c7a4d7f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8cb9887-f855-4acf-904d-5cc9c7a4d7f4">
											<gml:posList>35.67062835221232 139.73781485723455 29.559 35.67062835221232 139.73781485723455 29.204 35.6706128971671 139.7378192720708 29.204 35.6706128971671 139.7378192720708 29.559 35.67062835221232 139.73781485723455 29.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1170282-64f4-41b9-bd36-55e7633c4848">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1170282-64f4-41b9-bd36-55e7633c4848">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1170282-64f4-41b9-bd36-55e7633c4848">
											<gml:posList>35.6706152042306 139.73772783916726 25.845 35.6706152042306 139.73772783916726 29.559 35.670632338695704 139.7378179012624 29.559 35.670632338695704 139.7378179012624 26.473 35.670631705088944 139.73781456603646 26.473 35.670631705088944 139.73781456603646 25.845 35.6706152042306 139.73772783916726 25.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f0296e5-9839-4047-b695-f3ba4266a309">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f0296e5-9839-4047-b695-f3ba4266a309">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f0296e5-9839-4047-b695-f3ba4266a309">
											<gml:posList>35.670630021983705 139.73770410510576 26.473 35.670630021983705 139.73770410510576 25.845 35.67065003487142 139.73780934139364 25.845 35.67065003487142 139.73780934139364 26.473 35.670630021983705 139.73770410510576 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f858dec-4294-4a31-b908-18e9862a4e9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f858dec-4294-4a31-b908-18e9862a4e9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f858dec-4294-4a31-b908-18e9862a4e9e">
											<gml:posList>35.67065003487142 139.73780934139364 26.473 35.67065003487142 139.73780934139364 25.845 35.670631705088944 139.73781456603646 25.845 35.670631705088944 139.73781456603646 26.473 35.67065003487142 139.73780934139364 26.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8c7e82b-9a6f-48af-8e76-5dd6d0e5059f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8c7e82b-9a6f-48af-8e76-5dd6d0e5059f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8c7e82b-9a6f-48af-8e76-5dd6d0e5059f">
											<gml:posList>35.670653380986366 139.7378118891016 14.92 35.670632109921144 139.73770001548667 14.92 35.670632109921144 139.73770001548667 26.473 35.670653380986366 139.7378118891016 26.473 35.670653380986366 139.7378118891016 14.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7054</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">184.95505</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>