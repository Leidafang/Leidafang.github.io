<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_fc5dd56c-d1ef-4839-b8d1-51d3fada7d8d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">20.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67017857134987 139.74144589173082 0 35.670094920457124 139.7414413481855 0 35.67009059572528 139.74156197786064 0 35.67017362811106 139.74158287066152 0 35.67017857134987 139.74144589173082 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67017857134987 139.74144589173082 8.47 35.67017362811106 139.74158287066152 8.47 35.67009059572528 139.74156197786064 8.47 35.670094920457124 139.7414413481855 8.47 35.67017857134987 139.74144589173082 8.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67017857134987 139.74144589173082 8.47 35.670094920457124 139.7414413481855 8.47 35.670094920457124 139.7414413481855 28.61 35.67017857134987 139.74144589173082 28.61 35.67017857134987 139.74144589173082 8.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670094920457124 139.7414413481855 8.47 35.67009059572528 139.74156197786064 8.47 35.67009059572528 139.74156197786064 28.61 35.670094920457124 139.7414413481855 28.61 35.670094920457124 139.7414413481855 8.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67009059572528 139.74156197786064 8.47 35.67017362811106 139.74158287066152 8.47 35.67017362811106 139.74158287066152 28.61 35.67009059572528 139.74156197786064 28.61 35.67009059572528 139.74156197786064 8.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67017362811106 139.74158287066152 8.47 35.67017857134987 139.74144589173082 8.47 35.67017857134987 139.74144589173082 28.61 35.67017362811106 139.74158287066152 28.61 35.67017362811106 139.74158287066152 8.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67017857134987 139.74144589173082 28.61 35.670094920457124 139.7414413481855 28.61 35.67009059572528 139.74156197786064 28.61 35.67017362811106 139.74158287066152 28.61 35.67017857134987 139.74144589173082 28.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7450e3ad-f644-4997-89cd-7bb311af52b9"/>
							<gml:surfaceMember xlink:href="#poly-06bef42e-6260-48e6-80a7-c5390fe6afb8"/>
							<gml:surfaceMember xlink:href="#poly-d4cdb908-ee4b-46c3-ba30-a287abf22ef5"/>
							<gml:surfaceMember xlink:href="#poly-8520c159-5674-47b0-b3c1-d4d474a9b78d"/>
							<gml:surfaceMember xlink:href="#poly-33ed1127-98b0-4621-a625-333cc1b5d8da"/>
							<gml:surfaceMember xlink:href="#poly-829b3b6a-e597-4fcb-8057-8657f44069be"/>
							<gml:surfaceMember xlink:href="#poly-1158d729-fb20-4e88-94f6-12dd237afdfe"/>
							<gml:surfaceMember xlink:href="#poly-d0df3fb3-494b-458f-9362-7784ada10b34"/>
							<gml:surfaceMember xlink:href="#poly-59957685-1b85-41f9-9d11-be236a41cb1c"/>
							<gml:surfaceMember xlink:href="#poly-bee63fb6-bcea-4db6-bd05-ef3646576621"/>
							<gml:surfaceMember xlink:href="#poly-3c7d44c4-c7c0-4971-9141-730d162a0ff4"/>
							<gml:surfaceMember xlink:href="#poly-9dba4b70-b3e7-43cf-be73-15a4dfc58a5e"/>
							<gml:surfaceMember xlink:href="#poly-ecc3950a-fc3e-4142-a6df-37bb402e0c2f"/>
							<gml:surfaceMember xlink:href="#poly-78c47262-0019-4e06-84c0-6351b360e7a5"/>
							<gml:surfaceMember xlink:href="#poly-37451a99-ef25-4729-b295-5e525515d190"/>
							<gml:surfaceMember xlink:href="#poly-465b87ce-1706-498e-bb07-452557c06462"/>
							<gml:surfaceMember xlink:href="#poly-07834e9c-f1ec-4ff6-b20a-cd2ae8581563"/>
							<gml:surfaceMember xlink:href="#poly-f3295757-44ac-4a54-93ce-0654e45464a7"/>
							<gml:surfaceMember xlink:href="#poly-6bb1e273-a08d-4436-bbe6-fe5c78d5fc3f"/>
							<gml:surfaceMember xlink:href="#poly-6b77020f-b958-4429-b35f-71bf61e72ded"/>
							<gml:surfaceMember xlink:href="#poly-dfb903be-1eca-49d7-943f-88cbbef7a02d"/>
							<gml:surfaceMember xlink:href="#poly-d9d47680-8929-4d55-b5a5-609ded261863"/>
							<gml:surfaceMember xlink:href="#poly-3df8a019-668e-420e-aae0-f469837e267d"/>
							<gml:surfaceMember xlink:href="#poly-04e3bbd9-3199-46ba-8c9b-309c4adcc832"/>
							<gml:surfaceMember xlink:href="#poly-7f225e51-d16c-438b-8a19-26065f6dc8bd"/>
							<gml:surfaceMember xlink:href="#poly-4456e899-4759-4f16-b336-15836086a8d6"/>
							<gml:surfaceMember xlink:href="#poly-2fed0c3b-2678-435d-a199-3ea936e9aa20"/>
							<gml:surfaceMember xlink:href="#poly-2f839f87-6223-4729-a425-8c300606260e"/>
							<gml:surfaceMember xlink:href="#poly-3b1def18-d661-4f6a-8feb-956f0a6f8675"/>
							<gml:surfaceMember xlink:href="#poly-ce28eba9-f5f7-4393-adf6-f409d895bc50"/>
							<gml:surfaceMember xlink:href="#poly-d8a3b5ff-096c-4a81-aab3-f5c03ffb3850"/>
							<gml:surfaceMember xlink:href="#poly-6f06476f-ba38-4a11-a1ad-b0aaeedf2d89"/>
							<gml:surfaceMember xlink:href="#poly-0a294a77-5bf6-4cd8-b29e-6879f0855a02"/>
							<gml:surfaceMember xlink:href="#poly-396d8bc7-d061-4871-b560-c28231f23166"/>
							<gml:surfaceMember xlink:href="#poly-73b1e62d-4798-4621-8b2c-9e92e9e2ca1a"/>
							<gml:surfaceMember xlink:href="#poly-47890a4b-141f-4c5d-8ba9-7b9474e13703"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_fc5dd56c-d1ef-4839-b8d1-51d3fada7d8d_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3837eb47-0deb-4a24-93bc-af67b714895e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3837eb47-0deb-4a24-93bc-af67b714895e_0">
											<gml:posList>35.670118296149084 139.74149265319517 29.432 35.670135567167556 139.7414935833874 30.511 35.670135567167556 139.7414935833874 29.432 35.670118296149084 139.74149265319517 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a781c83-51d4-41f9-a55d-33b166d84bc0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a781c83-51d4-41f9-a55d-33b166d84bc0_0">
											<gml:posList>35.670118296149084 139.74149265319517 29.432 35.670118296149084 139.74149265319517 30.511 35.670135567167556 139.7414935833874 30.511 35.670118296149084 139.74149265319517 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4042ce50-796e-4c8e-8817-5467da547bae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4042ce50-796e-4c8e-8817-5467da547bae_0">
											<gml:posList>35.670118296149084 139.74149265319517 29.432 35.67011815491192 139.74149656372006 30.511 35.670118296149084 139.74149265319517 30.511 35.670118296149084 139.74149265319517 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89169c5f-a55a-4543-8f8d-e249f7ab5f9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89169c5f-a55a-4543-8f8d-e249f7ab5f9c_0">
											<gml:posList>35.670118296149084 139.74149265319517 29.432 35.67011815491192 139.74149656372006 29.432 35.67011815491192 139.74149656372006 30.511 35.670118296149084 139.74149265319517 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40ead195-6624-4e79-9294-47d379b5d099">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40ead195-6624-4e79-9294-47d379b5d099_0">
											<gml:posList>35.67011815491192 139.74149656372006 29.432 35.67011794296327 139.74150230799899 30.511 35.67011815491192 139.74149656372006 30.511 35.67011815491192 139.74149656372006 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4158381c-e2b1-483d-ad14-bb9b31421f0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4158381c-e2b1-483d-ad14-bb9b31421f0d_0">
											<gml:posList>35.67011815491192 139.74149656372006 29.432 35.67011794296327 139.74150230799899 29.432 35.67011794296327 139.74150230799899 30.511 35.67011815491192 139.74149656372006 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b607b71-d14c-433f-8ae8-9380b088e5ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b607b71-d14c-433f-8ae8-9380b088e5ed_0">
											<gml:posList>35.67012653340387 139.74150277314772 29.432 35.67011794296327 139.74150230799899 30.511 35.67011794296327 139.74150230799899 29.432 35.67012653340387 139.74150277314772 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f6e1ea6-70e8-4ad4-8ec8-d2722f911334">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f6e1ea6-70e8-4ad4-8ec8-d2722f911334_0">
											<gml:posList>35.67012653340387 139.74150277314772 29.432 35.67012653340387 139.74150277314772 30.511 35.67011794296327 139.74150230799899 30.511 35.67012653340387 139.74150277314772 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46c1358f-55bc-49b2-9064-7f5818351796">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46c1358f-55bc-49b2-9064-7f5818351796_0">
											<gml:posList>35.670135567167556 139.7414935833874 29.432 35.67013419915954 139.74153177175648 30.511 35.67013419915954 139.74153177175648 29.432 35.670135567167556 139.7414935833874 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b372e81-dc09-4a02-bdc9-95e2406def77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b372e81-dc09-4a02-bdc9-95e2406def77_0">
											<gml:posList>35.670135567167556 139.7414935833874 29.432 35.670135567167556 139.7414935833874 30.511 35.67013419915954 139.74153177175648 30.511 35.670135567167556 139.7414935833874 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cb830b7-7362-4ab5-b595-ecc66be205e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cb830b7-7362-4ab5-b595-ecc66be205e2_0">
											<gml:posList>35.670125509559696 139.74153129567193 29.432 35.67012653340387 139.74150277314772 30.511 35.67012653340387 139.74150277314772 29.432 35.670125509559696 139.74153129567193 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e331aa96-c76a-4eb9-b142-79d3680d8a6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e331aa96-c76a-4eb9-b142-79d3680d8a6e_0">
											<gml:posList>35.670125509559696 139.74153129567193 29.432 35.670125509559696 139.74153129567193 30.511 35.67012653340387 139.74150277314772 30.511 35.670125509559696 139.74153129567193 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e88e6d64-79e3-4d07-be30-c54f2f840b15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e88e6d64-79e3-4d07-be30-c54f2f840b15_0">
											<gml:posList>35.67013419915954 139.74153177175648 29.432 35.670125509559696 139.74153129567193 30.511 35.670125509559696 139.74153129567193 29.432 35.67013419915954 139.74153177175648 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9ff3c0a-4621-46d5-aae0-fc704cf9706a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9ff3c0a-4621-46d5-aae0-fc704cf9706a_0">
											<gml:posList>35.67013419915954 139.74153177175648 29.432 35.67013419915954 139.74153177175648 30.511 35.670125509559696 139.74153129567193 30.511 35.67013419915954 139.74153177175648 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4bbf567-6506-4525-af1f-fa5e84efa0d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4bbf567-6506-4525-af1f-fa5e84efa0d3_0">
											<gml:posList>35.67012653340387 139.74150277314772 30.511 35.67013419915954 139.74153177175648 30.511 35.670135567167556 139.7414935833874 30.511 35.67012653340387 139.74150277314772 30.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-357fefd8-df8f-4671-9141-247819747966">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-357fefd8-df8f-4671-9141-247819747966_0">
											<gml:posList>35.670118296149084 139.74149265319517 30.511 35.67012653340387 139.74150277314772 30.511 35.670135567167556 139.7414935833874 30.511 35.670118296149084 139.74149265319517 30.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dc1eb28-2177-4c63-b9d6-de4854ffc352">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4dc1eb28-2177-4c63-b9d6-de4854ffc352_0">
											<gml:posList>35.67012653340387 139.74150277314772 30.511 35.670125509559696 139.74153129567193 30.511 35.67013419915954 139.74153177175648 30.511 35.67012653340387 139.74150277314772 30.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-262666f0-3d11-4917-a8df-ae5a46072508">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-262666f0-3d11-4917-a8df-ae5a46072508_0">
											<gml:posList>35.67011794296327 139.74150230799899 30.511 35.67012653340387 139.74150277314772 30.511 35.67011815491192 139.74149656372006 30.511 35.67011794296327 139.74150230799899 30.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2bb8749-3310-4415-84f5-e491d554beee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2bb8749-3310-4415-84f5-e491d554beee_0">
											<gml:posList>35.67012653340387 139.74150277314772 30.511 35.670118296149084 139.74149265319517 30.511 35.67011815491192 139.74149656372006 30.511 35.67012653340387 139.74150277314772 30.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd8f1ff0-30e0-43d5-a9ab-acf24a210d55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013419915954 139.74153177175648 29.432 35.67012653340387 139.74150277314772 29.432 35.670135567167556 139.7414935833874 29.432 35.67013419915954 139.74153177175648 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6379640f-f250-4b0d-bc8c-b27048032773">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670135567167556 139.7414935833874 29.432 35.67012653340387 139.74150277314772 29.432 35.670118296149084 139.74149265319517 29.432 35.670135567167556 139.7414935833874 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f0bd8f1-aee4-4dab-9201-90ba194d08cd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013419915954 139.74153177175648 29.432 35.670125509559696 139.74153129567193 29.432 35.67012653340387 139.74150277314772 29.432 35.67013419915954 139.74153177175648 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d185c72b-9483-4b93-b6a8-cd7c17016531">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670118296149084 139.74149265319517 29.432 35.67012653340387 139.74150277314772 29.432 35.67011815491192 139.74149656372006 29.432 35.670118296149084 139.74149265319517 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-159d1321-a8fd-47fa-aa6d-40c30d798b3d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011815491192 139.74149656372006 29.432 35.67012653340387 139.74150277314772 29.432 35.67011794296327 139.74150230799899 29.432 35.67011815491192 139.74149656372006 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_fc5dd56c-d1ef-4839-b8d1-51d3fada7d8d_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-465fb707-c337-419e-90bf-f0bd83a62202">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670139246701446 139.74153157819137 29.432 35.67015550815729 139.74153247640942 29.432 35.67015478412996 139.74155228312608 29.432 35.67013852268268 139.74155139595024 29.432 35.670139246701446 139.74153157819137 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5674f36-f1d7-4ebb-8c97-6f5c16ec8755">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5674f36-f1d7-4ebb-8c97-6f5c16ec8755_0">
											<gml:posList>35.670139246701446 139.74153157819137 29.432 35.670139246701446 139.74153157819137 31.573 35.67015550815729 139.74153247640942 31.573 35.67015550815729 139.74153247640942 29.432 35.670139246701446 139.74153157819137 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13289ebd-522e-4043-aba2-24daf9bea66f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13289ebd-522e-4043-aba2-24daf9bea66f_0">
											<gml:posList>35.67013852268268 139.74155139595024 29.432 35.67013852268268 139.74155139595024 31.573 35.670139246701446 139.74153157819137 31.573 35.670139246701446 139.74153157819137 29.432 35.67013852268268 139.74155139595024 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b676e025-8d1a-4d06-818c-d9b9a7f967f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b676e025-8d1a-4d06-818c-d9b9a7f967f1_0">
											<gml:posList>35.67015478412996 139.74155228312608 31.573 35.67015550815729 139.74153247640942 31.573 35.670139246701446 139.74153157819137 31.573 35.67013852268268 139.74155139595024 31.573 35.67015478412996 139.74155228312608 31.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd54a04d-2106-460e-80d8-e2951938253e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd54a04d-2106-460e-80d8-e2951938253e_0">
											<gml:posList>35.67015550815729 139.74153247640942 29.432 35.67015550815729 139.74153247640942 31.573 35.67015478412996 139.74155228312608 31.573 35.67015478412996 139.74155228312608 29.432 35.67015550815729 139.74153247640942 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32dd37d1-3cfc-457b-b202-f0d2c06cc787">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32dd37d1-3cfc-457b-b202-f0d2c06cc787_0">
											<gml:posList>35.67015478412996 139.74155228312608 31.573 35.67013852268268 139.74155139595024 31.573 35.67013852268268 139.74155139595024 29.432 35.67015478412996 139.74155228312608 29.432 35.67015478412996 139.74155228312608 31.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7450e3ad-f644-4997-89cd-7bb311af52b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7450e3ad-f644-4997-89cd-7bb311af52b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7450e3ad-f644-4997-89cd-7bb311af52b9">
											<gml:posList>35.67017857134985 139.74144589173082 8.47 35.67017362811104 139.74158287066152 8.47 35.670090595725256 139.7415619778606 8.47 35.67009492045711 139.7414413481855 8.47 35.67017857134985 139.74144589173082 8.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06bef42e-6260-48e6-80a7-c5390fe6afb8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06bef42e-6260-48e6-80a7-c5390fe6afb8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06bef42e-6260-48e6-80a7-c5390fe6afb8">
											<gml:posList>35.670093931982905 139.74146895382245 30.177 35.67017757382724 139.74147345322194 30.177 35.67017857134985 139.74144589173082 26.083 35.67009492045711 139.7414413481855 26.083 35.670093931982905 139.74146895382245 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4cdb908-ee4b-46c3-ba30-a287abf22ef5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4cdb908-ee4b-46c3-ba30-a287abf22ef5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4cdb908-ee4b-46c3-ba30-a287abf22ef5">
											<gml:posList>35.67011839320217 139.74148990257433 35.285 35.67009559653528 139.74148866941857 35.285 35.670094254963594 139.74152606241057 35.285 35.670117051621695 139.74152728453075 35.285 35.67011839320217 139.74148990257433 35.285</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8520c159-5674-47b0-b3c1-d4d474a9b78d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8520c159-5674-47b0-b3c1-d4d474a9b78d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8520c159-5674-47b0-b3c1-d4d474a9b78d">
											<gml:posList>35.67012653340387 139.74150277314772 29.432 35.6701242298418 139.74156707585763 29.432 35.67017108319413 139.7415788748382 29.432 35.670174772952485 139.74147659356058 29.432 35.67009649449274 139.74147237521478 29.432 35.67009591203245 139.7414886911496 29.432 35.67011839320217 139.74148990257433 29.432 35.67011794296327 139.74150230799899 29.432 35.67012653340387 139.74150277314772 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33ed1127-98b0-4621-a625-333cc1b5d8da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33ed1127-98b0-4621-a625-333cc1b5d8da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33ed1127-98b0-4621-a625-333cc1b5d8da">
											<gml:posList>35.670093931982905 139.74146895382245 30.177 35.670090595725256 139.7415619778606 30.177 35.67009316950803 139.74155654017446 30.177 35.67009559653528 139.74148866941857 30.177 35.67009591203245 139.7414886911496 30.177 35.67009649449274 139.74147237521478 30.177 35.670174772952485 139.74147659356058 30.177 35.67017108319413 139.7415788748382 30.177 35.6701242298418 139.74156707585763 30.177 35.67012421215109 139.74156751772685 30.177 35.67017362811104 139.74158287066152 30.177 35.67017757382724 139.74147345322194 30.177 35.670093931982905 139.74146895382245 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-829b3b6a-e597-4fcb-8057-8657f44069be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-829b3b6a-e597-4fcb-8057-8657f44069be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-829b3b6a-e597-4fcb-8057-8657f44069be">
											<gml:posList>35.670117051621695 139.74152728453075 31.537 35.67009658060528 139.74152619230225 31.537 35.670095574564094 139.7415544275934 31.537 35.670122027984625 139.74156378660297 31.537 35.670124110784585 139.74150549329357 31.537 35.670117836972 139.741505158046 31.537 35.670117051621695 139.74152728453075 31.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1158d729-fb20-4e88-94f6-12dd237afdfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1158d729-fb20-4e88-94f6-12dd237afdfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1158d729-fb20-4e88-94f6-12dd237afdfe">
											<gml:posList>35.670095574564094 139.7415544275934 32.187 35.67009658060528 139.74152619230225 32.187 35.670094254963594 139.74152606241057 32.187 35.67009316950803 139.74155654017446 32.187 35.67012421215109 139.74156751772685 32.187 35.67012653340387 139.74150277314772 32.187 35.67011794296327 139.74150230799899 32.187 35.670117836972 139.741505158046 32.187 35.670124110784585 139.74150549329357 32.187 35.670122027984625 139.74156378660297 32.187 35.670095574564094 139.7415544275934 32.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0df3fb3-494b-458f-9362-7784ada10b34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0df3fb3-494b-458f-9362-7784ada10b34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0df3fb3-494b-458f-9362-7784ada10b34">
											<gml:posList>35.67009316950803 139.74155654017446 30.177 35.670090595725256 139.7415619778606 30.177 35.67009336992313 139.7415593125463 30.177 35.6700934670451 139.74155665029608 30.177 35.67009316950803 139.74155654017446 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-59957685-1b85-41f9-9d11-be236a41cb1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59957685-1b85-41f9-9d11-be236a41cb1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59957685-1b85-41f9-9d11-be236a41cb1c">
											<gml:posList>35.6700934670451 139.74155665029608 29.432 35.67009336992313 139.7415593125463 29.432 35.67011988439373 139.74156598725497 29.432 35.6700934670451 139.74155665029608 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bee63fb6-bcea-4db6-bd05-ef3646576621">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bee63fb6-bcea-4db6-bd05-ef3646576621">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bee63fb6-bcea-4db6-bd05-ef3646576621">
											<gml:posList>35.670090595725256 139.7415619778606 30.177 35.67017362811104 139.74158287066152 30.177 35.67012421215109 139.74156751772685 30.177 35.67011988439373 139.74156598725497 30.177 35.67009336992313 139.7415593125463 30.177 35.670090595725256 139.7415619778606 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c7d44c4-c7c0-4971-9141-730d162a0ff4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c7d44c4-c7c0-4971-9141-730d162a0ff4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c7d44c4-c7c0-4971-9141-730d162a0ff4">
											<gml:posList>35.67011988439373 139.74156598725497 30.177 35.6700934670451 139.74155665029608 30.177 35.6700934670451 139.74155665029608 29.432 35.67011988439373 139.74156598725497 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9dba4b70-b3e7-43cf-be73-15a4dfc58a5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dba4b70-b3e7-43cf-be73-15a4dfc58a5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dba4b70-b3e7-43cf-be73-15a4dfc58a5e">
											<gml:posList>35.670093931982905 139.74146895382245 30.177 35.67009492045711 139.7414413481855 26.083 35.67009492045711 139.7414413481855 8.47 35.670090595725256 139.7415619778606 8.47 35.670090595725256 139.7415619778606 30.177 35.670093931982905 139.74146895382245 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecc3950a-fc3e-4142-a6df-37bb402e0c2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecc3950a-fc3e-4142-a6df-37bb402e0c2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecc3950a-fc3e-4142-a6df-37bb402e0c2f">
											<gml:posList>35.67009336992313 139.7415593125463 30.177 35.67009336992313 139.7415593125463 29.432 35.6700934670451 139.74155665029608 29.432 35.6700934670451 139.74155665029608 30.177 35.67009336992313 139.7415593125463 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78c47262-0019-4e06-84c0-6351b360e7a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78c47262-0019-4e06-84c0-6351b360e7a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78c47262-0019-4e06-84c0-6351b360e7a5">
											<gml:posList>35.670094254963594 139.74152606241057 32.187 35.670094254963594 139.74152606241057 35.285 35.67009559653528 139.74148866941857 35.285 35.67009559653528 139.74148866941857 30.177 35.67009316950803 139.74155654017446 30.177 35.67009316950803 139.74155654017446 32.187 35.670094254963594 139.74152606241057 32.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37451a99-ef25-4729-b295-5e525515d190">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37451a99-ef25-4729-b295-5e525515d190">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37451a99-ef25-4729-b295-5e525515d190">
											<gml:posList>35.670095574564094 139.7415544275934 31.537 35.67009658060528 139.74152619230225 31.537 35.67009658060528 139.74152619230225 32.187 35.670095574564094 139.7415544275934 32.187 35.670095574564094 139.7415544275934 31.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-465b87ce-1706-498e-bb07-452557c06462">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-465b87ce-1706-498e-bb07-452557c06462">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-465b87ce-1706-498e-bb07-452557c06462">
											<gml:posList>35.67009649449274 139.74147237521478 29.432 35.67009649449274 139.74147237521478 30.177 35.67009591203245 139.7414886911496 30.177 35.67009591203245 139.7414886911496 29.432 35.67009649449274 139.74147237521478 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07834e9c-f1ec-4ff6-b20a-cd2ae8581563">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07834e9c-f1ec-4ff6-b20a-cd2ae8581563">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07834e9c-f1ec-4ff6-b20a-cd2ae8581563">
											<gml:posList>35.67009658060528 139.74152619230225 32.187 35.67009658060528 139.74152619230225 31.537 35.670117051621695 139.74152728453075 31.537 35.670117051621695 139.74152728453075 35.285 35.670094254963594 139.74152606241057 35.285 35.670094254963594 139.74152606241057 32.187 35.67009658060528 139.74152619230225 32.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3295757-44ac-4a54-93ce-0654e45464a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3295757-44ac-4a54-93ce-0654e45464a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3295757-44ac-4a54-93ce-0654e45464a7">
											<gml:posList>35.67009591203245 139.7414886911496 30.177 35.67009559653528 139.74148866941857 30.177 35.67009559653528 139.74148866941857 35.285 35.67011839320217 139.74148990257433 35.285 35.67011839320217 139.74148990257433 29.432 35.67009591203245 139.7414886911496 29.432 35.67009591203245 139.7414886911496 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bb1e273-a08d-4436-bbe6-fe5c78d5fc3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bb1e273-a08d-4436-bbe6-fe5c78d5fc3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bb1e273-a08d-4436-bbe6-fe5c78d5fc3f">
											<gml:posList>35.67012421215109 139.74156751772685 32.187 35.67009316950803 139.74155654017446 32.187 35.67009316950803 139.74155654017446 30.177 35.67012421215109 139.74156751772685 32.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b77020f-b958-4429-b35f-71bf61e72ded">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b77020f-b958-4429-b35f-71bf61e72ded">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b77020f-b958-4429-b35f-71bf61e72ded">
											<gml:posList>35.670122027984625 139.74156378660297 31.537 35.670095574564094 139.7415544275934 31.537 35.670095574564094 139.7415544275934 32.187 35.670122027984625 139.74156378660297 32.187 35.670122027984625 139.74156378660297 31.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dfb903be-1eca-49d7-943f-88cbbef7a02d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfb903be-1eca-49d7-943f-88cbbef7a02d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfb903be-1eca-49d7-943f-88cbbef7a02d">
											<gml:posList>35.67011988439373 139.74156598725497 30.177 35.67012421215109 139.74156751772685 32.187 35.6700934670451 139.74155665029608 30.177 35.67011988439373 139.74156598725497 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9d47680-8929-4d55-b5a5-609ded261863">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9d47680-8929-4d55-b5a5-609ded261863">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9d47680-8929-4d55-b5a5-609ded261863">
											<gml:posList>35.67011794296327 139.74150230799899 32.187 35.67011794296327 139.74150230799899 29.432 35.67011839320217 139.74148990257433 29.432 35.67011839320217 139.74148990257433 35.285 35.670117051621695 139.74152728453075 35.285 35.670117051621695 139.74152728453075 31.537 35.670117836972 139.741505158046 31.537 35.670117836972 139.741505158046 32.187 35.67011794296327 139.74150230799899 32.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3df8a019-668e-420e-aae0-f469837e267d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3df8a019-668e-420e-aae0-f469837e267d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3df8a019-668e-420e-aae0-f469837e267d">
											<gml:posList>35.670117836972 139.741505158046 31.537 35.670124110784585 139.74150549329357 31.537 35.670124110784585 139.74150549329357 32.187 35.670117836972 139.741505158046 32.187 35.670117836972 139.741505158046 31.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04e3bbd9-3199-46ba-8c9b-309c4adcc832">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04e3bbd9-3199-46ba-8c9b-309c4adcc832">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04e3bbd9-3199-46ba-8c9b-309c4adcc832">
											<gml:posList>35.67011988439373 139.74156598725497 30.177 35.67012421215109 139.74156751772685 30.177 35.67012421215109 139.74156751772685 32.187 35.67011988439373 139.74156598725497 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f225e51-d16c-438b-8a19-26065f6dc8bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f225e51-d16c-438b-8a19-26065f6dc8bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f225e51-d16c-438b-8a19-26065f6dc8bd">
											<gml:posList>35.67011794296327 139.74150230799899 32.187 35.67012653340387 139.74150277314772 32.187 35.67012653340387 139.74150277314772 29.432 35.67011794296327 139.74150230799899 29.432 35.67011794296327 139.74150230799899 32.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4456e899-4759-4f16-b336-15836086a8d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4456e899-4759-4f16-b336-15836086a8d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4456e899-4759-4f16-b336-15836086a8d6">
											<gml:posList>35.670124110784585 139.74150549329357 31.537 35.670122027984625 139.74156378660297 31.537 35.670122027984625 139.74156378660297 32.187 35.670124110784585 139.74150549329357 32.187 35.670124110784585 139.74150549329357 31.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2fed0c3b-2678-435d-a199-3ea936e9aa20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fed0c3b-2678-435d-a199-3ea936e9aa20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fed0c3b-2678-435d-a199-3ea936e9aa20">
											<gml:posList>35.6701242298418 139.74156707585763 30.177 35.6701242298418 139.74156707585763 29.432 35.67012653340387 139.74150277314772 29.432 35.67012653340387 139.74150277314772 32.187 35.67012421215109 139.74156751772685 32.187 35.67012421215109 139.74156751772685 30.177 35.6701242298418 139.74156707585763 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f839f87-6223-4729-a425-8c300606260e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f839f87-6223-4729-a425-8c300606260e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f839f87-6223-4729-a425-8c300606260e">
											<gml:posList>35.670090595725256 139.7415619778606 30.177 35.670090595725256 139.7415619778606 8.47 35.67017362811104 139.74158287066152 8.47 35.67017362811104 139.74158287066152 30.177 35.670090595725256 139.7415619778606 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b1def18-d661-4f6a-8feb-956f0a6f8675">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b1def18-d661-4f6a-8feb-956f0a6f8675">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b1def18-d661-4f6a-8feb-956f0a6f8675">
											<gml:posList>35.670174772952485 139.74147659356058 30.177 35.67009649449274 139.74147237521478 30.177 35.67009649449274 139.74147237521478 29.432 35.670174772952485 139.74147659356058 29.432 35.670174772952485 139.74147659356058 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce28eba9-f5f7-4393-adf6-f409d895bc50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce28eba9-f5f7-4393-adf6-f409d895bc50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce28eba9-f5f7-4393-adf6-f409d895bc50">
											<gml:posList>35.67017857134985 139.74144589173082 26.083 35.67017857134985 139.74144589173082 8.47 35.67009492045711 139.7414413481855 8.47 35.67009492045711 139.7414413481855 26.083 35.67017857134985 139.74144589173082 26.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8a3b5ff-096c-4a81-aab3-f5c03ffb3850">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8a3b5ff-096c-4a81-aab3-f5c03ffb3850">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8a3b5ff-096c-4a81-aab3-f5c03ffb3850">
											<gml:posList>35.67017108319413 139.7415788748382 30.177 35.67017108319413 139.7415788748382 29.432 35.6701242298418 139.74156707585763 29.432 35.6701242298418 139.74156707585763 30.177 35.67017108319413 139.7415788748382 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f06476f-ba38-4a11-a1ad-b0aaeedf2d89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f06476f-ba38-4a11-a1ad-b0aaeedf2d89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f06476f-ba38-4a11-a1ad-b0aaeedf2d89">
											<gml:posList>35.67017108319413 139.7415788748382 30.177 35.670174772952485 139.74147659356058 30.177 35.670174772952485 139.74147659356058 29.432 35.67017108319413 139.7415788748382 29.432 35.67017108319413 139.7415788748382 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a294a77-5bf6-4cd8-b29e-6879f0855a02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a294a77-5bf6-4cd8-b29e-6879f0855a02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a294a77-5bf6-4cd8-b29e-6879f0855a02">
											<gml:posList>35.67017857134985 139.74144589173082 26.083 35.67017757382724 139.74147345322194 30.177 35.67017362811104 139.74158287066152 30.177 35.67017362811104 139.74158287066152 8.47 35.67017857134985 139.74144589173082 8.47 35.67017857134985 139.74144589173082 26.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-396d8bc7-d061-4871-b560-c28231f23166">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-396d8bc7-d061-4871-b560-c28231f23166">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-396d8bc7-d061-4871-b560-c28231f23166">
											<gml:posList>35.67011988439373 139.74156598725497 30.177 35.6700934670451 139.74155665029608 29.432 35.67011988439373 139.74156598725497 29.432 35.67011988439373 139.74156598725497 30.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73b1e62d-4798-4621-8b2c-9e92e9e2ca1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73b1e62d-4798-4621-8b2c-9e92e9e2ca1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73b1e62d-4798-4621-8b2c-9e92e9e2ca1a">
											<gml:posList>35.67012421215109 139.74156751772685 32.187 35.67009316950803 139.74155654017446 30.177 35.6700934670451 139.74155665029608 30.177 35.67012421215109 139.74156751772685 32.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47890a4b-141f-4c5d-8ba9-7b9474e13703">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47890a4b-141f-4c5d-8ba9-7b9474e13703">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47890a4b-141f-4c5d-8ba9-7b9474e13703">
											<gml:posList>35.67009336992313 139.7415593125463 29.432 35.67009336992313 139.7415593125463 30.177 35.67011988439373 139.74156598725497 30.177 35.67011988439373 139.74156598725497 29.432 35.67009336992313 139.7415593125463 29.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6594</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">108.4057</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>