<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_feadf359-384e-4551-8581-719d7772411a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">23.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67280761670792 139.73786831124795 0 35.672934979726776 139.7378102974371 0 35.672903981655786 139.73770826372373 0 35.67277445618229 139.73776727444482 0 35.67275303762546 139.73769671229132 0 35.67263860471383 139.73774887814596 0 35.67271821460108 139.73801121686247 0 35.672834810130254 139.73795805456356 0 35.67280761670792 139.73786831124795 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67280761670792 139.73786831124795 8.65 35.672834810130254 139.73795805456356 8.65 35.67271821460108 139.73801121686247 8.65 35.67263860471383 139.73774887814596 8.65 35.67275303762546 139.73769671229132 8.65 35.67277445618229 139.73776727444482 8.65 35.672903981655786 139.73770826372373 8.65 35.672934979726776 139.7378102974371 8.65 35.67280761670792 139.73786831124795 8.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67280761670792 139.73786831124795 8.65 35.672934979726776 139.7378102974371 8.65 35.672934979726776 139.7378102974371 31.86 35.67280761670792 139.73786831124795 31.86 35.67280761670792 139.73786831124795 8.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672934979726776 139.7378102974371 8.65 35.672903981655786 139.73770826372373 8.65 35.672903981655786 139.73770826372373 31.86 35.672934979726776 139.7378102974371 31.86 35.672934979726776 139.7378102974371 8.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672903981655786 139.73770826372373 8.65 35.67277445618229 139.73776727444482 8.65 35.67277445618229 139.73776727444482 31.86 35.672903981655786 139.73770826372373 31.86 35.672903981655786 139.73770826372373 8.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67277445618229 139.73776727444482 8.65 35.67275303762546 139.73769671229132 8.65 35.67275303762546 139.73769671229132 31.86 35.67277445618229 139.73776727444482 31.86 35.67277445618229 139.73776727444482 8.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67275303762546 139.73769671229132 8.65 35.67263860471383 139.73774887814596 8.65 35.67263860471383 139.73774887814596 31.86 35.67275303762546 139.73769671229132 31.86 35.67275303762546 139.73769671229132 8.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67263860471383 139.73774887814596 8.65 35.67271821460108 139.73801121686247 8.65 35.67271821460108 139.73801121686247 31.86 35.67263860471383 139.73774887814596 31.86 35.67263860471383 139.73774887814596 8.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67271821460108 139.73801121686247 8.65 35.672834810130254 139.73795805456356 8.65 35.672834810130254 139.73795805456356 31.86 35.67271821460108 139.73801121686247 31.86 35.67271821460108 139.73801121686247 8.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672834810130254 139.73795805456356 8.65 35.67280761670792 139.73786831124795 8.65 35.67280761670792 139.73786831124795 31.86 35.672834810130254 139.73795805456356 31.86 35.672834810130254 139.73795805456356 8.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67280761670792 139.73786831124795 31.86 35.672934979726776 139.7378102974371 31.86 35.672903981655786 139.73770826372373 31.86 35.67277445618229 139.73776727444482 31.86 35.67275303762546 139.73769671229132 31.86 35.67263860471383 139.73774887814596 31.86 35.67271821460108 139.73801121686247 31.86 35.672834810130254 139.73795805456356 31.86 35.67280761670792 139.73786831124795 31.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1dfcda5f-e135-4919-bb1d-0c7579b8afdd"/>
							<gml:surfaceMember xlink:href="#poly-2ca29c4c-afd9-4678-8c45-3aea688319a7"/>
							<gml:surfaceMember xlink:href="#poly-6c14ae21-6404-4be2-a350-c33630b48c71"/>
							<gml:surfaceMember xlink:href="#poly-bed05202-77db-40f5-b891-5199f0a26d42"/>
							<gml:surfaceMember xlink:href="#poly-70bb5638-debd-453d-a640-33ecddc45da2"/>
							<gml:surfaceMember xlink:href="#poly-de05eca9-f017-4974-8033-12e5f3980b22"/>
							<gml:surfaceMember xlink:href="#poly-a9a0625f-3903-4ba0-9753-85bc545ef2bb"/>
							<gml:surfaceMember xlink:href="#poly-85ae4413-0553-4bf6-92bf-e3c24364a645"/>
							<gml:surfaceMember xlink:href="#poly-50010846-4f83-44fe-8e4e-07f4c3489a89"/>
							<gml:surfaceMember xlink:href="#poly-0d7433a5-064c-4969-a68f-3a39b0a10d8e"/>
							<gml:surfaceMember xlink:href="#poly-7af1be6a-5fb4-4363-b36b-bf4205e63c73"/>
							<gml:surfaceMember xlink:href="#poly-cef68381-77d3-4a61-8c99-52ee412bf0ba"/>
							<gml:surfaceMember xlink:href="#poly-4901215e-545d-4f40-8828-1df1ba5fc95b"/>
							<gml:surfaceMember xlink:href="#poly-5c2ed10d-0807-465f-a21f-2ae8396cc2a2"/>
							<gml:surfaceMember xlink:href="#poly-9db627df-4e14-4380-915a-35b9a68fe0db"/>
							<gml:surfaceMember xlink:href="#poly-3dc11ad8-e0f6-41fa-82fd-bd22aa360d4b"/>
							<gml:surfaceMember xlink:href="#poly-faa02e85-09e1-4de0-87db-1dd73e3f920a"/>
							<gml:surfaceMember xlink:href="#poly-944e81fc-2121-458d-9f0d-3d1f84e892c4"/>
							<gml:surfaceMember xlink:href="#poly-c9a7c7e4-8a93-45d4-bf4e-feea109c3a26"/>
							<gml:surfaceMember xlink:href="#poly-b92f4600-f783-4871-974f-2d7ac2aca4dc"/>
							<gml:surfaceMember xlink:href="#poly-d690f2fa-142f-48b5-bc8d-4cbf296c94e8"/>
							<gml:surfaceMember xlink:href="#poly-7c167efc-240c-418e-b546-9cc5307602fb"/>
							<gml:surfaceMember xlink:href="#poly-316f7c33-b176-40ca-a952-707582fcab30"/>
							<gml:surfaceMember xlink:href="#poly-e466a470-ae53-4095-948c-629d58e2af0b"/>
							<gml:surfaceMember xlink:href="#poly-d47aaef9-6e17-4a42-9da0-6abf4f6af8d4"/>
							<gml:surfaceMember xlink:href="#poly-d64ae631-748a-44fa-846a-c2dd37483e6c"/>
							<gml:surfaceMember xlink:href="#poly-b91b8842-f1ac-4610-a6af-055e6833154d"/>
							<gml:surfaceMember xlink:href="#poly-c528404e-a3ac-49c8-b6c8-e00b43121241"/>
							<gml:surfaceMember xlink:href="#poly-3e910ae3-3e9e-4340-9ef4-6420f0178369"/>
							<gml:surfaceMember xlink:href="#poly-277a1afd-9dee-45e1-a3f4-005c54304dc6"/>
							<gml:surfaceMember xlink:href="#poly-15a91b7b-33dc-4761-8af0-2e56a71e5e97"/>
							<gml:surfaceMember xlink:href="#poly-f29c9d21-c1b4-4da8-bcae-b39829fbb68e"/>
							<gml:surfaceMember xlink:href="#poly-6bb77d15-4260-46dc-98c4-d9a550a6598d"/>
							<gml:surfaceMember xlink:href="#poly-245078d5-361a-4f5b-9fda-91ad66132eae"/>
							<gml:surfaceMember xlink:href="#poly-7ddc5270-f8a4-478c-872a-c990f9e44903"/>
							<gml:surfaceMember xlink:href="#poly-67655821-0930-4d8b-ada0-1a3aac26fffa"/>
							<gml:surfaceMember xlink:href="#poly-e5282e3a-b949-4b71-a06b-599d20599056"/>
							<gml:surfaceMember xlink:href="#poly-46419445-1471-4f2a-911c-c8d95bbc007c"/>
							<gml:surfaceMember xlink:href="#poly-368a04f9-7330-4750-a842-1e52c4679cb3"/>
							<gml:surfaceMember xlink:href="#poly-939d8b63-e250-4546-8c3f-de3e298ba988"/>
							<gml:surfaceMember xlink:href="#poly-f320a9e3-ae86-435e-b6a2-d4157c1858cc"/>
							<gml:surfaceMember xlink:href="#poly-c6f12668-07ab-4f54-9db2-01bb649abdd0"/>
							<gml:surfaceMember xlink:href="#poly-f4ca844e-6b0e-4f7e-8285-33e0b241801e"/>
							<gml:surfaceMember xlink:href="#poly-521235a2-9d76-4f24-81fc-527a7bdb3ee3"/>
							<gml:surfaceMember xlink:href="#poly-7377a98b-0300-4a41-bb29-85602ffe6d7e"/>
							<gml:surfaceMember xlink:href="#poly-9a705acb-9aa1-4c73-a89e-e6a6a4c7fe0a"/>
							<gml:surfaceMember xlink:href="#poly-4d6ef2f8-c22e-4eb7-aedf-63820501d464"/>
							<gml:surfaceMember xlink:href="#poly-41c2ff34-dbbe-428d-a9dd-1ab7952f9e19"/>
							<gml:surfaceMember xlink:href="#poly-f4c0595d-2a20-4736-8823-ed793b9be0b8"/>
							<gml:surfaceMember xlink:href="#poly-a3f700b2-df3a-4d1c-a426-e7729b8e1245"/>
							<gml:surfaceMember xlink:href="#poly-34e05aa5-9918-4a1d-b0e5-520544321a07"/>
							<gml:surfaceMember xlink:href="#poly-0e3278d1-c040-49ec-ba4f-fb7f4858b80d"/>
							<gml:surfaceMember xlink:href="#poly-4b52c701-1502-4e80-82b5-d557e7fb3f43"/>
							<gml:surfaceMember xlink:href="#poly-3ba405fc-a5f8-4436-bf39-b2a5d0f67c2a"/>
							<gml:surfaceMember xlink:href="#poly-e6f8b358-34ab-4f2f-a117-771dd67930f2"/>
							<gml:surfaceMember xlink:href="#poly-88926b53-8fb2-4fdb-b94c-53130abdfda7"/>
							<gml:surfaceMember xlink:href="#poly-e286c3ba-cf7b-4750-ab6a-ff4d766b1a84"/>
							<gml:surfaceMember xlink:href="#poly-faf5bffc-2e4c-4d08-9a39-05e2c865b9ee"/>
							<gml:surfaceMember xlink:href="#poly-8b18bfb1-840d-4d45-96c9-7e9ae724d002"/>
							<gml:surfaceMember xlink:href="#poly-16f7a020-6c10-45a8-b1b2-fa8cc256c773"/>
							<gml:surfaceMember xlink:href="#poly-fcdf436b-2177-46db-8749-de8588e11194"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_feadf359-384e-4551-8581-719d7772411a_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-248539ce-1011-41d3-bc52-d2f97c62766e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67274831684099 139.73769974468726 32.508 35.672749256706716 139.7377028145169 32.508 35.67273239812793 139.73771050095525 32.508 35.672731458253615 139.73770742007957 32.508 35.67274831684099 139.73769974468726 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db93d4c3-25ee-4c7b-9c84-106eeca06ad6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67288452112131 139.7377197422644 31.901 35.67288534352749 139.73772245874824 31.901 35.67284286818187 139.73774180781183 31.901 35.672842036762404 139.73773909133996 31.901 35.67288452112131 139.7377197422644 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-964f4459-6625-4dd1-a6b8-318f82938651">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67288943745987 139.73773595281696 30.407 35.67284696211211 139.7377553018744 30.407 35.67284286818187 139.73774180781183 30.407 35.67288534352749 139.73772245874824 30.407 35.67288943745987 139.73773595281696 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed4634ed-68e7-4804-8779-de89f4031147">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672757349683536 139.7377919508179 32.002 35.67273239812793 139.73771050095525 32.002 35.672749256706716 139.7377028145169 32.002 35.67277420826748 139.73778426439426 32.002 35.672757349683536 139.7377919508179 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e82f0f8-9fd1-4d76-98da-fea32f5cef0c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67284313512164 139.7377715007503 30.407 35.672866182989544 139.7377598522526 30.407 35.67287372724141 139.73778226786237 30.407 35.67285067035762 139.73779391636552 30.407 35.67284313512164 139.7377715007503 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dee36d78-1794-4ca0-8853-d2f064a1a398">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6726932211976 139.73783130887236 32.002 35.672672587369156 139.73784089978602 32.002 35.6726531942139 139.73777825568052 32.002 35.67267382802863 139.7377686537065 32.002 35.6726932211976 139.73783130887236 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3949c02c-97c9-48c2-ae0d-20dacc931b83">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67268240134648 139.73786114751755 32.002 35.67274972658675 139.73782920898935 32.002 35.6727572629596 139.7378530716854 32.002 35.67268993771306 139.73788501019658 32.002 35.67268240134648 139.73786114751755 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcae857d-f215-40bb-88cc-ae341e54aff9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcae857d-f215-40bb-88cc-ae341e54aff9_0">
											<gml:posList>35.67274831684099 139.73769974468726 32.508 35.672731458253615 139.73770742007957 32.508 35.672731458253615 139.73770742007957 33.932 35.67274831684099 139.73769974468726 33.932 35.67274831684099 139.73769974468726 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d991bc4c-620b-4dba-aaf6-661a047e6dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d991bc4c-620b-4dba-aaf6-661a047e6dc2_0">
											<gml:posList>35.67273239812793 139.73771050095525 32.508 35.672749256706716 139.7377028145169 32.508 35.672749256706716 139.7377028145169 32.002 35.67273239812793 139.73771050095525 32.002 35.67273239812793 139.73771050095525 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6952139-9f35-4a04-9ba5-fbf1b083d1b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6952139-9f35-4a04-9ba5-fbf1b083d1b2_0">
											<gml:posList>35.67288452112131 139.7377197422644 32.35 35.67288943745987 139.73773595281696 32.35 35.67288943745987 139.73773595281696 30.407 35.67288534352749 139.73772245874824 30.407 35.67288534352749 139.73772245874824 31.901 35.67288452112131 139.7377197422644 31.901 35.67288452112131 139.7377197422644 32.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb69ba75-2bc3-422b-b76a-3577a6575016">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb69ba75-2bc3-422b-b76a-3577a6575016_0">
											<gml:posList>35.67288452112131 139.7377197422644 31.901 35.672842036762404 139.73773909133996 31.901 35.672842036762404 139.73773909133996 32.35 35.67288452112131 139.7377197422644 32.35 35.67288452112131 139.7377197422644 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-375f43cf-6547-4b51-87c6-1dbd89824452">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-375f43cf-6547-4b51-87c6-1dbd89824452_0">
											<gml:posList>35.67288534352749 139.73772245874824 31.901 35.67288534352749 139.73772245874824 30.407 35.67284286818187 139.73774180781183 30.407 35.67284286818187 139.73774180781183 31.901 35.67288534352749 139.73772245874824 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02f578aa-b742-4f3c-af0b-52adf825d10f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02f578aa-b742-4f3c-af0b-52adf825d10f_0">
											<gml:posList>35.67288943745987 139.73773595281696 32.35 35.67288452112131 139.7377197422644 32.35 35.672842036762404 139.73773909133996 32.35 35.67284696211211 139.7377553018744 32.35 35.67288943745987 139.73773595281696 32.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6eb5e32b-833e-4bf9-8450-49453d3cec11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6eb5e32b-833e-4bf9-8450-49453d3cec11_0">
											<gml:posList>35.672749256706716 139.7377028145169 32.508 35.67274831684099 139.73769974468726 32.508 35.67274831684099 139.73769974468726 33.932 35.67277420826748 139.73778426439426 33.932 35.67277420826748 139.73778426439426 32.002 35.672749256706716 139.7377028145169 32.002 35.672749256706716 139.7377028145169 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2009aeec-2da8-4e5b-b4bc-afd82b03a1d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2009aeec-2da8-4e5b-b4bc-afd82b03a1d6_0">
											<gml:posList>35.67284696211211 139.7377553018744 30.407 35.67288943745987 139.73773595281696 30.407 35.67288943745987 139.73773595281696 32.35 35.67284696211211 139.7377553018744 32.35 35.67284696211211 139.7377553018744 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d7ae153-79dc-4aa2-8ed6-ba51dd38c1e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d7ae153-79dc-4aa2-8ed6-ba51dd38c1e0_0">
											<gml:posList>35.672757349683536 139.7377919508179 33.932 35.67277420826748 139.73778426439426 33.932 35.67274831684099 139.73769974468726 33.932 35.672731458253615 139.73770742007957 33.932 35.672757349683536 139.7377919508179 33.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-436d506b-8a94-4127-9b2a-f4f78c950f1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-436d506b-8a94-4127-9b2a-f4f78c950f1d_0">
											<gml:posList>35.67284696211211 139.7377553018744 30.407 35.67284696211211 139.7377553018744 32.35 35.672842036762404 139.73773909133996 32.35 35.672842036762404 139.73773909133996 31.901 35.67284286818187 139.73774180781183 31.901 35.67284286818187 139.73774180781183 30.407 35.67284696211211 139.7377553018744 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8f9c83b-df2d-4e2c-b9ca-7e745fd88b4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8f9c83b-df2d-4e2c-b9ca-7e745fd88b4a_0">
											<gml:posList>35.67273239812793 139.73771050095525 32.508 35.67273239812793 139.73771050095525 32.002 35.672757349683536 139.7377919508179 32.002 35.672757349683536 139.7377919508179 33.932 35.672731458253615 139.73770742007957 33.932 35.672731458253615 139.73770742007957 32.508 35.67273239812793 139.73771050095525 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1715ca37-5516-4d09-9bb8-c66b1521a873">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1715ca37-5516-4d09-9bb8-c66b1521a873_0">
											<gml:posList>35.67284313512164 139.7377715007503 30.407 35.67284313512164 139.7377715007503 33.226 35.672866182989544 139.7377598522526 33.226 35.672866182989544 139.7377598522526 30.407 35.67284313512164 139.7377715007503 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-814499a3-e7a9-4612-b01e-6d9ea2364ffa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-814499a3-e7a9-4612-b01e-6d9ea2364ffa_0">
											<gml:posList>35.67287372724141 139.73778226786237 30.407 35.672866182989544 139.7377598522526 30.407 35.672866182989544 139.7377598522526 33.226 35.67287372724141 139.73778226786237 33.226 35.67287372724141 139.73778226786237 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b6f9730-750a-4d3e-92c2-7dd6bc13d91e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b6f9730-750a-4d3e-92c2-7dd6bc13d91e_0">
											<gml:posList>35.6726531942139 139.73777825568052 32.002 35.6726531942139 139.73777825568052 34.377 35.67267382802863 139.7377686537065 34.377 35.67267382802863 139.7377686537065 32.002 35.6726531942139 139.73777825568052 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95bfa69f-3dae-432e-bf7b-87af94a3aa5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95bfa69f-3dae-432e-bf7b-87af94a3aa5c_0">
											<gml:posList>35.67287372724141 139.73778226786237 33.226 35.672866182989544 139.7377598522526 33.226 35.67284313512164 139.7377715007503 33.226 35.67285067035762 139.73779391636552 33.226 35.67287372724141 139.73778226786237 33.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2c4155b-6899-4534-897f-f6e1c65f3e64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2c4155b-6899-4534-897f-f6e1c65f3e64_0">
											<gml:posList>35.67285067035762 139.73779391636552 30.407 35.67285067035762 139.73779391636552 33.226 35.67284313512164 139.7377715007503 33.226 35.67284313512164 139.7377715007503 30.407 35.67285067035762 139.73779391636552 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a366c701-a73c-4340-b527-7b01132c2819">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a366c701-a73c-4340-b527-7b01132c2819_0">
											<gml:posList>35.672757349683536 139.7377919508179 32.002 35.67277420826748 139.73778426439426 32.002 35.67277420826748 139.73778426439426 33.932 35.672757349683536 139.7377919508179 33.932 35.672757349683536 139.7377919508179 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64653ab9-57ec-4315-9550-0a8716e30cd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64653ab9-57ec-4315-9550-0a8716e30cd4_0">
											<gml:posList>35.67285067035762 139.73779391636552 30.407 35.67287372724141 139.73778226786237 30.407 35.67287372724141 139.73778226786237 33.226 35.67285067035762 139.73779391636552 33.226 35.67285067035762 139.73779391636552 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77353253-e649-48c0-a68c-cc5796d3c912">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77353253-e649-48c0-a68c-cc5796d3c912_0">
											<gml:posList>35.67267382802863 139.7377686537065 32.002 35.67267382802863 139.7377686537065 34.377 35.6726932211976 139.73783130887236 34.377 35.6726932211976 139.73783130887236 32.002 35.67267382802863 139.7377686537065 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e749e6f0-04f0-45ca-a27f-ed0c22d9b7cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e749e6f0-04f0-45ca-a27f-ed0c22d9b7cd_0">
											<gml:posList>35.6726531942139 139.73777825568052 34.377 35.672672587369156 139.73784089978602 34.377 35.6726932211976 139.73783130887236 34.377 35.67267382802863 139.7377686537065 34.377 35.6726531942139 139.73777825568052 34.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72bc3411-1651-47cf-adbb-85fcd50fdbf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72bc3411-1651-47cf-adbb-85fcd50fdbf0_0">
											<gml:posList>35.6726531942139 139.73777825568052 32.002 35.672672587369156 139.73784089978602 32.002 35.672672587369156 139.73784089978602 34.377 35.6726531942139 139.73777825568052 34.377 35.6726531942139 139.73777825568052 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0810182-375e-41e5-86f1-223cd6e491bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0810182-375e-41e5-86f1-223cd6e491bd_0">
											<gml:posList>35.672672587369156 139.73784089978602 32.002 35.6726932211976 139.73783130887236 32.002 35.6726932211976 139.73783130887236 34.377 35.672672587369156 139.73784089978602 34.377 35.672672587369156 139.73784089978602 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42003546-0887-4c06-8723-bf688255f6c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42003546-0887-4c06-8723-bf688255f6c8_0">
											<gml:posList>35.6727572629596 139.7378530716854 32.002 35.67274972658675 139.73782920898935 32.002 35.67274972658675 139.73782920898935 34.827 35.6727572629596 139.7378530716854 34.827 35.6727572629596 139.7378530716854 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-701812b7-8913-43ca-8ead-b158cffc8d97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-701812b7-8913-43ca-8ead-b158cffc8d97_0">
											<gml:posList>35.67268240134648 139.73786114751755 34.827 35.67274972658675 139.73782920898935 34.827 35.67274972658675 139.73782920898935 32.002 35.67268240134648 139.73786114751755 32.002 35.67268240134648 139.73786114751755 34.827</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd8447d9-1a4e-4b4e-aa78-be14f9aeeef2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd8447d9-1a4e-4b4e-aa78-be14f9aeeef2_0">
											<gml:posList>35.6727572629596 139.7378530716854 34.827 35.67274972658675 139.73782920898935 34.827 35.67268240134648 139.73786114751755 34.827 35.67268993771306 139.73788501019658 34.827 35.6727572629596 139.7378530716854 34.827</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59fac28b-efea-4503-b924-f438fc852f14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59fac28b-efea-4503-b924-f438fc852f14_0">
											<gml:posList>35.6727572629596 139.7378530716854 32.002 35.6727572629596 139.7378530716854 34.827 35.67268993771306 139.73788501019658 34.827 35.67268993771306 139.73788501019658 32.002 35.6727572629596 139.7378530716854 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-128c747a-1582-4238-9319-c821bbba0de1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-128c747a-1582-4238-9319-c821bbba0de1_0">
											<gml:posList>35.67268240134648 139.73786114751755 32.002 35.67268993771306 139.73788501019658 32.002 35.67268993771306 139.73788501019658 34.827 35.67268240134648 139.73786114751755 34.827 35.67268240134648 139.73786114751755 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_feadf359-384e-4551-8581-719d7772411a_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-155b4738-588e-40be-bc0b-8c9fc56a7d2d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67279676266421 139.73782093429244 30.407 35.67280792629746 139.73781541978877 30.407 35.672812597684484 139.73782965328317 30.407 35.67280142502811 139.73783515674933 30.407 35.67279676266421 139.73782093429244 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad9e3f69-4100-4f4b-9b1a-d9a3ebae77a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad9e3f69-4100-4f4b-9b1a-d9a3ebae77a8_0">
											<gml:posList>35.67279676266421 139.73782093429244 30.885 35.67279676266421 139.73782093429244 30.407 35.67280142502811 139.73783515674933 30.407 35.67280142502811 139.73783515674933 30.885 35.67279676266421 139.73782093429244 30.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22f985b1-f6c2-413d-9e0f-8e517a2dc2ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22f985b1-f6c2-413d-9e0f-8e517a2dc2ca_0">
											<gml:posList>35.67279676266421 139.73782093429244 30.407 35.67279676266421 139.73782093429244 30.885 35.67280792629746 139.73781541978877 30.885 35.67280792629746 139.73781541978877 30.407 35.67279676266421 139.73782093429244 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3cc83c7-e0b3-427f-afaa-bfcf90176108">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3cc83c7-e0b3-427f-afaa-bfcf90176108_0">
											<gml:posList>35.672812597684484 139.73782965328317 30.885 35.67280792629746 139.73781541978877 30.885 35.67279676266421 139.73782093429244 30.885 35.67280142502811 139.73783515674933 30.885 35.672812597684484 139.73782965328317 30.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3bead4f-8ede-4c6b-aa95-427e7af72aaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3bead4f-8ede-4c6b-aa95-427e7af72aaf_0">
											<gml:posList>35.672812597684484 139.73782965328317 30.407 35.672812597684484 139.73782965328317 30.885 35.67280142502811 139.73783515674933 30.885 35.67280142502811 139.73783515674933 30.407 35.672812597684484 139.73782965328317 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a68aad7-b996-4e85-a0b1-038bef84dc59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a68aad7-b996-4e85-a0b1-038bef84dc59_0">
											<gml:posList>35.67280792629746 139.73781541978877 30.885 35.672812597684484 139.73782965328317 30.885 35.672812597684484 139.73782965328317 30.407 35.67280792629746 139.73781541978877 30.407 35.67280792629746 139.73781541978877 30.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_feadf359-384e-4551-8581-719d7772411a_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-baa747ed-2979-41d8-8c94-efd3c0cd0232">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67272362681017 139.73772064113288 32.002 35.67273257236124 139.7377483021554 32.002 35.67271162352415 139.73775847893944 32.002 35.67270267795786 139.7377307958299 32.002 35.67272362681017 139.73772064113288 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49286b03-d9f7-42a8-87cc-a6acee02522b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67272670991978 139.73775522430563 32.002 35.67274187453622 139.73774831315785 32.002 35.67274491109003 139.73775831774344 32.002 35.67272974647301 139.7377652288896 32.002 35.67272670991978 139.73775522430563 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a7ed947-471c-4874-be31-c4ee53383ba9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67269698328085 139.73776737784175 32.002 35.672689766053985 139.73777086611676 32.002 35.67268651307552 139.73776074028322 32.002 35.67269372128839 139.73775725201816 32.002 35.67269698328085 139.73776737784175 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80acc75e-ce2d-4165-b710-2553c68d6570">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672710503024405 139.73777766818512 32.002 35.67270687054976 139.7377663829102 32.002 35.6727122947304 139.73776375840475 32.002 35.672715927205275 139.73777504368033 32.002 35.672710503024405 139.73777766818512 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94cb895a-78cf-4eab-acfc-77a751d8038b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672725907530676 139.73777772715053 32.002 35.6727238111844 139.73777122321232 32.002 35.67273518214856 139.7377657305528 32.002 35.67273727848636 139.7377722234452 32.002 35.672725907530676 139.73777772715053 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41925b2d-eb1a-4d28-bdac-cef5e923dcc5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672749793580785 139.73780003487684 32.002 35.672742891728 139.7378033902164 32.002 35.67273829247389 139.7377891897897 32.002 35.67274519431752 139.7377858234025 32.002 35.672749793580785 139.73780003487684 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24c6b01b-9474-4390-ad0c-bc338db25c7c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67270514531084 139.73781862424124 32.002 35.67269283828385 139.73778039565136 32.002 35.672700046497276 139.7377769073878 32.002 35.67271235352537 139.73781513598055 32.002 35.67270514531084 139.73781862424124 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eb3fc80-da6e-433b-af99-b20f08fc9279">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67273897226788 139.73780529489926 32.002 35.67273269211612 139.73780834019286 32.002 35.67272809286259 139.73779413976766 32.002 35.67273437300521 139.73779108342657 32.002 35.67273897226788 139.73780529489926 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e14d494a-2393-4af7-b011-f2a4b255d1ae">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672905100815356 139.737800943422 30.407 35.67290792884863 139.73780943489317 30.407 35.6728941793478 139.73781630017137 30.407 35.67289136032874 139.73780780869066 30.407 35.672905100815356 139.737800943422 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdd515d6-416e-4154-a3fc-c3827a5ae94a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67277155631178 139.73781592707803 32.002 35.67276865589751 139.73780709326303 32.002 35.67277962132477 139.7378017005081 32.002 35.67278252173065 139.7378105232775 32.002 35.67277155631178 139.73781592707803 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69bad582-f52c-4385-b863-72ed2bf1af15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67289148531512 139.73781765106696 30.407 35.67288332211101 139.737821725943 30.407 35.67288050309233 139.73781323446323 30.407 35.67288865728243 139.73780915959722 30.407 35.67289148531512 139.73781765106696 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df5c5622-5f63-493a-ad80-28a5e5622dd0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67277510975856 139.7378184966996 32.002 35.67277860651434 139.73782914144599 32.002 35.672771803811685 139.73783249666616 32.002 35.672768307047434 139.73782184087398 32.002 35.67277510975856 139.7378184966996 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ceb27de-6622-4825-9a3b-47ecb9143843">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67281007204908 139.7378614925757 30.407 35.672804388685265 139.73784417828568 30.407 35.67281557048717 139.7378388405086 30.407 35.67282138920641 139.73785634243157 30.407 35.67281007204908 139.7378614925757 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4c6485e-5789-4d80-b2c6-ea464a2f101b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67280776881131 139.73786688605622 31.901 35.67280095574632 139.7378458062237 31.901 35.672804388685265 139.73784417828568 31.901 35.67281007204908 139.7378614925757 31.901 35.67282138920641 139.73785634243157 31.901 35.67282272641627 139.73786035075332 31.901 35.67280776881131 139.73786688605622 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01b9d740-6b17-4137-bf08-6409e027b3e0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6727863286112 139.7378939867809 34.931 35.672782154553786 139.7378817300349 34.931 35.672790795206915 139.73787730111073 34.931 35.67279497828726 139.73788956889368 34.931 35.6727863286112 139.7378939867809 34.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-773a9983-60a8-4877-bea2-f588c970fdf7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67271998299382 139.73788820002753 32.002 35.67272678571561 139.7378848669074 32.002 35.67273780933887 139.73791877784254 32.002 35.672731006607385 139.73792209991367 32.002 35.67271998299382 139.73788820002753 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e51c690-74b4-43ee-860b-52810b6794df">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67278601560402 139.73790848028048 34.931 35.67280578511859 139.73790014971107 34.931 35.67281207642879 139.73792255576177 34.931 35.67279230692143 139.73793089737288 34.931 35.67278601560402 139.73790848028048 34.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ec44e45-1dd1-4293-a5a2-29e4203f0c51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67272291945667 139.73793115668886 32.002 35.67274205737375 139.73792202048264 32.002 35.67275080447177 139.73794954921107 32.002 35.6727316665526 139.73795868541174 32.002 35.67272291945667 139.73793115668886 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0199556c-feb7-4706-b5e8-3dc86b101bed">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67272894004813 139.73797594341767 32.002 35.67271340647714 139.73798363926736 32.002 35.672694907067296 139.7379226510184 32.002 35.67270904405078 139.73791564170887 32.002 35.67272894004813 139.73797594341767 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6de5f406-5cd1-48a0-a768-17bab008652d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67271340647714 139.73798363926736 32.508 35.67271303706338 139.73798382749857 32.508 35.67269314106995 139.73792352579977 32.508 35.672694907067296 139.7379226510184 32.508 35.67271340647714 139.73798363926736 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31301387-05e5-4bfc-8fca-3912c151a305">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31301387-05e5-4bfc-8fca-3912c151a305_0">
											<gml:posList>35.67273897226788 139.73780529489926 32.002 35.67273437300521 139.73779108342657 32.002 35.67273437300521 139.73779108342657 34.514 35.67273897226788 139.73780529489926 34.514 35.67273897226788 139.73780529489926 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5a42131-f1d5-491c-870b-40022742db52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5a42131-f1d5-491c-870b-40022742db52_0">
											<gml:posList>35.672731006607385 139.73792209991367 32.002 35.67273780933887 139.73791877784254 32.002 35.67273780933887 139.73791877784254 34.273 35.672731006607385 139.73792209991367 34.273 35.672731006607385 139.73792209991367 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d553c45-305f-4ae3-a17f-adbafe7df6dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d553c45-305f-4ae3-a17f-adbafe7df6dc_0">
											<gml:posList>35.67269314106995 139.73792352579977 32.508 35.67271303706338 139.73798382749857 32.508 35.67271303706338 139.73798382749857 33.783 35.67269314106995 139.73792352579977 33.783 35.67269314106995 139.73792352579977 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3387096-6419-4c0b-980e-30e31b43f432">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3387096-6419-4c0b-980e-30e31b43f432_0">
											<gml:posList>35.672694907067296 139.7379226510184 32.002 35.67271340647714 139.73798363926736 32.002 35.67271340647714 139.73798363926736 32.508 35.672694907067296 139.7379226510184 32.508 35.672694907067296 139.7379226510184 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2c821df-8a4f-47a2-b0fe-ab3c805f3e29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2c821df-8a4f-47a2-b0fe-ab3c805f3e29_0">
											<gml:posList>35.67271303706338 139.73798382749857 33.783 35.67272894004813 139.73797594341767 33.783 35.67270904405078 139.73791564170887 33.783 35.67269314106995 139.73792352579977 33.783 35.67271303706338 139.73798382749857 33.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae2cae22-33dd-4c70-8c94-9389ae7cccd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae2cae22-33dd-4c70-8c94-9389ae7cccd7_0">
											<gml:posList>35.67272894004813 139.73797594341767 32.002 35.67270904405078 139.73791564170887 32.002 35.67270904405078 139.73791564170887 33.783 35.67272894004813 139.73797594341767 33.783 35.67272894004813 139.73797594341767 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16c8f121-023b-407e-b2fb-abfb0c50f3f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16c8f121-023b-407e-b2fb-abfb0c50f3f4_0">
											<gml:posList>35.67272894004813 139.73797594341767 32.002 35.67272894004813 139.73797594341767 33.783 35.67271303706338 139.73798382749857 33.783 35.67271303706338 139.73798382749857 32.508 35.67271340647714 139.73798363926736 32.508 35.67271340647714 139.73798363926736 32.002 35.67272894004813 139.73797594341767 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42c6409a-e1fa-445e-90d6-098b9dd56a82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42c6409a-e1fa-445e-90d6-098b9dd56a82_0">
											<gml:posList>35.67272291945667 139.73793115668886 32.002 35.6727316665526 139.73795868541174 32.002 35.6727316665526 139.73795868541174 34.854 35.67272291945667 139.73793115668886 34.854 35.67272291945667 139.73793115668886 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8e6235e-034b-4fbd-ab52-870970f9302d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8e6235e-034b-4fbd-ab52-870970f9302d_0">
											<gml:posList>35.67272291945667 139.73793115668886 34.854 35.6727316665526 139.73795868541174 34.854 35.67275080447177 139.73794954921107 34.854 35.67274205737375 139.73792202048264 34.854 35.67272291945667 139.73793115668886 34.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfdb5c30-3d74-4427-9c20-45ccc39b735d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfdb5c30-3d74-4427-9c20-45ccc39b735d_0">
											<gml:posList>35.6727316665526 139.73795868541174 32.002 35.67275080447177 139.73794954921107 32.002 35.67275080447177 139.73794954921107 34.854 35.6727316665526 139.73795868541174 34.854 35.6727316665526 139.73795868541174 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea6f71b6-5462-42d4-ad20-5c9983626006">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea6f71b6-5462-42d4-ad20-5c9983626006_0">
											<gml:posList>35.67275080447177 139.73794954921107 32.002 35.67274205737375 139.73792202048264 32.002 35.67274205737375 139.73792202048264 34.854 35.67275080447177 139.73794954921107 34.854 35.67275080447177 139.73794954921107 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa127a85-8686-4cc2-b8c7-79ffe5aa2ecd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa127a85-8686-4cc2-b8c7-79ffe5aa2ecd_0">
											<gml:posList>35.67272362681017 139.73772064113288 32.002 35.67270267795786 139.7377307958299 32.002 35.67270267795786 139.7377307958299 34.094 35.67272362681017 139.73772064113288 34.094 35.67272362681017 139.73772064113288 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11642c77-710d-4224-b2ae-edaf15f89a27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11642c77-710d-4224-b2ae-edaf15f89a27_0">
											<gml:posList>35.67273257236124 139.7377483021554 32.002 35.67272362681017 139.73772064113288 32.002 35.67272362681017 139.73772064113288 34.094 35.67273257236124 139.7377483021554 34.094 35.67273257236124 139.7377483021554 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b60eaad-0fcd-4f7a-84bd-7dad0219da51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b60eaad-0fcd-4f7a-84bd-7dad0219da51_0">
											<gml:posList>35.67271162352415 139.73775847893944 34.094 35.67273257236124 139.7377483021554 34.094 35.67272362681017 139.73772064113288 34.094 35.67270267795786 139.7377307958299 34.094 35.67271162352415 139.73775847893944 34.094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25cb063c-884c-4490-8e28-714177e0ac9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25cb063c-884c-4490-8e28-714177e0ac9b_0">
											<gml:posList>35.67270267795786 139.7377307958299 32.002 35.67271162352415 139.73775847893944 32.002 35.67271162352415 139.73775847893944 34.094 35.67270267795786 139.7377307958299 34.094 35.67270267795786 139.7377307958299 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ec90f4b-b4bb-404a-9c9d-494fea23ab0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ec90f4b-b4bb-404a-9c9d-494fea23ab0a_0">
											<gml:posList>35.67274187453622 139.73774831315785 32.002 35.67272670991978 139.73775522430563 32.002 35.67272670991978 139.73775522430563 33.759 35.67274187453622 139.73774831315785 33.759 35.67274187453622 139.73774831315785 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a784f54-47cf-4925-9de2-518ae77cceab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a784f54-47cf-4925-9de2-518ae77cceab_0">
											<gml:posList>35.67274187453622 139.73774831315785 32.002 35.67274187453622 139.73774831315785 33.759 35.67274491109003 139.73775831774344 33.759 35.67274491109003 139.73775831774344 32.002 35.67274187453622 139.73774831315785 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8eff178b-fc85-4108-9363-577cf50205d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8eff178b-fc85-4108-9363-577cf50205d1_0">
											<gml:posList>35.67271162352415 139.73775847893944 32.002 35.67273257236124 139.7377483021554 32.002 35.67273257236124 139.7377483021554 34.094 35.67271162352415 139.73775847893944 34.094 35.67271162352415 139.73775847893944 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c51e79d-99a3-4f66-a176-8e9929afe212">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c51e79d-99a3-4f66-a176-8e9929afe212_0">
											<gml:posList>35.67272670991978 139.73775522430563 33.759 35.67272974647301 139.7377652288896 33.759 35.67274491109003 139.73775831774344 33.759 35.67274187453622 139.73774831315785 33.759 35.67272670991978 139.73775522430563 33.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10ecba5a-cd96-463a-8eb6-ffb658f37e9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10ecba5a-cd96-463a-8eb6-ffb658f37e9b_0">
											<gml:posList>35.67268651307552 139.73776074028322 32.002 35.67268651307552 139.73776074028322 33.958 35.67269372128839 139.73775725201816 33.958 35.67269372128839 139.73775725201816 32.002 35.67268651307552 139.73776074028322 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb9fffd5-b11e-4337-b523-2329c4155e19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb9fffd5-b11e-4337-b523-2329c4155e19_0">
											<gml:posList>35.67272974647301 139.7377652288896 33.759 35.67272670991978 139.73775522430563 33.759 35.67272670991978 139.73775522430563 32.002 35.67272974647301 139.7377652288896 32.002 35.67272974647301 139.7377652288896 33.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a8651ea-bdd1-4f5e-81fc-8a4a78e06b28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a8651ea-bdd1-4f5e-81fc-8a4a78e06b28_0">
											<gml:posList>35.67272974647301 139.7377652288896 32.002 35.67274491109003 139.73775831774344 32.002 35.67274491109003 139.73775831774344 33.759 35.67272974647301 139.7377652288896 33.759 35.67272974647301 139.7377652288896 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-382aab27-032b-4f4e-8be0-3cab61b76ebf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-382aab27-032b-4f4e-8be0-3cab61b76ebf_0">
											<gml:posList>35.67269698328085 139.73776737784175 32.002 35.67269372128839 139.73775725201816 32.002 35.67269372128839 139.73775725201816 33.958 35.67269698328085 139.73776737784175 33.958 35.67269698328085 139.73776737784175 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a49190e-c741-481c-8c50-e52b55eee68b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a49190e-c741-481c-8c50-e52b55eee68b_0">
											<gml:posList>35.67269698328085 139.73776737784175 33.958 35.67269372128839 139.73775725201816 33.958 35.67268651307552 139.73776074028322 33.958 35.672689766053985 139.73777086611676 33.958 35.67269698328085 139.73776737784175 33.958</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24395a08-637c-47c7-80af-6ee1bbb95ee9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24395a08-637c-47c7-80af-6ee1bbb95ee9_0">
											<gml:posList>35.6727122947304 139.73776375840475 32.002 35.67270687054976 139.7377663829102 32.002 35.67270687054976 139.7377663829102 33.916 35.6727122947304 139.73776375840475 33.916 35.6727122947304 139.73776375840475 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5dc83a9-0ee2-4e09-b5f3-35e3ee468b32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5dc83a9-0ee2-4e09-b5f3-35e3ee468b32_0">
											<gml:posList>35.67268651307552 139.73776074028322 32.002 35.672689766053985 139.73777086611676 32.002 35.672689766053985 139.73777086611676 33.958 35.67268651307552 139.73776074028322 33.958 35.67268651307552 139.73776074028322 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b3ad419-4032-4c25-b865-44cb163305d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b3ad419-4032-4c25-b865-44cb163305d2_0">
											<gml:posList>35.6727238111844 139.73777122321232 32.002 35.6727238111844 139.73777122321232 33.916 35.67273518214856 139.7377657305528 33.916 35.67273518214856 139.7377657305528 32.002 35.6727238111844 139.73777122321232 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70f7820e-1bc1-4420-bdd1-d71f7dd25e7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70f7820e-1bc1-4420-bdd1-d71f7dd25e7f_0">
											<gml:posList>35.67273727848636 139.7377722234452 32.002 35.67273518214856 139.7377657305528 32.002 35.67273518214856 139.7377657305528 33.916 35.67273727848636 139.7377722234452 33.916 35.67273727848636 139.7377722234452 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b008e4a-419d-46a9-a00d-8bf9164c7567">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b008e4a-419d-46a9-a00d-8bf9164c7567_0">
											<gml:posList>35.672689766053985 139.73777086611676 32.002 35.67269698328085 139.73776737784175 32.002 35.67269698328085 139.73776737784175 33.958 35.672689766053985 139.73777086611676 33.958 35.672689766053985 139.73777086611676 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab446edd-9aa5-476e-a5d3-be310e0c5bf3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab446edd-9aa5-476e-a5d3-be310e0c5bf3_0">
											<gml:posList>35.672715927205275 139.73777504368033 32.002 35.6727122947304 139.73776375840475 32.002 35.6727122947304 139.73776375840475 33.916 35.672715927205275 139.73777504368033 33.916 35.672715927205275 139.73777504368033 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff837186-6532-4bfd-b0f3-74ea5667aa5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff837186-6532-4bfd-b0f3-74ea5667aa5d_0">
											<gml:posList>35.6727122947304 139.73776375840475 33.916 35.67270687054976 139.7377663829102 33.916 35.672710503024405 139.73777766818512 33.916 35.672715927205275 139.73777504368033 33.916 35.6727122947304 139.73776375840475 33.916</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8361a5b4-d43c-4081-abd8-191a41938570">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8361a5b4-d43c-4081-abd8-191a41938570_0">
											<gml:posList>35.67273518214856 139.7377657305528 33.916 35.6727238111844 139.73777122321232 33.916 35.672725907530676 139.73777772715053 33.916 35.67273727848636 139.7377722234452 33.916 35.67273518214856 139.7377657305528 33.916</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7d23e1a-e759-451d-b814-9ab2b41a9286">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7d23e1a-e759-451d-b814-9ab2b41a9286_0">
											<gml:posList>35.67270687054976 139.7377663829102 32.002 35.672710503024405 139.73777766818512 32.002 35.672710503024405 139.73777766818512 33.916 35.67270687054976 139.7377663829102 33.916 35.67270687054976 139.7377663829102 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1795fe6-042a-4433-9e00-16b963412d34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1795fe6-042a-4433-9e00-16b963412d34_0">
											<gml:posList>35.6727238111844 139.73777122321232 32.002 35.672725907530676 139.73777772715053 32.002 35.672725907530676 139.73777772715053 33.916 35.6727238111844 139.73777122321232 33.916 35.6727238111844 139.73777122321232 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02d3e8f8-81d7-46fe-9be4-23702c13576e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02d3e8f8-81d7-46fe-9be4-23702c13576e_0">
											<gml:posList>35.672725907530676 139.73777772715053 32.002 35.67273727848636 139.7377722234452 32.002 35.67273727848636 139.7377722234452 33.916 35.672725907530676 139.73777772715053 33.916 35.672725907530676 139.73777772715053 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-940e56a4-0288-47d6-bef0-4d2076032fa6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-940e56a4-0288-47d6-bef0-4d2076032fa6_0">
											<gml:posList>35.672710503024405 139.73777766818512 32.002 35.672715927205275 139.73777504368033 32.002 35.672715927205275 139.73777504368033 33.916 35.672710503024405 139.73777766818512 33.916 35.672710503024405 139.73777766818512 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98e91e98-2125-452e-a605-5ccced10c35b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98e91e98-2125-452e-a605-5ccced10c35b_0">
											<gml:posList>35.672700046497276 139.7377769073878 32.002 35.67269283828385 139.73778039565136 32.002 35.67269283828385 139.73778039565136 34.066 35.672700046497276 139.7377769073878 34.066 35.672700046497276 139.7377769073878 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b81919f-85d7-48a2-a6b9-886b835ea953">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b81919f-85d7-48a2-a6b9-886b835ea953_0">
											<gml:posList>35.67274519431752 139.7377858234025 32.002 35.67273829247389 139.7377891897897 32.002 35.67273829247389 139.7377891897897 34.666 35.67274519431752 139.7377858234025 34.666 35.67274519431752 139.7377858234025 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bccaf539-9b9b-4154-bc42-f075d7ab1fad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bccaf539-9b9b-4154-bc42-f075d7ab1fad_0">
											<gml:posList>35.67273437300521 139.73779108342657 32.002 35.67272809286259 139.73779413976766 32.002 35.67272809286259 139.73779413976766 34.514 35.67273437300521 139.73779108342657 34.514 35.67273437300521 139.73779108342657 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e85f509-e752-487d-b69e-5e21d627ceda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e85f509-e752-487d-b69e-5e21d627ceda_0">
											<gml:posList>35.672749793580785 139.73780003487684 32.002 35.67274519431752 139.7377858234025 32.002 35.67274519431752 139.7377858234025 34.666 35.672749793580785 139.73780003487684 34.666 35.672749793580785 139.73780003487684 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3744f7de-2adb-49a3-a45a-c9a928229fb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3744f7de-2adb-49a3-a45a-c9a928229fb2_0">
											<gml:posList>35.67273829247389 139.7377891897897 34.666 35.672742891728 139.7378033902164 34.666 35.672749793580785 139.73780003487684 34.666 35.67274519431752 139.7377858234025 34.666 35.67273829247389 139.7377891897897 34.666</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d127ffd4-375f-4562-ab5e-2fc11f803d2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d127ffd4-375f-4562-ab5e-2fc11f803d2d_0">
											<gml:posList>35.67271235352537 139.73781513598055 32.002 35.672700046497276 139.7377769073878 32.002 35.672700046497276 139.7377769073878 34.066 35.67271235352537 139.73781513598055 34.066 35.67271235352537 139.73781513598055 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4adfe6b-8f86-4042-a9e8-4169fc72d6d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4adfe6b-8f86-4042-a9e8-4169fc72d6d2_0">
											<gml:posList>35.67273829247389 139.7377891897897 32.002 35.672742891728 139.7378033902164 32.002 35.672742891728 139.7378033902164 34.666 35.67273829247389 139.7377891897897 34.666 35.67273829247389 139.7377891897897 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84351b40-3afa-4b56-afd6-44a8617f8c08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84351b40-3afa-4b56-afd6-44a8617f8c08_0">
											<gml:posList>35.67270514531084 139.73781862424124 34.066 35.67271235352537 139.73781513598055 34.066 35.672700046497276 139.7377769073878 34.066 35.67269283828385 139.73778039565136 34.066 35.67270514531084 139.73781862424124 34.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec203983-9bc1-410e-91a6-8d5d2d3a5ad1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec203983-9bc1-410e-91a6-8d5d2d3a5ad1_0">
											<gml:posList>35.67270514531084 139.73781862424124 32.002 35.67270514531084 139.73781862424124 34.066 35.67269283828385 139.73778039565136 34.066 35.67269283828385 139.73778039565136 32.002 35.67270514531084 139.73781862424124 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ab1f98c-5e81-42f6-9c05-37467d1dd010">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ab1f98c-5e81-42f6-9c05-37467d1dd010_0">
											<gml:posList>35.67272809286259 139.73779413976766 34.514 35.67273269211612 139.73780834019286 34.514 35.67273897226788 139.73780529489926 34.514 35.67273437300521 139.73779108342657 34.514 35.67272809286259 139.73779413976766 34.514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-933e389e-1b88-4d37-94ce-bdc98ce0719f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-933e389e-1b88-4d37-94ce-bdc98ce0719f_0">
											<gml:posList>35.67272809286259 139.73779413976766 32.002 35.67273269211612 139.73780834019286 32.002 35.67273269211612 139.73780834019286 34.514 35.67272809286259 139.73779413976766 34.514 35.67272809286259 139.73779413976766 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4fe8802-8ef1-4424-8b43-e58953cb1501">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4fe8802-8ef1-4424-8b43-e58953cb1501_0">
											<gml:posList>35.672742891728 139.7378033902164 32.002 35.672749793580785 139.73780003487684 32.002 35.672749793580785 139.73780003487684 34.666 35.672742891728 139.7378033902164 34.666 35.672742891728 139.7378033902164 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4df55335-7b6b-4aa1-baae-aad7b0d0b0b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4df55335-7b6b-4aa1-baae-aad7b0d0b0b2_0">
											<gml:posList>35.67276865589751 139.73780709326303 32.002 35.67276865589751 139.73780709326303 33.784 35.67277962132477 139.7378017005081 33.784 35.67277962132477 139.7378017005081 32.002 35.67276865589751 139.73780709326303 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ac5ce0e-1b39-4ce2-8546-02bb829b5d34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ac5ce0e-1b39-4ce2-8546-02bb829b5d34_0">
											<gml:posList>35.672905100815356 139.737800943422 30.407 35.67289136032874 139.73780780869066 30.407 35.67289136032874 139.73780780869066 32.05 35.672905100815356 139.737800943422 32.05 35.672905100815356 139.737800943422 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81e7b57d-6ca4-4642-888b-5e0c200c98ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81e7b57d-6ca4-4642-888b-5e0c200c98ca_0">
											<gml:posList>35.67290792884863 139.73780943489317 30.407 35.672905100815356 139.737800943422 30.407 35.672905100815356 139.737800943422 32.05 35.67290792884863 139.73780943489317 32.05 35.67290792884863 139.73780943489317 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-951bc041-063d-4931-a61f-51500b0fe301">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-951bc041-063d-4931-a61f-51500b0fe301_0">
											<gml:posList>35.67278252173065 139.7378105232775 32.002 35.67277962132477 139.7378017005081 32.002 35.67277962132477 139.7378017005081 33.784 35.67278252173065 139.7378105232775 33.784 35.67278252173065 139.7378105232775 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0692cfd-e94b-4231-9231-99474b08d842">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0692cfd-e94b-4231-9231-99474b08d842_0">
											<gml:posList>35.67273269211612 139.73780834019286 32.002 35.67273897226788 139.73780529489926 32.002 35.67273897226788 139.73780529489926 34.514 35.67273269211612 139.73780834019286 34.514 35.67273269211612 139.73780834019286 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00ba95b3-b71a-49ac-afae-be8d242537f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00ba95b3-b71a-49ac-afae-be8d242537f8_0">
											<gml:posList>35.6728941793478 139.73781630017137 32.05 35.67290792884863 139.73780943489317 32.05 35.672905100815356 139.737800943422 32.05 35.67289136032874 139.73780780869066 32.05 35.6728941793478 139.73781630017137 32.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d342778-087a-4dbb-a961-60704ba0b619">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d342778-087a-4dbb-a961-60704ba0b619_0">
											<gml:posList>35.67277962132477 139.7378017005081 33.784 35.67276865589751 139.73780709326303 33.784 35.67277155631178 139.73781592707803 33.784 35.67278252173065 139.7378105232775 33.784 35.67277962132477 139.7378017005081 33.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9a7f1af-315c-4859-98c4-13d7b1da3cfd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9a7f1af-315c-4859-98c4-13d7b1da3cfd_0">
											<gml:posList>35.67288865728243 139.73780915959722 30.407 35.67288050309233 139.73781323446323 30.407 35.67288050309233 139.73781323446323 32.05 35.67288865728243 139.73780915959722 32.05 35.67288865728243 139.73780915959722 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d7a73de-e427-4003-b18b-d3151ac7b73e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d7a73de-e427-4003-b18b-d3151ac7b73e_0">
											<gml:posList>35.67276865589751 139.73780709326303 32.002 35.67277155631178 139.73781592707803 32.002 35.67277155631178 139.73781592707803 33.784 35.67276865589751 139.73780709326303 33.784 35.67276865589751 139.73780709326303 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-053199a7-5f55-4bc0-b4e3-d149db565345">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-053199a7-5f55-4bc0-b4e3-d149db565345_0">
											<gml:posList>35.6728941793478 139.73781630017137 30.407 35.6728941793478 139.73781630017137 32.05 35.67289136032874 139.73780780869066 32.05 35.67289136032874 139.73780780869066 30.407 35.6728941793478 139.73781630017137 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10a40afd-c17f-48c9-b765-01f32d7761d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10a40afd-c17f-48c9-b765-01f32d7761d7_0">
											<gml:posList>35.6728941793478 139.73781630017137 30.407 35.67290792884863 139.73780943489317 30.407 35.67290792884863 139.73780943489317 32.05 35.6728941793478 139.73781630017137 32.05 35.6728941793478 139.73781630017137 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ee0f92d-c743-4d90-bbd2-cf770ceabfff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ee0f92d-c743-4d90-bbd2-cf770ceabfff_0">
											<gml:posList>35.67277155631178 139.73781592707803 32.002 35.67278252173065 139.7378105232775 32.002 35.67278252173065 139.7378105232775 33.784 35.67277155631178 139.73781592707803 33.784 35.67277155631178 139.73781592707803 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f740be33-6ffa-453a-826f-126a868a463e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f740be33-6ffa-453a-826f-126a868a463e_0">
											<gml:posList>35.67288865728243 139.73780915959722 30.407 35.67288865728243 139.73780915959722 32.05 35.67289148531512 139.73781765106696 32.05 35.67289148531512 139.73781765106696 30.407 35.67288865728243 139.73780915959722 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1cd37dd-8c32-4105-9c50-b31e44be9a62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1cd37dd-8c32-4105-9c50-b31e44be9a62_0">
											<gml:posList>35.67288050309233 139.73781323446323 32.05 35.67288332211101 139.737821725943 32.05 35.67289148531512 139.73781765106696 32.05 35.67288865728243 139.73780915959722 32.05 35.67288050309233 139.73781323446323 32.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f27130ef-b529-42f0-b773-e23b71e03191">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f27130ef-b529-42f0-b773-e23b71e03191_0">
											<gml:posList>35.67270514531084 139.73781862424124 32.002 35.67271235352537 139.73781513598055 32.002 35.67271235352537 139.73781513598055 34.066 35.67270514531084 139.73781862424124 34.066 35.67270514531084 139.73781862424124 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6de148d-6337-4da5-b500-77f6c6b38309">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6de148d-6337-4da5-b500-77f6c6b38309_0">
											<gml:posList>35.67288050309233 139.73781323446323 30.407 35.67288332211101 139.737821725943 30.407 35.67288332211101 139.737821725943 32.05 35.67288050309233 139.73781323446323 32.05 35.67288050309233 139.73781323446323 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b80531cc-fec0-4970-affd-839d7e358f5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b80531cc-fec0-4970-affd-839d7e358f5d_0">
											<gml:posList>35.67288332211101 139.737821725943 30.407 35.67289148531512 139.73781765106696 30.407 35.67289148531512 139.73781765106696 32.05 35.67288332211101 139.737821725943 32.05 35.67288332211101 139.737821725943 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9cf7762-eebc-445a-b226-a9967ec10c94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9cf7762-eebc-445a-b226-a9967ec10c94_0">
											<gml:posList>35.67277510975856 139.7378184966996 32.002 35.672768307047434 139.73782184087398 32.002 35.672768307047434 139.73782184087398 33.784 35.67277510975856 139.7378184966996 33.784 35.67277510975856 139.7378184966996 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e2bbc8c-be45-4a00-9e6c-6d01a37b94e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e2bbc8c-be45-4a00-9e6c-6d01a37b94e0_0">
											<gml:posList>35.67277860651434 139.73782914144599 32.002 35.67277510975856 139.7378184966996 32.002 35.67277510975856 139.7378184966996 33.784 35.67277860651434 139.73782914144599 33.784 35.67277860651434 139.73782914144599 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5dfcfc0-f65a-4cc5-ad83-de5345d07295">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5dfcfc0-f65a-4cc5-ad83-de5345d07295_0">
											<gml:posList>35.672771803811685 139.73783249666616 33.784 35.67277860651434 139.73782914144599 33.784 35.67277510975856 139.7378184966996 33.784 35.672768307047434 139.73782184087398 33.784 35.672771803811685 139.73783249666616 33.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31a55ca5-5424-435a-b040-14c79dc51dd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31a55ca5-5424-435a-b040-14c79dc51dd6_0">
											<gml:posList>35.672768307047434 139.73782184087398 32.002 35.672771803811685 139.73783249666616 32.002 35.672771803811685 139.73783249666616 33.784 35.672768307047434 139.73782184087398 33.784 35.672768307047434 139.73782184087398 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e69ea9a4-2070-4cfb-b42d-8cfad184ad45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e69ea9a4-2070-4cfb-b42d-8cfad184ad45_0">
											<gml:posList>35.672771803811685 139.73783249666616 32.002 35.67277860651434 139.73782914144599 32.002 35.67277860651434 139.73782914144599 33.784 35.672771803811685 139.73783249666616 33.784 35.672771803811685 139.73783249666616 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bcdcc9b-2ae3-44f0-95ed-6a47c806e79b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bcdcc9b-2ae3-44f0-95ed-6a47c806e79b_0">
											<gml:posList>35.67280095574632 139.7378458062237 32.539 35.67281557048717 139.7378388405086 32.539 35.67281557048717 139.7378388405086 30.407 35.672804388685265 139.73784417828568 30.407 35.672804388685265 139.73784417828568 31.901 35.67280095574632 139.7378458062237 31.901 35.67280095574632 139.7378458062237 32.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1d5af27-3592-4ed9-b6a5-bea5ee949e23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1d5af27-3592-4ed9-b6a5-bea5ee949e23_0">
											<gml:posList>35.67281557048717 139.7378388405086 30.407 35.67281557048717 139.7378388405086 32.539 35.67282272641627 139.73786035075332 32.539 35.67282272641627 139.73786035075332 31.901 35.67282138920641 139.73785634243157 31.901 35.67282138920641 139.73785634243157 30.407 35.67281557048717 139.7378388405086 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-599d7bce-fe63-4cdf-a68b-fbbf209c6dfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-599d7bce-fe63-4cdf-a68b-fbbf209c6dfb_0">
											<gml:posList>35.672804388685265 139.73784417828568 31.901 35.672804388685265 139.73784417828568 30.407 35.67281007204908 139.7378614925757 30.407 35.67281007204908 139.7378614925757 31.901 35.672804388685265 139.73784417828568 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79a95638-4307-4f61-a445-2deefaed2eba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79a95638-4307-4f61-a445-2deefaed2eba_0">
											<gml:posList>35.67281557048717 139.7378388405086 32.539 35.67280095574632 139.7378458062237 32.539 35.67280776881131 139.73786688605622 32.539 35.67282272641627 139.73786035075332 32.539 35.67281557048717 139.7378388405086 32.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-933006d4-6058-4c19-bd5f-6231ab3ef756">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-933006d4-6058-4c19-bd5f-6231ab3ef756_0">
											<gml:posList>35.67280095574632 139.7378458062237 31.901 35.67280776881131 139.73786688605622 31.901 35.67280776881131 139.73786688605622 32.539 35.67280095574632 139.7378458062237 32.539 35.67280095574632 139.7378458062237 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad1c8e53-25f9-46e4-a2a6-25e27d9fdcdb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad1c8e53-25f9-46e4-a2a6-25e27d9fdcdb_0">
											<gml:posList>35.67281007204908 139.7378614925757 30.407 35.67282138920641 139.73785634243157 30.407 35.67282138920641 139.73785634243157 31.901 35.67281007204908 139.7378614925757 31.901 35.67281007204908 139.7378614925757 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c10068cf-8589-46f6-9033-851b62c51ebb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c10068cf-8589-46f6-9033-851b62c51ebb_0">
											<gml:posList>35.67280776881131 139.73786688605622 31.901 35.67282272641627 139.73786035075332 31.901 35.67282272641627 139.73786035075332 32.539 35.67280776881131 139.73786688605622 32.539 35.67280776881131 139.73786688605622 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0b8dacb-e61c-40d2-862d-c64699ad04e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0b8dacb-e61c-40d2-862d-c64699ad04e4_0">
											<gml:posList>35.672790795206915 139.73787730111073 34.931 35.672782154553786 139.7378817300349 34.931 35.672782154553786 139.7378817300349 37.16 35.672790795206915 139.73787730111073 37.16 35.672790795206915 139.73787730111073 34.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f57c92d2-14d0-4795-8ec4-c9218ac2ecfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f57c92d2-14d0-4795-8ec4-c9218ac2ecfa_0">
											<gml:posList>35.672790795206915 139.73787730111073 34.931 35.672790795206915 139.73787730111073 37.16 35.67279497828726 139.73788956889368 37.16 35.67279497828726 139.73788956889368 34.931 35.672790795206915 139.73787730111073 34.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-368a50b0-d99c-429c-952e-8bdaa3156a75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-368a50b0-d99c-429c-952e-8bdaa3156a75_0">
											<gml:posList>35.672790795206915 139.73787730111073 37.16 35.672782154553786 139.7378817300349 37.16 35.6727863286112 139.7378939867809 37.16 35.67279497828726 139.73788956889368 37.16 35.672790795206915 139.73787730111073 37.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b150aa3-e060-4c32-92d7-127fe3bec0fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b150aa3-e060-4c32-92d7-127fe3bec0fd_0">
											<gml:posList>35.67272678571561 139.7378848669074 32.002 35.67271998299382 139.73788820002753 32.002 35.67271998299382 139.73788820002753 34.273 35.67272678571561 139.7378848669074 34.273 35.67272678571561 139.7378848669074 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1dd99d5-c4a3-4793-86ab-a865571c9fb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1dd99d5-c4a3-4793-86ab-a865571c9fb6_0">
											<gml:posList>35.672782154553786 139.7378817300349 34.931 35.6727863286112 139.7378939867809 34.931 35.6727863286112 139.7378939867809 37.16 35.672782154553786 139.7378817300349 37.16 35.672782154553786 139.7378817300349 34.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f16906a-ec1e-4824-abc3-b7a1e85aa285">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f16906a-ec1e-4824-abc3-b7a1e85aa285_0">
											<gml:posList>35.6727863286112 139.7378939867809 34.931 35.67279497828726 139.73788956889368 34.931 35.67279497828726 139.73788956889368 37.16 35.6727863286112 139.7378939867809 37.16 35.6727863286112 139.7378939867809 34.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61f2638c-ced4-4bdd-8ff8-a02b7ac8133a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61f2638c-ced4-4bdd-8ff8-a02b7ac8133a_0">
											<gml:posList>35.67272678571561 139.7378848669074 32.002 35.67272678571561 139.7378848669074 34.273 35.67273780933887 139.73791877784254 34.273 35.67273780933887 139.73791877784254 32.002 35.67272678571561 139.7378848669074 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3834c3bc-ff66-40a1-9a2b-c903d8516b89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3834c3bc-ff66-40a1-9a2b-c903d8516b89_0">
											<gml:posList>35.67271998299382 139.73788820002753 34.273 35.672731006607385 139.73792209991367 34.273 35.67273780933887 139.73791877784254 34.273 35.67272678571561 139.7378848669074 34.273 35.67271998299382 139.73788820002753 34.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e86d54fc-6023-4b2a-9714-49a086a11cec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e86d54fc-6023-4b2a-9714-49a086a11cec_0">
											<gml:posList>35.67278601560402 139.73790848028048 34.931 35.67278601560402 139.73790848028048 38.905 35.67280578511859 139.73790014971107 38.905 35.67280578511859 139.73790014971107 34.931 35.67278601560402 139.73790848028048 34.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac1c5cb2-7cbc-4477-88ae-647d42a83d3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac1c5cb2-7cbc-4477-88ae-647d42a83d3d_0">
											<gml:posList>35.672731006607385 139.73792209991367 32.002 35.672731006607385 139.73792209991367 34.273 35.67271998299382 139.73788820002753 34.273 35.67271998299382 139.73788820002753 32.002 35.672731006607385 139.73792209991367 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65c646fe-fbe9-49cf-9cde-497cf7a2c8be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65c646fe-fbe9-49cf-9cde-497cf7a2c8be_0">
											<gml:posList>35.67280578511859 139.73790014971107 34.931 35.67280578511859 139.73790014971107 38.905 35.67281207642879 139.73792255576177 38.905 35.67281207642879 139.73792255576177 34.931 35.67280578511859 139.73790014971107 34.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c490e344-d8e5-4aa5-87b1-76ac16531572">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c490e344-d8e5-4aa5-87b1-76ac16531572_0">
											<gml:posList>35.67281207642879 139.73792255576177 38.905 35.67280578511859 139.73790014971107 38.905 35.67278601560402 139.73790848028048 38.905 35.67279230692143 139.73793089737288 38.905 35.67281207642879 139.73792255576177 38.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa459c94-5638-4919-ba71-b8208f076259">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa459c94-5638-4919-ba71-b8208f076259_0">
											<gml:posList>35.672694907067296 139.7379226510184 32.508 35.67269314106995 139.73792352579977 32.508 35.67269314106995 139.73792352579977 33.783 35.67270904405078 139.73791564170887 33.783 35.67270904405078 139.73791564170887 32.002 35.672694907067296 139.7379226510184 32.002 35.672694907067296 139.7379226510184 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb195469-2116-428f-ae19-ccd7dfec31a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb195469-2116-428f-ae19-ccd7dfec31a2_0">
											<gml:posList>35.67278601560402 139.73790848028048 34.931 35.67279230692143 139.73793089737288 34.931 35.67279230692143 139.73793089737288 38.905 35.67278601560402 139.73790848028048 38.905 35.67278601560402 139.73790848028048 34.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2189bf58-3007-46ee-8b1f-bea2580e6541">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2189bf58-3007-46ee-8b1f-bea2580e6541_0">
											<gml:posList>35.67274205737375 139.73792202048264 32.002 35.67272291945667 139.73793115668886 32.002 35.67272291945667 139.73793115668886 34.854 35.67274205737375 139.73792202048264 34.854 35.67274205737375 139.73792202048264 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55ee3cb6-4ed5-4a59-b9b2-01edcee59b8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55ee3cb6-4ed5-4a59-b9b2-01edcee59b8a_0">
											<gml:posList>35.67279230692143 139.73793089737288 34.931 35.67281207642879 139.73792255576177 34.931 35.67281207642879 139.73792255576177 38.905 35.67279230692143 139.73793089737288 38.905 35.67279230692143 139.73793089737288 34.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1dfcda5f-e135-4919-bb1d-0c7579b8afdd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1dfcda5f-e135-4919-bb1d-0c7579b8afdd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1dfcda5f-e135-4919-bb1d-0c7579b8afdd">
											<gml:posList>35.67277445618229 139.73776727444482 8.65 35.67290398165577 139.73770826372373 8.65 35.672934979726776 139.7378102974371 8.65 35.67280761670791 139.73786831124795 8.65 35.672834810130254 139.73795805456353 8.65 35.672718214601076 139.73801121686245 8.65 35.67263860471383 139.737748878146 8.65 35.67275303762545 139.73769671229132 8.65 35.67277445618229 139.73776727444482 8.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ca29c4c-afd9-4678-8c45-3aea688319a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ca29c4c-afd9-4678-8c45-3aea688319a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ca29c4c-afd9-4678-8c45-3aea688319a7">
											<gml:posList>35.67282514920893 139.73792618558053 35.205 35.67282188741574 139.73792766970604 35.205 35.67278343071102 139.7379451911768 35.205 35.67282514920893 139.73792618558053 35.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c14ae21-6404-4be2-a350-c33630b48c71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c14ae21-6404-4be2-a350-c33630b48c71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c14ae21-6404-4be2-a350-c33630b48c71">
											<gml:posList>35.67263860471383 139.737748878146 32.508 35.67264289716427 139.7377512922273 32.508 35.67275107681984 139.73770198385185 32.508 35.67275303762545 139.73769671229132 32.508 35.67263860471383 139.737748878146 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bed05202-77db-40f5-b891-5199f0a26d42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bed05202-77db-40f5-b891-5199f0a26d42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bed05202-77db-40f5-b891-5199f0a26d42">
											<gml:posList>35.67277445618229 139.73776727444482 32.508 35.67275303762545 139.73769671229132 32.508 35.67275107681984 139.73770198385185 32.508 35.672771338610524 139.73776875840397 32.508 35.67277445618229 139.73776727444482 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70bb5638-debd-453d-a640-33ecddc45da2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70bb5638-debd-453d-a640-33ecddc45da2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70bb5638-debd-453d-a640-33ecddc45da2">
											<gml:posList>35.67277445618229 139.73776727444482 31.901 35.67278016432962 139.73777037173227 31.901 35.6728856949397 139.73772230367666 31.901 35.672888258402075 139.73771544067793 31.901 35.67277445618229 139.73776727444482 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de05eca9-f017-4974-8033-12e5f3980b22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de05eca9-f017-4974-8033-12e5f3980b22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de05eca9-f017-4974-8033-12e5f3980b22">
											<gml:posList>35.67291925646705 139.73781747437408 31.71 35.672934979726776 139.7378102974371 29.273 35.67290398165577 139.73770826372373 29.273 35.672888258402075 139.73771544067793 31.71 35.67291925646705 139.73781747437408 31.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9a0625f-3903-4ba0-9753-85bc545ef2bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9a0625f-3903-4ba0-9753-85bc545ef2bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9a0625f-3903-4ba0-9753-85bc545ef2bb">
											<gml:posList>35.672888258402075 139.73771544067793 31.901 35.6728856949397 139.73772230367666 31.901 35.67291365644183 139.7378143217161 31.901 35.67291925646705 139.73781747437408 31.901 35.672888258402075 139.73771544067793 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-85ae4413-0553-4bf6-92bf-e3c24364a645">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85ae4413-0553-4bf6-92bf-e3c24364a645">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85ae4413-0553-4bf6-92bf-e3c24364a645">
											<gml:posList>35.67281007204908 139.7378614925757 30.407 35.67291365644183 139.7378143217161 30.407 35.6728856949397 139.73772230367666 30.407 35.67278016432962 139.73777037173227 30.407 35.67281007204908 139.7378614925757 30.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50010846-4f83-44fe-8e4e-07f4c3489a89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50010846-4f83-44fe-8e4e-07f4c3489a89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50010846-4f83-44fe-8e4e-07f4c3489a89">
											<gml:posList>35.67277445618229 139.73776727444482 32.508 35.672771338610524 139.73776875840397 32.508 35.67279680989139 139.73784638558448 32.508 35.67280118339317 139.73784871120645 32.508 35.67277445618229 139.73776727444482 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d7433a5-064c-4969-a68f-3a39b0a10d8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d7433a5-064c-4969-a68f-3a39b0a10d8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d7433a5-064c-4969-a68f-3a39b0a10d8e">
											<gml:posList>35.67280761670791 139.73786831124795 31.901 35.67281007204908 139.7378614925757 31.901 35.67278016432962 139.73777037173227 31.901 35.67277445618229 139.73776727444482 31.901 35.67280761670791 139.73786831124795 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7af1be6a-5fb4-4363-b36b-bf4205e63c73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7af1be6a-5fb4-4363-b36b-bf4205e63c73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7af1be6a-5fb4-4363-b36b-bf4205e63c73">
											<gml:posList>35.67291925646705 139.73781747437408 31.901 35.67291365644183 139.7378143217161 31.901 35.67281007204908 139.7378614925757 31.901 35.67280761670791 139.73786831124795 31.901 35.67291925646705 139.73781747437408 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cef68381-77d3-4a61-8c99-52ee412bf0ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cef68381-77d3-4a61-8c99-52ee412bf0ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cef68381-77d3-4a61-8c99-52ee412bf0ba">
											<gml:posList>35.672771338610524 139.73776875840397 32.002 35.67275107681984 139.73770198385185 32.002 35.67264289716427 139.7377512922273 32.002 35.67271499702906 139.7379888624084 32.002 35.672786837755936 139.7379563883661 32.002 35.672759888420785 139.73786755063418 32.002 35.672797975692 139.73785020631686 32.002 35.67279680989139 139.73784638558448 32.002 35.672771338610524 139.73776875840397 32.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4901215e-545d-4f40-8828-1df1ba5fc95b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4901215e-545d-4f40-8828-1df1ba5fc95b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4901215e-545d-4f40-8828-1df1ba5fc95b">
											<gml:posList>35.67280028237173 139.7378491541433 32.508 35.67280118339317 139.73784871120645 32.508 35.67279680989139 139.73784638558448 32.508 35.67280028237173 139.7378491541433 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c2ed10d-0807-465f-a21f-2ae8396cc2a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c2ed10d-0807-465f-a21f-2ae8396cc2a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c2ed10d-0807-465f-a21f-2ae8396cc2a2">
											<gml:posList>35.672797975692 139.73785020631686 32.508 35.67280028237173 139.7378491541433 32.508 35.67279680989139 139.73784638558448 32.508 35.672797975692 139.73785020631686 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9db627df-4e14-4380-915a-35b9a68fe0db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9db627df-4e14-4380-915a-35b9a68fe0db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9db627df-4e14-4380-915a-35b9a68fe0db">
											<gml:posList>35.67280118339317 139.73784871120645 32.508 35.67280028237173 139.7378491541433 32.508 35.67280627414556 139.73786892040928 32.508 35.67280761670791 139.73786831124795 32.508 35.67280118339317 139.73784871120645 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3dc11ad8-e0f6-41fa-82fd-bd22aa360d4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3dc11ad8-e0f6-41fa-82fd-bd22aa360d4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3dc11ad8-e0f6-41fa-82fd-bd22aa360d4b">
											<gml:posList>35.67280028237173 139.7378491541433 35.205 35.67279879826168 139.73785313268417 35.205 35.67280302775309 139.73786709054053 35.205 35.67280627414556 139.73786892040928 35.205 35.67280028237173 139.7378491541433 35.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-faa02e85-09e1-4de0-87db-1dd73e3f920a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faa02e85-09e1-4de0-87db-1dd73e3f920a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faa02e85-09e1-4de0-87db-1dd73e3f920a">
											<gml:posList>35.672759888420785 139.73786755063418 35.205 35.67276314381823 139.73786936944467 35.205 35.67279879826168 139.73785313268417 35.205 35.67280028237173 139.7378491541433 35.205 35.672759888420785 139.73786755063418 35.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-944e81fc-2121-458d-9f0d-3d1f84e892c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-944e81fc-2121-458d-9f0d-3d1f84e892c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-944e81fc-2121-458d-9f0d-3d1f84e892c4">
											<gml:posList>35.67280434590171 139.73786979538622 35.205 35.67280627414556 139.73786892040928 35.205 35.67280302775309 139.73786709054053 35.205 35.67280109950925 139.7378679655175 35.205 35.67280434590171 139.73786979538622 35.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9a7c7e4-8a93-45d4-bf4e-feea109c3a26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9a7c7e4-8a93-45d4-bf4e-feea109c3a26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9a7c7e4-8a93-45d4-bf4e-feea109c3a26">
											<gml:posList>35.67271302717943 139.73799411187687 32.508 35.67271499702906 139.7379888624084 32.508 35.67264289716427 139.7377512922273 32.508 35.67263860471383 139.737748878146 32.508 35.67271302717943 139.73799411187687 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b92f4600-f783-4871-974f-2d7ac2aca4dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b92f4600-f783-4871-974f-2d7ac2aca4dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b92f4600-f783-4871-974f-2d7ac2aca4dc">
											<gml:posList>35.67278492382909 139.7379412015811 34.931 35.672818641024165 139.7379258398346 34.931 35.67280109950925 139.7378679655175 34.931 35.67280302775309 139.73786709054053 34.931 35.67279879826168 139.73785313268417 34.931 35.67276314381823 139.73786936944467 34.931 35.67278492382909 139.7379412015811 34.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d690f2fa-142f-48b5-bc8d-4cbf296c94e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d690f2fa-142f-48b5-bc8d-4cbf296c94e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d690f2fa-142f-48b5-bc8d-4cbf296c94e8">
											<gml:posList>35.67280434590171 139.73786979538622 35.205 35.67280109950925 139.7378679655175 35.205 35.672818641024165 139.7379258398346 35.205 35.67282188741574 139.73792766970604 35.205 35.67280434590171 139.73786979538622 35.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c167efc-240c-418e-b546-9cc5307602fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c167efc-240c-418e-b546-9cc5307602fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c167efc-240c-418e-b546-9cc5307602fb">
											<gml:posList>35.67282188741574 139.73792766970604 32.508 35.67282514920893 139.73792618558053 32.508 35.67280761670791 139.73786831124795 32.508 35.67280627414556 139.73786892040928 32.508 35.67280434590171 139.73786979538622 32.508 35.67282188741574 139.73792766970604 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-316f7c33-b176-40ca-a952-707582fcab30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-316f7c33-b176-40ca-a952-707582fcab30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-316f7c33-b176-40ca-a952-707582fcab30">
											<gml:posList>35.67278343071102 139.7379451911768 35.205 35.67278492382909 139.7379412015811 35.205 35.67276314381823 139.73786936944467 35.205 35.672759888420785 139.73786755063418 35.205 35.67278343071102 139.7379451911768 35.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e466a470-ae53-4095-948c-629d58e2af0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e466a470-ae53-4095-948c-629d58e2af0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e466a470-ae53-4095-948c-629d58e2af0b">
											<gml:posList>35.67282188741574 139.73792766970604 35.205 35.672818641024165 139.7379258398346 35.205 35.67278492382909 139.7379412015811 35.205 35.67278343071102 139.7379451911768 35.205 35.67282188741574 139.73792766970604 35.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d47aaef9-6e17-4a42-9da0-6abf4f6af8d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d47aaef9-6e17-4a42-9da0-6abf4f6af8d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d47aaef9-6e17-4a42-9da0-6abf4f6af8d4">
											<gml:posList>35.67279013639019 139.73796727638072 32.577 35.67283183685536 139.73794825976918 32.577 35.67282514920893 139.73792618558053 35.205 35.67279013639019 139.73796727638072 32.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d64ae631-748a-44fa-846a-c2dd37483e6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d64ae631-748a-44fa-846a-c2dd37483e6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d64ae631-748a-44fa-846a-c2dd37483e6c">
											<gml:posList>35.67279013639019 139.73796727638072 32.577 35.67282514920893 139.73792618558053 35.205 35.67278343071102 139.7379451911768 35.205 35.67279013639019 139.73796727638072 32.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b91b8842-f1ac-4610-a6af-055e6833154d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b91b8842-f1ac-4610-a6af-055e6833154d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b91b8842-f1ac-4610-a6af-055e6833154d">
											<gml:posList>35.67279013639019 139.73796727638072 32.577 35.67279310966355 139.7379770711707 31.039 35.672834810130254 139.73795805456353 31.039 35.67283183685536 139.73794825976918 32.577 35.67279013639019 139.73796727638072 32.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c528404e-a3ac-49c8-b6c8-e00b43121241">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c528404e-a3ac-49c8-b6c8-e00b43121241">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c528404e-a3ac-49c8-b6c8-e00b43121241">
											<gml:posList>35.67271499702906 139.7379888624084 32.508 35.67271302717943 139.73799411187687 32.508 35.67278800357055 139.7379602311928 32.508 35.672786837755936 139.7379563883661 32.508 35.67271499702906 139.7379888624084 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e910ae3-3e9e-4340-9ef4-6420f0178369">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e910ae3-3e9e-4340-9ef4-6420f0178369">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e910ae3-3e9e-4340-9ef4-6420f0178369">
											<gml:posList>35.672718214601076 139.73801121686245 29.926 35.67279310966355 139.7379770711707 29.926 35.67278800357055 139.7379602311928 32.508 35.67271302717943 139.73799411187687 32.508 35.672718214601076 139.73801121686245 29.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-277a1afd-9dee-45e1-a3f4-005c54304dc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-277a1afd-9dee-45e1-a3f4-005c54304dc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-277a1afd-9dee-45e1-a3f4-005c54304dc6">
											<gml:posList>35.67280302775309 139.73786709054053 35.205 35.67280302775309 139.73786709054053 34.931 35.67280109950925 139.7378679655175 34.931 35.67280109950925 139.7378679655175 35.205 35.67280302775309 139.73786709054053 35.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15a91b7b-33dc-4761-8af0-2e56a71e5e97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15a91b7b-33dc-4761-8af0-2e56a71e5e97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15a91b7b-33dc-4761-8af0-2e56a71e5e97">
											<gml:posList>35.672718214601076 139.73801121686245 8.65 35.672718214601076 139.73801121686245 29.926 35.67271302717943 139.73799411187687 32.508 35.67263860471383 139.737748878146 32.508 35.67263860471383 139.737748878146 8.65 35.672718214601076 139.73801121686245 8.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f29c9d21-c1b4-4da8-bcae-b39829fbb68e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f29c9d21-c1b4-4da8-bcae-b39829fbb68e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f29c9d21-c1b4-4da8-bcae-b39829fbb68e">
											<gml:posList>35.67271499702906 139.7379888624084 32.508 35.67271499702906 139.7379888624084 32.002 35.67264289716427 139.7377512922273 32.002 35.67264289716427 139.7377512922273 32.508 35.67271499702906 139.7379888624084 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bb77d15-4260-46dc-98c4-d9a550a6598d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bb77d15-4260-46dc-98c4-d9a550a6598d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bb77d15-4260-46dc-98c4-d9a550a6598d">
											<gml:posList>35.67263860471383 139.737748878146 32.508 35.67275303762545 139.73769671229132 32.508 35.67275303762545 139.73769671229132 8.65 35.67263860471383 139.737748878146 8.65 35.67263860471383 139.737748878146 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-245078d5-361a-4f5b-9fda-91ad66132eae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-245078d5-361a-4f5b-9fda-91ad66132eae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-245078d5-361a-4f5b-9fda-91ad66132eae">
											<gml:posList>35.67264289716427 139.7377512922273 32.508 35.67264289716427 139.7377512922273 32.002 35.67275107681984 139.73770198385185 32.002 35.67275107681984 139.73770198385185 32.508 35.67264289716427 139.7377512922273 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ddc5270-f8a4-478c-872a-c990f9e44903">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ddc5270-f8a4-478c-872a-c990f9e44903">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ddc5270-f8a4-478c-872a-c990f9e44903">
											<gml:posList>35.67275107681984 139.73770198385185 32.508 35.67275107681984 139.73770198385185 32.002 35.672771338610524 139.73776875840397 32.002 35.672771338610524 139.73776875840397 32.508 35.67275107681984 139.73770198385185 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67655821-0930-4d8b-ada0-1a3aac26fffa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67655821-0930-4d8b-ada0-1a3aac26fffa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67655821-0930-4d8b-ada0-1a3aac26fffa">
											<gml:posList>35.67275303762545 139.73769671229132 32.508 35.67277445618229 139.73776727444482 32.508 35.67277445618229 139.73776727444482 31.901 35.67277445618229 139.73776727444482 8.65 35.67275303762545 139.73769671229132 8.65 35.67275303762545 139.73769671229132 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5282e3a-b949-4b71-a06b-599d20599056">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5282e3a-b949-4b71-a06b-599d20599056">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5282e3a-b949-4b71-a06b-599d20599056">
											<gml:posList>35.672797975692 139.73785020631686 32.508 35.672797975692 139.73785020631686 32.002 35.672759888420785 139.73786755063418 32.002 35.672759888420785 139.73786755063418 35.205 35.67280028237173 139.7378491541433 35.205 35.67280028237173 139.7378491541433 32.508 35.672797975692 139.73785020631686 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46419445-1471-4f2a-911c-c8d95bbc007c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46419445-1471-4f2a-911c-c8d95bbc007c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46419445-1471-4f2a-911c-c8d95bbc007c">
											<gml:posList>35.67276314381823 139.73786936944467 35.205 35.67276314381823 139.73786936944467 34.931 35.67279879826168 139.73785313268417 34.931 35.67279879826168 139.73785313268417 35.205 35.67276314381823 139.73786936944467 35.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-368a04f9-7330-4750-a842-1e52c4679cb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-368a04f9-7330-4750-a842-1e52c4679cb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-368a04f9-7330-4750-a842-1e52c4679cb3">
											<gml:posList>35.672771338610524 139.73776875840397 32.508 35.672771338610524 139.73776875840397 32.002 35.67279680989139 139.73784638558448 32.002 35.67279680989139 139.73784638558448 32.508 35.672771338610524 139.73776875840397 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-939d8b63-e250-4546-8c3f-de3e298ba988">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-939d8b63-e250-4546-8c3f-de3e298ba988">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-939d8b63-e250-4546-8c3f-de3e298ba988">
											<gml:posList>35.67280761670791 139.73786831124795 31.901 35.67277445618229 139.73776727444482 31.901 35.67277445618229 139.73776727444482 32.508 35.67280118339317 139.73784871120645 32.508 35.67280761670791 139.73786831124795 32.508 35.67280761670791 139.73786831124795 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f320a9e3-ae86-435e-b6a2-d4157c1858cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f320a9e3-ae86-435e-b6a2-d4157c1858cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f320a9e3-ae86-435e-b6a2-d4157c1858cc">
											<gml:posList>35.67281007204908 139.7378614925757 31.901 35.67281007204908 139.7378614925757 30.407 35.67278016432962 139.73777037173227 30.407 35.67278016432962 139.73777037173227 31.901 35.67281007204908 139.7378614925757 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6f12668-07ab-4f54-9db2-01bb649abdd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6f12668-07ab-4f54-9db2-01bb649abdd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6f12668-07ab-4f54-9db2-01bb649abdd0">
											<gml:posList>35.67279680989139 139.73784638558448 32.508 35.67279680989139 139.73784638558448 32.002 35.672797975692 139.73785020631686 32.002 35.672797975692 139.73785020631686 32.508 35.67279680989139 139.73784638558448 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4ca844e-6b0e-4f7e-8285-33e0b241801e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4ca844e-6b0e-4f7e-8285-33e0b241801e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4ca844e-6b0e-4f7e-8285-33e0b241801e">
											<gml:posList>35.67279879826168 139.73785313268417 35.205 35.67279879826168 139.73785313268417 34.931 35.67280302775309 139.73786709054053 34.931 35.67280302775309 139.73786709054053 35.205 35.67279879826168 139.73785313268417 35.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-521235a2-9d76-4f24-81fc-527a7bdb3ee3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-521235a2-9d76-4f24-81fc-527a7bdb3ee3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-521235a2-9d76-4f24-81fc-527a7bdb3ee3">
											<gml:posList>35.67280028237173 139.7378491541433 32.508 35.67280028237173 139.7378491541433 35.205 35.67280627414556 139.73786892040928 35.205 35.67280627414556 139.73786892040928 32.508 35.67280028237173 139.7378491541433 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7377a98b-0300-4a41-bb29-85602ffe6d7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7377a98b-0300-4a41-bb29-85602ffe6d7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7377a98b-0300-4a41-bb29-85602ffe6d7e">
											<gml:posList>35.67280627414556 139.73786892040928 32.508 35.67280627414556 139.73786892040928 35.205 35.67280434590171 139.73786979538622 35.205 35.67280434590171 139.73786979538622 32.508 35.67280627414556 139.73786892040928 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a705acb-9aa1-4c73-a89e-e6a6a4c7fe0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a705acb-9aa1-4c73-a89e-e6a6a4c7fe0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a705acb-9aa1-4c73-a89e-e6a6a4c7fe0a">
											<gml:posList>35.67278016432962 139.73777037173227 31.901 35.67278016432962 139.73777037173227 30.407 35.6728856949397 139.73772230367666 30.407 35.6728856949397 139.73772230367666 31.901 35.67278016432962 139.73777037173227 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d6ef2f8-c22e-4eb7-aedf-63820501d464">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d6ef2f8-c22e-4eb7-aedf-63820501d464">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d6ef2f8-c22e-4eb7-aedf-63820501d464">
											<gml:posList>35.67290398165577 139.73770826372373 8.65 35.67277445618229 139.73776727444482 8.65 35.67277445618229 139.73776727444482 31.901 35.672888258402075 139.73771544067793 31.901 35.672888258402075 139.73771544067793 31.71 35.67290398165577 139.73770826372373 29.273 35.67290398165577 139.73770826372373 8.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41c2ff34-dbbe-428d-a9dd-1ab7952f9e19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41c2ff34-dbbe-428d-a9dd-1ab7952f9e19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41c2ff34-dbbe-428d-a9dd-1ab7952f9e19">
											<gml:posList>35.67291365644183 139.7378143217161 31.901 35.67291365644183 139.7378143217161 30.407 35.67281007204908 139.7378614925757 30.407 35.67281007204908 139.7378614925757 31.901 35.67291365644183 139.7378143217161 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4c0595d-2a20-4736-8823-ed793b9be0b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4c0595d-2a20-4736-8823-ed793b9be0b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4c0595d-2a20-4736-8823-ed793b9be0b8">
											<gml:posList>35.67291925646705 139.73781747437408 31.71 35.67291925646705 139.73781747437408 31.901 35.67280761670791 139.73786831124795 31.901 35.67280761670791 139.73786831124795 8.65 35.672934979726776 139.7378102974371 8.65 35.672934979726776 139.7378102974371 29.273 35.67291925646705 139.73781747437408 31.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3f700b2-df3a-4d1c-a426-e7729b8e1245">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3f700b2-df3a-4d1c-a426-e7729b8e1245">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3f700b2-df3a-4d1c-a426-e7729b8e1245">
											<gml:posList>35.6728856949397 139.73772230367666 31.901 35.6728856949397 139.73772230367666 30.407 35.67291365644183 139.7378143217161 30.407 35.67291365644183 139.7378143217161 31.901 35.6728856949397 139.73772230367666 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34e05aa5-9918-4a1d-b0e5-520544321a07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34e05aa5-9918-4a1d-b0e5-520544321a07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34e05aa5-9918-4a1d-b0e5-520544321a07">
											<gml:posList>35.672888258402075 139.73771544067793 31.901 35.67291925646705 139.73781747437408 31.901 35.67291925646705 139.73781747437408 31.71 35.672888258402075 139.73771544067793 31.71 35.672888258402075 139.73771544067793 31.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e3278d1-c040-49ec-ba4f-fb7f4858b80d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e3278d1-c040-49ec-ba4f-fb7f4858b80d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e3278d1-c040-49ec-ba4f-fb7f4858b80d">
											<gml:posList>35.672934979726776 139.7378102974371 8.65 35.67290398165577 139.73770826372373 8.65 35.67290398165577 139.73770826372373 29.273 35.672934979726776 139.7378102974371 29.273 35.672934979726776 139.7378102974371 8.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b52c701-1502-4e80-82b5-d557e7fb3f43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b52c701-1502-4e80-82b5-d557e7fb3f43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b52c701-1502-4e80-82b5-d557e7fb3f43">
											<gml:posList>35.672786837755936 139.7379563883661 32.508 35.672786837755936 139.7379563883661 32.002 35.67271499702906 139.7379888624084 32.002 35.67271499702906 139.7379888624084 32.508 35.672786837755936 139.7379563883661 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ba405fc-a5f8-4436-bf39-b2a5d0f67c2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ba405fc-a5f8-4436-bf39-b2a5d0f67c2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ba405fc-a5f8-4436-bf39-b2a5d0f67c2a">
											<gml:posList>35.67278492382909 139.7379412015811 35.205 35.67278492382909 139.7379412015811 34.931 35.67276314381823 139.73786936944467 34.931 35.67276314381823 139.73786936944467 35.205 35.67278492382909 139.7379412015811 35.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6f8b358-34ab-4f2f-a117-771dd67930f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6f8b358-34ab-4f2f-a117-771dd67930f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6f8b358-34ab-4f2f-a117-771dd67930f2">
											<gml:posList>35.67279310966355 139.7379770711707 29.926 35.672718214601076 139.73801121686245 29.926 35.672718214601076 139.73801121686245 8.65 35.672834810130254 139.73795805456353 8.65 35.672834810130254 139.73795805456353 31.039 35.67279310966355 139.7379770711707 31.039 35.67279310966355 139.7379770711707 29.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88926b53-8fb2-4fdb-b94c-53130abdfda7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88926b53-8fb2-4fdb-b94c-53130abdfda7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88926b53-8fb2-4fdb-b94c-53130abdfda7">
											<gml:posList>35.67278800357055 139.7379602311928 32.508 35.67279310966355 139.7379770711707 29.926 35.67279310966355 139.7379770711707 31.039 35.67279013639019 139.73796727638072 32.577 35.67278343071102 139.7379451911768 35.205 35.672759888420785 139.73786755063418 35.205 35.672759888420785 139.73786755063418 32.002 35.672786837755936 139.7379563883661 32.002 35.672786837755936 139.7379563883661 32.508 35.67278800357055 139.7379602311928 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e286c3ba-cf7b-4750-ab6a-ff4d766b1a84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e286c3ba-cf7b-4750-ab6a-ff4d766b1a84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e286c3ba-cf7b-4750-ab6a-ff4d766b1a84">
											<gml:posList>35.672818641024165 139.7379258398346 35.205 35.672818641024165 139.7379258398346 34.931 35.67278492382909 139.7379412015811 34.931 35.67278492382909 139.7379412015811 35.205 35.672818641024165 139.7379258398346 35.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-faf5bffc-2e4c-4d08-9a39-05e2c865b9ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faf5bffc-2e4c-4d08-9a39-05e2c865b9ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faf5bffc-2e4c-4d08-9a39-05e2c865b9ee">
											<gml:posList>35.67280109950925 139.7378679655175 35.205 35.67280109950925 139.7378679655175 34.931 35.672818641024165 139.7379258398346 34.931 35.672818641024165 139.7379258398346 35.205 35.67280109950925 139.7378679655175 35.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b18bfb1-840d-4d45-96c9-7e9ae724d002">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b18bfb1-840d-4d45-96c9-7e9ae724d002">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b18bfb1-840d-4d45-96c9-7e9ae724d002">
											<gml:posList>35.67280434590171 139.73786979538622 32.508 35.67280434590171 139.73786979538622 35.205 35.67282188741574 139.73792766970604 35.205 35.67282188741574 139.73792766970604 32.508 35.67280434590171 139.73786979538622 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16f7a020-6c10-45a8-b1b2-fa8cc256c773">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16f7a020-6c10-45a8-b1b2-fa8cc256c773">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16f7a020-6c10-45a8-b1b2-fa8cc256c773">
											<gml:posList>35.67283183685536 139.73794825976918 32.577 35.672834810130254 139.73795805456353 31.039 35.672834810130254 139.73795805456353 8.65 35.67280761670791 139.73786831124795 8.65 35.67280761670791 139.73786831124795 31.901 35.67280761670791 139.73786831124795 32.508 35.67282514920893 139.73792618558053 32.508 35.67282514920893 139.73792618558053 35.205 35.67283183685536 139.73794825976918 32.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcdf436b-2177-46db-8749-de8588e11194">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcdf436b-2177-46db-8749-de8588e11194">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcdf436b-2177-46db-8749-de8588e11194">
											<gml:posList>35.67282188741574 139.73792766970604 32.508 35.67282188741574 139.73792766970604 35.205 35.67282514920893 139.73792618558053 35.205 35.67282514920893 139.73792618558053 32.508 35.67282188741574 139.73792766970604 32.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2967</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">510.01659</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>