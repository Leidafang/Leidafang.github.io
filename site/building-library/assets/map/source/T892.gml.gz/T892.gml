<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ff4a91a8-29e0-43b1-b1fc-14af2a22e3e4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">21</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67391055474931 139.73766451101162 0 35.673953354893094 139.7376455699902 0 35.673956183621684 139.73765492321266 0 35.67396292345893 139.73765186626494 0 35.67396909603025 139.73767225120505 0 35.6739778091522 139.73766828606966 0 35.67398174948841 139.73768131653895 0 35.67396629652795 139.73768833861843 0 35.67398570892976 139.73775246396974 0 35.6740693261354 139.73771447386247 0 35.674008954330695 139.73751305298418 0 35.673881994303116 139.73756755470305 0 35.67388118069638 139.73756457305475 0 35.6738512656117 139.7375777544092 0 35.67388552066219 139.73769480895993 0 35.67389795529173 139.7376893812211 0 35.67391765852594 139.73775652193314 0 35.67396442340398 139.7377359192184 0 35.673944720158374 139.73766877847228 0 35.67391561603385 139.7376816274284 0 35.67391055474931 139.73766451101162 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67391055474931 139.73766451101162 9.284 35.67391561603385 139.7376816274284 9.284 35.673944720158374 139.73766877847228 9.284 35.67396442340398 139.7377359192184 9.284 35.67391765852594 139.73775652193314 9.284 35.67389795529173 139.7376893812211 9.284 35.67388552066219 139.73769480895993 9.284 35.6738512656117 139.7375777544092 9.284 35.67388118069638 139.73756457305475 9.284 35.673881994303116 139.73756755470305 9.284 35.674008954330695 139.73751305298418 9.284 35.6740693261354 139.73771447386247 9.284 35.67398570892976 139.73775246396974 9.284 35.67396629652795 139.73768833861843 9.284 35.67398174948841 139.73768131653895 9.284 35.6739778091522 139.73766828606966 9.284 35.67396909603025 139.73767225120505 9.284 35.67396292345893 139.73765186626494 9.284 35.673956183621684 139.73765492321266 9.284 35.673953354893094 139.7376455699902 9.284 35.67391055474931 139.73766451101162 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67391055474931 139.73766451101162 9.284 35.673953354893094 139.7376455699902 9.284 35.673953354893094 139.7376455699902 27.809999999999995 35.67391055474931 139.73766451101162 27.809999999999995 35.67391055474931 139.73766451101162 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673953354893094 139.7376455699902 9.284 35.673956183621684 139.73765492321266 9.284 35.673956183621684 139.73765492321266 27.809999999999995 35.673953354893094 139.7376455699902 27.809999999999995 35.673953354893094 139.7376455699902 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673956183621684 139.73765492321266 9.284 35.67396292345893 139.73765186626494 9.284 35.67396292345893 139.73765186626494 27.809999999999995 35.673956183621684 139.73765492321266 27.809999999999995 35.673956183621684 139.73765492321266 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67396292345893 139.73765186626494 9.284 35.67396909603025 139.73767225120505 9.284 35.67396909603025 139.73767225120505 27.809999999999995 35.67396292345893 139.73765186626494 27.809999999999995 35.67396292345893 139.73765186626494 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67396909603025 139.73767225120505 9.284 35.6739778091522 139.73766828606966 9.284 35.6739778091522 139.73766828606966 27.809999999999995 35.67396909603025 139.73767225120505 27.809999999999995 35.67396909603025 139.73767225120505 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6739778091522 139.73766828606966 9.284 35.67398174948841 139.73768131653895 9.284 35.67398174948841 139.73768131653895 27.809999999999995 35.6739778091522 139.73766828606966 27.809999999999995 35.6739778091522 139.73766828606966 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67398174948841 139.73768131653895 9.284 35.67396629652795 139.73768833861843 9.284 35.67396629652795 139.73768833861843 27.809999999999995 35.67398174948841 139.73768131653895 27.809999999999995 35.67398174948841 139.73768131653895 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67396629652795 139.73768833861843 9.284 35.67398570892976 139.73775246396974 9.284 35.67398570892976 139.73775246396974 27.809999999999995 35.67396629652795 139.73768833861843 27.809999999999995 35.67396629652795 139.73768833861843 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67398570892976 139.73775246396974 9.284 35.6740693261354 139.73771447386247 9.284 35.6740693261354 139.73771447386247 27.809999999999995 35.67398570892976 139.73775246396974 27.809999999999995 35.67398570892976 139.73775246396974 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6740693261354 139.73771447386247 9.284 35.674008954330695 139.73751305298418 9.284 35.674008954330695 139.73751305298418 27.809999999999995 35.6740693261354 139.73771447386247 27.809999999999995 35.6740693261354 139.73771447386247 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674008954330695 139.73751305298418 9.284 35.673881994303116 139.73756755470305 9.284 35.673881994303116 139.73756755470305 27.809999999999995 35.674008954330695 139.73751305298418 27.809999999999995 35.674008954330695 139.73751305298418 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673881994303116 139.73756755470305 9.284 35.67388118069638 139.73756457305475 9.284 35.67388118069638 139.73756457305475 27.809999999999995 35.673881994303116 139.73756755470305 27.809999999999995 35.673881994303116 139.73756755470305 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67388118069638 139.73756457305475 9.284 35.6738512656117 139.7375777544092 9.284 35.6738512656117 139.7375777544092 27.809999999999995 35.67388118069638 139.73756457305475 27.809999999999995 35.67388118069638 139.73756457305475 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6738512656117 139.7375777544092 9.284 35.67388552066219 139.73769480895993 9.284 35.67388552066219 139.73769480895993 27.809999999999995 35.6738512656117 139.7375777544092 27.809999999999995 35.6738512656117 139.7375777544092 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67388552066219 139.73769480895993 9.284 35.67389795529173 139.7376893812211 9.284 35.67389795529173 139.7376893812211 27.809999999999995 35.67388552066219 139.73769480895993 27.809999999999995 35.67388552066219 139.73769480895993 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67389795529173 139.7376893812211 9.284 35.67391765852594 139.73775652193314 9.284 35.67391765852594 139.73775652193314 27.809999999999995 35.67389795529173 139.7376893812211 27.809999999999995 35.67389795529173 139.7376893812211 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67391765852594 139.73775652193314 9.284 35.67396442340398 139.7377359192184 9.284 35.67396442340398 139.7377359192184 27.809999999999995 35.67391765852594 139.73775652193314 27.809999999999995 35.67391765852594 139.73775652193314 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67396442340398 139.7377359192184 9.284 35.673944720158374 139.73766877847228 9.284 35.673944720158374 139.73766877847228 27.809999999999995 35.67396442340398 139.7377359192184 27.809999999999995 35.67396442340398 139.7377359192184 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673944720158374 139.73766877847228 9.284 35.67391561603385 139.7376816274284 9.284 35.67391561603385 139.7376816274284 27.809999999999995 35.673944720158374 139.73766877847228 27.809999999999995 35.673944720158374 139.73766877847228 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67391561603385 139.7376816274284 9.284 35.67391055474931 139.73766451101162 9.284 35.67391055474931 139.73766451101162 27.809999999999995 35.67391561603385 139.7376816274284 27.809999999999995 35.67391561603385 139.7376816274284 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67391055474931 139.73766451101162 27.809999999999995 35.673953354893094 139.7376455699902 27.809999999999995 35.673956183621684 139.73765492321266 27.809999999999995 35.67396292345893 139.73765186626494 27.809999999999995 35.67396909603025 139.73767225120505 27.809999999999995 35.6739778091522 139.73766828606966 27.809999999999995 35.67398174948841 139.73768131653895 27.809999999999995 35.67396629652795 139.73768833861843 27.809999999999995 35.67398570892976 139.73775246396974 27.809999999999995 35.6740693261354 139.73771447386247 27.809999999999995 35.674008954330695 139.73751305298418 27.809999999999995 35.673881994303116 139.73756755470305 27.809999999999995 35.67388118069638 139.73756457305475 27.809999999999995 35.6738512656117 139.7375777544092 27.809999999999995 35.67388552066219 139.73769480895993 27.809999999999995 35.67389795529173 139.7376893812211 27.809999999999995 35.67391765852594 139.73775652193314 27.809999999999995 35.67396442340398 139.7377359192184 27.809999999999995 35.673944720158374 139.73766877847228 27.809999999999995 35.67391561603385 139.7376816274284 27.809999999999995 35.67391055474931 139.73766451101162 27.809999999999995</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-34a75055-c6b9-4674-9766-426ae30dd9de"/>
							<gml:surfaceMember xlink:href="#poly-47e4a83f-1209-49c4-b648-5c3f64fcdfd8"/>
							<gml:surfaceMember xlink:href="#poly-b83cd158-e86b-47da-bf90-f2a92444176c"/>
							<gml:surfaceMember xlink:href="#poly-f56649d1-f97b-4ca6-a68c-2a760298fda4"/>
							<gml:surfaceMember xlink:href="#poly-a4a50438-287b-4ab3-b2a6-f8144e66b835"/>
							<gml:surfaceMember xlink:href="#poly-d0c4010c-2b50-48ae-a933-223792552093"/>
							<gml:surfaceMember xlink:href="#poly-e2ae312c-1909-438e-955a-d8e5611bb561"/>
							<gml:surfaceMember xlink:href="#poly-5f5d94ee-ff5c-4f44-af37-502b2f96dd66"/>
							<gml:surfaceMember xlink:href="#poly-1f4919a5-d88e-4e34-83f6-16f1ddb1fc18"/>
							<gml:surfaceMember xlink:href="#poly-c774e76c-1012-4789-885c-e1115fa3fae2"/>
							<gml:surfaceMember xlink:href="#poly-ef1d3c97-d2f9-4cab-98c8-4f3f35e40f0e"/>
							<gml:surfaceMember xlink:href="#poly-ca9de749-0879-410a-9ad8-1fb124e5c1d7"/>
							<gml:surfaceMember xlink:href="#poly-b613bb82-828f-4a0f-b094-6e2ee7282950"/>
							<gml:surfaceMember xlink:href="#poly-7dd3db8d-6747-4135-864d-cc687121fc72"/>
							<gml:surfaceMember xlink:href="#poly-6c4bcbc5-6b43-4c05-9da9-8697ecf9be25"/>
							<gml:surfaceMember xlink:href="#poly-f779c2e3-0147-4fa1-b2bc-28583bcc86a0"/>
							<gml:surfaceMember xlink:href="#poly-01e7b0cf-94d5-4339-8006-3f0e17b486c2"/>
							<gml:surfaceMember xlink:href="#poly-05633114-a4ab-4022-a87f-7af6cd59dd7f"/>
							<gml:surfaceMember xlink:href="#poly-e9ea63c3-886e-42c1-9155-212c5971783a"/>
							<gml:surfaceMember xlink:href="#poly-6a534d13-cbc8-4f31-bad0-c509a72c876b"/>
							<gml:surfaceMember xlink:href="#poly-124137af-9b2f-4ac7-9510-80aef35ca7ff"/>
							<gml:surfaceMember xlink:href="#poly-3aac7a7c-e51d-49bd-9e08-e7f45bf01a92"/>
							<gml:surfaceMember xlink:href="#poly-9859daf2-5ae4-49f5-b2ce-f140795f9d27"/>
							<gml:surfaceMember xlink:href="#poly-b1b4640b-e634-4a3a-a4ac-649e48552116"/>
							<gml:surfaceMember xlink:href="#poly-faca86fe-bdbf-4ca7-846b-3ec057e8db44"/>
							<gml:surfaceMember xlink:href="#poly-e32359f2-4d5f-469f-84fb-79907cde09dc"/>
							<gml:surfaceMember xlink:href="#poly-763f5574-defd-40b6-98ed-6b326d0c2f95"/>
							<gml:surfaceMember xlink:href="#poly-25a6a663-5d81-46a4-b298-6d71360b782d"/>
							<gml:surfaceMember xlink:href="#poly-cbd9529e-98cf-4edd-82e5-b32a7f774f07"/>
							<gml:surfaceMember xlink:href="#poly-4124162f-caae-4943-a998-c7425532fec8"/>
							<gml:surfaceMember xlink:href="#poly-2e6d097d-3a0c-47e1-abc1-d9241938b486"/>
							<gml:surfaceMember xlink:href="#poly-84202d1d-9e53-4b0e-bb88-b01c6c74dbc0"/>
							<gml:surfaceMember xlink:href="#poly-c172df57-7fbb-442f-a5c7-86eac1204657"/>
							<gml:surfaceMember xlink:href="#poly-83bb4823-53ec-49c9-aa50-6cd5984bd852"/>
							<gml:surfaceMember xlink:href="#poly-d880acfe-6519-4530-9feb-d6cc1d94c168"/>
							<gml:surfaceMember xlink:href="#poly-86285264-ed42-4d7a-a19f-8f98e1c54c1f"/>
							<gml:surfaceMember xlink:href="#poly-17b79e80-1584-4978-aa21-4c30c3697ea3"/>
							<gml:surfaceMember xlink:href="#poly-d788b026-1861-4d37-8ed4-5e3e7cd07de8"/>
							<gml:surfaceMember xlink:href="#poly-6e71e6a7-623a-48d3-82ff-906909c40711"/>
							<gml:surfaceMember xlink:href="#poly-66e0879e-23f6-4015-8c42-d0b6803cd2bc"/>
							<gml:surfaceMember xlink:href="#poly-cb8bd992-fd89-4e41-8ce4-8a4776f6207f"/>
							<gml:surfaceMember xlink:href="#poly-942bd138-ef12-40fe-bf1b-c6e66acbcb39"/>
							<gml:surfaceMember xlink:href="#poly-59fcb656-5a5a-47c6-8b01-69322c8f65d0"/>
							<gml:surfaceMember xlink:href="#poly-2ea3d3fc-3526-485c-843e-585eeb8171ec"/>
							<gml:surfaceMember xlink:href="#poly-88a62277-f41e-44bf-8325-a780ec88300c"/>
							<gml:surfaceMember xlink:href="#poly-0fab7894-1797-4d5f-b7eb-faa347318a92"/>
							<gml:surfaceMember xlink:href="#poly-ef7cc9e0-9cf7-4cc0-b829-23c392a4dcb9"/>
							<gml:surfaceMember xlink:href="#poly-d2e81ed2-efeb-4217-be2e-52c07b26bd8f"/>
							<gml:surfaceMember xlink:href="#poly-e4d237da-cfe9-4329-a6f2-ac4148da4b49"/>
							<gml:surfaceMember xlink:href="#poly-27224bd0-2953-44d3-b8c1-3d2e4fa3c355"/>
							<gml:surfaceMember xlink:href="#poly-0643b12e-69fe-4b65-ac1e-b88c4c7ab81c"/>
							<gml:surfaceMember xlink:href="#poly-be222ca4-0e2c-4f06-a7af-8ebe29600528"/>
							<gml:surfaceMember xlink:href="#poly-7ab27e24-aac7-455b-90b7-8768121d862e"/>
							<gml:surfaceMember xlink:href="#poly-8158a636-d55c-4afa-a10a-9f0ab8fc18a4"/>
							<gml:surfaceMember xlink:href="#poly-7934e9a9-f719-4260-bb4a-6428348d9c1f"/>
							<gml:surfaceMember xlink:href="#poly-a00bd28b-cdef-4a5e-875d-03ed261e734c"/>
							<gml:surfaceMember xlink:href="#poly-a063623a-b454-4543-92ac-5b9b8fbf2aed"/>
							<gml:surfaceMember xlink:href="#poly-6b5cca93-edc1-4ee8-832c-42942ff14c27"/>
							<gml:surfaceMember xlink:href="#poly-40cb66e3-9606-4a4f-b6a1-785d467ca419"/>
							<gml:surfaceMember xlink:href="#poly-d8551bc0-2617-4990-8e3b-e3aca0847de7"/>
							<gml:surfaceMember xlink:href="#poly-e471f824-4b2d-4d3d-8157-89f553b3a4a8"/>
							<gml:surfaceMember xlink:href="#poly-b09163b0-9909-46e9-acf5-26472422046e"/>
							<gml:surfaceMember xlink:href="#poly-3672204a-5e06-4a14-b9d9-fb80d4f4d363"/>
							<gml:surfaceMember xlink:href="#poly-8cad046c-fd0d-415f-b46a-7a0c4ee2222c"/>
							<gml:surfaceMember xlink:href="#poly-f62fc9b0-e89a-4d1c-b87e-abb1cb36936c"/>
							<gml:surfaceMember xlink:href="#poly-50958cdd-5950-45d3-91b9-2b6f3656bbd4"/>
							<gml:surfaceMember xlink:href="#poly-1ce8f536-7e81-4450-80cc-b14b0b4ba3c2"/>
							<gml:surfaceMember xlink:href="#poly-b9a7c97a-680e-49d9-9f86-8a43725e61a3"/>
							<gml:surfaceMember xlink:href="#poly-3e558dd9-1208-491f-afc5-5ee610be7238"/>
							<gml:surfaceMember xlink:href="#poly-4b3e6dfb-70e0-4a3e-b347-5321d6796651"/>
							<gml:surfaceMember xlink:href="#poly-2020cbd4-6801-4584-86a8-2ce8e3dd7a8b"/>
							<gml:surfaceMember xlink:href="#poly-550e16cf-27c0-45fc-9c00-334833e39daa"/>
							<gml:surfaceMember xlink:href="#poly-c26b392f-2734-4358-8385-fcefa06fbbc8"/>
							<gml:surfaceMember xlink:href="#poly-e4a1e376-56b4-411b-8451-c30fa2f5a007"/>
							<gml:surfaceMember xlink:href="#poly-9c05d0f6-8948-4206-9bce-17da91278f8a"/>
							<gml:surfaceMember xlink:href="#poly-53585c8e-915c-4477-8cac-49b87f5e5f0b"/>
							<gml:surfaceMember xlink:href="#poly-f99e1adc-a92d-4343-9f4b-d7d9a7cf24fe"/>
							<gml:surfaceMember xlink:href="#poly-cd79d766-2ac6-4306-8298-c39085e72126"/>
							<gml:surfaceMember xlink:href="#poly-3cd4ae3f-c5e5-4e99-a377-f41df626bed4"/>
							<gml:surfaceMember xlink:href="#poly-8dc49697-fbc7-43bc-bc55-2ec060bf23f8"/>
							<gml:surfaceMember xlink:href="#poly-7e52a9fb-45f3-484b-a1bd-10b7fecbe25c"/>
							<gml:surfaceMember xlink:href="#poly-df6443c6-db31-41e4-a953-1da2a75743e8"/>
							<gml:surfaceMember xlink:href="#poly-83e572aa-614b-44ae-91ca-a8d12ac463b9"/>
							<gml:surfaceMember xlink:href="#poly-1ea29353-1851-42f7-a3dc-a151b07a7077"/>
							<gml:surfaceMember xlink:href="#poly-6c9f032b-0f53-4926-a176-3407733f9c6f"/>
							<gml:surfaceMember xlink:href="#poly-c436fd7a-589b-4e0a-9dac-12abfb422d73"/>
							<gml:surfaceMember xlink:href="#poly-bf646cdc-e7c5-4b07-9d56-9cfd19348e02"/>
							<gml:surfaceMember xlink:href="#poly-072b1445-1989-423a-9b39-28760e1c9a28"/>
							<gml:surfaceMember xlink:href="#poly-ae60b8c9-c155-42e4-b1ee-f45968ebbd9e"/>
							<gml:surfaceMember xlink:href="#poly-c8d45a22-8901-4287-8aa1-92bdebe0bc46"/>
							<gml:surfaceMember xlink:href="#poly-7a5eb229-5b8d-4ed0-80f9-13261c008080"/>
							<gml:surfaceMember xlink:href="#poly-40d14a11-7bc5-430c-b332-80a6b1feedb1"/>
							<gml:surfaceMember xlink:href="#poly-a8f8eac1-cdea-4ef2-9437-c7bfc4a5ac31"/>
							<gml:surfaceMember xlink:href="#poly-1396a70b-6b86-468b-a9f6-6e50d4c55b46"/>
							<gml:surfaceMember xlink:href="#poly-464bc3d0-0a51-4237-8eb8-a365cfdf9ae7"/>
							<gml:surfaceMember xlink:href="#poly-ed7dd6dc-7a26-4663-aa16-16fea38d6632"/>
							<gml:surfaceMember xlink:href="#poly-01db3bb2-473b-4595-9481-14148b8ec7a1"/>
							<gml:surfaceMember xlink:href="#poly-af6ceb41-3397-4946-87bf-64b05b3c7cf4"/>
							<gml:surfaceMember xlink:href="#poly-54cfe3b4-2e0e-4beb-847a-53da19a834a7"/>
							<gml:surfaceMember xlink:href="#poly-a1305a7a-e604-465e-b95c-a77a8540c973"/>
							<gml:surfaceMember xlink:href="#poly-e7770348-5764-4a6a-aee6-d196c3c9760a"/>
							<gml:surfaceMember xlink:href="#poly-648d5e20-e3e2-4671-8018-bf4314878279"/>
							<gml:surfaceMember xlink:href="#poly-83a671a2-1058-4ee7-a0cb-1aa0d142827c"/>
							<gml:surfaceMember xlink:href="#poly-d24790c9-1314-4091-9327-9770e1b59dde"/>
							<gml:surfaceMember xlink:href="#poly-28a2e080-17d2-41c2-920b-8bb0b005ca47"/>
							<gml:surfaceMember xlink:href="#poly-c62b20af-8570-446d-bb8a-c9ec0de6732e"/>
							<gml:surfaceMember xlink:href="#poly-21ba23f0-ed27-4895-b538-dd8a3830bd24"/>
							<gml:surfaceMember xlink:href="#poly-9b15fd87-7803-48b2-bba7-6d7342efdd8c"/>
							<gml:surfaceMember xlink:href="#poly-b4cdc9bc-f207-44ee-901e-81c201b8cdb5"/>
							<gml:surfaceMember xlink:href="#poly-1f0233f0-628c-48c4-924c-7c07018d6d66"/>
							<gml:surfaceMember xlink:href="#poly-d92e200d-121d-40d3-a99f-10b7f3b2b93f"/>
							<gml:surfaceMember xlink:href="#poly-19669777-6350-4836-aecf-f0fdd1faabdb"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ff4a91a8-29e0-43b1-b1fc-14af2a22e3e4_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b2caa79-91a4-476e-98f1-37be770c948a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67397780915215 139.73766828606966 9.39 35.673981749488405 139.73768131653893 9.39 35.67396629652793 139.7376883386184 9.39 35.67395618362166 139.73765492321263 9.39 35.67396292345893 139.73765186626494 9.39 35.67396909603022 139.73767225120503 9.39 35.67397780915215 139.73766828606966 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84fc74a3-064e-439a-b0f4-4f64d5c13020">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84fc74a3-064e-439a-b0f4-4f64d5c13020_0">
											<gml:posList>35.67395618362166 139.73765492321263 30.171 35.67396292345893 139.73765186626494 30.171 35.67396292345893 139.73765186626494 9.39 35.67395618362166 139.73765492321263 9.39 35.67395618362166 139.73765492321263 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79a9abbb-f7ce-4f84-b522-f7b9d680f32d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79a9abbb-f7ce-4f84-b522-f7b9d680f32d_0">
											<gml:posList>35.67396629652793 139.7376883386184 30.171 35.67395618362166 139.73765492321263 30.171 35.67395618362166 139.73765492321263 9.39 35.67396629652793 139.7376883386184 9.39 35.67396629652793 139.7376883386184 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6f5bc64-c349-4712-80a0-3a789733c6d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6f5bc64-c349-4712-80a0-3a789733c6d1_0">
											<gml:posList>35.67396292345893 139.73765186626494 30.171 35.67396909603022 139.73767225120503 30.171 35.67396909603022 139.73767225120503 9.39 35.67396292345893 139.73765186626494 9.39 35.67396292345893 139.73765186626494 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec070893-f785-4fdd-b7a2-fd62a4c95418">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec070893-f785-4fdd-b7a2-fd62a4c95418_0">
											<gml:posList>35.67396292345893 139.73765186626494 30.171 35.67395618362166 139.73765492321263 30.171 35.67396629652793 139.7376883386184 30.171 35.673981749488405 139.73768131653893 30.171 35.67397780915215 139.73766828606966 30.171 35.67396909603022 139.73767225120503 30.171 35.67396292345893 139.73765186626494 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2aaebbaa-9525-4991-b9e3-46b39d342fed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2aaebbaa-9525-4991-b9e3-46b39d342fed_0">
											<gml:posList>35.67396909603022 139.73767225120503 30.171 35.67397780915215 139.73766828606966 30.171 35.67397780915215 139.73766828606966 9.39 35.67396909603022 139.73767225120503 9.39 35.67396909603022 139.73767225120503 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6eefe87-a833-4d1f-9d44-e8c7a1d54adf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6eefe87-a833-4d1f-9d44-e8c7a1d54adf_0">
											<gml:posList>35.673981749488405 139.73768131653893 30.171 35.67396629652793 139.7376883386184 30.171 35.67396629652793 139.7376883386184 9.39 35.673981749488405 139.73768131653893 9.39 35.673981749488405 139.73768131653893 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b23b180-f41e-4c9f-9517-56587487d226">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b23b180-f41e-4c9f-9517-56587487d226_0">
											<gml:posList>35.67397780915215 139.73766828606966 30.171 35.673981749488405 139.73768131653893 30.171 35.673981749488405 139.73768131653893 9.39 35.67397780915215 139.73766828606966 9.39 35.67397780915215 139.73766828606966 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ff4a91a8-29e0-43b1-b1fc-14af2a22e3e4_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90184826-ae2e-4831-b962-6995ff5f4af9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90184826-ae2e-4831-b962-6995ff5f4af9_0">
											<gml:posList>35.67401632833701 139.73762736709114 37.948 35.67399402742231 139.7376375014975 35.962 35.67399402742231 139.7376375014975 37.948 35.67401632833701 139.73762736709114 37.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3c06894-2913-40c0-8d86-6a7e4664f2e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3c06894-2913-40c0-8d86-6a7e4664f2e8_0">
											<gml:posList>35.67401632833701 139.73762736709114 37.948 35.67401632833701 139.73762736709114 35.962 35.67399402742231 139.7376375014975 35.962 35.67401632833701 139.73762736709114 37.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1764d9d-e2dd-4e2d-b56b-6cd2cd4364cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1764d9d-e2dd-4e2d-b56b-6cd2cd4364cf_0">
											<gml:posList>35.67401632833701 139.73762736709114 37.948 35.67402302507741 139.73764947471204 35.962 35.67401632833701 139.73762736709114 35.962 35.67401632833701 139.73762736709114 37.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee6a6273-c16c-45bc-8ed2-44e16f290cbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee6a6273-c16c-45bc-8ed2-44e16f290cbb_0">
											<gml:posList>35.67401632833701 139.73762736709114 37.948 35.67402302507741 139.73764947471204 37.948 35.67402302507741 139.73764947471204 35.962 35.67401632833701 139.73762736709114 37.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e747df16-bdd8-4d6a-bd4f-199ee80ecad6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e747df16-bdd8-4d6a-bd4f-199ee80ecad6_0">
											<gml:posList>35.67395190930974 139.73764130766966 26.459 35.673948593596464 139.7376429907336 26.144 35.67395190930974 139.73764130766966 26.144 35.67395190930974 139.73764130766966 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43584025-3fb6-4e98-932b-2cf93a198a33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43584025-3fb6-4e98-932b-2cf93a198a33_0">
											<gml:posList>35.67395190930974 139.73764130766966 26.459 35.673948593596464 139.7376429907336 26.459 35.673948593596464 139.7376429907336 26.144 35.67395190930974 139.73764130766966 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cdfb16f-a4cf-4219-bed1-044505738b27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6cdfb16f-a4cf-4219-bed1-044505738b27_0">
											<gml:posList>35.67395190930974 139.73764130766966 26.459 35.67395139431637 139.7376397838327 28.067 35.67395311095212 139.7376448522425 28.067 35.67395190930974 139.73764130766966 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58f9198d-be33-4056-9785-7bff6e688eb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58f9198d-be33-4056-9785-7bff6e688eb7_0">
											<gml:posList>35.67395311095212 139.7376448522425 28.067 35.67395311095212 139.7376448522425 26.459 35.67395190930974 139.73764130766966 26.459 35.67395311095212 139.7376448522425 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-894a6f20-ebfb-4cca-a37f-49c70ddf7cca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-894a6f20-ebfb-4cca-a37f-49c70ddf7cca_0">
											<gml:posList>35.673951394333926 139.7376398059262 26.144 35.67395139431637 139.7376397838327 28.067 35.67395190930974 139.73764130766966 26.459 35.673951394333926 139.7376398059262 26.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a857ad5-2490-41c2-ac2a-d0dc719bd638">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a857ad5-2490-41c2-ac2a-d0dc719bd638_0">
											<gml:posList>35.67395190930974 139.73764130766966 26.144 35.673951394333926 139.7376398059262 26.144 35.67395190930974 139.73764130766966 26.459 35.67395190930974 139.73764130766966 26.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09ebaa3d-949f-4723-a30a-604df8968d99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09ebaa3d-949f-4723-a30a-604df8968d99_0">
											<gml:posList>35.673908718722494 139.7376453139593 26.144 35.673908718722494 139.7376453139593 26.459 35.673919837750965 139.7376403959319 26.144 35.673908718722494 139.7376453139593 26.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bd366ff-0a0d-4817-8aab-66bed86426dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bd366ff-0a0d-4817-8aab-66bed86426dc_0">
											<gml:posList>35.673919837750965 139.7376403959319 26.144 35.673908718722494 139.7376453139593 26.459 35.673919837750965 139.7376403959319 28.067 35.673919837750965 139.7376403959319 26.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9345e41f-6be7-4579-ae01-ce03e79122dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9345e41f-6be7-4579-ae01-ce03e79122dc_0">
											<gml:posList>35.673919837750965 139.7376403959319 28.067 35.673908718722494 139.7376453139593 26.459 35.67390830424076 139.73764550224868 28.067 35.673919837750965 139.7376403959319 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8783b79-09c5-41e5-a4d2-d629acc9f7d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8783b79-09c5-41e5-a4d2-d629acc9f7d4_0">
											<gml:posList>35.673908718722494 139.7376453139593 26.459 35.67390830424076 139.73764550224868 26.459 35.67390830424076 139.73764550224868 28.067 35.673908718722494 139.7376453139593 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67d8aeb8-5b1c-4108-90f9-3e831847ac51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67d8aeb8-5b1c-4108-90f9-3e831847ac51_0">
											<gml:posList>35.674000715147166 139.73765960912385 37.948 35.67401632833701 139.73762736709114 37.948 35.67399402742231 139.7376375014975 37.948 35.674000715147166 139.73765960912385 37.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e93731f-076c-461e-a62c-04e7c91b2e95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e93731f-076c-461e-a62c-04e7c91b2e95_0">
											<gml:posList>35.674000715147166 139.73765960912385 37.948 35.67402302507741 139.73764947471204 37.948 35.67401632833701 139.73762736709114 37.948 35.674000715147166 139.73765960912385 37.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66ef94a7-017c-4843-87ac-dcb18c854267">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66ef94a7-017c-4843-87ac-dcb18c854267_0">
											<gml:posList>35.67395137627137 139.73763976176073 28.067 35.673923308385056 139.73765217866853 26.144 35.673923308385056 139.73765217866853 28.067 35.67395137627137 139.73763976176073 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dbe4798-8a3a-4cf0-a675-03f944db9fb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dbe4798-8a3a-4cf0-a675-03f944db9fb1_0">
											<gml:posList>35.67395137627137 139.73763976176073 28.067 35.67395137627137 139.73763976176073 26.144 35.673923308385056 139.73765217866853 26.144 35.67395137627137 139.73763976176073 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ae465ff-5524-46fc-b00b-9517a1a78c23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ae465ff-5524-46fc-b00b-9517a1a78c23_0">
											<gml:posList>35.673919837750965 139.7376403959319 28.067 35.673923308385056 139.73765217866853 26.144 35.673919837750965 139.7376403959319 26.144 35.673919837750965 139.7376403959319 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e7884b5-2b3b-459c-9b2c-30327ad597a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e7884b5-2b3b-459c-9b2c-30327ad597a5_0">
											<gml:posList>35.673919837750965 139.7376403959319 28.067 35.673923308385056 139.73765217866853 28.067 35.673923308385056 139.73765217866853 26.144 35.673919837750965 139.7376403959319 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4b824e9-f23f-4342-bd32-aa46a0391733">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4b824e9-f23f-4342-bd32-aa46a0391733_0">
											<gml:posList>35.674000715147166 139.73765960912385 37.948 35.67399402742231 139.7376375014975 35.962 35.674000715147166 139.73765960912385 35.962 35.674000715147166 139.73765960912385 37.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-138af20d-f1f2-4349-8d1c-c33b24997bef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-138af20d-f1f2-4349-8d1c-c33b24997bef_0">
											<gml:posList>35.674000715147166 139.73765960912385 37.948 35.67399402742231 139.7376375014975 37.948 35.67399402742231 139.7376375014975 35.962 35.674000715147166 139.73765960912385 37.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55f03f2b-3996-4736-bc34-5b4f37d22e6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55f03f2b-3996-4736-bc34-5b4f37d22e6a_0">
											<gml:posList>35.673948593596464 139.7376429907336 26.459 35.673912713564874 139.73765887459496 26.144 35.673948593596464 139.7376429907336 26.144 35.673948593596464 139.7376429907336 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ceeb2b76-11ba-4110-b940-7b568ebbc5f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ceeb2b76-11ba-4110-b940-7b568ebbc5f6_0">
											<gml:posList>35.673948593596464 139.7376429907336 26.459 35.673912713564874 139.73765887459496 26.459 35.673912713564874 139.73765887459496 26.144 35.673948593596464 139.7376429907336 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f13fc8a-1dc0-40da-ad37-644795c23285">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f13fc8a-1dc0-40da-ad37-644795c23285_0">
											<gml:posList>35.673908718722494 139.7376453139593 26.144 35.673912713564874 139.73765887459496 26.459 35.673908718722494 139.7376453139593 26.459 35.673908718722494 139.7376453139593 26.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba6941bd-57e9-4b3b-b910-3089ebddf7cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba6941bd-57e9-4b3b-b910-3089ebddf7cb_0">
											<gml:posList>35.673908718722494 139.7376453139593 26.144 35.673912713564874 139.73765887459496 26.144 35.673912713564874 139.73765887459496 26.459 35.673908718722494 139.7376453139593 26.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29dc4493-df6a-4ba9-9dd6-bd7192da4d30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29dc4493-df6a-4ba9-9dd6-bd7192da4d30_0">
											<gml:posList>35.67391352757303 139.73766236439522 28.067 35.67395311095212 139.7376448522425 26.459 35.67395311095212 139.7376448522425 28.067 35.67391352757303 139.73766236439522 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d61264d-9571-4593-be8c-1131ce36f6c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d61264d-9571-4593-be8c-1131ce36f6c6_0">
											<gml:posList>35.67391352757303 139.73766236439522 28.067 35.67391352757303 139.73766236439522 26.459 35.67395311095212 139.7376448522425 26.459 35.67391352757303 139.73766236439522 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67d13439-e52d-442a-ae34-b84fceaac389">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67d13439-e52d-442a-ae34-b84fceaac389_0">
											<gml:posList>35.67390830424076 139.73764550224868 28.067 35.67391352757303 139.73766236439522 26.459 35.67391352757303 139.73766236439522 28.067 35.67390830424076 139.73764550224868 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19060065-19de-4a0d-972f-8f13d778a2fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19060065-19de-4a0d-972f-8f13d778a2fc_0">
											<gml:posList>35.67390830424076 139.73764550224868 28.067 35.67390830424076 139.73764550224868 26.459 35.67391352757303 139.73766236439522 26.459 35.67390830424076 139.73764550224868 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-652c51dc-4eb1-4177-8861-55ff86bb4d5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-652c51dc-4eb1-4177-8861-55ff86bb4d5d_0">
											<gml:posList>35.674000715147166 139.73765960912385 37.948 35.67402302507741 139.73764947471204 35.962 35.67402302507741 139.73764947471204 37.948 35.674000715147166 139.73765960912385 37.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-292fa91b-6879-4ce2-ac65-575cabc35159">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-292fa91b-6879-4ce2-ac65-575cabc35159_0">
											<gml:posList>35.674000715147166 139.73765960912385 37.948 35.674000715147166 139.73765960912385 35.962 35.67402302507741 139.73764947471204 35.962 35.674000715147166 139.73765960912385 37.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7ed4482-75c1-48d7-a833-40c32e807e2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7ed4482-75c1-48d7-a833-40c32e807e2e_0">
											<gml:posList>35.67400706912424 139.73767007386823 32.658 35.67402836987019 139.73766038253336 29.579 35.67400706912424 139.73767007386823 29.579 35.67400706912424 139.73767007386823 32.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d83f23ac-4b20-4c10-b359-6824bee3a4da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d83f23ac-4b20-4c10-b359-6824bee3a4da_0">
											<gml:posList>35.67400706912424 139.73767007386823 32.658 35.67402836987019 139.73766038253336 32.658 35.67402836987019 139.73766038253336 29.579 35.67400706912424 139.73767007386823 32.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4465d72f-fe83-4128-9401-558182242b45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4465d72f-fe83-4128-9401-558182242b45_0">
											<gml:posList>35.67402836987019 139.73766038253336 32.658 35.67404209775476 139.73770574625553 29.579 35.67402836987019 139.73766038253336 29.579 35.67402836987019 139.73766038253336 32.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91c7cc17-68fa-41e9-a394-e0795075e633">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91c7cc17-68fa-41e9-a394-e0795075e633_0">
											<gml:posList>35.67402836987019 139.73766038253336 32.658 35.67404209775476 139.73770574625553 32.658 35.67404209775476 139.73770574625553 29.579 35.67402836987019 139.73766038253336 32.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-257232e9-77c7-435c-b535-47681d8a60fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-257232e9-77c7-435c-b535-47681d8a60fa_0">
											<gml:posList>35.67400706912424 139.73767007386823 32.658 35.67402079699641 139.73771542653324 32.658 35.67404209775476 139.73770574625553 32.658 35.67400706912424 139.73767007386823 32.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-feb27a98-bc2b-4a6f-83dc-571cf400de75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-feb27a98-bc2b-4a6f-83dc-571cf400de75_0">
											<gml:posList>35.67402836987019 139.73766038253336 32.658 35.67400706912424 139.73767007386823 32.658 35.67404209775476 139.73770574625553 32.658 35.67402836987019 139.73766038253336 32.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9b505fb-b05f-4299-ab5c-49679714af77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9b505fb-b05f-4299-ab5c-49679714af77_0">
											<gml:posList>35.67400706912424 139.73767007386823 32.658 35.67402079699641 139.73771542653324 29.579 35.67402079699641 139.73771542653324 32.658 35.67400706912424 139.73767007386823 32.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6257726b-ee73-4e2a-9025-fb8e01050ae1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6257726b-ee73-4e2a-9025-fb8e01050ae1_0">
											<gml:posList>35.67400706912424 139.73767007386823 32.658 35.67400706912424 139.73767007386823 29.579 35.67402079699641 139.73771542653324 29.579 35.67400706912424 139.73767007386823 32.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41119cd6-ee60-4b9b-a553-f98ad7fc76fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41119cd6-ee60-4b9b-a553-f98ad7fc76fb_0">
											<gml:posList>35.67404209775476 139.73770574625553 32.658 35.67402079699641 139.73771542653324 29.579 35.67404209775476 139.73770574625553 29.579 35.67404209775476 139.73770574625553 32.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb77db1a-7ae0-4631-8ca4-6d5678ceb363">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb77db1a-7ae0-4631-8ca4-6d5678ceb363_0">
											<gml:posList>35.67404209775476 139.73770574625553 32.658 35.67402079699641 139.73771542653324 32.658 35.67402079699641 139.73771542653324 29.579 35.67404209775476 139.73770574625553 32.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-745ae9f8-163f-486e-b8ea-8c4d3fb47745">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-745ae9f8-163f-486e-b8ea-8c4d3fb47745_0">
											<gml:posList>35.673919837750965 139.7376403959319 28.067 35.67390830424076 139.73764550224868 28.067 35.673923308385056 139.73765217866853 28.067 35.673919837750965 139.7376403959319 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2835ccfe-35a9-4c02-b3f4-d401ec34eaa5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2835ccfe-35a9-4c02-b3f4-d401ec34eaa5_0">
											<gml:posList>35.67390830424076 139.73764550224868 28.067 35.67391352757303 139.73766236439522 28.067 35.673923308385056 139.73765217866853 28.067 35.67390830424076 139.73764550224868 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8739e00d-c71e-4d4d-ba62-a8e4e16e6431">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8739e00d-c71e-4d4d-ba62-a8e4e16e6431_0">
											<gml:posList>35.673923308385056 139.73765217866853 28.067 35.67395311095212 139.7376448522425 28.067 35.67395137627137 139.73763976176073 28.067 35.673923308385056 139.73765217866853 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-750547c4-8521-4c1b-afe5-4f746016a2f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-750547c4-8521-4c1b-afe5-4f746016a2f6_0">
											<gml:posList>35.673923308385056 139.73765217866853 28.067 35.67391352757303 139.73766236439522 28.067 35.67395311095212 139.7376448522425 28.067 35.673923308385056 139.73765217866853 28.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8af87c1e-c861-4c0a-942f-b5525d806e07">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67390830424076 139.73764550224868 26.459 35.673908718722494 139.7376453139593 26.459 35.673912713564874 139.73765887459496 26.459 35.67390830424076 139.73764550224868 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53782501-66a2-4ff3-9cd2-b6d0f3fe9d5f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67390830424076 139.73764550224868 26.459 35.673912713564874 139.73765887459496 26.459 35.67391352757303 139.73766236439522 26.459 35.67390830424076 139.73764550224868 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ae1206b-eba2-46f3-966e-9a9307335b24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67391352757303 139.73766236439522 26.459 35.673948593596464 139.7376429907336 26.459 35.67395311095212 139.7376448522425 26.459 35.67391352757303 139.73766236439522 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c0511ef-b2e9-4f56-8fb1-fc1a3e8adbd6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673948593596464 139.7376429907336 26.459 35.67395190930974 139.73764130766966 26.459 35.67395311095212 139.7376448522425 26.459 35.673948593596464 139.7376429907336 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-243d7d03-5ad0-4d5d-8952-377f4c1daf6f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673912713564874 139.73765887459496 26.459 35.673948593596464 139.7376429907336 26.459 35.67391352757303 139.73766236439522 26.459 35.673912713564874 139.73765887459496 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6200552-e427-416d-8d05-d13a20eafe39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674000715147166 139.73765960912385 35.962 35.67401632833701 139.73762736709114 35.962 35.67402302507741 139.73764947471204 35.962 35.674000715147166 139.73765960912385 35.962</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbee1de6-97bb-444d-83dd-d720e94bd21f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674000715147166 139.73765960912385 35.962 35.67399402742231 139.7376375014975 35.962 35.67401632833701 139.73762736709114 35.962 35.674000715147166 139.73765960912385 35.962</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c6e7759-849e-4cf6-8571-65606a4c9857">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67404209775476 139.73770574625553 29.579 35.67402079699641 139.73771542653324 29.579 35.67400706912424 139.73767007386823 29.579 35.67404209775476 139.73770574625553 29.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82029053-fbdc-47c1-bbd7-5e860494a894">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67402836987019 139.73766038253336 29.579 35.67404209775476 139.73770574625553 29.579 35.67400706912424 139.73767007386823 29.579 35.67402836987019 139.73766038253336 29.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7119bbd4-52c4-4dad-abd1-a6b156c15ae9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673912713564874 139.73765887459496 26.144 35.673908718722494 139.7376453139593 26.144 35.673923308385056 139.73765217866853 26.144 35.673912713564874 139.73765887459496 26.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efb1912c-fe4c-4a1f-bb0d-0202cefe3774">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673908718722494 139.7376453139593 26.144 35.673919837750965 139.7376403959319 26.144 35.673923308385056 139.73765217866853 26.144 35.673908718722494 139.7376453139593 26.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9133f8e-1d26-4b9c-ab39-efb8a82fed27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673948593596464 139.7376429907336 26.144 35.673912713564874 139.73765887459496 26.144 35.673923308385056 139.73765217866853 26.144 35.673948593596464 139.7376429907336 26.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aef59331-d7b5-4744-8b91-d1bff3725981">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673951394333926 139.7376398059262 26.144 35.67395190930974 139.73764130766966 26.144 35.673948593596464 139.7376429907336 26.144 35.673951394333926 139.7376398059262 26.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7b1cbad-7be3-485b-9a20-f12f523ce48d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673951394333926 139.7376398059262 26.144 35.673948593596464 139.7376429907336 26.144 35.673923308385056 139.73765217866853 26.144 35.673951394333926 139.7376398059262 26.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-34a75055-c6b9-4674-9766-426ae30dd9de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34a75055-c6b9-4674-9766-426ae30dd9de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34a75055-c6b9-4674-9766-426ae30dd9de">
											<gml:posList>35.67385126561173 139.7375777544092 9.284 35.67388118069636 139.73756457305475 9.284 35.67388199430311 139.73756755470305 9.284 35.67400895433068 139.73751305298418 9.284 35.674069326135395 139.73771447386247 9.284 35.67398570892977 139.73775246396974 9.284 35.67396629652793 139.7376883386184 9.284 35.673981749488405 139.73768131653893 9.284 35.67397780915215 139.73766828606966 9.284 35.67396909603022 139.73767225120503 9.284 35.67396292345893 139.73765186626494 9.284 35.67395618362166 139.73765492321263 9.284 35.673953354893094 139.73764556999018 9.284 35.6739105547493 139.73766451101162 9.284 35.67391561603384 139.73768162742837 9.284 35.67394472015837 139.73766877847228 9.284 35.67396442340398 139.7377359192184 9.284 35.67391765852593 139.73775652193314 9.284 35.673897955291714 139.73768938122106 9.284 35.67388552066216 139.73769480895993 9.284 35.67385126561173 139.7375777544092 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47e4a83f-1209-49c4-b648-5c3f64fcdfd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47e4a83f-1209-49c4-b648-5c3f64fcdfd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47e4a83f-1209-49c4-b648-5c3f64fcdfd8">
											<gml:posList>35.67400895433068 139.73751305298418 20.436 35.67388199430311 139.73756755470305 20.436 35.67388547398439 139.73757937056038 20.436 35.67401237058725 139.73752444915678 20.436 35.67400895433068 139.73751305298418 20.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b83cd158-e86b-47da-bf90-f2a92444176c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b83cd158-e86b-47da-bf90-f2a92444176c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b83cd158-e86b-47da-bf90-f2a92444176c">
											<gml:posList>35.67401237058725 139.73752444915678 23.156 35.67388547398439 139.73757937056038 23.156 35.67388639587836 139.73758250673401 23.156 35.6738908245456 139.73759752501476 23.156 35.674017838414066 139.73754270291695 23.156 35.67401237058725 139.73752444915678 23.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f56649d1-f97b-4ca6-a68c-2a760298fda4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f56649d1-f97b-4ca6-a68c-2a760298fda4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f56649d1-f97b-4ca6-a68c-2a760298fda4">
											<gml:posList>35.674026009659556 139.7375827487103 26.459 35.67402724781529 139.7375868676736 26.459 35.674030626755524 139.73758535023157 26.459 35.674017838414066 139.73754270291695 26.459 35.674015679577614 139.73754830620388 26.459 35.674026009659556 139.7375827487103 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4a50438-287b-4ab3-b2a6-f8144e66b835">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4a50438-287b-4ab3-b2a6-f8144e66b835">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4a50438-287b-4ab3-b2a6-f8144e66b835">
											<gml:posList>35.6738908245456 139.73759752501476 26.459 35.67389543268911 139.7376002038704 26.459 35.674015679577614 139.73754830620388 26.459 35.674017838414066 139.73754270291695 26.459 35.6738908245456 139.73759752501476 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0c4010c-2b50-48ae-a933-223792552093">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0c4010c-2b50-48ae-a933-223792552093">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0c4010c-2b50-48ae-a933-223792552093">
											<gml:posList>35.67385126561173 139.7375777544092 19.087 35.67385652588671 139.73759572116901 19.087 35.67388639587836 139.73758250673401 19.087 35.67388199430311 139.73756755470305 19.087 35.67388118069636 139.73756457305475 19.087 35.67385126561173 139.7375777544092 19.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2ae312c-1909-438e-955a-d8e5611bb561">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2ae312c-1909-438e-955a-d8e5611bb561">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2ae312c-1909-438e-955a-d8e5611bb561">
											<gml:posList>35.67385652588671 139.73759572116901 22.184 35.67386168411293 139.73759870867516 22.184 35.67388396720824 139.73758883941792 22.184 35.67388639587836 139.73758250673401 22.184 35.67385652588671 139.73759572116901 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f5d94ee-ff5c-4f44-af37-502b2f96dd66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f5d94ee-ff5c-4f44-af37-502b2f96dd66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f5d94ee-ff5c-4f44-af37-502b2f96dd66">
											<gml:posList>35.6738908245456 139.73759752501476 22.184 35.67388639587836 139.73758250673401 22.184 35.67388396720824 139.73758883941792 22.184 35.67388702209219 139.7375992086605 22.184 35.6738908245456 139.73759752501476 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f4919a5-d88e-4e34-83f6-16f1ddb1fc18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f4919a5-d88e-4e34-83f6-16f1ddb1fc18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f4919a5-d88e-4e34-83f6-16f1ddb1fc18">
											<gml:posList>35.6738908245456 139.73759752501476 22.184 35.67388702209219 139.7375992086605 22.184 35.67388722996101 139.73759990435704 22.184 35.673891032414424 139.73759822071133 22.184 35.6738908245456 139.73759752501476 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c774e76c-1012-4789-885c-e1115fa3fae2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c774e76c-1012-4789-885c-e1115fa3fae2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c774e76c-1012-4789-885c-e1115fa3fae2">
											<gml:posList>35.67394586497998 139.73762350752278 26.144 35.67402724781529 139.7375868676736 26.144 35.674026009659556 139.7375827487103 26.144 35.674015679577614 139.73754830620388 26.144 35.67389543268911 139.7376002038704 26.144 35.673912713564874 139.73765887459496 26.144 35.673948593596464 139.7376429907336 26.144 35.67395190930974 139.73764130766966 26.144 35.67394586497998 139.73762350752278 26.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef1d3c97-d2f9-4cab-98c8-4f3f35e40f0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef1d3c97-d2f9-4cab-98c8-4f3f35e40f0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef1d3c97-d2f9-4cab-98c8-4f3f35e40f0e">
											<gml:posList>35.67394586497998 139.73762350752278 30.171 35.673951194369465 139.73762637331546 30.171 35.674028243153906 139.73759168287296 30.171 35.674030626755524 139.73758535023157 30.171 35.67394586497998 139.73762350752278 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca9de749-0879-410a-9ad8-1fb124e5c1d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca9de749-0879-410a-9ad8-1fb124e5c1d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca9de749-0879-410a-9ad8-1fb124e5c1d7">
											<gml:posList>35.67398352151706 139.73763131680857 36.405 35.67398739013989 139.73763349944798 36.405 35.67401926917519 139.7376190011825 36.405 35.67402105011502 139.73761424894903 36.405 35.67398352151706 139.73763131680857 36.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b613bb82-828f-4a0f-b094-6e2ee7282950">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b613bb82-828f-4a0f-b094-6e2ee7282950">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b613bb82-828f-4a0f-b094-6e2ee7282950">
											<gml:posList>35.67388702209219 139.7375992086605 21.89 35.67388396720824 139.73758883941792 21.89 35.67386168411293 139.73759870867516 21.89 35.67388178516861 139.73766731807643 21.89 35.67390792467433 139.73765559942686 21.89 35.673891032414424 139.73759822071133 21.89 35.67388722996101 139.73759990435704 21.89 35.67388702209219 139.7375992086605 21.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7dd3db8d-6747-4135-864d-cc687121fc72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dd3db8d-6747-4135-864d-cc687121fc72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dd3db8d-6747-4135-864d-cc687121fc72">
											<gml:posList>35.6739105547493 139.73766451101162 26.459 35.673912713564874 139.73765887459496 26.459 35.67389543268911 139.7376002038704 26.459 35.6738908245456 139.73759752501476 26.459 35.6739105547493 139.73766451101162 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c4bcbc5-6b43-4c05-9da9-8697ecf9be25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c4bcbc5-6b43-4c05-9da9-8697ecf9be25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c4bcbc5-6b43-4c05-9da9-8697ecf9be25">
											<gml:posList>35.67386168411293 139.73759870867516 22.184 35.67385652588671 139.73759572116901 22.184 35.67387797371804 139.7376690238229 22.184 35.67388178516861 139.73766731807643 22.184 35.67386168411293 139.73759870867516 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f779c2e3-0147-4fa1-b2bc-28583bcc86a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f779c2e3-0147-4fa1-b2bc-28583bcc86a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f779c2e3-0147-4fa1-b2bc-28583bcc86a0">
											<gml:posList>35.67402105011502 139.73761424894903 36.405 35.67401926917519 139.7376190011825 36.405 35.67402883078868 139.73765057245876 36.405 35.674032708416085 139.7376527440428 36.405 35.67402105011502 139.73761424894903 36.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01e7b0cf-94d5-4339-8006-3f0e17b486c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01e7b0cf-94d5-4339-8006-3f0e17b486c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01e7b0cf-94d5-4339-8006-3f0e17b486c2">
											<gml:posList>35.673953354893094 139.73764556999018 30.171 35.673957103177024 139.7376437759424 30.171 35.673951194369465 139.73762637331546 30.171 35.67394586497998 139.73762350752278 30.171 35.673953354893094 139.73764556999018 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05633114-a4ab-4022-a87f-7af6cd59dd7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05633114-a4ab-4022-a87f-7af6cd59dd7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05633114-a4ab-4022-a87f-7af6cd59dd7f">
											<gml:posList>35.67397387771237 139.73764376696656 33.867 35.67398566341328 139.73763841731568 33.867 35.67398452469114 139.73763465173124 33.867 35.67396967543294 139.73764139693048 33.867 35.67397387771237 139.73764376696656 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9ea63c3-886e-42c1-9155-212c5971783a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9ea63c3-886e-42c1-9155-212c5971783a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9ea63c3-886e-42c1-9155-212c5971783a">
											<gml:posList>35.67402883078868 139.73765057245876 35.962 35.67401926917519 139.7376190011825 35.962 35.67398739013989 139.73763349944798 35.962 35.673996942735904 139.73766507072418 35.962 35.67402883078868 139.73765057245876 35.962</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a534d13-cbc8-4f31-bad0-c509a72c876b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a534d13-cbc8-4f31-bad0-c509a72c876b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a534d13-cbc8-4f31-bad0-c509a72c876b">
											<gml:posList>35.673953354893094 139.73764556999018 30.171 35.67395618362166 139.73765492321263 30.171 35.67395856723542 139.73764860162555 30.171 35.673957103177024 139.7376437759424 30.171 35.673953354893094 139.73764556999018 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-124137af-9b2f-4ac7-9510-80aef35ca7ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-124137af-9b2f-4ac7-9510-80aef35ca7ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-124137af-9b2f-4ac7-9510-80aef35ca7ff">
											<gml:posList>35.674030626755524 139.73758535023157 30.171 35.674028243153906 139.73759168287296 30.171 35.67406416797361 139.73771156366846 30.171 35.674069326135395 139.73771447386247 30.171 35.674030626755524 139.73758535023157 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3aac7a7c-e51d-49bd-9e08-e7f45bf01a92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3aac7a7c-e51d-49bd-9e08-e7f45bf01a92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3aac7a7c-e51d-49bd-9e08-e7f45bf01a92">
											<gml:posList>35.67396292345893 139.73765186626494 30.171 35.6739653070813 139.737645555724 30.171 35.67395856723542 139.73764860162555 30.171 35.67395618362166 139.73765492321263 30.171 35.67396292345893 139.73765186626494 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9859daf2-5ae4-49f5-b2ce-f140795f9d27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9859daf2-5ae4-49f5-b2ce-f140795f9d27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9859daf2-5ae4-49f5-b2ce-f140795f9d27">
											<gml:posList>35.67399517079898 139.7376698118976 36.405 35.673996942735904 139.73766507072418 36.405 35.67398739013989 139.73763349944798 36.405 35.67398352151706 139.73763131680857 36.405 35.67399517079898 139.7376698118976 36.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1b4640b-e634-4a3a-a4ac-649e48552116">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1b4640b-e634-4a3a-a4ac-649e48552116">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1b4640b-e634-4a3a-a4ac-649e48552116">
											<gml:posList>35.6739105547493 139.73766451101162 26.459 35.673953354893094 139.73764556999018 26.459 35.67395190930974 139.73764130766966 26.459 35.673948593596464 139.7376429907336 26.459 35.673912713564874 139.73765887459496 26.459 35.6739105547493 139.73766451101162 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-faca86fe-bdbf-4ca7-846b-3ec057e8db44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faca86fe-bdbf-4ca7-846b-3ec057e8db44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faca86fe-bdbf-4ca7-846b-3ec057e8db44">
											<gml:posList>35.67396292345893 139.73765186626494 30.171 35.67396909603022 139.73767225120503 30.171 35.67397147062239 139.73766591858148 30.171 35.6739653070813 139.737645555724 30.171 35.67396292345893 139.73765186626494 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e32359f2-4d5f-469f-84fb-79907cde09dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e32359f2-4d5f-469f-84fb-79907cde09dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e32359f2-4d5f-469f-84fb-79907cde09dc">
											<gml:posList>35.674032708416085 139.7376527440428 36.405 35.67402883078868 139.73765057245876 36.405 35.673996942735904 139.73766507072418 36.405 35.67399517079898 139.7376698118976 36.405 35.674032708416085 139.7376527440428 36.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-763f5574-defd-40b6-98ed-6b326d0c2f95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-763f5574-defd-40b6-98ed-6b326d0c2f95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-763f5574-defd-40b6-98ed-6b326d0c2f95">
											<gml:posList>35.67396967543294 139.73764139693048 29.579 35.67398452469114 139.73763465173124 29.579 35.67398352151706 139.73763131680857 29.579 35.67402105011502 139.73761424894903 29.579 35.674032708416085 139.7376527440428 29.579 35.67399785592109 139.73766859355007 29.579 35.67401730448471 139.73773284039314 29.579 35.67406416797361 139.73771156366846 29.579 35.674028243153906 139.73759168287296 29.579 35.673951194369465 139.73762637331546 29.579 35.673957103177024 139.7376437759424 29.579 35.67395856723542 139.73764860162555 29.579 35.6739653070813 139.737645555724 29.579 35.67397147062239 139.73766591858148 29.579 35.67397265099796 139.73766538692865 29.579 35.67397641737105 139.73766367018706 29.579 35.67396967543294 139.73764139693048 29.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25a6a663-5d81-46a4-b298-6d71360b782d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25a6a663-5d81-46a4-b298-6d71360b782d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25a6a663-5d81-46a4-b298-6d71360b782d">
											<gml:posList>35.673981749488405 139.73768131653893 33.867 35.67398595177581 139.73768369762422 33.867 35.67397387771237 139.73764376696656 33.867 35.67396967543294 139.73764139693048 33.867 35.673981749488405 139.73768131653893 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cbd9529e-98cf-4edd-82e5-b32a7f774f07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbd9529e-98cf-4edd-82e5-b32a7f774f07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbd9529e-98cf-4edd-82e5-b32a7f774f07">
											<gml:posList>35.67396909603022 139.73767225120503 30.171 35.67397780915215 139.73766828606966 30.171 35.67397641737105 139.73766367018706 30.171 35.67397265099796 139.73766538692865 30.171 35.67397147062239 139.73766591858148 30.171 35.67396909603022 139.73767225120503 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4124162f-caae-4943-a998-c7425532fec8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4124162f-caae-4943-a998-c7425532fec8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4124162f-caae-4943-a998-c7425532fec8">
											<gml:posList>35.673882492853906 139.73768447282183 24.54 35.673912615406024 139.7376714680024 24.54 35.6739105547493 139.73766451101162 24.54 35.67390792467433 139.73765559942686 24.54 35.67387797371804 139.7376690238229 24.54 35.673882492853906 139.73768447282183 24.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e6d097d-3a0c-47e1-abc1-d9241938b486">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e6d097d-3a0c-47e1-abc1-d9241938b486">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e6d097d-3a0c-47e1-abc1-d9241938b486">
											<gml:posList>35.673897955291714 139.73768938122106 39.558 35.67390268967786 139.73769212621207 39.558 35.67394248936425 139.73767458067806 39.558 35.67394472015837 139.73766877847228 39.558 35.673897955291714 139.73768938122106 39.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84202d1d-9e53-4b0e-bb88-b01c6c74dbc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84202d1d-9e53-4b0e-bb88-b01c6c74dbc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84202d1d-9e53-4b0e-bb88-b01c6c74dbc0">
											<gml:posList>35.673912615406024 139.7376714680024 22.184 35.673882492853906 139.73768447282183 22.184 35.67388552066216 139.73769480895993 22.184 35.673897955291714 139.73768938122106 22.184 35.67391561603384 139.73768162742837 22.184 35.673912615406024 139.7376714680024 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c172df57-7fbb-442f-a5c7-86eac1204657">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c172df57-7fbb-442f-a5c7-86eac1204657">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c172df57-7fbb-442f-a5c7-86eac1204657">
											<gml:posList>35.673981749488405 139.73768131653893 33.867 35.67396629652793 139.7376883386184 33.867 35.67397049880644 139.73769070865683 33.867 35.67398595177581 139.73768369762422 33.867 35.673981749488405 139.73768131653893 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83bb4823-53ec-49c9-aa50-6cd5984bd852">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83bb4823-53ec-49c9-aa50-6cd5984bd852">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83bb4823-53ec-49c9-aa50-6cd5984bd852">
											<gml:posList>35.67399517079898 139.7376698118976 33.585 35.67398566341328 139.73763841731568 33.585 35.67397387771237 139.73764376696656 33.585 35.67398595177581 139.73768369762422 33.585 35.67397049880644 139.73769070865683 33.585 35.67398763377866 139.73774731388642 33.585 35.67401449400315 139.73773510833047 33.585 35.67399517079898 139.7376698118976 33.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d880acfe-6519-4530-9feb-d6cc1d94c168">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d880acfe-6519-4530-9feb-d6cc1d94c168">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d880acfe-6519-4530-9feb-d6cc1d94c168">
											<gml:posList>35.67394472015837 139.73766877847228 39.558 35.67394248936425 139.73767458067806 39.558 35.673959689018865 139.7377331742227 39.558 35.67396442340398 139.7377359192184 39.558 35.67394472015837 139.73766877847228 39.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-86285264-ed42-4d7a-a19f-8f98e1c54c1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86285264-ed42-4d7a-a19f-8f98e1c54c1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86285264-ed42-4d7a-a19f-8f98e1c54c1f">
											<gml:posList>35.67401449400315 139.73773510833047 33.867 35.67401870528566 139.7377374673153 33.867 35.67399785592109 139.73766859355007 33.867 35.67399517079898 139.7376698118976 33.867 35.67401449400315 139.73773510833047 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17b79e80-1584-4978-aa21-4c30c3697ea3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17b79e80-1584-4978-aa21-4c30c3697ea3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17b79e80-1584-4978-aa21-4c30c3697ea3">
											<gml:posList>35.673959689018865 139.7377331742227 38.9 35.67394248936425 139.73767458067806 38.9 35.67390268967786 139.73769212621207 38.9 35.67391988932402 139.73775071973142 38.9 35.673959689018865 139.7377331742227 38.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d788b026-1861-4d37-8ed4-5e3e7cd07de8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d788b026-1861-4d37-8ed4-5e3e7cd07de8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d788b026-1861-4d37-8ed4-5e3e7cd07de8">
											<gml:posList>35.67398570892977 139.73775246396974 33.867 35.67398763377866 139.73774731388642 33.867 35.67397049880644 139.73769070865683 33.867 35.67396629652793 139.7376883386184 33.867 35.67398570892977 139.73775246396974 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e71e6a7-623a-48d3-82ff-906909c40711">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e71e6a7-623a-48d3-82ff-906909c40711">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e71e6a7-623a-48d3-82ff-906909c40711">
											<gml:posList>35.67391765852593 139.73775652193314 39.558 35.67391988932402 139.73775071973142 39.558 35.67390268967786 139.73769212621207 39.558 35.673897955291714 139.73768938122106 39.558 35.67391765852593 139.73775652193314 39.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66e0879e-23f6-4015-8c42-d0b6803cd2bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66e0879e-23f6-4015-8c42-d0b6803cd2bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66e0879e-23f6-4015-8c42-d0b6803cd2bc">
											<gml:posList>35.67406416797361 139.73771156366846 30.171 35.67401730448471 139.73773284039314 30.171 35.67401870528566 139.7377374673153 30.171 35.674069326135395 139.73771447386247 30.171 35.67406416797361 139.73771156366846 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb8bd992-fd89-4e41-8ce4-8a4776f6207f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb8bd992-fd89-4e41-8ce4-8a4776f6207f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb8bd992-fd89-4e41-8ce4-8a4776f6207f">
											<gml:posList>35.67401870528566 139.7377374673153 33.867 35.67401449400315 139.73773510833047 33.867 35.67398763377866 139.73774731388642 33.867 35.67398570892977 139.73775246396974 33.867 35.67401870528566 139.7377374673153 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-942bd138-ef12-40fe-bf1b-c6e66acbcb39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-942bd138-ef12-40fe-bf1b-c6e66acbcb39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-942bd138-ef12-40fe-bf1b-c6e66acbcb39">
											<gml:posList>35.67396442340398 139.7377359192184 39.558 35.673959689018865 139.7377331742227 39.558 35.67391988932402 139.73775071973142 39.558 35.67391765852593 139.73775652193314 39.558 35.67396442340398 139.7377359192184 39.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59fcb656-5a5a-47c6-8b01-69322c8f65d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59fcb656-5a5a-47c6-8b01-69322c8f65d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59fcb656-5a5a-47c6-8b01-69322c8f65d0">
											<gml:posList>35.67388396720824 139.73758883941792 22.184 35.67388396720824 139.73758883941792 21.89 35.67388702209219 139.7375992086605 21.89 35.67388702209219 139.7375992086605 22.184 35.67388396720824 139.73758883941792 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ea3d3fc-3526-485c-843e-585eeb8171ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ea3d3fc-3526-485c-843e-585eeb8171ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ea3d3fc-3526-485c-843e-585eeb8171ec">
											<gml:posList>35.67388702209219 139.7375992086605 22.184 35.67388702209219 139.7375992086605 21.89 35.67388722996101 139.73759990435704 21.89 35.67388722996101 139.73759990435704 22.184 35.67388702209219 139.7375992086605 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88a62277-f41e-44bf-8325-a780ec88300c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88a62277-f41e-44bf-8325-a780ec88300c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88a62277-f41e-44bf-8325-a780ec88300c">
											<gml:posList>35.67400895433068 139.73751305298418 20.436 35.67400895433068 139.73751305298418 9.284 35.67388199430311 139.73756755470305 9.284 35.67388199430311 139.73756755470305 19.087 35.67388199430311 139.73756755470305 20.436 35.67400895433068 139.73751305298418 20.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fab7894-1797-4d5f-b7eb-faa347318a92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fab7894-1797-4d5f-b7eb-faa347318a92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fab7894-1797-4d5f-b7eb-faa347318a92">
											<gml:posList>35.67388547398439 139.73757937056038 20.436 35.67388547398439 139.73757937056038 23.156 35.67401237058725 139.73752444915678 23.156 35.67401237058725 139.73752444915678 20.436 35.67388547398439 139.73757937056038 20.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef7cc9e0-9cf7-4cc0-b829-23c392a4dcb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef7cc9e0-9cf7-4cc0-b829-23c392a4dcb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef7cc9e0-9cf7-4cc0-b829-23c392a4dcb9">
											<gml:posList>35.674015679577614 139.73754830620388 26.459 35.674015679577614 139.73754830620388 26.144 35.674026009659556 139.7375827487103 26.144 35.674026009659556 139.7375827487103 26.459 35.674015679577614 139.73754830620388 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2e81ed2-efeb-4217-be2e-52c07b26bd8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2e81ed2-efeb-4217-be2e-52c07b26bd8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2e81ed2-efeb-4217-be2e-52c07b26bd8f">
											<gml:posList>35.67388199430311 139.73756755470305 9.284 35.67388118069636 139.73756457305475 9.284 35.67388118069636 139.73756457305475 19.087 35.67388199430311 139.73756755470305 19.087 35.67388199430311 139.73756755470305 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4d237da-cfe9-4329-a6f2-ac4148da4b49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4d237da-cfe9-4329-a6f2-ac4148da4b49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4d237da-cfe9-4329-a6f2-ac4148da4b49">
											<gml:posList>35.674017838414066 139.73754270291695 26.459 35.674017838414066 139.73754270291695 23.156 35.6738908245456 139.73759752501476 23.156 35.6738908245456 139.73759752501476 26.459 35.674017838414066 139.73754270291695 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27224bd0-2953-44d3-b8c1-3d2e4fa3c355">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27224bd0-2953-44d3-b8c1-3d2e4fa3c355">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27224bd0-2953-44d3-b8c1-3d2e4fa3c355">
											<gml:posList>35.67388118069636 139.73756457305475 9.284 35.67385126561173 139.7375777544092 9.284 35.67385126561173 139.7375777544092 19.087 35.67388118069636 139.73756457305475 19.087 35.67388118069636 139.73756457305475 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0643b12e-69fe-4b65-ac1e-b88c4c7ab81c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0643b12e-69fe-4b65-ac1e-b88c4c7ab81c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0643b12e-69fe-4b65-ac1e-b88c4c7ab81c">
											<gml:posList>35.67389543268911 139.7376002038704 26.459 35.67389543268911 139.7376002038704 26.144 35.674015679577614 139.73754830620388 26.144 35.674015679577614 139.73754830620388 26.459 35.67389543268911 139.7376002038704 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be222ca4-0e2c-4f06-a7af-8ebe29600528">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be222ca4-0e2c-4f06-a7af-8ebe29600528">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be222ca4-0e2c-4f06-a7af-8ebe29600528">
											<gml:posList>35.67388547398439 139.73757937056038 20.436 35.67388199430311 139.73756755470305 20.436 35.67388199430311 139.73756755470305 19.087 35.67388639587836 139.73758250673401 19.087 35.67388639587836 139.73758250673401 22.184 35.67388639587836 139.73758250673401 23.156 35.67388547398439 139.73757937056038 23.156 35.67388547398439 139.73757937056038 20.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ab27e24-aac7-455b-90b7-8768121d862e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ab27e24-aac7-455b-90b7-8768121d862e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ab27e24-aac7-455b-90b7-8768121d862e">
											<gml:posList>35.674026009659556 139.7375827487103 26.459 35.674026009659556 139.7375827487103 26.144 35.67402724781529 139.7375868676736 26.144 35.67402724781529 139.7375868676736 26.459 35.674026009659556 139.7375827487103 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8158a636-d55c-4afa-a10a-9f0ab8fc18a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8158a636-d55c-4afa-a10a-9f0ab8fc18a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8158a636-d55c-4afa-a10a-9f0ab8fc18a4">
											<gml:posList>35.67385652588671 139.73759572116901 22.184 35.67388639587836 139.73758250673401 22.184 35.67388639587836 139.73758250673401 19.087 35.67385652588671 139.73759572116901 19.087 35.67385652588671 139.73759572116901 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7934e9a9-f719-4260-bb4a-6428348d9c1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7934e9a9-f719-4260-bb4a-6428348d9c1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7934e9a9-f719-4260-bb4a-6428348d9c1f">
											<gml:posList>35.6738908245456 139.73759752501476 22.184 35.6738908245456 139.73759752501476 23.156 35.67388639587836 139.73758250673401 23.156 35.67388639587836 139.73758250673401 22.184 35.6738908245456 139.73759752501476 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a00bd28b-cdef-4a5e-875d-03ed261e734c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a00bd28b-cdef-4a5e-875d-03ed261e734c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a00bd28b-cdef-4a5e-875d-03ed261e734c">
											<gml:posList>35.67386168411293 139.73759870867516 22.184 35.67386168411293 139.73759870867516 21.89 35.67388396720824 139.73758883941792 21.89 35.67388396720824 139.73758883941792 22.184 35.67386168411293 139.73759870867516 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a063623a-b454-4543-92ac-5b9b8fbf2aed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a063623a-b454-4543-92ac-5b9b8fbf2aed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a063623a-b454-4543-92ac-5b9b8fbf2aed">
											<gml:posList>35.67388722996101 139.73759990435704 22.184 35.67388722996101 139.73759990435704 21.89 35.673891032414424 139.73759822071133 21.89 35.673891032414424 139.73759822071133 22.184 35.67388722996101 139.73759990435704 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b5cca93-edc1-4ee8-832c-42942ff14c27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b5cca93-edc1-4ee8-832c-42942ff14c27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b5cca93-edc1-4ee8-832c-42942ff14c27">
											<gml:posList>35.67402724781529 139.7375868676736 26.459 35.67402724781529 139.7375868676736 26.144 35.67394586497998 139.73762350752278 26.144 35.67394586497998 139.73762350752278 30.171 35.674030626755524 139.73758535023157 30.171 35.674030626755524 139.73758535023157 26.459 35.67402724781529 139.7375868676736 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40cb66e3-9606-4a4f-b6a1-785d467ca419">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40cb66e3-9606-4a4f-b6a1-785d467ca419">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40cb66e3-9606-4a4f-b6a1-785d467ca419">
											<gml:posList>35.673951194369465 139.73762637331546 30.171 35.673951194369465 139.73762637331546 29.579 35.674028243153906 139.73759168287296 29.579 35.674028243153906 139.73759168287296 30.171 35.673951194369465 139.73762637331546 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8551bc0-2617-4990-8e3b-e3aca0847de7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8551bc0-2617-4990-8e3b-e3aca0847de7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8551bc0-2617-4990-8e3b-e3aca0847de7">
											<gml:posList>35.674017838414066 139.73754270291695 23.156 35.674017838414066 139.73754270291695 26.459 35.674030626755524 139.73758535023157 26.459 35.674030626755524 139.73758535023157 30.171 35.674069326135395 139.73771447386247 30.171 35.674069326135395 139.73771447386247 9.284 35.67400895433068 139.73751305298418 9.284 35.67400895433068 139.73751305298418 20.436 35.67401237058725 139.73752444915678 20.436 35.67401237058725 139.73752444915678 23.156 35.674017838414066 139.73754270291695 23.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e471f824-4b2d-4d3d-8157-89f553b3a4a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e471f824-4b2d-4d3d-8157-89f553b3a4a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e471f824-4b2d-4d3d-8157-89f553b3a4a8">
											<gml:posList>35.67398352151706 139.73763131680857 36.405 35.67402105011502 139.73761424894903 36.405 35.67402105011502 139.73761424894903 29.579 35.67398352151706 139.73763131680857 29.579 35.67398352151706 139.73763131680857 36.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b09163b0-9909-46e9-acf5-26472422046e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b09163b0-9909-46e9-acf5-26472422046e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b09163b0-9909-46e9-acf5-26472422046e">
											<gml:posList>35.67398739013989 139.73763349944798 36.405 35.67398739013989 139.73763349944798 35.962 35.67401926917519 139.7376190011825 35.962 35.67401926917519 139.7376190011825 36.405 35.67398739013989 139.73763349944798 36.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3672204a-5e06-4a14-b9d9-fb80d4f4d363">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3672204a-5e06-4a14-b9d9-fb80d4f4d363">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3672204a-5e06-4a14-b9d9-fb80d4f4d363">
											<gml:posList>35.673912713564874 139.73765887459496 26.459 35.673912713564874 139.73765887459496 26.144 35.67389543268911 139.7376002038704 26.144 35.67389543268911 139.7376002038704 26.459 35.673912713564874 139.73765887459496 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cad046c-fd0d-415f-b46a-7a0c4ee2222c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cad046c-fd0d-415f-b46a-7a0c4ee2222c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cad046c-fd0d-415f-b46a-7a0c4ee2222c">
											<gml:posList>35.673891032414424 139.73759822071133 22.184 35.673891032414424 139.73759822071133 21.89 35.67390792467433 139.73765559942686 21.89 35.67390792467433 139.73765559942686 24.54 35.6739105547493 139.73766451101162 24.54 35.6739105547493 139.73766451101162 26.459 35.6738908245456 139.73759752501476 26.459 35.6738908245456 139.73759752501476 23.156 35.6738908245456 139.73759752501476 22.184 35.673891032414424 139.73759822071133 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f62fc9b0-e89a-4d1c-b87e-abb1cb36936c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f62fc9b0-e89a-4d1c-b87e-abb1cb36936c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f62fc9b0-e89a-4d1c-b87e-abb1cb36936c">
											<gml:posList>35.67388178516861 139.73766731807643 22.184 35.67388178516861 139.73766731807643 21.89 35.67386168411293 139.73759870867516 21.89 35.67386168411293 139.73759870867516 22.184 35.67388178516861 139.73766731807643 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50958cdd-5950-45d3-91b9-2b6f3656bbd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50958cdd-5950-45d3-91b9-2b6f3656bbd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50958cdd-5950-45d3-91b9-2b6f3656bbd4">
											<gml:posList>35.67402105011502 139.73761424894903 36.405 35.674032708416085 139.7376527440428 36.405 35.674032708416085 139.7376527440428 29.579 35.67402105011502 139.73761424894903 29.579 35.67402105011502 139.73761424894903 36.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ce8f536-7e81-4450-80cc-b14b0b4ba3c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ce8f536-7e81-4450-80cc-b14b0b4ba3c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ce8f536-7e81-4450-80cc-b14b0b4ba3c2">
											<gml:posList>35.67395190930974 139.73764130766966 26.459 35.673953354893094 139.73764556999018 26.459 35.673953354893094 139.73764556999018 30.171 35.67394586497998 139.73762350752278 30.171 35.67394586497998 139.73762350752278 26.144 35.67395190930974 139.73764130766966 26.144 35.67395190930974 139.73764130766966 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9a7c97a-680e-49d9-9f86-8a43725e61a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9a7c97a-680e-49d9-9f86-8a43725e61a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9a7c97a-680e-49d9-9f86-8a43725e61a3">
											<gml:posList>35.67401926917519 139.7376190011825 36.405 35.67401926917519 139.7376190011825 35.962 35.67402883078868 139.73765057245876 35.962 35.67402883078868 139.73765057245876 36.405 35.67401926917519 139.7376190011825 36.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e558dd9-1208-491f-afc5-5ee610be7238">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e558dd9-1208-491f-afc5-5ee610be7238">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e558dd9-1208-491f-afc5-5ee610be7238">
											<gml:posList>35.673957103177024 139.7376437759424 30.171 35.673957103177024 139.7376437759424 29.579 35.673951194369465 139.73762637331546 29.579 35.673951194369465 139.73762637331546 30.171 35.673957103177024 139.7376437759424 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b3e6dfb-70e0-4a3e-b347-5321d6796651">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b3e6dfb-70e0-4a3e-b347-5321d6796651">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b3e6dfb-70e0-4a3e-b347-5321d6796651">
											<gml:posList>35.673882492853906 139.73768447282183 22.184 35.673882492853906 139.73768447282183 24.54 35.67387797371804 139.7376690238229 24.54 35.67387797371804 139.7376690238229 22.184 35.67385652588671 139.73759572116901 22.184 35.67385652588671 139.73759572116901 19.087 35.67385126561173 139.7375777544092 19.087 35.67385126561173 139.7375777544092 9.284 35.67388552066216 139.73769480895993 9.284 35.67388552066216 139.73769480895993 22.184 35.673882492853906 139.73768447282183 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2020cbd4-6801-4584-86a8-2ce8e3dd7a8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2020cbd4-6801-4584-86a8-2ce8e3dd7a8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2020cbd4-6801-4584-86a8-2ce8e3dd7a8b">
											<gml:posList>35.67396967543294 139.73764139693048 33.867 35.67398452469114 139.73763465173124 33.867 35.67398452469114 139.73763465173124 29.579 35.67396967543294 139.73764139693048 29.579 35.67396967543294 139.73764139693048 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-550e16cf-27c0-45fc-9c00-334833e39daa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-550e16cf-27c0-45fc-9c00-334833e39daa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-550e16cf-27c0-45fc-9c00-334833e39daa">
											<gml:posList>35.67397387771237 139.73764376696656 33.867 35.67397387771237 139.73764376696656 33.585 35.67398566341328 139.73763841731568 33.585 35.67398566341328 139.73763841731568 33.867 35.67397387771237 139.73764376696656 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c26b392f-2734-4358-8385-fcefa06fbbc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c26b392f-2734-4358-8385-fcefa06fbbc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c26b392f-2734-4358-8385-fcefa06fbbc8">
											<gml:posList>35.67395190930974 139.73764130766966 26.459 35.67395190930974 139.73764130766966 26.144 35.673948593596464 139.7376429907336 26.144 35.673948593596464 139.7376429907336 26.459 35.67395190930974 139.73764130766966 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4a1e376-56b4-411b-8451-c30fa2f5a007">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4a1e376-56b4-411b-8451-c30fa2f5a007">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4a1e376-56b4-411b-8451-c30fa2f5a007">
											<gml:posList>35.67395856723542 139.73764860162555 30.171 35.67395856723542 139.73764860162555 29.579 35.673957103177024 139.7376437759424 29.579 35.673957103177024 139.7376437759424 30.171 35.67395856723542 139.73764860162555 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c05d0f6-8948-4206-9bce-17da91278f8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c05d0f6-8948-4206-9bce-17da91278f8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c05d0f6-8948-4206-9bce-17da91278f8a">
											<gml:posList>35.6739653070813 139.737645555724 30.171 35.6739653070813 139.737645555724 29.579 35.67395856723542 139.73764860162555 29.579 35.67395856723542 139.73764860162555 30.171 35.6739653070813 139.737645555724 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53585c8e-915c-4477-8cac-49b87f5e5f0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53585c8e-915c-4477-8cac-49b87f5e5f0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53585c8e-915c-4477-8cac-49b87f5e5f0b">
											<gml:posList>35.673996942735904 139.73766507072418 36.405 35.673996942735904 139.73766507072418 35.962 35.67398739013989 139.73763349944798 35.962 35.67398739013989 139.73763349944798 36.405 35.673996942735904 139.73766507072418 36.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f99e1adc-a92d-4343-9f4b-d7d9a7cf24fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f99e1adc-a92d-4343-9f4b-d7d9a7cf24fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f99e1adc-a92d-4343-9f4b-d7d9a7cf24fe">
											<gml:posList>35.67395618362166 139.73765492321263 30.171 35.673953354893094 139.73764556999018 30.171 35.673953354893094 139.73764556999018 26.459 35.673953354893094 139.73764556999018 9.284 35.67395618362166 139.73765492321263 9.284 35.67395618362166 139.73765492321263 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd79d766-2ac6-4306-8298-c39085e72126">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd79d766-2ac6-4306-8298-c39085e72126">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd79d766-2ac6-4306-8298-c39085e72126">
											<gml:posList>35.67398566341328 139.73763841731568 33.867 35.67398566341328 139.73763841731568 33.585 35.67399517079898 139.7376698118976 33.585 35.67399517079898 139.7376698118976 33.867 35.67399517079898 139.7376698118976 36.405 35.67398352151706 139.73763131680857 36.405 35.67398352151706 139.73763131680857 29.579 35.67398452469114 139.73763465173124 29.579 35.67398452469114 139.73763465173124 33.867 35.67398566341328 139.73763841731568 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cd4ae3f-c5e5-4e99-a377-f41df626bed4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cd4ae3f-c5e5-4e99-a377-f41df626bed4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cd4ae3f-c5e5-4e99-a377-f41df626bed4">
											<gml:posList>35.673948593596464 139.7376429907336 26.459 35.673948593596464 139.7376429907336 26.144 35.673912713564874 139.73765887459496 26.144 35.673912713564874 139.73765887459496 26.459 35.673948593596464 139.7376429907336 26.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8dc49697-fbc7-43bc-bc55-2ec060bf23f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dc49697-fbc7-43bc-bc55-2ec060bf23f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dc49697-fbc7-43bc-bc55-2ec060bf23f8">
											<gml:posList>35.674028243153906 139.73759168287296 30.171 35.674028243153906 139.73759168287296 29.579 35.67406416797361 139.73771156366846 29.579 35.67406416797361 139.73771156366846 30.171 35.674028243153906 139.73759168287296 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e52a9fb-45f3-484b-a1bd-10b7fecbe25c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e52a9fb-45f3-484b-a1bd-10b7fecbe25c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e52a9fb-45f3-484b-a1bd-10b7fecbe25c">
											<gml:posList>35.67395618362166 139.73765492321263 9.284 35.67396292345893 139.73765186626494 9.284 35.67396292345893 139.73765186626494 30.171 35.67395618362166 139.73765492321263 30.171 35.67395618362166 139.73765492321263 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df6443c6-db31-41e4-a953-1da2a75743e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df6443c6-db31-41e4-a953-1da2a75743e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df6443c6-db31-41e4-a953-1da2a75743e8">
											<gml:posList>35.673953354893094 139.73764556999018 9.284 35.673953354893094 139.73764556999018 26.459 35.6739105547493 139.73766451101162 26.459 35.6739105547493 139.73766451101162 24.54 35.6739105547493 139.73766451101162 9.284 35.673953354893094 139.73764556999018 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83e572aa-614b-44ae-91ca-a8d12ac463b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83e572aa-614b-44ae-91ca-a8d12ac463b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83e572aa-614b-44ae-91ca-a8d12ac463b9">
											<gml:posList>35.67397147062239 139.73766591858148 30.171 35.67397147062239 139.73766591858148 29.579 35.6739653070813 139.737645555724 29.579 35.6739653070813 139.737645555724 30.171 35.67397147062239 139.73766591858148 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ea29353-1851-42f7-a3dc-a151b07a7077">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ea29353-1851-42f7-a3dc-a151b07a7077">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ea29353-1851-42f7-a3dc-a151b07a7077">
											<gml:posList>35.67402883078868 139.73765057245876 36.405 35.67402883078868 139.73765057245876 35.962 35.673996942735904 139.73766507072418 35.962 35.673996942735904 139.73766507072418 36.405 35.67402883078868 139.73765057245876 36.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c9f032b-0f53-4926-a176-3407733f9c6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c9f032b-0f53-4926-a176-3407733f9c6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c9f032b-0f53-4926-a176-3407733f9c6f">
											<gml:posList>35.674032708416085 139.7376527440428 29.579 35.674032708416085 139.7376527440428 36.405 35.67399517079898 139.7376698118976 36.405 35.67399517079898 139.7376698118976 33.867 35.67399785592109 139.73766859355007 33.867 35.67399785592109 139.73766859355007 29.579 35.674032708416085 139.7376527440428 29.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c436fd7a-589b-4e0a-9dac-12abfb422d73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c436fd7a-589b-4e0a-9dac-12abfb422d73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c436fd7a-589b-4e0a-9dac-12abfb422d73">
											<gml:posList>35.67396967543294 139.73764139693048 29.579 35.67397641737105 139.73766367018706 29.579 35.67397641737105 139.73766367018706 30.171 35.67397780915215 139.73766828606966 30.171 35.67397780915215 139.73766828606966 9.284 35.673981749488405 139.73768131653893 9.284 35.673981749488405 139.73768131653893 33.867 35.67396967543294 139.73764139693048 33.867 35.67396967543294 139.73764139693048 29.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf646cdc-e7c5-4b07-9d56-9cfd19348e02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf646cdc-e7c5-4b07-9d56-9cfd19348e02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf646cdc-e7c5-4b07-9d56-9cfd19348e02">
											<gml:posList>35.67396292345893 139.73765186626494 9.284 35.67396909603022 139.73767225120503 9.284 35.67396909603022 139.73767225120503 30.171 35.67396292345893 139.73765186626494 30.171 35.67396292345893 139.73765186626494 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-072b1445-1989-423a-9b39-28760e1c9a28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-072b1445-1989-423a-9b39-28760e1c9a28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-072b1445-1989-423a-9b39-28760e1c9a28">
											<gml:posList>35.67388178516861 139.73766731807643 22.184 35.67387797371804 139.7376690238229 22.184 35.67387797371804 139.7376690238229 24.54 35.67390792467433 139.73765559942686 24.54 35.67390792467433 139.73765559942686 21.89 35.67388178516861 139.73766731807643 21.89 35.67388178516861 139.73766731807643 22.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae60b8c9-c155-42e4-b1ee-f45968ebbd9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae60b8c9-c155-42e4-b1ee-f45968ebbd9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae60b8c9-c155-42e4-b1ee-f45968ebbd9e">
											<gml:posList>35.67398595177581 139.73768369762422 33.867 35.67398595177581 139.73768369762422 33.585 35.67397387771237 139.73764376696656 33.585 35.67397387771237 139.73764376696656 33.867 35.67398595177581 139.73768369762422 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8d45a22-8901-4287-8aa1-92bdebe0bc46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8d45a22-8901-4287-8aa1-92bdebe0bc46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8d45a22-8901-4287-8aa1-92bdebe0bc46">
											<gml:posList>35.67397641737105 139.73766367018706 30.171 35.67397641737105 139.73766367018706 29.579 35.67397265099796 139.73766538692865 29.579 35.67397265099796 139.73766538692865 30.171 35.67397641737105 139.73766367018706 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a5eb229-5b8d-4ed0-80f9-13261c008080">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a5eb229-5b8d-4ed0-80f9-13261c008080">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a5eb229-5b8d-4ed0-80f9-13261c008080">
											<gml:posList>35.67397265099796 139.73766538692865 30.171 35.67397265099796 139.73766538692865 29.579 35.67397147062239 139.73766591858148 29.579 35.67397147062239 139.73766591858148 30.171 35.67397265099796 139.73766538692865 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40d14a11-7bc5-430c-b332-80a6b1feedb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40d14a11-7bc5-430c-b332-80a6b1feedb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40d14a11-7bc5-430c-b332-80a6b1feedb1">
											<gml:posList>35.67396909603022 139.73767225120503 9.284 35.67397780915215 139.73766828606966 9.284 35.67397780915215 139.73766828606966 30.171 35.67396909603022 139.73767225120503 30.171 35.67396909603022 139.73767225120503 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8f8eac1-cdea-4ef2-9437-c7bfc4a5ac31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8f8eac1-cdea-4ef2-9437-c7bfc4a5ac31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8f8eac1-cdea-4ef2-9437-c7bfc4a5ac31">
											<gml:posList>35.6739105547493 139.73766451101162 9.284 35.6739105547493 139.73766451101162 24.54 35.673912615406024 139.7376714680024 24.54 35.673912615406024 139.7376714680024 22.184 35.67391561603384 139.73768162742837 22.184 35.67391561603384 139.73768162742837 9.284 35.6739105547493 139.73766451101162 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1396a70b-6b86-468b-a9f6-6e50d4c55b46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1396a70b-6b86-468b-a9f6-6e50d4c55b46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1396a70b-6b86-468b-a9f6-6e50d4c55b46">
											<gml:posList>35.673912615406024 139.7376714680024 24.54 35.673882492853906 139.73768447282183 24.54 35.673882492853906 139.73768447282183 22.184 35.673912615406024 139.7376714680024 22.184 35.673912615406024 139.7376714680024 24.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-464bc3d0-0a51-4237-8eb8-a365cfdf9ae7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-464bc3d0-0a51-4237-8eb8-a365cfdf9ae7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-464bc3d0-0a51-4237-8eb8-a365cfdf9ae7">
											<gml:posList>35.673897955291714 139.73768938122106 39.558 35.67394472015837 139.73766877847228 39.558 35.67394472015837 139.73766877847228 9.284 35.67391561603384 139.73768162742837 9.284 35.67391561603384 139.73768162742837 22.184 35.673897955291714 139.73768938122106 22.184 35.673897955291714 139.73768938122106 39.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed7dd6dc-7a26-4663-aa16-16fea38d6632">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed7dd6dc-7a26-4663-aa16-16fea38d6632">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed7dd6dc-7a26-4663-aa16-16fea38d6632">
											<gml:posList>35.67390268967786 139.73769212621207 39.558 35.67390268967786 139.73769212621207 38.9 35.67394248936425 139.73767458067806 38.9 35.67394248936425 139.73767458067806 39.558 35.67390268967786 139.73769212621207 39.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01db3bb2-473b-4595-9481-14148b8ec7a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01db3bb2-473b-4595-9481-14148b8ec7a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01db3bb2-473b-4595-9481-14148b8ec7a1">
											<gml:posList>35.673981749488405 139.73768131653893 9.284 35.67396629652793 139.7376883386184 9.284 35.67396629652793 139.7376883386184 33.867 35.673981749488405 139.73768131653893 33.867 35.673981749488405 139.73768131653893 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af6ceb41-3397-4946-87bf-64b05b3c7cf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af6ceb41-3397-4946-87bf-64b05b3c7cf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af6ceb41-3397-4946-87bf-64b05b3c7cf4">
											<gml:posList>35.67397049880644 139.73769070865683 33.867 35.67397049880644 139.73769070865683 33.585 35.67398595177581 139.73768369762422 33.585 35.67398595177581 139.73768369762422 33.867 35.67397049880644 139.73769070865683 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54cfe3b4-2e0e-4beb-847a-53da19a834a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54cfe3b4-2e0e-4beb-847a-53da19a834a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54cfe3b4-2e0e-4beb-847a-53da19a834a7">
											<gml:posList>35.67388552066216 139.73769480895993 9.284 35.673897955291714 139.73768938122106 9.284 35.673897955291714 139.73768938122106 22.184 35.67388552066216 139.73769480895993 22.184 35.67388552066216 139.73769480895993 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1305a7a-e604-465e-b95c-a77a8540c973">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1305a7a-e604-465e-b95c-a77a8540c973">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1305a7a-e604-465e-b95c-a77a8540c973">
											<gml:posList>35.67396442340398 139.7377359192184 9.284 35.67394472015837 139.73766877847228 9.284 35.67394472015837 139.73766877847228 39.558 35.67396442340398 139.7377359192184 39.558 35.67396442340398 139.7377359192184 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7770348-5764-4a6a-aee6-d196c3c9760a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7770348-5764-4a6a-aee6-d196c3c9760a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7770348-5764-4a6a-aee6-d196c3c9760a">
											<gml:posList>35.67399517079898 139.7376698118976 33.867 35.67399517079898 139.7376698118976 33.585 35.67401449400315 139.73773510833047 33.585 35.67401449400315 139.73773510833047 33.867 35.67399517079898 139.7376698118976 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-648d5e20-e3e2-4671-8018-bf4314878279">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-648d5e20-e3e2-4671-8018-bf4314878279">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-648d5e20-e3e2-4671-8018-bf4314878279">
											<gml:posList>35.67401730448471 139.73773284039314 30.171 35.67401730448471 139.73773284039314 29.579 35.67399785592109 139.73766859355007 29.579 35.67399785592109 139.73766859355007 33.867 35.67401870528566 139.7377374673153 33.867 35.67401870528566 139.7377374673153 30.171 35.67401730448471 139.73773284039314 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83a671a2-1058-4ee7-a0cb-1aa0d142827c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83a671a2-1058-4ee7-a0cb-1aa0d142827c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83a671a2-1058-4ee7-a0cb-1aa0d142827c">
											<gml:posList>35.67394248936425 139.73767458067806 39.558 35.67394248936425 139.73767458067806 38.9 35.673959689018865 139.7377331742227 38.9 35.673959689018865 139.7377331742227 39.558 35.67394248936425 139.73767458067806 39.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d24790c9-1314-4091-9327-9770e1b59dde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d24790c9-1314-4091-9327-9770e1b59dde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d24790c9-1314-4091-9327-9770e1b59dde">
											<gml:posList>35.67398763377866 139.73774731388642 33.867 35.67398763377866 139.73774731388642 33.585 35.67397049880644 139.73769070865683 33.585 35.67397049880644 139.73769070865683 33.867 35.67398763377866 139.73774731388642 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28a2e080-17d2-41c2-920b-8bb0b005ca47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28a2e080-17d2-41c2-920b-8bb0b005ca47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28a2e080-17d2-41c2-920b-8bb0b005ca47">
											<gml:posList>35.67396629652793 139.7376883386184 9.284 35.67398570892977 139.73775246396974 9.284 35.67398570892977 139.73775246396974 33.867 35.67396629652793 139.7376883386184 33.867 35.67396629652793 139.7376883386184 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c62b20af-8570-446d-bb8a-c9ec0de6732e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c62b20af-8570-446d-bb8a-c9ec0de6732e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c62b20af-8570-446d-bb8a-c9ec0de6732e">
											<gml:posList>35.67391988932402 139.73775071973142 39.558 35.67391988932402 139.73775071973142 38.9 35.67390268967786 139.73769212621207 38.9 35.67390268967786 139.73769212621207 39.558 35.67391988932402 139.73775071973142 39.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21ba23f0-ed27-4895-b538-dd8a3830bd24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21ba23f0-ed27-4895-b538-dd8a3830bd24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21ba23f0-ed27-4895-b538-dd8a3830bd24">
											<gml:posList>35.67406416797361 139.73771156366846 30.171 35.67406416797361 139.73771156366846 29.579 35.67401730448471 139.73773284039314 29.579 35.67401730448471 139.73773284039314 30.171 35.67406416797361 139.73771156366846 30.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b15fd87-7803-48b2-bba7-6d7342efdd8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b15fd87-7803-48b2-bba7-6d7342efdd8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b15fd87-7803-48b2-bba7-6d7342efdd8c">
											<gml:posList>35.67391765852593 139.73775652193314 9.284 35.67391765852593 139.73775652193314 39.558 35.673897955291714 139.73768938122106 39.558 35.673897955291714 139.73768938122106 22.184 35.673897955291714 139.73768938122106 9.284 35.67391765852593 139.73775652193314 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4cdc9bc-f207-44ee-901e-81c201b8cdb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4cdc9bc-f207-44ee-901e-81c201b8cdb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4cdc9bc-f207-44ee-901e-81c201b8cdb5">
											<gml:posList>35.67398570892977 139.73775246396974 9.284 35.674069326135395 139.73771447386247 9.284 35.674069326135395 139.73771447386247 30.171 35.67401870528566 139.7377374673153 30.171 35.67401870528566 139.7377374673153 33.867 35.67398570892977 139.73775246396974 33.867 35.67398570892977 139.73775246396974 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f0233f0-628c-48c4-924c-7c07018d6d66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f0233f0-628c-48c4-924c-7c07018d6d66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f0233f0-628c-48c4-924c-7c07018d6d66">
											<gml:posList>35.67401449400315 139.73773510833047 33.867 35.67401449400315 139.73773510833047 33.585 35.67398763377866 139.73774731388642 33.585 35.67398763377866 139.73774731388642 33.867 35.67401449400315 139.73773510833047 33.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d92e200d-121d-40d3-a99f-10b7f3b2b93f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d92e200d-121d-40d3-a99f-10b7f3b2b93f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d92e200d-121d-40d3-a99f-10b7f3b2b93f">
											<gml:posList>35.673959689018865 139.7377331742227 39.558 35.673959689018865 139.7377331742227 38.9 35.67391988932402 139.73775071973142 38.9 35.67391988932402 139.73775071973142 39.558 35.673959689018865 139.7377331742227 39.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19669777-6350-4836-aecf-f0fdd1faabdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19669777-6350-4836-aecf-f0fdd1faabdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19669777-6350-4836-aecf-f0fdd1faabdb">
											<gml:posList>35.67391765852593 139.73775652193314 9.284 35.67396442340398 139.7377359192184 9.284 35.67396442340398 139.7377359192184 39.558 35.67391765852593 139.73775652193314 39.558 35.67391765852593 139.73775652193314 9.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8184</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">240.13918</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>