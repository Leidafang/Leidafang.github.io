<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ffaefa2f-2f63-4c8d-a45a-5342c92120ad">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">24.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66702438703422 139.7457898419268 0 35.66698885744138 139.74576856233566 0 35.66701288014664 139.74570811559832 0 35.66687085215291 139.74562343923583 0 35.66676234515148 139.74589660914688 0 35.66690266154958 139.74598294461086 0 35.66692866378322 139.7459175362876 0 35.666965184852344 139.74593880380252 0 35.66702438703422 139.7457898419268 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66702438703422 139.7457898419268 8.87 35.666965184852344 139.74593880380252 8.87 35.66692866378322 139.7459175362876 8.87 35.66690266154958 139.74598294461086 8.87 35.66676234515148 139.74589660914688 8.87 35.66687085215291 139.74562343923583 8.87 35.66701288014664 139.74570811559832 8.87 35.66698885744138 139.74576856233566 8.87 35.66702438703422 139.7457898419268 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66702438703422 139.7457898419268 8.87 35.66698885744138 139.74576856233566 8.87 35.66698885744138 139.74576856233566 32.89 35.66702438703422 139.7457898419268 32.89 35.66702438703422 139.7457898419268 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66698885744138 139.74576856233566 8.87 35.66701288014664 139.74570811559832 8.87 35.66701288014664 139.74570811559832 32.89 35.66698885744138 139.74576856233566 32.89 35.66698885744138 139.74576856233566 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66701288014664 139.74570811559832 8.87 35.66687085215291 139.74562343923583 8.87 35.66687085215291 139.74562343923583 32.89 35.66701288014664 139.74570811559832 32.89 35.66701288014664 139.74570811559832 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687085215291 139.74562343923583 8.87 35.66676234515148 139.74589660914688 8.87 35.66676234515148 139.74589660914688 32.89 35.66687085215291 139.74562343923583 32.89 35.66687085215291 139.74562343923583 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676234515148 139.74589660914688 8.87 35.66690266154958 139.74598294461086 8.87 35.66690266154958 139.74598294461086 32.89 35.66676234515148 139.74589660914688 32.89 35.66676234515148 139.74589660914688 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66690266154958 139.74598294461086 8.87 35.66692866378322 139.7459175362876 8.87 35.66692866378322 139.7459175362876 32.89 35.66690266154958 139.74598294461086 32.89 35.66690266154958 139.74598294461086 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66692866378322 139.7459175362876 8.87 35.666965184852344 139.74593880380252 8.87 35.666965184852344 139.74593880380252 32.89 35.66692866378322 139.7459175362876 32.89 35.66692866378322 139.7459175362876 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666965184852344 139.74593880380252 8.87 35.66702438703422 139.7457898419268 8.87 35.66702438703422 139.7457898419268 32.89 35.666965184852344 139.74593880380252 32.89 35.666965184852344 139.74593880380252 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66702438703422 139.7457898419268 32.89 35.66698885744138 139.74576856233566 32.89 35.66701288014664 139.74570811559832 32.89 35.66687085215291 139.74562343923583 32.89 35.66676234515148 139.74589660914688 32.89 35.66690266154958 139.74598294461086 32.89 35.66692866378322 139.7459175362876 32.89 35.666965184852344 139.74593880380252 32.89 35.66702438703422 139.7457898419268 32.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-72471061-c887-4e79-ae89-a0960f378229"/>
							<gml:surfaceMember xlink:href="#poly-b63e3f33-48bb-4a9e-bbf5-a9592b355516"/>
							<gml:surfaceMember xlink:href="#poly-549546b6-71ba-4d7e-8dae-72b7a72a3da2"/>
							<gml:surfaceMember xlink:href="#poly-ffa2b024-2712-452b-bcca-581df9888646"/>
							<gml:surfaceMember xlink:href="#poly-3e383eea-eb2d-4140-b06e-60936168cdde"/>
							<gml:surfaceMember xlink:href="#poly-fea04aed-693e-4760-b698-92af18e615d6"/>
							<gml:surfaceMember xlink:href="#poly-4a952c8d-726c-49ac-8f6c-ec3f8f612eea"/>
							<gml:surfaceMember xlink:href="#poly-907c8453-fdc0-4f53-9073-2526ab8f6c9d"/>
							<gml:surfaceMember xlink:href="#poly-7af89e69-6095-4fc6-a7a5-6492c1c5c3e2"/>
							<gml:surfaceMember xlink:href="#poly-e37de8d2-3ce5-401f-950b-9174ea688143"/>
							<gml:surfaceMember xlink:href="#poly-501754d6-a84f-40cf-83fc-a605294721a3"/>
							<gml:surfaceMember xlink:href="#poly-926d5fcf-d951-4a8c-a95e-71155753603c"/>
							<gml:surfaceMember xlink:href="#poly-2d57195e-3e55-4f62-a5ed-3a53418371bf"/>
							<gml:surfaceMember xlink:href="#poly-376b6b57-116e-49f8-a983-87406c78bd02"/>
							<gml:surfaceMember xlink:href="#poly-7c044da7-ddeb-42d0-9ac2-2f59e71d66d6"/>
							<gml:surfaceMember xlink:href="#poly-e8e4dc81-ea4f-4e54-9071-7184bfa4e692"/>
							<gml:surfaceMember xlink:href="#poly-9adaf56a-cd14-460a-ac9c-647261306af3"/>
							<gml:surfaceMember xlink:href="#poly-b14d5ee5-6477-4634-a259-2e95149a8578"/>
							<gml:surfaceMember xlink:href="#poly-01396036-2937-4905-9d33-8021c156f574"/>
							<gml:surfaceMember xlink:href="#poly-d2cdf115-4e32-4743-94ed-c0f0869ccf4b"/>
							<gml:surfaceMember xlink:href="#poly-8b169cae-018e-4147-bb23-cbb669764e94"/>
							<gml:surfaceMember xlink:href="#poly-078e36bd-33fc-4488-8a8e-7cf6e1c8f651"/>
							<gml:surfaceMember xlink:href="#poly-8d159668-b8a8-41be-9dde-e11df4cf2102"/>
							<gml:surfaceMember xlink:href="#poly-3f583f67-4161-4d21-985e-90bb026ed0c2"/>
							<gml:surfaceMember xlink:href="#poly-fc1407fe-a24f-4a39-bb0d-41cda4939cf3"/>
							<gml:surfaceMember xlink:href="#poly-2261a97a-591c-4b03-b5cd-e5492a42fb92"/>
							<gml:surfaceMember xlink:href="#poly-82aaaff7-2017-4e74-bace-a1d6464d5ed8"/>
							<gml:surfaceMember xlink:href="#poly-e7a80cf0-5a51-4c82-900e-c03870e514eb"/>
							<gml:surfaceMember xlink:href="#poly-a8ae69ec-f046-4bde-8ad1-396a70a44146"/>
							<gml:surfaceMember xlink:href="#poly-581d209c-7b32-4ef9-ac9a-8c71eb2fd261"/>
							<gml:surfaceMember xlink:href="#poly-b855bc79-642d-4c59-bef9-cc1e7c5553a9"/>
							<gml:surfaceMember xlink:href="#poly-47905200-7ad6-43a0-a984-028ecff01063"/>
							<gml:surfaceMember xlink:href="#poly-b0be2617-25ac-4b79-b92f-75a787fdbfbd"/>
							<gml:surfaceMember xlink:href="#poly-828ff633-d20e-4927-bfb8-abdb64a25759"/>
							<gml:surfaceMember xlink:href="#poly-59648ba3-81a7-4a8e-b4fb-a172773156c6"/>
							<gml:surfaceMember xlink:href="#poly-5eb34eb7-35e5-416a-9a96-5f5f756a0794"/>
							<gml:surfaceMember xlink:href="#poly-e3f34058-3d35-4904-9f11-93e333a9b1b0"/>
							<gml:surfaceMember xlink:href="#poly-d225c73c-ab61-4407-9ec5-8c25501c5231"/>
							<gml:surfaceMember xlink:href="#poly-7b28af0b-6915-4962-b7da-f4d6e9d939fc"/>
							<gml:surfaceMember xlink:href="#poly-4d6b4c96-b73c-471a-839a-f4ef10c7ced6"/>
							<gml:surfaceMember xlink:href="#poly-b718be81-c8ac-43cf-8bd3-b2858dd3596c"/>
							<gml:surfaceMember xlink:href="#poly-ae27308f-ffa2-43ae-b12e-3bdf3a0dc303"/>
							<gml:surfaceMember xlink:href="#poly-d8e73895-fcc1-461f-b790-55b641995d47"/>
							<gml:surfaceMember xlink:href="#poly-f4454e9e-a259-436a-9e67-3fc7ec3d3a0c"/>
							<gml:surfaceMember xlink:href="#poly-9e44bff5-7ab0-4b34-a674-8f013f1d0818"/>
							<gml:surfaceMember xlink:href="#poly-2d4b2a66-5b4c-42c3-a6b6-0bc2234f0f58"/>
							<gml:surfaceMember xlink:href="#poly-2a51f8dd-f6ae-4b43-a58c-1db867f276e3"/>
							<gml:surfaceMember xlink:href="#poly-526d50d0-471e-41c2-958d-26a298000812"/>
							<gml:surfaceMember xlink:href="#poly-01c7502d-d291-4ed2-bacb-86f891c83779"/>
							<gml:surfaceMember xlink:href="#poly-1ba21a88-7c9d-4127-8ec0-56c0288c1288"/>
							<gml:surfaceMember xlink:href="#poly-6535076f-16b1-4367-99b9-ac5c7c26e306"/>
							<gml:surfaceMember xlink:href="#poly-ab1dfacb-bc61-47c3-8472-15bf25192f8b"/>
							<gml:surfaceMember xlink:href="#poly-b29b7456-ade7-4773-959f-aaa7129fdef3"/>
							<gml:surfaceMember xlink:href="#poly-fa5dbfcf-3af1-43ab-8f76-144328422b5b"/>
							<gml:surfaceMember xlink:href="#poly-e0d7511f-9fd2-41eb-8c6d-b93564df07dd"/>
							<gml:surfaceMember xlink:href="#poly-2762f994-2ef9-4835-9e4f-ed57b18ebd3a"/>
							<gml:surfaceMember xlink:href="#poly-111325f2-a70e-4fac-af06-dc1b422a56b4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ffaefa2f-2f63-4c8d-a45a-5342c92120ad_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2b94f78-54f8-41e6-882e-4ce71cb5efa4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66695328570612 139.74577610126988 32.788 35.666944764021395 139.74577100742127 32.788 35.66695641548826 139.74574169022188 32.788 35.666964946179895 139.74574677301248 32.788 35.66695328570612 139.74577610126988 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f19abb3-5e78-4e7a-84ef-13ea4201dcc2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666969324218876 139.745792729763 32.788 35.66696734032318 139.74579152793774 32.788 35.666965174747595 139.7457883932977 32.788 35.66696446970123 139.74578567680322 32.788 35.66696469306889 139.74578295929516 32.788 35.66696536725947 139.74578042907325 32.788 35.66696711400347 139.74577778722232 32.788 35.666969402125325 139.74577590693963 32.788 35.666971465715115 139.74577514252687 32.788 35.6669740617976 139.7457753164248 32.788 35.66698395378577 139.74578070701594 32.788 35.66697338166079 139.74580686394555 32.788 35.66696553624796 139.74580210072787 32.788 35.666969324218876 139.745792729763 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0445a9fc-cc53-4c44-bc8f-e9e7070f6b80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66684606486449 139.74582233444707 32.788 35.66687053876105 139.745836943392 32.788 35.666866229057646 139.74584778400063 32.788 35.66684175516237 139.7458331750532 32.788 35.66684606486449 139.74582233444707 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d4eb893-5480-4408-bd3b-e59c39eee8e8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66691947751413 139.7459406209431 8.87 35.66692866378319 139.7459175362876 8.87 35.66696518485234 139.74593880380252 8.87 35.66695581863327 139.7459623415395 8.87 35.66691947751413 139.7459406209431 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9703d235-1fea-43f4-9cd3-8bb6155c22f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9703d235-1fea-43f4-9cd3-8bb6155c22f7_0">
											<gml:posList>35.666964946179895 139.74574677301248 32.788 35.66695641548826 139.74574169022188 32.788 35.66695641548826 139.74574169022188 34.772 35.666964946179895 139.74574677301248 34.772 35.666964946179895 139.74574677301248 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81ed3486-13c9-4dcd-b4e9-1a61eba2c994">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81ed3486-13c9-4dcd-b4e9-1a61eba2c994_0">
											<gml:posList>35.66695641548826 139.74574169022188 32.788 35.666944764021395 139.74577100742127 32.788 35.666944764021395 139.74577100742127 34.772 35.66695641548826 139.74574169022188 34.772 35.66695641548826 139.74574169022188 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e64fa8b4-08b7-42a2-ba74-e50eae646e5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e64fa8b4-08b7-42a2-ba74-e50eae646e5f_0">
											<gml:posList>35.66695328570612 139.74577610126988 34.772 35.666964946179895 139.74574677301248 34.772 35.66695641548826 139.74574169022188 34.772 35.666944764021395 139.74577100742127 34.772 35.66695328570612 139.74577610126988 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-421c80a8-9d67-4924-9d23-41afe8d97876">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-421c80a8-9d67-4924-9d23-41afe8d97876_0">
											<gml:posList>35.66695328570612 139.74577610126988 32.788 35.666964946179895 139.74574677301248 32.788 35.666964946179895 139.74574677301248 34.772 35.66695328570612 139.74577610126988 34.772 35.66695328570612 139.74577610126988 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c36b2d4-8cbc-4991-bf98-e15b00248b3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c36b2d4-8cbc-4991-bf98-e15b00248b3f_0">
											<gml:posList>35.66695328570612 139.74577610126988 32.788 35.66695328570612 139.74577610126988 34.772 35.666944764021395 139.74577100742127 34.772 35.666944764021395 139.74577100742127 32.788 35.66695328570612 139.74577610126988 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a54601b-d3d0-4bda-9f3b-b8151dec941c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a54601b-d3d0-4bda-9f3b-b8151dec941c_0">
											<gml:posList>35.6669740617976 139.7457753164248 32.788 35.666971465715115 139.74577514252687 32.788 35.666971465715115 139.74577514252687 37.238 35.6669740617976 139.7457753164248 37.238 35.6669740617976 139.7457753164248 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83840f35-6b3f-47ca-9077-6c13d92c250f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83840f35-6b3f-47ca-9077-6c13d92c250f_0">
											<gml:posList>35.666971465715115 139.74577514252687 32.788 35.666969402125325 139.74577590693963 32.788 35.666969402125325 139.74577590693963 37.238 35.666971465715115 139.74577514252687 37.238 35.666971465715115 139.74577514252687 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8afd0f2-69b4-4461-89a4-91c31c5ec54d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8afd0f2-69b4-4461-89a4-91c31c5ec54d_0">
											<gml:posList>35.666969402125325 139.74577590693963 32.788 35.66696711400347 139.74577778722232 32.788 35.66696711400347 139.74577778722232 37.238 35.666969402125325 139.74577590693963 37.238 35.666969402125325 139.74577590693963 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b50b9a47-8f28-470d-9ac6-b9feb4e2e79b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b50b9a47-8f28-470d-9ac6-b9feb4e2e79b_0">
											<gml:posList>35.66698395378577 139.74578070701594 32.816 35.66698395378577 139.74578070701594 32.788 35.6669740617976 139.7457753164248 32.788 35.6669740617976 139.7457753164248 37.238 35.66698395378577 139.74578070701594 37.238 35.66698395378577 139.74578070701594 32.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-613729f5-e719-4623-9f53-1a89235afeba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-613729f5-e719-4623-9f53-1a89235afeba_0">
											<gml:posList>35.66696711400347 139.74577778722232 32.788 35.66696536725947 139.74578042907325 32.788 35.66696536725947 139.74578042907325 37.238 35.66696711400347 139.74577778722232 37.238 35.66696711400347 139.74577778722232 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01798ca0-a0d4-4385-9609-bc7714b9c9e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01798ca0-a0d4-4385-9609-bc7714b9c9e2_0">
											<gml:posList>35.66696536725947 139.74578042907325 32.788 35.66696469306889 139.74578295929516 32.788 35.66696469306889 139.74578295929516 37.238 35.66696536725947 139.74578042907325 37.238 35.66696536725947 139.74578042907325 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fc8c747-fe6c-4732-9b57-e8a001fb2cf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fc8c747-fe6c-4732-9b57-e8a001fb2cf5_0">
											<gml:posList>35.66696469306889 139.74578295929516 32.788 35.66696446970123 139.74578567680322 32.788 35.66696446970123 139.74578567680322 37.238 35.66696469306889 139.74578295929516 37.238 35.66696469306889 139.74578295929516 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16ef488c-8608-492b-9e43-b26b8ba77293">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16ef488c-8608-492b-9e43-b26b8ba77293_0">
											<gml:posList>35.66696446970123 139.74578567680322 32.788 35.666965174747595 139.7457883932977 32.788 35.666965174747595 139.7457883932977 37.238 35.66696446970123 139.74578567680322 37.238 35.66696446970123 139.74578567680322 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abfbf856-25a1-4d1b-a7d0-19825e0f1c89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abfbf856-25a1-4d1b-a7d0-19825e0f1c89_0">
											<gml:posList>35.666965174747595 139.7457883932977 32.788 35.66696734032318 139.74579152793774 32.788 35.66696734032318 139.74579152793774 37.238 35.666965174747595 139.7457883932977 37.238 35.666965174747595 139.7457883932977 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db3a1310-df56-4d1a-b999-e4b6b7f845d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db3a1310-df56-4d1a-b999-e4b6b7f845d7_0">
											<gml:posList>35.66697338166079 139.74580686394555 37.238 35.666980840624895 139.74578839828604 37.238 35.66698395378577 139.74578070701594 37.238 35.6669740617976 139.7457753164248 37.238 35.666971465715115 139.74577514252687 37.238 35.666969402125325 139.74577590693963 37.238 35.66696711400347 139.74577778722232 37.238 35.66696536725947 139.74578042907325 37.238 35.66696469306889 139.74578295929516 37.238 35.66696446970123 139.74578567680322 37.238 35.666965174747595 139.7457883932977 37.238 35.66696734032318 139.74579152793774 37.238 35.666969324218876 139.745792729763 37.238 35.66696553624796 139.74580210072787 37.238 35.66697338166079 139.74580686394555 37.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7eec598-8d05-4996-9a59-2fa30a045a09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7eec598-8d05-4996-9a59-2fa30a045a09_0">
											<gml:posList>35.66696734032318 139.74579152793774 32.788 35.666969324218876 139.745792729763 32.788 35.666969324218876 139.745792729763 37.238 35.66696734032318 139.74579152793774 37.238 35.66696734032318 139.74579152793774 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1706495e-a621-479b-828d-0f2451d930e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1706495e-a621-479b-828d-0f2451d930e6_0">
											<gml:posList>35.66698395378577 139.74578070701594 32.816 35.66698395378577 139.74578070701594 37.238 35.666980840624895 139.74578839828604 37.238 35.6669736335956 139.74580624510625 32.801 35.66698395378577 139.74578070701594 32.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9183a816-12af-41cd-9bf9-49a8797fad29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9183a816-12af-41cd-9bf9-49a8797fad29_0">
											<gml:posList>35.66697338166079 139.74580686394555 37.238 35.66697338166079 139.74580686394555 32.788 35.66698395378577 139.74578070701594 32.788 35.66698395378577 139.74578070701594 32.816 35.6669736335956 139.74580624510625 32.801 35.666980840624895 139.74578839828604 37.238 35.66697338166079 139.74580686394555 37.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8988dffa-f7f7-40c6-8049-865738d76821">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8988dffa-f7f7-40c6-8049-865738d76821_0">
											<gml:posList>35.666969324218876 139.745792729763 32.788 35.66696553624796 139.74580210072787 32.788 35.66696553624796 139.74580210072787 37.238 35.666969324218876 139.745792729763 37.238 35.666969324218876 139.745792729763 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9437075-ff45-4fb0-a230-a502cfa67c79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9437075-ff45-4fb0-a230-a502cfa67c79_0">
											<gml:posList>35.66697338166079 139.74580686394555 37.238 35.66696553624796 139.74580210072787 37.238 35.66696553624796 139.74580210072787 32.788 35.66697338166079 139.74580686394555 32.788 35.66697338166079 139.74580686394555 37.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c62bae2a-e54c-43d7-a07e-d4b6fcc45f9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c62bae2a-e54c-43d7-a07e-d4b6fcc45f9f_0">
											<gml:posList>35.66684606486449 139.74582233444707 32.788 35.66684175516237 139.7458331750532 32.788 35.66684175516237 139.7458331750532 34.772 35.66684606486449 139.74582233444707 34.772 35.66684606486449 139.74582233444707 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e760b25-f837-47c6-94ca-bf4eb80ef764">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e760b25-f837-47c6-94ca-bf4eb80ef764_0">
											<gml:posList>35.66684606486449 139.74582233444707 32.788 35.66684606486449 139.74582233444707 34.772 35.66687053876105 139.745836943392 34.772 35.66687053876105 139.745836943392 32.788 35.66684606486449 139.74582233444707 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf9c4000-33a3-4243-89a6-543d5adc52ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf9c4000-33a3-4243-89a6-543d5adc52ac_0">
											<gml:posList>35.666866229057646 139.74584778400063 34.772 35.66687053876105 139.745836943392 34.772 35.66684606486449 139.74582233444707 34.772 35.66684175516237 139.7458331750532 34.772 35.666866229057646 139.74584778400063 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c68250c4-77eb-4aa6-ae93-de1c0cac79ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c68250c4-77eb-4aa6-ae93-de1c0cac79ec_0">
											<gml:posList>35.666866229057646 139.74584778400063 32.788 35.666866229057646 139.74584778400063 34.772 35.66684175516237 139.7458331750532 34.772 35.66684175516237 139.7458331750532 32.788 35.666866229057646 139.74584778400063 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57ccd068-6dc4-44df-9d10-642c08b8f46b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57ccd068-6dc4-44df-9d10-642c08b8f46b_0">
											<gml:posList>35.666866229057646 139.74584778400063 32.788 35.66687053876105 139.745836943392 32.788 35.66687053876105 139.745836943392 34.772 35.666866229057646 139.74584778400063 34.772 35.666866229057646 139.74584778400063 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2eef3bf7-93ed-401c-9084-48c176ee65de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2eef3bf7-93ed-401c-9084-48c176ee65de_0">
											<gml:posList>35.66695523818753 139.74593258481863 28.189 35.666965274829295 139.74593858278865 28.189 35.66696518485234 139.74593880380252 8.87 35.66692866378319 139.7459175362876 8.87 35.66692893370595 139.74591686220052 30.119 35.66695523818753 139.74593258481863 28.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e057f83-cbac-4e0e-9bf1-c16bf8a3ba9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e057f83-cbac-4e0e-9bf1-c16bf8a3ba9c_0">
											<gml:posList>35.66691947751413 139.7459406209431 26.285 35.666924210117486 139.74592874156755 26.285 35.666924210117486 139.74592874156755 30.119 35.66692893370595 139.74591686220052 30.119 35.66692866378319 139.7459175362876 8.87 35.66691947751413 139.7459406209431 8.87 35.66691947751413 139.7459406209431 26.285</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b979651c-34fb-4de1-a26c-baa62e1bfb3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b979651c-34fb-4de1-a26c-baa62e1bfb3a_0">
											<gml:posList>35.66695523818753 139.74593258481863 28.189 35.66692893370595 139.74591686220052 30.119 35.666924210117486 139.74592874156755 30.119 35.66695050557581 139.74594445315273 28.189 35.66695523818753 139.74593258481863 28.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36d98256-c2a1-4f21-b08e-6854da2d8a9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36d98256-c2a1-4f21-b08e-6854da2d8a9b_0">
											<gml:posList>35.66695050557581 139.74594445315273 28.189 35.666924210117486 139.74592874156755 30.119 35.666924210117486 139.74592874156755 26.285 35.66695050557581 139.74594445315273 28.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-feacd321-a470-4db6-94a7-b6a94d95795e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-feacd321-a470-4db6-94a7-b6a94d95795e_0">
											<gml:posList>35.66695050557581 139.74594445315273 28.189 35.666960551238745 139.74595046215987 28.189 35.666965274829295 139.74593858278865 28.189 35.66695523818753 139.74593258481863 28.189 35.66695050557581 139.74594445315273 28.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20d28c2f-6356-4cf7-a501-8e335bd173a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20d28c2f-6356-4cf7-a501-8e335bd173a4_0">
											<gml:posList>35.66695050557581 139.74594445315273 28.189 35.666924210117486 139.74592874156755 26.285 35.66691947751413 139.7459406209431 26.285 35.66694578198465 139.74595633252136 28.189 35.66695050557581 139.74594445315273 28.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c74b4e2d-8b7d-44d4-a968-07e82bd03b91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c74b4e2d-8b7d-44d4-a968-07e82bd03b91_0">
											<gml:posList>35.66695581863327 139.7459623415395 8.87 35.66696518485234 139.74593880380252 8.87 35.666965274829295 139.74593858278865 28.189 35.666960551238745 139.74595046215987 28.189 35.66695581863327 139.7459623415395 28.189 35.66695581863327 139.7459623415395 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cee97615-8379-4f83-8887-4afa754e1f77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cee97615-8379-4f83-8887-4afa754e1f77_0">
											<gml:posList>35.66695581863327 139.7459623415395 8.87 35.66695581863327 139.7459623415395 28.189 35.66694578198465 139.74595633252136 28.189 35.66691947751413 139.7459406209431 26.285 35.66691947751413 139.7459406209431 8.87 35.66695581863327 139.7459623415395 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bec3fad0-a64e-40bc-88cd-9d843ea8799c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bec3fad0-a64e-40bc-88cd-9d843ea8799c_0">
											<gml:posList>35.66694578198465 139.74595633252136 28.189 35.66695581863327 139.7459623415395 28.189 35.666960551238745 139.74595046215987 28.189 35.66695050557581 139.74594445315273 28.189 35.66694578198465 139.74595633252136 28.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ffaefa2f-2f63-4c8d-a45a-5342c92120ad_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf00611d-a8dc-4d10-86f9-7660680f1667">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666907232400774 139.74569883108492 34.772 35.66686006952672 139.7458186409204 34.772 35.666850754338455 139.7458131392456 34.772 35.66689791720712 139.74569332942085 34.772 35.666907232400774 139.74569883108492 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ea59e18-79be-401c-9e0f-65932b500ec7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687495740656 139.74583957851135 34.772 35.666876900816625 139.7458346831115 34.772 35.666911285109194 139.74585521283862 34.772 35.666909341698315 139.74586010824007 34.772 35.66687495740656 139.74583957851135 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07ee4b4f-bab1-47be-8124-27d85fd3e129">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666912044475204 139.74570948500576 34.772 35.6669213415442 139.7457148541431 34.772 35.666877302533635 139.74582931442535 34.772 35.666868014483384 139.74582394526783 34.772 35.666912044475204 139.74570948500576 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac8e8fc0-9964-4ef3-87b9-e9408699a066">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689772712293 139.74569223609635 33.613 35.66684601977176 139.74582230135897 33.613 35.66684057311116 139.7458190488002 33.613 35.66689493466101 139.74568232003807 33.613 35.66696370329403 139.74572337938832 33.613 35.666961049097694 139.7457300539447 33.613 35.66689772712293 139.74569223609635 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48aec960-3eab-4684-90b7-5d7a24b2de1d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689772712293 139.74569223609635 32.788 35.666961049097694 139.7457300539447 32.788 35.666909341698315 139.74586010824007 32.788 35.66684601977176 139.74582230135897 32.788 35.66689772712293 139.74569223609635 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c9af9d2-020b-4f51-be36-b753288fc466">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66688614460875 139.74582876353338 34.772 35.666911588035994 139.7457635325165 34.772 35.66693277032197 139.74577593589234 34.772 35.66690731788242 139.74584117797818 34.772 35.66688614460875 139.74582876353338 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d9c35c5-55ec-4a92-9f9f-f2002fb103bf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666934692500604 139.7457170708036 34.772 35.66693017587801 139.74572844185107 34.772 35.666921257418394 139.74572311648106 34.772 35.666925783054225 139.7457117454247 34.772 35.666934692500604 139.7457170708036 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa2df7db-2152-4e2e-b7f6-2018f7a8f047">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66694916924028 139.74586679167845 32.788 35.666945471232424 139.74587593057782 32.788 35.6669126106971 139.74585599564307 32.788 35.666916308703485 139.7458468567465 32.788 35.66694916924028 139.74586679167845 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-907c8777-b4b3-4678-802d-14226d0913ec">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66694205861401 139.74571966956066 34.772 35.6669522215068 139.74572573363986 34.772 35.66693952636314 139.74575768087695 34.772 35.666929363471944 139.74575161679468 34.772 35.66694205861401 139.74571966956066 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51901860-d21f-4872-a628-78e67199a15e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51901860-d21f-4872-a628-78e67199a15e_0">
											<gml:posList>35.666912044475204 139.74570948500576 34.772 35.666868014483384 139.74582394526783 34.772 35.666868014483384 139.74582394526783 35.791 35.666912044475204 139.74570948500576 35.791 35.666912044475204 139.74570948500576 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df519b46-40f7-4e82-af14-e94e76d2aaf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df519b46-40f7-4e82-af14-e94e76d2aaf5_0">
											<gml:posList>35.66688614460875 139.74582876353338 34.772 35.66690731788242 139.74584117797818 34.772 35.66690731788242 139.74584117797818 36.917 35.66688614460875 139.74582876353338 36.917 35.66688614460875 139.74582876353338 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4617335b-f6cd-421d-be28-f7f172482fb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4617335b-f6cd-421d-be28-f7f172482fb3_0">
											<gml:posList>35.666916308703485 139.7458468567465 32.788 35.6669126106971 139.74585599564307 32.788 35.6669126106971 139.74585599564307 34.772 35.666916308703485 139.7458468567465 34.772 35.666916308703485 139.7458468567465 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1b1175c-56ec-484c-bdfb-5e0c0f8e4436">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1b1175c-56ec-484c-bdfb-5e0c0f8e4436_0">
											<gml:posList>35.666907232400774 139.74569883108492 34.772 35.66689791720712 139.74569332942085 34.772 35.66689791720712 139.74569332942085 35.791 35.666907232400774 139.74569883108492 35.791 35.666907232400774 139.74569883108492 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba451a90-2a6f-4c9d-bd00-8fe25cbe0907">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba451a90-2a6f-4c9d-bd00-8fe25cbe0907_0">
											<gml:posList>35.66689493466101 139.74568232003807 33.613 35.66689493466101 139.74568232003807 34.772 35.66696370329403 139.74572337938832 34.772 35.66696370329403 139.74572337938832 33.613 35.66689493466101 139.74568232003807 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f116c05e-3783-4c32-88cd-74ff0d9dae00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f116c05e-3783-4c32-88cd-74ff0d9dae00_0">
											<gml:posList>35.66689772712293 139.74569223609635 33.613 35.666961049097694 139.7457300539447 33.613 35.666961049097694 139.7457300539447 32.788 35.66689772712293 139.74569223609635 32.788 35.66689772712293 139.74569223609635 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-083f4c2f-049d-498e-bd4a-c5ec391f0e07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-083f4c2f-049d-498e-bd4a-c5ec391f0e07_0">
											<gml:posList>35.666912044475204 139.74570948500576 35.791 35.6669213415442 139.7457148541431 35.791 35.6669213415442 139.7457148541431 34.772 35.666912044475204 139.74570948500576 34.772 35.666912044475204 139.74570948500576 35.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5296aa1-9ec9-460b-bf02-f132727026be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5296aa1-9ec9-460b-bf02-f132727026be_0">
											<gml:posList>35.666934692500604 139.7457170708036 34.772 35.666925783054225 139.7457117454247 34.772 35.666925783054225 139.7457117454247 37.376 35.666934692500604 139.7457170708036 37.376 35.666934692500604 139.7457170708036 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2dc1e13-bbc8-478a-a5c4-3e936555e86a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2dc1e13-bbc8-478a-a5c4-3e936555e86a_0">
											<gml:posList>35.666925783054225 139.7457117454247 34.772 35.666921257418394 139.74572311648106 34.772 35.666921257418394 139.74572311648106 37.376 35.666925783054225 139.7457117454247 37.376 35.666925783054225 139.7457117454247 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa0b54ee-499b-4bc2-b8b5-ef90a0aec5b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa0b54ee-499b-4bc2-b8b5-ef90a0aec5b0_0">
											<gml:posList>35.666934692500604 139.7457170708036 37.376 35.666925783054225 139.7457117454247 37.376 35.666921257418394 139.74572311648106 37.376 35.66693017587801 139.74572844185107 37.376 35.666934692500604 139.7457170708036 37.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c18098f-8128-4a7c-bd56-68d4feb5eeb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c18098f-8128-4a7c-bd56-68d4feb5eeb4_0">
											<gml:posList>35.66694205861401 139.74571966956066 36.715 35.6669522215068 139.74572573363986 36.715 35.6669522215068 139.74572573363986 34.772 35.66694205861401 139.74571966956066 34.772 35.66694205861401 139.74571966956066 36.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-610ff196-fe20-40f9-a67f-aaaa25ab3f5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-610ff196-fe20-40f9-a67f-aaaa25ab3f5c_0">
											<gml:posList>35.666934692500604 139.7457170708036 37.376 35.66693017587801 139.74572844185107 37.376 35.66693017587801 139.74572844185107 34.772 35.666934692500604 139.7457170708036 34.772 35.666934692500604 139.7457170708036 37.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ff5f8c8-ec76-4f12-b6e6-4a0af74392a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ff5f8c8-ec76-4f12-b6e6-4a0af74392a2_0">
											<gml:posList>35.666921257418394 139.74572311648106 34.772 35.66693017587801 139.74572844185107 34.772 35.66693017587801 139.74572844185107 37.376 35.666921257418394 139.74572311648106 37.376 35.666921257418394 139.74572311648106 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd7307ef-bd74-4919-891c-db7f9be228b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd7307ef-bd74-4919-891c-db7f9be228b4_0">
											<gml:posList>35.66694205861401 139.74571966956066 34.772 35.666929363471944 139.74575161679468 34.772 35.666929363471944 139.74575161679468 36.715 35.66694205861401 139.74571966956066 36.715 35.66694205861401 139.74571966956066 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ad10316-a1a2-462c-bdd9-597131a82f4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ad10316-a1a2-462c-bdd9-597131a82f4c_0">
											<gml:posList>35.66694205861401 139.74571966956066 36.715 35.666929363471944 139.74575161679468 36.715 35.66693952636314 139.74575768087695 36.715 35.6669522215068 139.74572573363986 36.715 35.66694205861401 139.74571966956066 36.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba132179-c406-47c1-ae29-212de8a23920">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba132179-c406-47c1-ae29-212de8a23920_0">
											<gml:posList>35.66693952636314 139.74575768087695 36.715 35.66693952636314 139.74575768087695 34.772 35.6669522215068 139.74572573363986 34.772 35.6669522215068 139.74572573363986 36.715 35.66693952636314 139.74575768087695 36.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ecbc8c9-81b6-4084-9e8e-0d8ea3bab595">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ecbc8c9-81b6-4084-9e8e-0d8ea3bab595_0">
											<gml:posList>35.66684057311116 139.7458190488002 33.613 35.66684057311116 139.7458190488002 34.772 35.66689493466101 139.74568232003807 34.772 35.66689493466101 139.74568232003807 33.613 35.66684057311116 139.7458190488002 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce1b0f49-d330-4709-9f84-6589cf0dfdf6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce1b0f49-d330-4709-9f84-6589cf0dfdf6_0">
											<gml:posList>35.66689791720712 139.74569332942085 34.772 35.666850754338455 139.7458131392456 34.772 35.666850754338455 139.7458131392456 35.791 35.66689791720712 139.74569332942085 35.791 35.66689791720712 139.74569332942085 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-649de40a-9538-4edb-a8d3-f66205975b44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-649de40a-9538-4edb-a8d3-f66205975b44_0">
											<gml:posList>35.666929363471944 139.74575161679468 34.772 35.66693952636314 139.74575768087695 34.772 35.66693952636314 139.74575768087695 36.715 35.666929363471944 139.74575161679468 36.715 35.666929363471944 139.74575161679468 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-080026a5-e042-4479-8c99-d95f4efb5b2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-080026a5-e042-4479-8c99-d95f4efb5b2a_0">
											<gml:posList>35.666907232400774 139.74569883108492 35.791 35.66689791720712 139.74569332942085 35.791 35.666850754338455 139.7458131392456 35.791 35.66686006952672 139.7458186409204 35.791 35.666907232400774 139.74569883108492 35.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-344ba8d5-d0e1-4c5f-be28-42d7e5ecf1c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-344ba8d5-d0e1-4c5f-be28-42d7e5ecf1c5_0">
											<gml:posList>35.66684601977176 139.74582230135897 33.613 35.66689772712293 139.74569223609635 33.613 35.66689772712293 139.74569223609635 32.788 35.66684601977176 139.74582230135897 32.788 35.66684601977176 139.74582230135897 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65798d56-b3ca-4e89-aa4f-cad786189e8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65798d56-b3ca-4e89-aa4f-cad786189e8d_0">
											<gml:posList>35.666907232400774 139.74569883108492 34.772 35.666907232400774 139.74569883108492 35.791 35.66686006952672 139.7458186409204 35.791 35.66686006952672 139.7458186409204 34.772 35.666907232400774 139.74569883108492 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fe08034-f6ab-4a32-be1e-223603bdd43d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fe08034-f6ab-4a32-be1e-223603bdd43d_0">
											<gml:posList>35.666912044475204 139.74570948500576 35.791 35.666868014483384 139.74582394526783 35.791 35.666877302533635 139.74582931442535 35.791 35.6669213415442 139.7457148541431 35.791 35.666912044475204 139.74570948500576 35.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e52c55d-f214-456f-8651-1f73e47823a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e52c55d-f214-456f-8651-1f73e47823a2_0">
											<gml:posList>35.66693277032197 139.74577593589234 36.917 35.66693277032197 139.74577593589234 34.772 35.666911588035994 139.7457635325165 34.772 35.666911588035994 139.7457635325165 36.917 35.66693277032197 139.74577593589234 36.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78ef36f2-87bd-4be1-8a8b-689a9def189a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78ef36f2-87bd-4be1-8a8b-689a9def189a_0">
											<gml:posList>35.66696370329403 139.74572337938832 34.772 35.66689493466101 139.74568232003807 34.772 35.66684057311116 139.7458190488002 34.772 35.666909341698315 139.74586010824007 34.772 35.66696370329403 139.74572337938832 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d04f575f-2fa9-45b2-9f32-6cdd32d7e513">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d04f575f-2fa9-45b2-9f32-6cdd32d7e513_0">
											<gml:posList>35.666877302533635 139.74582931442535 34.772 35.6669213415442 139.7457148541431 34.772 35.6669213415442 139.7457148541431 35.791 35.666877302533635 139.74582931442535 35.791 35.666877302533635 139.74582931442535 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd5715ef-16f6-4618-bf37-b7decc85ba9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd5715ef-16f6-4618-bf37-b7decc85ba9b_0">
											<gml:posList>35.666961049097694 139.7457300539447 33.613 35.66696370329403 139.74572337938832 33.613 35.66696370329403 139.74572337938832 34.772 35.666909341698315 139.74586010824007 34.772 35.666909341698315 139.74586010824007 32.788 35.666961049097694 139.7457300539447 32.788 35.666961049097694 139.7457300539447 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90246842-ffaa-477e-a00c-34c607dc539b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90246842-ffaa-477e-a00c-34c607dc539b_0">
											<gml:posList>35.66688614460875 139.74582876353338 36.917 35.666911588035994 139.7457635325165 36.917 35.666911588035994 139.7457635325165 34.772 35.66688614460875 139.74582876353338 34.772 35.66688614460875 139.74582876353338 36.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe06e7a5-9895-45dc-8ab6-3a81e565b7d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe06e7a5-9895-45dc-8ab6-3a81e565b7d1_0">
											<gml:posList>35.66688614460875 139.74582876353338 36.917 35.66690731788242 139.74584117797818 36.917 35.66693277032197 139.74577593589234 36.917 35.666911588035994 139.7457635325165 36.917 35.66688614460875 139.74582876353338 36.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0baded5-dc28-4772-8721-a18cbf362a25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0baded5-dc28-4772-8721-a18cbf362a25_0">
											<gml:posList>35.66690731788242 139.74584117797818 36.917 35.66690731788242 139.74584117797818 34.772 35.66693277032197 139.74577593589234 34.772 35.66693277032197 139.74577593589234 36.917 35.66690731788242 139.74584117797818 36.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eedd757c-9916-4876-bb16-b7bc82a2d7ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eedd757c-9916-4876-bb16-b7bc82a2d7ca_0">
											<gml:posList>35.666850754338455 139.7458131392456 34.772 35.66686006952672 139.7458186409204 34.772 35.66686006952672 139.7458186409204 35.791 35.666850754338455 139.7458131392456 35.791 35.666850754338455 139.7458131392456 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b2ce5eb-d253-40ca-a822-476aacc794bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b2ce5eb-d253-40ca-a822-476aacc794bf_0">
											<gml:posList>35.666868014483384 139.74582394526783 35.791 35.666868014483384 139.74582394526783 34.772 35.666877302533635 139.74582931442535 34.772 35.666877302533635 139.74582931442535 35.791 35.666868014483384 139.74582394526783 35.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11a4d9c7-b5d4-44c3-b52b-44477600a916">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11a4d9c7-b5d4-44c3-b52b-44477600a916_0">
											<gml:posList>35.666876900816625 139.7458346831115 34.772 35.66687495740656 139.74583957851135 34.772 35.66687495740656 139.74583957851135 36.917 35.666876900816625 139.7458346831115 36.917 35.666876900816625 139.7458346831115 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f674ed3-6df1-485f-8cd3-7332b542c833">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f674ed3-6df1-485f-8cd3-7332b542c833_0">
											<gml:posList>35.66684057311116 139.7458190488002 33.613 35.66684601977176 139.74582230135897 33.613 35.66684601977176 139.74582230135897 32.788 35.666909341698315 139.74586010824007 32.788 35.666909341698315 139.74586010824007 34.772 35.66684057311116 139.7458190488002 34.772 35.66684057311116 139.7458190488002 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cb27ee1-db05-4e7d-890e-e8542e3a449e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cb27ee1-db05-4e7d-890e-e8542e3a449e_0">
											<gml:posList>35.666876900816625 139.7458346831115 36.917 35.666911285109194 139.74585521283862 36.917 35.666911285109194 139.74585521283862 34.772 35.666876900816625 139.7458346831115 34.772 35.666876900816625 139.7458346831115 36.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63761b2c-3d5f-482e-91ec-b7abed73207b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63761b2c-3d5f-482e-91ec-b7abed73207b_0">
											<gml:posList>35.666876900816625 139.7458346831115 36.917 35.66687495740656 139.74583957851135 36.917 35.666909341698315 139.74586010824007 36.917 35.666911285109194 139.74585521283862 36.917 35.666876900816625 139.7458346831115 36.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7abfbcef-53e0-476f-8790-05ee94036688">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7abfbcef-53e0-476f-8790-05ee94036688_0">
											<gml:posList>35.66687495740656 139.74583957851135 34.772 35.666909341698315 139.74586010824007 34.772 35.666909341698315 139.74586010824007 36.917 35.66687495740656 139.74583957851135 36.917 35.66687495740656 139.74583957851135 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12731371-cfe5-442e-95b8-9b90456e2c72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12731371-cfe5-442e-95b8-9b90456e2c72_0">
											<gml:posList>35.66694916924028 139.74586679167845 34.772 35.66694916924028 139.74586679167845 32.788 35.666916308703485 139.7458468567465 32.788 35.666916308703485 139.7458468567465 34.772 35.66694916924028 139.74586679167845 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45edb8f4-9327-4c94-bd33-17e415b15f35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45edb8f4-9327-4c94-bd33-17e415b15f35_0">
											<gml:posList>35.666909341698315 139.74586010824007 34.772 35.666911285109194 139.74585521283862 34.772 35.666911285109194 139.74585521283862 36.917 35.666909341698315 139.74586010824007 36.917 35.666909341698315 139.74586010824007 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-758bafb7-7f77-439a-aeac-eeda9329da85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-758bafb7-7f77-439a-aeac-eeda9329da85_0">
											<gml:posList>35.66694916924028 139.74586679167845 34.772 35.666916308703485 139.7458468567465 34.772 35.6669126106971 139.74585599564307 34.772 35.666945471232424 139.74587593057782 34.772 35.66694916924028 139.74586679167845 34.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9742574d-462f-479a-80af-881525396378">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9742574d-462f-479a-80af-881525396378_0">
											<gml:posList>35.6669126106971 139.74585599564307 32.788 35.666945471232424 139.74587593057782 32.788 35.666945471232424 139.74587593057782 34.772 35.6669126106971 139.74585599564307 34.772 35.6669126106971 139.74585599564307 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bfd28ad-347c-4a10-8aea-997335f45b52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bfd28ad-347c-4a10-8aea-997335f45b52_0">
											<gml:posList>35.666945471232424 139.74587593057782 32.788 35.66694916924028 139.74586679167845 32.788 35.66694916924028 139.74586679167845 34.772 35.666945471232424 139.74587593057782 34.772 35.666945471232424 139.74587593057782 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-72471061-c887-4e79-ae89-a0960f378229">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72471061-c887-4e79-ae89-a0960f378229">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72471061-c887-4e79-ae89-a0960f378229">
											<gml:posList>35.66698885744136 139.74576856233566 8.87 35.6670243870342 139.7457898419268 8.87 35.66696518485234 139.74593880380252 8.87 35.66692866378319 139.7459175362876 8.87 35.66690266154954 139.74598294461086 8.87 35.66676234515147 139.74589660914688 8.87 35.66687085215292 139.74562343923586 8.87 35.667012880146665 139.74570811559832 8.87 35.66698885744136 139.74576856233566 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b63e3f33-48bb-4a9e-bbf5-a9592b355516">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b63e3f33-48bb-4a9e-bbf5-a9592b355516">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b63e3f33-48bb-4a9e-bbf5-a9592b355516">
											<gml:posList>35.66687085215292 139.74562343923586 21.7 35.66676234515147 139.74589660914688 21.7 35.66676675154179 139.7458947817914 21.7 35.66687237943141 139.74562887208745 21.7 35.66687085215292 139.74562343923586 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-549546b6-71ba-4d7e-8dae-72b7a72a3da2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-549546b6-71ba-4d7e-8dae-72b7a72a3da2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-549546b6-71ba-4d7e-8dae-72b7a72a3da2">
											<gml:posList>35.66676234515147 139.74589660914688 21.7 35.66690266154954 139.74598294461086 21.7 35.66690114327669 139.74597747860332 21.7 35.66676675154179 139.7458947817914 21.7 35.66676234515147 139.74589660914688 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ffa2b024-2712-452b-bcca-581df9888646">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffa2b024-2712-452b-bcca-581df9888646">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffa2b024-2712-452b-bcca-581df9888646">
											<gml:posList>35.66689493466101 139.74568232003807 33.613 35.66682067110421 139.74586911890262 33.613 35.66682876294602 139.7458656858876 33.613 35.66689772712293 139.74569223609635 33.613 35.66689493466101 139.74568232003807 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e383eea-eb2d-4140-b06e-60936168cdde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e383eea-eb2d-4140-b06e-60936168cdde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e383eea-eb2d-4140-b06e-60936168cdde">
											<gml:posList>35.66682067110421 139.74586911890262 33.613 35.66692350833742 139.7459305207037 33.613 35.66692071588708 139.74592059358812 33.613 35.66682876294602 139.7458656858876 33.613 35.66682067110421 139.74586911890262 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fea04aed-693e-4760-b698-92af18e615d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fea04aed-693e-4760-b698-92af18e615d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fea04aed-693e-4760-b698-92af18e615d6">
											<gml:posList>35.66676675154179 139.7458947817914 21.225 35.66690114327669 139.74597747860332 21.225 35.66692052349421 139.7459287345402 21.225 35.66682067110421 139.74586911890262 21.225 35.66689493466101 139.74568232003807 21.225 35.66699556266016 139.74574239857407 21.225 35.667008446758366 139.74570999822814 21.225 35.66687237943141 139.74562887208745 21.225 35.66676675154179 139.7458947817914 21.225</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a952c8d-726c-49ac-8f6c-ec3f8f612eea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a952c8d-726c-49ac-8f6c-ec3f8f612eea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a952c8d-726c-49ac-8f6c-ec3f8f612eea">
											<gml:posList>35.6669815393375 139.7457700062799 32.788 35.666990446646224 139.74574760673093 32.788 35.66689772712293 139.74569223609635 32.788 35.66682876294602 139.7458656858876 32.788 35.66692071588708 139.74592059358812 32.788 35.666924791657046 139.74591032761182 32.788 35.66693023830709 139.74591356913444 32.788 35.66694916924028 139.74586679167845 32.788 35.666916308703485 139.7458468567465 32.788 35.666940521114235 139.74578692903216 32.788 35.66697338166079 139.74580686394555 32.788 35.66698697701769 139.74577330303404 32.788 35.6669815393375 139.7457700062799 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-907c8453-fdc0-4f53-9073-2526ab8f6c9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-907c8453-fdc0-4f53-9073-2526ab8f6c9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-907c8453-fdc0-4f53-9073-2526ab8f6c9d">
											<gml:posList>35.66692350833742 139.7459305207037 21.7 35.66692052349421 139.7459287345402 21.7 35.66690114327669 139.74597747860332 21.7 35.66690266154954 139.74598294461086 21.7 35.66692350833742 139.7459305207037 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7af89e69-6095-4fc6-a7a5-6492c1c5c3e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7af89e69-6095-4fc6-a7a5-6492c1c5c3e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7af89e69-6095-4fc6-a7a5-6492c1c5c3e2">
											<gml:posList>35.666924791657046 139.74591032761182 33.613 35.66692071588708 139.74592059358812 33.613 35.66692350833742 139.7459305207037 33.613 35.66692884372902 139.74591708321427 33.613 35.66693023830709 139.74591356913444 33.613 35.666924791657046 139.74591032761182 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e37de8d2-3ce5-401f-950b-9174ea688143">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e37de8d2-3ce5-401f-950b-9174ea688143">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e37de8d2-3ce5-401f-950b-9174ea688143">
											<gml:posList>35.667012880146665 139.74570811559832 21.7 35.66687085215292 139.74562343923586 21.7 35.66687237943141 139.74562887208745 21.7 35.667008446758366 139.74570999822814 21.7 35.667012880146665 139.74570811559832 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-501754d6-a84f-40cf-83fc-a605294721a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-501754d6-a84f-40cf-83fc-a605294721a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-501754d6-a84f-40cf-83fc-a605294721a3">
											<gml:posList>35.66694916924028 139.74586679167845 37.238 35.66697338166079 139.74580686394555 37.238 35.666940521114235 139.74578692903216 37.238 35.666916308703485 139.7458468567465 37.238 35.66694916924028 139.74586679167845 37.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-926d5fcf-d951-4a8c-a95e-71155753603c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-926d5fcf-d951-4a8c-a95e-71155753603c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-926d5fcf-d951-4a8c-a95e-71155753603c">
											<gml:posList>35.666998547506076 139.7457441847323 33.613 35.66689493466101 139.74568232003807 33.613 35.66689772712293 139.74569223609635 33.613 35.666990446646224 139.74574760673093 33.613 35.666998547506076 139.7457441847323 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d57195e-3e55-4f62-a5ed-3a53418371bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d57195e-3e55-4f62-a5ed-3a53418371bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d57195e-3e55-4f62-a5ed-3a53418371bf">
											<gml:posList>35.66692884372902 139.74591708321427 42.542 35.666965364806245 139.74593836177482 42.542 35.6669633950833 139.7459318469059 42.542 35.66693444844033 139.74591455866528 42.542 35.66692884372902 139.74591708321427 42.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-376b6b57-116e-49f8-a983-87406c78bd02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-376b6b57-116e-49f8-a983-87406c78bd02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-376b6b57-116e-49f8-a983-87406c78bd02">
											<gml:posList>35.66695623153488 139.745860631471 42.392 35.66693444844033 139.74591455866528 42.392 35.6669633950833 139.7459318469059 42.392 35.666984799640936 139.74587796429284 42.392 35.66695623153488 139.745860631471 42.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c044da7-ddeb-42d0-9ac2-2f59e71d66d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c044da7-ddeb-42d0-9ac2-2f59e71d66d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c044da7-ddeb-42d0-9ac2-2f59e71d66d6">
											<gml:posList>35.66698885744136 139.74576856233566 42.542 35.66692884372902 139.74591708321427 42.542 35.66693444844033 139.74591455866528 42.542 35.66699071915295 139.7457752761448 42.542 35.66698885744136 139.74576856233566 42.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8e4dc81-ea4f-4e54-9071-7184bfa4e692">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8e4dc81-ea4f-4e54-9071-7184bfa4e692">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8e4dc81-ea4f-4e54-9071-7184bfa4e692">
											<gml:posList>35.666984799640936 139.74587796429284 40.12 35.66700391887718 139.74582985004997 40.12 35.66697561227484 139.7458126715968 40.12 35.66695623153488 139.745860631471 40.12 35.666984799640936 139.74587796429284 40.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9adaf56a-cd14-460a-ac9c-647261306af3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9adaf56a-cd14-460a-ac9c-647261306af3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9adaf56a-cd14-460a-ac9c-647261306af3">
											<gml:posList>35.666990446646224 139.74574760673093 33.613 35.6669815393375 139.7457700062799 33.613 35.66698686878869 139.74577321478588 33.613 35.666998547506076 139.7457441847323 33.613 35.666990446646224 139.74574760673093 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b14d5ee5-6477-4634-a259-2e95149a8578">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b14d5ee5-6477-4634-a259-2e95149a8578">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b14d5ee5-6477-4634-a259-2e95149a8578">
											<gml:posList>35.666965364806245 139.74593836177482 42.542 35.6670243870342 139.7457898419268 42.542 35.66701889935954 139.74579216753526 42.542 35.6669633950833 139.7459318469059 42.542 35.666965364806245 139.74593836177482 42.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01396036-2937-4905-9d33-8021c156f574">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01396036-2937-4905-9d33-8021c156f574">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01396036-2937-4905-9d33-8021c156f574">
											<gml:posList>35.66700391887718 139.74582985004997 38.121 35.66701889935954 139.74579216753526 38.121 35.66699071915295 139.7457752761448 38.121 35.66697561227484 139.7458126715968 38.121 35.66700391887718 139.74582985004997 38.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2cdf115-4e32-4743-94ed-c0f0869ccf4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2cdf115-4e32-4743-94ed-c0f0869ccf4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2cdf115-4e32-4743-94ed-c0f0869ccf4b">
											<gml:posList>35.666998547506076 139.7457441847323 21.7 35.667012880146665 139.74570811559832 21.7 35.667008446758366 139.74570999822814 21.7 35.66699556266016 139.74574239857407 21.7 35.666998547506076 139.7457441847323 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b169cae-018e-4147-bb23-cbb669764e94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b169cae-018e-4147-bb23-cbb669764e94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b169cae-018e-4147-bb23-cbb669764e94">
											<gml:posList>35.6670243870342 139.7457898419268 42.542 35.66698885744136 139.74576856233566 42.542 35.66699071915295 139.7457752761448 42.542 35.66701889935954 139.74579216753526 42.542 35.6670243870342 139.7457898419268 42.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-078e36bd-33fc-4488-8a8e-7cf6e1c8f651">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-078e36bd-33fc-4488-8a8e-7cf6e1c8f651">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-078e36bd-33fc-4488-8a8e-7cf6e1c8f651">
											<gml:posList>35.66695623153488 139.745860631471 42.392 35.66695623153488 139.745860631471 40.12 35.66697561227484 139.7458126715968 40.12 35.66697561227484 139.7458126715968 38.121 35.66699071915295 139.7457752761448 38.121 35.66699071915295 139.7457752761448 42.542 35.66693444844033 139.74591455866528 42.542 35.66693444844033 139.74591455866528 42.392 35.66695623153488 139.745860631471 42.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d159668-b8a8-41be-9dde-e11df4cf2102">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d159668-b8a8-41be-9dde-e11df4cf2102">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d159668-b8a8-41be-9dde-e11df4cf2102">
											<gml:posList>35.66700391887718 139.74582985004997 40.12 35.666984799640936 139.74587796429284 40.12 35.666984799640936 139.74587796429284 42.392 35.6669633950833 139.7459318469059 42.392 35.6669633950833 139.7459318469059 42.542 35.66701889935954 139.74579216753526 42.542 35.66701889935954 139.74579216753526 38.121 35.66700391887718 139.74582985004997 38.121 35.66700391887718 139.74582985004997 40.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f583f67-4161-4d21-985e-90bb026ed0c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f583f67-4161-4d21-985e-90bb026ed0c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f583f67-4161-4d21-985e-90bb026ed0c2">
											<gml:posList>35.66687085215292 139.74562343923586 21.7 35.66687085215292 139.74562343923586 8.87 35.66676234515147 139.74589660914688 8.87 35.66676234515147 139.74589660914688 21.7 35.66687085215292 139.74562343923586 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc1407fe-a24f-4a39-bb0d-41cda4939cf3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc1407fe-a24f-4a39-bb0d-41cda4939cf3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc1407fe-a24f-4a39-bb0d-41cda4939cf3">
											<gml:posList>35.66687237943141 139.74562887208745 21.7 35.66676675154179 139.7458947817914 21.7 35.66676675154179 139.7458947817914 21.225 35.66687237943141 139.74562887208745 21.225 35.66687237943141 139.74562887208745 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2261a97a-591c-4b03-b5cd-e5492a42fb92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2261a97a-591c-4b03-b5cd-e5492a42fb92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2261a97a-591c-4b03-b5cd-e5492a42fb92">
											<gml:posList>35.66682067110421 139.74586911890262 21.225 35.66682067110421 139.74586911890262 33.613 35.66689493466101 139.74568232003807 33.613 35.66689493466101 139.74568232003807 21.225 35.66682067110421 139.74586911890262 21.225</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82aaaff7-2017-4e74-bace-a1d6464d5ed8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82aaaff7-2017-4e74-bace-a1d6464d5ed8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82aaaff7-2017-4e74-bace-a1d6464d5ed8">
											<gml:posList>35.66689772712293 139.74569223609635 33.613 35.66682876294602 139.7458656858876 33.613 35.66682876294602 139.7458656858876 32.788 35.66689772712293 139.74569223609635 32.788 35.66689772712293 139.74569223609635 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7a80cf0-5a51-4c82-900e-c03870e514eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7a80cf0-5a51-4c82-900e-c03870e514eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7a80cf0-5a51-4c82-900e-c03870e514eb">
											<gml:posList>35.667008446758366 139.74570999822814 21.7 35.66687237943141 139.74562887208745 21.7 35.66687237943141 139.74562887208745 21.225 35.667008446758366 139.74570999822814 21.225 35.667008446758366 139.74570999822814 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8ae69ec-f046-4bde-8ad1-396a70a44146">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8ae69ec-f046-4bde-8ad1-396a70a44146">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8ae69ec-f046-4bde-8ad1-396a70a44146">
											<gml:posList>35.667012880146665 139.74570811559832 21.7 35.667012880146665 139.74570811559832 8.87 35.66687085215292 139.74562343923586 8.87 35.66687085215292 139.74562343923586 21.7 35.667012880146665 139.74570811559832 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-581d209c-7b32-4ef9-ac9a-8c71eb2fd261">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-581d209c-7b32-4ef9-ac9a-8c71eb2fd261">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-581d209c-7b32-4ef9-ac9a-8c71eb2fd261">
											<gml:posList>35.666990446646224 139.74574760673093 33.613 35.66689772712293 139.74569223609635 33.613 35.66689772712293 139.74569223609635 32.788 35.666990446646224 139.74574760673093 32.788 35.666990446646224 139.74574760673093 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b855bc79-642d-4c59-bef9-cc1e7c5553a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b855bc79-642d-4c59-bef9-cc1e7c5553a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b855bc79-642d-4c59-bef9-cc1e7c5553a9">
											<gml:posList>35.66699556266016 139.74574239857407 21.7 35.66699556266016 139.74574239857407 21.225 35.66689493466101 139.74568232003807 21.225 35.66689493466101 139.74568232003807 33.613 35.666998547506076 139.7457441847323 33.613 35.666998547506076 139.7457441847323 21.7 35.66699556266016 139.74574239857407 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47905200-7ad6-43a0-a984-028ecff01063">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47905200-7ad6-43a0-a984-028ecff01063">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47905200-7ad6-43a0-a984-028ecff01063">
											<gml:posList>35.66698686878869 139.74577321478588 33.613 35.6669815393375 139.7457700062799 33.613 35.6669815393375 139.7457700062799 32.788 35.66698697701769 139.74577330303404 32.788 35.66698686878869 139.74577321478588 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0be2617-25ac-4b79-b92f-75a787fdbfbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0be2617-25ac-4b79-b92f-75a787fdbfbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0be2617-25ac-4b79-b92f-75a787fdbfbd">
											<gml:posList>35.6669815393375 139.7457700062799 33.613 35.666990446646224 139.74574760673093 33.613 35.666990446646224 139.74574760673093 32.788 35.6669815393375 139.7457700062799 32.788 35.6669815393375 139.7457700062799 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-828ff633-d20e-4927-bfb8-abdb64a25759">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-828ff633-d20e-4927-bfb8-abdb64a25759">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-828ff633-d20e-4927-bfb8-abdb64a25759">
											<gml:posList>35.66698885744136 139.74576856233566 8.87 35.667012880146665 139.74570811559832 8.87 35.667012880146665 139.74570811559832 21.7 35.666998547506076 139.7457441847323 21.7 35.666998547506076 139.7457441847323 33.613 35.66698686878869 139.74577321478588 33.613 35.66698885744136 139.74576856233566 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59648ba3-81a7-4a8e-b4fb-a172773156c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59648ba3-81a7-4a8e-b4fb-a172773156c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59648ba3-81a7-4a8e-b4fb-a172773156c6">
											<gml:posList>35.66699556266016 139.74574239857407 21.7 35.667008446758366 139.74570999822814 21.7 35.667008446758366 139.74570999822814 21.225 35.66699556266016 139.74574239857407 21.225 35.66699556266016 139.74574239857407 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5eb34eb7-35e5-416a-9a96-5f5f756a0794">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5eb34eb7-35e5-416a-9a96-5f5f756a0794">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5eb34eb7-35e5-416a-9a96-5f5f756a0794">
											<gml:posList>35.66701889935954 139.74579216753526 42.542 35.66699071915295 139.7457752761448 42.542 35.66699071915295 139.7457752761448 38.121 35.66701889935954 139.74579216753526 38.121 35.66701889935954 139.74579216753526 42.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3f34058-3d35-4904-9f11-93e333a9b1b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3f34058-3d35-4904-9f11-93e333a9b1b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3f34058-3d35-4904-9f11-93e333a9b1b0">
											<gml:posList>35.6670243870342 139.7457898419268 42.542 35.6670243870342 139.7457898419268 8.87 35.66698885744136 139.74576856233566 8.87 35.6670243870342 139.7457898419268 42.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d225c73c-ab61-4407-9ec5-8c25501c5231">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d225c73c-ab61-4407-9ec5-8c25501c5231">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d225c73c-ab61-4407-9ec5-8c25501c5231">
											<gml:posList>35.6670243870342 139.7457898419268 42.542 35.66698885744136 139.74576856233566 8.87 35.66698885744136 139.74576856233566 42.542 35.6670243870342 139.7457898419268 42.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b28af0b-6915-4962-b7da-f4d6e9d939fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b28af0b-6915-4962-b7da-f4d6e9d939fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b28af0b-6915-4962-b7da-f4d6e9d939fc">
											<gml:posList>35.66676234515147 139.74589660914688 21.7 35.66676234515147 139.74589660914688 8.87 35.66690266154954 139.74598294461086 8.87 35.66690266154954 139.74598294461086 21.7 35.66676234515147 139.74589660914688 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d6b4c96-b73c-471a-839a-f4ef10c7ced6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d6b4c96-b73c-471a-839a-f4ef10c7ced6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d6b4c96-b73c-471a-839a-f4ef10c7ced6">
											<gml:posList>35.66676675154179 139.7458947817914 21.7 35.66690114327669 139.74597747860332 21.7 35.66690114327669 139.74597747860332 21.225 35.66676675154179 139.7458947817914 21.225 35.66676675154179 139.7458947817914 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b718be81-c8ac-43cf-8bd3-b2858dd3596c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b718be81-c8ac-43cf-8bd3-b2858dd3596c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b718be81-c8ac-43cf-8bd3-b2858dd3596c">
											<gml:posList>35.66692052349421 139.7459287345402 21.7 35.66692350833742 139.7459305207037 21.7 35.66692350833742 139.7459305207037 33.613 35.66682067110421 139.74586911890262 33.613 35.66682067110421 139.74586911890262 21.225 35.66692052349421 139.7459287345402 21.225 35.66692052349421 139.7459287345402 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae27308f-ffa2-43ae-b12e-3bdf3a0dc303">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae27308f-ffa2-43ae-b12e-3bdf3a0dc303">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae27308f-ffa2-43ae-b12e-3bdf3a0dc303">
											<gml:posList>35.66682876294602 139.7458656858876 33.613 35.66692071588708 139.74592059358812 33.613 35.66692071588708 139.74592059358812 32.788 35.66682876294602 139.7458656858876 32.788 35.66682876294602 139.7458656858876 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8e73895-fcc1-461f-b790-55b641995d47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8e73895-fcc1-461f-b790-55b641995d47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8e73895-fcc1-461f-b790-55b641995d47">
											<gml:posList>35.66690114327669 139.74597747860332 21.7 35.66692052349421 139.7459287345402 21.7 35.66692052349421 139.7459287345402 21.225 35.66690114327669 139.74597747860332 21.225 35.66690114327669 139.74597747860332 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4454e9e-a259-436a-9e67-3fc7ec3d3a0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4454e9e-a259-436a-9e67-3fc7ec3d3a0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4454e9e-a259-436a-9e67-3fc7ec3d3a0c">
											<gml:posList>35.66692884372902 139.74591708321427 33.613 35.66692350833742 139.7459305207037 33.613 35.66692350833742 139.7459305207037 21.7 35.66690266154954 139.74598294461086 21.7 35.66690266154954 139.74598294461086 8.87 35.66692866378319 139.7459175362876 8.87 35.66692884372902 139.74591708321427 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e44bff5-7ab0-4b34-a674-8f013f1d0818">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e44bff5-7ab0-4b34-a674-8f013f1d0818">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e44bff5-7ab0-4b34-a674-8f013f1d0818">
											<gml:posList>35.66692071588708 139.74592059358812 33.613 35.666924791657046 139.74591032761182 33.613 35.666924791657046 139.74591032761182 32.788 35.66692071588708 139.74592059358812 32.788 35.66692071588708 139.74592059358812 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d4b2a66-5b4c-42c3-a6b6-0bc2234f0f58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d4b2a66-5b4c-42c3-a6b6-0bc2234f0f58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d4b2a66-5b4c-42c3-a6b6-0bc2234f0f58">
											<gml:posList>35.66693023830709 139.74591356913444 33.613 35.66693023830709 139.74591356913444 32.788 35.666924791657046 139.74591032761182 32.788 35.666924791657046 139.74591032761182 33.613 35.66693023830709 139.74591356913444 33.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a51f8dd-f6ae-4b43-a58c-1db867f276e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a51f8dd-f6ae-4b43-a58c-1db867f276e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a51f8dd-f6ae-4b43-a58c-1db867f276e3">
											<gml:posList>35.666916308703485 139.7458468567465 37.238 35.666940521114235 139.74578692903216 37.238 35.666940521114235 139.74578692903216 32.788 35.666916308703485 139.7458468567465 32.788 35.666916308703485 139.7458468567465 37.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-526d50d0-471e-41c2-958d-26a298000812">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-526d50d0-471e-41c2-958d-26a298000812">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-526d50d0-471e-41c2-958d-26a298000812">
											<gml:posList>35.66694916924028 139.74586679167845 37.238 35.666916308703485 139.7458468567465 37.238 35.666916308703485 139.7458468567465 32.788 35.66694916924028 139.74586679167845 32.788 35.66694916924028 139.74586679167845 37.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01c7502d-d291-4ed2-bacb-86f891c83779">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01c7502d-d291-4ed2-bacb-86f891c83779">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01c7502d-d291-4ed2-bacb-86f891c83779">
											<gml:posList>35.66694916924028 139.74586679167845 32.788 35.66693023830709 139.74591356913444 32.788 35.66693023830709 139.74591356913444 33.613 35.66692884372902 139.74591708321427 33.613 35.66692884372902 139.74591708321427 42.542 35.66694916924028 139.74586679167845 37.238 35.66694916924028 139.74586679167845 32.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ba21a88-7c9d-4127-8ec0-56c0288c1288">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ba21a88-7c9d-4127-8ec0-56c0288c1288">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ba21a88-7c9d-4127-8ec0-56c0288c1288">
											<gml:posList>35.666965364806245 139.74593836177482 42.542 35.66692884372902 139.74591708321427 42.542 35.66692884372902 139.74591708321427 33.613 35.66692866378319 139.7459175362876 8.87 35.66696518485234 139.74593880380252 8.87 35.666965364806245 139.74593836177482 42.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6535076f-16b1-4367-99b9-ac5c7c26e306">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6535076f-16b1-4367-99b9-ac5c7c26e306">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6535076f-16b1-4367-99b9-ac5c7c26e306">
											<gml:posList>35.6669633950833 139.7459318469059 42.542 35.6669633950833 139.7459318469059 42.392 35.66693444844033 139.74591455866528 42.392 35.66693444844033 139.74591455866528 42.542 35.6669633950833 139.7459318469059 42.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab1dfacb-bc61-47c3-8472-15bf25192f8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab1dfacb-bc61-47c3-8472-15bf25192f8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab1dfacb-bc61-47c3-8472-15bf25192f8b">
											<gml:posList>35.666940521114235 139.74578692903216 37.238 35.66697338166079 139.74580686394555 37.238 35.66697338166079 139.74580686394555 32.788 35.666940521114235 139.74578692903216 32.788 35.666940521114235 139.74578692903216 37.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b29b7456-ade7-4773-959f-aaa7129fdef3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b29b7456-ade7-4773-959f-aaa7129fdef3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b29b7456-ade7-4773-959f-aaa7129fdef3">
											<gml:posList>35.66698885744136 139.74576856233566 42.542 35.66697338166079 139.74580686394555 37.238 35.66694916924028 139.74586679167845 37.238 35.66692884372902 139.74591708321427 42.542 35.66698885744136 139.74576856233566 42.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa5dbfcf-3af1-43ab-8f76-144328422b5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa5dbfcf-3af1-43ab-8f76-144328422b5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa5dbfcf-3af1-43ab-8f76-144328422b5b">
											<gml:posList>35.666984799640936 139.74587796429284 40.12 35.66695623153488 139.745860631471 40.12 35.66695623153488 139.745860631471 42.392 35.666984799640936 139.74587796429284 42.392 35.666984799640936 139.74587796429284 40.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0d7511f-9fd2-41eb-8c6d-b93564df07dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0d7511f-9fd2-41eb-8c6d-b93564df07dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0d7511f-9fd2-41eb-8c6d-b93564df07dd">
											<gml:posList>35.66698885744136 139.74576856233566 42.542 35.66698885744136 139.74576856233566 8.87 35.66698686878869 139.74577321478588 33.613 35.66698697701769 139.74577330303404 32.788 35.66697338166079 139.74580686394555 32.788 35.66697338166079 139.74580686394555 37.238 35.66698885744136 139.74576856233566 42.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2762f994-2ef9-4835-9e4f-ed57b18ebd3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2762f994-2ef9-4835-9e4f-ed57b18ebd3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2762f994-2ef9-4835-9e4f-ed57b18ebd3a">
											<gml:posList>35.66700391887718 139.74582985004997 38.121 35.66697561227484 139.7458126715968 38.121 35.66697561227484 139.7458126715968 40.12 35.66700391887718 139.74582985004997 40.12 35.66700391887718 139.74582985004997 38.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-111325f2-a70e-4fac-af06-dc1b422a56b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-111325f2-a70e-4fac-af06-dc1b422a56b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-111325f2-a70e-4fac-af06-dc1b422a56b4">
											<gml:posList>35.6670243870342 139.7457898419268 42.542 35.666965364806245 139.74593836177482 42.542 35.66696518485234 139.74593880380252 8.87 35.6670243870342 139.7457898419268 8.87 35.6670243870342 139.7457898419268 42.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11489</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">548.8675</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>