<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ffffb029-f549-49d2-a573-3424074e463b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">11.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66707624240719 139.73833265227591 0 35.667025364852186 139.7383961154274 0 35.6670644299871 139.7384413569666 0 35.667114858447064 139.73837988259032 0 35.66707624240719 139.73833265227591 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66707624240719 139.73833265227591 13.065 35.667114858447064 139.73837988259032 13.065 35.6670644299871 139.7384413569666 13.065 35.667025364852186 139.7383961154274 13.065 35.66707624240719 139.73833265227591 13.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66707624240719 139.73833265227591 13.065 35.667025364852186 139.7383961154274 13.065 35.667025364852186 139.7383961154274 24.47 35.66707624240719 139.73833265227591 24.47 35.66707624240719 139.73833265227591 13.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667025364852186 139.7383961154274 13.065 35.6670644299871 139.7384413569666 13.065 35.6670644299871 139.7384413569666 24.47 35.667025364852186 139.7383961154274 24.47 35.667025364852186 139.7383961154274 13.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6670644299871 139.7384413569666 13.065 35.667114858447064 139.73837988259032 13.065 35.667114858447064 139.73837988259032 24.47 35.6670644299871 139.7384413569666 24.47 35.6670644299871 139.7384413569666 13.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667114858447064 139.73837988259032 13.065 35.66707624240719 139.73833265227591 13.065 35.66707624240719 139.73833265227591 24.47 35.667114858447064 139.73837988259032 24.47 35.667114858447064 139.73837988259032 13.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66707624240719 139.73833265227591 24.47 35.667025364852186 139.7383961154274 24.47 35.6670644299871 139.7384413569666 24.47 35.667114858447064 139.73837988259032 24.47 35.66707624240719 139.73833265227591 24.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5276bf23-f000-445f-a01d-c9023631f02d"/>
							<gml:surfaceMember xlink:href="#poly-b666364d-ad8b-4076-a509-7254402d5de0"/>
							<gml:surfaceMember xlink:href="#poly-22b4e5ef-d51f-4238-88ea-1b193200453a"/>
							<gml:surfaceMember xlink:href="#poly-2c31f2aa-069e-4698-bf02-fb9bf257777d"/>
							<gml:surfaceMember xlink:href="#poly-046548fa-82a4-4618-8af4-48537e53a433"/>
							<gml:surfaceMember xlink:href="#poly-6cb89ae1-a575-40f3-ae96-cef556fcf2b0"/>
							<gml:surfaceMember xlink:href="#poly-1606c9e2-1146-4676-88d6-7c92163ced48"/>
							<gml:surfaceMember xlink:href="#poly-0cad3278-e9cb-45b1-bd3a-ac5da593aee4"/>
							<gml:surfaceMember xlink:href="#poly-1ec457f8-4fba-4cc4-b746-ca6518349abd"/>
							<gml:surfaceMember xlink:href="#poly-119df4c9-9adf-4d01-b93e-9401360a580b"/>
							<gml:surfaceMember xlink:href="#poly-01d022b1-47ce-490e-9e7f-2d41aaa9d75c"/>
							<gml:surfaceMember xlink:href="#poly-e78058f7-ce14-4783-802a-a54a75eef9f4"/>
							<gml:surfaceMember xlink:href="#poly-49a6d4b1-0210-4689-b3e9-90b2091019f0"/>
							<gml:surfaceMember xlink:href="#poly-195a1830-c302-45c3-b3fa-2fc69020e6a1"/>
							<gml:surfaceMember xlink:href="#poly-e90b3dfe-3469-49a7-8b54-217ebee93ca4"/>
							<gml:surfaceMember xlink:href="#poly-22238f28-6138-47ab-8ea2-7537089c905b"/>
							<gml:surfaceMember xlink:href="#poly-b64bd0ed-d5bc-440d-9c5e-1ced38a09ef6"/>
							<gml:surfaceMember xlink:href="#poly-92d60b36-513e-41b1-99d8-46b5a968209f"/>
							<gml:surfaceMember xlink:href="#poly-fd69325a-1eff-455a-8cfd-38c93550dd46"/>
							<gml:surfaceMember xlink:href="#poly-d03337b9-4b23-4d03-997c-0f316ce6d3f6"/>
							<gml:surfaceMember xlink:href="#poly-146cdbd3-7835-4cb2-a752-4ac3e3ee3422"/>
							<gml:surfaceMember xlink:href="#poly-9194a35f-a017-4a9d-8e90-7551f6770982"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ffffb029-f549-49d2-a573-3424074e463b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99a25dff-4269-42b5-a493-b4b3618925d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66708680757218 139.73839114939088 25.478 35.667096163898776 139.73840267013526 25.478 35.667064429987086 139.73844135696658 25.478 35.66705507365545 139.73842982517644 25.478 35.66708680757218 139.73839114939088 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3629f9cb-d77a-41fe-9045-630c5fc30e70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3629f9cb-d77a-41fe-9045-630c5fc30e70_0">
											<gml:posList>35.66708680757218 139.73839114939088 25.478 35.66708680757218 139.73839114939088 27.865 35.667096163898776 139.73840267013526 27.865 35.667096163898776 139.73840267013526 25.478 35.66708680757218 139.73839114939088 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d3f75fb-baef-4cbf-9b67-9eee41279273">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d3f75fb-baef-4cbf-9b67-9eee41279273_0">
											<gml:posList>35.66708680757218 139.73839114939088 25.478 35.66705507365545 139.73842982517644 25.478 35.66705507365545 139.73842982517644 27.865 35.66708680757218 139.73839114939088 27.865 35.66708680757218 139.73839114939088 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-350b830d-03af-4d25-a6cb-299712ee4d69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-350b830d-03af-4d25-a6cb-299712ee4d69_0">
											<gml:posList>35.66708680757218 139.73839114939088 27.865 35.66705507365545 139.73842982517644 27.865 35.667064429987086 139.73844135696658 27.865 35.667096163898776 139.73840267013526 27.865 35.66708680757218 139.73839114939088 27.865</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e54a2ee9-9b28-4f7c-a12b-d656341ccc26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e54a2ee9-9b28-4f7c-a12b-d656341ccc26_0">
											<gml:posList>35.667064429987086 139.73844135696658 25.478 35.667096163898776 139.73840267013526 25.478 35.667096163898776 139.73840267013526 27.865 35.667064429987086 139.73844135696658 27.865 35.667064429987086 139.73844135696658 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d644ffe-2a64-4a15-ab70-0be8e2d04adf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d644ffe-2a64-4a15-ab70-0be8e2d04adf_0">
											<gml:posList>35.66705507365545 139.73842982517644 25.478 35.667064429987086 139.73844135696658 25.478 35.667064429987086 139.73844135696658 27.865 35.66705507365545 139.73842982517644 27.865 35.66705507365545 139.73842982517644 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5276bf23-f000-445f-a01d-c9023631f02d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5276bf23-f000-445f-a01d-c9023631f02d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5276bf23-f000-445f-a01d-c9023631f02d">
											<gml:posList>35.66707624240717 139.73833265227591 13.065 35.66711485844705 139.73837988259032 13.065 35.667064429987086 139.73844135696658 13.065 35.66702536485217 139.7383961154274 13.065 35.66707624240717 139.73833265227591 13.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b666364d-ad8b-4076-a509-7254402d5de0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b666364d-ad8b-4076-a509-7254402d5de0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b666364d-ad8b-4076-a509-7254402d5de0">
											<gml:posList>35.66707624240717 139.73833265227591 23.352 35.66706737260848 139.73834371963292 25.478 35.66709776602524 139.7383768652333 25.478 35.66707624240717 139.73833265227591 23.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22b4e5ef-d51f-4238-88ea-1b193200453a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22b4e5ef-d51f-4238-88ea-1b193200453a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22b4e5ef-d51f-4238-88ea-1b193200453a">
											<gml:posList>35.66709776602524 139.7383768652333 25.478 35.66711485844705 139.73837988259032 23.352 35.66707624240717 139.73833265227591 23.352 35.66709776602524 139.7383768652333 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c31f2aa-069e-4698-bf02-fb9bf257777d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c31f2aa-069e-4698-bf02-fb9bf257777d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c31f2aa-069e-4698-bf02-fb9bf257777d">
											<gml:posList>35.66706737260848 139.73834371963292 25.478 35.66706741008364 139.73834552005442 25.478 35.667096242783764 139.73837696644938 25.478 35.66709776602524 139.7383768652333 25.478 35.66706737260848 139.73834371963292 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-046548fa-82a4-4618-8af4-48537e53a433">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-046548fa-82a4-4618-8af4-48537e53a433">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-046548fa-82a4-4618-8af4-48537e53a433">
											<gml:posList>35.66702536485217 139.7383961154274 25.478 35.667026879132216 139.73839608049718 25.478 35.66706741008364 139.73834552005442 25.478 35.66706737260848 139.73834371963292 25.478 35.66702536485217 139.7383961154274 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6cb89ae1-a575-40f3-ae96-cef556fcf2b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cb89ae1-a575-40f3-ae96-cef556fcf2b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cb89ae1-a575-40f3-ae96-cef556fcf2b0">
											<gml:posList>35.66708680757218 139.73839114939088 25.478 35.66709776602524 139.7383768652333 25.478 35.667096242783764 139.73837696644938 25.478 35.66708604969626 139.73839023348634 25.478 35.66708680757218 139.73839114939088 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1606c9e2-1146-4676-88d6-7c92163ced48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1606c9e2-1146-4676-88d6-7c92163ced48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1606c9e2-1146-4676-88d6-7c92163ced48">
											<gml:posList>35.66708604969626 139.73839023348634 24.583 35.667096242783764 139.73837696644938 24.583 35.66706741008364 139.73834552005442 24.583 35.667026879132216 139.73839608049718 24.583 35.667054802085815 139.73842835640633 24.583 35.66708604969626 139.73839023348634 24.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0cad3278-e9cb-45b1-bd3a-ac5da593aee4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cad3278-e9cb-45b1-bd3a-ac5da593aee4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cad3278-e9cb-45b1-bd3a-ac5da593aee4">
											<gml:posList>35.667096163898776 139.73840267013526 23.352 35.66711485844705 139.73837988259032 23.352 35.66709776602524 139.7383768652333 25.478 35.667096163898776 139.73840267013526 23.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ec457f8-4fba-4cc4-b746-ca6518349abd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ec457f8-4fba-4cc4-b746-ca6518349abd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ec457f8-4fba-4cc4-b746-ca6518349abd">
											<gml:posList>35.66709776602524 139.7383768652333 25.478 35.66708680757218 139.73839114939088 25.478 35.667096163898776 139.73840267013526 23.352 35.66709776602524 139.7383768652333 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-119df4c9-9adf-4d01-b93e-9401360a580b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-119df4c9-9adf-4d01-b93e-9401360a580b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-119df4c9-9adf-4d01-b93e-9401360a580b">
											<gml:posList>35.66708680757218 139.73839114939088 25.478 35.66708604969626 139.73839023348634 25.478 35.667054802085815 139.73842835640633 25.478 35.66705482153225 139.7384301568489 25.478 35.66708680757218 139.73839114939088 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01d022b1-47ce-490e-9e7f-2d41aaa9d75c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01d022b1-47ce-490e-9e7f-2d41aaa9d75c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01d022b1-47ce-490e-9e7f-2d41aaa9d75c">
											<gml:posList>35.66705482153225 139.7384301568489 25.478 35.667054802085815 139.73842835640633 25.478 35.667026879132216 139.73839608049718 25.478 35.66702536485217 139.7383961154274 25.478 35.66705482153225 139.7384301568489 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e78058f7-ce14-4783-802a-a54a75eef9f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e78058f7-ce14-4783-802a-a54a75eef9f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e78058f7-ce14-4783-802a-a54a75eef9f4">
											<gml:posList>35.667064429987086 139.73844135696658 25.478 35.667096163898776 139.73840267013526 25.478 35.66708680757218 139.73839114939088 25.478 35.66705482153225 139.7384301568489 25.478 35.667064429987086 139.73844135696658 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49a6d4b1-0210-4689-b3e9-90b2091019f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49a6d4b1-0210-4689-b3e9-90b2091019f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49a6d4b1-0210-4689-b3e9-90b2091019f0">
											<gml:posList>35.66708604969626 139.73839023348634 25.478 35.66708604969626 139.73839023348634 24.583 35.667054802085815 139.73842835640633 24.583 35.667054802085815 139.73842835640633 25.478 35.66708604969626 139.73839023348634 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-195a1830-c302-45c3-b3fa-2fc69020e6a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-195a1830-c302-45c3-b3fa-2fc69020e6a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-195a1830-c302-45c3-b3fa-2fc69020e6a1">
											<gml:posList>35.66711485844705 139.73837988259032 13.065 35.66707624240717 139.73833265227591 13.065 35.66707624240717 139.73833265227591 23.352 35.66711485844705 139.73837988259032 23.352 35.66711485844705 139.73837988259032 13.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e90b3dfe-3469-49a7-8b54-217ebee93ca4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e90b3dfe-3469-49a7-8b54-217ebee93ca4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e90b3dfe-3469-49a7-8b54-217ebee93ca4">
											<gml:posList>35.66706741008364 139.73834552005442 25.478 35.66706741008364 139.73834552005442 24.583 35.667096242783764 139.73837696644938 24.583 35.667096242783764 139.73837696644938 25.478 35.66706741008364 139.73834552005442 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22238f28-6138-47ab-8ea2-7537089c905b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22238f28-6138-47ab-8ea2-7537089c905b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22238f28-6138-47ab-8ea2-7537089c905b">
											<gml:posList>35.66706737260848 139.73834371963292 25.478 35.66707624240717 139.73833265227591 23.352 35.66707624240717 139.73833265227591 13.065 35.66702536485217 139.7383961154274 13.065 35.66702536485217 139.7383961154274 25.478 35.66706737260848 139.73834371963292 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b64bd0ed-d5bc-440d-9c5e-1ced38a09ef6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b64bd0ed-d5bc-440d-9c5e-1ced38a09ef6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b64bd0ed-d5bc-440d-9c5e-1ced38a09ef6">
											<gml:posList>35.667026879132216 139.73839608049718 25.478 35.667026879132216 139.73839608049718 24.583 35.66706741008364 139.73834552005442 24.583 35.66706741008364 139.73834552005442 25.478 35.667026879132216 139.73839608049718 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92d60b36-513e-41b1-99d8-46b5a968209f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92d60b36-513e-41b1-99d8-46b5a968209f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92d60b36-513e-41b1-99d8-46b5a968209f">
											<gml:posList>35.667096242783764 139.73837696644938 25.478 35.667096242783764 139.73837696644938 24.583 35.66708604969626 139.73839023348634 24.583 35.66708604969626 139.73839023348634 25.478 35.667096242783764 139.73837696644938 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd69325a-1eff-455a-8cfd-38c93550dd46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd69325a-1eff-455a-8cfd-38c93550dd46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd69325a-1eff-455a-8cfd-38c93550dd46">
											<gml:posList>35.667096163898776 139.73840267013526 23.352 35.66708680757218 139.73839114939088 25.478 35.667096163898776 139.73840267013526 25.478 35.667096163898776 139.73840267013526 23.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d03337b9-4b23-4d03-997c-0f316ce6d3f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d03337b9-4b23-4d03-997c-0f316ce6d3f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d03337b9-4b23-4d03-997c-0f316ce6d3f6">
											<gml:posList>35.667096163898776 139.73840267013526 23.352 35.667096163898776 139.73840267013526 25.478 35.667064429987086 139.73844135696658 25.478 35.667064429987086 139.73844135696658 13.065 35.66711485844705 139.73837988259032 13.065 35.66711485844705 139.73837988259032 23.352 35.667096163898776 139.73840267013526 23.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-146cdbd3-7835-4cb2-a752-4ac3e3ee3422">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-146cdbd3-7835-4cb2-a752-4ac3e3ee3422">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-146cdbd3-7835-4cb2-a752-4ac3e3ee3422">
											<gml:posList>35.667054802085815 139.73842835640633 25.478 35.667054802085815 139.73842835640633 24.583 35.667026879132216 139.73839608049718 24.583 35.667026879132216 139.73839608049718 25.478 35.667054802085815 139.73842835640633 25.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9194a35f-a017-4a9d-8e90-7551f6770982">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9194a35f-a017-4a9d-8e90-7551f6770982">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9194a35f-a017-4a9d-8e90-7551f6770982">
											<gml:posList>35.66702536485217 139.7383961154274 13.065 35.667064429987086 139.73844135696658 13.065 35.667064429987086 139.73844135696658 25.478 35.66705482153225 139.7384301568489 25.478 35.66702536485217 139.7383961154274 25.478 35.66702536485217 139.7383961154274 13.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-504</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">47.892</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>